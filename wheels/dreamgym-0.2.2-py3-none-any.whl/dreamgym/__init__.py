import copy

from gymnasium.envs.registration import register

DEFAULT_AUTONOMOUS_DRIVING_ENV_KWARGS = {
    "render_mode": None,
    "render_config": None,
    "visualization_theme": None,
    "bicycle_model_config": {
        "axle_geometry": {
            "front_axle_distance_from_center_of_mass_m": 1.0,
            "rear_axle_distance_from_center_of_mass_m": 1.0,
        },
        "mass_properties": {
            "mass_kg": 1000.0,
            "yaw_moment_of_inertia_kg_m2": 1000.0,
        },
        "longitudinal_force_model": {
            "normalized_motor_command_force_gain_n": 1000.0,
            "quadratic_aerodynamic_drag_coefficient_kg_per_m": 0.0,
        },
        "steering": {
            "physical_front_wheel_angle_offset_from_request_rad": 0.0,
            "requested_front_wheel_angle_magnitude_limit_rad": 0.7853981633974483,
            "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                "lower": -1.5707963267948966,
                "upper": 1.5707963267948966,
            },
        },
        "kinematic_dynamic_transition": {
            "body_longitudinal_speed_range_mps": {
                "lower": 3.0,
                "upper": 5.0,
            },
        },
    },
    "road_spec": {
        "elements": [
            {
                "geometry": {
                    "type": "straight",
                    "length_m": 100.0,
                }
            },
        ],
    },
    "integration_config": {
        "method": "rk4",
        "environment_step_duration_s": 0.05,
        "substep_count": 1,
    },
    "termination_config": {},
    "initial_state_config": {
        "bounds": {
            "world_pose": {
                "x_m": {"lower": 0.0, "upper": 0.0},
                "y_m": {"lower": 0.0, "upper": 0.0},
                "heading_rad": {"lower": 0.0, "upper": 0.0},
            },
            "body_motion": {
                "longitudinal_velocity_mps": {
                    "lower": 0.0,
                    "upper": 0.0,
                },
                "lateral_velocity_mps": {"lower": 0.0, "upper": 0.0},
                "yaw_rate_rad_per_s": {"lower": 0.0, "upper": 0.0},
            },
            "front_wheel_steering_angle_rad": {
                "lower": 0.0,
                "upper": 0.0,
            },
        },
        "reference_line_progress_search": None,
    },
    "observation_config": {},
    "target_line_config": {},
    "ground_truth_mode": "operational",
    "observation_format": "dict",
}

register(
    id="dreamgym/autonomous_driving_env",
    entry_point="dreamgym.envs:AutonomousDrivingEnv",
    kwargs=copy.deepcopy(DEFAULT_AUTONOMOUS_DRIVING_ENV_KWARGS),
    max_episode_steps=None,
    reward_threshold=None,
    nondeterministic=False,
    order_enforce=True,
)

# register(
#     id="dreamgym/pendulum",
#     entry_point="dreamgym.envs:PendulumEnv",
#     max_episode_steps=None,
#     reward_threshold=None,
#     nondeterministic=False,
#     order_enforce=True,
# )

# register(
#    id="dreamgym/rocket2d",
#    entry_point="dreamgym.envs:RocketEnv",
#    max_episode_steps=None,
#    reward_threshold=None,
#    nondeterministic=False,
#    order_enforce=True,
# )

# register(
#     id="dreamgym/service_bot",
#     entry_point="dreamgym.envs:ServiceBot",
#     max_episode_steps=None,
#     reward_threshold=None,
#     nondeterministic=False,
#     order_enforce=True,
# )
