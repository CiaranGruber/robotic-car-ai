"""Training namespaces for dreamgym environments."""
