"""Stable named seed derivation for autonomous-driving training."""

from __future__ import annotations

import hashlib


SEED_DERIVATION_VERSION = "dreamgym-seed-derivation-v1"


def seed_derivation_version():
    """Return the supported derivation version without exposing mutable state."""

    return SEED_DERIVATION_VERSION


def derive_seed(namespace, *components):
    """Derive a reproducible NumPy-compatible seed from a named integer tuple."""

    if not isinstance(namespace, str) or not namespace:
        raise ValueError("seed namespace must be a non-empty string.")
    integers = []
    for component in components:
        if isinstance(component, bool) or not isinstance(component, int):
            raise TypeError("seed components must be integers.")
        integers.append(str(component))
    payload = "|".join((SEED_DERIVATION_VERSION, namespace, *integers))
    digest = hashlib.sha256(payload.encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") & 0x7FFFFFFF
