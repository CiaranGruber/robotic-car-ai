"""Evaluation and artifact helpers for training runs."""

from __future__ import annotations

import contextlib
import csv
from pathlib import Path
import random
from typing import Any, Dict, List, Optional

import matplotlib.pyplot as pyplot
import numpy as np

from dreamgym.evaluation.autonomous_driving.performance_metrics import (
    compute_autonomous_driving_metrics,
    default_metric_set,
)
from dreamgym.evaluation.autonomous_driving.simulation import simulate_policy
from dreamgym.visualization.autonomous_driving import (
    animate_simulation_trajectory,
    save_trajectory_animation,
)
from dreamgym.training.autonomous_driving.envs import (
    make_env,
    make_env_from_evaluation_view,
)
from dreamgym.training.autonomous_driving.models import import_sb3
from dreamgym.training.autonomous_driving.resolution import (
    EvaluationConfigView,
    EvaluationRoadCase,
    ResolvedTrainingConfig,
    evaluation_road_specs,
    evaluation_road_specs_from_snapshot,
    resolve_final_animation_road_case,
)


def _evaluation_configuration(config):
    if not hasattr(config, "to_dict"):
        raise TypeError("config must expose a detached resolved snapshot.")
    snapshot = config.to_dict()
    evaluation = snapshot.get("evaluation")
    if type(evaluation) is not dict:
        raise TypeError("config.evaluation must be an object.")
    if "configuration" in evaluation:
        evaluation = evaluation["configuration"]
    if type(evaluation) is not dict:
        raise TypeError("config.evaluation.configuration must be an object.")
    return evaluation


def _validate_execution_identity(
    evaluation_execution_context,
    scheduled_evaluation_step,
    actual_training_step,
):
    if evaluation_execution_context == "standalone":
        if scheduled_evaluation_step is not None:
            raise ValueError(
                "standalone evaluation requires scheduled_evaluation_step=None."
            )
    elif evaluation_execution_context == "during_training":
        if (
            type(scheduled_evaluation_step) is not int
            or scheduled_evaluation_step < 0
        ):
            raise ValueError(
                "during_training evaluation requires a non-negative "
                "scheduled_evaluation_step."
            )
    else:
        raise ValueError(
            "evaluation_execution_context must be during_training or standalone."
        )
    if actual_training_step is not None and (
        type(actual_training_step) is not int or actual_training_step < 0
    ):
        raise TypeError("actual_training_step must be null or non-negative.")


def _resolved_policy_name(
    config,
    *,
    evaluation_execution_context,
    scheduled_evaluation_step,
    policy_name,
    model_stem,
):
    if policy_name is not None:
        if type(policy_name) is not str or not policy_name:
            raise ValueError("policy_name must be null or a non-empty string.")
        return policy_name
    experiment_name = config.experiment_name
    if evaluation_execution_context == "during_training":
        return (
            experiment_name
            + "/model_at_evaluation_"
            + f"{scheduled_evaluation_step:09d}"
        )
    if type(model_stem) is not str or not model_stem:
        raise ValueError(
            "model_stem must be a non-empty string when standalone policy_name "
            "is omitted."
        )
    return experiment_name + "/" + model_stem


@contextlib.contextmanager
def isolated_action_sampling_rng(seed):
    """Seed action sampling temporarily without perturbing training RNG state."""

    import_sb3()
    import torch

    if type(seed) is not int or seed < 0:
        raise TypeError("action sampling seed must be a non-negative integer.")
    python_state = random.getstate()
    numpy_state = np.random.get_state()
    torch_state = torch.random.get_rng_state()
    cuda_states = (
        torch.cuda.get_rng_state_all()
        if torch.cuda.is_initialized()
        else None
    )
    try:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if cuda_states is not None:
            torch.cuda.manual_seed_all(seed)
        yield
    finally:
        random.setstate(python_state)
        np.random.set_state(numpy_state)
        torch.random.set_rng_state(torch_state)
        if cuda_states is not None:
            torch.cuda.set_rng_state_all(cuda_states)


class _RlModelPolicy:
    def __init__(self, model: Any, deterministic: bool):
        self.model = model
        self.deterministic = bool(deterministic)

    def compute_action(self, observation, info_dict, terminated, truncated):
        action, _state = self.model.predict(
            observation,
            deterministic=self.deterministic,
        )
        return action


def _make_evaluation_env(config, road_spec):
    if isinstance(config, ResolvedTrainingConfig) or not isinstance(
        config,
        EvaluationConfigView,
    ):
        return make_env(
            config.build,
            road_spec=road_spec,
            apply_reward=True,
            use_training_randomization=False,
        )
    return make_env_from_evaluation_view(config, road_spec=road_spec)


def evaluate_model_on_road_specs(
    model: Any,
    config: EvaluationConfigView,
    road_specs: List[EvaluationRoadCase],
    *,
    evaluation_execution_context: str,
    scheduled_evaluation_step: int | None,
    actual_training_step: int | None,
    policy_name: str | None = None,
    model_stem: str | None = None,
    max_rollout_steps_per_road: Optional[int] = None,
    deterministic_actions: Optional[bool] = None,
) -> List[Dict[str, Any]]:
    _validate_execution_identity(
        evaluation_execution_context,
        scheduled_evaluation_step,
        actual_training_step,
    )
    evaluation = _evaluation_configuration(config)
    n_steps = int(
        max_rollout_steps_per_road
        if max_rollout_steps_per_road is not None
        else evaluation["max_rollout_steps_per_road"]
    )
    deterministic = bool(
        evaluation["deterministic_actions"]
        if deterministic_actions is None
        else deterministic_actions
    )
    effective_policy_name = _resolved_policy_name(
        config,
        evaluation_execution_context=evaluation_execution_context,
        scheduled_evaluation_step=scheduled_evaluation_step,
        policy_name=policy_name,
        model_stem=model_stem,
    )
    rows = []
    for road_case in road_specs:
        if not isinstance(road_case, EvaluationRoadCase):
            raise TypeError("road_specs must contain EvaluationRoadCase values.")
        action_seed = (
            None
            if deterministic
            else road_case.stochastic_policy_action_seed
        )
        if not deterministic and action_seed is None:
            raise ValueError(
                "stochastic evaluation road cases require an action seed."
            )
        env = _make_evaluation_env(
            config,
            road_case.to_dict()["road_spec"],
        )
        try:
            rng_context = (
                contextlib.nullcontext()
                if deterministic
                else isolated_action_sampling_rng(action_seed)
            )
            with rng_context:
                time_series = simulate_policy(
                    env,
                    n_steps,
                    _RlModelPolicy(model, deterministic),
                    seed=road_case.environment_reset_seed,
                    should_save_look_ahead_results=False,
                    should_save_observations=False,
                    verbose=0,
                )
            metric_values = compute_autonomous_driving_metrics(
                time_series,
                default_metric_set(),
            )
            rows.append({
                "evaluation_execution_context": evaluation_execution_context,
                "scheduled_evaluation_step": scheduled_evaluation_step,
                "actual_training_step": actual_training_step,
                "policy_name": effective_policy_name,
                "road_name": road_case.road_name,
                "road_family": road_case.road_family,
                "road_family_index": road_case.road_family_index,
                "road_generation_seed": road_case.road_generation_seed,
                "environment_reset_seed": road_case.environment_reset_seed,
                "stochastic_policy_action_seed": action_seed,
                **metric_values,
                "terminated": bool(time_series.get("terminated", False)),
                "truncated": bool(time_series.get("truncated", False)),
            })
        finally:
            env.close()
    return rows


def write_metrics_csv(rows: List[Dict[str, Any]], path: str | Path, *, append: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    mode = "a" if append and path.exists() else "w"
    with path.open(mode, newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if mode == "w":
            writer.writeheader()
        writer.writerows(rows)


def save_policy_animation(
    model: Any,
    config: EvaluationConfigView,
    road_case: EvaluationRoadCase,
    path: str | Path,
    *,
    max_rollout_steps_per_road: Optional[int] = None,
    deterministic_actions: Optional[bool] = None,
) -> Path:
    if not isinstance(road_case, EvaluationRoadCase):
        raise TypeError("road_case must be an EvaluationRoadCase.")
    evaluation = _evaluation_configuration(config)
    n_steps = int(
        max_rollout_steps_per_road
        if max_rollout_steps_per_road is not None
        else evaluation["max_rollout_steps_per_road"]
    )
    deterministic = (
        evaluation["deterministic_actions"]
        if deterministic_actions is None
        else deterministic_actions
    )
    action_seed = (
        None
        if deterministic
        else road_case.stochastic_policy_action_seed
    )
    if not deterministic and action_seed is None:
        raise ValueError("stochastic animation road cases require an action seed.")
    env = _make_evaluation_env(
        config,
        road_case.to_dict()["road_spec"],
    )
    try:
        observation, _info = env.reset(
            seed=road_case.environment_reset_seed
        )
        px = np.full(n_steps + 1, np.nan, dtype=np.float32)
        py = np.full(n_steps + 1, np.nan, dtype=np.float32)
        theta = np.full(n_steps + 1, np.nan, dtype=np.float32)
        delta = np.full(n_steps + 1, np.nan, dtype=np.float32)

        def store(index: int) -> None:
            gt = env.unwrapped.get_current_ground_truth()
            px[index] = float(gt["ground_truth_world_position_x_m"])
            py[index] = float(gt["ground_truth_world_position_y_m"])
            theta[index] = float(
                gt["ground_truth_heading_in_world_frame_rad"]
            )
            delta[index] = float(
                gt["ground_truth_front_wheel_steering_angle_rad"]
            )

        store(0)
        last_index = 0
        rng_context = (
            contextlib.nullcontext()
            if deterministic
            else isolated_action_sampling_rng(action_seed)
        )
        with rng_context:
            for step_idx in range(n_steps):
                action, _state = model.predict(
                    observation,
                    deterministic=bool(deterministic),
                )
                observation, _reward, terminated, truncated, _info = env.step(
                    action
                )
                last_index = step_idx + 1
                store(last_index)
                if terminated or truncated:
                    break

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        trajectory_results = {
            "px": px[:last_index + 1],
            "py": py[:last_index + 1],
            "theta": theta[:last_index + 1],
            "delta": delta[:last_index + 1],
        }
        animation = None
        animation = animate_simulation_trajectory(
            env,
            trajectory_results,
            Ts=env.unwrapped.environment_step_duration_s,
            frame_step=1,
        )
        owned_figure = animation._fig
        try:
            saved_path = save_trajectory_animation(
                animation,
                path.parent,
                file_name=path.name,
                writer="pillow",
            )
        except BaseException:
            try:
                pyplot.close(owned_figure)
            except BaseException:
                pass
            raise
        else:
            pyplot.close(owned_figure)
    except BaseException:
        try:
            env.close()
        except BaseException:
            pass
        raise
    else:
        env.close()
        return saved_path
