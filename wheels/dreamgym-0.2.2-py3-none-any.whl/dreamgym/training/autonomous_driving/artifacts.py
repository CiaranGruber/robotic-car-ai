"""Canonical paths for artifacts owned by one training run."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RunArtifactPaths:
    run_dir: Path

    @property
    def config_json(self) -> Path:
        return self.run_dir / "config.json"

    @property
    def resolved_config_json(self) -> Path:
        return self.run_dir / "resolved_config.json"

    @property
    def progress_csv(self) -> Path:
        return self.run_dir / "progress.csv"

    @property
    def monitor_csv(self) -> Path:
        return self.run_dir / "monitor.csv"

    @property
    def eval_metrics_csv(self) -> Path:
        return self.run_dir / "eval" / "eval_metrics.csv"

    @property
    def final_model(self) -> Path:
        return self.run_dir / "models" / "final.zip"

    def model_at_evaluation(self, scheduled_step: int) -> Path:
        return (
            self.run_dir
            / "models"
            / f"model_at_evaluation_{scheduled_step:09d}.zip"
        )

    def evaluation_road_summary_at(self, scheduled_step: int) -> Path:
        return (
            self.run_dir
            / "plots"
            / f"evaluation_road_summary_at_{scheduled_step:09d}.png"
        )

    def training_progress_at(self, scheduled_step: int) -> Path:
        return (
            self.run_dir
            / "plots"
            / f"training_progress_at_{scheduled_step:09d}.png"
        )

    @property
    def final_plot(self) -> Path:
        return self.run_dir / "plots" / "final_training_progress.png"

    def scheduled_animation(self, scheduled_step: int, road_name: str) -> Path:
        return (
            self.run_dir
            / "animations"
            / (
                f"policy_at_evaluation_{scheduled_step:09d}"
                f"_on_{road_name}.gif"
            )
        )

    def final_animation(self, actual_step: int, road_name: str) -> Path:
        return (
            self.run_dir
            / "animations"
            / (
                f"final_policy_at_actual_training_step_{actual_step:09d}"
                f"_on_{road_name}.gif"
            )
        )


def run_artifact_paths(run_dir: str | Path) -> RunArtifactPaths:
    return RunArtifactPaths(Path(run_dir))
