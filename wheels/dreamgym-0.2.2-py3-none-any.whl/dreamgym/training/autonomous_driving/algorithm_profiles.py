"""Explicit Stable-Baselines3 algorithm profiles for training schema v1."""

from __future__ import annotations

import copy
import math

from dreamgym.envs.config_validation import finite_float
from dreamgym.training.autonomous_driving.config_validation import (
    freeze_json,
    thaw_json,
)


ALGORITHM_PROFILE_VERSION = "dreamgym-sb3-2.9-v1"


ALGORITHM_PROFILES = freeze_json({
    "PPO": {
        "algorithm_default_n_envs": 8,
        "algorithm_default_rollout_transitions": 2_048,
        "constructor_kwargs": {
            "learning_rate": 3e-4,
            "batch_size": 64,
            "n_epochs": 4,
            "gamma": 0.99,
            "gae_lambda": 0.95,
            "clip_range": 0.2,
            "clip_range_vf": None,
            "normalize_advantage": True,
            "ent_coef": 0.0,
            "vf_coef": 0.5,
            "max_grad_norm": 0.5,
            "use_sde": False,
            "sde_sample_freq": -1,
            "target_kl": None,
            "stats_window_size": 100,
            "device": "cpu",
        },
        "policy_kwargs": {
            "activation_fn": "tanh",
            "net_arch": {"pi": [64, 64], "vf": [64, 64]},
        },
    },
    "A2C": {
        "algorithm_default_n_envs": 8,
        "algorithm_default_rollout_transitions": 40,
        "constructor_kwargs": {
            "learning_rate": 7e-4,
            "gamma": 0.99,
            "gae_lambda": 1.0,
            "ent_coef": 0.0,
            "vf_coef": 0.5,
            "max_grad_norm": 0.5,
            "rms_prop_eps": 1e-5,
            "use_rms_prop": True,
            "normalize_advantage": False,
            "use_sde": False,
            "sde_sample_freq": -1,
            "stats_window_size": 100,
            "device": "cpu",
        },
        "policy_kwargs": {
            "activation_fn": "tanh",
            "net_arch": {"pi": [64, 64], "vf": [64, 64]},
        },
    },
    "SAC": {
        "algorithm_default_n_envs": 1,
        "algorithm_default_rollout_transitions": None,
        "constructor_kwargs": {
            "learning_rate": 3e-4,
            "buffer_size": 1_000_000,
            "learning_starts": 100,
            "batch_size": 256,
            "tau": 0.005,
            "gamma": 0.99,
            "train_freq": 1,
            "gradient_steps": 1,
            "n_steps": 1,
            "action_noise": None,
            "optimize_memory_usage": False,
            "ent_coef": "auto",
            "target_update_interval": 1,
            "target_entropy": "auto",
            "use_sde": False,
            "sde_sample_freq": -1,
            "use_sde_at_warmup": False,
            "stats_window_size": 100,
            "device": "cpu",
        },
        "policy_kwargs": {
            "activation_fn": "relu",
            "net_arch": {"pi": [256, 256], "qf": [256, 256]},
        },
    },
    "TD3": {
        "algorithm_default_n_envs": 1,
        "algorithm_default_rollout_transitions": None,
        "constructor_kwargs": {
            "learning_rate": 1e-3,
            "buffer_size": 1_000_000,
            "learning_starts": 100,
            "batch_size": 256,
            "tau": 0.005,
            "gamma": 0.99,
            "train_freq": 1,
            "gradient_steps": 1,
            "n_steps": 1,
            "action_noise": None,
            "optimize_memory_usage": False,
            "policy_delay": 2,
            "target_policy_noise": 0.2,
            "target_noise_clip": 0.5,
            "stats_window_size": 100,
            "device": "cpu",
        },
        "policy_kwargs": {
            "activation_fn": "relu",
            "net_arch": {"pi": [400, 300], "qf": [400, 300]},
        },
    },
    "DDPG": {
        "algorithm_default_n_envs": 1,
        "algorithm_default_rollout_transitions": None,
        "constructor_kwargs": {
            "learning_rate": 1e-3,
            "buffer_size": 1_000_000,
            "learning_starts": 100,
            "batch_size": 256,
            "tau": 0.005,
            "gamma": 0.99,
            "train_freq": 1,
            "gradient_steps": 1,
            "n_steps": 1,
            "action_noise": None,
            "optimize_memory_usage": False,
            "device": "cpu",
        },
        "policy_kwargs": {
            "activation_fn": "relu",
            "net_arch": {"pi": [400, 300], "qf": [400, 300]},
        },
    },
})


RESERVED_HYPERPARAMETER_KEYS = frozenset(
    {
        "policy",
        "env",
        "seed",
        "verbose",
        "tensorboard_log",
        "policy_kwargs",
        "n_envs",
        "n_rollout_transitions_per_update",
        "_init_setup_model",
        "rollout_buffer_class",
        "rollout_buffer_kwargs",
        "replay_buffer_class",
        "replay_buffer_kwargs",
    }
)
POLICY_KWARG_KEYS = frozenset({"activation_fn", "net_arch"})
ACTIVATION_NAMES = frozenset({"relu", "tanh", "elu", "leaky_relu"})
ON_POLICY_NET_ARCH_KEYS = frozenset({"pi", "vf"})
OFF_POLICY_NET_ARCH_KEYS = frozenset({"pi", "qf"})


_BOOLEAN_KEYS = frozenset(
    {
        "normalize_advantage",
        "optimize_memory_usage",
        "use_rms_prop",
        "use_sde",
        "use_sde_at_warmup",
    }
)
_POSITIVE_INTEGER_KEYS = frozenset(
    {
        "batch_size",
        "buffer_size",
        "n_epochs",
        "n_steps",
        "policy_delay",
        "stats_window_size",
        "target_update_interval",
        "train_freq",
    }
)
_POSITIVE_NUMBER_KEYS = frozenset(
    {
        "clip_range",
        "learning_rate",
        "max_grad_norm",
        "rms_prop_eps",
    }
)
_NONNEGATIVE_NUMBER_KEYS = frozenset(
    {
        "ent_coef",
        "target_noise_clip",
        "target_policy_noise",
        "vf_coef",
    }
)
_UNIT_INTERVAL_KEYS = frozenset({"gae_lambda", "gamma"})


def _exact_bool(value, path):
    if type(value) is not bool:
        raise TypeError(path + " must be boolean.")
    return value


def _exact_int(value, path, *, minimum=None):
    if type(value) is not int:
        raise TypeError(path + " must be an integer.")
    if minimum is not None and value < minimum:
        raise ValueError(path + " must be at least " + str(minimum) + ".")
    return value


def _finite_number(value, path):
    if type(value) not in (int, float):
        raise TypeError(path + " must be a finite number.")
    if not math.isfinite(value):
        raise ValueError(path + " must be finite.")
    return value


def _positive_number(value, path):
    result = _finite_number(value, path)
    if result <= 0:
        raise ValueError(path + " must be positive.")
    return result


def _nonnegative_number(value, path):
    result = _finite_number(value, path)
    if result < 0:
        raise ValueError(path + " must be nonnegative.")
    return result


def validate_policy_kwargs(algorithm_name, value):
    path = "algorithm.policy_kwargs"
    if type(value) is not dict or any(type(key) is not str for key in value):
        raise TypeError(path + " must be a JSON object.")
    unknown = sorted(set(value) - POLICY_KWARG_KEYS)
    if unknown:
        raise ValueError(path + "." + unknown[0] + " is not supported.")
    if "activation_fn" in value:
        activation = value["activation_fn"]
        if type(activation) is not str:
            raise TypeError(path + ".activation_fn must be an approved string.")
        if activation not in ACTIVATION_NAMES:
            raise ValueError(path + ".activation_fn is not supported.")
    if "net_arch" not in value:
        return copy.deepcopy(value)
    architecture = value["net_arch"]
    if type(architecture) is list:
        layer_lists = [architecture]
    elif type(architecture) is dict:
        expected = (
            ON_POLICY_NET_ARCH_KEYS
            if algorithm_name in {"PPO", "A2C"}
            else OFF_POLICY_NET_ARCH_KEYS
        )
        if set(architecture) != expected:
            raise ValueError(
                path + ".net_arch keys must be " + str(sorted(expected))
            )
        if any(type(key) is not str for key in architecture):
            raise TypeError(path + ".net_arch keys must be strings.")
        layer_lists = list(architecture.values())
    else:
        raise TypeError(path + ".net_arch must be a list or object.")
    for layers in layer_lists:
        if type(layers) is not list or not layers:
            raise TypeError(path + ".net_arch layers must be nonempty lists.")
        if any(type(width) is not int or width <= 0 for width in layers):
            raise ValueError(path + ".net_arch widths must be positive integers.")
    return copy.deepcopy(value)


def validate_action_noise(algorithm_name, value):
    path = "algorithm.hyperparameters.action_noise"
    if value is None:
        return None
    if algorithm_name not in {"SAC", "TD3", "DDPG"}:
        raise ValueError(path + " is off-policy only.")
    if type(value) is not dict or set(value) != {"type", "sigma"}:
        raise ValueError(path + " requires type and sigma only.")
    if type(value["type"]) is not str or value["type"] not in {
        "normal",
        "ornstein_uhlenbeck",
    }:
        raise ValueError(path + ".type is not supported.")
    sigma = finite_float(value["sigma"], path + ".sigma")
    if sigma <= 0.0:
        raise ValueError(path + ".sigma must be positive.")
    return {"type": value["type"], "sigma": sigma}


def validate_constructor_override(key, value, *, algorithm_name):
    path = "algorithm.hyperparameters." + key
    if key == "action_noise":
        return validate_action_noise(algorithm_name, value)
    if key in _BOOLEAN_KEYS:
        return _exact_bool(value, path)
    if key in _POSITIVE_INTEGER_KEYS:
        return _exact_int(value, path, minimum=1)
    if key == "learning_starts":
        return _exact_int(value, path, minimum=0)
    if key == "gradient_steps":
        return _exact_int(value, path, minimum=-1)
    if key == "sde_sample_freq":
        frequency = _exact_int(value, path, minimum=-1)
        if frequency == 0:
            raise ValueError(path + " must be -1 or a positive integer.")
        return frequency
    if key in _POSITIVE_NUMBER_KEYS:
        return _positive_number(value, path)
    if key == "ent_coef" and value == "auto":
        if algorithm_name != "SAC":
            raise ValueError(path + "='auto' is supported only for SAC.")
        return "auto"
    if key in _NONNEGATIVE_NUMBER_KEYS:
        return _nonnegative_number(value, path)
    if key in _UNIT_INTERVAL_KEYS:
        result = _finite_number(value, path)
        if not 0.0 <= result <= 1.0:
            raise ValueError(path + " must be between zero and one.")
        return result
    if key == "tau":
        result = _finite_number(value, path)
        if not 0.0 < result <= 1.0:
            raise ValueError(path + " must be greater than zero and at most one.")
        return result
    if key in {"clip_range_vf", "target_kl"}:
        return None if value is None else _positive_number(value, path)
    if key == "target_entropy" and value == "auto":
        return "auto"
    if key == "target_entropy":
        return _finite_number(value, path)
    if key == "device":
        if type(value) is not str or not value:
            raise TypeError(path + " must be a nonempty string.")
        return value
    return _finite_number(value, path)


def resolve_profile_overrides(algorithm_name, hyperparameters, policy_kwargs):
    profile = ALGORITHM_PROFILES[algorithm_name]
    allowed = set(profile["constructor_kwargs"])
    validated_overrides = {}
    for key, value in hyperparameters.items():
        path = "algorithm.hyperparameters." + key
        if key in RESERVED_HYPERPARAMETER_KEYS or key not in allowed:
            raise ValueError(path + " is not supported for " + algorithm_name + ".")
        validated_overrides[key] = validate_constructor_override(
            key,
            value,
            algorithm_name=algorithm_name,
        )
    explicit_policy_kwargs = validate_policy_kwargs(algorithm_name, policy_kwargs)
    effective_constructor_kwargs = thaw_json(profile["constructor_kwargs"])
    effective_constructor_kwargs.update(copy.deepcopy(validated_overrides))
    effective_policy_kwargs = thaw_json(profile["policy_kwargs"])
    effective_policy_kwargs.update(copy.deepcopy(explicit_policy_kwargs))
    return (
        effective_constructor_kwargs,
        effective_policy_kwargs,
        validated_overrides,
        explicit_policy_kwargs,
    )
