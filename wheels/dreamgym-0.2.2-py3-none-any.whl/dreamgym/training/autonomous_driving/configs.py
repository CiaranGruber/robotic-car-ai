"""Schema-v2 requested configuration for autonomous-driving RL training.

These dataclasses represent user intent only. Resolution, runtime facts, and
derived values belong in ``resolved_config.json`` rather than this namespace.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


CONFIG_KIND = "dreamgym.autonomous_driving.training"
SCHEMA_VERSION = 2


@dataclass
class RoadGenerationConfig:
    """Geometry and speed ranges for one random-road distribution."""

    element_count_range: dict[str, int] = field(
        default_factory=lambda: {"lower": 4, "upper": 8}
    )
    straight_element_probability: float = 0.45
    straight: dict[str, Any] = field(
        default_factory=lambda: {
            "length_range_m": {"lower": 35.0, "upper": 140.0},
        }
    )
    circular_arc: dict[str, Any] = field(
        default_factory=lambda: {
            "radius_range_m": {"lower": 80.0, "upper": 450.0},
            "sweep_angle_range_deg": {"lower": 8.0, "upper": 45.0},
        }
    )
    speed_limit_range_kph: dict[str, float] = field(
        default_factory=lambda: {"lower": 50.0, "upper": 90.0}
    )
    first_element: dict[str, Any] = field(
        default_factory=lambda: {
            "require_straight": True,
            "straight_length_range_m": {"lower": 20.0, "upper": 60.0},
        }
    )
    initial_cross_section: dict[str, Any] = field(
        default_factory=lambda: {
            "reference_line_role": "lane_boundary",
            "left_lane_width_range_m": {"lower": 3.0, "upper": 3.8},
        }
    )
    active_lane_minimum_width_m: float = 0.05


@dataclass
class TrainRandomizationConfig(RoadGenerationConfig):
    """Training-road generation plus reset sampling and seed controls."""

    enabled: bool = True
    seed: int = 0
    reset_road_sampling_mode: str = "generate_fresh"
    n_road_specs_in_reusable_pool: int = 0


@dataclass
class RoadConfig:
    """Independent training, fixed-evaluation, and random-evaluation roads."""

    train_randomization: TrainRandomizationConfig = field(
        default_factory=TrainRandomizationConfig
    )
    fixed_train_road_spec: dict[str, Any] | None = None
    fixed_evaluation_road_specs: list[dict[str, Any]] | None = None
    random_evaluation_road_generation: RoadGenerationConfig = field(
        default_factory=RoadGenerationConfig
    )
    n_random_evaluation_roads_reused_across_evaluations: int = 3
    n_fresh_random_evaluation_roads_per_evaluation: int = 3
    evaluation_road_generation_seed: int = 1000


@dataclass
class EnvConfig:
    """Public environment, target-relative reset, observation, and limit fields."""

    observation_format: str = "flat"
    ground_truth_mode: str = "operational"
    enable_lane_keep: bool = False
    enable_cruise_control: bool = False
    action_interface: str = "auto"
    vehicle_dynamics_regime: str = "kinematic"
    tire_force_condition: str = "dry"
    integration_method: str = "rk4"
    environment_timestep_seconds: float = 0.05
    integration_substeps_per_environment_step: int = 1
    tracking_mode: str = "target_lane"
    target_lane_index: int = 1
    initial_lateral_error_range_m: list[float] = field(
        default_factory=lambda: [-1.0, 1.0]
    )
    initial_speed_error_range_kph: list[float] = field(
        default_factory=lambda: [-10.0, 0.0]
    )
    target_line_lookahead_distance_m: float = 100.0
    target_line_lookahead_point_count: int = 10
    include_cone_detection_observations: bool = False
    include_next_speed_change_observations: bool = False
    cone_detection_observation_capacity: int = 20
    cone_detection_horizontal_field_of_view_degrees: float = 120.0
    cone_detection_forward_position_upper_bound_m: float = 30.0
    termination_planar_speed_lower_bound_kph: float = 0.0
    termination_planar_speed_upper_bound_kph: float = 200.0
    termination_absolute_lateral_error_from_target_line_upper_bound_m: float = 20.0
    max_episode_steps: int | None = None


@dataclass
class VectorizationConfig:
    """Vector backend and requested count; the sentinel resolves by algorithm."""

    vec_env: str = "dummy"
    n_envs: int | str = "algorithm_default"
    subproc_start_method: str = "spawn"


@dataclass
class AlgorithmConfig:
    """Algorithm name, aggregate rollout request, and explicit SB3 overrides."""

    name: str = "PPO"
    n_rollout_transitions_per_update: int | str = "algorithm_default"
    hyperparameters: dict[str, Any] = field(default_factory=dict)
    policy_kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass
class RewardConfig:
    """Registered reward preset and a strict sparse coefficient override."""

    preset_name: str = "combined_lane_speed"
    preset_parameters: dict[str, float] = field(
        default_factory=lambda: {
            "k_lane": 1.0,
            "k_speed": 1.0,
            "k_progress": 0.0,
            "road_progress_completion_reward": 0.0,
            "absolute_lateral_error_from_target_line_termination_reward": 0.0,
            "truncation_without_termination_reward": 0.0,
        }
    )


@dataclass
class EvaluationConfig:
    """Aggregate evaluation cadence, rollout limit, action mode, and seeds."""

    interval_steps: int = 100_000
    max_rollout_steps_per_road: int = 500
    deterministic_actions: bool = True
    environment_reset_seed: int = 0
    stochastic_policy_action_seed: int = 0


@dataclass
class ArtifactConfig:
    """Independent scheduled/final model, plot, and animation controls."""

    save_model_at_evaluations: bool = True
    save_final_model: bool = True
    save_plots_at_evaluations: bool = True
    save_final_plots: bool = True
    animation_evaluation_steps: list[int] | str = field(default_factory=list)
    animation_evaluation_road_index: int = 0
    save_final_policy_animation: bool = False


@dataclass
class LoggingConfig:
    """Progress cadence and independently gated console, Monitor, and TensorBoard."""

    progress_interval_steps: int = 10_000
    print_progress_to_console: bool = True
    save_monitor_csv: bool = True
    enable_tensorboard_logging: bool = False


@dataclass
class TrainingConfig:
    """Complete requested schema-v2 training configuration."""

    config_kind: str = CONFIG_KIND
    schema_version: int = SCHEMA_VERSION
    snapshot_type: str = "requested"
    experiment_name: str = "dreamgym_rl"
    run_output_parent_dir: str = "runs"
    requested_total_environment_transitions: int = 1_000_000
    seed: int = 0
    env: EnvConfig = field(default_factory=EnvConfig)
    vectorization: VectorizationConfig = field(default_factory=VectorizationConfig)
    algorithm: AlgorithmConfig = field(default_factory=AlgorithmConfig)
    reward: RewardConfig = field(default_factory=RewardConfig)
    roads: RoadConfig = field(default_factory=RoadConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    artifacts: ArtifactConfig = field(default_factory=ArtifactConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)


def default_training_config() -> TrainingConfig:
    """Return a new detached schema-v2 requested configuration."""

    return TrainingConfig()


def config_to_dict(config: TrainingConfig) -> dict[str, Any]:
    """Serialize a validated requested configuration to plain JSON values."""

    from dreamgym.training.autonomous_driving.config_validation import (
        config_to_dict as _config_to_dict,
    )

    return _config_to_dict(config)


def config_from_dict(data: dict[str, Any]) -> TrainingConfig:
    """Validate a complete requested snapshot without overlaying defaults."""

    from dreamgym.training.autonomous_driving.config_validation import (
        config_from_dict as _config_from_dict,
    )

    return _config_from_dict(data)


def save_config_json(config: TrainingConfig, path: str | Path) -> None:
    """Write a canonical requested snapshot as strict JSON."""

    from dreamgym.training.autonomous_driving.config_validation import (
        save_config_json as _save_config_json,
    )

    _save_config_json(config, path)


def load_config_json(path: str | Path) -> TrainingConfig:
    """Load and validate a complete schema-v2 requested JSON snapshot."""

    from dreamgym.training.autonomous_driving.config_validation import (
        load_config_json as _load_config_json,
    )

    return _load_config_json(path)
