"""Run-folder management and one-call training entry point."""

from __future__ import annotations

from dataclasses import dataclass
import datetime as _datetime
import importlib.util
from pathlib import Path
import re
import time
from typing import Optional

try:
    from stable_baselines3.common.callbacks import CallbackList
    from stable_baselines3.common.vec_env import VecMonitor
except ModuleNotFoundError:
    CallbackList = None
    VecMonitor = None

from dreamgym.training.autonomous_driving.artifacts import run_artifact_paths
from dreamgym.training.autonomous_driving.callbacks import (
    CsvProgressCallback,
    ScheduledEvaluationCallback,
)
from dreamgym.training.autonomous_driving.config_validation import (
    validate_requested_config,
)
from dreamgym.training.autonomous_driving.configs import TrainingConfig
from dreamgym.training.autonomous_driving.envs import make_vec_env
from dreamgym.training.autonomous_driving.evaluation import (
    evaluate_model_on_road_specs,
    save_policy_animation,
)
from dreamgym.training.autonomous_driving.models import import_sb3, make_model
from dreamgym.training.autonomous_driving.resolution import (
    ResolvedTrainingConfig,
    resolve_final_animation_road_case,
    resolve_training_request,
)
from dreamgym.training.autonomous_driving.snapshots import (
    finalize_resolved_training_config,
    requested_snapshot,
    save_snapshot_json,
)
from dreamgym.visualization.autonomous_driving import plot_training_progress


@dataclass(frozen=True)
class TrainingResult:
    run_dir: str
    final_model_path: str | None
    config_path: str
    resolved_config_path: str
    summary_path: str
    actual_environment_transitions: int


def _training_sb3_types():
    import_sb3()
    callback_list_type = CallbackList
    vec_monitor_type = VecMonitor
    if callback_list_type is None:
        from stable_baselines3.common.callbacks import CallbackList as callback_list_type
    if vec_monitor_type is None:
        from stable_baselines3.common.vec_env import VecMonitor as vec_monitor_type
    return callback_list_type, vec_monitor_type


def _safe_name(name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name).strip())
    return safe.strip("_") or "dreamgym_rl"


def make_run_dir(config: TrainingConfig, *, now: Optional[_datetime.datetime] = None) -> Path:
    config = validate_requested_config(config)
    now = now or _datetime.datetime.now()
    base_folder_name = _safe_name(config.experiment_name) + "_" + now.strftime("%Y%m%d-%H%M%S")
    parent_dir = Path(config.run_output_parent_dir)
    for suffix in [""] + [f"_{idx:02d}" for idx in range(1, 100)]:
        run_dir = parent_dir / (base_folder_name + suffix)
        try:
            run_dir.mkdir(parents=True, exist_ok=False)
            break
        except FileExistsError:
            continue
    else:
        raise FileExistsError("Could not create a unique run directory under " + str(parent_dir))
    (run_dir / "models").mkdir()
    (run_dir / "plots").mkdir()
    (run_dir / "eval").mkdir()
    return run_dir


def _monotonic_seconds():
    return time.perf_counter()


def _require_tensorboard_dependency() -> None:
    if importlib.util.find_spec("tensorboard") is None:
        raise ImportError(
            "TensorBoard logging is enabled, but the optional 'tensorboard' "
            "package must be installed. Install it with "
            "`python -m pip install tensorboard`, or set "
            "logging.enable_tensorboard_logging to false."
        )


def write_summary(
    config: ResolvedTrainingConfig,
    run_dir: Path,
    *,
    final_model_path: str | None,
    actual_environment_transitions: int,
    elapsed_s: float,
) -> Path:
    summary_path = run_dir / "summary.md"
    build = config.build
    algorithm = config.snapshot["algorithm"]
    vectorization = config.snapshot["vectorization"]
    if algorithm["n_rollout_transitions_per_update_applicability"] == "applicable":
        collection_lines = [
            "- Aggregate on-policy rollout: requested transitions per update="
            f"{algorithm['requested_n_rollout_transitions_per_update']}, "
            "native transitions per environment="
            f"{algorithm['native_n_steps_per_environment']}, "
            "effective rollout transitions per update="
            f"{algorithm['n_rollout_transitions_per_update_effective']}"
        ]
    else:
        collection_lines = [
            "- Off-policy collection cadence: transitions per collection="
            f"{algorithm['transitions_per_collection']}, "
            "gradient steps per collection="
            f"{algorithm['gradient_steps_per_collection']}",
            "- Update-to-data ratio: "
            f"{algorithm['update_to_data_ratio']:.6g}",
        ]
    lines = [
        "# RL Training Run",
        "",
        f"- Experiment: {build.experiment_name}",
        f"- Algorithm: {algorithm['name']}",
        f"- Algorithm profile: {algorithm['profile_version']}",
        "- Requested aggregate environment transitions: "
        f"{build.requested_total_environment_transitions}",
        "- Actual aggregate environment transitions: "
        f"{actual_environment_transitions}",
        "- Vectorization: "
        f"{vectorization['vec_env']}, "
        f"requested n_envs={vectorization['requested_n_envs']}, "
        f"effective n_envs={vectorization['effective_n_envs']}",
        *collection_lines,
        "- Requested configuration: `config.json`",
        "- Resolved configuration: `resolved_config.json`",
        f"- Elapsed seconds: {elapsed_s:.3f}",
        "",
        "## Written Artifacts",
        "",
    ]
    artifact_paths = sorted(
        path.relative_to(run_dir).as_posix()
        for path in run_dir.rglob("*")
        if path.is_file() and path != summary_path
    )
    if final_model_path is not None:
        final_model = Path(final_model_path)
        if not final_model.is_file():
            raise FileNotFoundError(
                "TrainingResult final_model_path does not exist: "
                + str(final_model)
            )
    final_animation_paths = [
        path
        for path in artifact_paths
        if path.startswith(
            "animations/final_policy_at_actual_training_step_"
        )
    ]
    if final_animation_paths:
        lines.extend([
            "- Final animation provenance: "
            "`resolved_config.json#artifacts.final_policy_animation`",
            "",
        ])
    lines.extend(f"- `{path}`" for path in artifact_paths)
    lines.append("")
    summary_path.write_text("\n".join(lines), encoding="utf-8")
    return summary_path


def train(config: TrainingConfig) -> TrainingResult:
    requested = validate_requested_config(config)
    build = resolve_training_request(requested)
    run_dir = make_run_dir(requested)
    paths = run_artifact_paths(run_dir)
    save_snapshot_json(requested_snapshot(requested), paths.config_json)
    if requested.logging.enable_tensorboard_logging:
        _require_tensorboard_dependency()
    callback_list_type, vec_monitor_type = _training_sb3_types()
    started_at = _monotonic_seconds()

    env = None
    try:
        env = make_vec_env(build, stage_vector_reset_seed=False)
        monitor_filename = (
            str(paths.monitor_csv)
            if requested.logging.save_monitor_csv
            else None
        )
        env = vec_monitor_type(env, filename=monitor_filename)
        tensorboard_log = (
            str(run_dir / "tensorboard")
            if requested.logging.enable_tensorboard_logging
            else None
        )
        model = make_model(build, env, tensorboard_log=tensorboard_log)
        final_animation_road_case = resolve_final_animation_road_case(build)
        resolved_config = finalize_resolved_training_config(
            build,
            env=env,
            model=model,
            final_animation_road_case=final_animation_road_case,
        )
        save_snapshot_json(
            resolved_config.to_dict(),
            paths.resolved_config_json,
        )

        resolved_build = resolved_config.build
        progress_callback = CsvProgressCallback(
            run_dir=run_dir,
            requested_total_environment_transitions=(
                resolved_build.requested_total_environment_transitions
            ),
            progress_interval_steps=int(
                resolved_build.logging["progress_interval_steps"]
            ),
            print_progress_to_console=bool(
                resolved_build.logging["print_progress_to_console"]
            ),
        )
        callbacks = [progress_callback.callback]
        if int(resolved_build.evaluation["interval_steps"]) > 0:
            callbacks.append(
                ScheduledEvaluationCallback(
                    config=resolved_config,
                    run_dir=run_dir,
                ).callback
            )

        model.learn(
            total_timesteps=(
                resolved_build.requested_total_environment_transitions
            ),
            callback=callback_list_type(callbacks),
            progress_bar=False,
        )
        actual_environment_transitions = int(model.num_timesteps)
        final_model_path = None
        if resolved_build.artifacts["save_final_model"]:
            model.save(str(paths.final_model))
            final_model_path = str(paths.final_model)
        if resolved_build.artifacts["save_final_plots"]:
            plot_training_progress(paths.progress_csv, paths.final_plot)
        if final_animation_road_case is not None:
            save_policy_animation(
                model=model,
                config=resolved_config,
                road_case=final_animation_road_case,
                path=paths.final_animation(
                    actual_environment_transitions,
                    final_animation_road_case.road_name,
                ),
            )
        elapsed_s = _monotonic_seconds() - started_at
        summary_path = write_summary(
            resolved_config,
            run_dir,
            final_model_path=final_model_path,
            actual_environment_transitions=actual_environment_transitions,
            elapsed_s=elapsed_s,
        )
        return TrainingResult(
            run_dir=str(run_dir),
            final_model_path=final_model_path,
            config_path=str(paths.config_json),
            resolved_config_path=str(paths.resolved_config_json),
            summary_path=str(summary_path),
            actual_environment_transitions=actual_environment_transitions,
        )
    finally:
        if env is not None:
            env.close()
