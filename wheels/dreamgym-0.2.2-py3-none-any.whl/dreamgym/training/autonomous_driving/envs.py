"""Environment factories for SB3 training."""

from __future__ import annotations

import copy
import math
from typing import Any, Dict, Optional

import gymnasium as gym
import numpy as np

import dreamgym  # noqa: F401  Registers the Gymnasium env.
from dreamgym.envs.autonomous_driving_env import (
    resolve_positive_road_speed_target_mps,
)
from dreamgym.envs.road import Road
from dreamgym.training.autonomous_driving.resolution import (
    EvaluationConfigView,
    TrainingBuildConfig,
    resolve_training_road_source,
)
from dreamgym.training.autonomous_driving.rewards import make_reward_wrapper
from dreamgym.training.autonomous_driving.seeds import derive_seed


def apply_road_spec_to_env(base_env: gym.Env, road_spec: Dict[str, Any]) -> None:
    road = Road(
        road_spec=copy.deepcopy(road_spec),
        minimum_curvature_magnitude_per_m=(1.0 / 10000.0),
    )
    base_env._install_road(road)


class RandomRoadResetWrapper(gym.Wrapper):
    """Replace the road from a stable named reset stream."""

    def __init__(self, env: gym.Env, build: TrainingBuildConfig):
        super().__init__(env)
        if not isinstance(build, TrainingBuildConfig):
            raise TypeError("build must be a TrainingBuildConfig.")
        road_config = build.roads_dict()["train_randomization"]
        self.config = copy.deepcopy(road_config["controls"])
        self.generation_config = copy.deepcopy(
            road_config["normalized_generation_config"]
        )
        self._road_randomizer_seed = int(self.config["seed"])
        self._restart_stream(build.root_seed)

    def _restart_stream(self, reset_seed: int) -> None:
        self._reset_seed = int(reset_seed)
        self._reset_counter = 0
        self._pool_index = 0
        self._reused_spec = None
        self._pool = None

    def _generate_spec(self) -> Dict[str, Any]:
        seed = derive_seed(
            "training_road",
            self._reset_seed,
            self._road_randomizer_seed,
            self._reset_counter,
        )
        self._reset_counter += 1
        return Road.generate_random_spec(
            generation_config=self.generation_config,
            seed=seed,
        )

    def _next_spec(self) -> Dict[str, Any]:
        mode = self.config["reset_road_sampling_mode"]
        if mode == "generate_fresh":
            return self._generate_spec()
        if mode == "reuse_initial":
            if self._reused_spec is None:
                self._reused_spec = self._generate_spec()
            return copy.deepcopy(self._reused_spec)
        if mode == "cycle_reusable_pool":
            if self._pool is None:
                self._pool = [
                    self._generate_spec()
                    for _ in range(
                        int(self.config["n_road_specs_in_reusable_pool"])
                    )
                ]
            spec = self._pool[self._pool_index % len(self._pool)]
            self._pool_index += 1
            return copy.deepcopy(spec)
        raise ValueError(
            "roads.train_randomization.reset_road_sampling_mode is unsupported: "
            + str(mode)
        )

    def reset(self, **kwargs):
        seed = kwargs.get("seed")
        if seed is not None:
            self._restart_stream(int(seed))
        apply_road_spec_to_env(self.env.unwrapped, self._next_spec())
        return self.env.reset(**kwargs)


def _target_relative_reset_options(
    road,
    target_line_config,
    *,
    lateral_error_m,
    speed_error_kph,
    speed_error_range_kph,
    heading_error_from_target_line_rad=0.0,
    lateral_velocity_mps=0.0,
    yaw_rate_rad_per_s=0.0,
    front_wheel_steering_angle_rad=0.0,
):
    """Return exact public reset bounds for a target-relative state."""

    target_sample = road.sample_target_line_horizon(
        0.0,
        np.array([0.0], dtype=np.float64),
        target_line_config=target_line_config,
    )
    target_point = np.asarray(
        target_sample.positions_in_world_frame_m[0],
        dtype=np.float64,
    )
    theta_target = float(target_sample.headings_in_world_frame_rad[0])
    left = np.array(
        [-math.sin(theta_target), math.cos(theta_target)],
        dtype=np.float64,
    )
    position = target_point + float(lateral_error_m) * left
    speed_limits, recommended = road.convert_progression_to_speed_limits(
        np.array([0.0], dtype=np.float64)
    )
    target_speed = resolve_positive_road_speed_target_mps(
        recommended[0],
        speed_limits[0],
    )
    minimum_speed = target_speed + float(speed_error_range_kph[0]) / 3.6
    maximum_speed = target_speed + float(speed_error_range_kph[1]) / 3.6
    if minimum_speed < 0.0:
        raise ValueError(
            "The resolved initial speed range includes a negative speed: "
            f"[{minimum_speed}, {maximum_speed}] m/s."
        )
    initial_speed = target_speed + float(speed_error_kph) / 3.6
    exact = {
        "world_pose": {
            "x_m": float(position[0]),
            "y_m": float(position[1]),
            "heading_rad": (
                theta_target + float(heading_error_from_target_line_rad)
            ),
        },
        "body_motion": {
            "longitudinal_velocity_mps": float(initial_speed),
            "lateral_velocity_mps": float(lateral_velocity_mps),
            "yaw_rate_rad_per_s": float(yaw_rate_rad_per_s),
        },
        "front_wheel_steering_angle_rad": float(
            front_wheel_steering_angle_rad
        ),
    }
    bounds = {
        group: {
            leaf: {"lower": value, "upper": value}
            for leaf, value in leaves.items()
        }
        for group, leaves in exact.items()
        if isinstance(leaves, dict)
    }
    steering = exact["front_wheel_steering_angle_rad"]
    bounds["front_wheel_steering_angle_rad"] = {
        "lower": steering,
        "upper": steering,
    }
    return {
        "bounds": bounds,
        "reference_line_progress_search": {
            "lower_bound_m": 0.0,
            "upper_bound_m": 0.0,
        },
    }


class TargetRelativeInitialStateResetWrapper(gym.Wrapper):
    """Sample training errors and express them in the selected road target frame."""

    def __init__(
        self,
        env: gym.Env,
        build: TrainingBuildConfig | None = None,
        *,
        environment_record: Dict[str, Any] | None = None,
        root_seed: int | None = None,
    ):
        super().__init__(env)
        if build is not None:
            if not isinstance(build, TrainingBuildConfig):
                raise TypeError("build must be a TrainingBuildConfig.")
            environment = build.environment_dict()
            initial_seed = build.root_seed
        else:
            if type(environment_record) is not dict:
                raise TypeError("environment_record must be an object.")
            if type(root_seed) is not int or root_seed < 0:
                raise TypeError("root_seed must be a non-negative integer.")
            environment = copy.deepcopy(environment_record)
            initial_seed = root_seed
        self.target_line_config = copy.deepcopy(
            environment["public_constructor_template"]["target_line_config"]
        )
        reset = environment["target_relative_reset"]
        self._lateral_error_from_target_line_range_m = tuple(
            reset["lateral_error_from_target_line_range_m"][field]
            for field in ("lower", "upper")
        )
        speed_target = reset["body_longitudinal_velocity_target"]
        if speed_target["source"] != "road_recommended_speed_then_speed_limit":
            raise ValueError(
                "target_relative_reset.body_longitudinal_velocity_target.source "
                "is unsupported."
            )
        self._body_longitudinal_velocity_target_error_range_kph = tuple(
            speed_target["error_range_kph"][field]
            for field in ("lower", "upper")
        )
        self.heading_error_from_target_line_rad = float(
            reset["heading_error_from_target_line_rad"]
        )
        fixed = reset["fixed_state_values"]
        body_motion = fixed["body_motion"]
        self.lateral_velocity_mps = float(
            body_motion["lateral_velocity_mps"]
        )
        self.yaw_rate_rad_per_s = float(body_motion["yaw_rate_rad_per_s"])
        self.front_wheel_steering_angle_rad = float(
            fixed["front_wheel_steering_angle_rad"]
        )
        self._restart_stream(initial_seed)

    def _restart_stream(self, reset_seed):
        self._reset_seed = int(reset_seed)
        self._reset_counter = 0

    def reset(self, *, seed=None, options=None, **kwargs):
        if seed is not None:
            self._restart_stream(seed)
        state_seed = derive_seed(
            "training_initial_state",
            self._reset_seed,
            self._reset_counter,
        )
        self._reset_counter += 1
        rng = np.random.default_rng(state_seed)
        lateral_error = float(
            rng.uniform(*self._lateral_error_from_target_line_range_m)
        )
        speed_error = float(
            rng.uniform(
                *self._body_longitudinal_velocity_target_error_range_kph
            )
        )
        owned_initial_state = _target_relative_reset_options(
            self.env.unwrapped.road,
            self.target_line_config,
            lateral_error_m=lateral_error,
            speed_error_kph=speed_error,
            speed_error_range_kph=(
                self._body_longitudinal_velocity_target_error_range_kph
            ),
            heading_error_from_target_line_rad=(
                self.heading_error_from_target_line_rad
            ),
            lateral_velocity_mps=self.lateral_velocity_mps,
            yaw_rate_rad_per_s=self.yaw_rate_rad_per_s,
            front_wheel_steering_angle_rad=(
                self.front_wheel_steering_angle_rad
            ),
        )
        merged_options = copy.deepcopy(options) if options is not None else {}
        merged_options["initial_state_config"] = owned_initial_state
        return self.env.reset(
            seed=seed,
            options=merged_options,
            **kwargs,
        )


def _initial_road_spec(build, road_source, resolved_road):
    if road_source == "train_randomization":
        controls = build.roads["train_randomization"]["controls"]
        return Road.generate_random_spec(
            generation_config=resolved_road,
            seed=derive_seed(
                "training_road",
                build.root_seed,
                controls["seed"],
                0,
            ),
        )
    return copy.deepcopy(resolved_road)


def make_base_env(
    build: TrainingBuildConfig,
    *,
    road_source: str,
    road_spec: Dict[str, Any],
) -> gym.Env:
    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    environment_record = build.environment_dict()
    training = environment_record["training"]
    postconstruction = environment_record["postconstruction_settings"]
    requested_tire_condition = training["tire_force_condition"]
    resolved_tire_condition = postconstruction["tire_force_condition"]
    if requested_tire_condition != resolved_tire_condition:
        raise ValueError(
            "environment.training.tire_force_condition must equal "
            "environment.postconstruction_settings.tire_force_condition."
        )
    constructor = copy.deepcopy(
        environment_record["public_constructor_template"]
    )
    constructor["road_spec"] = _initial_road_spec(
        build,
        road_source,
        road_spec,
    )
    env = None
    try:
        env = gym.make(
            "dreamgym/autonomous_driving_env",
            **constructor,
        )
        env.unwrapped.set_tire_force_condition(resolved_tire_condition)
        return env
    except BaseException:
        if env is not None:
            try:
                env.close()
            except BaseException:
                pass
        raise


def make_env(
    build: TrainingBuildConfig,
    *,
    road_spec: Optional[Dict[str, Any]] = None,
    apply_reward: bool = True,
    use_training_randomization: bool = True,
) -> gym.Env:
    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    road_source, selected_road = resolve_training_road_source(
        build,
        road_spec=road_spec,
    )
    if road_source == "train_randomization" and not use_training_randomization:
        road_source = "default_training_road"
        selected_road = build.roads_dict()["default_training_road_spec"]
    env = None
    try:
        env = make_base_env(
            build,
            road_source=road_source,
            road_spec=selected_road,
        )
        env = TargetRelativeInitialStateResetWrapper(env, build)
        if road_source == "train_randomization":
            env = RandomRoadResetWrapper(env, build)
        environment = build.environment_dict()["training"]
        if environment["max_episode_steps"] is not None:
            env = gym.wrappers.TimeLimit(
                env,
                max_episode_steps=int(environment["max_episode_steps"]),
            )
        if apply_reward:
            env = make_reward_wrapper(env, build.reward["effective"])
        return env
    except BaseException:
        if env is not None:
            try:
                env.close()
            except BaseException:
                pass
        raise


def make_vec_env(
    build: TrainingBuildConfig,
    *,
    stage_vector_reset_seed: bool = True,
):
    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    vectorization = build.requested_dict["vectorization"]
    vec_kind = str(vectorization["vec_env"])
    n_envs = build.effective_n_envs
    from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv

    constructed_envs = []
    vec_env = None
    try:
        if vec_kind == "dummy":
            def tracked_factory():
                env = make_env(build)
                constructed_envs.append(env)
                return env

            factories = [tracked_factory for _ in range(n_envs)]
            vec_env = DummyVecEnv(factories)
            constructed_envs.clear()
        elif vec_kind == "subproc":
            factories = [lambda: make_env(build) for _ in range(n_envs)]
            vec_env = SubprocVecEnv(
                factories,
                start_method=vectorization["subproc_start_method"],
            )
        else:
            raise ValueError("vectorization.vec_env must be dummy or subproc.")
        if stage_vector_reset_seed:
            vec_env.seed(build.root_seed)
        return vec_env
    except BaseException:
        if vec_env is not None:
            try:
                vec_env.close()
            except BaseException:
                pass
        else:
            for env in constructed_envs:
                try:
                    env.close()
                except BaseException:
                    pass
        raise


def _recorded_evaluation_snapshot(config: EvaluationConfigView):
    if not isinstance(config, EvaluationConfigView):
        raise TypeError("config must implement EvaluationConfigView.")
    snapshot = config.to_dict()
    if type(snapshot) is not dict:
        raise TypeError("config.to_dict() must return an object.")
    for field_name in ("environment", "roads", "reward", "seeds"):
        if type(snapshot.get(field_name)) is not dict:
            raise TypeError("config." + field_name + " must be an object.")
    return snapshot


def make_env_from_evaluation_view(
    config: EvaluationConfigView,
    *,
    road_spec: Optional[Dict[str, Any]] = None,
) -> gym.Env:
    """Construct evaluation from recorded effective values only."""

    snapshot = _recorded_evaluation_snapshot(config)
    environment_record = snapshot["environment"]
    training = environment_record["training"]
    postconstruction = environment_record["postconstruction_settings"]
    requested_tire_condition = training["tire_force_condition"]
    resolved_tire_condition = postconstruction["tire_force_condition"]
    if requested_tire_condition != resolved_tire_condition:
        raise ValueError(
            "environment.training.tire_force_condition must equal "
            "environment.postconstruction_settings.tire_force_condition."
        )
    constructor = copy.deepcopy(
        environment_record["public_constructor_template"]
    )
    constructor["road_spec"] = (
        copy.deepcopy(road_spec)
        if road_spec is not None
        else copy.deepcopy(snapshot["roads"]["default_training_road_spec"])
    )
    env = None
    try:
        env = gym.make("dreamgym/autonomous_driving_env", **constructor)
        env.unwrapped.set_tire_force_condition(resolved_tire_condition)
        root_seed = snapshot["seeds"]["inputs"]["training_root_seed"]
        env = TargetRelativeInitialStateResetWrapper(
            env,
            environment_record=environment_record,
            root_seed=root_seed,
        )
        if training["max_episode_steps"] is not None:
            env = gym.wrappers.TimeLimit(
                env,
                max_episode_steps=int(training["max_episode_steps"]),
            )
        env = make_reward_wrapper(env, snapshot["reward"]["effective"])
        return env
    except BaseException:
        if env is not None:
            env.close()
        raise


def make_evaluation_compatibility_vec_env(
    config,
    *,
    stage_vector_reset_seed: bool = True,
):
    """Create exactly one owned DummyVecEnv for loading a saved model."""

    from stable_baselines3.common.vec_env import DummyVecEnv

    if isinstance(config, TrainingBuildConfig):
        factory = lambda: make_env(
            config,
            apply_reward=True,
            use_training_randomization=False,
        )
        seed = config.root_seed
    elif isinstance(config, EvaluationConfigView):
        factory = lambda: make_env_from_evaluation_view(config)
        snapshot = _recorded_evaluation_snapshot(config)
        seed = snapshot["seeds"]["inputs"]["training_root_seed"]
    else:
        raise TypeError(
            "config must be a TrainingBuildConfig or EvaluationConfigView."
        )
    constructed_envs = []

    def tracked_factory():
        env = factory()
        constructed_envs.append(env)
        return env

    vec_env = None
    try:
        vec_env = DummyVecEnv([tracked_factory])
        constructed_envs.clear()
        if stage_vector_reset_seed:
            vec_env.seed(seed)
        return vec_env
    except BaseException:
        if vec_env is not None:
            try:
                vec_env.close()
            except BaseException:
                pass
        else:
            for env in constructed_envs:
                try:
                    env.close()
                except BaseException:
                    pass
        raise
