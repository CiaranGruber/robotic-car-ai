"""Strict configuration discovery and owned saved-model reconstruction."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

import gymnasium as gym
import numpy as np

if TYPE_CHECKING:
    from stable_baselines3.common.vec_env import VecEnv
else:
    VecEnv = Any

from dreamgym.training.autonomous_driving.config_validation import (
    JsonValue,
    canonical_snapshot_digest,
    config_from_dict,
    freeze_json,
    parse_strict_json_object,
    thaw_json,
    validate_json_value,
)
from dreamgym.training.autonomous_driving.envs import (
    make_evaluation_compatibility_vec_env,
)
from dreamgym.training.autonomous_driving.resolution import (
    EvaluationConfigView,
    TrainingBuildConfig,
)
from dreamgym.training.autonomous_driving.snapshots import (
    decode_gym_space,
    requested_snapshot,
    validate_resolved_snapshot,
    validate_saved_model_snapshot,
)


SUPPORTED_ALGORITHMS = ("PPO", "SAC", "TD3", "DDPG", "A2C")


@dataclass(frozen=True)
class RequestedEvaluationConfig:
    """Effective evaluation view reconstructed from a requested snapshot."""

    build: TrainingBuildConfig
    snapshot: Mapping[str, JsonValue]
    source_path: Path

    def __post_init__(self):
        if not isinstance(self.build, TrainingBuildConfig):
            raise TypeError("build must be a TrainingBuildConfig.")
        plain = validate_json_value(
            self.snapshot,
            path="evaluation_runtime",
        )
        object.__setattr__(self, "snapshot", freeze_json(plain))
        object.__setattr__(self, "source_path", Path(self.source_path))

    @property
    def experiment_name(self):
        return self.build.experiment_name

    def to_dict(self):
        return thaw_json(self.snapshot)


@dataclass(frozen=True)
class LoadedResolvedEvaluationConfig:
    """Validated recorded-only view of a finalized resolved snapshot."""

    snapshot: Mapping[str, JsonValue]
    source_path: Path

    def __post_init__(self):
        plain = validate_json_value(
            self.snapshot,
            path="resolved_snapshot",
        )
        validated = validate_resolved_snapshot(plain)
        object.__setattr__(self, "snapshot", freeze_json(validated))
        object.__setattr__(self, "source_path", Path(self.source_path))

    @property
    def experiment_name(self):
        return str(self.snapshot["experiment_name"])

    def to_dict(self):
        return thaw_json(self.snapshot)


@dataclass
class LoadedEvaluationBundle:
    """Loaded policy and the compatibility environment owned with it."""

    model: Any
    env: VecEnv
    config: EvaluationConfigView
    snapshot_path: Path
    _closed: bool = field(default=False, init=False, repr=False)

    def close(self):
        if not self._closed:
            self.env.close()
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False


def discover_training_snapshot(model_path, *, explicit_config):
    """Return the authoritative requested/resolved snapshot beside a model."""

    model_path = Path(model_path).resolve()
    if explicit_config is not None:
        explicit = Path(explicit_config).resolve()
        if not explicit.is_file():
            raise FileNotFoundError(
                "Explicit --config does not exist: " + str(explicit)
            )
        return explicit
    candidates = (
        model_path.parent / "resolved_config.json",
        model_path.parent / "config.json",
        model_path.parent.parent / "resolved_config.json",
        model_path.parent.parent / "config.json",
    )
    checked = tuple(dict.fromkeys(path.resolve() for path in candidates))
    for candidate in checked:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(
        "No training configuration found. Checked: "
        + ", ".join(str(path) for path in checked)
        + ". Supply --config explicitly."
    )


def _space_difference(saved, reconstructed, path):
    if type(saved) is not type(reconstructed):
        return path + " type"
    if isinstance(saved, gym.spaces.Box):
        if saved.shape != reconstructed.shape:
            return path + " shape"
        if np.dtype(saved.dtype) != np.dtype(reconstructed.dtype):
            return path + " dtype"
        if not np.array_equal(saved.low, reconstructed.low):
            return path + " lower bounds"
        if not np.array_equal(saved.high, reconstructed.high):
            return path + " upper bounds"
        return None
    if isinstance(saved, gym.spaces.Dict):
        if list(saved.spaces) != list(reconstructed.spaces):
            return path + " ordered keys"
        for key in saved.spaces:
            difference = _space_difference(
                saved.spaces[key],
                reconstructed.spaces[key],
                path + "." + key,
            )
            if difference is not None:
                return difference
        return None
    return path + " unsupported type " + type(saved).__name__


def assert_model_spaces_match(
    *,
    saved_observation_space,
    saved_action_space,
    reconstructed_observation_space,
    reconstructed_action_space,
):
    """Require exact type, shape, dtype, order, and bound compatibility."""

    for name, saved, reconstructed in (
        (
            "observation",
            saved_observation_space,
            reconstructed_observation_space,
        ),
        ("action", saved_action_space, reconstructed_action_space),
    ):
        difference = _space_difference(saved, reconstructed, name + " space")
        if difference is not None:
            raise ValueError(
                "Saved model "
                + name
                + " space does not exactly match the reconstructed "
                + name
                + " space; first mismatch: "
                + difference
                + "."
            )


def _assert_observation_names_match(snapshot, env):
    expected = tuple(snapshot["spaces"]["flat_observation_names"])
    observed_by_environment = env.get_attr("flat_observation_names")
    if (
        type(observed_by_environment) is not list
        or len(observed_by_environment) != 1
    ):
        raise ValueError(
            "Reconstructed environment did not expose exactly one observation "
            "names record."
        )
    observed = observed_by_environment[0]
    if type(observed) is not tuple or observed != expected:
        raise ValueError(
            "Saved model observation names and order do not exactly match the "
            "reconstructed environment."
        )


def _assert_action_interfaces_match(snapshot, env):
    environment = snapshot["environment"]
    requested = environment["public_constructor_template"][
        "internal_policy_config"
    ]["action_interface"]
    effective = environment["effective_action_interface"]
    for public_name, expected in (
        ("requested_action_interface", requested),
        ("effective_action_interface", effective),
    ):
        observed_by_environment = env.get_attr(public_name)
        if (
            type(observed_by_environment) is not list
            or len(observed_by_environment) != 1
        ):
            raise ValueError(
                "Reconstructed environment did not expose exactly one "
                + public_name
                + " record."
            )
        if observed_by_environment[0] != expected:
            raise ValueError(
                "Reconstructed environment "
                + public_name
                + " does not match the finalized snapshot."
            )


def _model_class(algorithm_name):
    from dreamgym.training.autonomous_driving.models import import_sb3

    normalized = str(algorithm_name).upper()
    if normalized not in SUPPORTED_ALGORITHMS:
        raise ValueError(
            "Unsupported recorded algorithm "
            + repr(algorithm_name)
            + "; expected one of "
            + ", ".join(SUPPORTED_ALGORITHMS)
            + "."
        )
    return getattr(import_sb3(), normalized)


def _load_saved_model(model_path, *, algorithm_name, env, seed):
    """Small test seam around the selected SB3 class loader."""

    return _model_class(algorithm_name).load(
        str(model_path),
        env=env,
        seed=seed,
    )


def _read_validated_snapshot(path):
    snapshot_path = Path(path)
    plain = parse_strict_json_object(snapshot_path.read_text(encoding="utf-8"))
    return validate_saved_model_snapshot(plain)


def _verify_counterpart_digest(snapshot_path, snapshot):
    counterpart = snapshot_path.parent / "config.json"
    if not counterpart.is_file():
        return
    counterpart_plain = parse_strict_json_object(
        counterpart.read_text(encoding="utf-8")
    )
    requested = requested_snapshot(config_from_dict(counterpart_plain))
    actual_digest = canonical_snapshot_digest(requested)
    if snapshot["requested_config_digest"] != actual_digest:
        raise ValueError(
            "resolved snapshot requested_config_digest does not match "
            + str(counterpart)
            + "."
        )


def _assert_loaded_model_class(model, algorithm_name):
    expected = _model_class(algorithm_name)
    if type(model) is not expected:
        raise ValueError(
            "Loaded model class "
            + type(model).__module__
            + "."
            + type(model).__qualname__
            + " does not match recorded algorithm "
            + str(algorithm_name)
            + "."
        )


def load_model_and_config_for_evaluation(model_path, *, explicit_config=None):
    """Strictly reconstruct a saved model and transfer owned resources."""

    from dreamgym.training.autonomous_driving.models import import_sb3

    import_sb3()
    model_path = Path(model_path)
    snapshot_path = discover_training_snapshot(
        model_path,
        explicit_config=explicit_config,
    )
    snapshot = _read_validated_snapshot(snapshot_path)
    _verify_counterpart_digest(snapshot_path, snapshot)

    env = None
    try:
        config = LoadedResolvedEvaluationConfig(
            snapshot=snapshot,
            source_path=snapshot_path,
        )
        algorithm_name = str(snapshot["algorithm"]["name"])
        seed = snapshot["seeds"]["inputs"]["training_root_seed"]
        recorded_observation = decode_gym_space(
            snapshot["spaces"]["observation"]
        )
        recorded_action = decode_gym_space(snapshot["spaces"]["action"])
        env = make_evaluation_compatibility_vec_env(
            config,
            stage_vector_reset_seed=False,
        )
        _assert_observation_names_match(snapshot, env)
        _assert_action_interfaces_match(snapshot, env)
        assert_model_spaces_match(
            saved_observation_space=recorded_observation,
            saved_action_space=recorded_action,
            reconstructed_observation_space=env.observation_space,
            reconstructed_action_space=env.action_space,
        )
        model = _load_saved_model(
            model_path,
            algorithm_name=algorithm_name,
            env=env,
            seed=seed,
        )
        _assert_loaded_model_class(model, algorithm_name)
        assert_model_spaces_match(
            saved_observation_space=recorded_observation,
            saved_action_space=recorded_action,
            reconstructed_observation_space=model.observation_space,
            reconstructed_action_space=model.action_space,
        )

        return LoadedEvaluationBundle(
            model=model,
            env=env,
            config=config,
            snapshot_path=snapshot_path,
        )
    except BaseException:
        if env is not None:
            env.close()
        raise
