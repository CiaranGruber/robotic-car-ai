"""Strict validation and reconstruction for training configuration snapshots."""

from __future__ import annotations

from collections.abc import Mapping
import copy
from dataclasses import asdict, fields, is_dataclass
import hashlib
import json
import math
from pathlib import Path
from types import MappingProxyType
from typing import Any, TypeAlias, Union

from dreamgym.envs.road import Road
from dreamgym.training.autonomous_driving.configs import (
    ArtifactConfig,
    CONFIG_KIND,
    EvaluationConfig,
    LoggingConfig,
    SCHEMA_VERSION,
    EnvConfig,
    RoadGenerationConfig,
    TrainingConfig,
    TrainRandomizationConfig,
)


JsonScalar: TypeAlias = Union[None, bool, int, float, str]
JsonValue: TypeAlias = Union[
    JsonScalar,
    list["JsonValue"],
    dict[str, "JsonValue"],
]


COMBINED_LANE_SPEED_DEFAULTS = {
    "k_lane": 1.0,
    "k_speed": 1.0,
    "k_progress": 0.0,
    "road_progress_completion_reward": 0.0,
    "absolute_lateral_error_from_target_line_termination_reward": 0.0,
    "truncation_without_termination_reward": 0.0,
}

_SCHEMA_V2_MIGRATION_GUIDANCE = (
    "Schema_version 2 uses env.tire_force_condition, "
    "env.termination_planar_speed_lower_bound_kph, "
    "reward.preset_parameters.road_progress_completion_reward, and final "
    "nested random-road generation records."
)


def validate_json_value(value, *, path):
    if value is None or type(value) in (bool, int, str):
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError(path + " must be finite.")
        return value
    if type(value) is list:
        return [
            validate_json_value(item, path=path + "[" + str(index) + "]")
            for index, item in enumerate(value)
        ]
    if type(value) is dict:
        detached = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError(path + " keys must be strings.")
            detached[key] = validate_json_value(item, path=path + "." + key)
        return detached
    raise TypeError(path + " must contain only JSON-native values.")


def freeze_json(value):
    if isinstance(value, dict):
        return MappingProxyType(
            {key: freeze_json(item) for key, item in value.items()}
        )
    if isinstance(value, list):
        return tuple(freeze_json(item) for item in value)
    return value


def thaw_json(value):
    if isinstance(value, Mapping):
        return {key: thaw_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [thaw_json(item) for item in value]
    return value


def canonical_json_text(value):
    detached = validate_json_value(value, path="snapshot")
    return json.dumps(
        detached,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def canonical_snapshot_digest(value):
    return hashlib.sha256(
        canonical_json_text(value).encode("utf-8")
    ).hexdigest()


def _reject_duplicate_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + str(key))
        result[key] = value
    return result


def parse_strict_json_object(text):
    def reject_constant(value):
        raise ValueError("Non-finite JSON number is not supported: " + value)

    value = json.loads(
        text,
        object_pairs_hook=_reject_duplicate_pairs,
        parse_constant=reject_constant,
    )
    if type(value) is not dict:
        raise TypeError("Training configuration JSON must contain an object.")
    return value


def construct_dataclass_strict(cls, data, path):
    if type(data) is not dict:
        raise TypeError(path + " must be an object.")
    dataclass_fields = {item.name: item for item in fields(cls)}
    unknown = sorted(set(data) - set(dataclass_fields))
    if unknown:
        raise ValueError(path + "." + unknown[0] + " is not supported.")
    missing = sorted(set(dataclass_fields) - set(data))
    if missing:
        raise ValueError(
            path + "." + missing[0] + " is required by schema_version 2."
        )
    kwargs = {}
    prototype = cls()
    for name in dataclass_fields:
        value = copy.deepcopy(data[name])
        current = getattr(prototype, name)
        if is_dataclass(current):
            value = construct_dataclass_strict(
                type(current),
                value,
                path + "." + name,
            )
        kwargs[name] = value
    return cls(**kwargs)


def _reject_stale_dataclass_attributes(value: Any, path: str) -> None:
    if not is_dataclass(value):
        return
    field_names = {item.name for item in fields(value)}
    stale = sorted(set(vars(value)) - field_names)
    if stale:
        raise ValueError(path + "." + stale[0] + " is not supported.")
    for field_name in field_names:
        child = getattr(value, field_name)
        if is_dataclass(child):
            _reject_stale_dataclass_attributes(child, path + "." + field_name)


def _exact_bool(value: Any, path: str) -> bool:
    if type(value) is not bool:
        raise TypeError(path + " must be a boolean.")
    return value


def _exact_int(
    value: Any,
    path: str,
    *,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    if type(value) is not int:
        raise TypeError(path + " must be an integer.")
    if minimum is not None and value < minimum:
        raise ValueError(path + " must be >= " + str(minimum) + ".")
    if maximum is not None and value > maximum:
        raise ValueError(path + " must be <= " + str(maximum) + ".")
    return value


def _finite_number(value: Any, path: str) -> int | float:
    if type(value) not in (int, float):
        raise TypeError(path + " must be a number.")
    if not math.isfinite(value):
        raise ValueError(path + " must be finite.")
    return value


def _positive_number(value: Any, path: str) -> int | float:
    value = _finite_number(value, path)
    if value <= 0:
        raise ValueError(path + " must be positive.")
    return value


def _nonnegative_number(value: Any, path: str) -> int | float:
    value = _finite_number(value, path)
    if value < 0:
        raise ValueError(path + " must be non-negative.")
    return value


def _choice(value: Any, path: str, choices: tuple[str, ...]) -> str:
    if type(value) is not str or value not in choices:
        raise ValueError(path + " must be one of: " + ", ".join(choices) + ".")
    return value


def _string(value: Any, path: str) -> str:
    if type(value) is not str or not value:
        raise ValueError(path + " must be a non-empty string.")
    return value


def _range_pair(
    value: Any,
    path: str,
    *,
    integral: bool = False,
    positive: bool = False,
) -> None:
    if type(value) is not list or len(value) != 2:
        raise TypeError(path + " must be a two-value list.")
    for index, item in enumerate(value):
        item_path = path + "[" + str(index) + "]"
        if integral:
            _exact_int(item, item_path)
        else:
            _finite_number(item, item_path)
        if positive and item <= 0:
            raise ValueError(item_path + " must be positive.")
    if value[1] < value[0]:
        raise ValueError(path + " upper bound must be >= lower bound.")


def _range_mapping(
    value: Any,
    path: str,
    *,
    integral: bool = False,
    positive: bool = False,
) -> None:
    if type(value) is not dict:
        raise TypeError(path + " must be an object.")
    expected = {"lower", "upper"}
    unknown = sorted(set(value) - expected)
    if unknown:
        raise ValueError(path + "." + unknown[0] + " is not supported.")
    missing = sorted(expected - set(value))
    if missing:
        raise ValueError(path + "." + missing[0] + " is required.")
    for name in ("lower", "upper"):
        item = value[name]
        item_path = path + "." + name
        if integral:
            _exact_int(item, item_path)
        else:
            _finite_number(item, item_path)
        if positive and item <= 0:
            raise ValueError(item_path + " must be positive.")
    if value["upper"] < value["lower"]:
        raise ValueError(path + " upper bound must be >= lower bound.")


def _closed_mapping(value: Any, path: str, keys: set[str]) -> dict[str, Any]:
    if type(value) is not dict:
        raise TypeError(path + " must be an object.")
    unknown = sorted(set(value) - keys)
    if unknown:
        raise ValueError(path + "." + unknown[0] + " is not supported.")
    missing = sorted(keys - set(value))
    if missing:
        raise ValueError(path + "." + missing[0] + " is required.")
    return value


def normalize_reward_preset(preset_name, preset_parameters):
    if preset_name != "combined_lane_speed":
        raise ValueError(
            "reward.preset_name must be 'combined_lane_speed'; "
            "canonical training does not support an omitted reward wrapper."
        )
    if type(preset_parameters) is not dict:
        raise TypeError("reward.preset_parameters must be an object.")
    detached = validate_json_value(
        preset_parameters,
        path="reward.preset_parameters",
    )
    unknown = sorted(set(detached) - set(COMBINED_LANE_SPEED_DEFAULTS))
    if unknown:
        raise ValueError(
            "reward.preset_parameters." + unknown[0] + " is not supported."
        )
    effective = dict(COMBINED_LANE_SPEED_DEFAULTS)
    for key, value in detached.items():
        _finite_number(value, "reward.preset_parameters." + key)
        effective[key] = float(value)
    return {
        "preset_name": "combined_lane_speed",
        "preset_parameters": effective,
    }


def _validate_road_generation(
    config: RoadGenerationConfig,
    path: str,
) -> None:
    _range_mapping(
        config.element_count_range,
        path + ".element_count_range",
        integral=True,
        positive=True,
    )
    probability = _finite_number(
        config.straight_element_probability,
        path + ".straight_element_probability",
    )
    if not 0.0 <= probability <= 1.0:
        raise ValueError(
            path + ".straight_element_probability must be in [0, 1]."
        )
    straight = _closed_mapping(
        config.straight,
        path + ".straight",
        {"length_range_m"},
    )
    _range_mapping(
        straight["length_range_m"],
        path + ".straight.length_range_m",
        positive=True,
    )
    circular_arc = _closed_mapping(
        config.circular_arc,
        path + ".circular_arc",
        {"radius_range_m", "sweep_angle_range_deg"},
    )
    _range_mapping(
        circular_arc["radius_range_m"],
        path + ".circular_arc.radius_range_m",
        positive=True,
    )
    _range_mapping(
        circular_arc["sweep_angle_range_deg"],
        path + ".circular_arc.sweep_angle_range_deg",
        positive=True,
    )
    _range_mapping(
        config.speed_limit_range_kph,
        path + ".speed_limit_range_kph",
        positive=True,
    )
    first_element = _closed_mapping(
        config.first_element,
        path + ".first_element",
        {"require_straight", "straight_length_range_m"},
    )
    _exact_bool(
        first_element["require_straight"],
        path + ".first_element.require_straight",
    )
    _range_mapping(
        first_element["straight_length_range_m"],
        path + ".first_element.straight_length_range_m",
        positive=True,
    )
    initial_cross_section = config.initial_cross_section
    if type(initial_cross_section) is not dict:
        raise TypeError(path + ".initial_cross_section must be an object.")
    if "reference_line_role" not in initial_cross_section:
        raise ValueError(
            path + ".initial_cross_section.reference_line_role is required."
        )
    role = _choice(
        initial_cross_section["reference_line_role"],
        path + ".initial_cross_section.reference_line_role",
        ("lane_boundary", "lane_center"),
    )
    width_field = (
        "left_lane_width_range_m"
        if role == "lane_boundary"
        else "reference_lane_width_range_m"
    )
    expected_cross_section_keys = {"reference_line_role", width_field}
    _closed_mapping(
        config.initial_cross_section,
        path + ".initial_cross_section",
        expected_cross_section_keys,
    )
    _range_mapping(
        initial_cross_section[width_field],
        path + ".initial_cross_section." + width_field,
        positive=True,
    )
    _nonnegative_number(
        config.active_lane_minimum_width_m,
        path + ".active_lane_minimum_width_m",
    )


def validate_train_randomization_config(
    config: TrainRandomizationConfig,
    *,
    path: str = "config.roads.train_randomization",
) -> TrainRandomizationConfig:
    """Validate canonical random-road generation and reset controls."""

    if type(config) is not TrainRandomizationConfig:
        raise TypeError(path + " must be a TrainRandomizationConfig.")
    _validate_road_generation(config, path)
    _exact_bool(config.enabled, path + ".enabled")
    _exact_int(config.seed, path + ".seed", minimum=0)
    mode = _choice(
        config.reset_road_sampling_mode,
        path + ".reset_road_sampling_mode",
        ("generate_fresh", "reuse_initial", "cycle_reusable_pool"),
    )
    pool_size = _exact_int(
        config.n_road_specs_in_reusable_pool,
        path + ".n_road_specs_in_reusable_pool",
        minimum=0,
    )
    if mode == "cycle_reusable_pool" and pool_size == 0:
        raise ValueError(
            path
            + ".n_road_specs_in_reusable_pool must be positive for "
            "cycle_reusable_pool."
        )
    if mode != "cycle_reusable_pool" and pool_size != 0:
        raise ValueError(
            path
            + ".n_road_specs_in_reusable_pool must be zero unless "
            "reset_road_sampling_mode is cycle_reusable_pool."
        )
    return copy.deepcopy(config)


def _validate_road_spec(value: Any, path: str) -> None:
    if type(value) is not dict:
        raise TypeError(path + " must be an object or null.")
    detached = validate_json_value(value, path=path)
    try:
        Road(
            road_spec=copy.deepcopy(detached),
            minimum_curvature_magnitude_per_m=1e-4,
        )
    except (TypeError, ValueError, KeyError, IndexError) as exc:
        raise ValueError(path + ": " + str(exc)) from exc


def _evaluation_road_count(config: TrainingConfig) -> int:
    fixed = config.roads.fixed_evaluation_road_specs
    fixed_count = 1 if fixed is None else len(fixed)
    return (
        fixed_count
        + config.roads.n_random_evaluation_roads_reused_across_evaluations
        + config.roads.n_fresh_random_evaluation_roads_per_evaluation
    )


def validate_environment_config(
    env: EnvConfig,
    *,
    path: str = "config.env",
) -> EnvConfig:
    """Validate one canonical environment record using schema owner rules."""

    if type(env) is not EnvConfig:
        raise TypeError(path + " must be an EnvConfig.")
    _choice(env.observation_format, path + ".observation_format", ("flat", "dict"))
    _choice(
        env.ground_truth_mode,
        path + ".ground_truth_mode",
        ("operational", "full"),
    )
    lane_keep = _exact_bool(env.enable_lane_keep, path + ".enable_lane_keep")
    cruise = _exact_bool(
        env.enable_cruise_control,
        path + ".enable_cruise_control",
    )
    action_interface = _choice(
        env.action_interface,
        path + ".action_interface",
        ("auto", "full", "drive_only", "steer_only", "none"),
    )
    effective_interface = {
        (False, False): "full",
        (True, False): "drive_only",
        (False, True): "steer_only",
        (True, True): "none",
    }[(lane_keep, cruise)]
    if effective_interface == "none":
        raise ValueError(
            path + ".action_interface resolves to none; SB3 requires external control."
        )
    if action_interface != "auto" and action_interface != effective_interface:
        raise ValueError(
            path
            + ".action_interface must agree with enabled internal-policy "
            "ownership (expected "
            + effective_interface
            + ")."
        )
    _choice(
        env.vehicle_dynamics_regime,
        path + ".vehicle_dynamics_regime",
        ("kinematic", "blended_dynamic"),
    )
    _choice(
        env.tire_force_condition,
        path + ".tire_force_condition",
        ("dry", "wet", "snow", "ice"),
    )
    _choice(
        env.integration_method,
        path + ".integration_method",
        ("euler", "heun", "midpoint", "rk4", "rk45"),
    )
    _positive_number(
        env.environment_timestep_seconds,
        path + ".environment_timestep_seconds",
    )
    _exact_int(
        env.integration_substeps_per_environment_step,
        path + ".integration_substeps_per_environment_step",
        minimum=1,
    )
    _choice(
        env.tracking_mode,
        path + ".tracking_mode",
        ("target_lane", "reference_line"),
    )
    lane_index = _exact_int(env.target_lane_index, path + ".target_lane_index")
    if lane_index == 0:
        raise ValueError(path + ".target_lane_index must identify a physical lane.")
    _range_pair(
        env.initial_lateral_error_range_m,
        path + ".initial_lateral_error_range_m",
    )
    _range_pair(
        env.initial_speed_error_range_kph,
        path + ".initial_speed_error_range_kph",
    )
    _positive_number(
        env.target_line_lookahead_distance_m,
        path + ".target_line_lookahead_distance_m",
    )
    _exact_int(
        env.target_line_lookahead_point_count,
        path + ".target_line_lookahead_point_count",
        minimum=0,
    )
    _exact_bool(
        env.include_cone_detection_observations,
        path + ".include_cone_detection_observations",
    )
    _exact_bool(
        env.include_next_speed_change_observations,
        path + ".include_next_speed_change_observations",
    )
    _exact_int(
        env.cone_detection_observation_capacity,
        path + ".cone_detection_observation_capacity",
        minimum=1,
    )
    fov = _positive_number(
        env.cone_detection_horizontal_field_of_view_degrees,
        path + ".cone_detection_horizontal_field_of_view_degrees",
    )
    if fov > 180.0:
        raise ValueError(
            path
            + ".cone_detection_horizontal_field_of_view_degrees must be <= 180."
        )
    _positive_number(
        env.cone_detection_forward_position_upper_bound_m,
        path + ".cone_detection_forward_position_upper_bound_m",
    )
    speed_lower = _nonnegative_number(
        env.termination_planar_speed_lower_bound_kph,
        path + ".termination_planar_speed_lower_bound_kph",
    )
    speed_upper = _positive_number(
        env.termination_planar_speed_upper_bound_kph,
        path + ".termination_planar_speed_upper_bound_kph",
    )
    if speed_upper <= speed_lower:
        raise ValueError(
            path
            + ".termination_planar_speed_upper_bound_kph must exceed "
            "the lower bound."
        )
    _positive_number(
        env.termination_absolute_lateral_error_from_target_line_upper_bound_m,
        path
        + ".termination_absolute_lateral_error_from_target_line_upper_bound_m",
    )
    if env.max_episode_steps is not None:
        _exact_int(env.max_episode_steps, path + ".max_episode_steps", minimum=1)
    return copy.deepcopy(env)


def _validate_vectorization(config: TrainingConfig) -> None:
    vectorization = config.vectorization
    path = "config.vectorization"
    _choice(vectorization.vec_env, path + ".vec_env", ("dummy", "subproc"))
    if vectorization.n_envs != "algorithm_default":
        _exact_int(vectorization.n_envs, path + ".n_envs", minimum=1)
    _choice(
        vectorization.subproc_start_method,
        path + ".subproc_start_method",
        ("spawn", "fork", "forkserver"),
    )


def _validate_algorithm(config: TrainingConfig) -> None:
    algorithm = config.algorithm
    path = "config.algorithm"
    name = _choice(
        algorithm.name,
        path + ".name",
        ("PPO", "A2C", "SAC", "TD3", "DDPG"),
    )
    rollout = algorithm.n_rollout_transitions_per_update
    if rollout != "algorithm_default":
        _exact_int(
            rollout,
            path + ".n_rollout_transitions_per_update",
            minimum=1,
        )
        if name in ("SAC", "TD3", "DDPG"):
            raise ValueError(
                path
                + ".n_rollout_transitions_per_update is not applicable to "
                + name
                + "."
            )
    for field_name in ("hyperparameters", "policy_kwargs"):
        value = getattr(algorithm, field_name)
        if type(value) is not dict:
            raise TypeError(path + "." + field_name + " must be an object.")
        validate_json_value(value, path=path + "." + field_name)


def _validate_roads(config: TrainingConfig) -> None:
    roads = config.roads
    path = "config.roads"
    validate_train_randomization_config(
        roads.train_randomization,
        path=path + ".train_randomization",
    )
    if roads.fixed_train_road_spec is not None:
        _validate_road_spec(
            roads.fixed_train_road_spec,
            path + ".fixed_train_road_spec",
        )
    fixed_evaluation = roads.fixed_evaluation_road_specs
    if fixed_evaluation is not None:
        if type(fixed_evaluation) is not list:
            raise TypeError(path + ".fixed_evaluation_road_specs must be a list or null.")
        for index, road_spec in enumerate(fixed_evaluation):
            _validate_road_spec(
                road_spec,
                path + ".fixed_evaluation_road_specs[" + str(index) + "]",
            )
    if type(roads.random_evaluation_road_generation) is not RoadGenerationConfig:
        raise TypeError(
            path + ".random_evaluation_road_generation must be a RoadGenerationConfig."
        )
    _validate_road_generation(
        roads.random_evaluation_road_generation,
        path + ".random_evaluation_road_generation",
    )
    _exact_int(
        roads.n_random_evaluation_roads_reused_across_evaluations,
        path + ".n_random_evaluation_roads_reused_across_evaluations",
        minimum=0,
    )
    _exact_int(
        roads.n_fresh_random_evaluation_roads_per_evaluation,
        path + ".n_fresh_random_evaluation_roads_per_evaluation",
        minimum=0,
    )
    _exact_int(
        roads.evaluation_road_generation_seed,
        path + ".evaluation_road_generation_seed",
        minimum=0,
    )


def validate_evaluation_and_artifacts(
    evaluation: EvaluationConfig,
    artifacts: ArtifactConfig,
    *,
    requested_total_environment_transitions: int,
    evaluation_road_count: int,
    path: str = "config",
) -> tuple[EvaluationConfig, ArtifactConfig]:
    """Validate canonical evaluation/artifact records with shared context."""

    if type(evaluation) is not EvaluationConfig:
        raise TypeError(path + ".evaluation must be an EvaluationConfig.")
    if type(artifacts) is not ArtifactConfig:
        raise TypeError(path + ".artifacts must be an ArtifactConfig.")
    evaluation_path = path + ".evaluation"
    artifact_path = path + ".artifacts"
    interval = _exact_int(
        evaluation.interval_steps,
        evaluation_path + ".interval_steps",
        minimum=0,
    )
    _exact_int(
        evaluation.max_rollout_steps_per_road,
        evaluation_path + ".max_rollout_steps_per_road",
        minimum=1,
    )
    _exact_bool(
        evaluation.deterministic_actions,
        evaluation_path + ".deterministic_actions",
    )
    _exact_int(
        evaluation.environment_reset_seed,
        evaluation_path + ".environment_reset_seed",
    )
    _exact_int(
        evaluation.stochastic_policy_action_seed,
        evaluation_path + ".stochastic_policy_action_seed",
    )
    for name in (
        "save_model_at_evaluations",
        "save_final_model",
        "save_plots_at_evaluations",
        "save_final_plots",
        "save_final_policy_animation",
    ):
        _exact_bool(getattr(artifacts, name), artifact_path + "." + name)
    road_index = _exact_int(
        artifacts.animation_evaluation_road_index,
        artifact_path + ".animation_evaluation_road_index",
        minimum=0,
    )

    has_scheduled_threshold = (
        interval > 0
        and interval <= requested_total_environment_transitions
    )
    selection = artifacts.animation_evaluation_steps
    scheduled_animation_active = False
    if selection == "all":
        if not has_scheduled_threshold:
            raise ValueError(
                artifact_path
                + ".animation_evaluation_steps='all' selects no scheduled evaluation."
            )
        scheduled_animation_active = True
    elif type(selection) is list:
        previous = None
        for index, step in enumerate(selection):
            _exact_int(
                step,
                artifact_path
                + ".animation_evaluation_steps["
                + str(index)
                + "]",
                minimum=1,
            )
            if previous is not None and step <= previous:
                raise ValueError(
                    artifact_path
                    + ".animation_evaluation_steps must be unique and strictly increasing."
                )
            if (
                interval == 0
                or step > requested_total_environment_transitions
                or step % interval != 0
            ):
                raise ValueError(
                    artifact_path
                    + ".animation_evaluation_steps must contain an actual scheduled threshold."
                )
            previous = step
        scheduled_animation_active = bool(selection)
    else:
        raise TypeError(
            artifact_path + ".animation_evaluation_steps must be a list or 'all'."
        )
    if (
        scheduled_animation_active or artifacts.save_final_policy_animation
    ) and road_index >= evaluation_road_count:
        raise ValueError(
            artifact_path
            + ".animation_evaluation_road_index does not select an evaluation road."
        )
    if interval > 0 and evaluation_road_count == 0:
        raise ValueError(
            evaluation_path
            + ".interval_steps enables evaluation but no evaluation road is configured."
        )
    return copy.deepcopy(evaluation), copy.deepcopy(artifacts)


def validate_logging_config(
    logging: LoggingConfig,
    *,
    path: str = "config.logging",
) -> LoggingConfig:
    """Validate one canonical logging record using schema-owner rules."""

    if type(logging) is not LoggingConfig:
        raise TypeError(path + " must be a LoggingConfig.")
    _exact_int(
        logging.progress_interval_steps,
        path + ".progress_interval_steps",
        minimum=0,
    )
    _exact_bool(
        logging.print_progress_to_console,
        path + ".print_progress_to_console",
    )
    _exact_bool(logging.save_monitor_csv, path + ".save_monitor_csv")
    _exact_bool(
        logging.enable_tensorboard_logging,
        path + ".enable_tensorboard_logging",
    )
    return copy.deepcopy(logging)


def validate_requested_config(config: TrainingConfig) -> TrainingConfig:
    if type(config) is not TrainingConfig:
        raise TypeError("config must be a TrainingConfig.")
    _reject_stale_dataclass_attributes(config, "config")
    detached_tree = validate_json_value(asdict(config), path="config")
    detached = construct_dataclass_strict(TrainingConfig, detached_tree, "config")
    if detached.config_kind != CONFIG_KIND or type(detached.config_kind) is not str:
        raise ValueError("config.config_kind is not supported.")
    if detached.schema_version != SCHEMA_VERSION or type(detached.schema_version) is not int:
        raise ValueError("config.schema_version is not supported.")
    if detached.snapshot_type != "requested" or type(detached.snapshot_type) is not str:
        raise ValueError("config.snapshot_type must be requested.")
    _string(detached.experiment_name, "config.experiment_name")
    _string(detached.run_output_parent_dir, "config.run_output_parent_dir")
    _exact_int(
        detached.requested_total_environment_transitions,
        "config.requested_total_environment_transitions",
        minimum=1,
    )
    _exact_int(detached.seed, "config.seed", minimum=0, maximum=2**32 - 1)
    validate_environment_config(detached.env)
    _validate_vectorization(detached)
    _validate_algorithm(detached)
    normalize_reward_preset(
        detached.reward.preset_name,
        detached.reward.preset_parameters,
    )
    _validate_roads(detached)
    validate_evaluation_and_artifacts(
        detached.evaluation,
        detached.artifacts,
        requested_total_environment_transitions=(
            detached.requested_total_environment_transitions
        ),
        evaluation_road_count=_evaluation_road_count(detached),
    )
    validate_logging_config(detached.logging)
    return detached


def config_to_dict(config: TrainingConfig) -> dict[str, JsonValue]:
    validated = validate_requested_config(config)
    return validate_json_value(asdict(validated), path="config")


def config_from_dict(data):
    if type(data) is not dict:
        raise TypeError("Training configuration must be an object.")
    required_envelope = {"config_kind", "schema_version", "snapshot_type"}
    missing = sorted(required_envelope - set(data))
    if missing:
        raise ValueError(
            "Unversioned training configuration is unsupported; "
            "manual migration to schema_version 2 is required. Missing: "
            + ", ".join(missing)
            + ". Supported config_kind='"
            + CONFIG_KIND
            + "', schema_version="
            + str(SCHEMA_VERSION)
            + ". "
            + _SCHEMA_V2_MIGRATION_GUIDANCE
        )
    if (
        type(data["config_kind"]) is not str
        or data["config_kind"] != CONFIG_KIND
        or type(data["schema_version"]) is not int
        or data["schema_version"] != SCHEMA_VERSION
    ):
        raise ValueError(
            "Unsupported training configuration kind/schema. Encountered "
            "config_kind="
            + repr(data["config_kind"])
            + ", schema_version="
            + repr(data["schema_version"])
            + ". Supported config_kind='"
            + CONFIG_KIND
            + "', schema_version="
            + str(SCHEMA_VERSION)
            + "; manual migration is required. "
            + _SCHEMA_V2_MIGRATION_GUIDANCE
        )
    if type(data["snapshot_type"]) is not str or data["snapshot_type"] != "requested":
        raise ValueError(
            "config_from_dict accepts requested snapshots only; use the strict "
            "snapshot loader for resolved configuration reconstruction; manual "
            "migration is required for unsupported snapshot forms."
        )
    detached = validate_json_value(data, path="config")
    return validate_requested_config(
        construct_dataclass_strict(TrainingConfig, detached, "config")
    )


def save_config_json(config: TrainingConfig, path: str | Path) -> None:
    validated = validate_requested_config(config)
    detached = validate_json_value(asdict(validated), path="config")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            detached,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )


def load_config_json(path: str | Path) -> TrainingConfig:
    data = parse_strict_json_object(Path(path).read_text(encoding="utf-8"))
    return config_from_dict(data)
