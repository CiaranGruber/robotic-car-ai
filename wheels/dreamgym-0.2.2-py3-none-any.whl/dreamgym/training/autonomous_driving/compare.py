"""File-based comparison utilities for local RL runs."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable, List

from dreamgym.visualization.autonomous_driving import plot_run_comparison


def _read_last_progress(run_dir: Path) -> dict:
    progress_path = run_dir / "progress.csv"
    if not progress_path.exists():
        return {}
    with progress_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return rows[-1] if rows else {}


def _read_eval_rows(run_dir: Path) -> List[dict]:
    eval_path = run_dir / "eval" / "eval_metrics.csv"
    if not eval_path.exists():
        return []
    with eval_path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _mean(values: List[float]) -> float:
    if not values:
        return float("nan")
    return sum(values) / len(values)


def summarize_run(run_dir: str | Path) -> dict:
    run_dir = Path(run_dir)
    progress = _read_last_progress(run_dir)
    eval_rows = _read_eval_rows(run_dir)
    rewards = [float(row["reward_sum"]) for row in eval_rows if row.get("reward_sum") not in ("", None)]
    lateral_errors = [
        float(row["mean_abs_lateral_error_m"])
        for row in eval_rows
        if row.get("mean_abs_lateral_error_m") not in ("", None)
    ]
    actual_evaluation_steps = [
        row["actual_training_step"]
        for row in eval_rows
        if row.get("actual_training_step") not in ("", None)
    ]
    return {
        "run_dir": str(run_dir),
        "run_name": run_dir.name,
        "timesteps": progress.get("timesteps", ""),
        "elapsed_s": progress.get("elapsed_s", ""),
        "steps_per_s": progress.get("steps_per_s", ""),
        "eval_episodes": len(eval_rows),
        "evaluation_actual_training_step": (
            actual_evaluation_steps[-1] if actual_evaluation_steps else ""
        ),
        "reward_sum__primary": _mean(rewards),
        "mean_abs_lateral_error_m__primary": _mean(lateral_errors),
    }


def _write_csv(rows: List[dict], path: Path) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _write_summary(rows: List[dict], path: Path) -> None:
    lines = ["# RL Run Comparison", ""]
    for row in rows:
        lines.extend([
            f"## {row['run_name']}",
            "",
            f"- Timesteps: {row['timesteps']}",
            f"- Elapsed seconds: {row['elapsed_s']}",
            f"- Steps/s: {row['steps_per_s']}",
            f"- Evaluation episodes: {row['eval_episodes']}",
            "- Evaluation actual training step: "
            f"{row['evaluation_actual_training_step']}",
            f"- Reward sum primary: {row['reward_sum__primary']}",
            f"- Mean absolute lateral error primary [m]: {row['mean_abs_lateral_error_m__primary']}",
            "",
        ])
    path.write_text("\n".join(lines), encoding="utf-8")


def compare_runs(run_dirs: Iterable[str | Path], output_dir: str | Path) -> List[dict]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = [summarize_run(Path(run_dir)) for run_dir in run_dirs]
    _write_csv(rows, output_dir / "comparison_metrics.csv")
    _write_summary(rows, output_dir / "comparison_summary.md")
    plot_run_comparison(rows, output_dir / "comparison_plots.png")
    return rows
