"""SB3 training helpers for the autonomous-driving environment."""

from importlib import import_module
from typing import TYPE_CHECKING

from dreamgym.training.autonomous_driving.configs import (
    CONFIG_KIND,
    SCHEMA_VERSION,
    AlgorithmConfig,
    ArtifactConfig,
    EnvConfig,
    EvaluationConfig,
    LoggingConfig,
    RewardConfig,
    RoadConfig,
    RoadGenerationConfig,
    TrainingConfig,
    TrainRandomizationConfig,
    VectorizationConfig,
    config_from_dict,
    config_to_dict,
    default_training_config,
    load_config_json,
    save_config_json,
)
from dreamgym.training.autonomous_driving.rewards import RewardContext, RewardFunctionWrapper

if TYPE_CHECKING:
    from dreamgym.training.autonomous_driving.model_discovery import (
        LoadedEvaluationBundle,
        LoadedResolvedEvaluationConfig,
        RequestedEvaluationConfig,
        assert_model_spaces_match,
        discover_training_snapshot,
        load_model_and_config_for_evaluation,
    )
    from dreamgym.training.autonomous_driving.resolution import EvaluationConfigView
    from dreamgym.training.autonomous_driving.run_manager import (
        TrainingResult,
        train,
    )
    from dreamgym.training.autonomous_driving.snapshots import decode_gym_space

__all__ = [
    "CONFIG_KIND",
    "SCHEMA_VERSION",
    "AlgorithmConfig",
    "ArtifactConfig",
    "EnvConfig",
    "EvaluationConfig",
    "EvaluationConfigView",
    "LoadedEvaluationBundle",
    "LoadedResolvedEvaluationConfig",
    "LoggingConfig",
    "RewardConfig",
    "RewardContext",
    "RewardFunctionWrapper",
    "RequestedEvaluationConfig",
    "RoadConfig",
    "RoadGenerationConfig",
    "TrainingConfig",
    "TrainingResult",
    "TrainRandomizationConfig",
    "VectorizationConfig",
    "config_from_dict",
    "config_to_dict",
    "assert_model_spaces_match",
    "decode_gym_space",
    "default_training_config",
    "discover_training_snapshot",
    "load_config_json",
    "load_model_and_config_for_evaluation",
    "save_config_json",
    "train",
]


_LAZY_EXPORT_MODULES = {
    "EvaluationConfigView": "dreamgym.training.autonomous_driving.resolution",
    "LoadedEvaluationBundle": "dreamgym.training.autonomous_driving.model_discovery",
    "LoadedResolvedEvaluationConfig": "dreamgym.training.autonomous_driving.model_discovery",
    "RequestedEvaluationConfig": "dreamgym.training.autonomous_driving.model_discovery",
    "TrainingResult": "dreamgym.training.autonomous_driving.run_manager",
    "assert_model_spaces_match": "dreamgym.training.autonomous_driving.model_discovery",
    "decode_gym_space": "dreamgym.training.autonomous_driving.snapshots",
    "discover_training_snapshot": "dreamgym.training.autonomous_driving.model_discovery",
    "load_model_and_config_for_evaluation": "dreamgym.training.autonomous_driving.model_discovery",
    "train": "dreamgym.training.autonomous_driving.run_manager",
}


def __getattr__(name):
    module_name = _LAZY_EXPORT_MODULES.get(name)
    if module_name is None:
        raise AttributeError(
            f"module {__name__!r} has no attribute {name!r}"
        )
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
