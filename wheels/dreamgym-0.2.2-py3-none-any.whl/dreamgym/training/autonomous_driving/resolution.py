"""Pure resolution of requested training configuration into an immutable build."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, fields
import math
from typing import Protocol, runtime_checkable

import numpy as np

from dreamgym.envs.autonomous_driving_env import (
    normalize_internal_policy_config,
    normalize_integration_config,
    normalize_termination_config,
)
from dreamgym.envs._render_config import normalize_render_config
from dreamgym.envs.bicycle_model_dynamic import normalize_bicycle_model_config
from dreamgym.envs.config_validation import (
    normalize_initial_state_config,
    normalize_observation_config,
)
from dreamgym.envs.road import Road
from dreamgym.envs.road_core.random_generation import (
    normalize_random_road_generation_config,
)

from dreamgym.training.autonomous_driving.algorithm_profiles import (
    ALGORITHM_PROFILES,
    ALGORITHM_PROFILE_VERSION,
    resolve_profile_overrides,
)
from dreamgym.training.autonomous_driving.config_validation import (
    JsonValue,
    canonical_snapshot_digest,
    freeze_json,
    normalize_reward_preset,
    thaw_json,
    validate_json_value,
    validate_requested_config,
)
from dreamgym.training.autonomous_driving.configs import (
    CONFIG_KIND,
    SCHEMA_VERSION,
    TrainingConfig,
    config_to_dict,
)
from dreamgym.training.autonomous_driving.seeds import (
    SEED_DERIVATION_VERSION,
    derive_seed,
)


RESOLVER_VERSION = "dreamgym-training-resolver-v3"
TRAINING_ROAD_SOURCE_PRECEDENCE = (
    "explicit_argument",
    "fixed_train_road_spec",
    "train_randomization",
    "default_training_road",
)
TRAINING_SEED_COUNTER_RULE = (
    "an explicit Gymnasium reset seed restarts at counter zero; "
    "an unseeded reset advances the counter"
)


def default_training_road_spec():
    """Return a detached, valid fallback road for canonical training."""

    return {
        "defaults": {
            "speed_limit_kph": 80.0,
        },
        "active_lane_minimum_width_m": 0.05,
        "elements": [
            {
                "geometry": {
                    "type": "straight",
                    "length_m": 80.0,
                },
                "lanes": {
                    "reference_line_role": "lane_boundary",
                    "left": [{"width_m": {"start": 3.5}}],
                    "right": [],
                },
                "cross_section_width_interpolation": "linear",
            },
            {
                "geometry": {
                    "type": "circular_arc",
                    "curvature_per_m": 1.0 / 250.0,
                    "sweep_angle_deg": 20.0,
                },
            },
            {
                "geometry": {
                    "type": "straight",
                    "length_m": 80.0,
                },
            },
            {
                "geometry": {
                    "type": "circular_arc",
                    "curvature_per_m": -1.0 / 220.0,
                    "sweep_angle_deg": 25.0,
                },
            },
            {
                "geometry": {
                    "type": "straight",
                    "length_m": 80.0,
                },
            },
        ],
    }


def _normalize_training_road_generation_config(requested):
    """Normalize one detached final-vocabulary generation request."""

    return normalize_random_road_generation_config(thaw_json(requested))


def _target_line_config(environment):
    selector = {"mode": "reference_line"}
    if environment["tracking_mode"] == "target_lane":
        selector = {
            "mode": "lane_center",
            "lane_index": environment["target_lane_index"],
            "require_active_lane": True,
        }
    return selector


def validate_road_for_target(road_spec, target_line_config, source):
    """Validate and detach a concrete road against the selected target."""

    try:
        detached = validate_json_value(road_spec, path=source)
        road = Road(
            road_spec=detached,
            minimum_curvature_magnitude_per_m=(1.0 / 10000.0),
        )
    except (TypeError, ValueError, KeyError, IndexError) as exc:
        raise ValueError(source + ": " + str(exc)) from exc
    if target_line_config["mode"] == "lane_center":
        lane_index = target_line_config["lane_index"]
        try:
            road.get_lane_center_offset_at_progress(0.0, lane_index)
        except (TypeError, ValueError, KeyError, IndexError) as exc:
            raise ValueError(
                source
                + ": target_lane_index "
                + str(lane_index)
                + " must identify an active lane at progress zero: "
                + str(exc)
            ) from exc
    return detached


def validate_random_lane_domain(generation, target_line_config, source):
    if target_line_config["mode"] != "lane_center":
        return
    cross_section = generation["initial_cross_section"]
    width_field = (
        "left_lane_width_range_m"
        if cross_section["reference_line_role"] == "lane_boundary"
        else "reference_lane_width_range_m"
    )
    minimum_lane_width = cross_section[width_field]["lower"]
    active_width = generation["active_lane_minimum_width_m"]
    if minimum_lane_width < active_width:
        raise ValueError(
            source
            + ".initial_cross_section."
            + width_field
            + ".lower must be >= "
            + source
            + ".active_lane_minimum_width_m so target_lane_index remains active."
        )


def validate_random_road_source_for_target(
    requested_generation,
    normalized_generation,
    target_line_config,
    representative_seed,
    source,
    *,
    requested_generation_source=None,
):
    """Validate one used random-road source against the selected target."""

    validate_random_lane_domain(
        requested_generation,
        target_line_config,
        source
        if requested_generation_source is None
        else requested_generation_source,
    )
    representative = Road.generate_random_spec(
        generation_config=normalized_generation,
        seed=representative_seed,
    )
    validate_road_for_target(
        representative,
        target_line_config,
        source + ".representative_road",
    )


def _road_generation_request(requested):
    controls = {
        key: requested[key]
        for key in (
            "enabled",
            "seed",
            "reset_road_sampling_mode",
            "n_road_specs_in_reusable_pool",
        )
    }
    generation = {
        key: value
        for key, value in requested.items()
        if key not in controls
    }
    return controls, generation


def _training_bicycle_model_config(regime):
    front_axle_distance = 0.55 * 2.875
    rear_axle_distance = 0.45 * 2.875
    config = {
        "axle_geometry": {
            "front_axle_distance_from_center_of_mass_m": front_axle_distance,
            "rear_axle_distance_from_center_of_mass_m": rear_axle_distance,
        },
        "mass_properties": {
            "mass_kg": 2000.0,
            "yaw_moment_of_inertia_kg_m2": (
                (1.0 / 12.0) * 2000.0 * (4.692**2 + 1.850**2)
            ),
        },
        "longitudinal_force_model": {
            "normalized_motor_command_force_gain_n": (
                (1.0 * 400.0 * 9.0) / 0.2286
            ),
            "quadratic_aerodynamic_drag_coefficient_kg_per_m": (
                0.5 * 0.24 * 2.2204 * 1.202
            ),
        },
        "steering": {
            "physical_front_wheel_angle_offset_from_request_rad": 0.0,
            "requested_front_wheel_angle_magnitude_limit_rad": math.radians(45.0),
            "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                "lower": -math.radians(45.0),
                "upper": math.radians(45.0),
            },
        },
        "body_geometry": {
            "front_extent_from_center_of_mass_m": front_axle_distance * 1.5,
            "rear_extent_from_center_of_mass_m": rear_axle_distance * 1.5,
            "width_m": 2.50,
        },
    }
    if regime == "kinematic":
        speed_range = {"lower": 500.0 / 3.6, "upper": 600.0 / 3.6}
    elif regime == "blended_dynamic":
        speed_range = {"lower": 3.0, "upper": 5.0}
    else:
        raise ValueError("Unknown vehicle dynamics regime: " + str(regime))
    config["kinematic_dynamic_transition"] = {
        "body_longitudinal_speed_range_mps": speed_range,
    }
    return config


def _training_initial_state_config():
    return {
        "bounds": {
            "world_pose": {
                "x_m": {"lower": 0.0, "upper": 0.0},
                "y_m": {"lower": -1.0, "upper": 1.0},
                "heading_rad": {"lower": 0.0, "upper": 0.0},
            },
            "body_motion": {
                "longitudinal_velocity_mps": {
                    "lower": 55.0 / 3.6,
                    "upper": 65.0 / 3.6,
                },
                "lateral_velocity_mps": {"lower": 0.0, "upper": 0.0},
                "yaw_rate_rad_per_s": {"lower": 0.0, "upper": 0.0},
            },
            "front_wheel_steering_angle_rad": {
                "lower": 0.0,
                "upper": 0.0,
            },
        },
        "reference_line_progress_search": None,
    }


def _routed_observation_record(enabled):
    return {"destination": "observation" if enabled else "neither"}


def _training_observation_config(environment):
    enabled = _routed_observation_record(True)
    lookahead_enabled = environment["target_line_lookahead_point_count"] > 0
    next_speed_enabled = environment["include_next_speed_change_observations"]
    cone_enabled = environment["include_cone_detection_observations"]
    config = {
        "body_longitudinal_velocity_mps": enabled,
        "front_wheel_steering_angle_rad": enabled,
        "lateral_error_from_target_line_m": enabled,
        "heading_error_from_target_line_rad": enabled,
        "target_line_curvature_per_m": enabled,
        "speed_limit_mps": enabled,
        "recommended_speed_mps": enabled,
        "target_line_lookahead": {
            "maximum_distance_m": environment[
                "target_line_lookahead_distance_m"
            ],
            "sample_count": max(
                1,
                environment["target_line_lookahead_point_count"],
            ),
            "acquisition": {"mode": "road_geometry"},
            "positions_in_body_frame_m": _routed_observation_record(
                lookahead_enabled
            ),
            "curvatures_per_m": _routed_observation_record(lookahead_enabled),
        },
        "cone_detections": {
            "maximum_detection_count": environment[
                "cone_detection_observation_capacity"
            ],
            "acquisition": {
                "horizontal_field_of_view_deg": environment[
                    "cone_detection_horizontal_field_of_view_degrees"
                ],
                "forward_position_upper_bound_m": environment[
                    "cone_detection_forward_position_upper_bound_m"
                ],
                "position_error_in_body_frame": {
                    "forward": {"noise_standard_deviation_m": 0.0},
                    "left": {"noise_standard_deviation_m": 0.0},
                },
            },
            "positions_in_body_frame_m": _routed_observation_record(
                cone_enabled
            ),
            "color_ids": _routed_observation_record(cone_enabled),
            "count": _routed_observation_record(cone_enabled),
        },
    }
    for family in (
        "next_speed_limit_change",
        "next_recommended_speed_change",
    ):
        config[family] = {
            "value_mps": _routed_observation_record(next_speed_enabled),
            "reference_line_distance_m": _routed_observation_record(
                next_speed_enabled
            ),
            "exists": {"destination": "neither"},
        }
    return config


def _effective_action_interface(environment):
    requested = environment["action_interface"]
    if requested != "auto":
        return requested
    return {
        (False, False): "full",
        (True, False): "drive_only",
        (False, True): "steer_only",
        (True, True): "none",
    }[(
        environment["enable_lane_keep"],
        environment["enable_cruise_control"],
    )]


def _trusted_json_native(value):
    if isinstance(value, np.ndarray):
        return _trusted_json_native(value.tolist())
    if isinstance(value, np.generic):
        return _trusted_json_native(value.item())
    if isinstance(value, Mapping):
        return {
            str(key): _trusted_json_native(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_trusted_json_native(item) for item in value]
    return value


def public_environment_constructor_template(requested_environment):
    """Translate canonical environment values into one complete public recipe."""

    bicycle = normalize_bicycle_model_config(
        _training_bicycle_model_config(
            requested_environment["vehicle_dynamics_regime"]
        )
    )
    integration = normalize_integration_config({
        "method": requested_environment["integration_method"],
        "environment_step_duration_s": requested_environment[
            "environment_timestep_seconds"
        ],
        "substep_count": requested_environment[
            "integration_substeps_per_environment_step"
        ],
    })
    termination = normalize_termination_config({
        "planar_speed_bounds_mps": {
            "lower": requested_environment[
                "termination_planar_speed_lower_bound_kph"
            ] / 3.6,
            "upper": requested_environment[
                "termination_planar_speed_upper_bound_kph"
            ] / 3.6,
        },
        "absolute_lateral_error_from_target_line_upper_bound_m": requested_environment[
            "termination_absolute_lateral_error_from_target_line_upper_bound_m"
        ],
    })
    initial_state = normalize_initial_state_config(
        _training_initial_state_config()
    )
    observation = normalize_observation_config(
        _training_observation_config(requested_environment)
    )
    internal_policy = normalize_internal_policy_config({
        "lane_keeping": {
            "enabled": requested_environment["enable_lane_keep"],
        },
        "cruise_control": {
            "enabled": requested_environment["enable_cruise_control"],
        },
        "action_interface": requested_environment["action_interface"],
    })
    render_config = normalize_render_config(None)
    recipe = _trusted_json_native({
        "render_mode": None,
        "render_config": render_config,
        "visualization_theme": None,
        "bicycle_model_config": bicycle,
        "integration_config": integration,
        "termination_config": termination,
        "initial_state_config": initial_state,
        "observation_config": observation,
        "internal_policy_config": internal_policy,
        "target_line_config": _target_line_config(requested_environment),
        "ground_truth_mode": requested_environment["ground_truth_mode"],
        "observation_format": requested_environment["observation_format"],
    })
    return validate_json_value(
        recipe,
        path="environment.public_constructor_template",
    )


def resolved_environment_record(requested_environment):
    """Return the complete environment provenance derived from training input."""

    return {
        "public_constructor_template": public_environment_constructor_template(
            requested_environment
        ),
        "target_relative_reset": {
            "reference_line_progress_m": 0.0,
            "lateral_error_from_target_line_range_m": {
                "lower": requested_environment[
                    "initial_lateral_error_range_m"
                ][0],
                "upper": requested_environment[
                    "initial_lateral_error_range_m"
                ][1],
            },
            "body_longitudinal_velocity_target": {
                "source": "road_recommended_speed_then_speed_limit",
                "error_range_kph": {
                    "lower": requested_environment[
                        "initial_speed_error_range_kph"
                    ][0],
                    "upper": requested_environment[
                        "initial_speed_error_range_kph"
                    ][1],
                },
            },
            "heading_error_from_target_line_rad": 0.0,
            "fixed_state_values": {
                "body_motion": {
                    "lateral_velocity_mps": 0.0,
                    "yaw_rate_rad_per_s": 0.0,
                },
                "front_wheel_steering_angle_rad": 0.0,
            },
        },
        "effective_action_interface": _effective_action_interface(
            requested_environment
        ),
        "gymnasium_metadata": {"render_fps": 20},
        "training": requested_environment,
        "postconstruction_settings": {
            "tire_force_condition": requested_environment[
                "tire_force_condition"
            ],
        },
    }


def _resolved_roads(requested_roads, requested_environment, root_seed):
    target_line_config = _target_line_config(requested_environment)
    controls, requested_training_generation = _road_generation_request(
        requested_roads["train_randomization"]
    )
    normalized_training_generation = _normalize_training_road_generation_config(
        requested_training_generation
    )
    requested_evaluation_generation = requested_roads[
        "random_evaluation_road_generation"
    ]
    normalized_evaluation_generation = _normalize_training_road_generation_config(
        requested_evaluation_generation
    )

    fixed_train = requested_roads["fixed_train_road_spec"]
    if fixed_train is not None:
        fixed_train = validate_road_for_target(
            fixed_train,
            target_line_config,
            "fixed_train_road_spec",
        )
        winning_source = "fixed_train_road_spec"
    elif controls["enabled"]:
        validate_random_road_source_for_target(
            requested_training_generation,
            normalized_training_generation,
            target_line_config,
            derive_seed(
                "training_road",
                root_seed,
                controls["seed"],
                0,
            ),
            "train_randomization",
        )
        winning_source = "train_randomization"
    else:
        validate_road_for_target(
            default_training_road_spec(),
            target_line_config,
            "default_training_road",
        )
        winning_source = "default_training_road"

    fixed_evaluation = requested_roads["fixed_evaluation_road_specs"]
    if fixed_evaluation is None:
        validate_road_for_target(
            default_training_road_spec(),
            target_line_config,
            "fallback_default_training_road",
        )
    else:
        for index, road_spec in enumerate(fixed_evaluation):
            validate_road_for_target(
                road_spec,
                target_line_config,
                "fixed_evaluation_road_specs[" + str(index) + "]",
            )

    random_evaluation_count = (
        requested_roads[
            "n_random_evaluation_roads_reused_across_evaluations"
        ]
        + requested_roads["n_fresh_random_evaluation_roads_per_evaluation"]
    )
    if random_evaluation_count:
        validate_random_road_source_for_target(
            requested_evaluation_generation,
            normalized_evaluation_generation,
            target_line_config,
            derive_seed(
                "evaluation_reused_road",
                requested_roads["evaluation_road_generation_seed"],
                0,
            ),
            "random_evaluation_road_generation",
        )

    return {
        "training_source_precedence": list(TRAINING_ROAD_SOURCE_PRECEDENCE),
        "winning_training_source": winning_source,
        "fixed_train_road_spec": fixed_train,
        "default_training_road_spec": default_training_road_spec(),
        "train_randomization": {
            "controls": controls,
            "requested_generation_config": requested_training_generation,
            "normalized_generation_config": normalized_training_generation,
        },
        "fixed_evaluation_road_specs": fixed_evaluation,
        "random_evaluation_road_generation": {
            "requested_generation_config": requested_evaluation_generation,
            "normalized_generation_config": normalized_evaluation_generation,
        },
        "n_random_evaluation_roads_reused_across_evaluations": requested_roads[
            "n_random_evaluation_roads_reused_across_evaluations"
        ],
        "n_fresh_random_evaluation_roads_per_evaluation": requested_roads[
            "n_fresh_random_evaluation_roads_per_evaluation"
        ],
        "evaluation_road_generation_seed": requested_roads[
            "evaluation_road_generation_seed"
        ],
    }


def evaluation_seed_derivation_rules():
    """Return the canonical evaluation seed namespaces and components."""

    return {
        "reused_road": {
            "namespace": "evaluation_reused_road",
            "components": [
                "evaluation_road_generation_seed",
                "road_family_index",
            ],
        },
        "fresh_road": {
            "namespace": "evaluation_fresh_road",
            "components": [
                "evaluation_road_generation_seed",
                "evaluation_execution_context_identity",
                "road_family_index",
            ],
            "evaluation_execution_context_identity": {
                "standalone": 0,
                "during_training": "scheduled_evaluation_step",
            },
        },
        "environment_reset": {
            "namespace": "evaluation_environment_reset",
            "components": [
                "evaluation_environment_reset_seed",
                "ordered_road_index",
            ],
        },
        "stochastic_policy_action": {
            "namespace": "evaluation_stochastic_policy_action",
            "components": [
                "evaluation_stochastic_policy_action_seed",
                "ordered_road_index",
            ],
            "applicability": "deterministic_actions_is_false",
        },
    }


def _resolved_seeds(requested, root_seed):
    road_seed = requested["roads"]["train_randomization"]["seed"]
    return {
        "inputs": {
            "training_root_seed": root_seed,
            "training_road_randomizer_seed": road_seed,
            "evaluation_road_generation_seed": requested["roads"][
                "evaluation_road_generation_seed"
            ],
            "evaluation_environment_reset_seed": requested["evaluation"][
                "environment_reset_seed"
            ],
            "evaluation_stochastic_policy_action_seed": requested["evaluation"][
                "stochastic_policy_action_seed"
            ],
        },
        "training_road": {
            "namespace": "training_road",
            "components": {
                "sb3_reset_seed": root_seed,
                "training_road_randomizer_seed": road_seed,
                "reset_counter": 0,
            },
            "derived_seed": derive_seed("training_road", root_seed, road_seed, 0),
        },
        "training_initial_state": {
            "namespace": "training_initial_state",
            "components": {
                "sb3_reset_seed": root_seed,
                "reset_counter": 0,
            },
            "derived_seed": derive_seed("training_initial_state", root_seed, 0),
        },
        "evaluation": evaluation_seed_derivation_rules(),
        "counter_rule": TRAINING_SEED_COUNTER_RULE,
    }


@dataclass(frozen=True)
class ResolvedAlgorithmConfig:
    name: str
    profile_version: str
    constructor_kwargs: Mapping[str, JsonValue]
    policy_kwargs: Mapping[str, JsonValue]
    explicit_hyperparameter_overrides: Mapping[str, JsonValue]
    explicit_policy_kwargs: Mapping[str, JsonValue]
    policy_alias: str
    buffer_kind: str
    requested_n_rollout_transitions_per_update: int | str
    n_rollout_transitions_per_update_applicability: str
    native_n_steps_per_environment: int | None
    n_rollout_transitions_per_update_effective: int | None
    n_rollout_transitions_rounding_amount: int | None
    ppo_minibatch_remainder: int | None
    transitions_per_collection: int | None
    gradient_steps_per_collection: int | None
    update_to_data_ratio: float | None

    def to_dict(self):
        return {
            item.name: thaw_json(getattr(self, item.name))
            for item in fields(self)
        }


def effective_algorithm_constructor_kwargs(algorithm):
    """Return complete SB3 semantic kwargs without changing the pinned profile."""

    if not isinstance(algorithm, ResolvedAlgorithmConfig):
        raise TypeError("algorithm must be a ResolvedAlgorithmConfig.")
    constructor_kwargs = thaw_json(algorithm.constructor_kwargs)
    if algorithm.native_n_steps_per_environment is not None:
        constructor_kwargs["n_steps"] = (
            algorithm.native_n_steps_per_environment
        )
    return constructor_kwargs


@dataclass(frozen=True)
class TrainingBuildConfig:
    config_kind: str
    schema_version: int
    resolver_version: str
    seed_derivation_version: str
    experiment_name: str
    run_output_parent_dir: str
    requested_total_environment_transitions: int
    root_seed: int
    requested_dict: Mapping[str, JsonValue]
    requested_digest: str
    effective_n_envs: int
    n_envs_source: str
    algorithm: ResolvedAlgorithmConfig
    environment: Mapping[str, JsonValue]
    roads: Mapping[str, JsonValue]
    seeds: Mapping[str, JsonValue]
    reward: Mapping[str, JsonValue]
    evaluation: Mapping[str, JsonValue]
    artifacts: Mapping[str, JsonValue]
    logging: Mapping[str, JsonValue]
    warnings: tuple[str, ...]

    def environment_dict(self):
        return thaw_json(self.environment)

    def roads_dict(self):
        return thaw_json(self.roads)

    def reward_dict(self):
        return thaw_json(self.reward)

    def seeds_dict(self):
        return thaw_json(self.seeds)

    def evaluation_dict(self):
        return thaw_json(self.evaluation)

    def artifacts_dict(self):
        return thaw_json(self.artifacts)

    def logging_dict(self):
        return thaw_json(self.logging)


@dataclass(frozen=True)
class ResolvedTrainingConfig:
    build: TrainingBuildConfig
    snapshot: Mapping[str, JsonValue]

    def __post_init__(self):
        detached = validate_json_value(self.snapshot, path="resolved_snapshot")
        object.__setattr__(self, "snapshot", freeze_json(detached))

    @property
    def experiment_name(self):
        return self.build.experiment_name

    def to_dict(self):
        return thaw_json(self.snapshot)


@runtime_checkable
class EvaluationConfigView(Protocol):
    """Read-only configuration surface shared by live and loaded evaluation."""

    @property
    def experiment_name(self) -> str: ...

    def to_dict(self) -> dict[str, JsonValue]: ...


@dataclass(frozen=True)
class EvaluationRoadCase:
    """One fully owned evaluation road and its independent seed identities."""

    road_name: str
    road_family: str
    road_family_index: int
    road_source: str
    road_spec: Mapping[str, JsonValue]
    road_generation_seed: int | None
    environment_reset_seed: int
    stochastic_policy_action_seed: int | None

    def __post_init__(self):
        for field_name in ("road_name", "road_family", "road_source"):
            value = getattr(self, field_name)
            if type(value) is not str or not value:
                raise TypeError(field_name + " must be a non-empty string.")
        if self.road_family not in ("fixed", "reused_random", "fresh_random"):
            raise ValueError(
                "road_family must be fixed, reused_random, or fresh_random."
            )
        if type(self.road_family_index) is not int or self.road_family_index < 0:
            raise TypeError("road_family_index must be a non-negative integer.")
        for field_name in (
            "road_generation_seed",
            "stochastic_policy_action_seed",
        ):
            value = getattr(self, field_name)
            if value is not None and (type(value) is not int or value < 0):
                raise TypeError(
                    field_name + " must be null or a non-negative integer."
                )
        if (
            type(self.environment_reset_seed) is not int
            or self.environment_reset_seed < 0
        ):
            raise TypeError(
                "environment_reset_seed must be a non-negative integer."
            )
        detached = validate_json_value(self.road_spec, path="road_spec")
        if type(detached) is not dict:
            raise TypeError("road_spec must be an object.")
        object.__setattr__(self, "road_spec", freeze_json(detached))

    def to_dict(self):
        return {
            "road_name": self.road_name,
            "road_family": self.road_family,
            "road_family_index": self.road_family_index,
            "road_source": self.road_source,
            "road_spec": thaw_json(self.road_spec),
            "road_generation_seed": self.road_generation_seed,
            "environment_reset_seed": self.environment_reset_seed,
            "stochastic_policy_action_seed": (
                self.stochastic_policy_action_seed
            ),
        }


def _evaluation_family_identity(
    *,
    evaluation_execution_context,
    scheduled_evaluation_step,
):
    if evaluation_execution_context == "standalone":
        if scheduled_evaluation_step is not None:
            raise ValueError(
                "standalone evaluation_execution_context requires "
                "scheduled_evaluation_step=None."
            )
        return 0
    if evaluation_execution_context == "during_training":
        if (
            type(scheduled_evaluation_step) is not int
            or scheduled_evaluation_step < 0
        ):
            raise ValueError(
                "during_training evaluation_execution_context requires a "
                "non-negative scheduled_evaluation_step."
            )
        return scheduled_evaluation_step
    raise ValueError(
        "evaluation_execution_context must be during_training or standalone."
    )


def _require_effective_evaluation_blocks(roads, evaluation):
    if type(roads) is not dict:
        raise TypeError("roads must be an object.")
    if type(evaluation) is not dict:
        raise TypeError("evaluation must be an object.")
    required_road_fields = (
        "default_training_road_spec",
        "fixed_evaluation_road_specs",
        "random_evaluation_road_generation",
        "n_random_evaluation_roads_reused_across_evaluations",
        "n_fresh_random_evaluation_roads_per_evaluation",
        "evaluation_road_generation_seed",
    )
    for field_name in required_road_fields:
        if field_name not in roads:
            raise ValueError("roads." + field_name + " is required.")
    required_evaluation_fields = (
        "deterministic_actions",
        "environment_reset_seed",
        "stochastic_policy_action_seed",
    )
    for field_name in required_evaluation_fields:
        if field_name not in evaluation:
            raise ValueError("evaluation." + field_name + " is required.")


def _derive_evaluation_road_cases(
    roads,
    evaluation,
    *,
    seed_derivation_version,
    evaluation_execution_context,
    scheduled_evaluation_step,
):
    if seed_derivation_version != SEED_DERIVATION_VERSION:
        raise ValueError(
            "seed_derivation_version is unsupported; supported value is "
            + repr(SEED_DERIVATION_VERSION)
            + "."
        )
    _require_effective_evaluation_blocks(roads, evaluation)
    fresh_family_identity = _evaluation_family_identity(
        evaluation_execution_context=evaluation_execution_context,
        scheduled_evaluation_step=scheduled_evaluation_step,
    )
    fixed_specs = roads["fixed_evaluation_road_specs"]
    if fixed_specs is None:
        fixed_specs = [roads["default_training_road_spec"]]
        fixed_source = "fallback_default_training_road"
    else:
        if type(fixed_specs) is not list:
            raise TypeError(
                "roads.fixed_evaluation_road_specs must be a list or null."
            )
        fixed_source = "explicit_fixed_evaluation_road"

    generated = roads["random_evaluation_road_generation"]
    if type(generated) is not dict:
        raise TypeError(
            "roads.random_evaluation_road_generation must be an object."
        )
    normalized_generation = generated.get("normalized_generation_config")
    if type(normalized_generation) is not dict:
        raise ValueError(
            "roads.random_evaluation_road_generation."
            "normalized_generation_config is required."
        )

    raw_cases = []
    for family_index, road_spec in enumerate(fixed_specs):
        raw_cases.append((
            "fixed",
            family_index,
            fixed_source,
            road_spec,
            None,
        ))

    generation_seed_input = roads["evaluation_road_generation_seed"]
    if type(generation_seed_input) is not int:
        raise TypeError(
            "roads.evaluation_road_generation_seed must be an integer."
        )
    reused_count = roads[
        "n_random_evaluation_roads_reused_across_evaluations"
    ]
    fresh_count = roads["n_fresh_random_evaluation_roads_per_evaluation"]
    for field_name, value in (
        ("n_random_evaluation_roads_reused_across_evaluations", reused_count),
        ("n_fresh_random_evaluation_roads_per_evaluation", fresh_count),
    ):
        if type(value) is not int or value < 0:
            raise TypeError("roads." + field_name + " must be non-negative.")

    for family_index in range(reused_count):
        generation_seed = derive_seed(
            "evaluation_reused_road",
            generation_seed_input,
            family_index,
        )
        raw_cases.append((
            "reused_random",
            family_index,
            "reused_random_evaluation_road",
            Road.generate_random_spec(
                generation_config=normalized_generation,
                seed=generation_seed,
            ),
            generation_seed,
        ))
    for family_index in range(fresh_count):
        generation_seed = derive_seed(
            "evaluation_fresh_road",
            generation_seed_input,
            fresh_family_identity,
            family_index,
        )
        raw_cases.append((
            "fresh_random",
            family_index,
            "fresh_random_evaluation_road",
            Road.generate_random_spec(
                generation_config=normalized_generation,
                seed=generation_seed,
            ),
            generation_seed,
        ))

    reset_seed_input = evaluation["environment_reset_seed"]
    action_seed_input = evaluation["stochastic_policy_action_seed"]
    for field_name, value in (
        ("environment_reset_seed", reset_seed_input),
        ("stochastic_policy_action_seed", action_seed_input),
    ):
        if type(value) is not int:
            raise TypeError(
                "evaluation." + field_name + " must be an integer."
            )
    deterministic_actions = evaluation["deterministic_actions"]
    if type(deterministic_actions) is not bool:
        raise TypeError("evaluation.deterministic_actions must be a boolean.")

    cases = []
    for ordered_index, (
        family,
        family_index,
        source,
        road_spec,
        generation_seed,
    ) in enumerate(raw_cases):
        cases.append(EvaluationRoadCase(
            road_name=family + "_" + str(family_index),
            road_family=family,
            road_family_index=family_index,
            road_source=source,
            road_spec=validate_json_value(
                road_spec,
                path="evaluation_roads[" + str(ordered_index) + "].road_spec",
            ),
            road_generation_seed=generation_seed,
            environment_reset_seed=derive_seed(
                "evaluation_environment_reset",
                reset_seed_input,
                ordered_index,
            ),
            stochastic_policy_action_seed=(
                None
                if deterministic_actions
                else derive_seed(
                    "evaluation_stochastic_policy_action",
                    action_seed_input,
                    ordered_index,
                )
            ),
        ))
    return cases


def evaluation_road_specs(
    build: TrainingBuildConfig,
    *,
    evaluation_execution_context: str,
    scheduled_evaluation_step: int | None,
):
    """Derive ordered evaluation roads from one immutable live build."""

    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    return _derive_evaluation_road_cases(
        build.roads_dict(),
        build.evaluation_dict(),
        seed_derivation_version=build.seed_derivation_version,
        evaluation_execution_context=evaluation_execution_context,
        scheduled_evaluation_step=scheduled_evaluation_step,
    )


def evaluation_road_specs_from_snapshot(
    snapshot: Mapping[str, JsonValue],
    *,
    evaluation_execution_context: str,
    scheduled_evaluation_step: int | None,
):
    """Derive ordered evaluation roads from recorded effective JSON only."""

    detached = validate_json_value(snapshot, path="snapshot")
    if type(detached) is not dict:
        raise TypeError("snapshot must be an object.")
    for field_name in ("roads", "evaluation", "seed_derivation_version"):
        if field_name not in detached:
            raise ValueError("snapshot." + field_name + " is required.")
    evaluation = detached["evaluation"]
    if type(evaluation) is not dict:
        raise TypeError("snapshot.evaluation must be an object.")
    if "configuration" in evaluation:
        evaluation = evaluation["configuration"]
    return _derive_evaluation_road_cases(
        detached["roads"],
        evaluation,
        seed_derivation_version=detached["seed_derivation_version"],
        evaluation_execution_context=evaluation_execution_context,
        scheduled_evaluation_step=scheduled_evaluation_step,
    )


def resolve_final_animation_road_case(build: TrainingBuildConfig):
    """Select the retained standalone road identity for the final animation."""

    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    if not build.artifacts["save_final_policy_animation"]:
        return None
    cases = evaluation_road_specs(
        build,
        evaluation_execution_context="standalone",
        scheduled_evaluation_step=None,
    )
    index = int(build.artifacts["animation_evaluation_road_index"])
    if index >= len(cases):
        raise ValueError(
            "artifacts.animation_evaluation_road_index exceeds the resolved "
            "standalone evaluation-road list."
        )
    return cases[index]


def policy_alias_for_observation_format(observation_format: str) -> str:
    """Return the schema-v1 SB3 policy alias for a canonical observation format."""

    if observation_format == "flat":
        return "MlpPolicy"
    if observation_format == "dict":
        return "MultiInputPolicy"
    raise ValueError("observation_format must be flat or dict.")


def buffer_kind_for_algorithm(algorithm_name: str) -> str:
    """Return the schema-v1 buffer family for a supported algorithm."""

    if algorithm_name in ("PPO", "A2C"):
        return "rollout"
    if algorithm_name in ("SAC", "TD3", "DDPG"):
        return "replay"
    raise ValueError("Unsupported algorithm: " + str(algorithm_name))


def resolve_effective_n_envs(requested_n_envs, algorithm_name):
    if requested_n_envs == "algorithm_default":
        return (
            int(ALGORITHM_PROFILES[algorithm_name]["algorithm_default_n_envs"]),
            "algorithm_profile",
        )
    if type(requested_n_envs) is not int:
        raise TypeError(
            "vectorization.n_envs must be algorithm_default or a positive integer."
        )
    if requested_n_envs <= 0:
        raise ValueError("vectorization.n_envs must be positive.")
    return requested_n_envs, "explicit_override"


def resolve_on_policy_rollout(
    requested,
    n_envs,
    batch_size,
    algorithm_name,
    normalize_advantage,
):
    if algorithm_name == "PPO" and normalize_advantage and batch_size <= 1:
        raise ValueError(
            "PPO with normalize_advantage=True requires batch_size greater than one."
        )
    native_n_steps = (requested + n_envs - 1) // n_envs
    effective = native_n_steps * n_envs
    if algorithm_name in ("PPO", "A2C") and normalize_advantage and effective <= 1:
        raise ValueError(
            algorithm_name
            + " with normalize_advantage=True requires more than one sample per rollout."
        )
    remainder = effective % batch_size if algorithm_name == "PPO" else None
    warnings = []
    if remainder:
        warnings.append(
            "PPO effective rollout is not divisible by batch_size; "
            "SB3 will use a smaller final minibatch of " + str(remainder) + "."
        )
    return native_n_steps, effective, effective - requested, remainder, warnings


def _resolve_reward(requested_reward):
    effective = normalize_reward_preset(
        requested_reward["preset_name"],
        requested_reward["preset_parameters"],
    )
    return {
        "requested": requested_reward,
        "effective": effective,
    }


def resolve_training_request(config: TrainingConfig) -> TrainingBuildConfig:
    validated = validate_requested_config(config)
    requested_dict = config_to_dict(validated)
    algorithm_name = validated.algorithm.name
    profile = ALGORITHM_PROFILES[algorithm_name]
    effective_n_envs, n_envs_source = resolve_effective_n_envs(
        validated.vectorization.n_envs,
        algorithm_name,
    )
    if validated.seed + effective_n_envs - 1 > 2**32 - 1:
        raise ValueError(
            "config.seed plus vectorization.n_envs exceeds the NumPy seed range."
        )

    (
        constructor_kwargs,
        policy_kwargs,
        explicit_hyperparameters,
        explicit_policy_kwargs,
    ) = resolve_profile_overrides(
        algorithm_name,
        validated.algorithm.hyperparameters,
        validated.algorithm.policy_kwargs,
    )

    requested_rollout = validated.algorithm.n_rollout_transitions_per_update
    warnings = []
    if algorithm_name in ("PPO", "A2C"):
        if requested_rollout == "algorithm_default":
            resolved_rollout = int(profile["algorithm_default_rollout_transitions"])
        else:
            resolved_rollout = int(requested_rollout)
        (
            native_n_steps,
            effective_rollout,
            rounding_amount,
            minibatch_remainder,
            rollout_warnings,
        ) = resolve_on_policy_rollout(
            resolved_rollout,
            effective_n_envs,
            constructor_kwargs.get("batch_size"),
            algorithm_name,
            constructor_kwargs["normalize_advantage"],
        )
        warnings.extend(rollout_warnings)
        applicability = "applicable"
        transitions_per_collection = None
        gradient_steps_per_collection = None
        update_to_data_ratio = None
        buffer_kind = buffer_kind_for_algorithm(algorithm_name)
    else:
        if requested_rollout != "algorithm_default":
            raise ValueError(
                "algorithm.n_rollout_transitions_per_update is not applicable to "
                + algorithm_name
                + "."
            )
        n_steps = constructor_kwargs["n_steps"]
        if n_steps > 1 and constructor_kwargs["optimize_memory_usage"]:
            raise ValueError(
                "algorithm.hyperparameters.n_steps greater than one is incompatible "
                "with optimize_memory_usage=True."
            )
        if validated.env.observation_format == "dict" and n_steps > 1:
            raise ValueError(
                "dict observations are incompatible with algorithm.hyperparameters.n_steps "
                "greater than one."
            )
        transitions_per_collection = (
            constructor_kwargs["train_freq"] * effective_n_envs
        )
        requested_gradient_steps = constructor_kwargs["gradient_steps"]
        gradient_steps_per_collection = (
            transitions_per_collection
            if requested_gradient_steps == -1
            else requested_gradient_steps
        )
        update_to_data_ratio = (
            gradient_steps_per_collection / transitions_per_collection
        )
        applicability = "not_applicable"
        native_n_steps = None
        effective_rollout = None
        rounding_amount = None
        minibatch_remainder = None
        buffer_kind = buffer_kind_for_algorithm(algorithm_name)

    algorithm = ResolvedAlgorithmConfig(
        name=algorithm_name,
        profile_version=ALGORITHM_PROFILE_VERSION,
        constructor_kwargs=freeze_json(constructor_kwargs),
        policy_kwargs=freeze_json(policy_kwargs),
        explicit_hyperparameter_overrides=freeze_json(explicit_hyperparameters),
        explicit_policy_kwargs=freeze_json(explicit_policy_kwargs),
        policy_alias=policy_alias_for_observation_format(
            validated.env.observation_format
        ),
        buffer_kind=buffer_kind,
        requested_n_rollout_transitions_per_update=requested_rollout,
        n_rollout_transitions_per_update_applicability=applicability,
        native_n_steps_per_environment=native_n_steps,
        n_rollout_transitions_per_update_effective=effective_rollout,
        n_rollout_transitions_rounding_amount=rounding_amount,
        ppo_minibatch_remainder=minibatch_remainder,
        transitions_per_collection=transitions_per_collection,
        gradient_steps_per_collection=gradient_steps_per_collection,
        update_to_data_ratio=update_to_data_ratio,
    )
    resolved_environment = resolved_environment_record(requested_dict["env"])
    resolved_roads = _resolved_roads(
        requested_dict["roads"],
        requested_dict["env"],
        validated.seed,
    )
    resolved_seeds = _resolved_seeds(requested_dict, validated.seed)
    return TrainingBuildConfig(
        config_kind=CONFIG_KIND,
        schema_version=SCHEMA_VERSION,
        resolver_version=RESOLVER_VERSION,
        seed_derivation_version=SEED_DERIVATION_VERSION,
        experiment_name=validated.experiment_name,
        run_output_parent_dir=validated.run_output_parent_dir,
        requested_total_environment_transitions=(
            validated.requested_total_environment_transitions
        ),
        root_seed=validated.seed,
        requested_dict=freeze_json(requested_dict),
        requested_digest=canonical_snapshot_digest(requested_dict),
        effective_n_envs=effective_n_envs,
        n_envs_source=n_envs_source,
        algorithm=algorithm,
        environment=freeze_json(resolved_environment),
        roads=freeze_json(resolved_roads),
        seeds=freeze_json(resolved_seeds),
        reward=freeze_json(_resolve_reward(requested_dict["reward"])),
        evaluation=freeze_json(requested_dict["evaluation"]),
        artifacts=freeze_json(requested_dict["artifacts"]),
        logging=freeze_json(requested_dict["logging"]),
        warnings=tuple(warnings),
    )


def resolve_training_road_source(build, *, road_spec=None):
    """Resolve and detach the winning training-road input by exact precedence."""

    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    target_line_config = thaw_json(
        build.environment["public_constructor_template"]["target_line_config"]
    )
    roads = build.roads_dict()
    if road_spec is not None:
        return (
            "explicit_argument",
            validate_road_for_target(
                road_spec,
                target_line_config,
                "explicit_argument",
            ),
        )
    if roads["fixed_train_road_spec"] is not None:
        return "fixed_train_road_spec", roads["fixed_train_road_spec"]
    if roads["train_randomization"]["controls"]["enabled"]:
        return (
            "train_randomization",
            roads["train_randomization"]["normalized_generation_config"],
        )
    return "default_training_road", roads["default_training_road_spec"]
