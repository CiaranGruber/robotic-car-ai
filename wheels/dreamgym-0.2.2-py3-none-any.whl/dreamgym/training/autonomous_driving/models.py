"""SB3 model factory helpers."""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np

from dreamgym.training.autonomous_driving.config_validation import (
    thaw_json,
)
from dreamgym.training.autonomous_driving.resolution import TrainingBuildConfig


SUPPORTED_ALGORITHMS = ("PPO", "SAC", "TD3", "DDPG", "A2C")


def import_sb3():
    try:
        import torch  # noqa: F401
        import stable_baselines3 as sb3
    except ModuleNotFoundError as exc:
        if exc.name not in {"torch", "stable_baselines3"}:
            raise
        raise ModuleNotFoundError(
            "Stable-Baselines3 is required for RL workflows. Install the "
            "optional extra with: python -m pip install -e .[rl]"
        ) from exc
    return sb3


def policy_name_for_observation_space(observation_space: gym.spaces.Space) -> str:
    if isinstance(observation_space, gym.spaces.Dict):
        return "MultiInputPolicy"
    return "MlpPolicy"


def _algorithm_class(sb3: Any, name: str):
    normalized = str(name).upper()
    if normalized not in SUPPORTED_ALGORITHMS:
        raise ValueError(
            "Unsupported SB3 algorithm " + str(name) +
            ". Supported algorithms: " + ", ".join(SUPPORTED_ALGORITHMS)
        )
    return getattr(sb3, normalized)


def _activation_classes():
    import torch

    return {
        "relu": torch.nn.ReLU,
        "tanh": torch.nn.Tanh,
        "elu": torch.nn.ELU,
        "leaky_relu": torch.nn.LeakyReLU,
    }


def materialize_policy_kwargs(value, *, observation_space, algorithm_name):
    import_sb3()
    from stable_baselines3.common.torch_layers import CombinedExtractor, FlattenExtractor

    kwargs = thaw_json(value)
    activation_name = kwargs.get("activation_fn")
    if activation_name is not None:
        kwargs["activation_fn"] = _activation_classes()[activation_name]
    kwargs["features_extractor_class"] = (
        CombinedExtractor
        if isinstance(observation_space, gym.spaces.Dict)
        else FlattenExtractor
    )
    if algorithm_name in ("SAC", "TD3", "DDPG"):
        kwargs["n_critics"] = 1 if algorithm_name == "DDPG" else 2
    return kwargs


def materialize_action_noise(spec, action_space):
    from stable_baselines3.common.noise import (
        NormalActionNoise,
        OrnsteinUhlenbeckActionNoise,
    )

    if spec is None:
        return None
    if not isinstance(action_space, gym.spaces.Box):
        raise TypeError("Action noise requires a Box action space.")
    dimension = int(np.prod(action_space.shape))
    mean = np.zeros(dimension, dtype=np.float32)
    sigma = np.full(dimension, float(spec["sigma"]), dtype=np.float32)
    if spec["type"] == "normal":
        return NormalActionNoise(mean=mean, sigma=sigma)
    return OrnsteinUhlenbeckActionNoise(mean=mean, sigma=sigma)


def materialize_buffer_arguments(build, observation_space):
    """Return the explicit SB3 buffer class and factory-owned kwargs."""

    from stable_baselines3.common.buffers import (
        DictReplayBuffer,
        DictRolloutBuffer,
        NStepReplayBuffer,
        ReplayBuffer,
        RolloutBuffer,
    )

    is_dict = isinstance(observation_space, gym.spaces.Dict)
    if build.algorithm.name in ("PPO", "A2C"):
        return {
            "rollout_buffer_class": (
                DictRolloutBuffer if is_dict else RolloutBuffer
            ),
            "rollout_buffer_kwargs": {},
        }

    n_steps = int(build.algorithm.constructor_kwargs["n_steps"])
    if is_dict and n_steps > 1:
        raise ValueError("Dict observations do not support n-step replay.")
    if n_steps > 1:
        return {
            "replay_buffer_class": NStepReplayBuffer,
            "replay_buffer_kwargs": {
                "n_steps": n_steps,
                "gamma": float(build.algorithm.constructor_kwargs["gamma"]),
            },
        }
    return {
        "replay_buffer_class": DictReplayBuffer if is_dict else ReplayBuffer,
        "replay_buffer_kwargs": {},
    }


def make_model(
    build: TrainingBuildConfig,
    env: Any,
    *,
    tensorboard_log: str | None = None,
):
    sb3 = import_sb3()
    algorithm_class = _algorithm_class(sb3, build.algorithm.name)
    constructor_kwargs = thaw_json(build.algorithm.constructor_kwargs)
    constructor_kwargs["policy_kwargs"] = materialize_policy_kwargs(
        build.algorithm.policy_kwargs,
        observation_space=env.observation_space,
        algorithm_name=build.algorithm.name,
    )
    constructor_kwargs["seed"] = build.root_seed
    constructor_kwargs["verbose"] = 0
    if build.algorithm.native_n_steps_per_environment is not None:
        constructor_kwargs["n_steps"] = (
            build.algorithm.native_n_steps_per_environment
        )
    constructor_kwargs.update(
        materialize_buffer_arguments(build, env.observation_space)
    )
    if tensorboard_log is not None:
        constructor_kwargs["tensorboard_log"] = tensorboard_log
    if "action_noise" in build.algorithm.constructor_kwargs:
        constructor_kwargs["action_noise"] = materialize_action_noise(
            build.algorithm.constructor_kwargs["action_noise"],
            env.action_space,
        )
    return algorithm_class(
        build.algorithm.policy_alias,
        env,
        **constructor_kwargs,
    )
