"""Readable reward presets for RL training."""

from __future__ import annotations

import copy
from collections.abc import Mapping
from dataclasses import dataclass
import math
from typing import Any, Callable, Dict, Optional

import gymnasium as gym

from dreamgym.training.autonomous_driving.configs import RewardConfig
from dreamgym.training.autonomous_driving.config_validation import (
    normalize_reward_preset,
    thaw_json,
)


def _detached_reward_mapping(config):
    if config is None:
        config = RewardConfig()
    if isinstance(config, RewardConfig):
        source = {
            "preset_name": config.preset_name,
            "preset_parameters": config.preset_parameters,
        }
    elif isinstance(config, Mapping):
        source = thaw_json(config)
    else:
        raise TypeError("reward configuration must be RewardConfig or a mapping.")
    if set(source) != {"preset_name", "preset_parameters"}:
        raise ValueError("reward configuration has unsupported or missing keys.")
    return normalize_reward_preset(
        source["preset_name"],
        source["preset_parameters"],
    )


def _required_value(ground_truth: Dict[str, Any], key: str) -> float:
    if key not in ground_truth:
        raise KeyError("current_ground_truth is missing required field: " + key)
    return float(ground_truth[key])


def _finite_reward(value: Any, source: str) -> float:
    reward = float(value)
    if not math.isfinite(reward):
        raise ValueError(source + " must return a finite reward")
    return reward


def _current_ground_truth(env: gym.Env) -> Dict[str, Any]:
    ground_truth = env.unwrapped.get_current_ground_truth()
    if type(ground_truth) is not dict:
        raise TypeError("get_current_ground_truth() must return an object.")
    return dict(ground_truth)


def lane_keep_reward(lateral_error_m: float) -> float:
    return 1.0 / (1.0 + abs(float(lateral_error_m)))


def speed_following_reward(speed_mps: float, recommended_speed_mps: float) -> float:
    if recommended_speed_mps <= 0.0 or not math.isfinite(recommended_speed_mps):
        return 0.0
    return 1.0 / (1.0 + abs(float(speed_mps) - float(recommended_speed_mps)))


def combined_lane_speed_reward(
    ground_truth: Dict[str, Any],
    *,
    previous_progress_m: float,
    params: Dict[str, Any],
) -> tuple[float, Dict[str, float]]:
    progress_m = _required_value(ground_truth, "reference_line_progress_m")
    lateral_error_m = _required_value(
        ground_truth,
        "lateral_error_from_target_line_m",
    )
    heading_error_rad = _required_value(
        ground_truth,
        "heading_error_from_target_line_rad",
    )
    speed_mps = _required_value(
        ground_truth,
        "ground_truth_body_longitudinal_velocity_mps",
    )
    recommended_speed_mps = _required_value(
        ground_truth,
        "recommended_speed_mps",
    )

    progress_delta_m = progress_m - float(previous_progress_m)
    lane_term = lane_keep_reward(lateral_error_m)
    heading_gate = max(0.0, math.cos(heading_error_rad))
    speed_term = heading_gate * speed_following_reward(speed_mps, recommended_speed_mps)
    progress_term = progress_delta_m

    reward = (
        float(params["k_lane"]) * lane_term +
        float(params["k_speed"]) * speed_term +
        float(params["k_progress"]) * progress_term
    )
    return reward, {
        "lane": lane_term,
        "speed": speed_term,
        "progress": progress_term,
        "heading_gate": heading_gate,
        "speed_target_mps": recommended_speed_mps,
        "speed_mps": speed_mps,
        "lateral_error_m": abs(lateral_error_m),
    }


@dataclass(frozen=True)
class RewardContext:
    observation: Any
    action: Any
    base_reward: float
    terminated: bool
    truncated: bool
    info: Dict[str, Any]
    ground_truth: Dict[str, Any]
    previous_ground_truth: Optional[Dict[str, Any]]


class RewardFunctionWrapper(gym.Wrapper):
    """Apply a user-supplied reward function to each environment step."""

    def __init__(self, env: gym.Env, reward_fn: Callable[[RewardContext], Any]):
        super().__init__(env)
        if not callable(reward_fn):
            raise TypeError("reward_fn must be callable.")
        self.reward_fn = reward_fn
        self._previous_ground_truth: Optional[Dict[str, Any]] = None

    def reset(self, **kwargs):
        result = self.env.reset(**kwargs)
        self._previous_ground_truth = _current_ground_truth(self.env)
        return result

    def step(self, action):
        observation, base_reward, terminated, truncated, info = self.env.step(action)
        info = dict(info)
        ground_truth = _current_ground_truth(self.env)
        context = RewardContext(
            observation=observation,
            action=action,
            base_reward=float(base_reward),
            terminated=bool(terminated),
            truncated=bool(truncated),
            info=info,
            ground_truth=ground_truth,
            previous_ground_truth=self._previous_ground_truth,
        )
        reward_result = self.reward_fn(context)
        if isinstance(reward_result, tuple):
            reward, terms = reward_result
            info["reward_terms"] = dict(terms)
        else:
            reward = reward_result
        self._previous_ground_truth = ground_truth
        return (
            observation,
            _finite_reward(reward, "reward_fn"),
            terminated,
            truncated,
            info,
        )


class CombinedLaneSpeedRewardWrapper(gym.Wrapper):
    """Default RL reward that always follows the road recommended speed."""

    def __init__(self, env: gym.Env, config=None):
        super().__init__(env)
        self.config = _detached_reward_mapping(config)
        self.params = copy.deepcopy(self.config["preset_parameters"])
        self._previous_progress_m = 0.0

    def reset(self, **kwargs):
        result = self.env.reset(**kwargs)
        ground_truth = _current_ground_truth(self.env)
        self._previous_progress_m = _required_value(
            ground_truth,
            "reference_line_progress_m",
        )
        return result

    def step(self, action):
        obs, _base_reward, terminated, truncated, info = self.env.step(action)
        ground_truth = _current_ground_truth(self.env)
        reward, terms = combined_lane_speed_reward(
            ground_truth,
            previous_progress_m=self._previous_progress_m,
            params=self.params,
        )
        self._previous_progress_m = _required_value(
            ground_truth,
            "reference_line_progress_m",
        )

        road_progress_completion_reward = 0.0
        lateral_error_termination_reward = 0.0
        truncation_without_termination_reward = 0.0

        if terminated:
            termination_reasons = (
                info.get("termination_reasons", {})
                if isinstance(info, dict)
                else {}
            )
            if termination_reasons.get(
                "road_progress_completion_threshold_reached"
            ):
                road_progress_completion_reward = float(
                    self.params["road_progress_completion_reward"]
                )
            if termination_reasons.get(
                "absolute_lateral_error_from_target_line_above_upper_bound"
            ):
                lateral_error_termination_reward = float(
                    self.params[
                        "absolute_lateral_error_from_target_line_termination_reward"
                    ]
                )
        if truncated and not terminated:
            truncation_without_termination_reward = float(
                self.params["truncation_without_termination_reward"]
            )

        reward += (
            road_progress_completion_reward
            + lateral_error_termination_reward
            + truncation_without_termination_reward
        )
        reward = _finite_reward(reward, "combined_lane_speed reward")
        terms = dict(terms)
        terms.update({
            "road_progress_completion_reward": (
                road_progress_completion_reward
            ),
            "absolute_lateral_error_from_target_line_termination_reward": (
                lateral_error_termination_reward
            ),
            "truncation_without_termination_reward": (
                truncation_without_termination_reward
            ),
            "total": reward,
        })
        info = dict(info)
        info["reward_terms"] = terms
        return obs, reward, terminated, truncated, info


def make_reward_wrapper(env: gym.Env, config=None) -> gym.Env:
    source = _detached_reward_mapping(config)
    return CombinedLaneSpeedRewardWrapper(env, source)
