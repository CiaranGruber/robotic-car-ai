"""Canonical requested and resolved training snapshot primitives."""

from __future__ import annotations

import copy
from collections import OrderedDict
from dataclasses import fields
from importlib.metadata import version
import json
import math
from pathlib import Path
import platform
import re

import gymnasium as gym
import numpy as np

from dreamgym.envs.observation_specs import compile_observation_records
from dreamgym.envs.road_core.random_generation import (
    normalize_random_road_generation_config,
)
from dreamgym.training.autonomous_driving.algorithm_profiles import (
    ALGORITHM_PROFILES,
    ALGORITHM_PROFILE_VERSION,
    resolve_profile_overrides,
)
from dreamgym.training.autonomous_driving.config_validation import (
    canonical_json_text,
    canonical_snapshot_digest,
    config_from_dict,
    config_to_dict,
    construct_dataclass_strict,
    normalize_reward_preset,
    parse_strict_json_object,
    thaw_json,
    validate_environment_config,
    validate_evaluation_and_artifacts,
    validate_json_value,
    validate_logging_config,
    validate_train_randomization_config,
)
from dreamgym.training.autonomous_driving.configs import (
    ArtifactConfig,
    CONFIG_KIND,
    EvaluationConfig,
    LoggingConfig,
    SCHEMA_VERSION,
    EnvConfig,
    RoadGenerationConfig,
    TrainRandomizationConfig,
)
from dreamgym.training.autonomous_driving.resolution import (
    EvaluationRoadCase,
    RESOLVER_VERSION,
    TRAINING_ROAD_SOURCE_PRECEDENCE,
    TRAINING_SEED_COUNTER_RULE,
    ResolvedTrainingConfig,
    TrainingBuildConfig,
    buffer_kind_for_algorithm,
    default_training_road_spec,
    evaluation_seed_derivation_rules,
    evaluation_road_specs_from_snapshot,
    effective_algorithm_constructor_kwargs,
    policy_alias_for_observation_format,
    resolved_environment_record,
    validate_random_road_source_for_target,
    validate_road_for_target,
)
from dreamgym.training.autonomous_driving.seeds import (
    derive_seed,
    seed_derivation_version,
)


_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_BOUND_TOKENS = frozenset(("negative_infinity", "positive_infinity"))
_RESOLVED_ALGORITHM_FIELDS = (
    "name",
    "profile_version",
    "constructor_kwargs",
    "policy_kwargs",
    "explicit_hyperparameter_overrides",
    "explicit_policy_kwargs",
    "policy_alias",
    "buffer_kind",
    "requested_n_rollout_transitions_per_update",
    "n_rollout_transitions_per_update_applicability",
    "native_n_steps_per_environment",
    "n_rollout_transitions_per_update_effective",
    "n_rollout_transitions_rounding_amount",
    "ppo_minibatch_remainder",
    "transitions_per_collection",
    "gradient_steps_per_collection",
    "update_to_data_ratio",
)
_MIGRATION_GUIDANCE = (
    "Copy and edit the requested configuration using the final field names; "
    "set schema_version=2; for retraining, pass the complete requested "
    "configuration to training, which generates a fresh finalized snapshot "
    "with dreamgym-training-resolver-v3. Use a compatible finalized "
    "resolver-v3 snapshot only for saved-model reconstruction. No converter, "
    "compatibility reader, legacy reader, or adapter is available."
)
_POLICY_CLASSES = {
    ("PPO", "MlpPolicy"): (
        "stable_baselines3.common.policies.ActorCriticPolicy"
    ),
    ("A2C", "MlpPolicy"): (
        "stable_baselines3.common.policies.ActorCriticPolicy"
    ),
    ("PPO", "MultiInputPolicy"): (
        "stable_baselines3.common.policies.MultiInputActorCriticPolicy"
    ),
    ("A2C", "MultiInputPolicy"): (
        "stable_baselines3.common.policies.MultiInputActorCriticPolicy"
    ),
    ("SAC", "MlpPolicy"): "stable_baselines3.sac.policies.SACPolicy",
    ("SAC", "MultiInputPolicy"): (
        "stable_baselines3.sac.policies.MultiInputPolicy"
    ),
    ("TD3", "MlpPolicy"): "stable_baselines3.td3.policies.TD3Policy",
    ("DDPG", "MlpPolicy"): "stable_baselines3.td3.policies.TD3Policy",
    ("TD3", "MultiInputPolicy"): (
        "stable_baselines3.td3.policies.MultiInputPolicy"
    ),
    ("DDPG", "MultiInputPolicy"): (
        "stable_baselines3.td3.policies.MultiInputPolicy"
    ),
}
_FLATTEN_EXTRACTOR = (
    "stable_baselines3.common.torch_layers.FlattenExtractor"
)
_COMBINED_EXTRACTOR = (
    "stable_baselines3.common.torch_layers.CombinedExtractor"
)
_ACTIVATION_CLASSES = {
    "relu": "torch.nn.modules.activation.ReLU",
    "tanh": "torch.nn.modules.activation.Tanh",
    "elu": "torch.nn.modules.activation.ELU",
    "leaky_relu": "torch.nn.modules.activation.LeakyReLU",
}
_BUFFER_CLASSES = {
    "rollout_flat": "stable_baselines3.common.buffers.RolloutBuffer",
    "rollout_dict": "stable_baselines3.common.buffers.DictRolloutBuffer",
    "replay_flat": "stable_baselines3.common.buffers.ReplayBuffer",
    "replay_dict": "stable_baselines3.common.buffers.DictReplayBuffer",
    "replay_n_step": "stable_baselines3.common.buffers.NStepReplayBuffer",
}
_RUNTIME_MODEL_FIELDS = (
    "policy_alias",
    "policy_class",
    "feature_extractor_class",
    "activation_fn",
    "activation_class",
    "net_arch",
    "buffer_class",
    "buffer_kwargs",
    "critic_count",
    "device",
)
_DDPG_RUNTIME_FIELDS = (
    "policy_delay",
    "target_policy_noise",
    "target_noise_clip",
)

def requested_snapshot(config):
    """Return a validated, detached requested snapshot."""

    return config_to_dict(config)


def _encode_bound(value, dtype):
    if np.dtype(dtype).kind in ("b", "i", "u"):
        return int(value)
    value = float(value)
    if math.isinf(value):
        return "negative_infinity" if value < 0.0 else "positive_infinity"
    if not math.isfinite(value):
        raise ValueError("Gymnasium space bounds cannot contain NaN.")
    return value


def encode_gym_space(space):
    """Encode the supported Gymnasium spaces using strict JSON-native values."""

    if isinstance(space, gym.spaces.Box):
        encoded = {
            "type": "Box",
            "shape": list(space.shape),
            "dtype": str(space.dtype),
            "low": [
                _encode_bound(value, space.dtype)
                for value in space.low.reshape(-1)
            ],
            "high": [
                _encode_bound(value, space.dtype)
                for value in space.high.reshape(-1)
            ],
        }
    elif isinstance(space, gym.spaces.Dict):
        encoded = {
            "type": "Dict",
            "spaces": {
                key: encode_gym_space(child)
                for key, child in space.spaces.items()
            },
        }
    else:
        raise TypeError(
            "Unsupported Gymnasium space type: " + type(space).__name__
        )
    return validate_json_value(encoded, path="space")


def _decode_bound(value):
    if value == "negative_infinity":
        return -math.inf
    if value == "positive_infinity":
        return math.inf
    return value


def decode_gym_space(encoded):
    """Decode one canonical Box/Dict encoding without consulting defaults."""

    detached = validate_json_value(encoded, path="space")
    _validate_encoded_gym_space(detached, "space")
    if detached["type"] == "Dict":
        return gym.spaces.Dict(OrderedDict(
            (key, decode_gym_space(child))
            for key, child in detached["spaces"].items()
        ))

    shape = tuple(detached["shape"])
    dtype = np.dtype(detached["dtype"])
    low = np.asarray(
        [_decode_bound(value) for value in detached["low"]],
        dtype=dtype,
    ).reshape(shape)
    high = np.asarray(
        [_decode_bound(value) for value in detached["high"]],
        dtype=dtype,
    ).reshape(shape)
    return gym.spaces.Box(low=low, high=high, shape=shape, dtype=dtype)


def save_snapshot_json(snapshot, path):
    """Write a snapshot as sorted, indented, strict JSON."""

    detached = validate_json_value(snapshot, path="snapshot")
    text = json.dumps(
        detached,
        allow_nan=False,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n"
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8", newline="\n")


def preconstruction_snapshot(build):
    """Assemble the internal resolved-build record available before runtime."""

    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    snapshot = {
        "config_kind": build.config_kind,
        "schema_version": build.schema_version,
        "snapshot_type": "resolved_build_internal",
        "experiment_name": build.experiment_name,
        "resolver_version": build.resolver_version,
        "algorithm_profile_version": build.algorithm.profile_version,
        "seed_derivation_version": build.seed_derivation_version,
        "requested_config_digest": build.requested_digest,
        "requested_total_environment_transitions": (
            build.requested_total_environment_transitions
        ),
        "vectorization": {
            "vec_env": build.requested_dict["vectorization"]["vec_env"],
            "subproc_start_method": build.requested_dict["vectorization"][
                "subproc_start_method"
            ],
            "requested_n_envs": build.requested_dict["vectorization"]["n_envs"],
            "effective_n_envs": build.effective_n_envs,
            "n_envs_source": build.n_envs_source,
        },
        "algorithm": build.algorithm.to_dict(),
        "environment": build.environment_dict(),
        "roads": build.roads_dict(),
        "seeds": build.seeds_dict(),
        "reward": build.reward_dict(),
        "evaluation": _resolved_evaluation_snapshot(build),
        "artifacts": build.artifacts_dict(),
        "logging": build.logging_dict(),
        "wrappers": {
            "exact_inner_to_outer": _expected_training_wrapper_stack({
                "vectorization": {
                    "vec_env": build.requested_dict["vectorization"]["vec_env"],
                },
                "environment": build.environment_dict(),
                "roads": build.roads_dict(),
            }),
        },
        "warnings": list(build.warnings),
    }
    return validate_preconstruction_snapshot(snapshot)


def _resolved_evaluation_snapshot(build):
    roads = build.roads_dict()
    fixed = roads["fixed_evaluation_road_specs"]
    return {
        "configuration": build.evaluation_dict(),
        "road_family_order": ["fixed", "reused_random", "fresh_random"],
        "road_counts": {
            "fixed": 1 if fixed is None else len(fixed),
            "reused_random": roads[
                "n_random_evaluation_roads_reused_across_evaluations"
            ],
            "fresh_random": roads[
                "n_fresh_random_evaluation_roads_per_evaluation"
            ],
        },
    }


def _require_object(value, path):
    if type(value) is not dict:
        raise TypeError(path + " must be an object.")
    return value


def _require_fields(value, required, path):
    missing = sorted(set(required) - set(value))
    if missing:
        raise ValueError(path + "." + missing[0] + " is required.")


def _require_exact_fields(value, required, path):
    _require_fields(value, required, path)
    unexpected = sorted(set(value) - set(required))
    if unexpected:
        raise ValueError(path + "." + unexpected[0] + " is unsupported.")


def _require_integer(value, path):
    if type(value) is not int:
        raise TypeError(path + " must be an integer.")
    return value


def _require_nonnegative_integer(value, path):
    value = _require_integer(value, path)
    if value < 0:
        raise ValueError(path + " must be a non-negative integer.")
    return value


def _first_json_difference(actual, expected, path):
    """Return the first deterministic dotted path whose JSON values differ."""

    if type(actual) is not type(expected):
        return path
    if type(actual) is dict:
        for key in sorted(set(actual) | set(expected)):
            child_path = path + "." + str(key)
            if key not in actual or key not in expected:
                return child_path
            difference = _first_json_difference(
                actual[key], expected[key], child_path
            )
            if difference is not None:
                return difference
        return None
    if type(actual) is list:
        if len(actual) != len(expected):
            return path
        for index, (actual_item, expected_item) in enumerate(
            zip(actual, expected)
        ):
            difference = _first_json_difference(
                actual_item,
                expected_item,
                path + "[" + str(index) + "]",
            )
            if difference is not None:
                return difference
        return None
    if actual != expected:
        return path
    return None


def _unsupported_version_message(field, encountered, supported):
    return (
        "snapshot."
        + field
        + "="
        + repr(encountered)
        + " is unsupported; supported "
        + field
        + "="
        + repr(supported)
        + "; manual migration is required. "
        + _MIGRATION_GUIDANCE
    )


def _snapshot_envelope_fields(snapshot_type):
    fields = (
        "config_kind",
        "schema_version",
        "snapshot_type",
        "resolver_version",
        "algorithm_profile_version",
        "seed_derivation_version",
        "requested_config_digest",
        "experiment_name",
        "requested_total_environment_transitions",
        "vectorization",
        "algorithm",
        "environment",
        "roads",
        "seeds",
        "reward",
        "evaluation",
        "artifacts",
        "logging",
        "wrappers",
        "warnings",
    )
    if snapshot_type == "resolved":
        fields += ("versions", "spaces", "runtime_model")
    return fields


def _validate_snapshot_envelope(snapshot, *, snapshot_type):
    expected_fields = _snapshot_envelope_fields(snapshot_type)
    _require_exact_fields(
        snapshot,
        expected_fields,
        "snapshot",
    )
    if type(snapshot["config_kind"]) is not str or snapshot["config_kind"] != CONFIG_KIND:
        raise ValueError(
            _unsupported_version_message(
                "config_kind",
                snapshot["config_kind"],
                CONFIG_KIND,
            )
        )
    if type(snapshot["schema_version"]) is not int or snapshot["schema_version"] != SCHEMA_VERSION:
        raise ValueError(
            _unsupported_version_message(
                "schema_version",
                snapshot["schema_version"],
                SCHEMA_VERSION,
            )
        )
    if type(snapshot["snapshot_type"]) is not str or snapshot["snapshot_type"] != snapshot_type:
        raise ValueError("snapshot.snapshot_type must be " + snapshot_type + ".")
    if snapshot["resolver_version"] != RESOLVER_VERSION:
        raise ValueError(
            _unsupported_version_message(
                "resolver_version",
                snapshot["resolver_version"],
                RESOLVER_VERSION,
            )
        )
    if snapshot["algorithm_profile_version"] != ALGORITHM_PROFILE_VERSION:
        raise ValueError(
            _unsupported_version_message(
                "algorithm_profile_version",
                snapshot["algorithm_profile_version"],
                ALGORITHM_PROFILE_VERSION,
            )
        )
    digest = snapshot["requested_config_digest"]
    if type(digest) is not str or _DIGEST_PATTERN.fullmatch(digest) is None:
        raise ValueError(
            "snapshot.requested_config_digest must be exactly 64 lowercase hexadecimal characters."
        )
    if type(snapshot["experiment_name"]) is not str or not snapshot["experiment_name"]:
        raise ValueError("snapshot.experiment_name must be a non-empty string.")
    requested_transitions = snapshot["requested_total_environment_transitions"]
    if type(requested_transitions) is not int or requested_transitions <= 0:
        raise ValueError(
            "snapshot.requested_total_environment_transitions must be positive."
        )
    for field in (
        "vectorization",
        "algorithm",
        "environment",
        "roads",
        "seeds",
        "reward",
        "evaluation",
        "artifacts",
        "logging",
        "wrappers",
    ):
        _require_object(snapshot[field], "snapshot." + field)
    if (
        type(snapshot["seed_derivation_version"]) is not str
        or not snapshot["seed_derivation_version"]
    ):
        raise ValueError(
            "snapshot.seed_derivation_version must be a non-empty string."
        )
    if snapshot["seed_derivation_version"] != seed_derivation_version():
        raise ValueError(
            _unsupported_version_message(
                "seed_derivation_version",
                snapshot["seed_derivation_version"],
                seed_derivation_version(),
            )
        )
    if type(snapshot["warnings"]) is not list:
        raise TypeError("snapshot.warnings must be a list.")


def _expected_training_wrapper_stack(snapshot):
    vectorization = _require_object(
        snapshot["vectorization"],
        "snapshot.vectorization",
    )
    environment = _require_object(snapshot["environment"], "snapshot.environment")
    training = _require_object(
        environment["training"],
        "snapshot.environment.training",
    )
    roads = _require_object(snapshot["roads"], "snapshot.roads")
    stack = [
        "AutonomousDrivingEnv",
        "PassiveEnvChecker",
        "OrderEnforcing",
        "TargetRelativeInitialStateResetWrapper",
    ]
    if roads["winning_training_source"] == "train_randomization":
        stack.append("RandomRoadResetWrapper")
    if training["max_episode_steps"] is not None:
        stack.append("TimeLimit")
    stack.append("CombinedLaneSpeedRewardWrapper")
    stack.append({
        "dummy": "DummyVecEnv",
        "subproc": "SubprocVecEnv",
    }.get(vectorization["vec_env"], ""))
    return stack


def _validate_wrapper_provenance(snapshot):
    wrappers = _require_object(snapshot["wrappers"], "snapshot.wrappers")
    _require_exact_fields(
        wrappers,
        ("exact_inner_to_outer",),
        "snapshot.wrappers",
    )
    wrapper_names = wrappers["exact_inner_to_outer"]
    if type(wrapper_names) is not list or any(
        type(name) is not str or not name for name in wrapper_names
    ):
        raise TypeError(
            "snapshot.wrappers.exact_inner_to_outer must be a list of strings."
        )
    expected = _expected_training_wrapper_stack(snapshot)
    if (
        snapshot.get("snapshot_type") == "resolved"
        and wrapper_names == expected + ["VecMonitor"]
    ):
        return
    if wrapper_names != expected:
        raise ValueError(
            "snapshot.wrappers.exact_inner_to_outer does not match the exact "
            "logical training wrapper stack."
        )


def _validate_environment_and_reward_provenance(snapshot):
    environment = _require_object(snapshot["environment"], "snapshot.environment")
    environment_fields = (
        "public_constructor_template",
        "target_relative_reset",
        "effective_action_interface",
        "gymnasium_metadata",
        "training",
        "postconstruction_settings",
    )
    _require_exact_fields(
        environment,
        environment_fields,
        "snapshot.environment",
    )
    training = _require_object(
        environment["training"],
        "snapshot.environment.training",
    )
    _require_exact_fields(
        training,
        tuple(field.name for field in fields(EnvConfig)),
        "snapshot.environment.training",
    )
    canonical_environment = construct_dataclass_strict(
        EnvConfig,
        training,
        "snapshot.environment.training",
    )
    validate_environment_config(
        canonical_environment,
        path="snapshot.environment.training",
    )
    try:
        expected_environment = resolved_environment_record(
            copy.deepcopy(training)
        )
    except (TypeError, ValueError, KeyError) as exc:
        raise type(exc)("snapshot.environment.training: " + str(exc)) from exc
    for field_name in environment_fields:
        difference = _first_json_difference(
            environment[field_name],
            expected_environment[field_name],
            "snapshot.environment." + field_name,
        )
        if difference is not None:
            raise ValueError(
                difference
                + " does not match the canonical training environment translation."
            )

    reward = _require_object(snapshot["reward"], "snapshot.reward")
    _require_exact_fields(
        reward,
        ("requested", "effective"),
        "snapshot.reward",
    )
    requested = _require_object(
        reward["requested"],
        "snapshot.reward.requested",
    )
    _require_exact_fields(
        requested,
        ("preset_name", "preset_parameters"),
        "snapshot.reward.requested",
    )
    try:
        expected_reward = normalize_reward_preset(
            requested["preset_name"],
            requested["preset_parameters"],
        )
    except (TypeError, ValueError, KeyError) as exc:
        raise type(exc)("snapshot.reward.requested: " + str(exc)) from exc
    difference = _first_json_difference(
        reward["effective"],
        expected_reward,
        "snapshot.reward.effective",
    )
    if difference is not None:
        raise ValueError(
            difference + " does not match snapshot.reward.requested."
        )


def _validate_evaluation_artifact_and_logging_sections(snapshot):
    artifact_record = _require_object(
        snapshot["artifacts"],
        "snapshot.artifacts",
    )
    requested_artifact_fields = tuple(
        field.name for field in fields(ArtifactConfig)
    )
    if snapshot["snapshot_type"] == "resolved":
        _require_exact_fields(
            artifact_record,
            requested_artifact_fields + ("final_policy_animation",),
            "snapshot.artifacts",
        )
    else:
        _require_exact_fields(
            artifact_record,
            requested_artifact_fields,
            "snapshot.artifacts",
        )
    evaluation_record = _require_object(
        snapshot["evaluation"],
        "snapshot.evaluation",
    )
    _require_exact_fields(
        evaluation_record,
        ("configuration", "road_family_order", "road_counts"),
        "snapshot.evaluation",
    )
    expected_family_order = ["fixed", "reused_random", "fresh_random"]
    if evaluation_record["road_family_order"] != expected_family_order:
        raise ValueError(
            "snapshot.evaluation.road_family_order must be fixed, "
            "reused_random, fresh_random."
        )
    road_counts = _require_object(
        evaluation_record["road_counts"],
        "snapshot.evaluation.road_counts",
    )
    _require_exact_fields(
        road_counts,
        tuple(expected_family_order),
        "snapshot.evaluation.road_counts",
    )
    for family in expected_family_order:
        _require_nonnegative_integer(
            road_counts[family],
            "snapshot.evaluation.road_counts." + family,
        )
    evaluation = construct_dataclass_strict(
        EvaluationConfig,
        evaluation_record["configuration"],
        "snapshot.evaluation.configuration",
    )
    artifacts = construct_dataclass_strict(
        ArtifactConfig,
        {
            field_name: artifact_record[field_name]
            for field_name in requested_artifact_fields
        },
        "snapshot.artifacts",
    )
    logging = construct_dataclass_strict(
        LoggingConfig,
        snapshot["logging"],
        "snapshot.logging",
    )
    roads = snapshot["roads"]
    for field_name in (
        "n_random_evaluation_roads_reused_across_evaluations",
        "n_fresh_random_evaluation_roads_per_evaluation",
    ):
        _require_nonnegative_integer(
            roads[field_name],
            "snapshot.roads." + field_name,
        )
    fixed_evaluation = roads["fixed_evaluation_road_specs"]
    expected_road_counts = {
        "fixed": 1 if fixed_evaluation is None else len(fixed_evaluation),
        "reused_random": roads[
            "n_random_evaluation_roads_reused_across_evaluations"
        ],
        "fresh_random": roads[
            "n_fresh_random_evaluation_roads_per_evaluation"
        ],
    }
    for family, expected_count in expected_road_counts.items():
        if road_counts[family] != expected_count:
            raise ValueError(
                "snapshot.evaluation.road_counts."
                + family
                + " does not match snapshot.roads."
            )
    evaluation_road_count = sum(expected_road_counts.values())
    validate_evaluation_and_artifacts(
        evaluation,
        artifacts,
        requested_total_environment_transitions=(
            snapshot["requested_total_environment_transitions"]
        ),
        evaluation_road_count=evaluation_road_count,
        path="snapshot",
    )
    validate_logging_config(logging, path="snapshot.logging")
    if snapshot["snapshot_type"] == "resolved":
        expected_final_animation = None
        if artifacts.save_final_policy_animation:
            cases = evaluation_road_specs_from_snapshot(
                snapshot,
                evaluation_execution_context="standalone",
                scheduled_evaluation_step=None,
            )
            index = artifacts.animation_evaluation_road_index
            if index >= len(cases):
                raise ValueError(
                    "snapshot.artifacts.animation_evaluation_road_index exceeds "
                    "the resolved standalone evaluation-road list."
                )
            expected_final_animation = cases[index].to_dict()
        difference = _first_json_difference(
            artifact_record["final_policy_animation"],
            expected_final_animation,
            "snapshot.artifacts.final_policy_animation",
        )
        if difference is not None:
            raise ValueError(
                difference
                + " does not match the recomputed standalone evaluation road."
            )


def _validate_rollout_arithmetic(snapshot):
    vectorization = _require_object(snapshot.get("vectorization"), "snapshot.vectorization")
    algorithm = _require_object(snapshot.get("algorithm"), "snapshot.algorithm")
    _require_exact_fields(
        vectorization,
        (
            "vec_env",
            "subproc_start_method",
            "requested_n_envs",
            "effective_n_envs",
            "n_envs_source",
        ),
        "snapshot.vectorization",
    )
    _require_fields(algorithm, _RESOLVED_ALGORITHM_FIELDS, "snapshot.algorithm")
    unexpected_fields = sorted(set(algorithm) - set(_RESOLVED_ALGORITHM_FIELDS))
    if unexpected_fields:
        raise ValueError(
            "snapshot.algorithm." + unexpected_fields[0] + " is unsupported."
        )
    _validate_algorithm_field_types(algorithm)
    if algorithm["profile_version"] != snapshot["algorithm_profile_version"]:
        raise ValueError(
            "snapshot.algorithm.profile_version does not match algorithm_profile_version."
        )
    name = algorithm["name"]
    if name not in ALGORITHM_PROFILES:
        raise ValueError("snapshot.algorithm.name is unsupported.")
    if vectorization["vec_env"] not in ("dummy", "subproc"):
        raise ValueError("snapshot.vectorization.vec_env is unsupported.")
    if vectorization["subproc_start_method"] not in (
        "spawn",
        "fork",
        "forkserver",
    ):
        raise ValueError(
            "snapshot.vectorization.subproc_start_method is unsupported."
        )
    requested_n_envs = vectorization["requested_n_envs"]
    if requested_n_envs == "algorithm_default":
        expected_n_envs = ALGORITHM_PROFILES[name]["algorithm_default_n_envs"]
        expected_source = "algorithm_profile"
    elif type(requested_n_envs) is int and requested_n_envs > 0:
        expected_n_envs = requested_n_envs
        expected_source = "explicit_override"
    else:
        raise ValueError("Resolved vectorization provenance is inconsistent.")
    n_envs = vectorization["effective_n_envs"]
    if (
        type(n_envs) is not int
        or n_envs != expected_n_envs
        or vectorization["n_envs_source"] != expected_source
    ):
        raise ValueError("Resolved vectorization provenance is inconsistent.")
    _validate_algorithm_profile_provenance(snapshot, algorithm)

    applicability = algorithm["n_rollout_transitions_per_update_applicability"]
    if name in ("PPO", "A2C"):
        if applicability != "applicable":
            raise ValueError(
                "snapshot.algorithm rollout applicability is inconsistent."
            )
        requested = algorithm["requested_n_rollout_transitions_per_update"]
        if requested == "algorithm_default":
            requested = ALGORITHM_PROFILES[name][
                "algorithm_default_rollout_transitions"
            ]
        if type(requested) is not int or requested <= 0:
            raise ValueError("Resolved rollout arithmetic is inconsistent.")
        expected_native = (requested + n_envs - 1) // n_envs
        expected_effective = expected_native * n_envs
        expected_rounding = expected_effective - requested
        if (
            algorithm["native_n_steps_per_environment"] != expected_native
            or algorithm["n_rollout_transitions_per_update_effective"]
            != expected_effective
            or algorithm["n_rollout_transitions_rounding_amount"]
            != expected_rounding
        ):
            raise ValueError("Resolved rollout arithmetic is inconsistent.")
        constructor = _require_object(
            algorithm["constructor_kwargs"],
            "snapshot.algorithm.constructor_kwargs",
        )
        expected_remainder = (
            expected_effective % constructor["batch_size"]
            if name == "PPO"
            else None
        )
        if algorithm["ppo_minibatch_remainder"] != expected_remainder:
            raise ValueError("Resolved rollout arithmetic is inconsistent.")
        for field in (
            "transitions_per_collection",
            "gradient_steps_per_collection",
            "update_to_data_ratio",
        ):
            if algorithm[field] is not None:
                raise ValueError("Resolved rollout arithmetic is inconsistent.")
        if algorithm["buffer_kind"] != "rollout":
            raise ValueError("Resolved rollout buffer kind is inconsistent.")
        expected_warnings = []
        if expected_remainder:
            expected_warnings.append(
                "PPO effective rollout is not divisible by batch_size; "
                "SB3 will use a smaller final minibatch of "
                + str(expected_remainder)
                + "."
            )
        if snapshot.get("warnings") != expected_warnings:
            raise ValueError("snapshot.warnings do not match rollout arithmetic.")
        return

    if name in ("SAC", "TD3", "DDPG"):
        if applicability != "not_applicable":
            raise ValueError(
                "snapshot.algorithm rollout applicability is inconsistent."
            )
        if algorithm["requested_n_rollout_transitions_per_update"] != "algorithm_default":
            raise ValueError("Resolved rollout arithmetic is inconsistent.")
        for field in (
            "native_n_steps_per_environment",
            "n_rollout_transitions_per_update_effective",
            "n_rollout_transitions_rounding_amount",
            "ppo_minibatch_remainder",
        ):
            if algorithm[field] is not None:
                raise ValueError("Resolved rollout arithmetic is inconsistent.")
        constructor = _require_object(
            algorithm["constructor_kwargs"],
            "snapshot.algorithm.constructor_kwargs",
        )
        expected_transitions = constructor["train_freq"] * n_envs
        expected_gradient_steps = (
            expected_transitions
            if constructor["gradient_steps"] == -1
            else constructor["gradient_steps"]
        )
        expected_ratio = expected_gradient_steps / expected_transitions
        if (
            algorithm["transitions_per_collection"] != expected_transitions
            or algorithm["gradient_steps_per_collection"]
            != expected_gradient_steps
            or algorithm["update_to_data_ratio"] != expected_ratio
        ):
            raise ValueError("Resolved off-policy cadence is inconsistent.")
        if algorithm["buffer_kind"] != "replay":
            raise ValueError("Resolved off-policy cadence buffer kind is inconsistent.")
        if snapshot.get("warnings") != []:
            raise ValueError("snapshot.warnings do not match off-policy cadence.")
        return

    if applicability not in ("applicable", "not_applicable"):
        raise ValueError(
            "snapshot.algorithm.n_rollout_transitions_per_update_applicability "
            "is unsupported."
        )
    raise ValueError("snapshot.algorithm.name is unsupported.")


def _validate_algorithm_field_types(algorithm):
    for field in (
        "name",
        "profile_version",
        "policy_alias",
        "buffer_kind",
        "n_rollout_transitions_per_update_applicability",
    ):
        if type(algorithm[field]) is not str:
            raise TypeError("snapshot.algorithm." + field + " must be a string.")

    for field in (
        "constructor_kwargs",
        "policy_kwargs",
        "explicit_hyperparameter_overrides",
        "explicit_policy_kwargs",
    ):
        _require_object(algorithm[field], "snapshot.algorithm." + field)

    requested_rollout = algorithm[
        "requested_n_rollout_transitions_per_update"
    ]
    if not (
        type(requested_rollout) is int
        or type(requested_rollout) is str
    ):
        raise TypeError(
            "snapshot.algorithm.requested_n_rollout_transitions_per_update "
            "must be an integer or string."
        )

    for field in (
        "native_n_steps_per_environment",
        "n_rollout_transitions_per_update_effective",
        "n_rollout_transitions_rounding_amount",
        "ppo_minibatch_remainder",
        "transitions_per_collection",
        "gradient_steps_per_collection",
    ):
        value = algorithm[field]
        if value is not None and type(value) is not int:
            raise TypeError(
                "snapshot.algorithm." + field + " must be an integer or null."
            )

    update_to_data_ratio = algorithm["update_to_data_ratio"]
    if update_to_data_ratio is not None and type(update_to_data_ratio) is not float:
        raise TypeError(
            "snapshot.algorithm.update_to_data_ratio must be a float or null."
        )


def _validate_algorithm_profile_provenance(snapshot, algorithm):
    name = algorithm["name"]
    if name not in ALGORITHM_PROFILES:
        raise ValueError("snapshot.algorithm.name is unsupported.")

    constructor_kwargs = _require_object(
        algorithm["constructor_kwargs"],
        "snapshot.algorithm.constructor_kwargs",
    )
    policy_kwargs = _require_object(
        algorithm["policy_kwargs"],
        "snapshot.algorithm.policy_kwargs",
    )
    explicit_hyperparameters = _require_object(
        algorithm["explicit_hyperparameter_overrides"],
        "snapshot.algorithm.explicit_hyperparameter_overrides",
    )
    explicit_policy_kwargs = _require_object(
        algorithm["explicit_policy_kwargs"],
        "snapshot.algorithm.explicit_policy_kwargs",
    )
    policy_alias = algorithm["policy_alias"]

    try:
        (
            expected_constructor_kwargs,
            expected_policy_kwargs,
            validated_hyperparameters,
            validated_policy_kwargs,
        ) = resolve_profile_overrides(
            name,
            explicit_hyperparameters,
            explicit_policy_kwargs,
        )
    except (TypeError, ValueError) as exc:
        message = str(exc).replace(
            "algorithm.hyperparameters",
            "snapshot.algorithm.explicit_hyperparameter_overrides",
        ).replace(
            "algorithm.policy_kwargs",
            "snapshot.algorithm.explicit_policy_kwargs",
        )
        raise type(exc)(message) from exc

    if snapshot["snapshot_type"] == "resolved" and name in ("PPO", "A2C"):
        requested_rollout = algorithm[
            "requested_n_rollout_transitions_per_update"
        ]
        if requested_rollout == "algorithm_default":
            requested_rollout = ALGORITHM_PROFILES[name][
                "algorithm_default_rollout_transitions"
            ]
        n_envs = snapshot["vectorization"]["effective_n_envs"]
        expected_constructor_kwargs["n_steps"] = (
            requested_rollout + n_envs - 1
        ) // n_envs

    if explicit_hyperparameters != validated_hyperparameters:
        raise ValueError(
            "snapshot.algorithm.explicit_hyperparameter_overrides "
            "does not match the pinned profile."
        )
    if explicit_policy_kwargs != validated_policy_kwargs:
        raise ValueError(
            "snapshot.algorithm.explicit_policy_kwargs does not match "
            "the pinned profile."
        )
    if canonical_json_text(constructor_kwargs) != canonical_json_text(
        expected_constructor_kwargs
    ):
        difference = _first_json_difference(
            constructor_kwargs,
            expected_constructor_kwargs,
            "snapshot.algorithm.constructor_kwargs",
        )
        raise ValueError(
            difference
            + " does not match the pinned profile and "
            "explicit_hyperparameter_overrides."
        )
    if canonical_json_text(policy_kwargs) != canonical_json_text(
        expected_policy_kwargs
    ):
        difference = _first_json_difference(
            policy_kwargs,
            expected_policy_kwargs,
            "snapshot.algorithm.policy_kwargs",
        )
        raise ValueError(
            difference
            + " does not match the pinned profile and explicit_policy_kwargs."
        )

    environment = _require_object(snapshot["environment"], "snapshot.environment")
    training_environment = _require_object(
        environment.get("training"),
        "snapshot.environment.training",
    )
    observation_format = training_environment.get("observation_format")
    if observation_format not in ("flat", "dict"):
        raise ValueError("snapshot.environment.observation_format is unsupported.")
    expected_policy_alias = policy_alias_for_observation_format(
        observation_format
    )
    if policy_alias != expected_policy_alias:
        raise ValueError(
            "snapshot.algorithm.policy_alias does not match "
            "snapshot.environment.observation_format."
        )

    expected_buffer_kind = buffer_kind_for_algorithm(name)
    if algorithm["buffer_kind"] != expected_buffer_kind:
        raise ValueError(
            "snapshot.algorithm.buffer_kind does not match the algorithm family."
        )


def _validate_seed_and_road_provenance(snapshot):
    seeds = _require_object(snapshot["seeds"], "snapshot.seeds")
    _require_exact_fields(
        seeds,
        (
            "inputs",
            "training_road",
            "training_initial_state",
            "evaluation",
            "counter_rule",
        ),
        "snapshot.seeds",
    )
    inputs = _require_object(seeds["inputs"], "snapshot.seeds.inputs")
    _require_exact_fields(
        inputs,
        (
            "training_root_seed",
            "training_road_randomizer_seed",
            "evaluation_road_generation_seed",
            "evaluation_environment_reset_seed",
            "evaluation_stochastic_policy_action_seed",
        ),
        "snapshot.seeds.inputs",
    )
    root_seed = _require_nonnegative_integer(
        inputs["training_root_seed"],
        "snapshot.seeds.inputs.training_root_seed",
    )
    if root_seed > 2**32 - 1:
        raise ValueError(
            "snapshot.seeds.inputs.training_root_seed must be <= 4294967295."
        )
    for field_name in (
        "training_road_randomizer_seed",
        "evaluation_road_generation_seed",
        "evaluation_environment_reset_seed",
        "evaluation_stochastic_policy_action_seed",
    ):
        _require_integer(
            inputs[field_name],
            "snapshot.seeds.inputs." + field_name,
        )
    expected_evaluation_rules = evaluation_seed_derivation_rules()
    evaluation_rules = _require_object(
        seeds["evaluation"],
        "snapshot.seeds.evaluation",
    )
    difference = _first_json_difference(
        evaluation_rules,
        expected_evaluation_rules,
        "snapshot.seeds.evaluation",
    )
    if difference is not None:
        raise ValueError(difference + " is inconsistent.")
    if seeds["counter_rule"] != TRAINING_SEED_COUNTER_RULE:
        raise ValueError("snapshot.seeds.counter_rule is inconsistent.")
    road_stream = _require_object(
        seeds["training_road"],
        "snapshot.seeds.training_road",
    )
    initial_state_stream = _require_object(
        seeds["training_initial_state"],
        "snapshot.seeds.training_initial_state",
    )
    for name, stream, component_fields in (
        (
            "training_road",
            road_stream,
            (
                "sb3_reset_seed",
                "training_road_randomizer_seed",
                "reset_counter",
            ),
        ),
        (
            "training_initial_state",
            initial_state_stream,
            ("sb3_reset_seed", "reset_counter"),
        ),
    ):
        _require_exact_fields(
            stream,
            ("namespace", "components", "derived_seed"),
            "snapshot.seeds." + name,
        )
        if stream["namespace"] != name:
            raise ValueError(
                "snapshot.seeds." + name + ".namespace is inconsistent."
            )
        components = _require_object(
            stream["components"],
            "snapshot.seeds." + name + ".components",
        )
        _require_exact_fields(
            components,
            component_fields,
            "snapshot.seeds." + name + ".components",
        )

    expected_road_components = {
        "sb3_reset_seed": inputs["training_root_seed"],
        "training_road_randomizer_seed": inputs[
            "training_road_randomizer_seed"
        ],
        "reset_counter": 0,
    }
    if road_stream["components"] != expected_road_components:
        raise ValueError(
            "snapshot.seeds.training_road.components are inconsistent."
        )
    expected_road_seed = derive_seed(
        "training_road",
        expected_road_components["sb3_reset_seed"],
        expected_road_components["training_road_randomizer_seed"],
        expected_road_components["reset_counter"],
    )
    if road_stream["derived_seed"] != expected_road_seed:
        raise ValueError(
            "snapshot.seeds.training_road.derived_seed is inconsistent."
        )

    expected_state_components = {
        "sb3_reset_seed": inputs["training_root_seed"],
        "reset_counter": 0,
    }
    if initial_state_stream["components"] != expected_state_components:
        raise ValueError(
            "snapshot.seeds.training_initial_state.components are inconsistent."
        )
    expected_state_seed = derive_seed(
        "training_initial_state",
        expected_state_components["sb3_reset_seed"],
        expected_state_components["reset_counter"],
    )
    if initial_state_stream["derived_seed"] != expected_state_seed:
        raise ValueError(
            "snapshot.seeds.training_initial_state.derived_seed is inconsistent."
        )

    roads = _require_object(snapshot["roads"], "snapshot.roads")
    _require_exact_fields(
        roads,
        (
            "training_source_precedence",
            "winning_training_source",
            "fixed_train_road_spec",
            "default_training_road_spec",
            "train_randomization",
            "fixed_evaluation_road_specs",
            "random_evaluation_road_generation",
            "n_random_evaluation_roads_reused_across_evaluations",
            "n_fresh_random_evaluation_roads_per_evaluation",
            "evaluation_road_generation_seed",
        ),
        "snapshot.roads",
    )
    _require_integer(
        roads["evaluation_road_generation_seed"],
        "snapshot.roads.evaluation_road_generation_seed",
    )
    evaluation_record = _require_object(
        snapshot["evaluation"],
        "snapshot.evaluation",
    )
    evaluation_configuration = _require_object(
        evaluation_record.get("configuration"),
        "snapshot.evaluation.configuration",
    )
    for field_name in (
        "environment_reset_seed",
        "stochastic_policy_action_seed",
    ):
        if field_name not in evaluation_configuration:
            raise ValueError(
                "snapshot.evaluation.configuration."
                + field_name
                + " is required."
            )
        _require_integer(
            evaluation_configuration[field_name],
            "snapshot.evaluation.configuration." + field_name,
        )
    if (
        inputs["evaluation_road_generation_seed"]
        != roads["evaluation_road_generation_seed"]
    ):
        raise ValueError(
            "snapshot.seeds.inputs.evaluation_road_generation_seed does not "
            "match snapshot.roads.evaluation_road_generation_seed."
        )
    if (
        inputs["evaluation_environment_reset_seed"]
        != evaluation_configuration["environment_reset_seed"]
    ):
        raise ValueError(
            "snapshot.seeds.inputs.evaluation_environment_reset_seed does not "
            "match snapshot.evaluation.configuration.environment_reset_seed."
        )
    if (
        inputs["evaluation_stochastic_policy_action_seed"]
        != evaluation_configuration["stochastic_policy_action_seed"]
    ):
        raise ValueError(
            "snapshot.seeds.inputs.evaluation_stochastic_policy_action_seed "
            "does not match snapshot.evaluation.configuration."
            "stochastic_policy_action_seed."
        )
    if roads["training_source_precedence"] != list(
        TRAINING_ROAD_SOURCE_PRECEDENCE
    ):
        raise ValueError(
            "snapshot.roads.training_source_precedence is inconsistent."
        )
    randomization = _require_object(
        roads["train_randomization"],
        "snapshot.roads.train_randomization",
    )
    _require_exact_fields(
        randomization,
        (
            "controls",
            "requested_generation_config",
            "normalized_generation_config",
        ),
        "snapshot.roads.train_randomization",
    )
    controls = _require_object(
        randomization["controls"],
        "snapshot.roads.train_randomization.controls",
    )
    _require_exact_fields(
        controls,
        (
            "enabled",
            "seed",
            "reset_road_sampling_mode",
            "n_road_specs_in_reusable_pool",
        ),
        "snapshot.roads.train_randomization.controls",
    )
    requested_generation = _require_object(
        randomization["requested_generation_config"],
        "snapshot.roads.train_randomization.requested_generation_config",
    )
    normalized_generation = _require_object(
        randomization["normalized_generation_config"],
        "snapshot.roads.train_randomization.normalized_generation_config",
    )
    generation_fields = tuple(field.name for field in fields(RoadGenerationConfig))
    _require_exact_fields(
        requested_generation,
        generation_fields,
        "snapshot.roads.train_randomization.requested_generation_config",
    )
    _require_exact_fields(
        normalized_generation,
        generation_fields,
        "snapshot.roads.train_randomization.normalized_generation_config",
    )
    canonical_randomization = construct_dataclass_strict(
        TrainRandomizationConfig,
        {**requested_generation, **controls},
        "snapshot.roads.train_randomization",
    )
    validate_train_randomization_config(
        canonical_randomization,
        path="snapshot.roads.train_randomization.controls",
    )
    if inputs["training_road_randomizer_seed"] != controls.get("seed"):
        raise ValueError(
            "snapshot.seeds.inputs.training_road_randomizer_seed does not "
            "match snapshot.roads.train_randomization.controls.seed."
        )
    expected_source = (
        "fixed_train_road_spec"
        if roads["fixed_train_road_spec"] is not None
        else "train_randomization"
        if controls.get("enabled") is True
        else "default_training_road"
    )
    if roads["winning_training_source"] != expected_source:
        raise ValueError(
            "snapshot.roads.winning_training_source does not match precedence."
        )
    try:
        expected_normalized = validate_json_value(
            normalize_random_road_generation_config(
                copy.deepcopy(requested_generation)
            ),
            path=(
                "snapshot.roads.train_randomization."
                "normalized_generation_config"
            ),
        )
    except (TypeError, ValueError, KeyError) as exc:
        raise type(exc)(
            "snapshot.roads.train_randomization.requested_generation_config: "
            + str(exc)
        ) from exc
    difference = _first_json_difference(
        normalized_generation,
        expected_normalized,
        "snapshot.roads.train_randomization.normalized_generation_config",
    )
    if difference is not None:
        raise ValueError(
            difference + " does not match requested_generation_config."
        )

    evaluation_generation = _require_object(
        roads.get("random_evaluation_road_generation"),
        "snapshot.roads.random_evaluation_road_generation",
    )
    _require_exact_fields(
        evaluation_generation,
        ("requested_generation_config", "normalized_generation_config"),
        "snapshot.roads.random_evaluation_road_generation",
    )
    requested_evaluation_generation = _require_object(
        evaluation_generation["requested_generation_config"],
        "snapshot.roads.random_evaluation_road_generation."
        "requested_generation_config",
    )
    normalized_evaluation_generation = _require_object(
        evaluation_generation["normalized_generation_config"],
        "snapshot.roads.random_evaluation_road_generation."
        "normalized_generation_config",
    )
    _require_exact_fields(
        requested_evaluation_generation,
        generation_fields,
        "snapshot.roads.random_evaluation_road_generation."
        "requested_generation_config",
    )
    _require_exact_fields(
        normalized_evaluation_generation,
        generation_fields,
        "snapshot.roads.random_evaluation_road_generation."
        "normalized_generation_config",
    )
    try:
        expected_evaluation_normalized = validate_json_value(
            normalize_random_road_generation_config(
                copy.deepcopy(requested_evaluation_generation)
            ),
            path=(
                "snapshot.roads.random_evaluation_road_generation."
                "normalized_generation_config"
            ),
        )
    except (TypeError, ValueError, KeyError) as exc:
        raise type(exc)(
            "snapshot.roads.random_evaluation_road_generation."
            "requested_generation_config: "
            + str(exc)
        ) from exc
    difference = _first_json_difference(
        normalized_evaluation_generation,
        expected_evaluation_normalized,
        "snapshot.roads.random_evaluation_road_generation."
        "normalized_generation_config",
    )
    if difference is not None:
        raise ValueError(
            difference + " does not match requested_generation_config."
        )

    target_line_config = snapshot["environment"][
        "public_constructor_template"
    ]["target_line_config"]
    if expected_source == "train_randomization":
        validate_random_road_source_for_target(
            requested_generation,
            normalized_generation,
            target_line_config,
            expected_road_seed,
            "snapshot.roads.train_randomization",
            requested_generation_source=(
                "snapshot.roads.train_randomization."
                "requested_generation_config"
            ),
        )
    random_evaluation_counts = (
        roads["n_random_evaluation_roads_reused_across_evaluations"],
        roads["n_fresh_random_evaluation_roads_per_evaluation"],
    )
    if (
        all(
            type(count) is int and count >= 0
            for count in random_evaluation_counts
        )
        and sum(random_evaluation_counts) > 0
    ):
        validate_random_road_source_for_target(
            requested_evaluation_generation,
            normalized_evaluation_generation,
            target_line_config,
            derive_seed(
                "evaluation_reused_road",
                roads["evaluation_road_generation_seed"],
                0,
            ),
            "snapshot.roads.random_evaluation_road_generation",
            requested_generation_source=(
                "snapshot.roads.random_evaluation_road_generation."
                "requested_generation_config"
            ),
        )
    if roads["fixed_train_road_spec"] is not None:
        validate_road_for_target(
            roads["fixed_train_road_spec"],
            target_line_config,
            "snapshot.roads.fixed_train_road_spec",
        )
    expected_default_road = default_training_road_spec()
    difference = _first_json_difference(
        roads["default_training_road_spec"],
        expected_default_road,
        "snapshot.roads.default_training_road_spec",
    )
    if difference is not None:
        raise ValueError(
            difference + " does not match the resolver-owned default Road."
        )
    validate_road_for_target(
        roads["default_training_road_spec"],
        target_line_config,
        "snapshot.roads.default_training_road_spec",
    )
    fixed_evaluation = roads["fixed_evaluation_road_specs"]
    if fixed_evaluation is not None:
        if type(fixed_evaluation) is not list:
            raise TypeError(
                "snapshot.roads.fixed_evaluation_road_specs must be a list or null."
            )
        for index, road_spec in enumerate(fixed_evaluation):
            validate_road_for_target(
                road_spec,
                target_line_config,
                "snapshot.roads.fixed_evaluation_road_specs["
                + str(index)
                + "]",
            )


def validate_preconstruction_snapshot(snapshot):
    """Validate and detach the internal preconstruction record."""

    detached = validate_json_value(snapshot, path="snapshot")
    detached = _require_object(detached, "snapshot")
    _validate_snapshot_envelope(
        detached,
        snapshot_type="resolved_build_internal",
    )
    _validate_rollout_arithmetic(detached)
    _validate_environment_and_reward_provenance(detached)
    _validate_seed_and_road_provenance(detached)
    _validate_evaluation_artifact_and_logging_sections(detached)
    _validate_wrapper_provenance(detached)
    return copy.deepcopy(detached)


def _validate_bound(value, path):
    if type(value) is str:
        if value not in _BOUND_TOKENS:
            raise ValueError(
                path
                + " must be a finite number, negative_infinity, or positive_infinity."
            )
        return value
    if type(value) not in (int, float) or isinstance(value, bool):
        raise TypeError(path + " must be a finite number or canonical infinity token.")
    if type(value) is float and not math.isfinite(value):
        raise ValueError(path + " must be finite or use a canonical infinity token.")
    return value


def _bound_order_value(value):
    if value == "negative_infinity":
        return -math.inf
    if value == "positive_infinity":
        return math.inf
    return value


def _validate_encoded_gym_space(space, path):
    space = _require_object(space, path)
    _require_fields(space, ("type",), path)
    if space["type"] == "Box":
        expected_keys = {"type", "shape", "dtype", "low", "high"}
        if set(space) != expected_keys:
            raise ValueError(path + " Box encoding has unsupported or missing fields.")
        shape = space["shape"]
        if type(shape) is not list or any(
            type(dimension) is not int or dimension < 0
            for dimension in shape
        ):
            raise TypeError(path + ".shape must be a list of non-negative integers.")
        dtype = space["dtype"]
        if type(dtype) is not str:
            raise TypeError(path + ".dtype must be a string.")
        try:
            parsed_dtype = np.dtype(dtype)
        except TypeError as exc:
            raise ValueError(path + ".dtype is not supported: " + dtype) from exc
        if parsed_dtype.kind not in ("b", "i", "u", "f"):
            raise ValueError(
                path + ".dtype is not supported for a Gymnasium Box: " + dtype
            )
        if str(parsed_dtype) != dtype:
            raise ValueError(path + ".dtype is not canonical: " + dtype)
        expected_count = math.prod(shape)
        decoded_bounds = {}
        for name in ("low", "high"):
            bounds = space[name]
            if type(bounds) is not list:
                raise TypeError(path + "." + name + " must be a list.")
            if len(bounds) != expected_count:
                raise ValueError(path + "." + name + " does not match shape.")
            decoded_bounds[name] = []
            for index, value in enumerate(bounds):
                decoded_bounds[name].append(
                    _validate_bound(
                        value,
                        path + "." + name + "[" + str(index) + "]",
                    )
                )
        for index, (low, high) in enumerate(
            zip(decoded_bounds["low"], decoded_bounds["high"])
        ):
            if _bound_order_value(low) > _bound_order_value(high):
                raise ValueError(
                    path
                    + ".bounds["
                    + str(index)
                    + "] has low greater than high."
                )
        all_bounds = decoded_bounds["low"] + decoded_bounds["high"]
        if parsed_dtype.kind == "b":
            if any(
                type(bound) is not int or bound not in (0, 1)
                for bound in all_bounds
            ):
                raise ValueError(
                    path + " bounds are not representable by dtype " + dtype + "."
                )
        elif parsed_dtype.kind in ("i", "u"):
            limits = np.iinfo(parsed_dtype)
            if any(
                type(bound) is not int
                or bound < limits.min
                or bound > limits.max
                for bound in all_bounds
            ):
                raise ValueError(
                    path + " bounds are not representable by dtype " + dtype + "."
                )
        else:
            limits = np.finfo(parsed_dtype)
            minimum = float(limits.min)
            maximum = float(limits.max)
            if any(
                type(bound) is not str
                and (bound < minimum or bound > maximum)
                for bound in all_bounds
            ):
                raise ValueError(
                    path + " bounds are not representable by dtype " + dtype + "."
                )
        return
    if space["type"] == "Dict":
        if set(space) != {"type", "spaces"}:
            raise ValueError(path + " Dict encoding has unsupported or missing fields.")
        children = _require_object(space["spaces"], path + ".spaces")
        for key, child in children.items():
            _validate_encoded_gym_space(child, path + ".spaces." + key)
        return
    raise ValueError(path + ".type is not a supported Gymnasium space type.")


def _qualified_class_name(instance):
    cls = type(instance)
    return cls.__module__ + "." + cls.__qualname__


def _qualified_type_name(cls):
    return cls.__module__ + "." + cls.__qualname__


def _activation_name(activation_class):
    import torch

    names = {
        torch.nn.ReLU: "relu",
        torch.nn.Tanh: "tanh",
        torch.nn.ELU: "elu",
        torch.nn.LeakyReLU: "leaky_relu",
    }
    if activation_class not in names:
        raise ValueError(
            "Constructed model policy exposes an unsupported activation class."
        )
    return names[activation_class]


def _runtime_versions():
    import stable_baselines3
    import torch

    return {
        "dreamgym": str(version("DreamGym")),
        "gymnasium": str(gym.__version__),
        "stable_baselines3": str(stable_baselines3.__version__),
        "python": str(platform.python_version()),
        "numpy": str(np.__version__),
        "torch": str(torch.__version__),
    }


def _wrapper_names_inner_to_outer(env):
    vector_layers = []
    current = env
    seen = set()
    while id(current) not in seen:
        seen.add(id(current))
        vector_layers.append(type(current).__name__)
        nested = getattr(current, "venv", None)
        if nested is not None:
            current = nested
            continue
        members = getattr(current, "envs", None)
        if members:
            current = members[0]
        else:
            current = None
        break

    gym_layers = []
    seen.clear()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        gym_layers.append(type(current).__name__)
        current = getattr(current, "env", None)
    if gym_layers:
        return list(reversed(gym_layers)) + list(reversed(vector_layers))
    return list(reversed(vector_layers))


def _finalized_wrapper_stack(snapshot, env):
    observed = _wrapper_names_inner_to_outer(env)
    expected = snapshot["wrappers"]["exact_inner_to_outer"]
    if expected[-1:] == ["SubprocVecEnv"]:
        if observed == ["SubprocVecEnv"]:
            return copy.deepcopy(expected)
        if observed == ["SubprocVecEnv", "VecMonitor"]:
            return copy.deepcopy(expected) + ["VecMonitor"]
    return observed


def _runtime_model_snapshot(build, env, model):
    policy = getattr(model, "policy", None)
    if policy is None:
        raise ValueError("Constructed model does not expose policy metadata.")
    buffer = getattr(model, "rollout_buffer", None)
    if buffer is None:
        buffer = getattr(model, "replay_buffer", None)
    if buffer is None:
        raise ValueError("Constructed model does not expose buffer metadata.")

    extractor = getattr(policy, "features_extractor", None)
    if extractor is None:
        actor = getattr(policy, "actor", None)
        extractor = getattr(actor, "features_extractor", None)
    if extractor is None:
        raise ValueError(
            "Constructed model policy does not expose observed feature extractor "
            "metadata."
        )
    extractor_class = _qualified_class_name(extractor)

    device = getattr(model, "device", None)
    if device is None or not str(device):
        raise ValueError("Constructed model does not expose observed device metadata.")

    net_arch = getattr(policy, "net_arch", None)
    if net_arch is None:
        raise ValueError(
            "Constructed model policy does not expose observed net_arch metadata."
        )
    activation_class = getattr(policy, "activation_fn", None)
    if activation_class is None:
        raise ValueError(
            "Constructed model policy does not expose observed activation metadata."
        )

    constructor = build.algorithm.constructor_kwargs
    n_steps = int(constructor.get("n_steps", 1))
    buffer_kwargs = {}
    if build.algorithm.buffer_kind == "replay" and n_steps > 1:
        observed_n_steps = getattr(buffer, "n_steps", None)
        observed_gamma = getattr(buffer, "gamma", None)
        if observed_n_steps is None or observed_gamma is None:
            raise ValueError(
                "Constructed n-step replay buffer does not expose buffer kwargs."
            )
        buffer_kwargs = {
            "n_steps": int(observed_n_steps),
            "gamma": float(observed_gamma),
        }

    if build.algorithm.name in ("PPO", "A2C"):
        critic_count = 1
    else:
        critic = getattr(policy, "critic", None)
        critic_count = getattr(critic, "n_critics", None)
        if type(critic_count) is not int or critic_count <= 0:
            raise ValueError(
                "Constructed model policy does not expose observed critic metadata."
            )

    runtime = {
        "policy_alias": build.algorithm.policy_alias,
        "policy_class": _qualified_class_name(policy),
        "feature_extractor_class": extractor_class,
        "activation_fn": _activation_name(activation_class),
        "activation_class": _qualified_type_name(activation_class),
        "net_arch": validate_json_value(net_arch, path="runtime_model.net_arch"),
        "buffer_class": _qualified_class_name(buffer),
        "buffer_kwargs": buffer_kwargs,
        "critic_count": critic_count,
        "device": str(device),
    }
    if build.algorithm.name == "DDPG":
        for field in _DDPG_RUNTIME_FIELDS:
            value = getattr(model, field, None)
            if type(value) not in (int, float) or isinstance(value, bool):
                raise ValueError(
                    "Constructed DDPG model does not expose runtime_model."
                    + field
                    + "."
                )
            runtime[field] = value
    return runtime


def _expected_buffer_metadata(algorithm, observation_is_dict):
    name = algorithm["name"]
    if buffer_kind_for_algorithm(name) == "rollout":
        key = "rollout_dict" if observation_is_dict else "rollout_flat"
        return _BUFFER_CLASSES[key], {}
    n_steps = int(algorithm["constructor_kwargs"]["n_steps"])
    if observation_is_dict:
        if n_steps > 1:
            raise ValueError(
                "snapshot.runtime_model.buffer_class is incompatible with "
                "dict observations and n-step replay."
            )
        return _BUFFER_CLASSES["replay_dict"], {}
    if n_steps > 1:
        return _BUFFER_CLASSES["replay_n_step"], {
            "n_steps": n_steps,
            "gamma": float(algorithm["constructor_kwargs"]["gamma"]),
        }
    return _BUFFER_CLASSES["replay_flat"], {}


def _validate_runtime_model(snapshot, runtime_model, spaces):
    algorithm = snapshot["algorithm"]
    name = algorithm["name"]
    observation_is_dict = spaces["observation"]["type"] == "Dict"
    expected_fields = list(_RUNTIME_MODEL_FIELDS)
    if name == "DDPG":
        expected_fields.extend(_DDPG_RUNTIME_FIELDS)
    _require_exact_fields(
        runtime_model,
        tuple(expected_fields),
        "snapshot.runtime_model",
    )

    expected_alias = policy_alias_for_observation_format(
        "dict" if observation_is_dict else "flat"
    )
    expected_buffer_class, expected_buffer_kwargs = _expected_buffer_metadata(
        algorithm, observation_is_dict
    )
    expected = {
        "policy_alias": expected_alias,
        "policy_class": _POLICY_CLASSES[(name, expected_alias)],
        "feature_extractor_class": (
            _COMBINED_EXTRACTOR if observation_is_dict else _FLATTEN_EXTRACTOR
        ),
        "activation_fn": algorithm["policy_kwargs"]["activation_fn"],
        "activation_class": _ACTIVATION_CLASSES[
            algorithm["policy_kwargs"]["activation_fn"]
        ],
        "net_arch": algorithm["policy_kwargs"]["net_arch"],
        "buffer_class": expected_buffer_class,
        "buffer_kwargs": expected_buffer_kwargs,
        "critic_count": 1 if name in ("PPO", "A2C", "DDPG") else 2,
    }
    if name == "DDPG":
        expected.update({
            "policy_delay": 1,
            "target_policy_noise": 0.1,
            "target_noise_clip": 0.0,
        })
    for field, expected_value in expected.items():
        difference = _first_json_difference(
            runtime_model[field],
            expected_value,
            "snapshot.runtime_model." + field,
        )
        if difference is not None:
            raise ValueError(
                difference + " does not match the resolved runtime model."
            )
    device = runtime_model["device"]
    if type(device) is not str or not device:
        raise ValueError(
            "snapshot.runtime_model.device must be a non-empty string."
        )
    import torch

    try:
        canonical_device = str(torch.device(device))
    except (RuntimeError, ValueError) as exc:
        raise ValueError(
            "snapshot.runtime_model.device is not a canonical torch device."
        ) from exc
    if device != canonical_device:
        raise ValueError(
            "snapshot.runtime_model.device is not a canonical torch device."
        )
    requested_device = algorithm["constructor_kwargs"]["device"]
    if requested_device != "auto":
        try:
            expected_device = str(torch.device(requested_device))
        except (RuntimeError, ValueError) as exc:
            raise ValueError(
                "snapshot.algorithm.constructor_kwargs.device is not a "
                "canonical torch device."
            ) from exc
        if device != expected_device:
            raise ValueError(
                "snapshot.runtime_model.device does not match "
                "snapshot.algorithm.constructor_kwargs.device."
            )


def _vector_member_attribute_values(env, public_name, expected_count):
    try:
        values = env.get_attr(public_name)
    except AttributeError as exc:
        raise ValueError(
            "Constructed environment does not expose " + public_name + "."
        ) from exc
    if type(values) is not list or len(values) != expected_count:
        raise ValueError(
            "Constructed environment "
            + public_name
            + " must contain exactly one value for each of the "
            + str(expected_count)
            + " vectorized environments."
        )
    return values


def finalize_resolved_training_config(
    build,
    env,
    model,
    *,
    final_animation_road_case=None,
):
    """Finalize a build with constructed runtime metadata without mutating it."""

    snapshot = preconstruction_snapshot(build)
    snapshot["snapshot_type"] = "resolved"
    snapshot["algorithm"]["constructor_kwargs"] = (
        effective_algorithm_constructor_kwargs(build.algorithm)
    )
    if final_animation_road_case is not None and not isinstance(
        final_animation_road_case,
        EvaluationRoadCase,
    ):
        raise TypeError(
            "final_animation_road_case must be an EvaluationRoadCase or null."
        )
    snapshot["artifacts"]["final_policy_animation"] = (
        None
        if final_animation_road_case is None
        else final_animation_road_case.to_dict()
    )
    snapshot["versions"] = _runtime_versions()
    expected_member_count = snapshot["vectorization"]["effective_n_envs"]
    environment_authority = snapshot["environment"]
    expected_requested_action_interface = environment_authority[
        "public_constructor_template"
    ]["internal_policy_config"]["action_interface"]
    expected_effective_action_interface = environment_authority[
        "effective_action_interface"
    ]
    for public_name, expected in (
        (
            "requested_action_interface",
            expected_requested_action_interface,
        ),
        (
            "effective_action_interface",
            expected_effective_action_interface,
        ),
    ):
        observed_values = _vector_member_attribute_values(
            env,
            public_name,
            expected_member_count,
        )
        if any(
            type(value) is not str or value != expected
            for value in observed_values
        ):
            raise ValueError(
                "Constructed environment "
                + public_name
                + " does not match the resolved environment authority for "
                "every vectorized environment."
            )
    observed_name_records = _vector_member_attribute_values(
        env,
        "flat_observation_names",
        expected_member_count,
    )
    flat_observation_names = observed_name_records[0]
    if (
        type(flat_observation_names) is not tuple
        or not flat_observation_names
        or any(type(name) is not str or not name for name in flat_observation_names)
    ):
        raise ValueError(
            "Constructed environment flat_observation_names must be a "
            "non-empty tuple of non-empty strings."
        )
    if any(
        type(names) is not tuple or names != flat_observation_names
        for names in observed_name_records[1:]
    ):
        raise ValueError(
            "Constructed environments must expose identical "
            "flat_observation_names in the same order."
        )
    snapshot["spaces"] = {
        "observation": encode_gym_space(env.observation_space),
        "action": encode_gym_space(env.action_space),
        "flat_observation_names": list(flat_observation_names),
    }
    snapshot["runtime_model"] = _runtime_model_snapshot(build, env, model)
    for name in ("observation", "action"):
        model_space = getattr(model, name + "_space", None)
        if model_space is None:
            raise ValueError(
                "Constructed model does not expose observed " + name + " space."
            )
        encoded_model_space = encode_gym_space(model_space)
        difference = _first_json_difference(
            encoded_model_space,
            snapshot["spaces"][name],
            "model." + name + "_space",
        )
        if difference is not None:
            raise ValueError(
                difference + " does not match the constructed environment."
            )
    snapshot["wrappers"] = {
        "exact_inner_to_outer": _finalized_wrapper_stack(snapshot, env),
    }
    validated = validate_resolved_snapshot(snapshot)
    return ResolvedTrainingConfig(build=build, snapshot=validated)


def validate_resolved_snapshot(snapshot):
    """Validate and detach a finalized schema-2/resolver-v3 snapshot."""

    detached = validate_json_value(snapshot, path="snapshot")
    detached = _require_object(detached, "snapshot")
    _validate_snapshot_envelope(detached, snapshot_type="resolved")
    _validate_rollout_arithmetic(detached)
    _validate_environment_and_reward_provenance(detached)
    _validate_seed_and_road_provenance(detached)
    _validate_evaluation_artifact_and_logging_sections(detached)
    _validate_wrapper_provenance(detached)
    _require_fields(
        detached,
        ("versions", "spaces", "runtime_model", "wrappers"),
        "snapshot",
    )
    versions = _require_object(detached["versions"], "snapshot.versions")
    _require_exact_fields(
        versions,
        ("dreamgym", "gymnasium", "stable_baselines3", "python", "numpy", "torch"),
        "snapshot.versions",
    )
    for name, value in versions.items():
        if type(value) is not str or not value:
            raise ValueError("snapshot.versions." + name + " must be a non-empty string.")
    spaces = _require_object(detached["spaces"], "snapshot.spaces")
    _require_exact_fields(
        spaces,
        ("observation", "action", "flat_observation_names"),
        "snapshot.spaces",
    )
    _validate_encoded_gym_space(spaces["observation"], "snapshot.spaces.observation")
    _validate_encoded_gym_space(spaces["action"], "snapshot.spaces.action")
    flat_observation_names = spaces["flat_observation_names"]
    if (
        type(flat_observation_names) is not list
        or not flat_observation_names
        or any(type(name) is not str or not name for name in flat_observation_names)
    ):
        raise ValueError(
            "snapshot.spaces.flat_observation_names must be a non-empty list "
            "of non-empty strings."
        )
    observation_config = detached["environment"][
        "public_constructor_template"
    ]["observation_config"]
    expected_observation_names = [
        record.spec.name
        for record in compile_observation_records(observation_config)
        if record.destination == "observation"
    ] or ["_empty_observation"]
    if flat_observation_names != expected_observation_names:
        raise ValueError(
            "snapshot.spaces.flat_observation_names does not match the "
            "canonical observation configuration and order."
        )
    runtime_model = _require_object(
        detached["runtime_model"],
        "snapshot.runtime_model",
    )
    _validate_runtime_model(detached, runtime_model, spaces)
    return copy.deepcopy(detached)


def validate_snapshot(snapshot):
    """Strictly dispatch a plain requested or finalized resolved snapshot."""

    detached = validate_json_value(snapshot, path="snapshot")
    detached = _require_object(detached, "snapshot")
    _require_fields(
        detached,
        ("config_kind", "schema_version", "snapshot_type"),
        "snapshot",
    )
    snapshot_type = detached["snapshot_type"]
    if snapshot_type == "requested":
        return requested_snapshot(config_from_dict(detached))
    if snapshot_type == "resolved":
        return validate_resolved_snapshot(detached)
    if snapshot_type == "resolved_build_internal":
        raise ValueError(
            "snapshot_type resolved_build_internal is an internal assembly record "
            "and is not loadable."
        )
    raise ValueError(
        "snapshot.snapshot_type is unsupported; expected requested or resolved."
    )


def validate_saved_model_snapshot(snapshot):
    """Accept only the finalized schema-2/resolver-v3 saved-model envelope."""

    if type(snapshot) is not dict:
        raise TypeError("Saved-model snapshot must be an object.")
    required = ("config_kind", "schema_version", "snapshot_type")
    missing = sorted(set(required) - set(snapshot))
    if missing:
        raise ValueError(
            "Saved-model snapshot envelope is malformed; snapshot."
            + missing[0]
            + " is required."
        )
    if (
        type(snapshot["config_kind"]) is not str
        or snapshot["config_kind"] != CONFIG_KIND
    ):
        raise ValueError(
            _unsupported_version_message(
                "config_kind",
                snapshot["config_kind"],
                CONFIG_KIND,
            )
        )
    if (
        type(snapshot["schema_version"]) is not int
        or snapshot["schema_version"] != SCHEMA_VERSION
    ):
        raise ValueError(
            _unsupported_version_message(
                "schema_version",
                snapshot["schema_version"],
                SCHEMA_VERSION,
            )
        )
    if (
        type(snapshot["snapshot_type"]) is not str
        or snapshot["snapshot_type"] != "resolved"
    ):
        raise ValueError(
            "Saved-model reconstruction requires snapshot_type resolved; "
            "encountered "
            + repr(snapshot["snapshot_type"])
            + "."
        )
    if "resolver_version" not in snapshot:
        raise ValueError(
            "Saved-model snapshot envelope is malformed; "
            "snapshot.resolver_version is required."
        )
    if snapshot["resolver_version"] != RESOLVER_VERSION:
        raise ValueError(
            _unsupported_version_message(
                "resolver_version",
                snapshot["resolver_version"],
                RESOLVER_VERSION,
            )
        )
    _require_exact_fields(
        snapshot,
        _snapshot_envelope_fields("resolved"),
        "snapshot",
    )
    if snapshot["algorithm_profile_version"] != ALGORITHM_PROFILE_VERSION:
        raise ValueError(
            _unsupported_version_message(
                "algorithm_profile_version",
                snapshot["algorithm_profile_version"],
                ALGORITHM_PROFILE_VERSION,
            )
        )
    if snapshot["seed_derivation_version"] != seed_derivation_version():
        raise ValueError(
            _unsupported_version_message(
                "seed_derivation_version",
                snapshot["seed_derivation_version"],
                seed_derivation_version(),
            )
        )
    digest = snapshot["requested_config_digest"]
    if type(digest) is not str or _DIGEST_PATTERN.fullmatch(digest) is None:
        raise ValueError(
            "snapshot.requested_config_digest must be exactly 64 lowercase "
            "hexadecimal characters."
        )
    if (
        type(snapshot["experiment_name"]) is not str
        or not snapshot["experiment_name"]
    ):
        raise ValueError("snapshot.experiment_name must be a non-empty string.")
    requested_transitions = snapshot["requested_total_environment_transitions"]
    if type(requested_transitions) is not int or requested_transitions <= 0:
        raise ValueError(
            "snapshot.requested_total_environment_transitions must be positive."
        )
    if type(snapshot["warnings"]) is not list:
        raise TypeError("snapshot.warnings must be a list.")
    for field in (
        "vectorization",
        "algorithm",
        "environment",
        "roads",
        "seeds",
        "reward",
        "evaluation",
        "artifacts",
        "logging",
        "wrappers",
        "versions",
        "spaces",
        "runtime_model",
    ):
        _require_object(snapshot[field], "snapshot." + field)
    return validate_resolved_snapshot(snapshot)


def load_snapshot_json(path):
    """Read strict JSON and dispatch only supported training snapshot forms."""

    data = parse_strict_json_object(Path(path).read_text(encoding="utf-8"))
    return validate_snapshot(data)
