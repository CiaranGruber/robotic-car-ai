"""Small SB3 callbacks for progress and scheduled evaluation."""

from __future__ import annotations

import csv
from pathlib import Path
import time

from dreamgym.training.autonomous_driving.artifacts import run_artifact_paths
from dreamgym.training.autonomous_driving.evaluation import (
    evaluate_model_on_road_specs,
    evaluation_road_specs,
    save_policy_animation,
    write_metrics_csv,
)
from dreamgym.training.autonomous_driving.resolution import ResolvedTrainingConfig
from dreamgym.visualization.autonomous_driving import plot_eval_summary, plot_training_progress


def _format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


class CsvProgressCallback:
    def __init__(
        self,
        *,
        run_dir: str | Path,
        requested_total_environment_transitions: int,
        progress_interval_steps: int,
        print_progress_to_console: bool,
    ):
        from stable_baselines3.common.callbacks import BaseCallback

        class _Callback(BaseCallback):
            def __init__(self, outer):
                super().__init__()
                self.outer = outer

            def _on_training_start(self) -> None:
                self.outer._on_training_start(self)

            def _on_step(self) -> bool:
                return self.outer._on_step(self)

            def _on_training_end(self) -> None:
                self.outer._on_training_end(self)

        self.callback = _Callback(self)
        self.run_dir = Path(run_dir)
        self.paths = run_artifact_paths(self.run_dir)
        self.requested_total_environment_transitions = int(
            requested_total_environment_transitions
        )
        self.progress_interval_steps = int(progress_interval_steps)
        self.print_progress_to_console = bool(print_progress_to_console)
        self.progress_path = self.paths.progress_csv
        self._start_time = 0.0
        self._next_emit_step = 0

    def _on_training_start(self, callback) -> None:
        self._start_time = time.perf_counter()
        self._next_emit_step = (
            self.progress_interval_steps
            if self.progress_interval_steps > 0
            else 0
        )
        self.progress_path.parent.mkdir(parents=True, exist_ok=True)
        with self.progress_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=["timesteps", "percent", "elapsed_s", "eta_s", "steps_per_s"],
            )
            writer.writeheader()

    def _write_progress_row(self, callback) -> None:
        elapsed_s = time.perf_counter() - self._start_time
        timesteps = int(callback.num_timesteps)
        steps_per_s = timesteps / elapsed_s if elapsed_s > 0.0 else 0.0
        remaining = max(
            0,
            self.requested_total_environment_transitions - timesteps,
        )
        eta_s = remaining / steps_per_s if steps_per_s > 0.0 else 0.0
        percent = (
            100.0
            * min(timesteps, self.requested_total_environment_transitions)
            / max(1, self.requested_total_environment_transitions)
        )
        with self.progress_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=["timesteps", "percent", "elapsed_s", "eta_s", "steps_per_s"],
            )
            writer.writerow({
                "timesteps": timesteps,
                "percent": f"{percent:.2f}",
                "elapsed_s": f"{elapsed_s:.3f}",
                "eta_s": f"{eta_s:.3f}",
                "steps_per_s": f"{steps_per_s:.3f}",
            })
        if self.print_progress_to_console:
            print(
                f"{timesteps}/{self.requested_total_environment_transitions} "
                f"{percent:.1f}% elapsed={_format_duration(elapsed_s)} "
                f"eta={_format_duration(eta_s)}"
            )

    def _on_step(self, callback) -> bool:
        if self.progress_interval_steps <= 0:
            return True
        current = int(callback.num_timesteps)
        upper = min(current, self.requested_total_environment_transitions)
        while self._next_emit_step and self._next_emit_step <= upper:
            self._write_progress_row(callback)
            self._next_emit_step += self.progress_interval_steps
        return True

    def _on_training_end(self, callback) -> None:
        self._write_progress_row(callback)


class ScheduledEvaluationCallback:
    def __init__(
        self,
        *,
        config: ResolvedTrainingConfig,
        run_dir: str | Path,
    ):
        from stable_baselines3.common.callbacks import BaseCallback

        class _Callback(BaseCallback):
            def __init__(self, outer):
                super().__init__()
                self.outer = outer

            def _on_training_start(self) -> None:
                self.outer._on_training_start(self)

            def _on_step(self) -> bool:
                return self.outer._on_step(self)

        self.callback = _Callback(self)
        self.config = config
        self.run_dir = Path(run_dir)
        self.paths = run_artifact_paths(self.run_dir)
        self.interval_steps = int(config.build.evaluation["interval_steps"])
        self.requested_total_environment_transitions = int(
            config.build.requested_total_environment_transitions
        )
        self._next_scheduled_step = (
            self.interval_steps if self.interval_steps > 0 else 0
        )
        self._serviced_scheduled_steps: list[int] = []

    @property
    def serviced_scheduled_steps(self) -> tuple[int, ...]:
        return tuple(self._serviced_scheduled_steps)

    def _on_training_start(self, callback) -> None:
        self.paths.eval_metrics_csv.parent.mkdir(parents=True, exist_ok=True)
        if self.config.build.artifacts["save_model_at_evaluations"]:
            self.paths.final_model.parent.mkdir(parents=True, exist_ok=True)
        if self.config.build.artifacts["save_plots_at_evaluations"]:
            self.paths.final_plot.parent.mkdir(parents=True, exist_ok=True)

    def _on_step(self, callback) -> bool:
        current = int(callback.num_timesteps)
        upper = min(current, self.requested_total_environment_transitions)
        while (
            self._next_scheduled_step
            and self._next_scheduled_step <= upper
        ):
            scheduled = self._next_scheduled_step
            self._service_scheduled_evaluation(callback, scheduled)
            self._serviced_scheduled_steps.append(scheduled)
            self._next_scheduled_step += self.interval_steps
        return True

    def _service_scheduled_evaluation(self, callback, scheduled_step: int) -> None:
        actual_step = int(callback.num_timesteps)
        roads = evaluation_road_specs(
            self.config.build,
            evaluation_execution_context="during_training",
            scheduled_evaluation_step=scheduled_step,
        )
        rows = evaluate_model_on_road_specs(
            model=callback.model,
            config=self.config,
            road_specs=roads,
            evaluation_execution_context="during_training",
            scheduled_evaluation_step=scheduled_step,
            actual_training_step=actual_step,
            policy_name=None,
            model_stem=None,
        )
        write_metrics_csv(rows, self.paths.eval_metrics_csv, append=True)

        if self.config.build.artifacts["save_model_at_evaluations"]:
            callback.model.save(str(self.paths.model_at_evaluation(scheduled_step)))
        if self.config.build.artifacts["save_plots_at_evaluations"]:
            plot_eval_summary(
                rows,
                self.paths.evaluation_road_summary_at(scheduled_step),
            )
            plot_training_progress(
                self.paths.progress_csv,
                self.paths.training_progress_at(scheduled_step),
            )
        animation_steps = self.config.build.artifacts["animation_evaluation_steps"]
        save_animation = (
            animation_steps == "all"
            or scheduled_step in animation_steps
        )
        if save_animation and roads:
            road_index = int(
                self.config.build.artifacts["animation_evaluation_road_index"]
            )
            road_case = roads[road_index]
            save_policy_animation(
                callback.model,
                self.config,
                road_case,
                self.paths.scheduled_animation(
                    scheduled_step,
                    road_case.road_name,
                ),
            )
