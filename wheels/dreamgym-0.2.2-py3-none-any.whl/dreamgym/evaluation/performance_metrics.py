from __future__ import annotations

import csv
from dataclasses import dataclass
from enum import Enum
import math
from pathlib import Path
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np


class MetricDirection(str, Enum):
    SMALLER = "smaller"
    BIGGER = "bigger"
    TARGET = "target"
    CONSTRAINT = "constraint"
    INFORMATIONAL = "informational"


MetricFunction = Callable[[Mapping[str, object]], float]


class MetricEvaluationError(RuntimeError):
    """A named performance metric failed while computing its scalar."""

    def __init__(self, metric_name: str):
        self.metric_name = metric_name
        super().__init__(
            "Performance metric " + repr(metric_name) + " failed."
        )


@dataclass(frozen=True)
class AggregationSpec:
    statistics: tuple[str, ...] = (
        "mean",
        "median",
        "std",
        "min",
        "max",
        "p05",
        "p25",
        "p75",
        "p95",
        "worst_case",
        "ci95_low",
        "ci95_high",
    )
    percentiles: tuple[float, ...] = (5.0, 25.0, 75.0, 95.0)


@dataclass(frozen=True)
class PerformanceMetric:
    name: str
    display_name: str
    unit: str
    direction: MetricDirection | str
    requirement_group: str
    required_fields: tuple[str, ...]
    equation: str
    description: str
    justification: str
    function: MetricFunction
    primary_aggregate: str = "mean"
    threshold: float | None = None

    def __post_init__(self):
        direction = self.direction
        if isinstance(direction, MetricDirection):
            object.__setattr__(self, "direction", direction)
        else:
            object.__setattr__(self, "direction", MetricDirection(str(direction)))
        object.__setattr__(self, "required_fields", tuple(self.required_fields))
        if not self.name:
            raise ValueError("PerformanceMetric.name must be non-empty.")
        if not self.display_name:
            raise ValueError("PerformanceMetric.display_name must be non-empty.")
        if self.primary_aggregate not in AggregationSpec().statistics:
            raise ValueError("Unknown primary aggregate: " + str(self.primary_aggregate))


@dataclass(frozen=True)
class PolicySpec:
    name: str
    policy: object

    def __post_init__(self):
        if not self.name:
            raise ValueError("PolicySpec.name must be non-empty.")


@dataclass(frozen=True)
class MetricSet:
    metrics: tuple[PerformanceMetric, ...]

    def __init__(self, metrics: Iterable[PerformanceMetric]):
        metric_tuple = tuple(metrics)
        names = tuple(metric.name for metric in metric_tuple)
        non_string_names = tuple(
            repr(name)
            for name in names
            if not isinstance(name, str)
        )
        if non_string_names:
            raise TypeError(
                "Metric names must be strings: "
                + ", ".join(non_string_names)
            )
        empty_names = tuple(repr(name) for name in names if not name)
        if empty_names:
            raise ValueError(
                "Metric names must be non-empty: "
                + ", ".join(empty_names)
            )
        duplicate_names = tuple(
            sorted({name for name in names if names.count(name) > 1})
        )
        if duplicate_names:
            raise ValueError(
                "Duplicate metric names: " + ", ".join(duplicate_names)
            )
        object.__setattr__(self, "metrics", metric_tuple)

    def __iter__(self):
        return iter(self.metrics)

    def __len__(self):
        return len(self.metrics)

    def names(self) -> list[str]:
        return [metric.name for metric in self.metrics]

    def get(self, name: str) -> PerformanceMetric:
        for metric in self.metrics:
            if metric.name == name:
                return metric
        raise KeyError(name)

    def pareto_metrics(self) -> list[PerformanceMetric]:
        return [
            metric
            for metric in self.metrics
            if metric.direction in (MetricDirection.SMALLER, MetricDirection.BIGGER)
        ]


@dataclass
class PerformanceMetricResults:
    aggregate_rows: list[dict]
    rollout_index_rows: list[dict]
    per_rollout_metric_rows: list[dict] | None = None


def _has_required_fields(metric: PerformanceMetric, time_series: Mapping[str, object]) -> bool:
    return all(field_name in time_series for field_name in metric.required_fields)


def compute_metric_values(metrics: MetricSet, time_series: Mapping[str, object]) -> dict[str, float]:
    values: dict[str, float] = {}
    for metric in metrics:
        if not _has_required_fields(metric, time_series):
            values[metric.name] = float("nan")
            continue
        try:
            values[metric.name] = float(metric.function(time_series))
        except Exception as error:
            raise MetricEvaluationError(metric.name) from error
    return values


def _finite_metric_values(rows: Sequence[Mapping[str, object]], metric_name: str) -> np.ndarray:
    values = []
    for row in rows:
        value = row.get(metric_name, float("nan"))
        try:
            value = float(value)
        except (TypeError, ValueError):
            value = float("nan")
        if math.isfinite(value):
            values.append(value)
    return np.asarray(values, dtype=np.float64)


def _confidence_interval_95(values: np.ndarray) -> tuple[float, float]:
    if values.size == 0:
        return float("nan"), float("nan")
    if values.size == 1:
        return float(values[0]), float(values[0])
    mean = float(np.mean(values))
    stderr = float(np.std(values, ddof=1) / math.sqrt(values.size))
    margin = 1.96 * stderr
    return mean - margin, mean + margin


def _worst_case(values: np.ndarray, metric: PerformanceMetric) -> float:
    if values.size == 0:
        return float("nan")
    if metric.direction == MetricDirection.BIGGER:
        return float(np.min(values))
    return float(np.max(values))


def _statistic_values(values: np.ndarray, metric: PerformanceMetric) -> dict[str, float]:
    if values.size == 0:
        return {
            "mean": float("nan"),
            "median": float("nan"),
            "std": float("nan"),
            "min": float("nan"),
            "max": float("nan"),
            "p05": float("nan"),
            "p25": float("nan"),
            "p75": float("nan"),
            "p95": float("nan"),
            "worst_case": float("nan"),
            "ci95_low": float("nan"),
            "ci95_high": float("nan"),
        }
    ci_low, ci_high = _confidence_interval_95(values)
    return {
        "mean": float(np.mean(values)),
        "median": float(np.median(values)),
        "std": float(np.std(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "p05": float(np.percentile(values, 5.0)),
        "p25": float(np.percentile(values, 25.0)),
        "p75": float(np.percentile(values, 75.0)),
        "p95": float(np.percentile(values, 95.0)),
        "worst_case": _worst_case(values, metric),
        "ci95_low": ci_low,
        "ci95_high": ci_high,
    }


def _row_is_flagged(row: Mapping[str, object]) -> bool:
    return _bool_like(row.get("terminated", False)) or _bool_like(row.get("truncated", False))


def _bool_like(value: object) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in ("", "0", "false", "f", "no", "n", "none"):
            return False
        if normalized in ("1", "true", "t", "yes", "y"):
            return True
    return bool(value)


def aggregate_metric_rows(
    rows: Sequence[Mapping[str, object]],
    metrics: MetricSet,
    aggregation: AggregationSpec | None = None,
    *,
    include_flagged_rollouts: bool = False,
) -> list[dict]:
    aggregation = AggregationSpec() if aggregation is None else aggregation
    policy_names = sorted({str(row["policy_name"]) for row in rows})
    aggregate_rows: list[dict] = []
    for policy_name in policy_names:
        policy_rows = [row for row in rows if str(row["policy_name"]) == policy_name]
        flagged_count = sum(1 for row in policy_rows if _row_is_flagged(row))
        metric_rows = policy_rows if include_flagged_rollouts else [
            row for row in policy_rows if not _row_is_flagged(row)
        ]
        aggregate_row = {
            "policy_name": policy_name,
            "rollout_count": len(policy_rows),
            "metric_rollout_count": len(metric_rows),
            "flagged_rollout_count": flagged_count,
        }
        for metric in metrics:
            values = _finite_metric_values(metric_rows, metric.name)
            stats = _statistic_values(values, metric)
            for statistic in aggregation.statistics:
                aggregate_row[metric.name + "__" + statistic] = stats[statistic]
            aggregate_row[metric.name + "__primary"] = stats[metric.primary_aggregate]
            if metric.threshold is not None:
                primary = aggregate_row[metric.name + "__primary"]
                aggregate_row[metric.name + "__threshold"] = metric.threshold
                aggregate_row[metric.name + "__threshold_exceeded"] = (
                    math.isfinite(primary) and primary > metric.threshold
                )
        aggregate_rows.append(aggregate_row)
    return aggregate_rows


def _dominates(
    row_j: Mapping[str, object],
    row_i: Mapping[str, object],
    metrics: Sequence[PerformanceMetric],
) -> bool:
    strictly_better = False
    for metric in metrics:
        key = metric.name + "__primary"
        value_i = float(row_i.get(key, float("nan")))
        value_j = float(row_j.get(key, float("nan")))
        if not (math.isfinite(value_i) and math.isfinite(value_j)):
            return False
        if metric.direction == MetricDirection.BIGGER:
            if value_j < value_i:
                return False
            if value_j > value_i:
                strictly_better = True
        elif metric.direction == MetricDirection.SMALLER:
            if value_j > value_i:
                return False
            if value_j < value_i:
                strictly_better = True
    return strictly_better


def compute_pareto_front(
    rows: Sequence[Mapping[str, object]],
    metrics: MetricSet,
    metric_names: Sequence[str] | None = None,
) -> list[dict]:
    if metric_names is None:
        pareto_metrics = metrics.pareto_metrics()
    else:
        selected = set(metric_names)
        pareto_metrics = [
            metric for metric in metrics.pareto_metrics()
            if metric.name in selected
        ]
    result_rows: list[dict] = []
    for i, row_i in enumerate(rows):
        dominated_by = []
        dominates = []
        for j, row_j in enumerate(rows):
            if i == j:
                continue
            if _dominates(row_j, row_i, pareto_metrics):
                dominated_by.append(str(row_j["policy_name"]))
            if _dominates(row_i, row_j, pareto_metrics):
                dominates.append(str(row_j["policy_name"]))
        result = dict(row_i)
        result["pareto_status"] = "dominated" if dominated_by else "front"
        result["is_pareto_front"] = not dominated_by
        result["dominated_by"] = dominated_by
        result["dominates"] = dominates
        result_rows.append(result)
    return result_rows


def _write_csv(rows: Sequence[Mapping[str, object]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def metric_rows_to_markdown(rows: Sequence[Mapping[str, object]]) -> str:
    if not rows:
        return ""
    columns = list(rows[0].keys())
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    return "\n".join(lines) + "\n"


def _latex_escape(value: object) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in text)


def _latex_column_labels(columns: Sequence[str], metrics: MetricSet | None = None) -> list[str]:
    if metrics is None:
        return [_latex_escape(column) for column in columns]

    metric_by_name = {metric.name: metric for metric in metrics}
    labels = []
    for column in columns:
        matched_label = None
        for metric_name, metric in metric_by_name.items():
            prefix = metric_name + "__"
            if column.startswith(prefix):
                statistic = column[len(prefix):]
                matched_label = metric.display_name + " (" + statistic + ")"
                break
        labels.append(_latex_escape(matched_label if matched_label is not None else column))
    return labels


def metric_rows_to_latex(
    rows: Sequence[Mapping[str, object]],
    metrics: MetricSet | None = None,
) -> str:
    if not rows:
        return ""
    columns = list(rows[0].keys())
    column_labels = _latex_column_labels(columns, metrics)
    lines = [
        "\\begin{tabular}{" + "l" * len(columns) + "}",
        " & ".join(column_labels) + " \\\\",
        "\\hline",
    ]
    for row in rows:
        lines.append(" & ".join(_latex_escape(row.get(column, "")) for column in columns) + " \\\\")
    lines.append("\\end{tabular}")
    return "\n".join(lines) + "\n"


def save_metric_tables(
    results: PerformanceMetricResults,
    output_dir: str | Path = "performance_metric_results",
    *,
    file_prefix: str = "performance_metrics",
    metrics: MetricSet | None = None,
) -> dict[str, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "aggregate_csv": output_dir / (file_prefix + "_aggregate.csv"),
        "rollout_index_csv": output_dir / (file_prefix + "_rollout_index.csv"),
        "aggregate_markdown": output_dir / (file_prefix + "_aggregate.md"),
        "aggregate_latex": output_dir / (file_prefix + "_aggregate.tex"),
    }
    _write_csv(results.aggregate_rows, paths["aggregate_csv"])
    _write_csv(results.rollout_index_rows, paths["rollout_index_csv"])
    paths["aggregate_markdown"].write_text(
        metric_rows_to_markdown(results.aggregate_rows),
        encoding="utf-8",
    )
    paths["aggregate_latex"].write_text(
        metric_rows_to_latex(results.aggregate_rows, metrics=metrics),
        encoding="utf-8",
    )
    if results.per_rollout_metric_rows is not None:
        paths["per_rollout_csv"] = output_dir / (file_prefix + "_per_rollout.csv")
        _write_csv(results.per_rollout_metric_rows, paths["per_rollout_csv"])
    return paths
