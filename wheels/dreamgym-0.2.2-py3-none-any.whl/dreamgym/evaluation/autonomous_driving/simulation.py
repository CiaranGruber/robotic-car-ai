#!/usr/bin/env python

from dataclasses import dataclass
import inspect
from numbers import Integral

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCRolloutHistory,
)
from dreamgym.policies.autonomous_driving import RLPolicy
from dreamgym.policies.autonomous_driving._mpc_rollout import (
    _AutonomousDrivingMPCPolicyMarker,
    _MPCConfiguredRaiseError,
)


_GROUND_TRUTH_SOURCES = {
    "px": ("ground_truth_world_position_x_m", None),
    "py": ("ground_truth_world_position_y_m", None),
    "theta": ("ground_truth_heading_in_world_frame_rad", None),
    "vx": ("ground_truth_body_longitudinal_velocity_mps", None),
    "vy": ("ground_truth_body_lateral_velocity_mps", None),
    "omega": ("ground_truth_yaw_rate_rad_per_s", None),
    "delta": ("ground_truth_front_wheel_steering_angle_rad", None),
    "reference_line_progress_at_closest_point": (
        "reference_line_progress_m",
        None,
    ),
    "lateral_error_from_target_line": (
        "lateral_error_from_target_line_m",
        None,
    ),
    "heading_angle_relative_to_target_line": (
        "heading_error_from_target_line_rad",
        None,
    ),
    "target_line_curvature_at_closest_point": (
        "target_line_curvature_per_m",
        None,
    ),
    "speed_limit_at_closest_point": ("speed_limit_mps", None),
    "recommended_speed_at_closest_point": ("recommended_speed_mps", None),
    "target_line_px_closest": (
        "target_line_position_at_closest_reference_line_progress_in_world_frame_m",
        0,
    ),
    "target_line_py_closest": (
        "target_line_position_at_closest_reference_line_progress_in_world_frame_m",
        1,
    ),
    "target_line_px_closest_in_body_frame": (
        "target_line_position_at_closest_reference_line_progress_in_body_frame_m",
        0,
    ),
    "target_line_py_closest_in_body_frame": (
        "target_line_position_at_closest_reference_line_progress_in_body_frame_m",
        1,
    ),
}
_GROUND_TRUTH_KEYS = tuple(_GROUND_TRUTH_SOURCES)
_OBSERVATION_KEYS = {
    "obs_lateral_error_from_target_line": "lateral_error_from_target_line_m",
    "obs_heading_angle_relative_to_target_line": (
        "heading_error_from_target_line_rad"
    ),
    "obs_target_line_curvature_at_closest_point": (
        "target_line_curvature_per_m"
    ),
}


def _scalar_observation_or_nan(env, observation, observation_name):
    if isinstance(observation, dict):
        value = observation.get(observation_name, np.nan)
    elif isinstance(observation, np.ndarray):
        flat_slices = getattr(env.unwrapped, "flat_observation_slices", {})
        if observation_name not in flat_slices:
            return np.nan
        value = observation[flat_slices[observation_name]]
    else:
        return np.nan

    value_array = np.asarray(value)
    if value_array.size == 0:
        return np.nan
    return float(value_array.reshape(-1)[0])


def _seed_compatible_call(method, seed):
    """Return an inspect-validated call shape for an optional seed argument."""

    try:
        signature = inspect.signature(method)
    except (TypeError, ValueError):
        # Some extension callables do not expose signatures. Prefer the public
        # keyword convention and let any error from the method propagate.
        return (), {"seed": seed}

    candidates = (
        ((), {"seed": seed}),
        ((seed,), {}),
        ((), {}),
    )
    for args, kwargs in candidates:
        try:
            signature.bind(*args, **kwargs)
        except TypeError:
            continue
        return args, kwargs
    raise TypeError("policy reset hook has an unsupported signature")


def _reset_policy_if_supported(policy, seed=None):
    """Reset an optional stateful policy without swallowing hook failures."""

    if seed is not None:
        for method_name in ("set_seed", "seed"):
            seed_method = getattr(policy, method_name, None)
            if callable(seed_method):
                seed_args, seed_kwargs = _seed_compatible_call(
                    seed_method, seed
                )
                seed_method(*seed_args, **seed_kwargs)
                break

    reset = getattr(policy, "reset", None)
    if not callable(reset):
        return

    args, kwargs = _seed_compatible_call(reset, seed)
    reset(*args, **kwargs)


def _allocate_legacy_time_series(
    *,
    n_steps,
    save_look_ahead,
    save_observations,
    look_ahead_length,
):
    values = {
        name: np.full(n_steps + 1, np.nan, dtype=np.float32)
        for name in (
            "reward",
            *_GROUND_TRUTH_KEYS,
            "drive_command",
            "delta_request",
        )
    }
    if save_look_ahead:
        for name in (
            "look_ahead_x_coords_in_body_frame",
            "look_ahead_y_coords_in_body_frame",
            "look_ahead_target_line_curvatures",
        ):
            values[name] = np.full(
                (look_ahead_length, n_steps + 1),
                np.nan,
                dtype=np.float32,
            )
    else:
        for name in (
            "look_ahead_x_coords_in_body_frame",
            "look_ahead_y_coords_in_body_frame",
            "look_ahead_target_line_curvatures",
        ):
            values[name] = np.nan
    for result_name in _OBSERVATION_KEYS:
        values[result_name] = (
            np.full(n_steps + 1, np.nan, dtype=np.float32)
            if save_observations
            else np.nan
        )
    return values


def _record_legacy_state_sample(
    *,
    values,
    environment,
    ground_truth,
    observation,
    state_index,
    save_look_ahead,
    save_observations,
):
    for result_name, (source_name, component_index) in (
        _GROUND_TRUTH_SOURCES.items()
    ):
        source_value = ground_truth[source_name]
        if component_index is not None:
            source_value = source_value[component_index]
        values[result_name][state_index] = source_value
    if save_look_ahead:
        expected_length = values[
            "look_ahead_target_line_curvatures"
        ].shape[0]
        coordinates, curvatures = _validated_look_ahead_sample(
            ground_truth,
            expected_length=expected_length,
        )
        values["look_ahead_x_coords_in_body_frame"][:, state_index] = (
            coordinates[:, 0]
        )
        values["look_ahead_y_coords_in_body_frame"][:, state_index] = (
            coordinates[:, 1]
        )
        values["look_ahead_target_line_curvatures"][:, state_index] = (
            curvatures
        )
    if save_observations:
        for result_name, observation_name in _OBSERVATION_KEYS.items():
            values[result_name][state_index] = _scalar_observation_or_nan(
                environment,
                observation,
                observation_name,
            )


def _validated_look_ahead_sample(ground_truth, *, expected_length=None):
    coordinates = np.asarray(
        ground_truth[
            "target_line_lookahead_positions_in_body_frame_m"
        ],
        dtype=np.float32,
    )
    if coordinates.ndim != 2 or coordinates.shape[1] != 2:
        raise ValueError(
            "target-line lookahead positions must have shape (N, 2)"
        )
    if (
        expected_length is not None
        and coordinates.shape[0] != expected_length
    ):
        raise ValueError(
            "target-line lookahead positions must have shape (N, 2) "
            "with N fixed by the initial sample"
        )

    curvatures = np.asarray(
        ground_truth["target_line_lookahead_curvatures_per_m"],
        dtype=np.float32,
    )
    if curvatures.shape != (coordinates.shape[0],):
        raise ValueError(
            "target-line lookahead curvatures must have shape (N,) "
            "matching positions"
        )
    return coordinates, curvatures


@dataclass(slots=True)
class _SimulationTimeSeriesStorage:
    environment: object
    n_steps: int
    save_look_ahead: bool
    save_observations: bool
    values: dict[str, object]

    @classmethod
    def create(
        cls,
        *,
        environment,
        n_steps,
        save_look_ahead,
        save_observations,
        initial_ground_truth,
    ):
        look_ahead_length = 0
        if save_look_ahead:
            look_ahead_positions, _ = _validated_look_ahead_sample(
                initial_ground_truth,
            )
            look_ahead_length = look_ahead_positions.shape[0]
        values = _allocate_legacy_time_series(
            n_steps=n_steps,
            save_look_ahead=save_look_ahead,
            save_observations=save_observations,
            look_ahead_length=look_ahead_length,
        )
        return cls(
            environment=environment,
            n_steps=n_steps,
            save_look_ahead=save_look_ahead,
            save_observations=save_observations,
            values=values,
        )

    def record_initial(self, *, ground_truth, observation):
        _record_legacy_state_sample(
            values=self.values,
            environment=self.environment,
            ground_truth=ground_truth,
            observation=observation,
            state_index=0,
            save_look_ahead=self.save_look_ahead,
            save_observations=self.save_observations,
        )

    def record_transition(
        self,
        *,
        transition_index,
        ground_truth_after,
        next_observation,
        reward,
        environment_drive_request,
        environment_steering_request,
    ):
        self.values["reward"][transition_index] = reward
        self.values["drive_command"][transition_index] = (
            environment_drive_request
        )
        self.values["delta_request"][transition_index] = (
            environment_steering_request
        )
        _record_legacy_state_sample(
            values=self.values,
            environment=self.environment,
            ground_truth=ground_truth_after,
            observation=next_observation,
            state_index=transition_index + 1,
            save_look_ahead=self.save_look_ahead,
            save_observations=self.save_observations,
        )

    def finalize(
        self,
        *,
        completed_transition_count,
        terminated,
        truncated,
    ):
        if not 0 <= completed_transition_count <= self.n_steps:
            raise ValueError("completed_transition_count is outside storage")
        result = dict(self.values)
        result["terminated"] = bool(terminated)
        result["truncated"] = bool(truncated)
        result["time_index"] = np.arange(self.n_steps + 1)
        result["time_in_seconds"] = (
            result["time_index"]
            * self.environment.unwrapped.environment_step_duration_s
        )
        return result


def _project_mpc_policy_attempt(
    *,
    policy,
    policy_result,
    prediction_context,
    ground_truth,
):
    from dreamgym.evaluation.autonomous_driving._mpc_rollout import (
        _formulation_and_metadata_for_policy,
    )
    from dreamgym.evaluation.autonomous_driving._mpc_world_projection import (
        _project_mpc_world_prediction,
    )

    formulation, _ = _formulation_and_metadata_for_policy(policy)
    outcome = _project_mpc_world_prediction(
        formulation=formulation,
        policy_result=policy_result,
        prediction_context=prediction_context,
        model_config=policy.config.model,
        ground_truth=ground_truth,
    )
    return formulation, outcome


def _project_and_distribute_mpc_attempt(
    *,
    policy,
    policy_result,
    prediction_context,
    ground_truth,
    collector,
    retain_world_projection,
    live_overlay_adapter,
    transition_index,
):
    formulation, outcome = _project_mpc_policy_attempt(
        policy=policy,
        policy_result=policy_result,
        prediction_context=prediction_context,
        ground_truth=ground_truth,
    )
    collector.capture_world_projection(
        outcome=outcome,
        retain=retain_world_projection,
    )
    if live_overlay_adapter is not None:
        live_overlay_adapter._publish_projection_outcome(
            policy=policy,
            policy_result=policy_result,
            outcome=outcome,
            transition_index=transition_index,
            expected_formulation=formulation,
        )


def _simulate_policy_episode(
    *,
    env,
    n_steps,
    policy,
    environment_seed,
    policy_seed,
    reset_policy,
    should_save_look_ahead_results,
    should_save_observations,
    verbose,
    collector,
    live_overlay_adapter=None,
    retain_world_projection=False,
):
    if type(retain_world_projection) is not bool:
        raise TypeError("retain_world_projection must be a bool")
    if live_overlay_adapter is not None and collector is None:
        raise ValueError("a live MPC overlay requires an MPC collector")
    projection_requested = (
        retain_world_projection or live_overlay_adapter is not None
    )
    is_mpc = isinstance(policy, _AutonomousDrivingMPCPolicyMarker)
    if is_mpc and not reset_policy:
        if policy_seed is not None:
            raise ValueError("policy_seed requires reset_policy=True")
        policy._validate_rollout_continuation(env)
        effective_policy_seed = policy.rollout_seed
        policy_was_reset = False

    env.unwrapped.ground_truth_mode = "full"

    if is_mpc and reset_policy:
        effective_policy_seed = (
            environment_seed if policy_seed is None else policy_seed
        )
        policy.bind_environment(env, seed=effective_policy_seed)
        policy_was_reset = True
    elif not is_mpc:
        bind_environment = getattr(policy, "bind_environment", None)
        if callable(bind_environment):
            bind_environment(env)
        effective_policy_seed = (
            environment_seed if policy_seed is None else policy_seed
        )
        policy_was_reset = bool(reset_policy)

    observation, info_dict = env.reset(seed=environment_seed)
    if not is_mpc and reset_policy:
        _reset_policy_if_supported(policy, effective_policy_seed)

    current_ground_truth = env.unwrapped.get_current_ground_truth()
    storage = _SimulationTimeSeriesStorage.create(
        environment=env,
        n_steps=n_steps,
        save_look_ahead=should_save_look_ahead_results,
        save_observations=should_save_observations,
        initial_ground_truth=current_ground_truth,
    )
    storage.record_initial(
        ground_truth=current_ground_truth,
        observation=observation,
    )
    if collector is not None:
        collector.start_rollout(
            environment=env,
            policy=policy,
            environment_seed=environment_seed,
            effective_policy_seed=effective_policy_seed,
            policy_was_reset=policy_was_reset,
            initial_ground_truth=current_ground_truth,
        )
    if verbose > 0:
        print("\n\nNow starting simulation.")

    sim_terminated = False
    sim_truncated = False
    completed_transition_count = 0
    for transition_index in range(n_steps):
        if collector is not None:
            collector.begin_transition(
                transition_index=transition_index,
                ground_truth_before=current_ground_truth,
            )

        try:
            action = policy.compute_action(
                observation,
                info_dict,
                sim_terminated,
                sim_truncated,
            )
        except _MPCConfiguredRaiseError as original:
            if collector is None:
                raise
            if projection_requested:
                try:
                    prediction_context = collector.prepare_configured_raise(
                        error=original,
                        ground_truth_before=current_ground_truth,
                    )
                    _project_and_distribute_mpc_attempt(
                        policy=policy,
                        policy_result=original.policy_result,
                        prediction_context=prediction_context,
                        ground_truth=current_ground_truth,
                        collector=collector,
                        retain_world_projection=retain_world_projection,
                        live_overlay_adapter=live_overlay_adapter,
                        transition_index=transition_index,
                    )
                except BaseException:
                    if live_overlay_adapter is not None:
                        live_overlay_adapter._clear_active_snapshot()
                    raise
            partial_series = storage.finalize(
                completed_transition_count=completed_transition_count,
                terminated=sim_terminated,
                truncated=sim_truncated,
            )
            replacement = collector.abort_configured_raise(
                error=original,
                simulation_time_series=partial_series,
                ground_truth_before=current_ground_truth,
            )
            raise replacement from original
        except BaseException:
            if live_overlay_adapter is not None:
                live_overlay_adapter._clear_active_snapshot()
            raise
        if collector is not None:
            try:
                prediction_context = collector.capture_policy_result(
                    policy_result=policy.last_result,
                    problem=policy.last_problem,
                    emitted_action=np.asarray(action).copy(),
                    ground_truth_before=current_ground_truth,
                )
                if projection_requested:
                    _project_and_distribute_mpc_attempt(
                        policy=policy,
                        policy_result=policy.last_result,
                        prediction_context=prediction_context,
                        ground_truth=current_ground_truth,
                        collector=collector,
                        retain_world_projection=retain_world_projection,
                        live_overlay_adapter=live_overlay_adapter,
                        transition_index=transition_index,
                    )
            except BaseException:
                if live_overlay_adapter is not None:
                    live_overlay_adapter._clear_active_snapshot()
                raise

        next_observation, reward, terminated, truncated, next_info = (
            env.step(action)
        )
        resolved_action_request = env.unwrapped.car.resolved_action_request
        drive_request = resolved_action_request["normalized_drive_command"]
        steering_request = resolved_action_request[
            "requested_front_wheel_angle_rad"
        ]

        record_applied_action = getattr(
            policy,
            "record_applied_action",
            None,
        )
        if collector is not None or callable(record_applied_action):
            current_model_action = env.unwrapped.car.current_model_action
            current_model_state = env.unwrapped.car.state
            applied_drive = current_model_action["normalized_drive_command"]
            applied_rate = current_model_action[
                "physical_front_wheel_angle_rate_rad_per_s"
            ]
            realized_angle = current_model_state[
                "front_wheel_steering_angle_rad"
            ]
            if callable(record_applied_action):
                record_applied_action(
                    drive_command=applied_drive,
                    steering_rate=applied_rate,
                    steering_angle=realized_angle,
                )
        else:
            applied_drive = None
            applied_rate = None
            realized_angle = None

        ground_truth_after = env.unwrapped.get_current_ground_truth()
        if collector is not None:
            collector.complete_transition(
                reward=reward,
                terminated=terminated,
                truncated=truncated,
                environment_drive_request=drive_request,
                environment_steering_request_radians=steering_request,
                applied_drive_command=applied_drive,
                applied_steering_rate_radians_per_second=applied_rate,
                realized_steering_angle_radians=realized_angle,
                ground_truth_after=ground_truth_after,
            )

        storage.record_transition(
            transition_index=transition_index,
            ground_truth_after=ground_truth_after,
            next_observation=next_observation,
            reward=reward,
            environment_drive_request=drive_request,
            environment_steering_request=steering_request,
        )
        observation, info_dict = next_observation, next_info
        current_ground_truth = ground_truth_after
        completed_transition_count = transition_index + 1
        sim_terminated = bool(terminated)
        sim_truncated = bool(truncated)
        if terminated or truncated:
            break

    if verbose > 0:
        print("Simulation finished\n")
    simulation_time_series = storage.finalize(
        completed_transition_count=completed_transition_count,
        terminated=sim_terminated,
        truncated=sim_truncated,
    )
    if collector is None:
        return simulation_time_series
    return collector.finish_rollout(
        simulation_time_series=simulation_time_series,
    )


def _simulate_policy(
    *,
    env,
    n_steps,
    policy,
    environment_seed,
    policy_seed,
    reset_policy,
    should_save_look_ahead_results,
    should_save_observations,
    verbose,
    collector,
    live_overlay_adapter=None,
    retain_world_projection=False,
):
    if live_overlay_adapter is not None:
        live_overlay_adapter.begin_episode()
    try:
        return _simulate_policy_episode(
            env=env,
            n_steps=n_steps,
            policy=policy,
            environment_seed=environment_seed,
            policy_seed=policy_seed,
            reset_policy=reset_policy,
            should_save_look_ahead_results=(
                should_save_look_ahead_results
            ),
            should_save_observations=should_save_observations,
            verbose=verbose,
            collector=collector,
            live_overlay_adapter=live_overlay_adapter,
            retain_world_projection=retain_world_projection,
        )
    finally:
        if live_overlay_adapter is not None:
            live_overlay_adapter.finish_rollout()


## -----------------
#  SIMULATE A POLICY
#  -----------------
def simulate_policy(
    env,
    N_sim,
    policy,
    seed=None,
    should_save_look_ahead_results=False,
    should_save_observations=False,
    verbose=0,
    *,
    reset_policy=True,
    policy_seed=None,
):
    return _simulate_policy(
        env=env,
        n_steps=N_sim,
        policy=policy,
        environment_seed=seed,
        policy_seed=policy_seed,
        reset_policy=reset_policy,
        should_save_look_ahead_results=should_save_look_ahead_results,
        should_save_observations=should_save_observations,
        verbose=verbose,
        collector=None,
    )


def simulate_mpc_policy(
    env,
    n_steps,
    policy,
    seed=None,
    should_save_look_ahead_results=False,
    should_save_observations=False,
    verbose=0,
    *,
    reset_policy=True,
    policy_seed=None,
    capture_world_predictions=False,
    live_overlay_config=None,
) -> AutonomousDrivingMPCRolloutHistory:
    if isinstance(n_steps, bool) or not isinstance(n_steps, Integral):
        raise TypeError("n_steps must be a nonnegative integer")
    n_steps = int(n_steps)
    if n_steps < 0:
        raise ValueError("n_steps must be nonnegative")
    if not isinstance(capture_world_predictions, bool):
        raise TypeError("capture_world_predictions must be a bool")
    live_overlay_adapter = None
    if live_overlay_config is not None:
        from dreamgym.visualization.autonomous_driving.mpc_live import (
            AutonomousDrivingMPCLivePredictionOverlayAdapter,
        )

        live_overlay_adapter = (
            AutonomousDrivingMPCLivePredictionOverlayAdapter(
                env,
                live_overlay_config,
            )
        )

    from dreamgym.evaluation.autonomous_driving._mpc_rollout import (
        _MPCRolloutCollector,
    )

    collector = _MPCRolloutCollector(
        policy,
        capture_world_predictions=capture_world_predictions,
    )
    try:
        return _simulate_policy(
            env=env,
            n_steps=n_steps,
            policy=policy,
            environment_seed=seed,
            policy_seed=policy_seed,
            reset_policy=reset_policy,
            should_save_look_ahead_results=(
                should_save_look_ahead_results
            ),
            should_save_observations=should_save_observations,
            verbose=verbose,
            collector=collector,
            live_overlay_adapter=live_overlay_adapter,
            retain_world_projection=capture_world_predictions,
        )
    finally:
        if live_overlay_adapter is not None:
            live_overlay_adapter.close()


## -----------------
#  SIMULATE RL MODEL
#  -----------------
def simulate_rl_model(env, N_sim, rl_model, seed=None, should_save_look_ahead_results=False, should_save_observations=False, verbose=0):
    # Put the RL model into a policy class
    rl_policy = RLPolicy(rl_model)
    # Call the simulate policy function
    sim_time_series_dict = simulate_policy(
        env,
        N_sim,
        rl_policy,
        seed=seed,
        should_save_look_ahead_results=should_save_look_ahead_results,
        should_save_observations=should_save_observations,
        verbose=verbose,
    )
    # Return the results dictionary
    return sim_time_series_dict
