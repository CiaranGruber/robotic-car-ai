"""Dependency-light immutable MPC rollout history contracts."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, fields
from enum import Enum
import math
from numbers import Integral, Real
from types import MappingProxyType

import numpy as np

from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCActionRequest,
    MPCEnvironmentBindingDiagnostics,
    MPCPolicyFailure,
    MPCPolicyResult,
    MPCRoadHorizonContext,
)


def _semantic_tuple(name: str, value: object) -> tuple[str, ...]:
    if not isinstance(value, tuple):
        raise TypeError(f"{name} must be a tuple")
    if not value or not all(isinstance(item, str) and item for item in value):
        raise TypeError(f"{name} must contain nonempty strings")
    return value


class AutonomousDrivingMPCFormulation(str, Enum):
    DIRECT_STEERING = "direct_steering"
    STEERING_RATE = "steering_rate"
    ROAD_AWARE_DIRECT_STEERING = "road_aware_direct_steering"
    ROAD_AWARE_STEERING_RATE = "road_aware_steering_rate"


class MPCWorldProjectionGeometry(str, Enum):
    LOCAL_STRAIGHT_TARGET_LINE = "local_straight_target_line"
    ROAD_AWARE_TARGET_LINE = "road_aware_target_line"


class MPCWorldProjectionUnavailabilityReason(str, Enum):
    NO_USABLE_PREDICTION = "no_usable_prediction"
    EVALUATOR_ANCHOR_UNAVAILABLE = "evaluator_anchor_unavailable"
    TARGET_DISTANCE_INVALID = "target_distance_invalid"
    PREVIEW_COVERAGE_INSUFFICIENT = "preview_coverage_insufficient"
    TARGET_GEOMETRY_UNSUPPORTED = "target_geometry_unsupported"


@dataclass(frozen=True, slots=True)
class MPCVariableMetadata:
    state_names: tuple[str, ...]
    state_units_si: tuple[str, ...]
    control_names: tuple[str, ...]
    control_units_si: tuple[str, ...]
    actual_control_signal_names: tuple[str, ...]

    def __post_init__(self) -> None:
        for field_name in (
            "state_names",
            "state_units_si",
            "control_names",
            "control_units_si",
            "actual_control_signal_names",
        ):
            object.__setattr__(
                self,
                field_name,
                _semantic_tuple(field_name, getattr(self, field_name)),
            )
        if len(self.state_names) != len(self.state_units_si):
            raise ValueError("state names and SI units must have equal lengths")
        if len(self.control_names) != len(self.control_units_si):
            raise ValueError("control names and SI units must have equal lengths")
        if len(self.control_names) != len(self.actual_control_signal_names):
            raise ValueError(
                "control names and actual-control signal names must have "
                "equal lengths"
            )
        if len(set(self.state_names)) != len(self.state_names):
            raise ValueError("state names must be unique")
        if len(set(self.control_names)) != len(self.control_names):
            raise ValueError("control names must be unique")
        if len(set(self.actual_control_signal_names)) != len(
            self.actual_control_signal_names
        ):
            raise ValueError("actual control signal names must be unique")


def _read_only_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {value.shape}")
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, dtype=np.float64, copy=True)
    copied.setflags(write=False)
    return copied


def _read_only_finite_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
) -> np.ndarray:
    copied = _read_only_array(name, value, shape)
    if not np.isfinite(copied).all():
        raise ValueError(f"{name} must contain only finite values")
    return copied


def _read_only_boolean_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {value.shape}")
    if value.dtype != np.bool_:
        raise TypeError(f"{name} must have boolean dtype")
    copied = np.array(value, dtype=np.bool_, copy=True)
    copied.setflags(write=False)
    return copied


def _read_only_bound_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
    *,
    lower: bool,
) -> np.ndarray:
    copied = _read_only_array(name, value, shape)
    if np.isnan(copied).any():
        raise ValueError(f"{name} must not contain NaN")
    wrong_infinity = np.isposinf(copied) if lower else np.isneginf(copied)
    if wrong_infinity.any():
        side = "positive" if lower else "negative"
        raise ValueError(f"{name} must not contain {side} infinity")
    return copied


def _require_ordered_bounds(
    name: str,
    lower: np.ndarray,
    upper: np.ndarray,
) -> None:
    if np.any(lower > upper):
        raise ValueError(f"{name} lower bounds must not exceed upper bounds")


def _finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    return converted


def _road_horizon_contexts_equal(
    left: MPCRoadHorizonContext | None,
    right: MPCRoadHorizonContext | None,
) -> bool:
    if left is right:
        return True
    if left is None or right is None:
        return False
    for item in fields(MPCRoadHorizonContext):
        left_value = getattr(left, item.name)
        right_value = getattr(right, item.name)
        if isinstance(left_value, np.ndarray):
            if not isinstance(right_value, np.ndarray) or not np.array_equal(
                left_value,
                right_value,
                equal_nan=True,
            ):
                return False
        elif left_value != right_value:
            return False
    return True


@dataclass(frozen=True, slots=True)
class MPCWorldPose:
    position_metres: np.ndarray
    heading_radians: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "position_metres",
            _read_only_finite_array(
                "position_metres",
                self.position_metres,
                (2,),
            ),
        )
        object.__setattr__(
            self,
            "heading_radians",
            _finite_float("heading_radians", self.heading_radians),
        )


def _world_poses_equal(left: MPCWorldPose, right: MPCWorldPose) -> bool:
    return (
        np.array_equal(left.position_metres, right.position_metres)
        and left.heading_radians == right.heading_radians
    )


@dataclass(frozen=True, slots=True)
class MPCWorldPrediction:
    predicted_vehicle_positions_metres: np.ndarray
    predicted_vehicle_headings_radians: np.ndarray
    formulation_target_line_positions_metres: np.ndarray
    formulation_target_line_headings_radians: np.ndarray
    source_preview_target_line_positions_metres: np.ndarray | None
    source_preview_validity: np.ndarray | None
    installed_right_lane_bound_positions_metres: np.ndarray | None
    installed_left_lane_bound_positions_metres: np.ndarray | None
    predicted_relative_reference_progress_metres: np.ndarray
    predicted_relative_target_line_distances_metres: np.ndarray
    authoritative_target_line_origin_position_metres: np.ndarray
    authoritative_target_line_origin_heading_radians: float
    geometry: MPCWorldProjectionGeometry
    formulation: AutonomousDrivingMPCFormulation
    projection_time_seconds: float

    def __post_init__(self) -> None:
        predicted_positions = self.predicted_vehicle_positions_metres
        if not isinstance(predicted_positions, np.ndarray):
            raise TypeError(
                "predicted_vehicle_positions_metres must be a NumPy array"
            )
        if (
            predicted_positions.ndim != 2
            or predicted_positions.shape[1] != 2
            or predicted_positions.shape[0] < 2
        ):
            raise ValueError(
                "predicted_vehicle_positions_metres must have shape (N + 1, 2) "
                "for positive N"
            )
        horizon_steps = predicted_positions.shape[0] - 1
        state_rows = horizon_steps + 1
        finite_shapes = {
            "predicted_vehicle_positions_metres": (state_rows, 2),
            "predicted_vehicle_headings_radians": (state_rows,),
            "formulation_target_line_positions_metres": (state_rows, 2),
            "formulation_target_line_headings_radians": (state_rows,),
            "predicted_relative_reference_progress_metres": (state_rows,),
            "predicted_relative_target_line_distances_metres": (state_rows,),
            "authoritative_target_line_origin_position_metres": (2,),
        }
        for field_name, shape in finite_shapes.items():
            object.__setattr__(
                self,
                field_name,
                _read_only_finite_array(
                    field_name,
                    getattr(self, field_name),
                    shape,
                ),
            )

        source_positions = self.source_preview_target_line_positions_metres
        source_validity = self.source_preview_validity
        if (source_positions is None) != (source_validity is None):
            raise ValueError(
                "source preview positions and validity must both be present or absent"
            )
        if source_positions is not None:
            if (
                not isinstance(source_positions, np.ndarray)
                or source_positions.ndim != 2
                or source_positions.shape[1] != 2
            ):
                if not isinstance(source_positions, np.ndarray):
                    raise TypeError(
                        "source_preview_target_line_positions_metres must be a "
                        "NumPy array"
                    )
                raise ValueError(
                    "source_preview_target_line_positions_metres must have shape "
                    "(M, 2)"
                )
            source_count = source_positions.shape[0]
            if source_count <= 0:
                raise ValueError("source preview must contain at least one row")
            object.__setattr__(
                self,
                "source_preview_target_line_positions_metres",
                _read_only_finite_array(
                    "source_preview_target_line_positions_metres",
                    source_positions,
                    (source_count, 2),
                ),
            )
            object.__setattr__(
                self,
                "source_preview_validity",
                _read_only_boolean_array(
                    "source_preview_validity",
                    source_validity,
                    (source_count,),
                ),
            )

        right_lane = self.installed_right_lane_bound_positions_metres
        left_lane = self.installed_left_lane_bound_positions_metres
        if (right_lane is None) != (left_lane is None):
            raise ValueError(
                "installed right and left lane bounds must both be present or absent"
            )
        if right_lane is not None:
            for field_name in (
                "installed_right_lane_bound_positions_metres",
                "installed_left_lane_bound_positions_metres",
            ):
                object.__setattr__(
                    self,
                    field_name,
                    _read_only_finite_array(
                        field_name,
                        getattr(self, field_name),
                        (horizon_steps, 2),
                    ),
                )

        reference_progress = self.predicted_relative_reference_progress_metres
        if reference_progress[0] != 0.0:
            raise ValueError(
                "predicted_relative_reference_progress_metres must begin at "
                "exactly zero"
            )
        target_distances = self.predicted_relative_target_line_distances_metres
        if target_distances[0] != 0.0:
            raise ValueError(
                "predicted_relative_target_line_distances_metres must begin at "
                "exactly zero"
            )
        if np.any(np.diff(target_distances) < 0.0):
            raise ValueError(
                "predicted_relative_target_line_distances_metres must be "
                "nondecreasing"
            )
        if not isinstance(self.geometry, MPCWorldProjectionGeometry):
            raise TypeError("geometry must be an MPCWorldProjectionGeometry")
        if not isinstance(self.formulation, AutonomousDrivingMPCFormulation):
            raise TypeError("formulation must be an AutonomousDrivingMPCFormulation")
        projection_time = _finite_float(
            "projection_time_seconds",
            self.projection_time_seconds,
        )
        if projection_time < 0.0:
            raise ValueError("projection_time_seconds must be nonnegative")
        object.__setattr__(self, "projection_time_seconds", projection_time)
        object.__setattr__(
            self,
            "authoritative_target_line_origin_heading_radians",
            _finite_float(
                "authoritative_target_line_origin_heading_radians",
                self.authoritative_target_line_origin_heading_radians,
            ),
        )


@dataclass(frozen=True, slots=True)
class MPCPredictionContext:
    state_references: np.ndarray
    control_references: np.ndarray
    hard_state_lower_bounds: np.ndarray
    hard_state_upper_bounds: np.ndarray
    soft_state_lower_bounds: np.ndarray
    soft_state_upper_bounds: np.ndarray
    control_lower_bounds: np.ndarray
    control_upper_bounds: np.ndarray
    control_difference_lower_bounds: np.ndarray
    control_difference_upper_bounds: np.ndarray
    previous_control: np.ndarray | None
    reference_speeds_mps: np.ndarray
    soft_speed_upper_bounds_mps: np.ndarray | None
    linearization_speeds_mps: np.ndarray
    progress_schedule_metres: np.ndarray
    predicted_relative_progress_metres: np.ndarray | None
    actual_reference_line_progress_anchor_metres: float
    road_horizon_context: MPCRoadHorizonContext | None = None
    world_prediction_capture_requested: bool = False
    world_prediction: MPCWorldPrediction | None = None
    world_projection_unavailability_reason: (
        MPCWorldProjectionUnavailabilityReason | None
    ) = None

    def __post_init__(self) -> None:
        if not isinstance(self.state_references, np.ndarray):
            raise TypeError("state_references must be a NumPy array")
        if not isinstance(self.control_references, np.ndarray):
            raise TypeError("control_references must be a NumPy array")
        horizon_steps, n_control = self.control_references.shape
        if horizon_steps <= 0 or n_control <= 0:
            raise ValueError("control_references must have positive dimensions")
        if self.state_references.ndim != 2:
            raise ValueError("state_references must be two-dimensional")
        n_state = self.state_references.shape[1]
        if self.state_references.shape != (horizon_steps + 1, n_state):
            raise ValueError("state_references must have shape (N + 1, n_state)")
        shapes = {
            "state_references": (horizon_steps + 1, n_state),
            "control_references": (horizon_steps, n_control),
            "hard_state_lower_bounds": (horizon_steps, n_state),
            "hard_state_upper_bounds": (horizon_steps, n_state),
            "soft_state_lower_bounds": (horizon_steps, n_state),
            "soft_state_upper_bounds": (horizon_steps, n_state),
            "control_lower_bounds": (horizon_steps, n_control),
            "control_upper_bounds": (horizon_steps, n_control),
            "control_difference_lower_bounds": (horizon_steps, n_control),
            "control_difference_upper_bounds": (horizon_steps, n_control),
        }
        bound_names = {
            "hard_state_lower_bounds": True,
            "hard_state_upper_bounds": False,
            "soft_state_lower_bounds": True,
            "soft_state_upper_bounds": False,
            "control_lower_bounds": True,
            "control_upper_bounds": False,
            "control_difference_lower_bounds": True,
            "control_difference_upper_bounds": False,
        }
        for field_name, shape in shapes.items():
            if field_name in bound_names:
                copied = _read_only_bound_array(
                    field_name,
                    getattr(self, field_name),
                    shape,
                    lower=bound_names[field_name],
                )
            else:
                copied = _read_only_finite_array(
                    field_name,
                    getattr(self, field_name),
                    shape,
                )
            object.__setattr__(self, field_name, copied)
        if self.previous_control is not None:
            object.__setattr__(
                self,
                "previous_control",
                _read_only_finite_array(
                    "previous_control",
                    self.previous_control,
                    (n_control,),
                ),
            )
        vector_shapes = {
            "reference_speeds_mps": (horizon_steps + 1,),
            "linearization_speeds_mps": (horizon_steps,),
            "progress_schedule_metres": (horizon_steps + 1,),
        }
        for field_name, shape in vector_shapes.items():
            object.__setattr__(
                self,
                field_name,
                _read_only_finite_array(
                    field_name,
                    getattr(self, field_name),
                    shape,
                ),
            )
        soft_speed_bounds = self.soft_speed_upper_bounds_mps
        if soft_speed_bounds is not None:
            soft_speed_bounds = _read_only_bound_array(
                "soft_speed_upper_bounds_mps",
                soft_speed_bounds,
                (horizon_steps,),
                lower=False,
            )
            if np.any(soft_speed_bounds < 0.0):
                raise ValueError(
                    "soft_speed_upper_bounds_mps must be nonnegative or +inf"
                )
            object.__setattr__(
                self,
                "soft_speed_upper_bounds_mps",
                soft_speed_bounds,
            )
        predicted_progress = self.predicted_relative_progress_metres
        if predicted_progress is not None:
            object.__setattr__(
                self,
                "predicted_relative_progress_metres",
                _read_only_finite_array(
                    "predicted_relative_progress_metres",
                    predicted_progress,
                    (horizon_steps + 1,),
                ),
            )
        object.__setattr__(
            self,
            "actual_reference_line_progress_anchor_metres",
            _finite_float(
                "actual_reference_line_progress_anchor_metres",
                self.actual_reference_line_progress_anchor_metres,
            ),
        )
        for family, lower_name, upper_name in (
            ("hard_state", "hard_state_lower_bounds", "hard_state_upper_bounds"),
            ("soft_state", "soft_state_lower_bounds", "soft_state_upper_bounds"),
            ("control", "control_lower_bounds", "control_upper_bounds"),
            (
                "control_difference",
                "control_difference_lower_bounds",
                "control_difference_upper_bounds",
            ),
        ):
            _require_ordered_bounds(
                family,
                getattr(self, lower_name),
                getattr(self, upper_name),
            )
        predicted_progress = self.predicted_relative_progress_metres
        if predicted_progress is not None and predicted_progress[0] != 0.0:
            raise ValueError(
                "predicted_relative_progress_metres must begin at exactly zero"
            )
        if self.road_horizon_context is not None and not isinstance(
            self.road_horizon_context,
            MPCRoadHorizonContext,
        ):
            raise TypeError(
                "road_horizon_context must be an MPCRoadHorizonContext or None"
            )
        if not isinstance(self.world_prediction_capture_requested, bool):
            raise TypeError("world_prediction_capture_requested must be a bool")
        if self.world_prediction is not None and not isinstance(
            self.world_prediction,
            MPCWorldPrediction,
        ):
            raise TypeError("world_prediction must be an MPCWorldPrediction or None")
        reason = self.world_projection_unavailability_reason
        if reason is not None and not isinstance(
            reason,
            MPCWorldProjectionUnavailabilityReason,
        ):
            raise TypeError(
                "world_projection_unavailability_reason must be an "
                "MPCWorldProjectionUnavailabilityReason or None"
            )
        if not self.world_prediction_capture_requested:
            if self.world_prediction is not None or reason is not None:
                raise ValueError(
                    "world projection outcomes require requested history capture"
                )
        elif (self.world_prediction is None) == (reason is None):
            raise ValueError(
                "requested world prediction capture requires exactly one outcome"
            )


def _read_only_copy(value: np.ndarray) -> np.ndarray:
    copied = np.array(value, copy=True)
    copied.setflags(write=False)
    return copied


@dataclass(frozen=True, slots=True)
class MPCActionExecution:
    policy_action_request: MPCActionRequest
    environment_normalized_drive_command_request: float
    environment_steering_request_radians: float
    environment_steering_target_radians: float
    applied_normalized_drive_command: float
    applied_steering_rate_radians_per_second: float
    realized_steering_angle_radians: float

    def __post_init__(self) -> None:
        if not isinstance(self.policy_action_request, MPCActionRequest):
            raise TypeError("policy_action_request must be an MPCActionRequest")
        for field_name in (
            "environment_normalized_drive_command_request",
            "environment_steering_request_radians",
            "environment_steering_target_radians",
            "applied_normalized_drive_command",
            "applied_steering_rate_radians_per_second",
            "realized_steering_angle_radians",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_float(field_name, getattr(self, field_name)),
            )


@dataclass(frozen=True, slots=True)
class MPCTransitionRecord:
    transition_index: int
    time_seconds: float
    policy_result: MPCPolicyResult
    prediction_context: MPCPredictionContext | None
    action_execution: MPCActionExecution
    actual_model_state_before: np.ndarray
    actual_model_state_after: np.ndarray
    actual_world_pose_before: MPCWorldPose
    actual_world_pose_after: MPCWorldPose
    actual_reference_line_progress_before_metres: float
    actual_reference_line_progress_after_metres: float
    reward: float
    terminated: bool
    truncated: bool

    def __post_init__(self) -> None:
        if isinstance(self.transition_index, bool) or not isinstance(
            self.transition_index,
            Integral,
        ):
            raise TypeError("transition_index must be an integer")
        transition_index = int(self.transition_index)
        if transition_index < 0:
            raise ValueError("transition_index must be nonnegative")
        object.__setattr__(self, "transition_index", transition_index)
        time_seconds = _finite_float("time_seconds", self.time_seconds)
        if time_seconds < 0.0:
            raise ValueError("time_seconds must be nonnegative")
        object.__setattr__(self, "time_seconds", time_seconds)
        if not isinstance(self.policy_result, MPCPolicyResult):
            raise TypeError("policy_result must be an MPCPolicyResult")
        if self.prediction_context is not None and not isinstance(
            self.prediction_context,
            MPCPredictionContext,
        ):
            raise TypeError(
                "prediction_context must be an MPCPredictionContext or None"
            )
        if not isinstance(self.action_execution, MPCActionExecution):
            raise TypeError("action_execution must be an MPCActionExecution")
        for field_name in (
            "actual_world_pose_before",
            "actual_world_pose_after",
        ):
            if not isinstance(getattr(self, field_name), MPCWorldPose):
                raise TypeError(f"{field_name} must be an MPCWorldPose")
        n_state = self.policy_result.initial_state.shape[0]
        for field_name in (
            "actual_model_state_before",
            "actual_model_state_after",
        ):
            object.__setattr__(
                self,
                field_name,
                _read_only_finite_array(
                    field_name,
                    getattr(self, field_name),
                    (n_state,),
                ),
            )
        for field_name in (
            "actual_reference_line_progress_before_metres",
            "actual_reference_line_progress_after_metres",
            "reward",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_float(field_name, getattr(self, field_name)),
            )
        for field_name in ("terminated", "truncated"):
            if not isinstance(getattr(self, field_name), bool):
                raise TypeError(f"{field_name} must be a bool")
        result = self.policy_result
        context = self.prediction_context
        execution = self.action_execution
        if result.action_request is None:
            raise ValueError("a completed transition requires an action request")
        if execution.policy_action_request is not result.action_request:
            raise ValueError(
                "action execution must retain the exact policy action request"
            )
        if not result.solve_usable and (
            result.action_request.planned_model_control is not None
        ):
            raise ValueError("fallback transitions must not contain planned control")
        if context is None:
            if result.solve_result is not None:
                raise ValueError(
                    "a solver outcome requires an attempted prediction context"
                )
            return
        if result.solve_result is None:
            raise ValueError(
                "a pre-solver policy result requires prediction_context=None"
            )
        context_road = context.road_horizon_context
        result_road = result.road_horizon_context
        if context_road is not None and context_road is result_road:
            raise ValueError(
                "prediction road horizon context must be detached from the "
                "policy result"
            )
        if not _road_horizon_contexts_equal(context_road, result_road):
            raise ValueError(
                "prediction and policy-result road horizon contexts must match"
            )
        if (
            context.actual_reference_line_progress_anchor_metres
            != self.actual_reference_line_progress_before_metres
        ):
            raise ValueError("prediction context anchor must equal pre-step progress")
        for result_name, context_name in (
            ("progress_schedule_metres", "progress_schedule_metres"),
            ("reference_speeds_mps", "reference_speeds_mps"),
            ("soft_speed_upper_bounds_mps", "soft_speed_upper_bounds_mps"),
            ("linearization_speeds_mps", "linearization_speeds_mps"),
        ):
            result_value = getattr(result, result_name)
            context_value = getattr(context, context_name)
            if (result_value is None) != (context_value is None):
                raise ValueError(f"{result_name} None state must match")
            if result_value is not None and not np.array_equal(
                result_value,
                context_value,
            ):
                raise ValueError(f"{result_name} values must match")
        has_current_progress = (
            context.predicted_relative_progress_metres is not None
        )
        if result.solve_usable != has_current_progress:
            raise ValueError(
                "current predicted progress must exist exactly for usable solves"
            )
        world_prediction = context.world_prediction
        unavailability_reason = context.world_projection_unavailability_reason
        if world_prediction is not None:
            if not result.solve_usable:
                raise ValueError(
                    "a retained world prediction requires a usable solve"
                )
            assert context.predicted_relative_progress_metres is not None
            if not np.array_equal(
                world_prediction.predicted_relative_reference_progress_metres,
                context.predicted_relative_progress_metres,
            ):
                raise ValueError(
                    "world prediction reference progress must match the current "
                    "prediction context"
                )
        elif context.world_prediction_capture_requested:
            if result.solve_usable and unavailability_reason is (
                MPCWorldProjectionUnavailabilityReason.NO_USABLE_PREDICTION
            ):
                raise ValueError(
                    "NO_USABLE_PREDICTION is invalid for a usable solve"
                )
            if not result.solve_usable and unavailability_reason is not (
                MPCWorldProjectionUnavailabilityReason.NO_USABLE_PREDICTION
            ):
                raise ValueError(
                    "an unusable solve requires NO_USABLE_PREDICTION"
                )
        if context.state_references.shape[1] != result.initial_state.shape[0]:
            raise ValueError(
                "context state width must equal the controller-visible state width"
            )
        prediction = (
            None
            if result.solve_result is None
            else result.solve_result.prediction
        )
        if prediction is not None and (
            context.state_references.shape != prediction.states.shape
            or context.control_references.shape != prediction.controls.shape
        ):
            raise ValueError(
                "context reference shapes must match the current prediction"
            )

    @property
    def controller_visible_model_state(self) -> np.ndarray:
        return _read_only_copy(self.policy_result.initial_state)

    @property
    def solve_status(self) -> str | None:
        return self.policy_result.solve_status

    @property
    def solve_usable(self) -> bool:
        return self.policy_result.solve_usable

    @property
    def policy_failure(self) -> MPCPolicyFailure | None:
        return self.policy_result.failure

    @property
    def fallback_mode(self):
        return self.policy_result.fallback_mode

    @property
    def fallback_action_used(self) -> bool:
        return self.policy_result.fallback_action_used

    @property
    def emitted_environment_action(self) -> np.ndarray:
        action = self.policy_result.environment_action
        assert action is not None
        return _read_only_copy(action)


def _freeze_tree(value: object) -> object:
    if isinstance(value, np.ndarray):
        return _read_only_copy(value)
    if isinstance(value, Mapping):
        return MappingProxyType(
            {str(key): _freeze_tree(item) for key, item in value.items()}
        )
    if isinstance(value, (tuple, list)):
        return tuple(_freeze_tree(item) for item in value)
    if isinstance(value, (str, int, float, bool, type(None), Enum)):
        return value
    raise TypeError(f"unsupported snapshot value: {type(value).__name__}")


def _optional_seed(name: str, value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer or None")
    converted = int(value)
    if converted < 0:
        raise ValueError(f"{name} must be nonnegative")
    return converted


def _thaw_tree(value: object) -> object:
    if isinstance(value, np.ndarray):
        return np.array(value, copy=True)
    if isinstance(value, Mapping):
        return {key: _thaw_tree(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(_thaw_tree(item) for item in value)
    return value


def _validate_simulation_snapshot(
    *,
    history_records: tuple[MPCTransitionRecord, ...],
    control_timestep_seconds: float,
    initial_state: np.ndarray,
    initial_progress: float,
    snapshot: Mapping[str, object],
) -> None:
    transition_count = len(history_records)
    required_arrays = (
        "time_index",
        "time_in_seconds",
        "reward",
        "vx",
        "lateral_error_from_target_line",
        "heading_angle_relative_to_target_line",
        "reference_line_progress_at_closest_point",
        "drive_command",
        "delta_request",
    )
    for key in required_arrays:
        if key not in snapshot or not isinstance(snapshot[key], np.ndarray):
            raise ValueError(f"simulation snapshot requires array {key!r}")
    allocated_length = snapshot["time_index"].shape[0]
    if allocated_length < transition_count + 1:
        raise ValueError("simulation snapshot is shorter than completed history")
    for key in required_arrays:
        if snapshot[key].ndim != 1 or snapshot[key].shape != (
            allocated_length,
        ):
            raise ValueError(
                f"simulation snapshot {key!r} must use the allocated length"
            )
    expected_time_index = np.arange(allocated_length)
    if not np.array_equal(snapshot["time_index"], expected_time_index):
        raise ValueError("simulation snapshot time_index is inconsistent")
    expected_times = expected_time_index * control_timestep_seconds
    if not np.allclose(
        snapshot["time_in_seconds"],
        expected_times,
        rtol=0.0,
        atol=1.0e-12,
    ):
        raise ValueError("simulation snapshot time_in_seconds is inconsistent")
    states = np.vstack(
        (
            initial_state,
            *(record.actual_model_state_after for record in history_records),
        )
    )
    progress = np.asarray(
        (
            initial_progress,
            *(
                record.actual_reference_line_progress_after_metres
                for record in history_records
            ),
        )
    )
    state_columns = (
        ("vx", 0),
        ("lateral_error_from_target_line", 1),
        ("heading_angle_relative_to_target_line", 2),
    )
    for key, column in state_columns:
        expected_prefix = np.asarray(
            states[:, column],
            dtype=snapshot[key].dtype,
        )
        if not np.array_equal(
            snapshot[key][: transition_count + 1],
            expected_prefix,
        ):
            raise ValueError(f"simulation snapshot {key} prefix disagrees")
        if not np.isnan(snapshot[key][transition_count + 1 :]).all():
            raise ValueError(f"simulation snapshot {key} padding must be NaN")
    progress_values = snapshot[
        "reference_line_progress_at_closest_point"
    ]
    expected_progress = np.asarray(progress, dtype=progress_values.dtype)
    if not np.array_equal(
        progress_values[: transition_count + 1],
        expected_progress,
    ):
        raise ValueError("simulation snapshot progress prefix disagrees")
    if not np.isnan(progress_values[transition_count + 1 :]).all():
        raise ValueError("simulation snapshot progress padding must be NaN")
    for index, record in enumerate(history_records):
        expected_reward = np.asarray(
            record.reward,
            dtype=snapshot["reward"].dtype,
        ).item()
        if snapshot["reward"][index] != expected_reward:
            raise ValueError("simulation snapshot reward prefix disagrees")
        expected_drive = np.asarray(
            record.action_execution.environment_normalized_drive_command_request,
            dtype=snapshot["drive_command"].dtype,
        ).item()
        if (
            snapshot["drive_command"][index]
            != expected_drive
        ):
            raise ValueError("simulation snapshot drive prefix disagrees")
        expected_steering = np.asarray(
            record.action_execution.environment_steering_request_radians,
            dtype=snapshot["delta_request"].dtype,
        ).item()
        if (
            snapshot["delta_request"][index]
            != expected_steering
        ):
            raise ValueError("simulation snapshot steering prefix disagrees")
    for key in ("reward", "drive_command", "delta_request"):
        if not np.isnan(snapshot[key][transition_count:]).all():
            raise ValueError(f"simulation snapshot {key} padding must be NaN")
    expected_terminated = (
        history_records[-1].terminated if history_records else False
    )
    expected_truncated = (
        history_records[-1].truncated if history_records else False
    )
    if snapshot.get("terminated") is not expected_terminated:
        raise ValueError("simulation snapshot terminated flag disagrees")
    if snapshot.get("truncated") is not expected_truncated:
        raise ValueError("simulation snapshot truncated flag disagrees")


@dataclass(frozen=True, slots=True, init=False)
class AutonomousDrivingMPCRolloutHistory:
    formulation: AutonomousDrivingMPCFormulation
    variable_metadata: MPCVariableMetadata
    control_timestep_seconds: float
    environment_seed: int | None
    policy_seed: int | None
    policy_was_reset: bool
    starting_policy_control_step: int
    policy_config_snapshot: Mapping[str, object]
    environment_binding_diagnostics: MPCEnvironmentBindingDiagnostics
    world_prediction_capture_requested: bool
    initial_actual_model_state: np.ndarray
    initial_actual_world_pose: MPCWorldPose
    initial_reference_line_progress_metres: float
    records: tuple[MPCTransitionRecord, ...]
    _simulation_time_series_snapshot: Mapping[str, object] = field(repr=False)

    @property
    def transition_count(self) -> int:
        return len(self.records)

    @property
    def final_actual_model_state(self) -> np.ndarray:
        source = (
            self.initial_actual_model_state
            if not self.records
            else self.records[-1].actual_model_state_after
        )
        return _read_only_copy(source)

    @property
    def final_reference_line_progress_metres(self) -> float:
        if not self.records:
            return self.initial_reference_line_progress_metres
        return self.records[-1].actual_reference_line_progress_after_metres

    @property
    def actual_state_times_seconds(self) -> np.ndarray:
        return _read_only_copy(
            np.arange(self.transition_count + 1)
            * self.control_timestep_seconds
        )

    @property
    def transition_times_seconds(self) -> np.ndarray:
        return _read_only_copy(
            np.arange(self.transition_count) * self.control_timestep_seconds
        )

    @property
    def simulation_time_series(self) -> dict[str, object]:
        return _thaw_tree(self._simulation_time_series_snapshot)

    @property
    def actual_model_states(self) -> np.ndarray:
        rows = [self.initial_actual_model_state]
        rows.extend(record.actual_model_state_after for record in self.records)
        return _read_only_copy(np.asarray(rows, dtype=np.float64))

    @property
    def actual_reference_line_progress_metres(self) -> np.ndarray:
        values = [self.initial_reference_line_progress_metres]
        values.extend(
            record.actual_reference_line_progress_after_metres
            for record in self.records
        )
        return _read_only_copy(np.asarray(values, dtype=np.float64))

    @property
    def actual_world_positions_metres(self) -> np.ndarray:
        positions = [self.initial_actual_world_pose.position_metres]
        positions.extend(
            record.actual_world_pose_after.position_metres
            for record in self.records
        )
        return _read_only_copy(np.asarray(positions, dtype=np.float64))

    @property
    def actual_world_headings_radians(self) -> np.ndarray:
        headings = [self.initial_actual_world_pose.heading_radians]
        headings.extend(
            record.actual_world_pose_after.heading_radians
            for record in self.records
        )
        return _read_only_copy(np.asarray(headings, dtype=np.float64))

    @property
    def world_prediction_available_mask(self) -> np.ndarray:
        return _read_only_copy(
            np.asarray(
                [
                    record.prediction_context is not None
                    and record.prediction_context.world_prediction is not None
                    for record in self.records
                ],
                dtype=np.bool_,
            )
        )

    @property
    def road_horizon_context_available_mask(self) -> np.ndarray:
        return _read_only_copy(
            np.asarray(
                [
                    record.prediction_context is not None
                    and record.prediction_context.road_horizon_context is not None
                    for record in self.records
                ],
                dtype=np.bool_,
            )
        )

    def _horizon_steps(self) -> int:
        return int(self.policy_config_snapshot["horizon_steps"])

    def _road_preview_point_count(self) -> int:
        distances = (
            self.environment_binding_diagnostics.environment
            .road_preview_distances_metres
        )
        return 0 if distances is None else len(distances)

    def _stack_optional_record_arrays(
        self,
        *,
        field_name: str,
        row_shape: tuple[int, ...],
        value_for_record,
    ) -> np.ndarray:
        values = np.full(
            (self.transition_count, *row_shape),
            np.nan,
            dtype=np.float64,
        )
        for index, record in enumerate(self.records):
            value = value_for_record(record)
            if value is None:
                continue
            array = np.asarray(value)
            if array.shape != row_shape:
                raise ValueError(
                    f"record {index} {field_name} must have shape "
                    f"{row_shape}, got {array.shape}"
                )
            values[index] = array
        return _read_only_copy(values)

    @staticmethod
    def _world_prediction_for_record(record: MPCTransitionRecord):
        context = record.prediction_context
        return None if context is None else context.world_prediction

    @staticmethod
    def _road_horizon_context_for_record(record: MPCTransitionRecord):
        context = record.prediction_context
        return None if context is None else context.road_horizon_context

    def _stack_world_prediction_array(
        self,
        *,
        field_name: str,
        row_shape: tuple[int, ...],
    ) -> np.ndarray:
        def value_for_record(record: MPCTransitionRecord):
            prediction = self._world_prediction_for_record(record)
            return None if prediction is None else getattr(prediction, field_name)

        return self._stack_optional_record_arrays(
            field_name=field_name,
            row_shape=row_shape,
            value_for_record=value_for_record,
        )

    def _stack_road_horizon_array(
        self,
        *,
        field_name: str,
        row_shape: tuple[int, ...],
    ) -> np.ndarray:
        def value_for_record(record: MPCTransitionRecord):
            road_context = self._road_horizon_context_for_record(record)
            return (
                None
                if road_context is None
                else getattr(road_context, field_name)
            )

        return self._stack_optional_record_arrays(
            field_name=field_name,
            row_shape=row_shape,
            value_for_record=value_for_record,
        )

    @property
    def predicted_world_positions_metres(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="predicted_vehicle_positions_metres",
            row_shape=(self._horizon_steps() + 1, 2),
        )

    @property
    def predicted_world_headings_radians(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="predicted_vehicle_headings_radians",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def formulation_target_world_positions_metres(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="formulation_target_line_positions_metres",
            row_shape=(self._horizon_steps() + 1, 2),
        )

    @property
    def formulation_target_world_headings_radians(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="formulation_target_line_headings_radians",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def source_preview_target_world_positions_metres(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="source_preview_target_line_positions_metres",
            row_shape=(self._road_preview_point_count(), 2),
        )

    @property
    def projected_installed_right_lane_bounds_metres(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="installed_right_lane_bound_positions_metres",
            row_shape=(self._horizon_steps(), 2),
        )

    @property
    def projected_installed_left_lane_bounds_metres(self) -> np.ndarray:
        return self._stack_world_prediction_array(
            field_name="installed_left_lane_bound_positions_metres",
            row_shape=(self._horizon_steps(), 2),
        )

    @property
    def road_preview_source_validity(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="source_validity",
            row_shape=(self._road_preview_point_count(),),
        )

    @property
    def road_preview_query_distances_metres(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="road_preview_query_distances_metres",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def interpolated_target_line_curvatures_per_metre(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="interpolated_target_line_curvatures_per_metre",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def interpolated_recommended_speeds_mps(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="interpolated_recommended_speeds_mps",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def interpolated_speed_limits_mps(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="interpolated_speed_limits_mps",
            row_shape=(self._horizon_steps() + 1,),
        )

    @property
    def installed_soft_lateral_error_lower_bounds_metres(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="installed_soft_lateral_error_lower_bounds_metres",
            row_shape=(self._horizon_steps(),),
        )

    @property
    def installed_soft_lateral_error_upper_bounds_metres(self) -> np.ndarray:
        return self._stack_road_horizon_array(
            field_name="installed_soft_lateral_error_upper_bounds_metres",
            row_shape=(self._horizon_steps(),),
        )

    @property
    def controller_visible_model_states(self) -> np.ndarray:
        if not self.records:
            values = np.empty((0, len(self.variable_metadata.state_names)))
        else:
            values = np.stack(
                [record.controller_visible_model_state for record in self.records]
            )
        return _read_only_copy(values)

    @property
    def emitted_environment_actions(self) -> np.ndarray:
        if not self.records:
            values = np.empty((0, 2))
        else:
            values = np.stack(
                [record.emitted_environment_action for record in self.records]
            )
        return _read_only_copy(values)

    @property
    def applied_control_comparators(self) -> np.ndarray:
        values = np.empty((self.transition_count, 2), dtype=np.float64)
        for index, record in enumerate(self.records):
            execution = record.action_execution
            values[index, 0] = execution.applied_normalized_drive_command
            if self.formulation in (
                AutonomousDrivingMPCFormulation.DIRECT_STEERING,
                AutonomousDrivingMPCFormulation.ROAD_AWARE_DIRECT_STEERING,
            ):
                values[index, 1] = (
                    execution.environment_steering_target_radians
                )
            elif self.formulation in (
                AutonomousDrivingMPCFormulation.STEERING_RATE,
                AutonomousDrivingMPCFormulation.ROAD_AWARE_STEERING_RATE,
            ):
                values[index, 1] = (
                    execution.applied_steering_rate_radians_per_second
                )
            else:
                raise ValueError("unsupported MPC formulation")
        return _read_only_copy(values)

    @property
    def realized_steering_angles_radians(self) -> np.ndarray:
        return _read_only_copy(
            np.asarray(
                [
                    record.action_execution.realized_steering_angle_radians
                    for record in self.records
                ],
                dtype=np.float64,
            )
        )

    @property
    def prediction_available_mask(self) -> np.ndarray:
        return _read_only_copy(
            np.asarray(
                [record.solve_usable for record in self.records],
                dtype=np.bool_,
            )
        )

    def _stack_predictions(self, *, states: bool) -> np.ndarray:
        horizon_steps = int(self.policy_config_snapshot["horizon_steps"])
        width = (
            len(self.variable_metadata.state_names)
            if states
            else len(self.variable_metadata.control_names)
        )
        row_count = horizon_steps + 1 if states else horizon_steps
        values = np.full(
            (self.transition_count, row_count, width),
            np.nan,
            dtype=np.float64,
        )
        for index, record in enumerate(self.records):
            solve_result = record.policy_result.solve_result
            prediction = (
                None if solve_result is None else solve_result.prediction
            )
            if prediction is not None:
                values[index] = (
                    prediction.states if states else prediction.controls
                )
        return _read_only_copy(values)

    @property
    def predicted_states(self) -> np.ndarray:
        return self._stack_predictions(states=True)

    @property
    def predicted_controls(self) -> np.ndarray:
        return self._stack_predictions(states=False)

    def alignment_at(
        self,
        transition_index: int,
    ) -> MPCTransitionAlignment:
        if isinstance(transition_index, bool) or not isinstance(
            transition_index,
            Integral,
        ):
            raise TypeError("transition_index must be an integer")
        index = int(transition_index)
        if not 0 <= index < self.transition_count:
            raise IndexError("transition_index is outside the rollout")
        horizon_steps = int(self.policy_config_snapshot["horizon_steps"])
        record = self.records[index]
        state_times = (
            record.time_seconds
            + np.arange(horizon_steps + 1) * self.control_timestep_seconds
        )
        control_times = (
            record.time_seconds
            + np.arange(horizon_steps) * self.control_timestep_seconds
        )
        actual_states = self.actual_model_states[
            index : index + horizon_steps + 1
        ]
        actual_controls = self.applied_control_comparators[
            index : index + horizon_steps
        ]
        state_mask = np.arange(horizon_steps + 1) < actual_states.shape[0]
        control_mask = np.arange(horizon_steps) < actual_controls.shape[0]
        solve_result = record.policy_result.solve_result
        prediction = (
            None if solve_result is None else solve_result.prediction
        )
        return MPCTransitionAlignment(
            transition_index=index,
            prediction_available=prediction is not None,
            predicted_state_times_seconds=state_times,
            predicted_control_times_seconds=control_times,
            actual_state_times_seconds=state_times[: actual_states.shape[0]],
            actual_control_times_seconds=control_times[
                : actual_controls.shape[0]
            ],
            predicted_states=(
                None if prediction is None else prediction.states
            ),
            predicted_controls=(
                None if prediction is None else prediction.controls
            ),
            actual_states=actual_states,
            actual_controls=actual_controls,
            state_availability_mask=state_mask,
            control_availability_mask=control_mask,
        )


@dataclass(frozen=True, slots=True)
class MPCTransitionAlignment:
    transition_index: int
    prediction_available: bool
    predicted_state_times_seconds: np.ndarray
    predicted_control_times_seconds: np.ndarray
    actual_state_times_seconds: np.ndarray
    actual_control_times_seconds: np.ndarray
    predicted_states: np.ndarray | None
    predicted_controls: np.ndarray | None
    actual_states: np.ndarray
    actual_controls: np.ndarray
    state_availability_mask: np.ndarray
    control_availability_mask: np.ndarray

    def __post_init__(self) -> None:
        if isinstance(self.transition_index, bool) or not isinstance(
            self.transition_index,
            Integral,
        ):
            raise TypeError("transition_index must be an integer")
        transition_index = int(self.transition_index)
        if transition_index < 0:
            raise ValueError("transition_index must be nonnegative")
        object.__setattr__(self, "transition_index", transition_index)
        if not isinstance(self.prediction_available, bool):
            raise TypeError("prediction_available must be a bool")

        predicted_state_times = np.asarray(
            self.predicted_state_times_seconds
        )
        predicted_control_times = np.asarray(
            self.predicted_control_times_seconds
        )
        if predicted_state_times.ndim != 1:
            raise ValueError("predicted state times must be one-dimensional")
        if predicted_control_times.ndim != 1:
            raise ValueError("predicted control times must be one-dimensional")
        n_state_rows = predicted_state_times.shape[0]
        n_control_rows = predicted_control_times.shape[0]
        if n_state_rows != n_control_rows + 1 or n_control_rows <= 0:
            raise ValueError("alignment must contain N controls and N + 1 states")
        predicted_state_times = _read_only_finite_array(
            "predicted_state_times_seconds",
            self.predicted_state_times_seconds,
            (n_state_rows,),
        )
        predicted_control_times = _read_only_finite_array(
            "predicted_control_times_seconds",
            self.predicted_control_times_seconds,
            (n_control_rows,),
        )
        actual_state_times = np.asarray(self.actual_state_times_seconds)
        actual_control_times = np.asarray(self.actual_control_times_seconds)
        if actual_state_times.ndim != 1 or actual_control_times.ndim != 1:
            raise ValueError("actual alignment times must be one-dimensional")
        actual_state_count = actual_state_times.shape[0]
        actual_control_count = actual_control_times.shape[0]
        if actual_state_count > n_state_rows or actual_control_count > n_control_rows:
            raise ValueError("actual suffix cannot exceed the prediction horizon")
        actual_state_times = _read_only_finite_array(
            "actual_state_times_seconds",
            self.actual_state_times_seconds,
            (actual_state_count,),
        )
        actual_control_times = _read_only_finite_array(
            "actual_control_times_seconds",
            self.actual_control_times_seconds,
            (actual_control_count,),
        )
        if not np.array_equal(
            actual_state_times,
            predicted_state_times[:actual_state_count],
        ) or not np.array_equal(
            actual_control_times,
            predicted_control_times[:actual_control_count],
        ):
            raise ValueError("actual times must be prediction-grid prefixes")

        actual_states = np.asarray(self.actual_states)
        actual_controls = np.asarray(self.actual_controls)
        if actual_states.ndim != 2 or actual_controls.ndim != 2:
            raise ValueError("actual aligned values must be two-dimensional")
        n_state = actual_states.shape[1]
        n_control = actual_controls.shape[1]
        if n_state <= 0 or n_control <= 0:
            raise ValueError("alignment variable widths must be positive")
        actual_states = _read_only_finite_array(
            "actual_states",
            self.actual_states,
            (actual_state_count, n_state),
        )
        actual_controls = _read_only_finite_array(
            "actual_controls",
            self.actual_controls,
            (actual_control_count, n_control),
        )

        state_mask = np.asarray(self.state_availability_mask)
        control_mask = np.asarray(self.control_availability_mask)
        if state_mask.dtype.kind != "b" or state_mask.shape != (n_state_rows,):
            raise ValueError("state availability mask must be Boolean length N + 1")
        if control_mask.dtype.kind != "b" or control_mask.shape != (
            n_control_rows,
        ):
            raise ValueError("control availability mask must be Boolean length N")
        if not np.array_equal(
            state_mask,
            np.arange(n_state_rows) < actual_state_count,
        ) or not np.array_equal(
            control_mask,
            np.arange(n_control_rows) < actual_control_count,
        ):
            raise ValueError("availability masks must mark only actual prefixes")

        predicted_states = self.predicted_states
        predicted_controls = self.predicted_controls
        if self.prediction_available:
            if predicted_states is None or predicted_controls is None:
                raise ValueError(
                    "available prediction requires state and control arrays"
                )
            predicted_states = _read_only_finite_array(
                "predicted_states",
                predicted_states,
                (n_state_rows, n_state),
            )
            predicted_controls = _read_only_finite_array(
                "predicted_controls",
                predicted_controls,
                (n_control_rows, n_control),
            )
        elif predicted_states is not None or predicted_controls is not None:
            raise ValueError("unavailable prediction must store None arrays")

        for field_name, value in (
            ("predicted_state_times_seconds", predicted_state_times),
            ("predicted_control_times_seconds", predicted_control_times),
            ("actual_state_times_seconds", actual_state_times),
            ("actual_control_times_seconds", actual_control_times),
            ("actual_states", actual_states),
            ("actual_controls", actual_controls),
            ("state_availability_mask", _read_only_copy(state_mask)),
            ("control_availability_mask", _read_only_copy(control_mask)),
            ("predicted_states", predicted_states),
            ("predicted_controls", predicted_controls),
        ):
            object.__setattr__(self, field_name, value)


def _create_mpc_rollout_history(
    *,
    formulation,
    variable_metadata,
    control_timestep_seconds,
    environment_seed,
    policy_seed,
    policy_was_reset,
    starting_policy_control_step,
    policy_config_snapshot,
    environment_binding_diagnostics,
    world_prediction_capture_requested,
    initial_actual_model_state,
    initial_actual_world_pose,
    initial_reference_line_progress_metres,
    records,
    simulation_time_series_snapshot,
) -> AutonomousDrivingMPCRolloutHistory:
    if not isinstance(formulation, AutonomousDrivingMPCFormulation):
        raise TypeError("formulation must be an AutonomousDrivingMPCFormulation")
    if not isinstance(variable_metadata, MPCVariableMetadata):
        raise TypeError("variable_metadata must be MPCVariableMetadata")
    timestep = _finite_float(
        "control_timestep_seconds",
        control_timestep_seconds,
    )
    if timestep <= 0.0:
        raise ValueError("control_timestep_seconds must be positive")
    if not isinstance(policy_was_reset, bool):
        raise TypeError("policy_was_reset must be a bool")
    if not isinstance(world_prediction_capture_requested, bool):
        raise TypeError("world_prediction_capture_requested must be a bool")
    if isinstance(starting_policy_control_step, bool) or not isinstance(
        starting_policy_control_step,
        Integral,
    ):
        raise TypeError("starting_policy_control_step must be an integer")
    starting_step = int(starting_policy_control_step)
    if starting_step < 0:
        raise ValueError("starting_policy_control_step must be nonnegative")
    if not isinstance(records, tuple) or not all(
        isinstance(record, MPCTransitionRecord) for record in records
    ):
        raise TypeError("records must be a tuple of MPCTransitionRecord")
    if not isinstance(
        environment_binding_diagnostics,
        MPCEnvironmentBindingDiagnostics,
    ):
        raise TypeError(
            "environment_binding_diagnostics must be "
            "MPCEnvironmentBindingDiagnostics"
        )
    if not isinstance(initial_actual_world_pose, MPCWorldPose):
        raise TypeError("initial_actual_world_pose must be an MPCWorldPose")

    initial_state = _read_only_finite_array(
        "initial_actual_model_state",
        initial_actual_model_state,
        (len(variable_metadata.state_names),),
    )
    initial_progress = _finite_float(
        "initial_reference_line_progress_metres",
        initial_reference_line_progress_metres,
    )
    frozen_config = _freeze_tree(policy_config_snapshot)
    frozen_simulation = _freeze_tree(simulation_time_series_snapshot)
    if not isinstance(frozen_config, Mapping):
        raise TypeError("policy_config_snapshot must be a mapping")
    if not isinstance(frozen_simulation, Mapping):
        raise TypeError("simulation_time_series_snapshot must be a mapping")
    horizon_steps = frozen_config.get("horizon_steps")
    if isinstance(horizon_steps, bool) or not isinstance(horizon_steps, Integral):
        raise TypeError("policy_config_snapshot horizon_steps must be an integer")
    horizon_steps = int(horizon_steps)
    if horizon_steps <= 0:
        raise ValueError("policy_config_snapshot horizon_steps must be positive")

    previous_state = initial_state
    previous_world_pose = initial_actual_world_pose
    previous_progress = initial_progress
    for index, record in enumerate(records):
        if record.transition_index != index:
            raise ValueError("record transition indices must be local and contiguous")
        if record.policy_result.control_step_index != starting_step + index:
            raise ValueError("policy control steps must continue from starting step")
        if not math.isclose(
            record.time_seconds,
            index * timestep,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise ValueError("record time_seconds must equal local index times Ts")
        context = record.prediction_context
        if context is not None and context.control_references.shape != (
            horizon_steps,
            len(variable_metadata.control_names),
        ):
            raise ValueError("record horizon/control width does not match metadata")
        if (
            context is not None
            and context.world_prediction_capture_requested
            != world_prediction_capture_requested
        ):
            raise ValueError(
                "record world-prediction capture flag must match the history "
                "capture flag"
            )
        world_prediction = None if context is None else context.world_prediction
        if world_prediction is not None:
            if world_prediction.formulation is not formulation:
                raise ValueError(
                    "world prediction formulation must match the history formulation"
                )
            if world_prediction.predicted_vehicle_positions_metres.shape[0] != (
                horizon_steps + 1
            ):
                raise ValueError(
                    "world prediction horizon must match the history configuration"
                )
        if record.actual_model_state_before.shape != initial_state.shape:
            raise ValueError("record state width does not match metadata")
        if not np.array_equal(record.actual_model_state_before, previous_state):
            raise ValueError("record state continuity is broken")
        if not _world_poses_equal(
            record.actual_world_pose_before,
            previous_world_pose,
        ):
            raise ValueError("record world pose continuity is broken")
        if (
            record.actual_reference_line_progress_before_metres
            != previous_progress
        ):
            raise ValueError("record progress continuity is broken")
        previous_state = record.actual_model_state_after
        previous_world_pose = record.actual_world_pose_after
        previous_progress = (
            record.actual_reference_line_progress_after_metres
        )

    _validate_simulation_snapshot(
        history_records=records,
        control_timestep_seconds=timestep,
        initial_state=initial_state,
        initial_progress=initial_progress,
        snapshot=frozen_simulation,
    )

    history = object.__new__(AutonomousDrivingMPCRolloutHistory)
    values = {
        "formulation": formulation,
        "variable_metadata": variable_metadata,
        "control_timestep_seconds": timestep,
        "environment_seed": _optional_seed("environment_seed", environment_seed),
        "policy_seed": _optional_seed("policy_seed", policy_seed),
        "policy_was_reset": policy_was_reset,
        "starting_policy_control_step": starting_step,
        "policy_config_snapshot": frozen_config,
        "environment_binding_diagnostics": environment_binding_diagnostics,
        "world_prediction_capture_requested": world_prediction_capture_requested,
        "initial_actual_model_state": initial_state,
        "initial_actual_world_pose": initial_actual_world_pose,
        "initial_reference_line_progress_metres": initial_progress,
        "records": records,
        "_simulation_time_series_snapshot": frozen_simulation,
    }
    for field_name, value in values.items():
        object.__setattr__(history, field_name, value)
    return history


class MPCRolloutAbortedError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        partial_history: AutonomousDrivingMPCRolloutHistory,
        failed_policy_result: MPCPolicyResult,
        attempted_prediction_context: MPCPredictionContext | None,
        transition_index: int,
    ) -> None:
        super().__init__(message)
        self.partial_history = partial_history
        self.failed_policy_result = failed_policy_result
        self.attempted_prediction_context = attempted_prediction_context
        self.transition_index = transition_index
