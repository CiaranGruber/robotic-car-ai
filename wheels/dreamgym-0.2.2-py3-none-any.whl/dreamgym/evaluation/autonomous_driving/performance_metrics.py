"""Performance metrics for autonomous-driving rollout time series.

Built-in metric index:
- reward_sum
- reward_mean
- reward_std
- reward_min
- reward_max
- mean_abs_lateral_error_m
- median_abs_lateral_error_m
- rms_lateral_error_m
- std_lateral_error_m
- max_abs_lateral_error_m
- mean_abs_heading_error_rad
- max_abs_heading_error_rad
- mean_speed_relative_to_recommended_kph
- mean_abs_speed_error_to_recommended_kph
- max_speed_above_recommended_kph
- fraction_time_above_recommended_speed
- mean_speed_relative_to_limit_kph
- max_speed_limit_exceedance_kph
- mean_speed_limit_exceedance_kph
- fraction_time_above_speed_limit
- final_progress_m
- progress_delta_m
- duration_s
- steps_completed
- terminated_flag
- truncated_flag
- incomplete_rollout_flag
- completion_fraction
- mean_abs_drive_command
- rms_drive_command
- mean_abs_delta_request_rad
- rms_delta_request_rad
- mean_abs_acceleration_mps2
- max_abs_acceleration_mps2
- mean_abs_jerk_mps3
- max_abs_jerk_mps3
- mean_abs_steering_rate_radps
- max_abs_steering_rate_radps
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from enum import Enum
from itertools import product
from typing import Mapping

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCRolloutHistory,
)
from dreamgym.evaluation.performance_metrics import (
    MetricSet,
    PerformanceMetric,
    PerformanceMetricResults,
    PolicySpec,
    aggregate_metric_rows,
    compute_metric_values,
)


class SweepMode(str, Enum):
    FULL_FACTORIAL = "full_factorial"
    MONTE_CARLO = "monte_carlo"


_ROLLOUT_INDEX_METADATA_KEYS = frozenset(
    {
        "policy_name",
        "rollout_index",
        "terminated",
        "truncated",
        "steps_recorded",
    }
)


@dataclass(frozen=True)
class ParameterSample:
    values: dict
    appliers: tuple

    def apply_to_env_kwargs(self, base_env_kwargs: dict) -> tuple[dict, dict]:
        env_kwargs = deepcopy(base_env_kwargs)
        post_create: dict = {}
        for applier in self.appliers:
            applier(env_kwargs, post_create, self.values)
        return env_kwargs, post_create


@dataclass(frozen=True)
class UniformMultiplierParameter:
    name: str
    path: tuple[str, ...]
    low: float
    high: float
    samples: int | None = None

    def grid_values(self):
        count = int(self.samples or 1)
        return np.linspace(self.low, self.high, count).tolist()

    def monte_carlo_value(self, rng):
        return float(rng.uniform(self.low, self.high))

    def applier(self):
        def apply(env_kwargs, post_create, values):
            target = env_kwargs
            for key in self.path[:-1]:
                target = target.setdefault(key, {})
            final_key = self.path[-1]
            target[final_key] = float(target[final_key]) * float(values[self.name])

        return apply


@dataclass(frozen=True)
class UniformOffsetParameter:
    name: str
    path: tuple[str, ...]
    low: float
    high: float
    samples: int | None = None

    def grid_values(self):
        count = int(self.samples or 1)
        return np.linspace(self.low, self.high, count).tolist()

    def monte_carlo_value(self, rng):
        return float(rng.uniform(self.low, self.high))

    def applier(self):
        def apply(env_kwargs, post_create, values):
            target = env_kwargs
            for key in self.path[:-1]:
                target = target.setdefault(key, {})
            target[self.path[-1]] = float(values[self.name])

        return apply


@dataclass(frozen=True)
class ChoiceParameter:
    name: str
    values: tuple | list

    def grid_values(self):
        return list(self.values)

    def monte_carlo_value(self, rng):
        values = list(self.values)
        return values[int(rng.integers(0, len(values)))]

    def applier(self):
        def apply(env_kwargs, post_create, values):
            if self.name == "tire_force_condition":
                post_create["tire_force_condition"] = values[self.name]
            else:
                env_kwargs[self.name] = values[self.name]

        return apply


@dataclass(frozen=True)
class SeedParameter:
    name: str
    values: object

    def grid_values(self):
        return list(self.values)

    def monte_carlo_value(self, rng):
        values = list(self.values)
        return int(values[int(rng.integers(0, len(values)))])

    def applier(self):
        def apply(env_kwargs, post_create, values):
            post_create[self.name] = int(values[self.name])

        return apply


@dataclass(frozen=True)
class ObservationNoiseSeedParameter:
    values: object
    name: str = field(default="fixed_noise_seed", init=False)

    def grid_values(self):
        return list(self.values)

    def monte_carlo_value(self, rng):
        values = list(self.values)
        return int(values[int(rng.integers(0, len(values)))])

    def applier(self):
        def apply(env_kwargs, post_create, values):
            observation_config = env_kwargs.setdefault("observation_config", {})
            observation_config["fixed_noise_seed"] = int(values[self.name])

        return apply


@dataclass(frozen=True)
class PolicySeedParameter:
    values: object
    name: str = "policy_seed"

    def grid_values(self):
        return list(self.values)

    def monte_carlo_value(self, rng):
        values = list(self.values)
        return int(values[int(rng.integers(0, len(values)))])

    def applier(self):
        def apply(env_kwargs, post_create, values):
            post_create[self.name] = int(values[self.name])

        return apply


_INITIAL_STATE_VALUE_PATHS = frozenset(
    {
        ("world_pose", "x_m"),
        ("world_pose", "y_m"),
        ("world_pose", "heading_rad"),
        ("body_motion", "longitudinal_velocity_mps"),
        ("body_motion", "lateral_velocity_mps"),
        ("body_motion", "yaw_rate_rad_per_s"),
        ("front_wheel_steering_angle_rad",),
    }
)
_OBSERVATION_NOISE_PATHS = frozenset(
    {
        ("body_longitudinal_velocity_mps", "noise_standard_deviation_mps"),
        ("front_wheel_steering_angle_rad", "noise_standard_deviation_rad"),
        ("lateral_error_from_target_line_m", "noise_standard_deviation_m"),
        ("heading_error_from_target_line_rad", "noise_standard_deviation_rad"),
        (
            "target_line_offset_from_reference_line_m",
            "noise_standard_deviation_m",
        ),
        (
            "lateral_error_from_reference_line_m",
            "noise_standard_deviation_m",
        ),
        ("yaw_rate_rad_per_s", "noise_standard_deviation_rad_per_s"),
        (
            "target_line_position_at_closest_reference_line_progress_in_body_frame_m",
            "noise_standard_deviation_m",
        ),
        (
            "reference_line_closest_point_position_in_body_frame_m",
            "noise_standard_deviation_m",
        ),
        ("target_line_curvature_per_m", "noise_standard_deviation_per_m"),
        (
            "target_line_lookahead",
            "acquisition",
            "position_error_in_body_frame",
            "forward",
            "noise_standard_deviation_m",
        ),
        (
            "target_line_lookahead",
            "acquisition",
            "position_error_in_body_frame",
            "left",
            "noise_standard_deviation_m",
        ),
        (
            "target_line_lookahead",
            "acquisition",
            "curvature_error",
            "noise_standard_deviation_per_m",
        ),
        (
            "target_line_lookahead",
            "acquisition",
            "query_distance_error",
            "noise_standard_deviation_m",
        ),
        (
            "target_line_lookahead",
            "acquisition",
            "query_distance_error",
            "random_walk_standard_deviation_m_per_sqrt_s",
        ),
        (
            "road_preview",
            "acquisition",
            "query_origin_error_along_target_line",
            "noise_standard_deviation_m",
        ),
        (
            "road_preview",
            "acquisition",
            "query_origin_error_along_target_line",
            "random_walk_standard_deviation_m_per_sqrt_s",
        ),
        *(
            (
                "road_preview",
                "acquisition",
                "output_errors",
                record_name,
                noise_name,
            )
            for record_name, noise_name in (
                (
                    "target_line_curvatures_per_m",
                    "noise_standard_deviation_per_m",
                ),
                ("recommended_speeds_mps", "noise_standard_deviation_mps"),
                ("speed_limits_mps", "noise_standard_deviation_mps"),
                (
                    "right_lane_bound_offsets_from_target_line_m",
                    "noise_standard_deviation_m",
                ),
                (
                    "left_lane_bound_offsets_from_target_line_m",
                    "noise_standard_deviation_m",
                ),
            )
        ),
        (
            "cone_detections",
            "acquisition",
            "position_error_in_body_frame",
            "forward",
            "noise_standard_deviation_m",
        ),
        (
            "cone_detections",
            "acquisition",
            "position_error_in_body_frame",
            "left",
            "noise_standard_deviation_m",
        ),
    }
)


def _validate_parameter_name_and_path(name, path, *, allowed_paths):
    if type(name) is not str or not name:
        raise TypeError("name must be a non-empty string")
    if type(path) is not tuple:
        raise TypeError("path must be a tuple")
    if path not in allowed_paths:
        raise ValueError("path is not a supported final configuration path")


def _nested_target(root, path):
    target = root
    for key in path:
        target = target.setdefault(key, {})
        if not isinstance(target, dict):
            raise TypeError("configuration path crosses a non-mapping value")
    return target


@dataclass(frozen=True)
class UniformObservationNoiseParameter:
    name: str
    path: tuple[str, ...]
    low: float
    high: float
    samples: int | None = None

    def __post_init__(self):
        _validate_parameter_name_and_path(
            self.name,
            self.path,
            allowed_paths=_OBSERVATION_NOISE_PATHS,
        )

    def grid_values(self):
        count = int(self.samples or 1)
        return np.linspace(self.low, self.high, count).tolist()

    def monte_carlo_value(self, rng):
        return float(rng.uniform(self.low, self.high))

    def applier(self):
        def apply(env_kwargs, post_create, values):
            observation_config = env_kwargs.setdefault("observation_config", {})
            target = _nested_target(observation_config, self.path[:-1])
            target[self.path[-1]] = float(values[self.name])

        return apply


@dataclass(frozen=True)
class InitialStateValueParameter:
    name: str
    path: tuple[str, ...]
    low: float
    high: float
    samples: int | None = None

    def __post_init__(self):
        _validate_parameter_name_and_path(
            self.name,
            self.path,
            allowed_paths=_INITIAL_STATE_VALUE_PATHS,
        )

    def grid_values(self):
        count = int(self.samples or 1)
        return np.linspace(self.low, self.high, count).tolist()

    def monte_carlo_value(self, rng):
        return float(rng.uniform(self.low, self.high))

    def applier(self):
        def apply(env_kwargs, post_create, values):
            initial_state_config = env_kwargs.setdefault(
                "initial_state_config",
                {},
            )
            bounds = initial_state_config.setdefault("bounds", {})
            value = float(values[self.name])
            target = _nested_target(bounds, self.path[:-1])
            target[self.path[-1]] = {"lower": value, "upper": value}

        return apply


@dataclass(frozen=True)
class RoadRandomizationParameter:
    name: str
    config: dict
    values: object

    def grid_values(self):
        return list(self.values)

    def monte_carlo_value(self, rng):
        values = list(self.values)
        return int(values[int(rng.integers(0, len(values)))])

    def applier(self):
        def apply(env_kwargs, post_create, values):
            from dreamgym.envs.road import Road

            if values[self.name] is None:
                return
            seed = int(values[self.name])
            env_kwargs["road_spec"] = Road.generate_random_spec(
                generation_config=self.config,
                seed=seed,
            )

        return apply


@dataclass(frozen=True)
class UncertaintySweep:
    parameters: tuple
    mode: SweepMode
    sample_count: int | None = None
    seed: int = 0

    def __post_init__(self):
        object.__setattr__(self, "parameters", tuple(self.parameters))
        names = tuple(parameter.name for parameter in self.parameters)
        non_string_names = tuple(
            repr(name)
            for name in names
            if not isinstance(name, str)
        )
        if non_string_names:
            raise TypeError(
                "Sweep parameter names must be strings: "
                + ", ".join(non_string_names)
            )
        empty_names = tuple(repr(name) for name in names if not name)
        if empty_names:
            raise ValueError(
                "Sweep parameter names must be non-empty: "
                + ", ".join(empty_names)
            )
        duplicate_names = tuple(
            sorted({name for name in names if names.count(name) > 1})
        )
        if duplicate_names:
            raise ValueError(
                "Duplicate sweep parameter names: "
                + ", ".join(duplicate_names)
            )
        metadata_collisions = tuple(
            sorted(set(names) & _ROLLOUT_INDEX_METADATA_KEYS)
        )
        if metadata_collisions:
            raise ValueError(
                "Sweep parameter names collide with rollout-index metadata: "
                + ", ".join(metadata_collisions)
            )

    @classmethod
    def full_factorial(cls, parameters):
        return cls(parameters=tuple(parameters), mode=SweepMode.FULL_FACTORIAL)

    @classmethod
    def monte_carlo(cls, parameters, *, samples: int, seed: int = 0):
        return cls(
            parameters=tuple(parameters),
            mode=SweepMode.MONTE_CARLO,
            sample_count=int(samples),
            seed=int(seed),
        )

    def samples(self):
        if self.mode == SweepMode.FULL_FACTORIAL:
            grids = [parameter.grid_values() for parameter in self.parameters]
            for combo in product(*grids):
                values = {
                    parameter.name: value
                    for parameter, value in zip(self.parameters, combo)
                }
                yield ParameterSample(
                    values=values,
                    appliers=tuple(parameter.applier() for parameter in self.parameters),
                )
            return

        rng = np.random.default_rng(self.seed)
        for _ in range(int(self.sample_count or 0)):
            values = {
                parameter.name: parameter.monte_carlo_value(rng)
                for parameter in self.parameters
            }
            yield ParameterSample(
                values=values,
                appliers=tuple(parameter.applier() for parameter in self.parameters),
            )


_DEFAULT_SWEEP_ROAD_RANDOMIZATION_CONFIG = {
    "element_count_range": {"lower": 4, "upper": 6},
    "straight_element_probability": 0.45,
    "straight": {"length_range_m": {"lower": 35.0, "upper": 120.0}},
    "circular_arc": {
        "radius_range_m": {"lower": 90.0, "upper": 350.0},
        "sweep_angle_range_deg": {"lower": 8.0, "upper": 35.0},
    },
    "speed_limit_range_kph": {"lower": 50.0, "upper": 90.0},
    "first_element": {
        "require_straight": True,
        "straight_length_range_m": {"lower": 20.0, "upper": 60.0},
    },
    "initial_cross_section": {
        "reference_line_role": "lane_boundary",
        "left_lane_width_range_m": {"lower": 3.0, "upper": 3.8},
    },
}


def quick_uncertainty_sweep() -> UncertaintySweep:
    return UncertaintySweep.full_factorial([
        UniformMultiplierParameter(
            "mass_multiplier",
            ("bicycle_model_config", "mass_properties", "mass_kg"),
            0.98,
            1.02,
            samples=2,
        ),
        UniformMultiplierParameter(
            "inertia_multiplier",
            (
                "bicycle_model_config",
                "mass_properties",
                "yaw_moment_of_inertia_kg_m2",
            ),
            0.98,
            1.02,
            samples=2,
        ),
        UniformOffsetParameter(
            "steering_offset_rad",
            (
                "bicycle_model_config",
                "steering",
                "physical_front_wheel_angle_offset_from_request_rad",
            ),
            -0.5 * np.pi / 180.0,
            0.5 * np.pi / 180.0,
            samples=2,
        ),
        ChoiceParameter("tire_force_condition", ["dry"]),
        RoadRandomizationParameter(
            "road_seed",
            config=_DEFAULT_SWEEP_ROAD_RANDOMIZATION_CONFIG,
            values=[None, 0],
        ),
        ObservationNoiseSeedParameter(values=[0]),
        UniformObservationNoiseParameter(
            "body_longitudinal_velocity_noise_standard_deviation_mps",
            (
                "body_longitudinal_velocity_mps",
                "noise_standard_deviation_mps",
            ),
            0.0,
            0.2,
            samples=2,
        ),
        PolicySeedParameter(values=[0]),
        SeedParameter("rollout_seed", range(2)),
    ])


def final_uncertainty_sweep() -> UncertaintySweep:
    return UncertaintySweep.monte_carlo([
        UniformMultiplierParameter(
            "mass_multiplier",
            ("bicycle_model_config", "mass_properties", "mass_kg"),
            0.95,
            1.05,
        ),
        UniformMultiplierParameter(
            "inertia_multiplier",
            (
                "bicycle_model_config",
                "mass_properties",
                "yaw_moment_of_inertia_kg_m2",
            ),
            0.95,
            1.05,
        ),
        UniformOffsetParameter(
            "steering_offset_rad",
            (
                "bicycle_model_config",
                "steering",
                "physical_front_wheel_angle_offset_from_request_rad",
            ),
            -2.0 * np.pi / 180.0,
            2.0 * np.pi / 180.0,
        ),
        ChoiceParameter("tire_force_condition", ["dry", "wet"]),
        RoadRandomizationParameter(
            "road_seed",
            config=_DEFAULT_SWEEP_ROAD_RANDOMIZATION_CONFIG,
            values=range(100000),
        ),
        InitialStateValueParameter(
            "initial_world_position_y_m",
            ("world_pose", "y_m"),
            -0.5,
            0.5,
        ),
        InitialStateValueParameter(
            "initial_heading_in_world_frame_rad",
            ("world_pose", "heading_rad"),
            -2.0 * np.pi / 180.0,
            2.0 * np.pi / 180.0,
        ),
        ObservationNoiseSeedParameter(values=range(100000)),
        UniformObservationNoiseParameter(
            "body_longitudinal_velocity_noise_standard_deviation_mps",
            (
                "body_longitudinal_velocity_mps",
                "noise_standard_deviation_mps",
            ),
            0.0,
            0.5,
        ),
        PolicySeedParameter(values=range(100000)),
        SeedParameter("rollout_seed", range(100000)),
    ], samples=200, seed=1)


@dataclass(frozen=True)
class AutonomousDrivingEvaluationConfig:
    n_steps: int
    base_env_kwargs: dict
    include_look_ahead_results: bool = False
    include_observations: bool = False
    verbose: int = 0


def _require_supported_mpc_policy(policy) -> None:
    from dreamgym.evaluation.autonomous_driving._mpc_rollout import (
        _formulation_and_metadata_for_policy,
    )

    _formulation_and_metadata_for_policy(policy)


def _sample_from_rollout_index_row(
    sweep: UncertaintySweep,
    rollout_index_row: Mapping[str, object],
) -> ParameterSample:
    names = tuple(parameter.name for parameter in sweep.parameters)
    missing = tuple(name for name in names if name not in rollout_index_row)
    if missing:
        raise ValueError(
            "Rollout-index row is missing sweep parameters: "
            + ", ".join(missing)
        )
    values = {name: rollout_index_row[name] for name in names}
    appliers = tuple(
        parameter.applier()
        for parameter in sweep.parameters
    )
    return ParameterSample(
        values=values,
        appliers=appliers,
    )


def _validate_sweep_result_schema(
    sweep: UncertaintySweep,
    metrics: MetricSet,
) -> None:
    parameter_names = {parameter.name for parameter in sweep.parameters}
    metric_names = set(metrics.names())
    metric_metadata = metric_names & _ROLLOUT_INDEX_METADATA_KEYS
    metric_parameters = metric_names & parameter_names
    if metric_metadata or metric_parameters:
        collisions = sorted(metric_metadata | metric_parameters)
        raise ValueError(
            "Evaluation result column names collide: " + ", ".join(collisions)
        )


def _make_env_from_sample(
    config: AutonomousDrivingEvaluationConfig,
    sample: ParameterSample,
):
    import gymnasium as gym

    env_kwargs, post_create = sample.apply_to_env_kwargs(
        config.base_env_kwargs
    )
    env = gym.make(
        "dreamgym/autonomous_driving_env",
        **env_kwargs,
    )
    try:
        if "tire_force_condition" in post_create:
            env.unwrapped.set_tire_force_condition(
                post_create["tire_force_condition"]
            )
        return env, post_create
    except BaseException:
        env.close()
        raise


def evaluate_policies_over_sweep(
    policies,
    config: AutonomousDrivingEvaluationConfig,
    metrics=None,
    sweep=None,
    *,
    include_per_rollout_metrics: bool = False,
) -> PerformanceMetricResults:
    metric_set = default_metric_set() if metrics is None else metrics
    sweep = quick_uncertainty_sweep() if sweep is None else sweep
    _validate_sweep_result_schema(sweep, metric_set)

    from dreamgym.evaluation.autonomous_driving.simulation import simulate_policy

    metric_rows = []
    rollout_index_rows = []

    for policy_spec in policies:
        for rollout_index, sample in enumerate(sweep.samples()):
            env, post_create = _make_env_from_sample(config, sample)
            try:
                policy_seed = post_create.get("policy_seed", sample.values.get("policy_seed", None))
                rollout_seed = int(post_create.get("rollout_seed", sample.values.get("rollout_seed", 0)))
                time_series = simulate_policy(
                    env,
                    config.n_steps,
                    policy_spec.policy,
                    seed=rollout_seed,
                    should_save_look_ahead_results=config.include_look_ahead_results,
                    should_save_observations=config.include_observations,
                    verbose=config.verbose,
                    policy_seed=policy_seed,
                )
                metric_values = compute_autonomous_driving_metrics(time_series, metric_set)
                row = {
                    "policy_name": policy_spec.name,
                    "rollout_index": rollout_index,
                    "terminated": bool(time_series.get("terminated", False)),
                    "truncated": bool(time_series.get("truncated", False)),
                    **sample.values,
                    **metric_values,
                }
                metric_rows.append(row)
                rollout_index_rows.append({
                    "policy_name": policy_spec.name,
                    "rollout_index": rollout_index,
                    "terminated": bool(time_series.get("terminated", False)),
                    "truncated": bool(time_series.get("truncated", False)),
                    "steps_recorded": int(metric_values.get("steps_completed", 0.0)),
                    **sample.values,
                })
            finally:
                env.close()

    aggregate_rows = aggregate_metric_rows(metric_rows, metric_set)
    return PerformanceMetricResults(
        aggregate_rows=aggregate_rows,
        rollout_index_rows=rollout_index_rows,
        per_rollout_metric_rows=metric_rows if include_per_rollout_metrics else None,
    )


def rerun_sweep_rollout(
    policy_spec: PolicySpec,
    config: AutonomousDrivingEvaluationConfig,
    sweep: UncertaintySweep,
    rollout_index_row: Mapping[str, object],
):
    from dreamgym.evaluation.autonomous_driving.simulation import (
        simulate_policy,
    )

    sample = _sample_from_rollout_index_row(
        sweep=sweep,
        rollout_index_row=rollout_index_row,
    )
    env, post_create = _make_env_from_sample(config, sample)
    try:
        policy_seed = post_create.get(
            "policy_seed",
            sample.values.get("policy_seed", None),
        )
        rollout_seed = int(
            post_create.get(
                "rollout_seed",
                sample.values.get("rollout_seed", 0),
            )
        )
        return simulate_policy(
            env,
            config.n_steps,
            policy_spec.policy,
            seed=rollout_seed,
            should_save_look_ahead_results=(
                config.include_look_ahead_results
            ),
            should_save_observations=config.include_observations,
            verbose=config.verbose,
            policy_seed=policy_seed,
        )
    finally:
        env.close()


def rerun_mpc_sweep_rollout(
    policy_spec: PolicySpec,
    config: AutonomousDrivingEvaluationConfig,
    sweep: UncertaintySweep,
    rollout_index_row: Mapping[str, object],
    *,
    capture_world_predictions: bool = False,
) -> AutonomousDrivingMPCRolloutHistory:
    from dreamgym.evaluation.autonomous_driving.simulation import (
        simulate_mpc_policy,
    )

    _require_supported_mpc_policy(policy_spec.policy)
    sample = _sample_from_rollout_index_row(
        sweep=sweep,
        rollout_index_row=rollout_index_row,
    )
    environment, post_create = _make_env_from_sample(config, sample)
    try:
        policy_seed = post_create.get(
            "policy_seed",
            sample.values.get("policy_seed", None),
        )
        rollout_seed = int(
            post_create.get(
                "rollout_seed",
                sample.values.get("rollout_seed", 0),
            )
        )
        return simulate_mpc_policy(
            environment,
            config.n_steps,
            policy_spec.policy,
            seed=rollout_seed,
            policy_seed=policy_seed,
            should_save_look_ahead_results=(
                config.include_look_ahead_results
            ),
            should_save_observations=config.include_observations,
            verbose=config.verbose,
            capture_world_predictions=capture_world_predictions,
        )
    finally:
        environment.close()


def _finite(values) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64).reshape(-1)
    return arr[np.isfinite(arr)]


def _finite_pair(a, b) -> tuple[np.ndarray, np.ndarray]:
    a_arr = np.asarray(a, dtype=np.float64).reshape(-1)
    b_arr = np.asarray(b, dtype=np.float64).reshape(-1)
    n = min(a_arr.size, b_arr.size)
    mask = np.isfinite(a_arr[:n]) & np.isfinite(b_arr[:n])
    return a_arr[:n][mask], b_arr[:n][mask]


def _finite_signal_and_time(results: Mapping[str, object], signal_name: str) -> tuple[np.ndarray, np.ndarray]:
    signal = np.asarray(results[signal_name], dtype=np.float64).reshape(-1)
    time = np.asarray(results["time_in_seconds"], dtype=np.float64).reshape(-1)
    n = min(signal.size, time.size)
    mask = np.isfinite(signal[:n]) & np.isfinite(time[:n])
    return signal[:n][mask], time[:n][mask]


def _mean(values) -> float:
    arr = _finite(values)
    return float(np.mean(arr)) if arr.size else float("nan")


def _median(values) -> float:
    arr = _finite(values)
    return float(np.median(arr)) if arr.size else float("nan")


def _std(values) -> float:
    arr = _finite(values)
    return float(np.std(arr)) if arr.size else float("nan")


def _min(values) -> float:
    arr = _finite(values)
    return float(np.min(arr)) if arr.size else float("nan")


def _max(values) -> float:
    arr = _finite(values)
    return float(np.max(arr)) if arr.size else float("nan")


def _sum(values) -> float:
    arr = _finite(values)
    return float(np.sum(arr)) if arr.size else float("nan")


def _rms(values) -> float:
    arr = _finite(values)
    return float(np.sqrt(np.mean(arr * arr))) if arr.size else float("nan")


def _last(values) -> float:
    arr = _finite(values)
    return float(arr[-1]) if arr.size else float("nan")


def _first(values) -> float:
    arr = _finite(values)
    return float(arr[0]) if arr.size else float("nan")


def _fraction_true(mask_values) -> float:
    arr = np.asarray(mask_values, dtype=np.float64).reshape(-1)
    arr = arr[np.isfinite(arr)]
    return float(np.mean(arr > 0.0)) if arr.size else float("nan")


def _derivative(values: np.ndarray, time: np.ndarray) -> np.ndarray:
    if values.size < 2 or time.size < 2:
        return np.array([], dtype=np.float64)
    delta_t = np.diff(time)
    delta_v = np.diff(values)
    valid = np.isfinite(delta_t) & np.isfinite(delta_v) & (delta_t > 0.0)
    if not np.any(valid):
        return np.array([], dtype=np.float64)
    return delta_v[valid] / delta_t[valid]


def _reward_sum(results):
    """Equation: sum(reward)."""
    return _sum(results["reward"])


def _reward_mean(results):
    """Equation: mean(reward)."""
    return _mean(results["reward"])


def _reward_std(results):
    """Equation: std(reward)."""
    return _std(results["reward"])


def _reward_min(results):
    """Equation: min(reward)."""
    return _min(results["reward"])


def _reward_max(results):
    """Equation: max(reward)."""
    return _max(results["reward"])


def _mean_abs_lateral_error_m(results):
    """Equation: mean(abs(lateral_error_from_target_line))."""
    return _mean(np.abs(results["lateral_error_from_target_line"]))


def _median_abs_lateral_error_m(results):
    """Equation: median(abs(lateral_error_from_target_line))."""
    return _median(np.abs(results["lateral_error_from_target_line"]))


def _rms_lateral_error_m(results):
    """Equation: sqrt(mean(lateral_error_from_target_line^2))."""
    return _rms(results["lateral_error_from_target_line"])


def _std_lateral_error_m(results):
    """Equation: std(lateral_error_from_target_line)."""
    return _std(results["lateral_error_from_target_line"])


def _max_abs_lateral_error_m(results):
    """Equation: max(abs(lateral_error_from_target_line))."""
    return _max(np.abs(results["lateral_error_from_target_line"]))


def _mean_abs_heading_error_rad(results):
    """Equation: mean(abs(heading_angle_relative_to_target_line))."""
    return _mean(np.abs(results["heading_angle_relative_to_target_line"]))


def _max_abs_heading_error_rad(results):
    """Equation: max(abs(heading_angle_relative_to_target_line))."""
    return _max(np.abs(results["heading_angle_relative_to_target_line"]))


def _speed_relative_to_recommended(results) -> np.ndarray:
    vx, recommended = _finite_pair(results["vx"], results["recommended_speed_at_closest_point"])
    return vx - recommended


def _speed_relative_to_limit(results) -> np.ndarray:
    vx, limit = _finite_pair(results["vx"], results["speed_limit_at_closest_point"])
    return vx - limit


def _mean_speed_relative_to_recommended_kph(results):
    """Equation: mean(vx - recommended_speed_at_closest_point) * 3.6."""
    return _mean(_speed_relative_to_recommended(results)) * 3.6


def _mean_abs_speed_error_to_recommended_kph(results):
    """Equation: mean(abs(vx - recommended_speed_at_closest_point)) * 3.6."""
    return _mean(np.abs(_speed_relative_to_recommended(results))) * 3.6


def _max_speed_above_recommended_kph(results):
    """Equation: max(max(vx - recommended_speed_at_closest_point, 0)) * 3.6."""
    return _max(np.maximum(_speed_relative_to_recommended(results), 0.0)) * 3.6


def _fraction_time_above_recommended_speed(results):
    """Equation: count(vx > recommended_speed_at_closest_point) / finite speed samples."""
    return _fraction_true(_speed_relative_to_recommended(results) > 0.0)


def _mean_speed_relative_to_limit_kph(results):
    """Equation: mean(vx - speed_limit_at_closest_point) * 3.6."""
    return _mean(_speed_relative_to_limit(results)) * 3.6


def _max_speed_limit_exceedance_kph(results):
    """Equation: max(max(vx - speed_limit_at_closest_point, 0)) * 3.6."""
    return _max(np.maximum(_speed_relative_to_limit(results), 0.0)) * 3.6


def _mean_speed_limit_exceedance_kph(results):
    """Equation: mean(max(vx - speed_limit_at_closest_point, 0)) * 3.6."""
    return _mean(np.maximum(_speed_relative_to_limit(results), 0.0)) * 3.6


def _fraction_time_above_speed_limit(results):
    """Equation: count(vx > speed_limit_at_closest_point) / finite speed samples."""
    return _fraction_true(_speed_relative_to_limit(results) > 0.0)


def _final_progress_m(results):
    """Equation: last finite reference_line_progress_at_closest_point."""
    return _last(results["reference_line_progress_at_closest_point"])


def _progress_delta_m(results):
    """Equation: final progress minus initial progress."""
    progress = results["reference_line_progress_at_closest_point"]
    first = _first(progress)
    last = _last(progress)
    if not (np.isfinite(first) and np.isfinite(last)):
        return float("nan")
    return last - first


def _duration_s(results):
    """Equation: final finite time sample aligned with finite vx."""
    vx, time = _finite_signal_and_time(results, "vx")
    if vx.size == 0:
        return float("nan")
    return float(time[-1])


def _steps_completed(results):
    """Equation: count(finite vx samples)."""
    return float(_finite(results["vx"]).size)


def _terminated_flag(results):
    """Equation: 1 if rollout terminated else 0."""
    return 1.0 if bool(results.get("terminated", False)) else 0.0


def _truncated_flag(results):
    """Equation: 1 if rollout truncated else 0."""
    return 1.0 if bool(results.get("truncated", False)) else 0.0


def _incomplete_rollout_flag(results):
    """Equation: 1 if rollout terminated or truncated else 0."""
    return 1.0 if bool(results.get("terminated", False) or results.get("truncated", False)) else 0.0


def _completion_fraction(results):
    """Equation: count(finite vx samples) / total vx samples."""
    vx = np.asarray(results["vx"], dtype=np.float64).reshape(-1)
    if vx.size == 0:
        return float("nan")
    return float(np.sum(np.isfinite(vx)) / vx.size)


def _mean_abs_drive_command(results):
    """Equation: mean(abs(drive_command))."""
    return _mean(np.abs(results["drive_command"]))


def _rms_drive_command(results):
    """Equation: sqrt(mean(drive_command^2))."""
    return _rms(results["drive_command"])


def _mean_abs_delta_request_rad(results):
    """Equation: mean(abs(delta_request))."""
    return _mean(np.abs(results["delta_request"]))


def _rms_delta_request_rad(results):
    """Equation: sqrt(mean(delta_request^2))."""
    return _rms(results["delta_request"])


def _acceleration(results) -> np.ndarray:
    vx, time = _finite_signal_and_time(results, "vx")
    return _derivative(vx, time)


def _mean_abs_acceleration_mps2(results):
    """Equation: mean(abs(diff(vx) / diff(time)))."""
    return _mean(np.abs(_acceleration(results)))


def _max_abs_acceleration_mps2(results):
    """Equation: max(abs(diff(vx) / diff(time)))."""
    return _max(np.abs(_acceleration(results)))


def _jerk(results) -> np.ndarray:
    vx, time = _finite_signal_and_time(results, "vx")
    acceleration = _derivative(vx, time)
    if acceleration.size < 2 or time.size < 3:
        return np.array([], dtype=np.float64)
    accel_time = time[1:1 + acceleration.size]
    return _derivative(acceleration, accel_time)


def _mean_abs_jerk_mps3(results):
    """Equation: mean(abs(diff(acceleration) / diff(time)))."""
    return _mean(np.abs(_jerk(results)))


def _max_abs_jerk_mps3(results):
    """Equation: max(abs(diff(acceleration) / diff(time)))."""
    return _max(np.abs(_jerk(results)))


def _steering_rate(results) -> np.ndarray:
    steering, time = _finite_signal_and_time(results, "delta_request")
    return _derivative(steering, time)


def _mean_abs_steering_rate_radps(results):
    """Equation: mean(abs(diff(delta_request) / diff(time)))."""
    return _mean(np.abs(_steering_rate(results)))


def _max_abs_steering_rate_radps(results):
    """Equation: max(abs(diff(delta_request) / diff(time)))."""
    return _max(np.abs(_steering_rate(results)))


def _metric(
    *,
    name,
    display_name,
    unit,
    direction,
    requirement_group,
    required_fields,
    equation,
    description,
    justification,
    function,
    primary_aggregate="mean",
    threshold=None,
):
    return PerformanceMetric(
        name=name,
        display_name=display_name,
        unit=unit,
        direction=direction,
        requirement_group=requirement_group,
        required_fields=tuple(required_fields),
        equation=equation,
        description=description,
        justification=justification,
        function=function,
        primary_aggregate=primary_aggregate,
        threshold=threshold,
    )


_BUILT_IN_METRICS = (
    _metric(
        name="reward_sum",
        display_name="Reward sum",
        unit="reward",
        direction="bigger",
        requirement_group="reward",
        required_fields=("reward",),
        equation="sum(reward)",
        description="Sum of finite reward samples over the rollout.",
        justification="The reward sum is useful for relating engineering metrics back to the scalar objective used by RL.",
        function=_reward_sum,
    ),
    _metric(
        name="reward_mean",
        display_name="Mean reward",
        unit="reward",
        direction="bigger",
        requirement_group="reward",
        required_fields=("reward",),
        equation="mean(reward)",
        description="Mean finite reward sample over the rollout.",
        justification="The mean reward normalizes reward by rollout length for rough comparison between completed and shorter rollouts.",
        function=_reward_mean,
    ),
    _metric(
        name="reward_std",
        display_name="Reward standard deviation",
        unit="reward",
        direction="smaller",
        requirement_group="reward",
        required_fields=("reward",),
        equation="std(reward)",
        description="Standard deviation of finite reward samples.",
        justification="Large reward variation can indicate inconsistent behavior across the rollout.",
        function=_reward_std,
    ),
    _metric(
        name="reward_min",
        display_name="Minimum reward",
        unit="reward",
        direction="bigger",
        requirement_group="reward",
        required_fields=("reward",),
        equation="min(reward)",
        description="Smallest finite reward sample.",
        justification="The minimum reward highlights the worst local reward outcome during a rollout.",
        function=_reward_min,
    ),
    _metric(
        name="reward_max",
        display_name="Maximum reward",
        unit="reward",
        direction="bigger",
        requirement_group="reward",
        required_fields=("reward",),
        equation="max(reward)",
        description="Largest finite reward sample.",
        justification="The maximum reward is a simple diagnostic for the best local reward outcome during a rollout.",
        function=_reward_max,
    ),
    _metric(
        name="mean_abs_lateral_error_m",
        display_name="Mean absolute lateral error",
        unit="m",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("lateral_error_from_target_line",),
        equation="mean(abs(lateral_error_from_target_line))",
        description="Average absolute distance from the selected target line.",
        justification="Lower average lateral error indicates better lane-centering over the full rollout.",
        function=_mean_abs_lateral_error_m,
    ),
    _metric(
        name="median_abs_lateral_error_m",
        display_name="Median absolute lateral error",
        unit="m",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("lateral_error_from_target_line",),
        equation="median(abs(lateral_error_from_target_line))",
        description="Median absolute distance from the selected target line.",
        justification="The median describes typical lane-centering performance with less sensitivity to rare excursions.",
        function=_median_abs_lateral_error_m,
    ),
    _metric(
        name="rms_lateral_error_m",
        display_name="RMS lateral error",
        unit="m",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("lateral_error_from_target_line",),
        equation="sqrt(mean(lateral_error_from_target_line^2))",
        description="Root-mean-square signed lateral error from the selected target line.",
        justification="RMS error penalizes larger lane deviations more strongly than the mean absolute error.",
        function=_rms_lateral_error_m,
    ),
    _metric(
        name="std_lateral_error_m",
        display_name="Lateral error standard deviation",
        unit="m",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("lateral_error_from_target_line",),
        equation="std(lateral_error_from_target_line)",
        description="Standard deviation of signed lateral error.",
        justification="Lower lateral-error variation indicates steadier lane tracking.",
        function=_std_lateral_error_m,
    ),
    _metric(
        name="max_abs_lateral_error_m",
        display_name="Maximum absolute lateral error",
        unit="m",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("lateral_error_from_target_line",),
        equation="max(abs(lateral_error_from_target_line))",
        description="Largest absolute distance from the selected target line.",
        justification="The maximum error captures the worst lane-keeping excursion and is important for safety margins.",
        function=_max_abs_lateral_error_m,
        primary_aggregate="worst_case",
    ),
    _metric(
        name="mean_abs_heading_error_rad",
        display_name="Mean absolute heading error",
        unit="rad",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("heading_angle_relative_to_target_line",),
        equation="mean(abs(heading_angle_relative_to_target_line))",
        description="Average absolute heading angle relative to the target line.",
        justification="Lower heading error indicates the vehicle is aligned with the path it is trying to follow.",
        function=_mean_abs_heading_error_rad,
    ),
    _metric(
        name="max_abs_heading_error_rad",
        display_name="Maximum absolute heading error",
        unit="rad",
        direction="smaller",
        requirement_group="lane_keeping",
        required_fields=("heading_angle_relative_to_target_line",),
        equation="max(abs(heading_angle_relative_to_target_line))",
        description="Largest absolute heading angle relative to the target line.",
        justification="The maximum heading error highlights the worst alignment event in a rollout.",
        function=_max_abs_heading_error_rad,
        primary_aggregate="worst_case",
    ),
    _metric(
        name="mean_speed_relative_to_recommended_kph",
        display_name="Mean speed relative to recommended",
        unit="km/h",
        direction="target",
        requirement_group="speed_tracking_recommended",
        required_fields=("vx", "recommended_speed_at_closest_point"),
        equation="mean(vx - recommended_speed_at_closest_point) * 3.6",
        description="Mean signed speed difference relative to the road recommended speed.",
        justification="This identifies whether a policy tends to drive above or below the road's recommended speed.",
        function=_mean_speed_relative_to_recommended_kph,
    ),
    _metric(
        name="mean_abs_speed_error_to_recommended_kph",
        display_name="Mean absolute recommended-speed error",
        unit="km/h",
        direction="smaller",
        requirement_group="speed_tracking_recommended",
        required_fields=("vx", "recommended_speed_at_closest_point"),
        equation="mean(abs(vx - recommended_speed_at_closest_point)) * 3.6",
        description="Mean absolute speed error relative to the road recommended speed.",
        justification="Lower absolute speed error means the policy better follows the recommended speed profile.",
        function=_mean_abs_speed_error_to_recommended_kph,
    ),
    _metric(
        name="max_speed_above_recommended_kph",
        display_name="Maximum speed above recommended",
        unit="km/h",
        direction="smaller",
        requirement_group="speed_tracking_recommended",
        required_fields=("vx", "recommended_speed_at_closest_point"),
        equation="max(max(vx - recommended_speed_at_closest_point, 0)) * 3.6",
        description="Largest positive exceedance over recommended speed.",
        justification="This captures the worst case of driving faster than the recommended speed.",
        function=_max_speed_above_recommended_kph,
        primary_aggregate="worst_case",
    ),
    _metric(
        name="fraction_time_above_recommended_speed",
        display_name="Fraction above recommended speed",
        unit="fraction",
        direction="smaller",
        requirement_group="speed_tracking_recommended",
        required_fields=("vx", "recommended_speed_at_closest_point"),
        equation="count(vx > recommended_speed_at_closest_point) / finite speed samples",
        description="Fraction of finite speed samples above the recommended speed.",
        justification="This distinguishes brief excursions from persistent driving above the recommendation.",
        function=_fraction_time_above_recommended_speed,
    ),
    _metric(
        name="mean_speed_relative_to_limit_kph",
        display_name="Mean speed relative to limit",
        unit="km/h",
        direction="target",
        requirement_group="speed_limit_compliance",
        required_fields=("vx", "speed_limit_at_closest_point"),
        equation="mean(vx - speed_limit_at_closest_point) * 3.6",
        description="Mean signed speed difference relative to the speed limit.",
        justification="This identifies whether a policy tends to operate close to, below, or above the speed limit.",
        function=_mean_speed_relative_to_limit_kph,
    ),
    _metric(
        name="max_speed_limit_exceedance_kph",
        display_name="Maximum speed-limit exceedance",
        unit="km/h",
        direction="smaller",
        requirement_group="speed_limit_compliance",
        required_fields=("vx", "speed_limit_at_closest_point"),
        equation="max(max(vx - speed_limit_at_closest_point, 0)) * 3.6",
        description="Largest positive exceedance over the speed limit.",
        justification="This is a direct worst-case safety metric for speed-limit compliance.",
        function=_max_speed_limit_exceedance_kph,
        primary_aggregate="worst_case",
        threshold=0.0,
    ),
    _metric(
        name="mean_speed_limit_exceedance_kph",
        display_name="Mean speed-limit exceedance",
        unit="km/h",
        direction="smaller",
        requirement_group="speed_limit_compliance",
        required_fields=("vx", "speed_limit_at_closest_point"),
        equation="mean(max(vx - speed_limit_at_closest_point, 0)) * 3.6",
        description="Mean positive exceedance over the speed limit.",
        justification="This measures how large speed-limit violations are on average, counting compliant samples as zero exceedance.",
        function=_mean_speed_limit_exceedance_kph,
        threshold=0.0,
    ),
    _metric(
        name="fraction_time_above_speed_limit",
        display_name="Fraction above speed limit",
        unit="fraction",
        direction="smaller",
        requirement_group="speed_limit_compliance",
        required_fields=("vx", "speed_limit_at_closest_point"),
        equation="count(vx > speed_limit_at_closest_point) / finite speed samples",
        description="Fraction of finite speed samples above the speed limit.",
        justification="This measures how persistently a policy violates the speed limit.",
        function=_fraction_time_above_speed_limit,
        threshold=0.0,
    ),
    _metric(
        name="final_progress_m",
        display_name="Final progress",
        unit="m",
        direction="bigger",
        requirement_group="progress_completion",
        required_fields=("reference_line_progress_at_closest_point",),
        equation="last finite reference_line_progress_at_closest_point",
        description="Final progress reached along the road reference line.",
        justification="More progress indicates that the vehicle moved farther along the route.",
        function=_final_progress_m,
    ),
    _metric(
        name="progress_delta_m",
        display_name="Progress delta",
        unit="m",
        direction="bigger",
        requirement_group="progress_completion",
        required_fields=("reference_line_progress_at_closest_point",),
        equation="final progress - initial progress",
        description="Change in reference-line progress over the rollout.",
        justification="Progress delta removes dependence on the initial progress value.",
        function=_progress_delta_m,
    ),
    _metric(
        name="duration_s",
        display_name="Duration",
        unit="s",
        direction="informational",
        requirement_group="progress_completion",
        required_fields=("time_in_seconds", "vx"),
        equation="final finite time sample aligned with finite vx",
        description="Duration covered by finite vehicle state samples.",
        justification="Duration helps interpret early terminations and truncated rollouts.",
        function=_duration_s,
    ),
    _metric(
        name="steps_completed",
        display_name="Steps completed",
        unit="steps",
        direction="bigger",
        requirement_group="progress_completion",
        required_fields=("vx",),
        equation="count(finite vx samples)",
        description="Number of finite vehicle speed samples in the rollout.",
        justification="More completed steps usually means the policy remained valid for longer.",
        function=_steps_completed,
    ),
    _metric(
        name="terminated_flag",
        display_name="Terminated flag",
        unit="flag",
        direction="smaller",
        requirement_group="termination_truncation",
        required_fields=(),
        equation="1 if terminated else 0",
        description="Flag indicating whether Gymnasium termination occurred.",
        justification="Termination counts should be visible when comparing policy robustness.",
        function=_terminated_flag,
    ),
    _metric(
        name="truncated_flag",
        display_name="Truncated flag",
        unit="flag",
        direction="smaller",
        requirement_group="termination_truncation",
        required_fields=(),
        equation="1 if truncated else 0",
        description="Flag indicating whether Gymnasium truncation occurred.",
        justification="Truncation counts indicate policies that exceeded operating limits or time limits.",
        function=_truncated_flag,
    ),
    _metric(
        name="incomplete_rollout_flag",
        display_name="Incomplete rollout flag",
        unit="flag",
        direction="smaller",
        requirement_group="termination_truncation",
        required_fields=(),
        equation="1 if terminated or truncated else 0",
        description="Flag indicating whether the rollout ended early.",
        justification="Incomplete rollout counts provide a compact robustness signal.",
        function=_incomplete_rollout_flag,
    ),
    _metric(
        name="completion_fraction",
        display_name="Completion fraction",
        unit="fraction",
        direction="bigger",
        requirement_group="termination_truncation",
        required_fields=("vx",),
        equation="count(finite vx samples) / total vx samples",
        description="Fraction of vehicle speed samples that are finite.",
        justification="This approximates how much of the requested rollout produced valid vehicle state data.",
        function=_completion_fraction,
    ),
    _metric(
        name="mean_abs_drive_command",
        display_name="Mean absolute drive command",
        unit="command",
        direction="smaller",
        requirement_group="control_smoothness",
        required_fields=("drive_command",),
        equation="mean(abs(drive_command))",
        description="Mean absolute longitudinal drive command.",
        justification="Lower command magnitude can indicate less aggressive longitudinal control.",
        function=_mean_abs_drive_command,
    ),
    _metric(
        name="rms_drive_command",
        display_name="RMS drive command",
        unit="command",
        direction="smaller",
        requirement_group="control_smoothness",
        required_fields=("drive_command",),
        equation="sqrt(mean(drive_command^2))",
        description="Root-mean-square longitudinal drive command.",
        justification="RMS command magnitude penalizes large throttle or braking requests.",
        function=_rms_drive_command,
    ),
    _metric(
        name="mean_abs_delta_request_rad",
        display_name="Mean absolute steering request",
        unit="rad",
        direction="smaller",
        requirement_group="control_smoothness",
        required_fields=("delta_request",),
        equation="mean(abs(delta_request))",
        description="Mean absolute steering request.",
        justification="Lower steering-request magnitude can indicate smoother steering behavior.",
        function=_mean_abs_delta_request_rad,
    ),
    _metric(
        name="rms_delta_request_rad",
        display_name="RMS steering request",
        unit="rad",
        direction="smaller",
        requirement_group="control_smoothness",
        required_fields=("delta_request",),
        equation="sqrt(mean(delta_request^2))",
        description="Root-mean-square steering request.",
        justification="RMS steering request penalizes large steering actions more strongly.",
        function=_rms_delta_request_rad,
    ),
    _metric(
        name="mean_abs_acceleration_mps2",
        display_name="Mean absolute acceleration",
        unit="m/s^2",
        direction="smaller",
        requirement_group="acceleration_braking_smoothness",
        required_fields=("vx", "time_in_seconds"),
        equation="mean(abs(diff(vx) / diff(time)))",
        description="Mean absolute longitudinal acceleration estimated from speed differences.",
        justification="Lower absolute acceleration indicates smoother acceleration and braking behavior.",
        function=_mean_abs_acceleration_mps2,
    ),
    _metric(
        name="max_abs_acceleration_mps2",
        display_name="Maximum absolute acceleration",
        unit="m/s^2",
        direction="smaller",
        requirement_group="acceleration_braking_smoothness",
        required_fields=("vx", "time_in_seconds"),
        equation="max(abs(diff(vx) / diff(time)))",
        description="Maximum absolute longitudinal acceleration estimated from speed differences.",
        justification="This captures the worst acceleration or braking event in the rollout.",
        function=_max_abs_acceleration_mps2,
        primary_aggregate="worst_case",
    ),
    _metric(
        name="mean_abs_jerk_mps3",
        display_name="Mean absolute jerk",
        unit="m/s^3",
        direction="smaller",
        requirement_group="acceleration_braking_smoothness",
        required_fields=("vx", "time_in_seconds"),
        equation="mean(abs(diff(acceleration) / diff(time)))",
        description="Mean absolute longitudinal jerk estimated from acceleration differences.",
        justification="Lower jerk indicates smoother acceleration and braking transitions.",
        function=_mean_abs_jerk_mps3,
    ),
    _metric(
        name="max_abs_jerk_mps3",
        display_name="Maximum absolute jerk",
        unit="m/s^3",
        direction="smaller",
        requirement_group="acceleration_braking_smoothness",
        required_fields=("vx", "time_in_seconds"),
        equation="max(abs(diff(acceleration) / diff(time)))",
        description="Maximum absolute longitudinal jerk estimated from acceleration differences.",
        justification="This captures the harshest acceleration or braking transition.",
        function=_max_abs_jerk_mps3,
        primary_aggregate="worst_case",
    ),
    _metric(
        name="mean_abs_steering_rate_radps",
        display_name="Mean absolute steering rate",
        unit="rad/s",
        direction="smaller",
        requirement_group="lane_keeping_smoothness",
        required_fields=("delta_request", "time_in_seconds"),
        equation="mean(abs(diff(delta_request) / diff(time)))",
        description="Mean absolute steering-request rate.",
        justification="Lower steering-rate magnitude indicates smoother lane-keeping control.",
        function=_mean_abs_steering_rate_radps,
    ),
    _metric(
        name="max_abs_steering_rate_radps",
        display_name="Maximum absolute steering rate",
        unit="rad/s",
        direction="smaller",
        requirement_group="lane_keeping_smoothness",
        required_fields=("delta_request", "time_in_seconds"),
        equation="max(abs(diff(delta_request) / diff(time)))",
        description="Maximum absolute steering-request rate.",
        justification="This captures the harshest steering change in the rollout.",
        function=_max_abs_steering_rate_radps,
        primary_aggregate="worst_case",
    ),
)


def built_in_metrics() -> MetricSet:
    return MetricSet(_BUILT_IN_METRICS)


def default_metric_set() -> MetricSet:
    return built_in_metrics()


def metric_by_name(name: str) -> PerformanceMetric:
    return built_in_metrics().get(name)


def compute_autonomous_driving_metrics(time_series, metrics=None) -> dict[str, float]:
    metric_set = default_metric_set() if metrics is None else metrics
    return compute_metric_values(metric_set, time_series)
