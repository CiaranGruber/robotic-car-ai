"""Private MPC rollout adaptation and context materialization."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import fields, is_dataclass, replace
from enum import Enum
from types import MappingProxyType

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCFormulation,
    MPCActionExecution,
    MPCPredictionContext,
    MPCRolloutAbortedError,
    MPCTransitionRecord,
    MPCVariableMetadata,
    MPCWorldPose,
    _create_mpc_rollout_history,
)
from dreamgym.policies.autonomous_driving._mpc_rollout import (
    _AutonomousDrivingMPCPolicyMarker,
    _MPCConfiguredRaiseError,
)
from dreamgym.policies.autonomous_driving._mpc_formulations import (
    predict_current_relative_progress,
)
from dreamgym.policies.autonomous_driving._mpc_control import _MPCControlKind
from dreamgym.policies.autonomous_driving.mpc_results import MPCPolicyResult
from dreamgym.policies.mpc._formulation import (
    normalize_bounds,
    normalize_control_bounds,
    normalize_control_references,
    normalize_state_references,
    stage_zero_control_rate_requires_previous_control,
)
from dreamgym.policies.mpc.problem import LinearQuadraticMPCProblem


_DIRECT_METADATA = MPCVariableMetadata(
    state_names=("speed", "lateral_error", "heading_error"),
    state_units_si=("m/s", "m", "rad"),
    control_names=("normalized_drive_command", "steering_angle"),
    control_units_si=("1", "rad"),
    actual_control_signal_names=(
        "applied_normalized_drive_command",
        "environment_steering_target_radians",
    ),
)
_RATE_METADATA = MPCVariableMetadata(
    state_names=(
        "speed",
        "lateral_error",
        "heading_error",
        "steering_angle",
    ),
    state_units_si=("m/s", "m", "rad", "rad"),
    control_names=("normalized_drive_command", "steering_rate"),
    control_units_si=("1", "rad/s"),
    actual_control_signal_names=(
        "applied_normalized_drive_command",
        "applied_steering_rate_radians_per_second",
    ),
)
_FORMULATION_METADATA = {
    "direct_steering": (
        AutonomousDrivingMPCFormulation.DIRECT_STEERING,
        _DIRECT_METADATA,
    ),
    "road_aware_direct_steering": (
        AutonomousDrivingMPCFormulation.ROAD_AWARE_DIRECT_STEERING,
        _DIRECT_METADATA,
    ),
    "steering_rate": (
        AutonomousDrivingMPCFormulation.STEERING_RATE,
        _RATE_METADATA,
    ),
    "road_aware_steering_rate": (
        AutonomousDrivingMPCFormulation.ROAD_AWARE_STEERING_RATE,
        _RATE_METADATA,
    ),
}
_FORMULATION_CONTROL_KINDS = {
    AutonomousDrivingMPCFormulation.DIRECT_STEERING: (
        _MPCControlKind.DIRECT_STEERING
    ),
    AutonomousDrivingMPCFormulation.ROAD_AWARE_DIRECT_STEERING: (
        _MPCControlKind.DIRECT_STEERING
    ),
    AutonomousDrivingMPCFormulation.STEERING_RATE: (
        _MPCControlKind.STEERING_RATE
    ),
    AutonomousDrivingMPCFormulation.ROAD_AWARE_STEERING_RATE: (
        _MPCControlKind.STEERING_RATE
    ),
}


def _control_kind_for_formulation(formulation) -> _MPCControlKind:
    if not isinstance(formulation, AutonomousDrivingMPCFormulation):
        raise TypeError(
            "formulation must be an AutonomousDrivingMPCFormulation"
        )
    try:
        return _FORMULATION_CONTROL_KINDS[formulation]
    except KeyError as error:
        raise ValueError("unsupported MPC formulation") from error


def _formulation_and_metadata_for_policy(
    policy,
) -> tuple[AutonomousDrivingMPCFormulation, MPCVariableMetadata]:
    if not isinstance(policy, _AutonomousDrivingMPCPolicyMarker):
        raise TypeError(
            "MPC rollout capture requires a supported autonomous-driving "
            "MPC policy"
        )
    token = getattr(policy, "_mpc_formulation_key", None)
    if token not in _FORMULATION_METADATA:
        raise ValueError(f"unsupported MPC formulation token: {token!r}")
    from dreamgym.policies.autonomous_driving.mpc import (
        AutonomousDrivingDirectSteeringMPCPolicy,
        AutonomousDrivingSteeringRateMPCPolicy,
    )
    from dreamgym.policies.autonomous_driving.road_aware_mpc import (
        AutonomousDrivingRoadAwareDirectSteeringMPCPolicy,
        AutonomousDrivingRoadAwareSteeringRateMPCPolicy,
    )

    if isinstance(policy, AutonomousDrivingRoadAwareDirectSteeringMPCPolicy):
        policy_family_token = "road_aware_direct_steering"
    elif isinstance(
        policy,
        AutonomousDrivingRoadAwareSteeringRateMPCPolicy,
    ):
        policy_family_token = "road_aware_steering_rate"
    elif isinstance(policy, AutonomousDrivingDirectSteeringMPCPolicy):
        policy_family_token = "direct_steering"
    elif isinstance(policy, AutonomousDrivingSteeringRateMPCPolicy):
        policy_family_token = "steering_rate"
    else:
        raise TypeError(
            "MPC rollout capture requires a supported autonomous-driving "
            "MPC policy"
        )
    if token != policy_family_token:
        raise TypeError(
            f"MPC formulation token {token!r} does not match policy family "
            f"{policy_family_token!r}"
        )
    return _FORMULATION_METADATA[token]


def _qualified_callable_name(value) -> str:
    module = getattr(value, "__module__", None)
    qualified_name = getattr(value, "__qualname__", None)
    if not isinstance(module, str) or not isinstance(qualified_name, str):
        raise TypeError("callable configuration values need stable names")
    return f"{module}.{qualified_name}"


def _snapshot_value(value: object) -> object:
    if isinstance(value, np.ndarray):
        copied = np.array(value, copy=True)
        copied.setflags(write=False)
        return copied
    if is_dataclass(value) and not isinstance(value, type):
        return MappingProxyType(
            {
                item.name: _snapshot_value(getattr(value, item.name))
                for item in fields(value)
            }
        )
    if isinstance(value, Mapping):
        return MappingProxyType(
            {
                str(key): _snapshot_value(item)
                for key, item in value.items()
            }
        )
    if isinstance(value, (tuple, list)):
        return tuple(_snapshot_value(item) for item in value)
    if isinstance(value, Enum):
        return value
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if callable(value):
        return _qualified_callable_name(value)
    raise TypeError(
        "configuration snapshot cannot retain "
        f"{type(value).__name__}"
    )


def _snapshot_policy_config(config) -> Mapping[str, object]:
    snapshot = _snapshot_value(config)
    if not isinstance(snapshot, Mapping):
        raise TypeError("policy config must be a dataclass or mapping")
    return snapshot


def _stack_stages(values) -> np.ndarray:
    return np.stack(tuple(values), axis=0)


def _materialize_prediction_context(
    *,
    problem,
    policy_result,
    model_config,
    actual_progress_anchor_metres,
) -> MPCPredictionContext:
    horizon_steps = problem.horizon_steps
    n_state = problem.initial_state.shape[0]
    control_matrices = problem.control_matrices
    n_control = (
        control_matrices.shape[1]
        if isinstance(control_matrices, np.ndarray)
        else control_matrices[0].shape[1]
    )
    state_references = normalize_state_references(
        n_state=n_state,
        horizon_steps=horizon_steps,
        state_references=problem.state_references,
        terminal_state_reference=problem.terminal_state_reference,
    )
    control_references = normalize_control_references(
        n_control=n_control,
        horizon_steps=horizon_steps,
        control_references=problem.control_references,
    )
    hard_state = normalize_bounds(
        name="state",
        horizon_steps=horizon_steps,
        size=n_state,
        lower_bounds=problem.state_lower_bounds,
        upper_bounds=problem.state_upper_bounds,
    )
    soft_state = normalize_bounds(
        name="soft_state",
        horizon_steps=horizon_steps,
        size=n_state,
        lower_bounds=problem.soft_state_lower_bounds,
        upper_bounds=problem.soft_state_upper_bounds,
    )
    control_lower, control_upper = normalize_control_bounds(
        horizon_steps=horizon_steps,
        n_control=n_control,
        lower_bounds=problem.control_lower_bounds,
        upper_bounds=problem.control_upper_bounds,
    )
    control_difference = normalize_bounds(
        name="control_rate",
        horizon_steps=horizon_steps,
        size=n_control,
        lower_bounds=problem.control_rate_lower_bounds,
        upper_bounds=problem.control_rate_upper_bounds,
    )
    previous_control = (
        problem.previous_control
        if stage_zero_control_rate_requires_previous_control(
            control_difference
        )
        else None
    )
    solve_result = policy_result.solve_result
    prediction = (
        None if solve_result is None else solve_result.prediction
    )
    predicted_progress = (
        None
        if prediction is None
        else predict_current_relative_progress(
            model_config,
            prediction.states,
            prediction.controls,
        )
    )
    road_horizon_context = policy_result.road_horizon_context
    context = MPCPredictionContext(
        state_references=np.vstack(
            (
                *state_references.stage_references,
                state_references.terminal_reference,
            )
        ),
        control_references=_stack_stages(
            control_references.stage_references
        ),
        hard_state_lower_bounds=_stack_stages(hard_state.lower_bounds),
        hard_state_upper_bounds=_stack_stages(hard_state.upper_bounds),
        soft_state_lower_bounds=_stack_stages(soft_state.lower_bounds),
        soft_state_upper_bounds=_stack_stages(soft_state.upper_bounds),
        control_lower_bounds=_stack_stages(control_lower),
        control_upper_bounds=_stack_stages(control_upper),
        control_difference_lower_bounds=_stack_stages(
            control_difference.lower_bounds
        ),
        control_difference_upper_bounds=_stack_stages(
            control_difference.upper_bounds
        ),
        previous_control=previous_control,
        reference_speeds_mps=policy_result.reference_speeds_mps,
        soft_speed_upper_bounds_mps=(
            policy_result.soft_speed_upper_bounds_mps
        ),
        linearization_speeds_mps=policy_result.linearization_speeds_mps,
        progress_schedule_metres=policy_result.progress_schedule_metres,
        predicted_relative_progress_metres=predicted_progress,
        actual_reference_line_progress_anchor_metres=(
            actual_progress_anchor_metres
        ),
        road_horizon_context=(
            None
            if road_horizon_context is None
            else replace(road_horizon_context)
        ),
    )
    return context


def _prediction_context_for_attempt(
    *,
    problem,
    policy_result,
    model_config,
    actual_progress_anchor_metres,
) -> MPCPredictionContext | None:
    return (
        None
        if problem is None
        else _materialize_prediction_context(
            problem=problem,
            policy_result=policy_result,
            model_config=model_config,
            actual_progress_anchor_metres=actual_progress_anchor_metres,
        )
    )


def _prediction_context_with_world_projection(context, outcome):
    if context is None:
        return None
    return replace(
        context,
        world_prediction_capture_requested=True,
        world_prediction=outcome.world_prediction,
        world_projection_unavailability_reason=outcome.unavailability_reason,
    )


def _ground_truth_float(ground_truth, key: str) -> float:
    if key not in ground_truth:
        raise KeyError(f"ground truth is missing {key!r}")
    value = float(ground_truth[key])
    if not np.isfinite(value):
        raise ValueError(f"ground truth {key!r} must be finite")
    return value


def _actual_model_state_from_ground_truth(
    formulation,
    ground_truth,
) -> np.ndarray:
    values = [
        _ground_truth_float(
            ground_truth,
            "ground_truth_body_longitudinal_velocity_mps",
        ),
        _ground_truth_float(
            ground_truth,
            "lateral_error_from_target_line_m",
        ),
        _ground_truth_float(
            ground_truth,
            "heading_error_from_target_line_rad",
        ),
    ]
    control_kind = _control_kind_for_formulation(formulation)
    if control_kind is _MPCControlKind.STEERING_RATE:
        values.append(
            _ground_truth_float(
                ground_truth,
                "ground_truth_front_wheel_steering_angle_rad",
            )
        )
    return np.asarray(values, dtype=np.float64)


def _reference_line_progress_from_ground_truth(ground_truth) -> float:
    return _ground_truth_float(
        ground_truth,
        "reference_line_progress_m",
    )


def _world_pose_from_ground_truth(ground_truth) -> MPCWorldPose:
    return MPCWorldPose(
        position_metres=np.array(
            [
                _ground_truth_float(
                    ground_truth,
                    "ground_truth_world_position_x_m",
                ),
                _ground_truth_float(
                    ground_truth,
                    "ground_truth_world_position_y_m",
                ),
            ],
            dtype=np.float64,
        ),
        heading_radians=_ground_truth_float(
            ground_truth,
            "ground_truth_heading_in_world_frame_rad",
        ),
    )


def _build_action_execution(
    *,
    policy_result,
    environment_drive_request,
    environment_steering_request_radians,
    steering_offset_radians,
    applied_drive_command,
    applied_steering_rate_radians_per_second,
    realized_steering_angle_radians,
) -> MPCActionExecution:
    request = policy_result.action_request
    if request is None:
        raise ValueError("completed action execution requires an action request")
    steering_request = float(environment_steering_request_radians)
    steering_offset = float(steering_offset_radians)
    return MPCActionExecution(
        policy_action_request=request,
        environment_normalized_drive_command_request=float(
            environment_drive_request
        ),
        environment_steering_request_radians=steering_request,
        environment_steering_target_radians=(
            steering_request + steering_offset
        ),
        applied_normalized_drive_command=float(applied_drive_command),
        applied_steering_rate_radians_per_second=float(
            applied_steering_rate_radians_per_second
        ),
        realized_steering_angle_radians=float(
            realized_steering_angle_radians
        ),
    )


class _MPCRolloutCollector:
    def __init__(self, policy, *, capture_world_predictions=False):
        if not isinstance(capture_world_predictions, bool):
            raise TypeError("capture_world_predictions must be a bool")
        self._policy = policy
        self._capture_world_predictions = capture_world_predictions
        (
            self._formulation,
            self._variable_metadata,
        ) = _formulation_and_metadata_for_policy(policy)
        self._records = []
        self._history = None
        self._environment_seed = None
        self._policy_seed = None
        self._policy_was_reset = False
        self._starting_policy_control_step = 0
        self._initial_actual_model_state = None
        self._initial_actual_world_pose = None
        self._initial_reference_line_progress_metres = None
        self._pending_before = None
        self._pending_result_and_context = None
        self._pending_configured_raise = None

    def start_rollout(
        self,
        *,
        environment,
        policy,
        environment_seed,
        effective_policy_seed,
        policy_was_reset,
        initial_ground_truth,
    ):
        if policy is not self._policy:
            raise ValueError("collector policy changed during rollout")
        self._starting_policy_control_step = int(
            self._policy.control_step_index
        )
        self._environment_seed = environment_seed
        self._policy_seed = effective_policy_seed
        self._policy_was_reset = bool(policy_was_reset)
        self._initial_actual_model_state = (
            _actual_model_state_from_ground_truth(
                self._formulation,
                initial_ground_truth,
            )
        )
        self._initial_actual_world_pose = _world_pose_from_ground_truth(
            initial_ground_truth
        )
        self._initial_reference_line_progress_metres = (
            _reference_line_progress_from_ground_truth(
                initial_ground_truth
            )
        )

    def begin_transition(
        self,
        *,
        transition_index,
        ground_truth_before,
    ):
        if transition_index != len(self._records):
            raise ValueError("transition_index is not rollout-local")
        if (
            self._pending_before is not None
            or self._pending_result_and_context is not None
            or self._pending_configured_raise is not None
        ):
            raise RuntimeError("previous transition is still pending")
        self._pending_before = (
            _actual_model_state_from_ground_truth(
                self._formulation,
                ground_truth_before,
            ),
            _reference_line_progress_from_ground_truth(
                ground_truth_before
            ),
            _world_pose_from_ground_truth(ground_truth_before),
        )

    def capture_policy_result(
        self,
        *,
        policy_result,
        problem,
        emitted_action,
        ground_truth_before,
    ):
        if not isinstance(policy_result, MPCPolicyResult):
            raise TypeError("policy last_result must be an MPCPolicyResult")
        if problem is not None and not isinstance(
            problem,
            LinearQuadraticMPCProblem,
        ):
            raise TypeError(
                "policy last_problem must be a "
                "LinearQuadraticMPCProblem or None"
            )
        if self._pending_before is None:
            raise RuntimeError("transition was not begun")
        expected_step = (
            self._starting_policy_control_step + len(self._records)
        )
        if policy_result.control_step_index != expected_step:
            raise ValueError("policy result is stale or out of sequence")
        if not np.array_equal(
            policy_result.environment_action,
            emitted_action,
        ):
            raise ValueError(
                "emitted action differs from the sampled policy result"
            )
        _, progress_before, _ = self._pending_before
        context = _prediction_context_for_attempt(
            problem=problem,
            policy_result=policy_result,
            model_config=self._policy.config.model,
            actual_progress_anchor_metres=progress_before,
        )
        self._pending_result_and_context = (policy_result, context)
        return context

    def capture_world_projection(self, *, outcome, retain):
        if not isinstance(retain, bool):
            raise TypeError("retain must be a bool")
        if retain != self._capture_world_predictions:
            raise ValueError(
                "retain must match the collector world-capture request"
            )
        if self._pending_result_and_context is not None:
            policy_result, context = self._pending_result_and_context
            if retain:
                context = _prediction_context_with_world_projection(
                    context,
                    outcome,
                )
                self._pending_result_and_context = (
                    policy_result,
                    context,
                )
            return
        if self._pending_configured_raise is not None:
            policy_result, context = self._pending_configured_raise
            if retain:
                context = _prediction_context_with_world_projection(
                    context,
                    outcome,
                )
                self._pending_configured_raise = (
                    policy_result,
                    context,
                )
            return
        raise RuntimeError("no MPC attempt is pending world projection")

    def complete_transition(
        self,
        *,
        reward,
        terminated,
        truncated,
        environment_drive_request,
        environment_steering_request_radians,
        applied_drive_command,
        applied_steering_rate_radians_per_second,
        realized_steering_angle_radians,
        ground_truth_after,
    ):
        if (
            self._pending_before is None
            or self._pending_result_and_context is None
        ):
            raise RuntimeError("transition capture is incomplete")
        state_before, progress_before, world_pose_before = self._pending_before
        policy_result, context = self._pending_result_and_context
        transition_index = len(self._records)
        state_after = _actual_model_state_from_ground_truth(
            self._formulation,
            ground_truth_after,
        )
        progress_after = _reference_line_progress_from_ground_truth(
            ground_truth_after
        )
        world_pose_after = _world_pose_from_ground_truth(ground_truth_after)
        execution = _build_action_execution(
            policy_result=policy_result,
            environment_drive_request=environment_drive_request,
            environment_steering_request_radians=(
                environment_steering_request_radians
            ),
            steering_offset_radians=(
                self._policy.config.environment.steering_offset_radians
            ),
            applied_drive_command=applied_drive_command,
            applied_steering_rate_radians_per_second=(
                applied_steering_rate_radians_per_second
            ),
            realized_steering_angle_radians=(
                realized_steering_angle_radians
            ),
        )
        self._records.append(
            MPCTransitionRecord(
                transition_index=transition_index,
                time_seconds=(
                    transition_index
                    * self._policy.config.model.control_timestep_seconds
                ),
                policy_result=policy_result,
                prediction_context=context,
                action_execution=execution,
                actual_model_state_before=state_before,
                actual_model_state_after=state_after,
                actual_world_pose_before=world_pose_before,
                actual_world_pose_after=world_pose_after,
                actual_reference_line_progress_before_metres=(
                    progress_before
                ),
                actual_reference_line_progress_after_metres=progress_after,
                reward=reward,
                terminated=bool(terminated),
                truncated=bool(truncated),
            )
        )
        self._pending_before = None
        self._pending_result_and_context = None

    def prepare_configured_raise(
        self,
        *,
        error,
        ground_truth_before,
    ):
        if not isinstance(error, _MPCConfiguredRaiseError):
            raise TypeError("error must be _MPCConfiguredRaiseError")
        if self._pending_before is None:
            raise RuntimeError("aborted transition was not begun")
        if self._pending_configured_raise is not None:
            raise RuntimeError("configured-raise attempt was already prepared")
        failed = error.policy_result
        expected_step = (
            self._starting_policy_control_step + len(self._records)
        )
        if failed.control_step_index != expected_step:
            raise ValueError(
                "configured-raise result is stale or out of sequence"
            )
        _, progress_before, _ = self._pending_before
        attempted_context = _prediction_context_for_attempt(
            problem=error.problem,
            policy_result=failed,
            model_config=self._policy.config.model,
            actual_progress_anchor_metres=progress_before,
        )
        self._pending_configured_raise = (failed, attempted_context)
        return attempted_context

    def abort_configured_raise(
        self,
        *,
        error,
        simulation_time_series,
        ground_truth_before,
    ):
        if self._pending_configured_raise is None:
            self.prepare_configured_raise(
                error=error,
                ground_truth_before=ground_truth_before,
            )
        failed, attempted_context = self._pending_configured_raise
        transition_index = len(self._records)
        partial_history = self._freeze(simulation_time_series)
        return MPCRolloutAbortedError(
            f"MPC rollout aborted at transition {transition_index}",
            partial_history=partial_history,
            failed_policy_result=failed,
            attempted_prediction_context=attempted_context,
            transition_index=transition_index,
        )

    def _freeze(self, simulation_time_series):
        if self._history is not None:
            raise RuntimeError("collector history was already frozen")
        if self._initial_actual_model_state is None:
            raise RuntimeError("collector was not started")
        if self._initial_actual_world_pose is None:
            raise RuntimeError("collector was not started")
        self._history = _create_mpc_rollout_history(
            formulation=self._formulation,
            variable_metadata=self._variable_metadata,
            control_timestep_seconds=(
                self._policy.config.model.control_timestep_seconds
            ),
            environment_seed=self._environment_seed,
            policy_seed=self._policy_seed,
            policy_was_reset=self._policy_was_reset,
            starting_policy_control_step=(
                self._starting_policy_control_step
            ),
            policy_config_snapshot=_snapshot_policy_config(
                self._policy.config
            ),
            environment_binding_diagnostics=(
                self._policy.binding_diagnostics
            ),
            world_prediction_capture_requested=(
                self._capture_world_predictions
            ),
            initial_actual_model_state=(
                self._initial_actual_model_state
            ),
            initial_actual_world_pose=self._initial_actual_world_pose,
            initial_reference_line_progress_metres=(
                self._initial_reference_line_progress_metres
            ),
            records=tuple(self._records),
            simulation_time_series_snapshot=simulation_time_series,
        )
        return self._history

    def finish_rollout(self, *, simulation_time_series):
        return self._freeze(simulation_time_series)
