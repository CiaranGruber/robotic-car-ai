"""Dependency-light evaluator-only MPC world projection."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from time import perf_counter

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCFormulation,
    MPCWorldPrediction,
    MPCWorldProjectionGeometry,
    MPCWorldProjectionUnavailabilityReason,
    _road_horizon_contexts_equal,
)


@dataclass(frozen=True, slots=True)
class _MPCFormulationProjectionSemantics:
    state_width: int
    road_aware: bool
    steering_rate: bool


_FORMULATION_SEMANTICS = {
    AutonomousDrivingMPCFormulation.DIRECT_STEERING: (
        _MPCFormulationProjectionSemantics(3, False, False)
    ),
    AutonomousDrivingMPCFormulation.STEERING_RATE: (
        _MPCFormulationProjectionSemantics(4, False, True)
    ),
    AutonomousDrivingMPCFormulation.ROAD_AWARE_DIRECT_STEERING: (
        _MPCFormulationProjectionSemantics(3, True, False)
    ),
    AutonomousDrivingMPCFormulation.ROAD_AWARE_STEERING_RATE: (
        _MPCFormulationProjectionSemantics(4, True, True)
    ),
}


@dataclass(frozen=True, slots=True)
class _MPCWorldProjectionAnchor:
    vehicle_position_metres: np.ndarray
    vehicle_heading_radians: float
    target_line_origin_position_metres: np.ndarray
    target_line_origin_heading_radians: float


@dataclass(frozen=True, slots=True)
class _MPCWorldProjectionOutcome:
    world_prediction: MPCWorldPrediction | None
    unavailability_reason: MPCWorldProjectionUnavailabilityReason | None

    def __post_init__(self) -> None:
        if (self.world_prediction is None) == (
            self.unavailability_reason is None
        ):
            raise ValueError("exactly one world projection outcome is required")


def _world_projection_anchor_from_ground_truth(
    ground_truth: Mapping[str, object],
) -> _MPCWorldProjectionAnchor | None:
    try:
        px = float(ground_truth["ground_truth_world_position_x_m"])
        py = float(ground_truth["ground_truth_world_position_y_m"])
        vehicle_heading = float(
            ground_truth["ground_truth_heading_in_world_frame_rad"]
        )
        relative_heading = float(
            ground_truth["heading_error_from_target_line_rad"]
        )
        target_position = np.asarray(
            ground_truth[
                "target_line_position_at_closest_reference_line_progress_in_world_frame_m"
            ],
            dtype=np.float64,
        )
    except (KeyError, TypeError, ValueError, OverflowError):
        return None
    if target_position.shape != (2,):
        return None
    values = np.array(
        (px, py, vehicle_heading, relative_heading, *target_position),
        dtype=np.float64,
    )
    if not np.isfinite(values).all():
        return None
    return _MPCWorldProjectionAnchor(
        vehicle_position_metres=np.array([px, py], dtype=np.float64),
        vehicle_heading_radians=vehicle_heading,
        target_line_origin_position_metres=np.array(target_position, copy=True),
        target_line_origin_heading_radians=(
            vehicle_heading - relative_heading
        ),
    )


def _unavailable(
    reason: MPCWorldProjectionUnavailabilityReason,
) -> _MPCWorldProjectionOutcome:
    return _MPCWorldProjectionOutcome(
        world_prediction=None,
        unavailability_reason=reason,
    )


def _local_straight_target_line(
    *,
    query_distances: np.ndarray,
    origin_position: np.ndarray,
    origin_heading: float,
) -> tuple[np.ndarray, np.ndarray]:
    tangent = np.array(
        [np.cos(origin_heading), np.sin(origin_heading)],
        dtype=np.float64,
    )
    return (
        origin_position + query_distances[:, None] * tangent,
        np.full(query_distances.shape, origin_heading),
    )


def _advance_target_pose(
    position: np.ndarray,
    heading: float,
    *,
    distance: float,
    curvature_at_start: float,
    curvature_at_end: float,
) -> tuple[np.ndarray, float]:
    mean_curvature = 0.5 * (curvature_at_start + curvature_at_end)
    next_heading = heading + mean_curvature * distance
    if abs(mean_curvature) > 1.0e-12:
        displacement = np.array(
            [
                (np.sin(next_heading) - np.sin(heading)) / mean_curvature,
                (np.cos(heading) - np.cos(next_heading)) / mean_curvature,
            ]
        )
    else:
        displacement = distance * np.array(
            [np.cos(heading), np.sin(heading)]
        )
    return position + displacement, next_heading


def _captured_curvature_target_line(
    *,
    query_distances: np.ndarray,
    origin_position: np.ndarray,
    origin_heading: float,
    source_distances: np.ndarray,
    source_curvatures: np.ndarray,
    valid_count: int,
) -> tuple[np.ndarray, np.ndarray]:
    positions = np.empty((query_distances.shape[0], 2), dtype=np.float64)
    headings = np.empty(query_distances.shape, dtype=np.float64)
    final_valid_distance = float(source_distances[valid_count - 1])
    final_curvature = float(source_curvatures[valid_count - 1])
    for query_index, query_distance in enumerate(query_distances):
        position = np.array(origin_position, dtype=np.float64, copy=True)
        heading = float(origin_heading)
        for source_index in range(valid_count - 1):
            interval_start = float(source_distances[source_index])
            interval_end = float(source_distances[source_index + 1])
            if query_distance <= interval_start:
                break
            traversed = min(float(query_distance), interval_end) - interval_start
            interval_length = interval_end - interval_start
            start_curvature = float(source_curvatures[source_index])
            end_curvature = start_curvature + (
                traversed
                / interval_length
                * (
                    float(source_curvatures[source_index + 1])
                    - start_curvature
                )
            )
            position, heading = _advance_target_pose(
                position,
                heading,
                distance=traversed,
                curvature_at_start=start_curvature,
                curvature_at_end=end_curvature,
            )
            if query_distance <= interval_end:
                break
        if query_distance > final_valid_distance:
            position, heading = _advance_target_pose(
                position,
                heading,
                distance=float(query_distance) - final_valid_distance,
                curvature_at_start=final_curvature,
                curvature_at_end=final_curvature,
            )
        positions[query_index] = position
        headings[query_index] = heading
    return positions, headings


def _source_preview_positions(
    *,
    road_context,
    origin_position: np.ndarray,
    origin_heading: float,
) -> tuple[np.ndarray, np.ndarray]:
    source_validity = road_context.source_validity
    valid_count = int(np.count_nonzero(source_validity))
    valid_distances = road_context.source_distances_metres[:valid_count]
    if road_context.use_curvature_preview:
        source_curvatures = (
            road_context.source_target_line_curvatures_per_metre
        )
        if source_curvatures is None:
            raise ValueError(
                "curvature-enabled road context requires source curvature"
            )
        valid_positions, _ = _captured_curvature_target_line(
            query_distances=valid_distances,
            origin_position=origin_position,
            origin_heading=origin_heading,
            source_distances=road_context.source_distances_metres,
            source_curvatures=source_curvatures,
            valid_count=valid_count,
        )
    else:
        valid_positions, _ = _local_straight_target_line(
            query_distances=valid_distances,
            origin_position=origin_position,
            origin_heading=origin_heading,
        )
    source_positions = np.empty(
        (source_validity.shape[0], 2),
        dtype=np.float64,
    )
    source_positions[:valid_count] = valid_positions
    source_positions[valid_count:] = valid_positions[-1]
    return source_positions, np.array(source_validity, copy=True)


def _installed_lane_bound_positions(
    *,
    road_context,
    origin_position: np.ndarray,
    origin_heading: float,
) -> tuple[np.ndarray | None, np.ndarray | None]:
    if not road_context.use_lane_bound_constraints:
        return None, None
    query_distances = road_context.road_preview_query_distances_metres[1:]
    if road_context.use_curvature_preview:
        source_curvatures = (
            road_context.source_target_line_curvatures_per_metre
        )
        if source_curvatures is None:
            raise ValueError(
                "curvature-enabled road context requires source curvature"
            )
        target_positions, target_headings = (
            _captured_curvature_target_line(
                query_distances=query_distances,
                origin_position=origin_position,
                origin_heading=origin_heading,
                source_distances=road_context.source_distances_metres,
                source_curvatures=source_curvatures,
                valid_count=int(np.count_nonzero(road_context.source_validity)),
            )
        )
    else:
        target_positions, target_headings = _local_straight_target_line(
            query_distances=query_distances,
            origin_position=origin_position,
            origin_heading=origin_heading,
        )
    lower_bounds = (
        road_context.installed_soft_lateral_error_lower_bounds_metres
    )
    upper_bounds = (
        road_context.installed_soft_lateral_error_upper_bounds_metres
    )
    if lower_bounds is None or upper_bounds is None:
        raise ValueError("lane-enabled road context requires installed bounds")
    if not np.isfinite(lower_bounds).all() or not np.isfinite(
        upper_bounds
    ).all():
        raise ValueError("installed lane bounds must be finite for projection")
    normals_left = np.column_stack(
        (-np.sin(target_headings), np.cos(target_headings))
    )
    return (
        target_positions + lower_bounds[:, None] * normals_left,
        target_positions + upper_bounds[:, None] * normals_left,
    )


def _project_mpc_world_prediction(
    *,
    formulation,
    policy_result,
    prediction_context,
    model_config,
    ground_truth,
) -> _MPCWorldProjectionOutcome:
    projection_started = perf_counter()
    if not isinstance(formulation, AutonomousDrivingMPCFormulation):
        raise TypeError(
            "formulation must be an AutonomousDrivingMPCFormulation"
        )
    try:
        semantics = _FORMULATION_SEMANTICS[formulation]
    except KeyError as error:
        raise ValueError("unsupported MPC formulation") from error
    if not policy_result.solve_usable:
        return _unavailable(
            MPCWorldProjectionUnavailabilityReason.NO_USABLE_PREDICTION
        )
    if prediction_context is None:
        raise ValueError("usable prediction requires a prediction context")
    prediction = policy_result.solve_result.prediction
    if prediction.states.shape[1] != semantics.state_width:
        raise ValueError(
            "prediction state width does not match the MPC formulation"
        )
    if prediction.controls.shape[1] != 2:
        raise ValueError("autonomous-driving MPC prediction needs two controls")
    road_context = policy_result.road_horizon_context
    if not _road_horizon_contexts_equal(
        road_context,
        prediction_context.road_horizon_context,
    ):
        raise ValueError(
            "prediction and policy result road contexts do not match"
        )
    if not semantics.road_aware and road_context is not None:
        raise ValueError("baseline MPC formulation cannot carry road context")
    if (
        semantics.road_aware
        and road_context is not None
        and road_context.use_curvature_preview
    ):
        direct_feedforward = (
            road_context.direct_steering_angle_feedforward_radians
        )
        rate_feedforward = (
            road_context.steering_angle_state_feedforward_radians
        )
        if semantics.steering_rate != (rate_feedforward is not None):
            raise ValueError(
                "curvature feedforward family does not match formulation"
            )
        if semantics.steering_rate == (direct_feedforward is not None):
            raise ValueError(
                "curvature feedforward family does not match formulation"
            )
    anchor = _world_projection_anchor_from_ground_truth(ground_truth)
    if anchor is None:
        return _unavailable(
            MPCWorldProjectionUnavailabilityReason.EVALUATOR_ANCHOR_UNAVAILABLE
        )

    states = prediction.states
    controls = prediction.controls
    timestep = model_config.control_timestep_seconds
    increments = (
        timestep * states[:-1, 0]
        + 0.5
        * timestep**2
        * (model_config.motor_force_gain_newtons / model_config.mass_kg)
        * controls[:, 0]
    )
    target_distances = np.concatenate(
        (np.array([0.0], dtype=np.float64), np.cumsum(increments))
    )
    if (
        not np.isfinite(target_distances).all()
        or np.any(target_distances < 0.0)
        or np.any(np.diff(target_distances) < 0.0)
    ):
        return _unavailable(
            MPCWorldProjectionUnavailabilityReason.TARGET_DISTANCE_INVALID
        )

    reference_progress = prediction_context.predicted_relative_progress_metres
    if reference_progress is None:
        raise ValueError(
            "usable prediction context requires current relative progress"
        )
    if reference_progress.shape != target_distances.shape:
        raise ValueError(
            "current relative progress shape does not match prediction"
        )
    target_heading = anchor.target_line_origin_heading_radians
    use_curvature = (
        semantics.road_aware
        and road_context is not None
        and road_context.use_curvature_preview
    )
    if use_curvature:
        if road_context.target_curvature_provenance not in {
            "exact_reference_line",
            "exact_parallel_curve",
        }:
            return _unavailable(
                MPCWorldProjectionUnavailabilityReason.TARGET_GEOMETRY_UNSUPPORTED
            )
        final_valid_distance = (
            road_context.final_valid_preview_distance_metres
        )
        if (
            road_context.extension_mode.value == "error"
            and target_distances[-1] > final_valid_distance
        ):
            return _unavailable(
                MPCWorldProjectionUnavailabilityReason.PREVIEW_COVERAGE_INSUFFICIENT
            )
        source_validity = road_context.source_validity
        valid_count = int(np.count_nonzero(source_validity))
        source_curvatures = (
            road_context.source_target_line_curvatures_per_metre
        )
        if source_curvatures is None:
            raise ValueError(
                "curvature-enabled road context requires source curvature"
            )
        target_positions, target_headings = _captured_curvature_target_line(
            query_distances=target_distances,
            origin_position=anchor.target_line_origin_position_metres,
            origin_heading=target_heading,
            source_distances=road_context.source_distances_metres,
            source_curvatures=source_curvatures,
            valid_count=valid_count,
        )
        geometry = MPCWorldProjectionGeometry.ROAD_AWARE_TARGET_LINE
    else:
        target_positions, target_headings = _local_straight_target_line(
            query_distances=target_distances,
            origin_position=anchor.target_line_origin_position_metres,
            origin_heading=target_heading,
        )
        geometry = MPCWorldProjectionGeometry.LOCAL_STRAIGHT_TARGET_LINE
    if semantics.road_aware and road_context is not None:
        source_positions, source_validity = _source_preview_positions(
            road_context=road_context,
            origin_position=anchor.target_line_origin_position_metres,
            origin_heading=target_heading,
        )
        right_lane_positions, left_lane_positions = (
            _installed_lane_bound_positions(
                road_context=road_context,
                origin_position=anchor.target_line_origin_position_metres,
                origin_heading=target_heading,
            )
        )
    else:
        source_positions = None
        source_validity = None
        right_lane_positions = None
        left_lane_positions = None
    normal_left = np.column_stack(
        (-np.sin(target_headings), np.cos(target_headings))
    )
    vehicle_positions = target_positions + states[:, 1, None] * normal_left
    vehicle_headings = target_headings + states[:, 2]
    world_prediction = MPCWorldPrediction(
        predicted_vehicle_positions_metres=vehicle_positions,
        predicted_vehicle_headings_radians=vehicle_headings,
        formulation_target_line_positions_metres=target_positions,
        formulation_target_line_headings_radians=target_headings,
        source_preview_target_line_positions_metres=source_positions,
        source_preview_validity=source_validity,
        installed_right_lane_bound_positions_metres=right_lane_positions,
        installed_left_lane_bound_positions_metres=left_lane_positions,
        predicted_relative_reference_progress_metres=np.array(
            reference_progress,
            copy=True,
        ),
        predicted_relative_target_line_distances_metres=np.array(
            target_distances,
            copy=True,
        ),
        authoritative_target_line_origin_position_metres=(
            anchor.target_line_origin_position_metres
        ),
        authoritative_target_line_origin_heading_radians=target_heading,
        geometry=geometry,
        formulation=formulation,
        projection_time_seconds=perf_counter() - projection_started,
    )
    return _MPCWorldProjectionOutcome(
        world_prediction=world_prediction,
        unavailability_reason=None,
    )
