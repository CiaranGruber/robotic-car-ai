"""Presentation helpers for validated unified profiling results.

This module deliberately consumes completed runner records only.  It never
starts work, owns an executor, or mutates a result bundle.
"""

from __future__ import annotations

import csv
import html
import io
import re
from typing import TYPE_CHECKING, TextIO

if TYPE_CHECKING:
    from dreamgym.profiling.autonomous_driving.runner import ProfileRunResult


_CONTROL_CHARACTER_RE = re.compile(r"[\x00-\x1f\x7f-\x9f]")
_MARKDOWN_META_RE = re.compile(r"([\\`*_{}\[\]()#+.!|>-])")


def _single_line(value: str) -> str:
    return " ".join(
        _CONTROL_CHARACTER_RE.sub(" ", value).split()
    )


def _markdown_text(value: str) -> str:
    escaped = html.escape(_single_line(value), quote=False)
    return _MARKDOWN_META_RE.sub(r"\\\1", escaped)


def render_table(result: "ProfileRunResult") -> list[tuple[str, str, int]]:
    """Return presentation-ready rows without changing the structured result."""

    return [
        (case.case_id, case.status, len(case.sample_ns))
        for case in result.case_results
    ]


def _error_summary(error) -> str:
    return (
        error["stage"]
        + " "
        + error["exception_type"]
        + ": "
        + error["message"]
    )


def _markdown_error_summary(error) -> str:
    return (
        error["stage"]
        + " "
        + _markdown_text(error["exception_type"])
        + ": "
        + _markdown_text(error["message"])
    )


def render_terminal(result: "ProfileRunResult") -> str:
    """Render a concise human-facing summary from immutable case results."""

    rows = ["Profiling status: " + result.status]
    rows.extend(
        "- {}: {} ({} samples)".format(case_id, status, samples)
        for case_id, status, samples in render_table(result)
    )
    for case in result.case_results:
        rows.extend(
            "  warning: " + _single_line(warning)
            for warning in case.warnings
        )
        rows.extend(
            "  error: " + _single_line(_error_summary(error))
            for error in case.errors
        )
    if result.warnings:
        rows.append("Warnings: " + str(len(result.warnings)))
    return "\n".join(rows)


def render_markdown(result: "ProfileRunResult") -> str:
    """Render a portable Markdown report from the validated run result."""

    lines = [
        "# Unified Autonomous-Driving Profiling Report",
        "",
        "Status: `" + result.status + "`",
        "",
        "| Case | Status | Samples |",
        "| --- | --- | ---: |",
    ]
    lines.extend(
        "| {} | {} | {} |".format(case_id, status, samples)
        for case_id, status, samples in render_table(result)
    )
    case_diagnostics = [
        (case.case_id, "warning", _markdown_text(warning))
        for case in result.case_results
        for warning in case.warnings
    ]
    case_diagnostics.extend(
        (case.case_id, "error", _markdown_error_summary(error))
        for case in result.case_results
        for error in case.errors
    )
    if case_diagnostics:
        lines.extend(["", "## Case diagnostics", ""])
        lines.extend(
            "- {} {}: {}".format(
                case_id,
                kind,
                summary,
            )
            for case_id, kind, summary in case_diagnostics
        )
    if result.warnings:
        lines.extend(["", "## Rendering warnings", ""])
        lines.extend(
            "- " + _markdown_text(warning)
            for warning in result.warnings
        )
    return "\n".join(lines) + "\n"


def render_markdown_bytes(result: "ProfileRunResult") -> bytes:
    """Return UTF-8 Markdown for parent-owned bundle persistence."""

    return render_markdown(result).encode("utf-8")


def render_csv_bytes(result: "ProfileRunResult") -> bytes:
    """Return a small UTF-8 CSV summary without writing a file."""

    handle = io.StringIO(newline="")
    writer = csv.writer(handle, lineterminator="\n")
    writer.writerow(("case_id", "status", "sample_count"))
    writer.writerows(render_table(result))
    return handle.getvalue().encode("utf-8")


def render_plot_bytes(result: "ProfileRunResult") -> bytes:
    """Optionally render sample counts into an in-memory PNG."""

    import matplotlib.pyplot as pyplot

    rows = render_table(result)
    figure, axis = pyplot.subplots()
    axis.bar(range(len(rows)), [row[2] for row in rows])
    axis.set_xlabel("case")
    axis.set_ylabel("sample count")
    output = io.BytesIO()
    try:
        figure.savefig(output, format="png")
        return output.getvalue()
    finally:
        pyplot.close(figure)


def print_terminal(result: "ProfileRunResult", stream: TextIO) -> None:
    """Print only an already-rendered result, never from an executor."""

    stream.write(render_terminal(result) + "\n")
