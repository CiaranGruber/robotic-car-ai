"""Privacy gates shared by profiling artifact writers and renderers."""

from __future__ import annotations

from collections.abc import Mapping
import getpass
import os
from pathlib import Path
from pathlib import PurePosixPath
import re
import socket
from typing import Any

from dreamgym.profiling.autonomous_driving.records import (
    exception_class_identity,
)


class PrivacyError(ValueError):
    """Raised before sensitive or host-identifying content reaches an artifact."""


_SENSITIVE_PATTERNS = (
    re.compile(
        r"(?i)(?<![a-z0-9_])[a-z]:[\\/](?=[^\s\\/])"
    ),
    re.compile(r"(?i)(?<![a-z0-9_])/(?=[^\s/])"),
    re.compile(r"(?i)\\\\[^\\\s]+\\[^\\\s]+"),
    re.compile(r"(?i)\b(?:https?|ssh|git)://"),
    re.compile(
        r"(?i)\b[a-z][a-z0-9+.-]*://"
        r"[^\s/@:]+(?::[^\s/@]*)?@"
    ),
    re.compile(r"(?i)\bgit@[^:\s]+:"),
    re.compile(r"(?i)\b(?:token|password|passwd|secret|api[_-]?key)\s*[:=]"),
    re.compile(r"(?i)\b(?:ghp|github_pat|sk)-[a-z0-9_-]{16,}\b"),
    re.compile(
        r"(?<![0-9])(?:25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})"
        r"(?:\.(?:25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})){3}(?![0-9])"
    ),
    re.compile(r"(?i)traceback \(most recent call last\)"),
)
_DIAGNOSTIC_FIELDS = frozenset(
    ("stage", "exception_type", "message", "source_locations")
)
_SOURCE_LOCATION_FIELDS = frozenset(("path", "line", "function"))
_STAGE_RE = re.compile(r"^[a-z][a-z0-9_]*$")
_DIAGNOSTIC_MESSAGE_OMITTED = (
    "diagnostic message omitted by privacy policy"
)
_SENSITIVE_ENVIRONMENT_NAME_MARKERS = (
    "TOKEN",
    "PASSWORD",
    "PASSWD",
    "SECRET",
    "API_KEY",
    "APIKEY",
    "ACCESS_KEY",
    "PRIVATE_KEY",
    "CREDENTIAL",
    "AUTHORIZATION",
    "CONNECTION_STRING",
    "JWT",
)
_SENSITIVE_ENVIRONMENT_EXACT_NAMES = frozenset(
    {"DOCKER_AUTH_CONFIG", "NPM_CONFIG__AUTH", "KAGGLE_KEY"}
)


def _selected_sensitive_environment_values(
    environ: Mapping[str, str],
) -> tuple[str, ...]:
    values = {
        value
        for name, value in environ.items()
        if value
        and (
            name.upper() in _SENSITIVE_ENVIRONMENT_EXACT_NAMES
            or any(
                marker in name.upper()
                for marker in _SENSITIVE_ENVIRONMENT_NAME_MARKERS
            )
        )
    }
    return tuple(sorted(values, key=lambda item: (-len(item), item)))


def _profiling_repository_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _runtime_diagnostic_redaction_values() -> tuple[str, ...]:
    values: set[str] = set()
    for probe in (
        getpass.getuser,
        socket.gethostname,
        lambda: str(Path.home()),
        lambda: str(_profiling_repository_root()),
    ):
        try:
            value = probe()
        except Exception:
            continue
        if value:
            values.add(value)
    values.update(_selected_sensitive_environment_values(os.environ))
    return tuple(sorted(values, key=lambda item: (-len(item), item)))


def _safe_string(value: str) -> None:
    for pattern in _SENSITIVE_PATTERNS:
        if pattern.search(value):
            raise PrivacyError("artifact text contains privacy-sensitive content")


def ensure_artifact_safe(value: Any) -> Any:
    """Reject privacy-sensitive content in renderer inputs.

    The function deliberately returns its input so it can be placed directly at
    an output boundary. It never attempts lossy redaction of scientific data.
    """

    if value is None or type(value) in (bool, int, float):
        return value
    if type(value) is str:
        _safe_string(value)
        return value
    if isinstance(value, BaseException):
        if value.__traceback__ is not None:
            raise PrivacyError("artifact exception contains an attached traceback")
        _safe_string(str(value))
        return value
    if isinstance(value, Mapping):
        for key, item in value.items():
            if type(key) is not str:
                raise PrivacyError("artifact object keys must be strings")
            _safe_string(key)
            ensure_artifact_safe(item)
        return value
    if isinstance(value, (list, tuple)):
        for item in value:
            ensure_artifact_safe(item)
        return value

    # NumPy is optional at this boundary. Duck-typing avoids making it a new
    # dependency of metadata collection while still scanning plot/NPZ labels.
    dtype = getattr(value, "dtype", None)
    tolist = getattr(value, "tolist", None)
    if dtype is not None and callable(tolist):
        ensure_artifact_safe(tolist())
        return value
    raise PrivacyError(
        "artifact value is not in the privacy gate's supported allowlist"
    )


def is_controlled_diagnostic_stage(value: Any) -> bool:
    return type(value) is str and _STAGE_RE.fullmatch(value) is not None


def _contains_redaction_value(
    value: str,
    redaction_values: tuple[str, ...],
) -> bool:
    folded = value.casefold()
    for redaction_value in redaction_values:
        candidate = redaction_value.casefold()
        if not candidate:
            continue
        if re.fullmatch(r"[a-z0-9_]+", candidate):
            matched = (
                folded == candidate
                or re.search(
                    r"(?<![a-z0-9_])"
                    + re.escape(candidate)
                    + r"(?![a-z0-9_])",
                    folded,
                )
                is not None
            )
        else:
            matched = candidate in folded
        if matched:
            return True
    return False


def sanitize_diagnostic_message(
    value: Any,
    *,
    redaction_values: tuple[str, ...] | None = None,
) -> str:
    if type(value) is not str or not value:
        raise ValueError("diagnostic message must be a non-empty string")
    try:
        ensure_artifact_safe(value)
    except PrivacyError:
        return _DIAGNOSTIC_MESSAGE_OMITTED
    active = (
        _runtime_diagnostic_redaction_values()
        if redaction_values is None
        else tuple(item for item in redaction_values if item)
    )
    if _contains_redaction_value(value, active):
        return _DIAGNOSTIC_MESSAGE_OMITTED
    return value


def sanitize_case_warning(
    value: Any,
    *,
    redaction_values: tuple[str, ...] | None = None,
) -> str:
    """Return one non-empty warning safe for every profiling output."""

    return sanitize_diagnostic_message(value, redaction_values=redaction_values)


def validate_case_warning(value: Any) -> str:
    """Require a persisted warning to already satisfy the privacy gate."""

    if type(value) is not str or not value:
        raise ValueError("diagnostic message must be a non-empty string")
    ensure_artifact_safe(value)
    return value


def _repository_relative_source_location(
    value: Any,
    *,
    repository_root: Path,
) -> dict[str, Any]:
    if type(value) is not dict or set(value) != _SOURCE_LOCATION_FIELDS:
        raise ValueError(
            "diagnostic source location must contain only path, line, and function"
        )
    relative = value["path"]
    if (
        type(relative) is not str
        or not relative
        or "\\" in relative
        or ":" in relative
    ):
        raise ValueError(
            "diagnostic source location path must be POSIX repository-relative"
        )
    pure = PurePosixPath(relative)
    if pure.is_absolute() or any(part in ("", ".", "..") for part in pure.parts):
        raise ValueError(
            "diagnostic source location path must be POSIX repository-relative"
        )
    root = repository_root.resolve(strict=True)
    resolved = (root / Path(*pure.parts)).resolve(strict=False)
    try:
        canonical_relative = resolved.relative_to(root).as_posix()
    except ValueError as error:
        raise ValueError(
            "diagnostic source location must resolve inside the repository"
        ) from error
    if canonical_relative != relative:
        raise ValueError(
            "diagnostic source location path must use its canonical repository path"
        )
    line = value["line"]
    function = value["function"]
    if type(line) is not int or line <= 0:
        raise ValueError("diagnostic source location line must be positive")
    if type(function) is not str or not function:
        raise ValueError(
            "diagnostic source location function must be a non-empty string"
        )
    location = {
        "path": canonical_relative,
        "line": line,
        "function": function,
    }
    ensure_artifact_safe(location)
    return location


def _validate_case_diagnostic_structure(
    value: Any,
    *,
    repository_root: Path | None = None,
) -> dict[str, Any]:
    """Return a static-safe diagnostic with its exact structural contract."""

    if type(value) is not dict or set(value) != _DIAGNOSTIC_FIELDS:
        raise ValueError(
            "case diagnostic must contain only stage, exception_type, "
            "message, and source_locations"
        )
    stage = value["stage"]
    exception_type = value["exception_type"]
    if not is_controlled_diagnostic_stage(stage):
        raise ValueError("diagnostic stage must be a stable controlled token")
    if type(exception_type) is not str or not exception_type:
        raise ValueError(
            "diagnostic exception_type must be a non-empty class name"
        )
    locations = value["source_locations"]
    if type(locations) is not list:
        raise TypeError("diagnostic source_locations must be an array")
    root = (
        _profiling_repository_root()
        if repository_root is None
        else Path(repository_root)
    )
    diagnostic = {
        "stage": stage,
        "exception_type": exception_type,
        "message": value["message"],
        "source_locations": [
            _repository_relative_source_location(
                location,
                repository_root=root,
            )
            for location in locations
        ],
    }
    ensure_artifact_safe(diagnostic)
    return diagnostic


def sanitize_case_diagnostic(
    value: Any,
    *,
    repository_root: Path | None = None,
    redaction_values: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    """Sanitize a source-time diagnostic message before structural validation."""

    if type(value) is not dict or "message" not in value:
        raise ValueError("case diagnostic must contain a message")
    diagnostic = dict(value)
    diagnostic["message"] = sanitize_diagnostic_message(
        value["message"],
        redaction_values=redaction_values,
    )
    return _validate_case_diagnostic_structure(
        diagnostic,
        repository_root=repository_root,
    )


def validate_case_diagnostic(
    value: Any,
    *,
    repository_root: Path | None = None,
) -> dict[str, Any]:
    """Require a persisted diagnostic to be exact and already privacy-safe."""

    return _validate_case_diagnostic_structure(
        value,
        repository_root=repository_root,
    )


def case_diagnostic_from_exception(
    stage: str,
    error: BaseException,
    *,
    exception_type: str | None = None,
    message: str | None = None,
    repository_root: Path | None = None,
    redaction_values: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    """Build a sanitized diagnostic without retaining a raw traceback."""

    if not isinstance(error, BaseException):
        raise TypeError("error must be an exception")
    error_class_name = exception_class_identity(error)[1]
    fallback_stage = (
        stage
        if is_controlled_diagnostic_stage(stage)
        else "case_execution"
    )
    fallback_exception_type = "Exception"
    try:
        candidate_exception_type = error_class_name
        if not candidate_exception_type:
            raise ValueError
        ensure_artifact_safe(candidate_exception_type)
        fallback_exception_type = candidate_exception_type
    except BaseException:
        pass
    fallback = {
        "stage": fallback_stage,
        "exception_type": fallback_exception_type,
        "message": _DIAGNOSTIC_MESSAGE_OMITTED,
        "source_locations": [],
    }
    try:
        root = (
            _profiling_repository_root()
            if repository_root is None
            else Path(repository_root)
        ).resolve(strict=True)
        locations: list[dict[str, Any]] = []
        traceback = error.__traceback__
        while traceback is not None:
            frame = traceback.tb_frame
            resolved = Path(
                frame.f_code.co_filename
            ).resolve(strict=False)
            try:
                relative = resolved.relative_to(root)
            except ValueError:
                pass
            else:
                locations.append(
                    {
                        "path": relative.as_posix(),
                        "line": traceback.tb_lineno,
                        "function": frame.f_code.co_name,
                    }
                )
            traceback = traceback.tb_next
        diagnostic_exception_type = (
            error_class_name
            if exception_type is None
            else exception_type
        )
        if message is None:
            try:
                diagnostic_message = str(error)
            except BaseException:
                diagnostic_message = error_class_name or "Exception"
            if not diagnostic_message:
                diagnostic_message = error_class_name or "Exception"
        else:
            diagnostic_message = message
        return sanitize_case_diagnostic(
            {
                "stage": stage,
                "exception_type": diagnostic_exception_type,
                "message": diagnostic_message,
                "source_locations": locations,
            },
            repository_root=root,
            redaction_values=redaction_values,
        )
    except Exception:
        return fallback


def case_measurement_diagnostic(
    stage: str,
    message: str,
    *,
    redaction_values: tuple[str, ...] | None = None,
) -> dict[str, Any]:
    """Build a sanitized non-exception measurement-failure diagnostic."""

    return sanitize_case_diagnostic(
        {
            "stage": stage,
            "exception_type": "CaseMeasurementError",
            "message": message,
            "source_locations": [],
        },
        redaction_values=redaction_values,
    )
