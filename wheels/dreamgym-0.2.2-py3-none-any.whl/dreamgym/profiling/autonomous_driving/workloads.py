"""Versioned, typed workload population for autonomous-driving profiling.

The resolver is deliberately pre-execution: resource identity and release
status come from normalized requested semantics and execution requirements,
never from observed timing results or machine-dependent facts.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
import hashlib
import importlib.resources
import json
from pathlib import Path
import stat
from types import MappingProxyType
from typing import Any, Literal

from dreamgym.profiling.autonomous_driving.production_rl import (
    RLCaseRequest,
    build_algorithm_comparison_case,
    build_ppo_step_scaling_case,
    build_ppo_vectorization_case,
    resolve_rl_profile_case,
)
from dreamgym.profiling.autonomous_driving.records import (
    CaseSpec,
    ExecutionSpec,
    PROFILE_RESULTS_SCHEMA_VERSION,
    ResolvedWorkload,
    canonical_json_bytes,
)


HISTORICAL_WORKLOAD_VERSION_V2 = (
    "dreamgym-autonomous-driving-workload-v2"
)
WORKLOAD_VERSION = "dreamgym-autonomous-driving-workload-v3"
WORKLOAD_RESOURCE_SCHEMA_VERSION = "dreamgym-autonomous-driving-workload-resource-v2"
_ACTIVE_WORKLOAD_RESOURCE_NAMES = frozenset({
    "workload_development_v3.json",
    "workload_v3.json",
    "submission_workload_v3.json",
})
PROFILING_V3_NOT_RELEASED_MESSAGE = "profiling v3 is not yet released"
_V3_RELEASE_RESOURCE_NAMES = (
    "workload_v3.json",
    "submission_workload_v3.json",
    "benchmark_sources_workload_v3.json",
)
_V3_CANDIDATE_RESOURCE_NAME = "workload_release_candidate_v3.json"


@dataclass(frozen=True)
class _V3PresetDefinition:
    """One immutable canonical candidate definition before calibration."""

    core_suite_scope: Literal["quick_subset", "full"]
    warmup_iterations: int
    sample_count: int
    repetitions: int
    mpc_policies: tuple[str, ...]
    mpc_horizons: tuple[int, ...]
    mpc_soft_modes: tuple[str, ...]
    rl_algorithms: tuple[str, ...]
    algorithm_requested_transition_target: int
    ppo_scaling_requested_transition_targets: tuple[int, ...]
    ppo_vector_n_envs: tuple[int, ...]
    ppo_vector_requested_transition_target: int


@dataclass(frozen=True)
class _V3SubmissionDefinition:
    """Immutable fixed submission selection; execution inherits long."""

    mpc_policy: str
    mpc_horizons: tuple[int, ...]
    mpc_soft_mode: str
    ppo_vector_n_envs: tuple[int, ...]
    ppo_vector_requested_transition_target: int


# This is the sole authority for canonical preset-owned composition and counts.
_V3_PRESET_DEFINITIONS = MappingProxyType({
    "quick": _V3PresetDefinition(
        core_suite_scope="quick_subset",
        warmup_iterations=50,
        sample_count=100,
        repetitions=3,
        mpc_policies=("direct_steering", "steering_rate"),
        mpc_horizons=(10, 20, 40, 80),
        mpc_soft_modes=("off", "on"),
        rl_algorithms=("PPO", "SAC", "TD3", "DDPG", "A2C"),
        algorithm_requested_transition_target=10_000,
        ppo_scaling_requested_transition_targets=(10_000, 100_000),
        ppo_vector_n_envs=(1, 2, 4, 8),
        ppo_vector_requested_transition_target=100_000,
    ),
    "medium": _V3PresetDefinition(
        core_suite_scope="full",
        warmup_iterations=200,
        sample_count=100,
        repetitions=4,
        mpc_policies=("direct_steering", "steering_rate"),
        mpc_horizons=(10, 20, 40, 80),
        mpc_soft_modes=("off", "on"),
        rl_algorithms=("PPO", "SAC", "TD3", "DDPG", "A2C"),
        algorithm_requested_transition_target=10_000,
        ppo_scaling_requested_transition_targets=(10_000, 100_000, 500_000),
        ppo_vector_n_envs=(1, 2, 4, 8),
        ppo_vector_requested_transition_target=100_000,
    ),
    "long": _V3PresetDefinition(
        core_suite_scope="full",
        warmup_iterations=200,
        sample_count=100,
        repetitions=6,
        mpc_policies=("direct_steering", "steering_rate"),
        mpc_horizons=(10, 20, 40, 80),
        mpc_soft_modes=("off", "on"),
        rl_algorithms=("PPO", "SAC", "TD3", "DDPG", "A2C"),
        algorithm_requested_transition_target=100_000,
        ppo_scaling_requested_transition_targets=(
            10_000,
            100_000,
            500_000,
            1_000_000,
        ),
        ppo_vector_n_envs=(1, 2, 4, 8),
        ppo_vector_requested_transition_target=100_000,
    ),
})
_V3_SUBMISSION_DEFINITION = _V3SubmissionDefinition(
    mpc_policy="steering_rate",
    mpc_horizons=(20, 80),
    mpc_soft_mode="on",
    ppo_vector_n_envs=(1, 4),
    ppo_vector_requested_transition_target=100_000,
)
_DEVELOPMENT_EXECUTION_COUNTS = MappingProxyType({
    "warmup_iterations": 1,
    "sample_count": 1,
    "repetitions": 1,
})
_PRESETS = tuple(_V3_PRESET_DEFINITIONS)


def _execution_counts(definition: _V3PresetDefinition) -> Mapping[str, int]:
    return MappingProxyType({
        "warmup_iterations": definition.warmup_iterations,
        "sample_count": definition.sample_count,
        "repetitions": definition.repetitions,
    })


@dataclass(frozen=True)
class ProfileRequest:
    """Student-facing comparison selections plus operational destinations."""

    preset: Literal["quick", "medium", "long"] = "quick"
    mpc_prediction_horizon_steps: Sequence[int] | None = None
    mpc_soft_constraint_modes: Sequence[str] | None = None
    rl_algorithms: Sequence[str] | None = None
    rl_training_steps: Sequence[int] | None = None
    rl_n_envs: Sequence[int] | None = None
    output_dir: Path | str | None = None
    resume_from: Path | str | None = None


@dataclass(frozen=True)
class AdvancedProfileRequest(ProfileRequest):
    """Non-student override surface for explicitly custom workload research."""

    vector_training_steps: int | None = None
    include_road_aware_mpc: bool = False


@dataclass(frozen=True)
class ResolvedRLWorkloadCase:
    """RL resolution plus the workload-owned execution requirements."""

    request: RLCaseRequest
    case_spec: CaseSpec
    execution_spec: ExecutionSpec
    families: tuple[str, ...]
    worker_execution_spec_digest: str
    requested_config_digest: str

    @property
    def execution_document(self) -> Mapping[str, Any]:
        return self.execution_spec.execution_document


@dataclass(frozen=True)
class RLDestinationView:
    """One ordered comparison view over an exact scheduled RL execution."""

    readable_identity: str
    family: str
    requested_transition_target: int
    semantic_case_digest: str
    destination_execution_spec_digest: str
    destination_requested_config_digest: str
    destination_requested_config_path: str
    selected_source_case_id: str
    selected_source_execution_spec_digest: str
    selected_source_requested_config_digest: str
    selected_source_requested_config_path: str
    selected_source_resolved_config_path: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "readable_identity": self.readable_identity,
            "family": self.family,
            "requested_transition_target": self.requested_transition_target,
            "semantic_case_digest": self.semantic_case_digest,
            "destination_execution_spec_digest": (
                self.destination_execution_spec_digest
            ),
            "destination_requested_config_digest": (
                self.destination_requested_config_digest
            ),
            "destination_requested_config_path": (
                self.destination_requested_config_path
            ),
            "selected_source_case_id": self.selected_source_case_id,
            "selected_source_execution_spec_digest": (
                self.selected_source_execution_spec_digest
            ),
            "selected_source_requested_config_digest": (
                self.selected_source_requested_config_digest
            ),
            "selected_source_requested_config_path": (
                self.selected_source_requested_config_path
            ),
            "selected_source_resolved_config_path": (
                self.selected_source_resolved_config_path
            ),
        }


@dataclass(frozen=True)
class ResolvedProfileWorkload:
    """A resolved workload with non-volatile workload-level eligibility."""

    workload: ResolvedWorkload
    normalized_request: ProfileRequest
    classification: str
    canonical_status: bool
    submission_status: bool
    _core_cases: tuple[CaseSpec, ...]
    _mpc_cases: tuple[CaseSpec, ...]
    _rl_cases: tuple[ResolvedRLWorkloadCase, ...]
    _rl_destination_views: tuple[RLDestinationView, ...] = ()
    workload_release_id: str | None = None
    result_schema_release_id: str | None = None
    timing_protocol_release_id: str | None = None

    def core_cases(self) -> tuple[CaseSpec, ...]:
        return self._core_cases

    def mpc_cases(self) -> tuple[CaseSpec, ...]:
        return self._mpc_cases

    def rl_cases(self, family: str | None = None) -> tuple[ResolvedRLWorkloadCase, ...]:
        if family is None:
            return self._rl_cases
        return tuple(case for case in self._rl_cases if family in case.families)

    def rl_destination_views(self) -> tuple[RLDestinationView, ...]:
        return self._rl_destination_views

    def rl_binding_for(
        self,
        case: CaseSpec,
        execution: ExecutionSpec,
    ) -> ResolvedRLWorkloadCase:
        """Resolve one exact deduplicated RL execution binding."""

        matches = tuple(
            binding
            for binding in self._rl_cases
            if (
                binding.case_spec.semantic_case_digest
                == case.semantic_case_digest
                and binding.execution_spec.execution_spec_digest
                == execution.execution_spec_digest
            )
        )
        if not matches:
            raise ValueError("no matching RL execution binding")
        if len(matches) != 1:
            raise ValueError("RL execution binding is ambiguous")
        return matches[0]

    def suite_for(self, case: CaseSpec, execution: ExecutionSpec) -> str:
        """Return the workload-owned suite without changing semantic identity."""

        suite = case.semantic_document.get("suite")
        if type(suite) is str and suite:
            return suite
        self.rl_binding_for(case, execution)
        return "rl"

    def to_dict(self) -> dict[str, Any]:
        return {
            "release_status": {
                "classification": self.classification,
                "canonical_status": self.canonical_status,
                "submission_status": self.submission_status,
            },
            "resolved_workload": self.workload.to_dict(),
            "rl_destination_views": [
                view.to_dict() for view in self._rl_destination_views
            ],
        }


@dataclass(frozen=True)
class ResolvedProfileRelease:
    """Strict released three-preset authority."""

    aggregate_resource_digest: str
    resource_sha256: str
    workload_release_id: str
    result_schema_release_id: str
    timing_protocol_release_id: str
    classification: str
    canonical_status: bool
    submission_status: bool
    _preset_resolutions: tuple[
        tuple[str, ResolvedProfileWorkload], ...
    ]
    _stored_snapshot_bytes: tuple[tuple[str, bytes], ...]

    def preset(self, name: str) -> ResolvedProfileWorkload:
        """Return one named, re-resolved canonical preset."""

        for preset_name, resolved in self._preset_resolutions:
            if preset_name == name:
                return resolved
        raise ValueError("released preset is not supported.")

    def stored_preset_snapshot(self, name: str) -> dict[str, Any]:
        """Return a detached copy of one released serialized snapshot."""

        for preset_name, snapshot_bytes in self._stored_snapshot_bytes:
            if preset_name == name:
                return json.loads(snapshot_bytes.decode("utf-8"))
        raise ValueError("released preset is not supported.")


def _normalize_positive_ints(value: Sequence[int] | None, name: str, default: tuple[int, ...]) -> tuple[int, ...]:
    if value is None:
        return default
    if isinstance(value, (str, bytes)):
        raise TypeError(name + " must be a sequence of integers.")
    normalized = []
    for item in value:
        if type(item) is not int:
            raise TypeError(name + " must contain integers.")
        if item <= 0:
            raise ValueError(name + " must contain positive integers.")
        normalized.append(item)
    if not normalized:
        raise ValueError(name + " must not be empty.")
    return tuple(sorted(set(normalized)))


def _normalize_soft_modes(
    value: Sequence[str] | None,
    default: tuple[str, ...],
) -> tuple[str, ...]:
    if value is None:
        return default
    if isinstance(value, (str, bytes)):
        raise TypeError("mpc_soft_constraint_modes must be a sequence.")
    normalized = []
    for item in value:
        if type(item) is not str:
            raise TypeError("mpc_soft_constraint_modes must contain strings.")
        mode = item.lower()
        if mode not in default:
            raise ValueError("mpc_soft_constraint_modes must contain only off or on.")
        normalized.append(mode)
    if not normalized:
        raise ValueError("mpc_soft_constraint_modes must not be empty.")
    return tuple(mode for mode in default if mode in normalized)


def _normalize_algorithms(
    value: Sequence[str] | None,
    default: tuple[str, ...],
) -> tuple[str, ...]:
    if value is None:
        return default
    if isinstance(value, (str, bytes)):
        raise TypeError("rl_algorithms must be a sequence.")
    selected = set()
    for item in value:
        if type(item) is not str:
            raise TypeError("rl_algorithms must contain strings.")
        algorithm = item.upper()
        if algorithm not in default:
            raise ValueError("rl_algorithms contains an unsupported algorithm.")
        selected.add(algorithm)
    if not selected:
        raise ValueError("rl_algorithms must not be empty.")
    return tuple(algorithm for algorithm in default if algorithm in selected)


def _normalize_request(request: ProfileRequest) -> ProfileRequest:
    if not isinstance(request, ProfileRequest):
        raise TypeError("request must be a ProfileRequest.")
    if request.preset not in _PRESETS:
        raise ValueError("preset must be quick, medium, or long.")
    definition = _V3_PRESET_DEFINITIONS[request.preset]
    return replace(
        request,
        mpc_prediction_horizon_steps=_normalize_positive_ints(
            request.mpc_prediction_horizon_steps,
            "mpc_prediction_horizon_steps",
            definition.mpc_horizons,
        ),
        mpc_soft_constraint_modes=_normalize_soft_modes(
            request.mpc_soft_constraint_modes,
            definition.mpc_soft_modes,
        ),
        rl_algorithms=_normalize_algorithms(
            request.rl_algorithms,
            definition.rl_algorithms,
        ),
        rl_training_steps=_normalize_positive_ints(
            request.rl_training_steps,
            "rl_training_steps",
            definition.ppo_scaling_requested_transition_targets,
        ),
        rl_n_envs=_normalize_positive_ints(
            request.rl_n_envs,
            "rl_n_envs",
            definition.ppo_vector_n_envs,
        ),
    )


def _core_execution(
    case: CaseSpec,
    counts: Mapping[str, int],
    candidate: bool,
    required: bool,
) -> tuple[CaseSpec, ExecutionSpec]:
    execution = ExecutionSpec(
        semantic_case_id=case.semantic_case_id,
        execution_document={
            "execution_spec_version": "dreamgym-core-execution-v1",
            "candidate_execution": candidate,
            "required": required,
            **counts,
        },
    )
    return case, execution


def _mpc_case(
    policy: str,
    horizon: int,
    soft_mode: str,
    counts: Mapping[str, int],
    candidate: bool,
    required: bool,
) -> tuple[CaseSpec, ExecutionSpec]:
    from dreamgym.profiling.autonomous_driving.mpc import (
        mpc_fixture_sequence_spec,
    )

    road_aware = policy.startswith("road_aware_")
    mpc_semantics = {
        "policy": policy,
        "road_aware": road_aware,
        "prediction_horizon_steps": horizon,
        "soft_constraints": soft_mode,
    }
    if required:
        mpc_semantics["fixture_sequence"] = mpc_fixture_sequence_spec(
            road_aware=road_aware,
        )
    case = CaseSpec(
        readable_prefix="mpc-" + policy + "-h" + str(horizon) + "-soft-" + soft_mode,
        semantic_document={
            "suite": "mpc",
            "mpc": mpc_semantics,
        },
        timing_protocol={"version": "dreamgym-mpc-solve-timing-v1", "clock": "perf_counter_ns"},
    )
    execution = ExecutionSpec(
        semantic_case_id=case.semantic_case_id,
        execution_document={
            "execution_spec_version": "dreamgym-mpc-execution-v1",
            "candidate_execution": candidate,
            "required": required,
            **counts,
        },
    )
    return case, execution


def _rl_workload_case(
    request: RLCaseRequest,
    candidate: bool,
    required: bool,
) -> ResolvedRLWorkloadCase:
    resolved = resolve_rl_profile_case(request)
    execution_document = resolved.execution_spec.to_dict()["execution_document"]
    execution_document["candidate_execution"] = candidate
    execution_document["required"] = required
    execution = ExecutionSpec(
        semantic_case_id=resolved.case_spec.semantic_case_id,
        execution_document=execution_document,
    )
    return ResolvedRLWorkloadCase(
        request=resolved.request,
        case_spec=resolved.case_spec,
        execution_spec=execution,
        families=(request.case_family,),
        worker_execution_spec_digest=(
            resolved.execution_spec.execution_spec_digest
        ),
        requested_config_digest=resolved.requested_config_digest,
    )


def _deduplicate_rl_bindings(
    bindings: Sequence[ResolvedRLWorkloadCase],
) -> tuple[ResolvedRLWorkloadCase, ...]:
    """Deduplicate RL identity, execution and request provenance together."""

    deduplicated: list[ResolvedRLWorkloadCase] = []
    positions: dict[tuple[str, str], int] = {}
    for binding in bindings:
        key = (
            binding.case_spec.semantic_case_digest,
            binding.execution_spec.execution_spec_digest,
        )
        position = positions.get(key)
        if position is None:
            positions[key] = len(deduplicated)
            deduplicated.append(binding)
            continue
        previous = deduplicated[position]
        families = tuple(dict.fromkeys((*previous.families, *binding.families)))
        deduplicated[position] = replace(previous, families=families)
    return tuple(deduplicated)


def _rl_destination_view_records(
    requested: Sequence[ResolvedRLWorkloadCase],
    scheduled: Sequence[ResolvedRLWorkloadCase],
) -> tuple[RLDestinationView, ...]:
    sources = {
        (
            binding.case_spec.semantic_case_digest,
            binding.execution_spec.execution_spec_digest,
        ): binding
        for binding in scheduled
    }
    views = []
    for binding in requested:
        source = sources[(
            binding.case_spec.semantic_case_digest,
            binding.execution_spec.execution_spec_digest,
        )]
        destination_digest = binding.requested_config_digest
        source_digest = source.requested_config_digest
        views.append(
            RLDestinationView(
                readable_identity=binding.request.case_name,
                family=binding.request.case_family,
                requested_transition_target=binding.request.rl_training_steps,
                semantic_case_digest=binding.case_spec.semantic_case_digest,
                destination_execution_spec_digest=(
                    binding.execution_spec.execution_spec_digest
                ),
                destination_requested_config_digest=destination_digest,
                destination_requested_config_path=(
                    "training_configs/"
                    + destination_digest
                    + "/config.json"
                ),
                selected_source_case_id=source.case_spec.semantic_case_id,
                selected_source_execution_spec_digest=(
                    source.execution_spec.execution_spec_digest
                ),
                selected_source_requested_config_digest=source_digest,
                selected_source_requested_config_path=(
                    "training_configs/" + source_digest + "/config.json"
                ),
                selected_source_resolved_config_path=(
                    "training_configs/"
                    + source_digest
                    + "/resolved_config.json"
                ),
            )
        )
    return tuple(views)


def _deduplicate_pairs(
    pairs: Sequence[tuple[CaseSpec, ExecutionSpec]],
) -> tuple[tuple[CaseSpec, ExecutionSpec], ...]:
    """Retain the first canonical identity for equivalent semantics."""

    deduplicated: list[tuple[CaseSpec, ExecutionSpec]] = []
    positions: dict[tuple[str, str], int] = {}
    for case, execution in pairs:
        key = (
            case.semantic_case_digest,
            execution.execution_spec_digest,
        )
        position = positions.get(key)
        if position is not None:
            continue
        positions[key] = len(deduplicated)
        deduplicated.append((case, execution))
    return tuple(deduplicated)


def _build_live_v3_workload(
    request: ProfileRequest,
    *,
    classification: str,
    candidate: bool,
    counts: Mapping[str, int],
    definition: _V3PresetDefinition,
    canonical_contract: bool = True,
    submission: bool = False,
) -> ResolvedProfileWorkload:
    normalized = _normalize_request(request)
    if submission:
        submission_definition = _V3_SUBMISSION_DEFINITION
        mpc_pairs = tuple(
            _mpc_case(
                submission_definition.mpc_policy,
                horizon,
                submission_definition.mpc_soft_mode,
                counts,
                candidate,
                True,
            )
            for horizon in submission_definition.mpc_horizons
        )
        rl_cases = tuple(
            _rl_workload_case(
                build_ppo_vectorization_case(
                    n_envs,
                    rl_training_steps=(
                        submission_definition
                        .ppo_vector_requested_transition_target
                    ),
                ),
                candidate,
                True,
            )
            for n_envs in submission_definition.ppo_vector_n_envs
        )
        pairs = _deduplicate_pairs([
            *mpc_pairs,
            *((item.case_spec, item.execution_spec) for item in rl_cases),
        ])
        workload_release_id = None
        result_schema_release_id = None
        timing_protocol_release_id = None
        if not candidate:
            from dreamgym.profiling.autonomous_driving.release import (
                RESULT_SCHEMA_RELEASE_ID,
                SUBMISSION_RELEASE_ID,
                TIMING_PROTOCOL_RELEASE_ID,
            )

            workload_release_id = SUBMISSION_RELEASE_ID
            result_schema_release_id = RESULT_SCHEMA_RELEASE_ID
            timing_protocol_release_id = TIMING_PROTOCOL_RELEASE_ID
        return ResolvedProfileWorkload(
            workload=ResolvedWorkload(
                workload_version=WORKLOAD_VERSION,
                cases=pairs,
            ),
            normalized_request=normalized,
            classification=classification,
            canonical_status=not candidate,
            submission_status=not candidate,
            _core_cases=(),
            _mpc_cases=tuple(case for case, _ in mpc_pairs),
            _rl_cases=rl_cases,
            _rl_destination_views=_rl_destination_view_records(
                rl_cases,
                rl_cases,
            ),
            workload_release_id=workload_release_id,
            result_schema_release_id=result_schema_release_id,
            timing_protocol_release_id=timing_protocol_release_id,
        )
    from dreamgym.profiling.autonomous_driving.core_suites import (
        build_core_case_specs,
    )

    core_catalog = build_core_case_specs()
    if not canonical_contract:
        core_cases = core_catalog[:4]
    elif definition.core_suite_scope == "quick_subset":
        quick_names = (
            "core-road-reference_line",
            "core-road-target_lane",
            "core-road-fixed_offset",
            "core-road-local_hint",
            "core-road-no_lookahead",
            "core-road-large_lookahead",
            "core-road-component_breakdown",
            "core-observation-flat_basic",
            "core-observation-flat_rich",
            "core-observation-dict_basic",
            "core-observation-dict_rich",
            "core-reset-fixed_road_public_reset",
            "core-reset-production_schema_v2_reset",
            "core-bicycle-kinematic_euler_1_default",
            "core-bicycle-kinematic_rk4_4_dry",
            "core-bicycle-blended_euler_1_default",
            "core-bicycle-blended_rk4_4_dry",
            "core-bicycle-dynamic_euler_1_default",
            "core-bicycle-dynamic_rk4_4_dry",
            "core-gym-step-flat_basic_step_only",
            "core-gym-step-dict_basic_step_only",
            "core-gym-step-flat_basic_reset_encountering_rollout",
            "core-gymnasium-registration",
        )
        by_name = {case.readable_prefix: case for case in core_catalog}
        core_cases = tuple(by_name[name] for name in quick_names)
    else:
        core_cases = core_catalog
    core_pairs = tuple(
        _core_execution(case, counts, candidate, canonical_contract)
        for case in core_cases
    )
    mpc_policies = definition.mpc_policies
    if isinstance(normalized, AdvancedProfileRequest) and normalized.include_road_aware_mpc:
        mpc_policies += (
            "road_aware_direct_steering",
            "road_aware_steering_rate",
        )
        classification = "custom"
    mpc_pairs = tuple(
        _mpc_case(
            policy,
            horizon,
            soft_mode,
            counts,
            candidate,
            canonical_contract,
        )
        for policy in mpc_policies
        for horizon in normalized.mpc_prediction_horizon_steps
        for soft_mode in normalized.mpc_soft_constraint_modes
    )
    rl_cases: list[ResolvedRLWorkloadCase] = []
    rl_cases.extend(
        _rl_workload_case(
            build_algorithm_comparison_case(
                algorithm,
                definition.algorithm_requested_transition_target,
            ),
            candidate,
            canonical_contract,
        )
        for algorithm in normalized.rl_algorithms
    )
    rl_cases.extend(
        _rl_workload_case(
            build_ppo_step_scaling_case(steps),
            candidate,
            canonical_contract,
        )
        for steps in normalized.rl_training_steps
    )
    vector_steps = definition.ppo_vector_requested_transition_target
    if isinstance(normalized, AdvancedProfileRequest) and normalized.vector_training_steps is not None:
        vector_steps = _normalize_positive_ints((normalized.vector_training_steps,), "vector_training_steps", ())[0]
        classification = "custom"
    rl_cases.extend(
        _rl_workload_case(
            build_ppo_vectorization_case(
                n_envs,
                rl_training_steps=vector_steps,
            ),
            candidate,
            canonical_contract,
        )
        for n_envs in normalized.rl_n_envs
    )
    requested_rl_bindings = tuple(rl_cases)
    rl_bindings = _deduplicate_rl_bindings(requested_rl_bindings)
    pairs = _deduplicate_pairs(
        [
            *core_pairs,
            *mpc_pairs,
            *((item.case_spec, item.execution_spec) for item in rl_bindings),
        ]
    )
    workload = ResolvedWorkload(workload_version=WORKLOAD_VERSION, cases=pairs)
    is_canonical = classification == "canonical"
    workload_release_id = None
    result_schema_release_id = None
    timing_protocol_release_id = None
    if is_canonical:
        from dreamgym.profiling.autonomous_driving.release import (
            RESULT_SCHEMA_RELEASE_ID,
            TIMING_PROTOCOL_RELEASE_ID,
            WORKLOAD_RELEASE_ID,
        )

        workload_release_id = WORKLOAD_RELEASE_ID
        result_schema_release_id = RESULT_SCHEMA_RELEASE_ID
        timing_protocol_release_id = TIMING_PROTOCOL_RELEASE_ID
    return ResolvedProfileWorkload(
        workload=workload,
        normalized_request=normalized,
        classification=classification,
        canonical_status=is_canonical,
        submission_status=False,
        _core_cases=tuple(case for case, _ in core_pairs),
        _mpc_cases=tuple(case for case, _ in mpc_pairs),
        _rl_cases=rl_bindings,
        _rl_destination_views=_rl_destination_view_records(
            requested_rl_bindings,
            rl_bindings,
        ),
        workload_release_id=workload_release_id,
        result_schema_release_id=result_schema_release_id,
        timing_protocol_release_id=timing_protocol_release_id,
    )


def resolve_profile_request(request: ProfileRequest = ProfileRequest()) -> ResolvedProfileWorkload:
    """Resolve an explicitly custom workload or the installed v3 release."""

    normalized = _normalize_request(request)
    preset = _normalize_request(ProfileRequest(preset=normalized.preset))
    comparison_fields = (
        "mpc_prediction_horizon_steps",
        "mpc_soft_constraint_modes",
        "rl_algorithms",
        "rl_training_steps",
        "rl_n_envs",
    )
    student_custom = any(
        getattr(normalized, field) != getattr(preset, field)
        for field in comparison_fields
    )
    classification = (
        "custom"
        if isinstance(normalized, AdvancedProfileRequest) or student_custom
        else "canonical"
    )
    if classification == "canonical":
        return _resolve_installed_v3_preset(normalized.preset)
    return _build_live_v3_workload(
        normalized,
        classification=classification,
        candidate=False,
        counts=_execution_counts(_V3_PRESET_DEFINITIONS[normalized.preset]),
        definition=_V3_PRESET_DEFINITIONS[normalized.preset],
    )


def _installed_v3_resource_root():
    return importlib.resources.files(
        "dreamgym.profiling.autonomous_driving.resources"
    )


def _resource_node_kind(node: object) -> str:
    """Classify one installed resource without following indirection."""

    try:
        status = Path(node).lstat()
    except FileNotFoundError:
        return "absent"
    except (OSError, TypeError, ValueError):
        return "error"
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    if stat.S_ISLNK(status.st_mode) or bool(
        getattr(status, "st_file_attributes", 0) & reparse_flag
    ):
        return "indirect"
    if stat.S_ISREG(status.st_mode):
        return "regular"
    if stat.S_ISDIR(status.st_mode):
        return "directory"
    return "other"


def _require_installed_v3_release_resources() -> None:
    try:
        root = _installed_v3_resource_root()
        candidate_kind = _resource_node_kind(
            root.joinpath(_V3_CANDIDATE_RESOURCE_NAME)
        )
        release_kinds = tuple(
            _resource_node_kind(root.joinpath(name))
            for name in _V3_RELEASE_RESOURCE_NAMES
        )
        if candidate_kind != "absent" or any(
            kind != "regular" for kind in release_kinds
        ):
            raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
        from dreamgym.profiling.autonomous_driving.release import (
            validate_installed_v3_benchmark_sources,
        )

        validation = validate_installed_v3_benchmark_sources()
        if (
            not isinstance(validation, Mapping)
            or validation.get("validated") is not True
        ):
            raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    except (OSError, RuntimeError, TypeError, ValueError) as error:
        if str(error) == PROFILING_V3_NOT_RELEASED_MESSAGE:
            raise
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)


def _resolve_installed_v3_preset(preset: str) -> ResolvedProfileWorkload:
    _require_installed_v3_release_resources()
    released = load_workload_resource("workload_v3.json")
    if not isinstance(released, ResolvedProfileRelease):
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    return released.preset(preset)


def resolve_development_workload() -> ResolvedProfileWorkload:
    """Load the exact committed development-v3 workload resource."""

    resolved = load_workload_resource("workload_development_v3.json")
    if not isinstance(resolved, ResolvedProfileWorkload):
        raise TypeError("development resource did not resolve one workload.")
    return resolved


def resolve_submission_workload() -> ResolvedProfileWorkload:
    """Resolve only the exact installed v3 submission release."""

    _require_installed_v3_release_resources()
    resolved = load_workload_resource("submission_workload_v3.json")
    if not isinstance(resolved, ResolvedProfileWorkload):
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    return resolved


def _release_status(resolved: ResolvedProfileWorkload) -> dict[str, Any]:
    return {
        "classification": resolved.classification,
        "canonical_status": resolved.canonical_status,
        "submission_status": resolved.submission_status,
    }


def _submission_metric_definitions(
    submission: ResolvedProfileWorkload,
) -> list[dict[str, Any]]:
    cases = submission.workload.cases
    if len(cases) != 4:
        raise ValueError(
            "submission workload must contain exactly four metric cases."
        )
    labels = (
        "MPC short horizon",
        "MPC long horizon",
        "PPO single environment",
        "PPO vector environments",
    )
    definitions: list[dict[str, Any]] = []
    for index, ((case, execution), label) in enumerate(
        zip(cases, labels, strict=True),
        start=1,
    ):
        suite = submission.suite_for(case, execution)
        if suite == "mpc":
            mpc = case.semantic_document.get("mpc")
            expected_horizon = (20, 80)[index - 1]
            if (
                not isinstance(mpc, Mapping)
                or mpc.get("policy") != "steering_rate"
                or mpc.get("soft_constraints") != "on"
                or mpc.get("prediction_horizon_steps")
                != expected_horizon
            ):
                raise ValueError(
                    "submission MPC metric population is not exact."
                )
            definitions.append(
                {
                    "order": index,
                    "case_id": case.semantic_case_id,
                    "execution_spec_digest": (
                        execution.execution_spec_digest
                    ),
                    "label": label,
                    "suite": "mpc",
                    "metric": (
                        "post_warmup_median_complete_solver_time"
                    ),
                    "definition": (
                        "Median complete solver invocation time across all "
                        "post-warm-up samples."
                    ),
                    "source_path": (
                        "metrics.headline."
                        "median_complete_solver_time_ns"
                    ),
                    "source_unit": "ns/solve",
                    "display_unit": "ms/solve",
                    "conversion": "divide_by_1000000",
                }
            )
            continue
        if suite != "rl":
            raise ValueError(
                "submission metric population contains an unknown suite."
            )
        vectorization = case.semantic_document.get("vectorization")
        expected_n_envs = (1, 4)[index - 3]
        if (
            not isinstance(vectorization, Mapping)
            or vectorization.get("effective_n_envs")
            != expected_n_envs
            or execution.execution_document.get(
                "requested_total_environment_transitions"
            )
            != 100_000
        ):
            raise ValueError(
                "submission RL metric population is not exact."
            )
        definitions.append(
            {
                "order": index,
                "case_id": case.semantic_case_id,
                "execution_spec_digest": (
                    execution.execution_spec_digest
                ),
                "label": label,
                "suite": "rl",
                "metric": (
                    "post_warmup_median_aggregate_environment_"
                    "transitions_per_second"
                ),
                "definition": (
                    "Median aggregate environment transitions per second "
                    "across complete post-warm-up steady-state windows."
                ),
                "source_path": (
                    "metrics.training.median_transitions_per_second"
                ),
                "source_unit": "transitions/s",
                "display_unit": "transitions/s",
                "conversion": "identity",
            }
        )
    return definitions


def _build_development_v3_resource_document() -> dict[str, Any]:
    """Serialize the private development builder without resolver recursion."""

    resolved = _build_live_v3_workload(
        ProfileRequest(preset="quick"),
        classification="development",
        candidate=False,
        counts=_DEVELOPMENT_EXECUTION_COUNTS,
        definition=_V3_PRESET_DEFINITIONS["quick"],
        canonical_contract=False,
    )
    return {
        "resource_schema_version": WORKLOAD_RESOURCE_SCHEMA_VERSION,
        "release_status": _release_status(resolved),
        "source": {"kind": "development"},
        "resolved_workload": resolved.workload.to_dict(),
        "rl_destination_views": [
            view.to_dict() for view in resolved.rl_destination_views()
        ],
    }


def _validate_workload_snapshot(document: Mapping[str, Any]) -> None:
    if type(document) is not dict:
        raise TypeError("resolved_workload must be an object.")
    expected_keys = {"schema_version", "workload_version", "workload_digest", "cases"}
    if set(document) != expected_keys:
        raise ValueError("resolved_workload must contain exactly the workload record fields.")
    if document["schema_version"] != PROFILE_RESULTS_SCHEMA_VERSION:
        raise ValueError("resolved_workload schema_version is not supported.")
    cases = document["cases"]
    if type(cases) is not list:
        raise TypeError("resolved_workload.cases must be a list.")
    pairs = []
    for item in cases:
        if type(item) is not dict or set(item) != {"case_spec", "execution_spec"}:
            raise ValueError("each resolved workload case must contain case_spec and execution_spec.")
        case_document = item["case_spec"]
        execution_document = item["execution_spec"]
        if type(case_document) is not dict or type(execution_document) is not dict:
            raise TypeError("workload case records must be objects.")
        case = CaseSpec(
            readable_prefix=case_document.get("readable_prefix"),
            semantic_document=case_document.get("semantic_document"),
            timing_protocol=case_document.get("timing_protocol"),
            schema_version=case_document.get("schema_version"),
        )
        execution = ExecutionSpec(
            semantic_case_id=execution_document.get("semantic_case_id"),
            execution_document=execution_document.get("execution_document"),
            schema_version=execution_document.get("schema_version"),
        )
        if case.to_dict() != case_document or execution.to_dict() != execution_document:
            raise ValueError("resource case identity or digest does not recompute exactly.")
        pairs.append((case, execution))
    workload = ResolvedWorkload(
        workload_version=document["workload_version"],
        cases=pairs,
        schema_version=document["schema_version"],
    )
    if workload.to_dict() != document:
        raise ValueError("resource workload digest does not recompute exactly.")


def _resolve_workload_resource_document(
    name: str,
    document: Mapping[str, Any],
    *,
    resource_sha256: str | None = None,
) -> ResolvedProfileWorkload:
    """Validate only the private-builder-backed development-v3 artifact."""

    del resource_sha256
    if name not in _ACTIVE_WORKLOAD_RESOURCE_NAMES:
        raise ValueError("name is not a supported workload resource.")
    if name != "workload_development_v3.json":
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    if type(document) is not dict or set(document) != {
        "resource_schema_version",
        "release_status",
        "source",
        "resolved_workload",
        "rl_destination_views",
    }:
        raise ValueError(
            "development workload has an invalid top-level shape."
        )
    if (
        document["resource_schema_version"]
        != WORKLOAD_RESOURCE_SCHEMA_VERSION
    ):
        raise ValueError(
            "workload resource schema version is not supported."
        )
    if document["source"] != {"kind": "development"}:
        raise ValueError("development workload source is not exact.")
    _validate_workload_snapshot(document["resolved_workload"])
    expected = _build_development_v3_resource_document()
    if canonical_json_bytes(document) != canonical_json_bytes(expected):
        raise ValueError(
            "development workload resource does not match the private "
            "v3 builder."
        )
    return _build_live_v3_workload(
        ProfileRequest(preset="quick"),
        classification="development",
        candidate=False,
        counts=_DEVELOPMENT_EXECUTION_COUNTS,
        definition=_V3_PRESET_DEFINITIONS["quick"],
        canonical_contract=False,
    )



def load_workload_resource(
    name: str,
) -> (
    ResolvedProfileWorkload
    | ResolvedProfileRelease
):
    """Load one explicitly supported active-v3 resource."""

    if name not in _ACTIVE_WORKLOAD_RESOURCE_NAMES:
        raise ValueError("name is not a supported workload resource.")
    resource = importlib.resources.files(
        "dreamgym.profiling.autonomous_driving.resources"
    ).joinpath(name)
    return _load_workload_resource_bytes(
        name,
        resource.read_bytes(),
    )


def _load_workload_resource_bytes(
    name: str,
    resource_bytes: bytes,
) -> (
    ResolvedProfileWorkload
    | ResolvedProfileRelease
):
    """Parse and resolve one exact resource byte stream."""

    if name not in _ACTIVE_WORKLOAD_RESOURCE_NAMES:
        raise ValueError("name is not a supported workload resource.")
    if name != "workload_development_v3.json":
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    if type(resource_bytes) is not bytes:
        raise TypeError("resource_bytes must be bytes.")
    expected_bytes = (
        json.dumps(
            _build_development_v3_resource_document(),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")
    if resource_bytes != expected_bytes:
        raise ValueError(
            "development workload resource is not exact serialized bytes."
        )
    try:
        document = json.loads(resource_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("workload resource is not valid JSON.") from error
    return _resolve_workload_resource_document(
        name,
        document,
        resource_sha256=hashlib.sha256(resource_bytes).hexdigest(),
    )


def load_workload_resource_path(
    path: str | Path,
) -> (
    ResolvedProfileWorkload
    | ResolvedProfileRelease
):
    """Load and resolve the exact bytes at one explicit resource path."""

    resolved_path = Path(path).resolve(strict=True)
    if not resolved_path.is_file():
        raise ValueError("workload resource path must be a file.")
    return _load_workload_resource_bytes(
        resolved_path.name,
        resolved_path.read_bytes(),
    )
