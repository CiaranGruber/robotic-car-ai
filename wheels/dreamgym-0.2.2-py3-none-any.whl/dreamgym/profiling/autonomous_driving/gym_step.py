"""Public Gymnasium construction and step profiling seams.

Fixture construction and reset preparation stay outside step-only timing.  The
measured callable is always the outer environment's public ``step`` method so
the action interface, integration, observations, reward, terminal flags, and
public wrappers remain inside the boundary.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import numpy as np


def _fixed_action(env: Any) -> np.ndarray:
    space = env.action_space
    shape = getattr(space, "shape", None)
    if shape is None:
        raise TypeError("public Gym-step profiling requires an array action space")
    dtype = getattr(space, "dtype", np.dtype(np.float32))
    return np.zeros(shape, dtype=dtype)


def make_public_step_environment(
    *,
    observation_format: str,
    payload: str,
):
    """Construct the production wrapper stack for one public-step fixture."""

    if observation_format not in {"flat", "dict"}:
        raise ValueError("observation_format must be flat or dict")
    if payload not in {"basic", "rich"}:
        raise ValueError("payload must be basic or rich")

    from dreamgym.training.autonomous_driving.configs import (
        default_training_config,
    )
    from dreamgym.training.autonomous_driving.envs import make_env
    from dreamgym.training.autonomous_driving.resolution import (
        resolve_training_request,
    )

    config = default_training_config()
    config.env.observation_format = observation_format
    config.env.include_cone_detection_observations = payload == "rich"
    config.env.include_next_speed_change_observations = payload == "rich"
    build = resolve_training_request(config)
    return make_env(build, apply_reward=True)


def profile_public_steps(
    env: Any,
    *,
    warmup_iterations: int,
    sample_count: int,
    repetitions: int,
    reset_seed: int,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> tuple[list[int], dict[str, Any]]:
    """Time only calls to the outer public ``env.step`` path."""

    from dreamgym.profiling.autonomous_driving.core_suites import (
        measure_indexed_callable_ns,
    )

    action = _fixed_action(env)
    env.reset(seed=reset_seed)
    needs_reset = False
    completed_steps = 0

    def prepare(_: int) -> None:
        nonlocal needs_reset
        if needs_reset:
            env.reset()
            needs_reset = False

    def step(_: int) -> float:
        nonlocal needs_reset, completed_steps
        observation, reward, terminated, truncated, info = env.step(action)
        completed_steps += 1
        needs_reset = bool(terminated or truncated)
        sink = float(reward)
        if isinstance(observation, np.ndarray) and observation.size:
            sink += float(observation.reshape(-1)[-1]) * 1.0e-12
        elif isinstance(observation, dict):
            sink += float(len(observation)) * 1.0e-12
        sink += float(len(info)) * 1.0e-12
        return sink

    samples, sink = measure_indexed_callable_ns(
        step,
        prepare=prepare,
        warmup_calls=warmup_iterations,
        sample_count=sample_count,
        repetitions=repetitions,
        clock_ns=clock_ns,
        suppress_gc=False,
    )
    return samples, {
        "timing_boundary": "step_only",
        "public_step_calls": completed_steps,
        "sink": sink,
    }


def profile_reset_encountering_rollout(
    env: Any,
    *,
    warmup_iterations: int,
    sample_count: int,
    repetitions: int,
    reset_seed: int,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> tuple[list[int], dict[str, Any]]:
    """Time end-to-end public reset-plus-step rollout encounters."""

    from dreamgym.profiling.autonomous_driving.core_suites import (
        measure_indexed_callable_ns,
    )

    action = _fixed_action(env)
    reset_calls = 0

    def reset_and_step(index: int) -> float:
        nonlocal reset_calls
        env.reset(seed=reset_seed + index)
        reset_calls += 1
        observation, reward, terminated, truncated, info = env.step(action)
        sink = float(reward) + float(bool(terminated or truncated))
        if isinstance(observation, np.ndarray) and observation.size:
            sink += float(observation.reshape(-1)[-1]) * 1.0e-12
        elif isinstance(observation, dict):
            sink += float(len(observation)) * 1.0e-12
        sink += float(len(info)) * 1.0e-12
        return sink

    samples, sink = measure_indexed_callable_ns(
        reset_and_step,
        warmup_calls=warmup_iterations,
        sample_count=sample_count,
        repetitions=repetitions,
        clock_ns=clock_ns,
        suppress_gc=False,
    )
    return samples, {
        "timing_boundary": "reset_encountering_rollout",
        "reset_calls": reset_calls,
        "sink": sink,
    }


def profile_gymnasium_registration(
    *,
    environment_id: str,
    warmup_iterations: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> tuple[list[int], dict[str, Any]]:
    """Time lightweight registered construction while closing every instance."""

    if type(environment_id) is not str or not environment_id:
        raise ValueError("environment_id must be a non-empty string")
    import gymnasium as gym
    import dreamgym  # noqa: F401  Register the public environment.

    from dreamgym.profiling.autonomous_driving.core_suites import (
        measure_indexed_callable_ns,
    )

    current_env = None
    constructed = 0

    def close_current(_: int) -> None:
        nonlocal current_env
        if current_env is not None:
            current_env.close()
            current_env = None

    def construct(_: int) -> float:
        nonlocal current_env, constructed
        current_env = gym.make(environment_id)
        constructed += 1
        return float(np.prod(current_env.action_space.shape))

    try:
        samples, sink = measure_indexed_callable_ns(
            construct,
            prepare=close_current,
            warmup_calls=warmup_iterations,
            sample_count=sample_count,
            repetitions=repetitions,
            clock_ns=clock_ns,
            suppress_gc=False,
        )
        return samples, {
            "timing_boundary": "gymnasium_make_construction",
            "environment_id": environment_id,
            "constructed_environments": constructed,
            "sink": sink,
        }
    finally:
        close_current(0)
