"""Isolated, no-output production RL timing worker.

The worker owns only construction and ``model.learn``.  A parent transport
owns requested/resolved snapshot persistence, checksums, result persistence,
rendering, and process lifecycle.  The two snapshot acknowledgements are hard
barriers and are deliberately outside every measured interval.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Mapping
from dataclasses import dataclass
import multiprocessing
from pathlib import Path
import statistics
import threading
import time
from typing import Any, Protocol

from stable_baselines3.common.callbacks import BaseCallback

from dreamgym.profiling.autonomous_driving.production_rl import (
    RL_PROGRESS_MILESTONE_COUNT,
    RLCaseRequest,
    RLRequestedPersisted,
    RLRequestedReady,
    RLResolvedPersisted,
    RLResolvedReady,
    RLWorkerAbort,
    RLWorkerFailure,
    RLWorkerProgress,
    RLWorkerResult,
    ResolvedRLProfileCase,
    compare_rl_projection_to_finalized_snapshot,
    resolve_rl_profile_case,
    rl_case_request_from_dict,
    rl_case_request_to_dict,
    rl_worker_message_from_dict,
)
from dreamgym.profiling.autonomous_driving.records import (
    SPAWNED_RL_WORKER_REQUIRED_MODULES_V2,
    collect_loaded_benchmark_module_origins,
    exception_class_identity,
    validate_benchmark_module_origins,
)
from dreamgym.training.autonomous_driving.config_validation import (
    canonical_snapshot_digest,
    thaw_json,
)
from dreamgym.training.autonomous_driving.snapshots import (
    validate_resolved_snapshot,
    validate_snapshot,
)


_ON_POLICY_ALGORITHMS = frozenset(("PPO", "A2C"))
_OFF_POLICY_ALGORITHMS = frozenset(("SAC", "TD3", "DDPG"))
_REQUESTED_REFERENCE_FIELDS = (
    "requested_config_path",
    "requested_config_digest",
    "requested_file_sha256",
)
_RESOLVED_REFERENCE_FIELDS = _REQUESTED_REFERENCE_FIELDS + (
    "resolved_config_path",
    "resolved_config_digest",
    "resolved_file_sha256",
)
_COOPERATIVE_ABORT_TIMEOUT_SECONDS = 10.0
_TERMINAL_DRAIN_TIMEOUT_SECONDS = 0.1
_INVALID_REMOTE_DIAGNOSTIC_MESSAGE = (
    "remote worker diagnostic payload was invalid."
)


class RLWorkerProtocolError(RuntimeError):
    """The parent/worker acknowledgement sequence was violated."""


class RLWorkerAborted(RuntimeError):
    """The parent requested cancellation at a persistence barrier."""


class RLRemoteWorkerError(RuntimeError):
    """A spawned worker reported a structured failure."""

    def __init__(
        self,
        stage: str,
        exception_type: str,
        message: str,
        *,
        requested_snapshot_reference: Mapping[str, Any] | None = None,
        resolved_snapshot_reference: Mapping[str, Any] | None = None,
    ) -> None:
        if any(
            type(value) is not str or not value
            for value in (stage, exception_type, message)
        ):
            raise ValueError(
                "remote worker diagnostic fields must be non-empty strings"
            )
        self.stage = stage
        self.exception_type = exception_type
        self.remote_message = message
        if requested_snapshot_reference is None:
            if resolved_snapshot_reference is not None:
                raise ValueError(
                    "resolved_snapshot_reference requires "
                    "requested_snapshot_reference"
                )
            requested_reference = None
            resolved_reference = None
        else:
            requested_reference = _validated_snapshot_reference(
                requested_snapshot_reference,
                fields=_REQUESTED_REFERENCE_FIELDS,
                path="requested_snapshot_reference",
            )
            resolved_reference = (
                None
                if resolved_snapshot_reference is None
                else _validated_snapshot_reference(
                    resolved_snapshot_reference,
                    fields=_RESOLVED_REFERENCE_FIELDS,
                    path="resolved_snapshot_reference",
                )
            )
            if (
                resolved_reference is not None
                and {
                    field: resolved_reference[field]
                    for field in _REQUESTED_REFERENCE_FIELDS
                }
                != requested_reference
            ):
                raise ValueError(
                    "resolved_snapshot_reference does not preserve "
                    "requested_snapshot_reference"
                )
        self.requested_snapshot_reference = requested_reference
        self.resolved_snapshot_reference = resolved_reference
        super().__init__(
            stage + " " + exception_type + ": " + message
        )


def _stable_exception_message(error: BaseException) -> str:
    exception_name = exception_class_identity(error)[1] or "Exception"
    try:
        message = str(error)
    except BaseException:
        return exception_name
    return message or exception_name


class _WorkerAbortSignal:
    """Thread-safe, in-memory cancellation state consumed by the callback."""

    def __init__(
        self,
        requested: Callable[[], bool] | None = None,
    ):
        self._requested = requested
        self._event = threading.Event()
        self._reason = "parent requested abort"
        self._protocol_error: BaseException | None = None

    def set(self, reason: str) -> None:
        self._reason = reason
        self._event.set()

    def fail(self, error: BaseException) -> None:
        self._protocol_error = error
        self._event.set()

    def is_set(self) -> bool:
        if self._protocol_error is not None:
            raise self._protocol_error
        return self._event.is_set() or bool(
            self._requested is not None and self._requested()
        )

    def raise_if_requested(self) -> None:
        if self.is_set():
            raise RLWorkerAborted(self._reason)

    @property
    def reason(self) -> str:
        return self._reason


@dataclass(frozen=True)
class RLTimingWindow:
    """One non-overlapping rollout-start to rollout-start measurement."""

    start_transition: int
    end_transition: int
    start_vector_call: int
    end_vector_call: int
    start_update: int
    end_update: int
    start_ns: int
    end_ns: int
    effective_n_envs: int

    def __post_init__(self) -> None:
        integer_fields = (
            "start_transition",
            "end_transition",
            "start_vector_call",
            "end_vector_call",
            "start_update",
            "end_update",
            "start_ns",
            "end_ns",
            "effective_n_envs",
        )
        if any(type(getattr(self, name)) is not int for name in integer_fields):
            raise TypeError("timing window fields must be integers.")
        if (
            self.start_transition < 0
            or self.start_vector_call < 0
            or self.start_update < 0
            or self.start_ns < 0
        ):
            raise ValueError("timing window starts must be non-negative.")
        if self.end_transition <= self.start_transition:
            raise ValueError("timing window must contain transitions.")
        if self.end_update <= self.start_update:
            raise ValueError("timing window must contain an optimizer update.")
        if self.end_vector_call <= self.start_vector_call:
            raise ValueError("timing window must contain vector calls.")
        if self.end_ns <= self.start_ns:
            raise ValueError("timing window elapsed time must be positive.")
        if self.effective_n_envs <= 0:
            raise ValueError("effective_n_envs must be positive.")
        if (
            self.transition_count
            != self.vector_call_count * self.effective_n_envs
        ):
            raise ValueError(
                "transition delta must equal vector-call delta times "
                "effective_n_envs."
            )

    @property
    def transition_count(self) -> int:
        return self.end_transition - self.start_transition

    @property
    def update_count(self) -> int:
        return self.end_update - self.start_update

    @property
    def elapsed_ns(self) -> int:
        return self.end_ns - self.start_ns

    @property
    def vector_call_count(self) -> int:
        return self.end_vector_call - self.start_vector_call

    @property
    def aggregate_transitions_per_second(self) -> float:
        return self.transition_count * 1_000_000_000.0 / self.elapsed_ns

    @property
    def vector_calls_per_second(self) -> float:
        return self.vector_call_count * 1_000_000_000.0 / self.elapsed_ns

    def to_dict(self) -> dict[str, Any]:
        return {
            "start_transition": self.start_transition,
            "end_transition": self.end_transition,
            "transition_count": self.transition_count,
            "start_vector_call": self.start_vector_call,
            "end_vector_call": self.end_vector_call,
            "start_update": self.start_update,
            "end_update": self.end_update,
            "update_count": self.update_count,
            "start_ns": self.start_ns,
            "end_ns": self.end_ns,
            "elapsed_ns": self.elapsed_ns,
            "effective_n_envs": self.effective_n_envs,
            "vector_call_count": self.vector_call_count,
            "aggregate_transitions_per_second": (
                self.aggregate_transitions_per_second
            ),
            "vector_calls_per_second": self.vector_calls_per_second,
        }


@dataclass(frozen=True)
class RLPartialTimingWindow:
    """Incomplete final interval retained only as a diagnostic."""

    start_transition: int
    end_transition: int
    start_vector_call: int
    end_vector_call: int
    start_update: int
    end_update: int
    start_ns: int
    end_ns: int
    effective_n_envs: int

    @property
    def transition_count(self) -> int:
        return max(0, self.end_transition - self.start_transition)

    @property
    def update_count(self) -> int:
        return max(0, self.end_update - self.start_update)

    @property
    def vector_call_count(self) -> int:
        return max(0, self.end_vector_call - self.start_vector_call)

    @property
    def elapsed_ns(self) -> int:
        return max(0, self.end_ns - self.start_ns)

    def to_dict(self) -> dict[str, Any]:
        return {
            "start_transition": self.start_transition,
            "end_transition": self.end_transition,
            "transition_count": self.transition_count,
            "start_vector_call": self.start_vector_call,
            "end_vector_call": self.end_vector_call,
            "vector_call_count": self.vector_call_count,
            "start_update": self.start_update,
            "end_update": self.end_update,
            "update_count": self.update_count,
            "start_ns": self.start_ns,
            "end_ns": self.end_ns,
            "elapsed_ns": self.elapsed_ns,
            "effective_n_envs": self.effective_n_envs,
            "complete": False,
            "headline_eligible": False,
        }


class RLTimingCallback(BaseCallback):
    """In-memory lifecycle recorder shared by all five supported algorithms."""

    def __init__(
        self,
        *,
        algorithm_name: str,
        effective_n_envs: int,
        complete_window_transition_target: int,
        required_complete_window_count: int,
        learning_starts: int = 0,
        clock_ns: Callable[[], int] = time.perf_counter_ns,
        abort_requested: Callable[[], bool] | None = None,
        progress_transition_target: int | None = None,
        progress: Callable[[int, int], None] | None = None,
    ):
        super().__init__(verbose=0)
        if algorithm_name not in _ON_POLICY_ALGORITHMS | _OFF_POLICY_ALGORITHMS:
            raise ValueError("algorithm_name is unsupported.")
        for name, value in (
            ("effective_n_envs", effective_n_envs),
            (
                "complete_window_transition_target",
                complete_window_transition_target,
            ),
            (
                "required_complete_window_count",
                required_complete_window_count,
            ),
        ):
            if type(value) is not int or value <= 0:
                raise ValueError(name + " must be a positive integer.")
        if type(learning_starts) is not int or learning_starts < 0:
            raise ValueError("learning_starts must be a non-negative integer.")
        if not callable(clock_ns):
            raise TypeError("clock_ns must be callable.")
        if abort_requested is not None and not callable(abort_requested):
            raise TypeError("abort_requested must be callable or null.")
        if (progress_transition_target is None) != (progress is None):
            raise ValueError(
                "progress_transition_target and progress must be supplied "
                "together."
            )
        if (
            progress_transition_target is not None
            and (
                type(progress_transition_target) is not int
                or progress_transition_target <= 0
            )
        ):
            raise ValueError(
                "progress_transition_target must be a positive integer."
            )
        if progress is not None and not callable(progress):
            raise TypeError("progress must be callable or null.")
        self.algorithm_name = algorithm_name
        self.effective_n_envs = effective_n_envs
        self.complete_window_transition_target = (
            complete_window_transition_target
        )
        self.required_complete_window_count = required_complete_window_count
        self.learning_starts = learning_starts
        self._clock_ns = clock_ns
        self._abort_requested = abort_requested or (lambda: False)
        self._progress_transition_target = progress_transition_target
        self._progress = progress
        self._progress_initial_transition = 0
        self._last_progress_milestone = 0
        self._abort_observed = False
        self._training_start_ns: int | None = None
        self._training_end_ns: int | None = None
        self._initial_transition = 0
        self._window_start: tuple[int, int, int, int] | None = None
        self._complete_windows: list[RLTimingWindow] = []
        self._partial_window: RLPartialTimingWindow | None = None
        self._rollout_start_count = 0

    def _state(self) -> tuple[int, int, int]:
        model = getattr(self, "model", None)
        if model is None:
            raise RuntimeError("SB3 callback model state is unavailable.")
        transitions = getattr(model, "num_timesteps", None)
        updates = getattr(model, "_n_updates", None)
        vector_calls = getattr(self, "n_calls", None)
        if type(transitions) is not int or transitions < 0:
            raise RuntimeError(
                "SB3 model num_timesteps lifecycle state is unavailable."
            )
        if type(updates) is not int or updates < 0:
            raise RuntimeError(
                "SB3 model _n_updates lifecycle state is unavailable."
            )
        if type(vector_calls) is not int or vector_calls < 0:
            raise RuntimeError(
                "SB3 callback n_calls lifecycle state is unavailable."
            )
        return transitions, updates, vector_calls

    def _eligible_start(self, transitions: int, updates: int) -> bool:
        if updates < 1:
            return False
        if (
            self.algorithm_name in _OFF_POLICY_ALGORITHMS
            and transitions <= self.learning_starts
        ):
            return False
        return True

    def _on_training_start(self) -> None:
        transitions, _, _ = self._state()
        self._training_start_ns = int(self._clock_ns())
        self._initial_transition = transitions
        self._progress_initial_transition = transitions

    def _on_rollout_start(self) -> None:
        if self._training_start_ns is None:
            raise RuntimeError("training start lifecycle event was not observed.")
        transitions, updates, vector_calls = self._state()
        now_ns = int(self._clock_ns())
        self._rollout_start_count += 1
        if not self._eligible_start(transitions, updates):
            return
        if self._window_start is None:
            self._window_start = (
                transitions,
                vector_calls,
                updates,
                now_ns,
            )
            return
        (
            start_transition,
            start_vector_call,
            start_update,
            start_ns,
        ) = self._window_start
        if (
            transitions < start_transition
            or vector_calls < start_vector_call
            or updates < start_update
        ):
            raise RuntimeError("SB3 lifecycle counters moved backwards.")
        transition_count = transitions - start_transition
        if (
            transition_count < self.complete_window_transition_target
            or updates <= start_update
        ):
            return
        window = RLTimingWindow(
            start_transition=start_transition,
            end_transition=transitions,
            start_vector_call=start_vector_call,
            end_vector_call=vector_calls,
            start_update=start_update,
            end_update=updates,
            start_ns=start_ns,
            end_ns=now_ns,
            effective_n_envs=self.effective_n_envs,
        )
        self._complete_windows.append(window)
        self._window_start = (
            transitions,
            vector_calls,
            updates,
            now_ns,
        )

    def _on_step(self) -> bool:
        if self._abort_requested():
            self._abort_observed = True
            return False
        if (
            self._progress is not None
            and self._progress_transition_target is not None
        ):
            model = getattr(self, "model", None)
            transitions = getattr(model, "num_timesteps", None)
            if type(transitions) is not int or transitions < 0:
                raise RuntimeError(
                    "SB3 model num_timesteps lifecycle state is "
                    "unavailable."
                )
            completed_transitions = max(
                0,
                transitions - self._progress_initial_transition,
            )
            while (
                self._last_progress_milestone
                < RL_PROGRESS_MILESTONE_COUNT
                and completed_transitions * RL_PROGRESS_MILESTONE_COUNT
                >= self._progress_transition_target
                * (self._last_progress_milestone + 1)
            ):
                self._last_progress_milestone += 1
                self._progress(
                    self._last_progress_milestone,
                    RL_PROGRESS_MILESTONE_COUNT,
                )
        return True

    def _on_rollout_end(self) -> None:
        return None

    def _on_training_end(self) -> None:
        if self._training_start_ns is None:
            raise RuntimeError("training start lifecycle event was not observed.")
        transitions, updates, vector_calls = self._state()
        now_ns = int(self._clock_ns())
        self._training_end_ns = now_ns
        if self._window_start is not None:
            (
                start_transition,
                start_vector_call,
                start_update,
                start_ns,
            ) = self._window_start
            self._partial_window = RLPartialTimingWindow(
                start_transition=start_transition,
                end_transition=transitions,
                start_vector_call=start_vector_call,
                end_vector_call=vector_calls,
                start_update=start_update,
                end_update=updates,
                start_ns=start_ns,
                end_ns=now_ns,
                effective_n_envs=self.effective_n_envs,
            )

    @property
    def complete_windows(self) -> tuple[RLTimingWindow, ...]:
        return tuple(self._complete_windows)

    @property
    def abort_observed(self) -> bool:
        return self._abort_observed

    @property
    def partial_window(self) -> RLPartialTimingWindow | None:
        return self._partial_window

    @property
    def warmup_transition_count(self) -> int:
        if self._complete_windows:
            start = self._complete_windows[0].start_transition
        elif self._window_start is not None:
            start = self._window_start[0]
        else:
            return 0
        return max(0, start - self._initial_transition)

    def summary(self) -> dict[str, Any]:
        if self._training_start_ns is None or self._training_end_ns is None:
            raise RuntimeError("complete SB3 training lifecycle was not observed.")
        if self._rollout_start_count == 0:
            raise RuntimeError("no rollout-start lifecycle boundary was observed.")
        windows = self.complete_windows
        enough = len(windows) >= self.required_complete_window_count
        rates = [
            window.aggregate_transitions_per_second
            for window in windows
        ]
        vector_rates = [
            window.vector_calls_per_second for window in windows
        ]
        return {
            "status": "completed" if enough else "failed",
            "canonical_window_requirement_met": enough,
            "complete_window_count": len(windows),
            "required_complete_window_count": (
                self.required_complete_window_count
            ),
            "minimum_window_transition_count": (
                self.complete_window_transition_target
            ),
            "warmup_transitions": self.warmup_transition_count,
            "complete_windows": [
                window.to_dict() for window in windows
            ],
            "partial_final_window": (
                None
                if self._partial_window is None
                else self._partial_window.to_dict()
            ),
            "median_transitions_per_second": (
                statistics.median(rates) if enough else None
            ),
            "median_vector_calls_per_second": (
                statistics.median(vector_rates) if enough else None
            ),
            "headline_window_elapsed_ns": (
                [window.elapsed_ns for window in windows]
                if enough
                else []
            ),
        }


class RLWorkerTransport(Protocol):
    def send(self, message: Any) -> None:
        ...

    def receive(self) -> Any:
        ...

    def start_abort_listener(self, case_id: str) -> _WorkerAbortSignal:
        ...


class InProcessRLWorkerTransport:
    """Deterministic parent adapter for tests and bounded local integration."""

    def __init__(
        self,
        parent_handler: Callable[[Any], Any] | None = None,
        *,
        abort_requested: Callable[[], bool] | None = None,
    ):
        self.parent_handler = parent_handler
        self.messages: list[Any] = []
        self._replies: deque[Any] = deque()
        self._abort_requested = abort_requested

    def send(self, message: Any) -> None:
        self.messages.append(message)
        if self.parent_handler is None:
            return
        reply = self.parent_handler(message)
        if reply is not None:
            self._replies.append(reply)

    def receive(self) -> Any:
        if not self._replies:
            raise RLWorkerProtocolError(
                "parent persistence acknowledgement is unavailable."
            )
        return self._replies.popleft()

    def start_abort_listener(self, case_id: str) -> _WorkerAbortSignal:
        return _WorkerAbortSignal(self._abort_requested)


class BundlePersistenceTransport(InProcessRLWorkerTransport):
    """Parent-side in-process transport backed by the bundle authority."""

    def __init__(self, writer: Any):
        self.writer = writer
        self.requested_reference: dict[str, Any] | None = None
        self.resolved_reference: dict[str, Any] | None = None
        self.result: RLWorkerResult | None = None
        self.failure: RLWorkerFailure | None = None
        self.progress: RLWorkerProgress | None = None
        super().__init__(self._persist)

    def _persist(self, message: Any) -> Any:
        if isinstance(message, RLRequestedReady):
            self.requested_reference = self.writer.persist_requested_config(
                thaw_json(message.snapshot)
            )
            return RLRequestedPersisted(
                message.case_id,
                self.requested_reference,
            )
        if isinstance(message, RLResolvedReady):
            if self.requested_reference is None:
                raise RLWorkerProtocolError(
                    "resolved snapshot arrived before requested persistence."
                )
            self.resolved_reference = self.writer.persist_resolved_config(
                self.requested_reference,
                thaw_json(message.snapshot),
            )
            return RLResolvedPersisted(
                message.case_id,
                self.resolved_reference,
            )
        if isinstance(message, RLWorkerProgress):
            self.progress = message
            return None
        if isinstance(message, RLWorkerResult):
            self.result = message
            return None
        if isinstance(message, RLWorkerFailure):
            self.failure = message
            return None
        raise RLWorkerProtocolError("parent received an unsupported message.")


class _ConnectionTransport:
    def __init__(self, connection: Any):
        self.connection = connection
        self._abort_signal: _WorkerAbortSignal | None = None
        self._abort_listener: threading.Thread | None = None

    def send(self, message: Any) -> None:
        self.connection.send(message.to_dict())

    def receive(self) -> Any:
        return rl_worker_message_from_dict(self.connection.recv())

    def start_abort_listener(self, case_id: str) -> _WorkerAbortSignal:
        if self._abort_signal is not None:
            raise RLWorkerProtocolError(
                "cooperative abort listener was already started."
            )
        signal = _WorkerAbortSignal()
        self._abort_signal = signal

        def listen() -> None:
            try:
                message = rl_worker_message_from_dict(
                    self.connection.recv()
                )
                if not isinstance(message, RLWorkerAbort):
                    raise RLWorkerProtocolError(
                        "worker received a non-abort control message "
                        "during learning."
                    )
                if message.case_id != case_id:
                    raise RLWorkerProtocolError(
                        "abort belongs to a different case."
                    )
                signal.set(message.reason)
            except EOFError:
                return
            except BaseException as error:
                signal.fail(error)

        listener = threading.Thread(
            target=listen,
            name="dreamgym-rl-abort-listener",
            daemon=True,
        )
        self._abort_listener = listener
        listener.start()
        return signal


@dataclass(frozen=True)
class RLWorkerDependencies:
    """Injectable production seams; defaults bind lazily inside the worker."""

    resolve_case: Callable[[RLCaseRequest], ResolvedRLProfileCase] = (
        resolve_rl_profile_case
    )
    make_vec_env: Callable[..., Any] | None = None
    vec_monitor: Callable[..., Any] | None = None
    make_model: Callable[..., Any] | None = None
    finalize_resolved_training_config: Callable[..., Any] | None = None
    compare_projection_to_finalized: Callable[..., Mapping[str, Any]] = (
        compare_rl_projection_to_finalized_snapshot
    )
    clock_ns: Callable[[], int] = time.perf_counter_ns


def _bound_dependencies(
    dependencies: RLWorkerDependencies | None,
) -> RLWorkerDependencies:
    supplied = dependencies or RLWorkerDependencies()
    if not isinstance(supplied, RLWorkerDependencies):
        raise TypeError("dependencies must be RLWorkerDependencies.")
    from stable_baselines3.common.vec_env import VecMonitor

    from dreamgym.training.autonomous_driving.envs import make_vec_env
    from dreamgym.training.autonomous_driving.models import make_model
    from dreamgym.training.autonomous_driving.snapshots import (
        finalize_resolved_training_config,
    )

    return RLWorkerDependencies(
        resolve_case=supplied.resolve_case,
        make_vec_env=supplied.make_vec_env or make_vec_env,
        vec_monitor=supplied.vec_monitor or VecMonitor,
        make_model=supplied.make_model or make_model,
        finalize_resolved_training_config=(
            supplied.finalize_resolved_training_config
            or finalize_resolved_training_config
        ),
        compare_projection_to_finalized=(
            supplied.compare_projection_to_finalized
        ),
        clock_ns=supplied.clock_ns,
    )


def _acknowledge(
    transport: RLWorkerTransport,
    expected_type: type,
    *,
    case_id: str,
    requested_config_digest: str,
    requested_reference: Mapping[str, Any] | None = None,
) -> Any:
    reply = transport.receive()
    if isinstance(reply, RLWorkerAbort):
        if reply.case_id != case_id:
            raise RLWorkerProtocolError("abort belongs to a different case.")
        raise RLWorkerAborted(reply.reason)
    if not isinstance(reply, expected_type):
        raise RLWorkerProtocolError(
            "parent supplied the wrong persistence acknowledgement."
        )
    if reply.case_id != case_id:
        raise RLWorkerProtocolError(
            "persistence acknowledgement belongs to a different case."
        )
    reference = _validated_snapshot_reference(
        thaw_json(reply.snapshot_reference),
        fields=(
            _REQUESTED_REFERENCE_FIELDS
            if expected_type is RLRequestedPersisted
            else _RESOLVED_REFERENCE_FIELDS
        ),
        path="persistence_acknowledgement.snapshot_reference",
    )
    if (
        reference.get("requested_config_digest")
        != requested_config_digest
    ):
        raise RLWorkerProtocolError(
            "persistence acknowledgement has the wrong requested digest."
        )
    if requested_reference is not None:
        expected_requested = {
            field: requested_reference.get(field)
            for field in _REQUESTED_REFERENCE_FIELDS
        }
        actual_requested = {
            field: reference.get(field)
            for field in _REQUESTED_REFERENCE_FIELDS
        }
        if actual_requested != expected_requested:
            raise RLWorkerProtocolError(
                "resolved acknowledgement changed the parent-owned "
                "requested snapshot reference."
            )
    return reply


class _CloseOnce:
    """Invoke one captured close boundary at most once."""

    def __init__(self, close: Callable[[], Any]):
        self._close = close
        self._started = False
        self._error: BaseException | None = None

    def __call__(self) -> None:
        if self._started:
            if self._error is not None:
                raise self._error
            return
        self._started = True
        try:
            self._close()
        except BaseException as error:
            self._error = error
            raise


def _install_idempotent_close(resource: Any) -> _CloseOnce | None:
    """Gate one resource's close without changing its identity or type."""

    close = getattr(resource, "close", None)
    if not callable(close):
        return None
    close_once = _CloseOnce(close)
    resource.close = close_once
    return close_once


def _close_resources(
    model: Any,
    env: Any,
    env_close: _CloseOnce | None,
    primary: BaseException | None,
) -> None:
    close_error: BaseException | None = None
    try:
        model_close = getattr(model, "close", None)
        if callable(model_close):
            model_close()
    except BaseException as error:
        close_error = error
    try:
        close = (
            env_close
            if env_close is not None
            else getattr(env, "close", None)
        )
        if callable(close):
            close()
    except BaseException as error:
        if close_error is None:
            close_error = error
    if primary is None and close_error is not None:
        raise close_error


def _algorithm_metrics(resolved: ResolvedRLProfileCase) -> dict[str, Any]:
    algorithm = resolved.build.algorithm.to_dict()
    constructor = algorithm["constructor_kwargs"]
    cadence: dict[str, Any]
    if algorithm["n_rollout_transitions_per_update_applicability"] == "applicable":
        cadence = {
            "family": "on_policy",
            "requested_rollout_transitions": (
                algorithm["requested_n_rollout_transitions_per_update"]
            ),
            "resolved_profile_rollout_transitions": (
                resolved.resolved_profile_rollout_transitions
            ),
            "native_n_steps_per_environment": (
                algorithm["native_n_steps_per_environment"]
            ),
            "effective_rollout_transitions": (
                algorithm[
                    "n_rollout_transitions_per_update_effective"
                ]
            ),
            "upward_rounding_transitions": (
                algorithm["n_rollout_transitions_rounding_amount"]
            ),
            "ppo_minibatch_remainder": algorithm["ppo_minibatch_remainder"],
        }
    else:
        cadence = {
            "family": "off_policy",
            "train_freq": thaw_json(constructor["train_freq"]),
            "n_steps": constructor["n_steps"],
            "gradient_steps": constructor["gradient_steps"],
            "transitions_per_collection": (
                algorithm["transitions_per_collection"]
            ),
            "gradient_steps_per_collection": (
                algorithm["gradient_steps_per_collection"]
            ),
            "update_to_data_ratio": algorithm["update_to_data_ratio"],
            "learning_starts": constructor["learning_starts"],
        }
    return {
        "name": algorithm["name"],
        "profile_version": algorithm["profile_version"],
        "policy_alias": algorithm["policy_alias"],
        "buffer_kind": algorithm["buffer_kind"],
        "cadence": cadence,
    }


def _worker_metrics(
    resolved: ResolvedRLProfileCase,
    *,
    snapshot_reference: Mapping[str, Any],
    comparison: Mapping[str, Any],
    callback_summary: Mapping[str, Any],
    actual_transitions: int,
    environment_construction_ns: int,
    model_construction_ns: int,
    model_learn_ns: int,
) -> dict[str, Any]:
    requested_transitions = (
        resolved.build.requested_total_environment_transitions
    )
    constructor_device = resolved.build.algorithm.constructor_kwargs["device"]
    requested_device = resolved.request.device_policy or constructor_device
    resolved_device = (
        comparison["actual_device"]
        if requested_device == "auto"
        else constructor_device
    )
    eligibility = {
        "canonical_status": resolved.eligibility.canonical_status,
        "submission_status": resolved.eligibility.submission_status,
        "semantic_reuse_import": (
            resolved.eligibility.semantic_reuse_import
        ),
        "sample_aggregation": resolved.eligibility.sample_aggregation,
        "diagnostic_execution": (
            resolved.eligibility.diagnostic_execution
        ),
    }
    return {
        "requested_transitions": requested_transitions,
        "actual_transitions": actual_transitions,
        "transition_overshoot": actual_transitions - requested_transitions,
        "construction": {
            "environment_ns": environment_construction_ns,
            "model_ns": model_construction_ns,
        },
        "training": {
            "model_learn_ns": model_learn_ns,
            "total_transitions_per_second": (
                actual_transitions * 1_000_000_000.0 / model_learn_ns
                if model_learn_ns > 0
                else None
            ),
            **dict(callback_summary),
        },
        "vectorization": {
            "kind": "dummy",
            "effective_n_envs": resolved.build.effective_n_envs,
            "aggregate_transition_rule": (
                "one vector call contributes effective_n_envs transitions"
            ),
        },
        "algorithm": _algorithm_metrics(resolved),
        "devices": {
            "requested": requested_device,
            "resolved": resolved_device,
            "observed": comparison["actual_device"],
            "diagnostic_auto": bool(comparison["diagnostic"]),
        },
        "classification": resolved.classification,
        "eligibility": eligibility,
        "warnings": list(resolved.warnings),
        "semantic_case_digest": resolved.semantic_case_digest,
        "timing_protocol_digest": resolved.timing_protocol_digest,
        "snapshot_reference": dict(snapshot_reference),
        "window_ownership": "single_model_learn_call",
    }


def run_rl_worker(
    request: RLCaseRequest,
    transport: RLWorkerTransport,
    *,
    dependencies: RLWorkerDependencies | None = None,
) -> RLWorkerResult:
    """Execute one production RL case through the exact two-barrier lifecycle."""

    if not isinstance(request, RLCaseRequest):
        raise TypeError("request must be an RLCaseRequest.")
    bound = _bound_dependencies(dependencies)
    case_id = request.case_name
    stage = "resolution"
    env = None
    env_close = None
    model = None
    primary: BaseException | None = None
    cleanup_attempted = False
    requested_reference: dict[str, Any] | None = None
    resolved_reference: dict[str, Any] | None = None
    try:
        resolved = bound.resolve_case(request)
        if not isinstance(resolved, ResolvedRLProfileCase):
            raise TypeError("resolve_case must return ResolvedRLProfileCase.")
        case_id = resolved.semantic_case_id
        if resolved.build.requested_dict["vectorization"]["vec_env"] != "dummy":
            raise ValueError("RL workload v1 requires DummyVecEnv.")

        stage = "requested_persistence"
        transport.send(
            RLRequestedReady(
                case_id,
                thaw_json(resolved.requested_snapshot),
                resolved.requested_config_digest,
            )
        )
        requested_ack = _acknowledge(
            transport,
            RLRequestedPersisted,
            case_id=case_id,
            requested_config_digest=resolved.requested_config_digest,
        )
        requested_reference = thaw_json(
            requested_ack.snapshot_reference
        )

        stage = "environment_construction"
        started_ns = int(bound.clock_ns())
        env = bound.make_vec_env(
            resolved.build,
            stage_vector_reset_seed=False,
        )
        env = bound.vec_monitor(env, filename=None)
        env_close = _install_idempotent_close(env)
        environment_construction_ns = int(bound.clock_ns()) - started_ns

        stage = "model_construction"
        started_ns = int(bound.clock_ns())
        model = bound.make_model(
            resolved.build,
            env,
            tensorboard_log=None,
        )
        model_construction_ns = int(bound.clock_ns()) - started_ns

        stage = "resolved_finalization"
        finalized = bound.finalize_resolved_training_config(
            resolved.build,
            env=env,
            model=model,
            final_animation_road_case=None,
        )
        finalized_snapshot = finalized.to_dict()
        if (
            finalized_snapshot.get("requested_config_digest")
            != resolved.requested_config_digest
        ):
            raise ValueError(
                "finalized resolved snapshot has the wrong requested digest."
            )
        comparison = bound.compare_projection_to_finalized(
            resolved.semantic_projection,
            finalized_snapshot,
        )

        stage = "resolved_persistence"
        transport.send(
            RLResolvedReady(
                case_id,
                finalized_snapshot,
                resolved.requested_config_digest,
            )
        )
        resolved_ack = _acknowledge(
            transport,
            RLResolvedPersisted,
            case_id=case_id,
            requested_config_digest=resolved.requested_config_digest,
            requested_reference=requested_reference,
        )
        resolved_reference = thaw_json(resolved_ack.snapshot_reference)
        start_abort_listener = getattr(
            transport,
            "start_abort_listener",
            None,
        )
        abort_signal = (
            start_abort_listener(case_id)
            if callable(start_abort_listener)
            else _WorkerAbortSignal()
        )

        algorithm = resolved.build.algorithm.to_dict()
        learning_starts = (
            int(algorithm["constructor_kwargs"]["learning_starts"])
            if algorithm[
                "n_rollout_transitions_per_update_applicability"
            ]
            == "not_applicable"
            else 0
        )
        callback = RLTimingCallback(
            algorithm_name=resolved.build.algorithm.name,
            effective_n_envs=resolved.build.effective_n_envs,
            complete_window_transition_target=(
                request.complete_window_transition_target
            ),
            required_complete_window_count=(
                request.required_complete_window_count
            ),
            learning_starts=learning_starts,
            clock_ns=bound.clock_ns,
            abort_requested=abort_signal.is_set,
            progress_transition_target=(
                resolved.build.requested_total_environment_transitions
            ),
            progress=lambda completed, total: transport.send(
                RLWorkerProgress(case_id, completed, total)
            ),
        )

        stage = "training"
        abort_signal.raise_if_requested()
        started_ns = int(bound.clock_ns())
        model.learn(
            callback=callback,
            total_timesteps=(
                resolved.build.requested_total_environment_transitions
            ),
            progress_bar=False,
        )
        model_learn_ns = int(bound.clock_ns()) - started_ns
        if callback.abort_observed:
            raise RLWorkerAborted(abort_signal.reason)
        abort_signal.raise_if_requested()
        actual_transitions = getattr(model, "num_timesteps", None)
        if type(actual_transitions) is not int or actual_transitions < 0:
            raise RuntimeError(
                "constructed model did not expose actual num_timesteps."
            )
        callback_summary = callback.summary()
        metrics = _worker_metrics(
            resolved,
            snapshot_reference=resolved_reference,
            comparison=comparison,
            callback_summary=callback_summary,
            actual_transitions=actual_transitions,
            environment_construction_ns=environment_construction_ns,
            model_construction_ns=model_construction_ns,
            model_learn_ns=model_learn_ns,
        )
        complete_windows = callback.complete_windows
        sample_ns = (
            tuple(window.elapsed_ns for window in complete_windows)
            if callback_summary["status"] == "completed"
            else ()
        )
        result = RLWorkerResult(
            case_id,
            resolved.execution_spec_digest,
            requested_reference,
            resolved_reference,
            sample_ns,
            metrics,
            callback_summary["status"],
        )

        stage = "cleanup"
        cleanup_attempted = True
        _close_resources(model, env, env_close, None)

        stage = "result_delivery"
        transport.send(result)
        return result
    except BaseException as error:
        primary = error
        if not cleanup_attempted:
            cleanup_attempted = True
            _close_resources(model, env, env_close, primary)
        try:
            transport.send(
                RLWorkerFailure(
                    case_id,
                    stage,
                    exception_class_identity(error)[1] or "Exception",
                    _stable_exception_message(error),
                    requested_reference,
                    resolved_reference,
                )
            )
        except BaseException:
            pass
        raise
    finally:
        if not cleanup_attempted:
            _close_resources(model, env, env_close, primary)


def _spawn_worker_entry(
    request_value: Mapping[str, Any],
    connection: Any,
) -> None:
    transport = _ConnectionTransport(connection)
    try:
        request = rl_case_request_from_dict(request_value)
        try:
            dependencies = _bound_dependencies(None)
            _validate_spawned_worker_source_origins()
        except BaseException as error:
            try:
                transport.send(
                    RLWorkerFailure(
                        request.case_name,
                        "source_validation",
                        exception_class_identity(error)[1] or "Exception",
                        _stable_exception_message(error),
                    )
                )
            except BaseException:
                pass
            return
        run_rl_worker(
            request,
            transport,
            dependencies=dependencies,
        )
    except BaseException:
        # The structured failure has already been delivered.  Avoid the
        # multiprocessing traceback/terminal output path.
        return
    finally:
        connection.close()


def _validate_spawned_worker_source_origins() -> dict[str, str]:
    """Validate the dynamic worker closure before readiness or timing."""

    repository_root = Path(__file__).resolve().parents[3]
    return validate_benchmark_module_origins(
        repository_root,
        collect_loaded_benchmark_module_origins(),
        required_module_names=SPAWNED_RL_WORKER_REQUIRED_MODULES_V2,
        require_exact=False,
    )


def _validated_snapshot_reference(
    value: Any,
    *,
    fields: tuple[str, ...],
    path: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise RLWorkerProtocolError(path + " must be a mapping.")
    reference = thaw_json(value)
    if set(reference) != set(fields):
        raise RLWorkerProtocolError(
            path + " does not have the exact SnapshotReference fields."
        )
    for name in fields:
        item = reference[name]
        if name.endswith("_path"):
            if type(item) is not str or not item:
                raise RLWorkerProtocolError(
                    path + "." + name + " must be a non-empty path."
                )
        elif (
            type(item) is not str
            or len(item) != 64
            or any(character not in "0123456789abcdef" for character in item)
        ):
            raise RLWorkerProtocolError(
                path + "." + name + " must be a SHA-256 digest."
            )
    return reference


class _SpawnParentProtocol:
    """One exact, side-effect-ordered parent session for a spawned worker."""

    def __init__(
        self,
        expected: ResolvedRLProfileCase,
        writer: Any,
        progress: Callable[[RLWorkerProgress], None] | None,
    ):
        self.expected = expected
        self.writer = writer
        self.progress = progress
        self.state = "await_requested_ready"
        self.requested_reference: dict[str, Any] | None = None
        self.resolved_reference: dict[str, Any] | None = None
        self.result: RLWorkerResult | None = None
        self.failure: RLWorkerFailure | None = None
        self._last_progress = 0

    def _validate_identity(self, message: Any) -> None:
        expected_case_id = (
            self.expected.request.case_name
            if (
                self.state == "await_requested_ready"
                and isinstance(message, RLWorkerFailure)
                and message.stage == "source_validation"
            )
            else self.expected.semantic_case_id
        )
        if getattr(message, "case_id", None) != expected_case_id:
            raise RLWorkerProtocolError(
                "worker message identity does not match request."
            )

    def _requested_snapshot(self, message: RLRequestedReady) -> dict[str, Any]:
        if (
            message.requested_config_digest
            != self.expected.requested_config_digest
        ):
            raise RLWorkerProtocolError(
                "requested readiness identity does not match request."
            )
        try:
            snapshot = validate_snapshot(thaw_json(message.snapshot))
        except (TypeError, ValueError) as error:
            raise RLWorkerProtocolError(
                "requested readiness snapshot payload is invalid."
            ) from error
        digest = canonical_snapshot_digest(snapshot)
        if (
            digest != message.requested_config_digest
            or digest != self.expected.requested_config_digest
            or snapshot != thaw_json(self.expected.requested_snapshot)
        ):
            raise RLWorkerProtocolError(
                "requested readiness snapshot payload does not match request."
            )
        return snapshot

    def _resolved_snapshot(self, message: RLResolvedReady) -> dict[str, Any]:
        if (
            message.requested_config_digest
            != self.expected.requested_config_digest
        ):
            raise RLWorkerProtocolError(
                "resolved readiness identity does not match request."
            )
        try:
            snapshot = validate_resolved_snapshot(
                thaw_json(message.snapshot)
            )
            if (
                snapshot["requested_config_digest"]
                != self.expected.requested_config_digest
            ):
                raise ValueError(
                    "resolved snapshot requested digest link is foreign."
                )
            comparison = compare_rl_projection_to_finalized_snapshot(
                self.expected.semantic_projection,
                snapshot,
            )
            observe_device = getattr(
                self.writer,
                "observe_rl_device",
                None,
            )
            if not callable(observe_device):
                raise TypeError(
                    "writer must verify the model-observed RL device."
                )
            observe_device(
                requested_device=comparison["requested_device_policy"],
                observed_device=comparison["actual_device"],
            )
        except (TypeError, ValueError) as error:
            raise RLWorkerProtocolError(
                "resolved readiness snapshot payload is invalid or "
                "runtime-incompatible."
            ) from error
        return snapshot

    def _persist_requested(
        self,
        message: RLRequestedReady,
        send: Callable[[Mapping[str, Any]], None],
    ) -> None:
        snapshot = self._requested_snapshot(message)
        persisted = self.writer.persist_requested_config(snapshot)
        reference = _validated_snapshot_reference(
            persisted,
            fields=_REQUESTED_REFERENCE_FIELDS,
            path="requested_snapshot_reference",
        )
        if (
            reference["requested_config_digest"]
            != canonical_snapshot_digest(snapshot)
        ):
            raise RLWorkerProtocolError(
                "requested SnapshotReference config digest does not match "
                "the authenticated snapshot."
            )
        self.requested_reference = reference
        send(
            RLRequestedPersisted(
                message.case_id,
                reference,
            ).to_dict()
        )
        self.state = "await_resolved_ready"

    def _persist_resolved(
        self,
        message: RLResolvedReady,
        send: Callable[[Mapping[str, Any]], None],
    ) -> None:
        if self.requested_reference is None:
            raise RLWorkerProtocolError(
                "resolved snapshot arrived before requested persistence."
            )
        snapshot = self._resolved_snapshot(message)
        persisted = self.writer.persist_resolved_config(
            self.requested_reference,
            snapshot,
        )
        reference = _validated_snapshot_reference(
            persisted,
            fields=_RESOLVED_REFERENCE_FIELDS,
            path="resolved_snapshot_reference",
        )
        requested_part = {
            field: reference[field]
            for field in _REQUESTED_REFERENCE_FIELDS
        }
        if requested_part != self.requested_reference:
            raise RLWorkerProtocolError(
                "resolved SnapshotReference changed the requested "
                "snapshot reference."
            )
        if (
            reference["resolved_config_digest"]
            != canonical_snapshot_digest(snapshot)
        ):
            raise RLWorkerProtocolError(
                "resolved SnapshotReference config digest does not match "
                "the authenticated snapshot."
            )
        self.resolved_reference = reference
        send(
            RLResolvedPersisted(
                message.case_id,
                reference,
            ).to_dict()
        )
        self.state = "await_result"

    def _accept_progress(self, message: RLWorkerProgress) -> None:
        if (
            message.total != RL_PROGRESS_MILESTONE_COUNT
            or message.completed != self._last_progress + 1
        ):
            raise RLWorkerProtocolError(
                "worker progress does not match the bounded transition "
                "protocol."
            )
        self._last_progress = message.completed
        if self.progress is not None:
            self.progress(message)

    def _accept_result(self, message: RLWorkerResult) -> None:
        if self._last_progress != RL_PROGRESS_MILESTONE_COUNT:
            raise RLWorkerProtocolError(
                "worker result arrived before transition progress "
                "completed."
            )
        if (
            self.requested_reference is None
            or self.resolved_reference is None
        ):
            raise RLWorkerProtocolError(
                "worker result arrived before both persistence barriers."
            )
        requested_reference = thaw_json(
            message.requested_snapshot_reference
        )
        resolved_reference = thaw_json(
            message.resolved_snapshot_reference
        )
        metrics = thaw_json(message.metrics)
        if (
            message.execution_spec_digest
            != self.expected.execution_spec_digest
        ):
            raise RLWorkerProtocolError(
                "spawned worker result identity does not match request."
            )
        if (
            requested_reference != self.requested_reference
            or resolved_reference != self.resolved_reference
        ):
            raise RLWorkerProtocolError(
                "spawned worker result snapshot reference does not match "
                "the parent-owned references."
            )
        if metrics.get("snapshot_reference") != self.resolved_reference:
            raise RLWorkerProtocolError(
                "spawned worker result metrics snapshot reference does not "
                "match the parent-owned resolved reference."
            )
        self.result = message
        self.state = "terminal"

    def _accept_failure(self, message: RLWorkerFailure) -> None:
        requested_reference = (
            None
            if message.requested_snapshot_reference is None
            else thaw_json(message.requested_snapshot_reference)
        )
        resolved_reference = (
            None
            if message.resolved_snapshot_reference is None
            else thaw_json(message.resolved_snapshot_reference)
        )
        if (
            requested_reference != self.requested_reference
            or resolved_reference != self.resolved_reference
        ):
            raise RLWorkerProtocolError(
                "worker failure snapshot references do not match the "
                "parent-owned persistence state."
            )
        self.failure = message
        self.state = "terminal"

    def handle(
        self,
        message: Any,
        send: Callable[[Mapping[str, Any]], None],
    ) -> None:
        self._validate_identity(message)
        if self.state == "terminal":
            raise RLWorkerProtocolError(
                "worker sent a message after a terminal message."
            )
        if isinstance(message, RLWorkerFailure):
            self._accept_failure(message)
            return
        if self.state == "await_requested_ready":
            if not isinstance(message, RLRequestedReady):
                raise RLWorkerProtocolError(
                    "parent expected requested-ready exactly once."
                )
            self._persist_requested(message, send)
            return
        if self.state == "await_resolved_ready":
            if not isinstance(message, RLResolvedReady):
                raise RLWorkerProtocolError(
                    "parent expected resolved-ready exactly once after "
                    "the requested acknowledgement."
                )
            self._persist_resolved(message, send)
            return
        if self.state != "await_result":
            raise RLWorkerProtocolError("parent worker protocol state is invalid.")
        if isinstance(message, RLWorkerProgress):
            self._accept_progress(message)
            return
        if isinstance(message, RLWorkerResult):
            self._accept_result(message)
            return
        raise RLWorkerProtocolError(
            "parent expected progress, failure, or one terminal result "
            "after the resolved acknowledgement."
        )


def _send_abort(
    connection: Any,
    *,
    case_id: str,
    reason: str,
) -> None:
    try:
        connection.send(RLWorkerAbort(case_id, reason).to_dict())
    except BaseException:
        return


def _close_handle(
    handle: Any,
    errors: list[BaseException],
) -> None:
    if handle is None:
        return
    try:
        close = getattr(handle, "close", None)
        if callable(close):
            close()
    except BaseException as error:
        errors.append(error)


def _surface_parent_snapshot_references(
    error: BaseException,
    protocol: _SpawnParentProtocol | None,
) -> None:
    """Attach only parent-authenticated persistence state to a terminal error."""

    requested = (
        None
        if protocol is None or protocol.requested_reference is None
        else dict(protocol.requested_reference)
    )
    resolved = (
        None
        if protocol is None or protocol.resolved_reference is None
        else dict(protocol.resolved_reference)
    )
    error.requested_snapshot_reference = requested
    error.resolved_snapshot_reference = resolved


def run_spawned_rl_worker(
    request: RLCaseRequest,
    writer: Any,
    *,
    progress: Callable[[RLWorkerProgress], None] | None = None,
) -> RLWorkerResult:
    """Run one worker with Windows-compatible ``spawn`` and parent persistence."""

    if not isinstance(request, RLCaseRequest):
        raise TypeError("request must be an RLCaseRequest.")
    try:
        expected = resolve_rl_profile_case(request)
    except KeyboardInterrupt:
        raise
    except Exception as error:
        raise RLRemoteWorkerError(
            "resolution",
            exception_class_identity(error)[1] or "Exception",
            _stable_exception_message(error),
        ) from error
    parent_connection = None
    child_connection = None
    process = None
    process_started = False
    child_connection_closed = False
    primary: BaseException | None = None
    protocol: _SpawnParentProtocol | None = None
    try:
        context = multiprocessing.get_context("spawn")
        parent_connection, child_connection = context.Pipe(duplex=True)
        process = context.Process(
            target=_spawn_worker_entry,
            args=(rl_case_request_to_dict(request), child_connection),
        )
        process.start()
        process_started = True
        child_connection.close()
        child_connection_closed = True
        protocol = _SpawnParentProtocol(expected, writer, progress)
        while True:
            try:
                wire = parent_connection.recv()
            except EOFError:
                break
            try:
                message = rl_worker_message_from_dict(wire)
            except (TypeError, ValueError) as error:
                raise RLRemoteWorkerError(
                    "case_execution",
                    "RLWorkerProtocolError",
                    _INVALID_REMOTE_DIAGNOSTIC_MESSAGE,
                    requested_snapshot_reference=(
                        protocol.requested_reference
                    ),
                    resolved_snapshot_reference=(
                        protocol.resolved_reference
                    ),
                ) from error
            protocol.handle(message, parent_connection.send)
            if protocol.state == "terminal":
                poll = getattr(parent_connection, "poll", None)
                if callable(poll):
                    try:
                        terminal_message_waiting = poll(
                            _TERMINAL_DRAIN_TIMEOUT_SECONDS
                        )
                    except BrokenPipeError:
                        break
                    if not terminal_message_waiting:
                        break
        if protocol.result is not None:
            return protocol.result
        if protocol.failure is not None:
            message = protocol.failure
            raise RLRemoteWorkerError(
                message.stage,
                message.exception_type,
                message.message,
                requested_snapshot_reference=(
                    protocol.requested_reference
                ),
                resolved_snapshot_reference=(
                    protocol.resolved_reference
                ),
            )
        raise RLRemoteWorkerError(
            "case_execution",
            "RLWorkerProtocolError",
            "worker exited without a result.",
            requested_snapshot_reference=protocol.requested_reference,
            resolved_snapshot_reference=protocol.resolved_reference,
        )
    except BaseException as error:
        _surface_parent_snapshot_references(error, protocol)
        primary = error
        if process_started and parent_connection is not None:
            _send_abort(
                parent_connection,
                case_id=expected.semantic_case_id,
                reason=(
                    "parent interrupted"
                    if isinstance(error, KeyboardInterrupt)
                    else "parent protocol aborted"
                ),
            )
        raise
    finally:
        cleanup_errors: list[BaseException] = []
        if child_connection is not None and not child_connection_closed:
            _close_handle(child_connection, cleanup_errors)
        if process is not None and process_started:
            try:
                process.join(timeout=_COOPERATIVE_ABORT_TIMEOUT_SECONDS)
            except BaseException as error:
                cleanup_errors.append(error)
            try:
                process_alive = process.is_alive()
            except BaseException as error:
                cleanup_errors.append(error)
                process_alive = True
            if process_alive:
                try:
                    process.terminate()
                except BaseException as error:
                    cleanup_errors.append(error)
                try:
                    process.join(timeout=_COOPERATIVE_ABORT_TIMEOUT_SECONDS)
                except BaseException as error:
                    cleanup_errors.append(error)
        _close_handle(parent_connection, cleanup_errors)
        _close_handle(process, cleanup_errors)
        if primary is None and cleanup_errors:
            _surface_parent_snapshot_references(cleanup_errors[0], protocol)
            raise cleanup_errors[0]
