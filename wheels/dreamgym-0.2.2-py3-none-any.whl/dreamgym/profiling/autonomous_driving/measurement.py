"""Deterministic measurement and sample-statistics primitives."""

from __future__ import annotations

import gc
import time
from collections.abc import Callable, Iterable
from statistics import mean, median
from typing import Any

import numpy as np


def _clock_tick_ns(clock_ns: Callable[[], int]) -> int:
    tick_ns = clock_ns()
    if type(tick_ns) is not int or tick_ns < 0:
        raise ValueError("clock_ns must produce non-negative integer ticks")
    return tick_ns


def measure_callable_ns(
    callable_: Callable[[], Any],
    *,
    warmup_calls: int = 0,
    sample_count: int = 1,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
    suppress_gc: bool = False,
) -> list[int]:
    """Measure repeated calls using a monotonic nanosecond clock.

    The caller owns fixture preparation: only ``callable_`` is bracketed by the
    timing clock.  Garbage collection is restored to its original enabled state
    even when the callable raises.
    """

    if isinstance(warmup_calls, bool) or not isinstance(warmup_calls, int) or warmup_calls < 0:
        raise ValueError("warmup_calls must be a non-negative integer")
    if isinstance(sample_count, bool) or not isinstance(sample_count, int) or sample_count < 1:
        raise ValueError("sample_count must be a positive integer")

    prior_gc_enabled = gc.isenabled()
    if suppress_gc:
        gc.disable()
    try:
        for _ in range(warmup_calls):
            callable_()
        samples: list[int] = []
        for _ in range(sample_count):
            started_ns = _clock_tick_ns(clock_ns)
            callable_()
            elapsed_ns = _clock_tick_ns(clock_ns) - started_ns
            if elapsed_ns < 0:
                raise ValueError("clock_ns must produce non-decreasing integer nanoseconds")
            samples.append(elapsed_ns)
        return samples
    finally:
        if suppress_gc:
            if prior_gc_enabled:
                gc.enable()
            else:
                gc.disable()


def _linear_p95(samples_ns: list[int | float]) -> float:
    try:
        return float(np.percentile(samples_ns, 95, method="linear"))
    except TypeError:  # pragma: no cover - NumPy before 1.22
        return float(np.percentile(samples_ns, 95, interpolation="linear"))


def summarize_sample_ns(
    samples_ns: Iterable[int],
) -> dict[str, int | float | str | list[int] | None]:
    """Summarize a non-empty canonical nanosecond sample sequence.

    This intentionally retains the raw samples, making the returned record
    suitable for result bundles as well as presentation adapters.
    """

    samples = list(samples_ns)
    if not samples:
        raise ValueError("canonical timing samples must not be empty")
    if any(
        type(value) is not int
        or value < 0
        for value in samples
    ):
        raise ValueError("samples_ns must contain non-negative integer nanoseconds")
    total_ns = sum(samples)
    total_s = total_ns / 1_000_000_000.0
    return {
        "samples_ns": samples,
        "sample_unit": "ns",
        "sample_count": len(samples),
        "total_ns": total_ns,
        "total_s": total_s,
        "mean_ns": mean(samples),
        "median_ns": median(samples),
        "min_ns": min(samples),
        "max_ns": max(samples),
        "p95_ns": _linear_p95(samples),
        "throughput_per_s": None if total_ns == 0 else len(samples) / total_s,
        "diagnostic_status": "single_sample" if len(samples) == 1 else "ok",
    }
