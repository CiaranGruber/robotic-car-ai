"""Public orchestration helpers for the student machine-profiling notebook.

The notebook stays presentation-only: timing, workload resolution, execution,
and durable bundle ownership remain in the public profiling library.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import contextlib
from dataclasses import dataclass, replace
import hashlib
import html
import importlib.resources
import io
import json
import math
from numbers import Real
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
from statistics import median
import subprocess
import sys
from typing import Any
from urllib.parse import urlsplit
import uuid
import zipfile

from dreamgym.profiling.autonomous_driving.records import (
    BENCHMARK_MODULE_ORIGINS_V3,
    canonical_json_bytes,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    sanitize_diagnostic_message,
)


_COMMIT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
_DEFAULT_COLAB_CHECKOUT = "/content/dream-gym-benchmark"


@dataclass(frozen=True)
class ColabSetupPlan:
    """A credential-free, exact-commit Colab installation plan."""

    checkout_directory: str
    release_commit: str
    commands: tuple[tuple[str, ...], ...]
    clone_only_if_missing: bool = True
    ordering: str = "install_then_import"


@dataclass(frozen=True)
class LocalSetupPlan:
    """Read-only checks for an already-installed local package."""

    checks: tuple[str, ...]
    commands: tuple[tuple[str, ...], ...] = ()
    read_only: bool = True


@dataclass(frozen=True)
class SourceValidation:
    """Content validation that becomes release authority only when bound."""

    validated: bool
    manifest_digest: str | None
    diagnostic: str | None = None

    def __post_init__(self) -> None:
        if self.diagnostic is not None:
            object.__setattr__(
                self,
                "diagnostic",
                sanitize_diagnostic_message(self.diagnostic),
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "validated": self.validated,
            "manifest_digest": self.manifest_digest,
        }


@dataclass(frozen=True)
class SubmissionDiagnostic:
    """The one controlled, deliberately nonnumeric Part 1 failure object."""

    message: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "message",
            sanitize_diagnostic_message(self.message),
        )

    def __repr__(self) -> str:
        return self.message

    def _repr_html_(self) -> str:
        return "<p>" + html.escape(self.message) + "</p>"


@dataclass(frozen=True)
class LockedReleaseValidation:
    """Release eligibility already checked outside the measured operation."""

    validated: bool
    manifest_digest: str | None
    diagnostic: str | None = None
    release_commit: str | None = None

    def __post_init__(self) -> None:
        if self.diagnostic is not None:
            object.__setattr__(
                self,
                "diagnostic",
                sanitize_diagnostic_message(self.diagnostic),
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "validated": self.validated,
            "manifest_digest": self.manifest_digest,
            "release_commit": self.release_commit,
        }


@dataclass(frozen=True)
class SubmissionRow:
    """One numeric Canvas value with controlled visible formatting."""

    label: str
    value: float
    unit: str

    @property
    def formatted_value(self) -> str:
        return format(self.value, ".3g")


@dataclass(frozen=True)
class SubmissionDisplay:
    """The only successful Part 1 display object."""

    rows: tuple[SubmissionRow, ...]

    def __post_init__(self) -> None:
        if len(self.rows) != 4:
            raise ValueError("submission display must contain four rows")

    def __repr__(self) -> str:
        return "\n".join(
            row.label + " | " + row.formatted_value + " " + row.unit
            for row in self.rows
        )

    def _repr_html_(self) -> str:
        rows = "".join(
            "<tr><th>{}</th><td>{}</td><td>{}</td></tr>".format(
                row.label,
                row.formatted_value,
                row.unit,
            )
            for row in self.rows
        )
        return "<table>" + rows + "</table>"


@dataclass(frozen=True)
class LockedSubmissionRun:
    """In-memory reuse state whose display hides all explanatory metadata."""

    display: SubmissionDisplay
    result: Any
    compatibility_identity: tuple[str, str, str]
    environment: str
    resolved: Any

    def __repr__(self) -> str:
        return repr(self.display)

    def _repr_html_(self) -> str:
        return self.display._repr_html_()


@dataclass(frozen=True)
class SuiteView:
    """Structured table and plot series for one full-suite section."""

    suite: str
    table: tuple[dict[str, Any], ...]
    plot_series: "PlotSeries"

    def __repr__(self) -> str:
        lines = [
            self.suite.upper() + " performance",
            "case | status | metric | value | unit",
        ]
        lines.extend(
            "{} | {} | {} | {} | {}".format(
                row["case_id"],
                row["status"],
                row["headline_metric"],
                row["headline_value"],
                row["headline_unit"],
            )
            for row in self.table
        )
        return "\n".join(lines)

    def _repr_html_(self) -> str:
        table_rows = "".join(
            "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                html.escape(str(row["case_id"])),
                html.escape(str(row["status"])),
                html.escape(str(row["headline_metric"])),
                html.escape(str(row["headline_value"])),
                html.escape(str(row["headline_unit"])),
            )
            for row in self.table
        )
        maximum = max(self.plot_series.values, default=0.0)
        bars = "".join(
            '<rect x="0" y="{}" width="{}%" height="16"></rect>'.format(
                index * 22,
                0.0 if maximum <= 0.0 else value * 100.0 / maximum,
            )
            for index, value in enumerate(self.plot_series.values)
        )
        height = max(22, len(self.plot_series.values) * 22)
        return (
            "<table><thead><tr><th>case</th><th>status</th><th>metric</th>"
            "<th>value</th><th>unit</th></tr></thead><tbody>"
            + table_rows
            + "</tbody></table><svg role=\"img\" aria-label=\""
            + html.escape(self.plot_series.metric)
            + " performance plot\" viewBox=\"0 0 100 "
            + str(height)
            + "\">"
            + bars
            + "</svg>"
        )


@dataclass(frozen=True)
class PlotSeries:
    """One performance metric prepared for a suite plot."""

    metric: str
    unit: str
    labels: tuple[str, ...]
    values: tuple[float, ...]


@dataclass(frozen=True)
class ConfigurableProfileRun:
    """Combined full-suite result plus its exact reused case records."""

    result: Any
    reused_results: tuple[Any, ...]
    views: Mapping[str, SuiteView]
    resolved: Any


def detect_notebook_environment() -> str:
    """Classify the active runtime without importing a cloud SDK."""

    return "colab" if "google.colab" in sys.modules else "local"


def _validate_repository_url(repository_url: str) -> None:
    if type(repository_url) is not str or not repository_url:
        raise ValueError("repository URL must be a non-empty HTTPS URL")
    parsed = urlsplit(repository_url)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("repository URL must not contain credentials")


def build_colab_setup_plan(
    *,
    repository_url: str,
    release_commit: str,
    checkout_directory: str = _DEFAULT_COLAB_CHECKOUT,
) -> ColabSetupPlan:
    """Return an idempotent detached-checkout plan for a frozen release."""

    _validate_repository_url(repository_url)
    if (
        type(release_commit) is not str
        or _COMMIT_PATTERN.fullmatch(release_commit) is None
    ):
        raise ValueError("release commit must be an exact lowercase commit")
    if checkout_directory != _DEFAULT_COLAB_CHECKOUT:
        raise ValueError("Colab checkout must use the dedicated directory")
    return ColabSetupPlan(
        checkout_directory=checkout_directory,
        release_commit=release_commit,
        commands=(
            (
                "git",
                "clone",
                "--no-checkout",
                repository_url,
                checkout_directory,
            ),
            (
                "git",
                "-C",
                checkout_directory,
                "fetch",
                "--depth",
                "1",
                "origin",
                release_commit,
            ),
            (
                "git",
                "-C",
                checkout_directory,
                "checkout",
                "--detach",
                release_commit,
            ),
            (
                sys.executable,
                "-m",
                "pip",
                "install",
                "-e",
                checkout_directory + "[rl,mpc]",
            ),
        ),
    )


def build_local_setup_plan() -> LocalSetupPlan:
    """Describe local validation without repository or environment mutation."""

    return LocalSetupPlan(
        checks=(
            "inspect installed package version",
            "validate frozen release identity",
            "validate benchmark source hashes",
            "validate imported module origins",
        )
    )


def _manifest_files(manifest: Mapping[str, Any]) -> dict[str, str]:
    if not isinstance(manifest, Mapping):
        raise TypeError("benchmark source manifest must be an object")
    if set(manifest) != {"schema_version", "files"}:
        raise ValueError("benchmark source manifest fields are unsupported")
    if manifest.get("schema_version") != "benchmark-sources-v1":
        raise ValueError("benchmark source manifest schema is unsupported")
    raw_files = manifest.get("files")
    if not isinstance(raw_files, Mapping) or not raw_files:
        raise ValueError("benchmark source manifest files are missing")
    files: dict[str, str] = {}
    for raw_path, raw_digest in raw_files.items():
        if type(raw_path) is not str or type(raw_digest) is not str:
            raise TypeError("benchmark source entries must be strings")
        path = PurePosixPath(raw_path)
        if path.is_absolute() or ".." in path.parts or str(path) != raw_path:
            raise ValueError("benchmark source paths must be safe and relative")
        if re.fullmatch(r"[0-9a-f]{64}", raw_digest) is None:
            raise ValueError("benchmark source hash must be lowercase SHA-256")
        files[raw_path] = raw_digest
    return files


def validate_benchmark_sources(
    source_root: str | Path,
    manifest: Mapping[str, Any],
    *,
    imported_module_origins: Mapping[str, str | Path] | None = None,
) -> SourceValidation:
    """Validate all manifest hashes and reject imported shadow modules.

    The returned record intentionally contains no resolved path, dirty diff,
    module name, or file-specific failure detail.
    """

    try:
        files = _manifest_files(manifest)
        root = Path(source_root).resolve(strict=True)
        for relative, expected_digest in sorted(files.items()):
            candidate = root.joinpath(*PurePosixPath(relative).parts)
            if (
                not candidate.is_file()
                or not candidate.resolve(strict=True).is_relative_to(root)
                or hashlib.sha256(candidate.read_bytes()).hexdigest()
                != expected_digest
            ):
                raise ValueError("benchmark source validation failed")
        for module_name, origin in (
            imported_module_origins or {}
        ).items():
            resolved = Path(origin).resolve(strict=True)
            if not resolved.is_file() or not resolved.is_relative_to(root):
                raise ValueError("benchmark source validation failed")
            relative = resolved.relative_to(root).as_posix()
            module_path = module_name.replace(".", "/")
            controlled_origins = {
                candidate
                for candidate in (
                    module_path + ".py",
                    module_path + "/__init__.py",
                )
                if candidate in files
            }
            if relative not in controlled_origins:
                raise ValueError("benchmark source validation failed")
        digest = hashlib.sha256(canonical_json_bytes(dict(manifest))).hexdigest()
        return SourceValidation(True, digest)
    except (OSError, TypeError, ValueError):
        return SourceValidation(False, None, "benchmark source validation failed")


def resolve_locked_submission():
    """Resolve only the exact installed v3 submission release."""

    from dreamgym.profiling.autonomous_driving.workloads import (
        resolve_submission_workload,
    )

    return resolve_submission_workload()


def resolve_configurable_profile(
    *,
    preset: str,
    mpc_horizons: Sequence[int] | None,
    mpc_soft_constraints: Sequence[str] | None,
    rl_algorithms: Sequence[str] | None,
    rl_training_steps: Sequence[int] | None,
    rl_n_envs: Sequence[int] | None,
):
    """Resolve the six notebook controls through the public CLI resolver."""

    from dreamgym.profiling.autonomous_driving.workloads import (
        ProfileRequest,
        resolve_profile_request,
    )

    return resolve_profile_request(
        ProfileRequest(
            preset=preset,
            mpc_prediction_horizon_steps=mpc_horizons,
            mpc_soft_constraint_modes=mpc_soft_constraints,
            rl_algorithms=rl_algorithms,
            rl_training_steps=rl_training_steps,
            rl_n_envs=rl_n_envs,
        )
    )


def matching_completed_cases(
    resolved: Any,
    candidates: Sequence[Any],
) -> tuple[Any, ...]:
    """Select only completed results with exact target case identities."""

    expected = {
        (case.semantic_case_id, execution.execution_spec_digest)
        for case, execution in resolved.workload.cases
    }
    selected: dict[tuple[str, str], Any] = {}
    for result in candidates:
        key = (
            getattr(result, "case_id", None),
            getattr(result, "execution_spec_digest", None),
        )
        if (
            key in expected
            and getattr(result, "status", None) == "completed"
            and key not in selected
        ):
            selected[key] = result
    return tuple(
        selected[key]
        for case, execution in resolved.workload.cases
        if (
            key := (
                case.semantic_case_id,
                execution.execution_spec_digest,
            )
        )
        in selected
    )


def _stored_complete_window_count(result_record: Mapping[str, Any]) -> int | None:
    metric = result_record.get("metrics", {}).get(
        "training.complete_window_count"
    )
    if (
        not isinstance(metric, Mapping)
        or metric.get("unit") != "count"
        or type(metric.get("value")) is not int
    ):
        return None
    return metric["value"]


def _reusable_import_plans(
    resolved: Any,
    reusable_runs: Sequence[Any],
) -> tuple[Any, ...]:
    """Select exact or stronger durable cases without changing the workload."""

    from dreamgym.profiling.autonomous_driving.bundle import load_bundle
    from dreamgym.profiling.autonomous_driving.production_rl import (
        resolve_rl_profile_case,
        rl_reuse_record,
    )
    from dreamgym.profiling.autonomous_driving.records import (
        execution_instance_id,
    )
    from dreamgym.profiling.autonomous_driving.runner import CaseImportPlan

    sources = []
    for reusable_run in reusable_runs:
        source_resolved = getattr(reusable_run, "resolved", None)
        source_result = getattr(reusable_run, "result", None)
        source_output = getattr(source_result, "output", None)
        if (
            source_resolved is None
            or source_output is None
            or not hasattr(source_resolved, "workload")
        ):
            continue
        try:
            document = load_bundle(source_output)
        except (OSError, TypeError, ValueError):
            continue
        if (
            document["manifest"]["workload"]["workload_digest"]
            != source_resolved.workload.workload_digest
        ):
            continue
        for source_case, source_execution in source_resolved.workload.cases:
            source_instance_id = execution_instance_id(
                source_case.semantic_case_id,
                source_execution.execution_spec_digest,
            )
            source_case_record = document["manifest"]["cases"].get(
                source_instance_id
            )
            source_result_record = document["results"]["cases"].get(
                source_instance_id
            )
            if (
                not isinstance(source_case_record, Mapping)
                or not isinstance(source_result_record, Mapping)
                or source_result_record.get("status") != "completed"
                or source_case_record.get("eligibility", {}).get(
                    "semantic_reuse_import"
                )
                is not True
            ):
                continue
            sources.append(
                (
                    Path(source_output),
                    source_resolved,
                    source_case,
                    source_execution,
                    source_instance_id,
                    source_case_record,
                    source_result_record,
                    document,
                )
            )

    plans = []
    for destination_case, destination_execution in resolved.workload.cases:
        candidates = []
        for source_index, source in enumerate(sources):
            (
                source_output,
                source_resolved,
                source_case,
                source_execution,
                source_instance_id,
                source_case_record,
                source_result_record,
                source_document,
            ) = source
            if (
                source_case.semantic_case_digest
                != destination_case.semantic_case_digest
                or source_case.timing_protocol_digest
                != destination_case.timing_protocol_digest
            ):
                continue
            exact = (
                source_execution.execution_spec_digest
                == destination_execution.execution_spec_digest
            )
            reuse_authority = None
            try:
                source_suite = source_resolved.suite_for(
                    source_case,
                    source_execution,
                )
                destination_suite = resolved.suite_for(
                    destination_case,
                    destination_execution,
                )
            except (KeyError, TypeError, ValueError):
                continue
            if source_suite == "rl" or destination_suite == "rl":
                try:
                    if (
                        source_suite != "rl"
                        or destination_suite != "rl"
                    ):
                        continue
                    complete_windows = _stored_complete_window_count(
                        source_result_record
                    )
                    source_snapshot = source_case_record.get("snapshot")
                    if (
                        complete_windows is None
                        or not isinstance(source_snapshot, Mapping)
                    ):
                        continue
                    source_binding = source_resolved.rl_binding_for(
                        source_case,
                        source_execution,
                    )
                    destination_binding = resolved.rl_binding_for(
                        destination_case,
                        destination_execution,
                    )
                    compatibility_digest = source_document["manifest"][
                        "compatibility"
                    ]["runtime_hardware_compatibility_digest"]
                    reuse_authority = rl_reuse_record(
                        resolve_rl_profile_case(source_binding.request),
                        resolve_rl_profile_case(
                            destination_binding.request
                        ),
                        source_execution_reference=source_instance_id,
                        source_execution_spec_digest=(
                            source_execution.execution_spec_digest
                        ),
                        destination_execution_spec_digest=(
                            destination_execution.execution_spec_digest
                        ),
                        source_snapshot_reference=source_snapshot,
                        source_actual_completed_transitions=(
                            source_result_record[
                                "actual_completed_transitions"
                            ]
                        ),
                        source_complete_window_count=complete_windows,
                        source_status=source_result_record["status"],
                        runtime_compatibility_digest=(
                            compatibility_digest
                        ),
                        destination_runtime_compatibility_digest=(
                            compatibility_digest
                        ),
                    )
                except (KeyError, TypeError, ValueError):
                    continue
                if reuse_authority["compatible"] is not True:
                    continue
            elif not exact:
                continue
            source_strength = source_result_record[
                "actual_completed_transitions"
            ]
            candidates.append(
                (
                    0 if exact else 1,
                    source_strength,
                    source_output.as_posix(),
                    source_instance_id,
                    source_index,
                    source,
                    reuse_authority,
                )
            )
        if not candidates:
            continue
        _, _, _, _, _, selected, authority = min(candidates)
        (
            source_output,
            _source_resolved,
            _source_case,
            _source_execution,
            source_instance_id,
            _source_case_record,
            _source_result_record,
            _source_document,
        ) = selected
        plans.append(
            CaseImportPlan(
                source_bundle=source_output,
                source_execution_instance_id=source_instance_id,
                destination_semantic_case_id=(
                    destination_case.semantic_case_id
                ),
                destination_execution_spec_digest=(
                    destination_execution.execution_spec_digest
                ),
                reuse_authority=authority,
            )
        )
    return tuple(plans)


def _clear_progress_best_effort(
    clear_progress: Callable[[], None] | None,
) -> None:
    if clear_progress is None:
        return
    try:
        clear_progress()
    except Exception:
        pass


def _configurable_workload_manifest(resolved: Any) -> dict[str, Any]:
    return {
        "workload_version": resolved.workload.workload_version,
        "workload_digest": resolved.workload.workload_digest,
        "release_identity": {
            "workload_release_id": resolved.workload_release_id,
            "result_schema_release_id": resolved.result_schema_release_id,
            "timing_protocol_release_id": (
                resolved.timing_protocol_release_id
            ),
        },
        "release_status": {
            "classification": resolved.classification,
            "canonical_status": resolved.canonical_status,
            "submission_status": resolved.submission_status,
        },
    }


def _is_resumable_configurable_bundle(
    destination: Path,
    resolved: Any,
    source_validation: Mapping[str, Any] | None,
) -> bool:
    """Recognize an exact interrupted bundle after a notebook restart."""

    from dreamgym.profiling.autonomous_driving.bundle import (
        BundleCompatibilityError,
        _validate_rl_resume_snapshot,
        load_bundle,
    )
    from dreamgym.profiling.autonomous_driving.records import (
        execution_instance_id,
    )

    try:
        document = load_bundle(destination)
        manifest = document["manifest"]
        if (
            manifest["workload"]
            != _configurable_workload_manifest(resolved)
            or manifest.get("source_validation")
            != (
                None
                if source_validation is None
                else dict(source_validation)
            )
        ):
            return False
        attempt_id = manifest.get("current_run_attempt_id")
        if attempt_id is None:
            return False
        attempt = manifest["run_attempts"][attempt_id]
        if attempt["status"] not in {
            "running",
            "incomplete",
            "interrupted",
        }:
            return False

        expected = {
            execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            ): (case, execution)
            for case, execution in resolved.workload.cases
        }
        if attempt["expected_case_ids"] != list(expected):
            return False
        if not set(manifest["cases"]) <= set(expected):
            return False
        completed = 0
        for instance_id, stored_case in manifest["cases"].items():
            case, execution = expected[instance_id]
            expected_identity = {
                "semantic_case_id": case.semantic_case_id,
                "semantic_case_digest": case.semantic_case_digest,
                "execution_spec_digest": (
                    execution.execution_spec_digest
                ),
                "timing_protocol_digest": (
                    case.timing_protocol_digest
                ),
                "result_schema_version": case.schema_version,
                "benchmark_release": resolved.classification,
                "semantic_projection_digest": (
                    case.semantic_case_digest
                ),
            }
            if any(
                stored_case.get(field) != value
                for field, value in expected_identity.items()
            ):
                return False
            stored_result = document["results"]["cases"].get(instance_id)
            if stored_result is None:
                return False
            status = stored_result["status"]
            if (
                status not in {"completed", "failed", "interrupted"}
                or (
                    status == "failed"
                    and stored_result["fatal"] is True
                )
            ):
                return False
            if status == "completed":
                completed += 1
            try:
                suite = resolved.suite_for(case, execution)
            except (KeyError, TypeError, ValueError):
                return False
            if suite == "rl":
                destination_requested_config_digest = None
                if (
                    stored_case.get("snapshot") is not None
                    and stored_case.get("imported_from") is None
                ):
                    destination_requested_config_digest = (
                        resolved.rl_binding_for(
                            case,
                            execution,
                        ).requested_config_digest
                    )
                try:
                    _validate_rl_resume_snapshot(
                        stored_case,
                        stored_result,
                        destination_requested_config_digest=(
                            destination_requested_config_digest
                        ),
                    )
                except (KeyError, TypeError, ValueError):
                    return False
        return completed != len(expected)
    except (BundleCompatibilityError, OSError, TypeError, ValueError):
        return False


def run_configurable_profile(
    resolved: Any,
    *,
    output: str | Path,
    runner: Callable[..., Any],
    source_validation: Mapping[str, Any] | None = None,
    reusable_runs: Sequence[Any] = (),
    previous: ConfigurableProfileRun | None = None,
    fresh: bool = False,
    progress_sink: Callable[[Any], None] | None = None,
    clear_progress: Callable[[], None] | None = None,
) -> ConfigurableProfileRun:
    """Create, resume, or reuse one complete destination workload bundle."""

    if (
        getattr(resolved, "canonical_status", False) is True
        or getattr(resolved, "classification", None)
        in {
            "canonical",
            "locked_submission",
            "release_candidate",
            "locked_submission_candidate",
            "preset_candidate",
        }
    ):
        from dreamgym.profiling.autonomous_driving.workloads import (
            PROFILING_V3_NOT_RELEASED_MESSAGE,
        )

        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)

    if getattr(resolved, "canonical_status", False) is True and (
        not isinstance(source_validation, Mapping)
        or set(source_validation)
        != {"validated", "manifest_digest", "release_commit"}
        or source_validation.get("validated") is not True
        or type(source_validation.get("manifest_digest")) is not str
        or re.fullmatch(
            r"[0-9a-f]{64}",
            source_validation.get("manifest_digest", ""),
        )
        is None
        or type(source_validation.get("release_commit")) is not str
        or _COMMIT_PATTERN.fullmatch(
            source_validation.get("release_commit", ""),
        )
        is None
    ):
        raise ValueError(
            "canonical configurable profiling requires valid source validation"
        )

    same_previous_workload = (
        isinstance(previous, ConfigurableProfileRun)
        and previous.resolved.workload.workload_digest
        == resolved.workload.workload_digest
    )
    if (
        not fresh
        and same_previous_workload
        and previous.result.status == "successful"
    ):
        return previous

    runner_kwargs: dict[str, Any] = {}
    if source_validation is not None:
        runner_kwargs["source_validation"] = source_validation
    source_runs = list(reusable_runs)
    if (
        not fresh
        and same_previous_workload
        and previous.result.status in {"interrupted", "incomplete"}
    ):
        destination = Path(previous.result.output)
        runner_kwargs["resume"] = destination
    else:
        base = Path(output)
        occupied = base.is_dir() and any(base.iterdir())
        resume_existing = (
            not fresh
            and previous is None
            and occupied
            and _is_resumable_configurable_bundle(
                base,
                resolved,
                source_validation,
            )
        )
        destination = (
            base
            if resume_existing
            else _fresh_bundle_destination(base)
            if fresh or occupied
            else base
        )
        if resume_existing:
            runner_kwargs["resume"] = base
        elif isinstance(previous, ConfigurableProfileRun):
            source_runs.append(previous)
        if not resume_existing:
            imports = _reusable_import_plans(resolved, source_runs)
            if imports:
                runner_kwargs["imports"] = imports

    try:
        measured = runner(
            resolved,
            output=destination,
            progress_sink=(
                progress_sink
                if progress_sink is not None
                else lambda _event: None
            ),
            **runner_kwargs,
        )
    finally:
        _clear_progress_best_effort(clear_progress)
    imported_keys = {
        (
            plan.destination_semantic_case_id,
            plan.destination_execution_spec_digest,
        )
        for plan in runner_kwargs.get("imports", ())
    }
    reused = tuple(
        result
        for result in measured.case_results
        if (result.case_id, result.execution_spec_digest)
        in imported_keys
    )
    return ConfigurableProfileRun(
        result=measured,
        reused_results=reused,
        views=render_full_suite_views(resolved, measured),
        resolved=resolved,
    )


def _numeric_metric_leaves(
    value: Any,
    prefix: tuple[str, ...] = (),
) -> dict[str, float]:
    leaves: dict[str, float] = {}
    if isinstance(value, Mapping):
        for name, item in value.items():
            leaves.update(
                _numeric_metric_leaves(item, (*prefix, str(name)))
            )
    elif (
        not isinstance(value, bool)
        and isinstance(value, Real)
        and math.isfinite(float(value))
    ):
        leaves[".".join(prefix)] = float(value)
    return leaves


def _performance_metric(
    suite: str,
    metrics: Mapping[str, Any],
) -> tuple[str, float, str]:
    leaves = _numeric_metric_leaves(metrics)
    preferences = {
        "core": ("median", "per_second", "headline"),
        "mpc": (
            "post_warmup_median_complete_solver_time",
            "median_complete_solver_time",
            "median",
        ),
        "rl": (
            "median_transitions_per_second",
            "total_transitions_per_second",
            "median",
        ),
    }[suite]
    name = next(
        (
            key
            for preference in preferences
            for key in sorted(leaves)
            if preference in key
        ),
        next(iter(sorted(leaves)), "unavailable"),
    )
    value = leaves.get(name, 0.0)
    if name.endswith("_ns") or "_ns." in name:
        unit = "ns"
    elif "per_second" in name:
        unit = "1/s"
    elif name.endswith("_us") or "_us." in name:
        unit = "us"
    elif name.endswith("_seconds") or "_seconds." in name:
        unit = "s"
    else:
        unit = "value"
    return name, value, unit


def render_full_suite_views(
    resolved: Any,
    result: Any,
    *,
    reused_results: Sequence[Any] = (),
) -> dict[str, SuiteView]:
    """Build core, MPC, and RL views from structured result records."""

    case_suites = {
        (case.semantic_case_id, execution.execution_spec_digest):
        resolved.suite_for(case, execution)
        for case, execution in resolved.workload.cases
    }
    combined: dict[tuple[str, str], Any] = {}
    for candidate in (*tuple(reused_results), *tuple(result.case_results)):
        key = (candidate.case_id, candidate.execution_spec_digest)
        if key in case_suites and key not in combined:
            combined[key] = candidate
    tables: dict[str, list[dict[str, Any]]] = {
        "core": [],
        "mpc": [],
        "rl": [],
    }
    for case, execution in resolved.workload.cases:
        key = (case.semantic_case_id, execution.execution_spec_digest)
        candidate = combined.get(key)
        if candidate is None:
            continue
        suite = case_suites[key]
        metrics = candidate.to_dict()["metrics"]
        metric, value, unit = _performance_metric(suite, metrics)
        tables[suite].append(
            {
                "case_id": candidate.case_id,
                "status": candidate.status,
                "headline_metric": metric,
                "headline_value": value,
                "headline_unit": unit,
                "metrics": metrics,
            }
        )
    views = {}
    for suite, rows in tables.items():
        metric = (
            rows[0]["headline_metric"] if rows else "unavailable"
        )
        selected = [
            row for row in rows if row["headline_metric"] == metric
        ]
        views[suite] = SuiteView(
            suite=suite,
            table=tuple(rows),
            plot_series=PlotSeries(
                metric=metric,
                unit=(
                    selected[0]["headline_unit"]
                    if selected
                    else "value"
                ),
                labels=tuple(row["case_id"] for row in selected),
                values=tuple(
                    float(row["headline_value"]) for row in selected
                ),
            ),
        )
    return views


def default_notebook_output(environment: str, name: str) -> Path:
    """Return a stable session-local bundle path without a machine identifier."""

    if environment not in {"colab", "local"}:
        raise ValueError("notebook environment must be colab or local")
    if (
        type(name) is not str
        or not name
        or Path(name).name != name
        or name in {".", ".."}
    ):
        raise ValueError("bundle name must be one safe path component")
    return (
        Path("/content", name)
        if environment == "colab"
        else Path("profiling_results", name)
    )


def _path_is_link_or_reparse(path: Path) -> bool:
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return False
    return path.is_symlink() or bool(
        getattr(metadata, "st_file_attributes", 0) & 0x400
    )


def _indexed_bundle_files(document: Mapping[str, Any]) -> frozenset[str]:
    indexed = {"manifest.json", "results.json"}
    manifest = document["manifest"]
    for snapshot in manifest["configurations"].values():
        indexed.add(snapshot["requested_config_path"])
        if "resolved_config_path" in snapshot:
            indexed.add(snapshot["resolved_config_path"])
    for case in manifest["cases"].values():
        if "raw_samples" in case:
            indexed.add(case["raw_samples"]["path"])
        if "structured_records" in case:
            indexed.add(case["structured_records"]["path"])
    indexed.update(
        artifact["path"] for artifact in manifest["artifacts"].values()
    )
    return frozenset(indexed)


def _bundle_tree_entries(
    root: Path,
) -> tuple[frozenset[str], frozenset[str]]:
    from dreamgym.profiling.autonomous_driving.bundle import (
        BundleIntegrityError,
    )

    actual_files: set[str] = set()
    actual_directories: set[str] = set()
    pending = [root]
    while pending:
        directory = pending.pop()
        for candidate in directory.iterdir():
            relative = candidate.relative_to(root).as_posix()
            if _path_is_link_or_reparse(candidate):
                raise BundleIntegrityError(
                    "bundle export cannot contain a link or reparse point"
                )
            try:
                mode = candidate.lstat().st_mode
            except OSError as error:
                raise BundleIntegrityError(
                    "bundle export content cannot be inspected"
                ) from error
            if stat.S_ISREG(mode):
                actual_files.add(relative)
            elif stat.S_ISDIR(mode):
                actual_directories.add(relative)
                pending.append(candidate)
            else:
                raise BundleIntegrityError(
                    "bundle export content must be regular files"
                )
    return frozenset(actual_files), frozenset(actual_directories)


def _indexed_bundle_checksums(
    document: Mapping[str, Any],
) -> dict[str, str]:
    checksums: dict[str, str] = {}

    def index(path: str, digest: str) -> None:
        if path in checksums and checksums[path] != digest:
            raise ValueError("bundle path has conflicting checksums")
        checksums[path] = digest

    manifest = document["manifest"]
    for snapshot in manifest["configurations"].values():
        index(
            snapshot["requested_config_path"],
            snapshot["requested_file_sha256"],
        )
        if "resolved_config_path" in snapshot:
            index(
                snapshot["resolved_config_path"],
                snapshot["resolved_file_sha256"],
            )
    for case in manifest["cases"].values():
        for field in ("raw_samples", "structured_records"):
            if field in case:
                index(case[field]["path"], case[field]["sha256"])
    for artifact in manifest["artifacts"].values():
        index(artifact["path"], artifact["sha256"])
    return checksums


def _validated_bundle_export_files(
    bundle: str | Path,
) -> tuple[Path, tuple[tuple[str, bytes], ...]]:
    from dreamgym.profiling.autonomous_driving.bundle import (
        BundleIntegrityError,
        load_bundle,
    )

    source = Path(bundle)
    document = load_bundle(source)
    root = source.resolve(strict=True)
    indexed = _indexed_bundle_files(document)
    expected_directories = {
        parent.as_posix()
        for reference in indexed
        for parent in PurePosixPath(reference).parents
        if parent != PurePosixPath(".")
    }
    actual_files, actual_directories = _bundle_tree_entries(root)
    if (
        actual_files != set(indexed)
        or actual_directories != expected_directories
    ):
        raise BundleIntegrityError("bundle contains unindexed content")
    checksums = _indexed_bundle_checksums(document)
    payloads: list[tuple[str, bytes]] = []
    for relative in sorted(indexed):
        path = root.joinpath(*PurePosixPath(relative).parts)
        if _path_is_link_or_reparse(path) or not path.is_file():
            raise BundleIntegrityError(
                "indexed bundle file changed after validation"
            )
        try:
            payload = path.read_bytes()
        except OSError as error:
            raise BundleIntegrityError(
                "indexed bundle file changed after validation"
            ) from error
        if relative in {"manifest.json", "results.json"}:
            try:
                current = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as error:
                raise BundleIntegrityError(
                    "indexed bundle file changed after validation"
                ) from error
            expected = document[
                "manifest" if relative == "manifest.json" else "results"
            ]
            if current != expected:
                raise BundleIntegrityError(
                    "indexed bundle file changed after validation"
                )
        elif (
            relative not in checksums
            or hashlib.sha256(payload).hexdigest()
            != checksums[relative]
        ):
            raise BundleIntegrityError(
                "indexed bundle file checksum changed after validation"
            )
        payloads.append((relative, payload))
    final_files, final_directories = _bundle_tree_entries(root)
    if (
        final_files != actual_files
        or final_directories != actual_directories
    ):
        raise BundleIntegrityError(
            "bundle content changed during export validation"
        )
    return root, tuple(payloads)


def _validate_export_destination(source: Path, destination: Path) -> None:
    resolved_destination = destination.resolve(strict=False)
    if resolved_destination.is_relative_to(source):
        raise ValueError("export destination cannot be inside the source bundle")


def _export_staging_path(destination: Path) -> Path:
    return destination.with_name(
        "." + destination.name + ".exporting-" + uuid.uuid4().hex
    )


def prepare_bundle_download(
    bundle: str | Path,
    *,
    archive_path: str | Path,
) -> Path:
    """Create a ZIP only when the user explicitly calls this helper."""

    source, payloads = _validated_bundle_export_files(bundle)
    destination = Path(archive_path)
    _validate_export_destination(source, destination)
    if (
        destination.suffix.lower() != ".zip"
        or destination.exists()
        or _path_is_link_or_reparse(destination)
    ):
        raise ValueError("archive path must be a new ZIP file")
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = _export_staging_path(destination)
    try:
        with zipfile.ZipFile(
            staging,
            mode="x",
            compression=zipfile.ZIP_DEFLATED,
        ) as archive:
            for relative, payload in payloads:
                archive.writestr(
                    (PurePosixPath(source.name) / relative).as_posix(),
                    payload,
                )
        if destination.exists() or _path_is_link_or_reparse(destination):
            raise ValueError("archive path must remain a new ZIP file")
        os.replace(staging, destination)
    except BaseException:
        staging.unlink(missing_ok=True)
        raise
    return destination


def copy_bundle_to_drive(
    bundle: str | Path,
    destination: str | Path,
) -> Path:
    """Copy to an already-mounted Drive path only on an explicit call."""

    source, payloads = _validated_bundle_export_files(bundle)
    target = Path(destination)
    _validate_export_destination(source, target)
    if target.exists() or _path_is_link_or_reparse(target):
        raise ValueError("bundle must exist and destination must be new")
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = _export_staging_path(target)
    try:
        staging.mkdir()
        for relative, payload in payloads:
            target_file = staging.joinpath(
                *PurePosixPath(relative).parts
            )
            target_file.parent.mkdir(parents=True, exist_ok=True)
            target_file.write_bytes(payload)
        if target.exists() or _path_is_link_or_reparse(target):
            raise ValueError(
                "bundle destination must remain new during export"
            )
        os.replace(staging, target)
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return target


def validate_locked_release(
    resolved: Any,
    *,
    expected_commit: str,
    source_validation: SourceValidation,
    expected_manifest_digest: str | None,
) -> LockedReleaseValidation:
    """Validate release-attested source, workload, timing, and device gates."""

    try:
        from dreamgym.profiling.autonomous_driving.release import (
            RESULT_SCHEMA_RELEASE_ID,
            SUBMISSION_RELEASE_ID,
            TIMING_PROTOCOL_RELEASE_ID,
        )

        if (
            _COMMIT_PATTERN.fullmatch(expected_commit) is None
            or source_validation.validated is not True
            or re.fullmatch(
                r"[0-9a-f]{64}",
                expected_manifest_digest or "",
            )
            is None
            or source_validation.manifest_digest
            != expected_manifest_digest
            or re.fullmatch(
                r"[0-9a-f]{64}",
                source_validation.manifest_digest or "",
            )
            is None
            or resolved.canonical_status is not True
            or resolved.submission_status is not True
            or resolved.workload_release_id
            != SUBMISSION_RELEASE_ID
            or resolved.result_schema_release_id
            != RESULT_SCHEMA_RELEASE_ID
            or resolved.timing_protocol_release_id
            != TIMING_PROTOCOL_RELEASE_ID
            or resolved.workload.workload_digest
            != resolve_locked_submission().workload.workload_digest
        ):
            raise ValueError("locked release is not eligible")
        pairs = tuple(resolved.workload.cases)
        _expected_case_results(resolved)
        if tuple(
            resolved.suite_for(case, execution)
            for case, execution in pairs
        ) != ("mpc", "mpc", "rl", "rl"):
            raise ValueError("locked workload suite order is invalid")
        for case, execution in pairs:
            if (
                not case.timing_protocol.get("version")
                or not case.timing_protocol_digest
                or not execution.execution_document.get(
                    "execution_spec_version"
                )
            ):
                raise ValueError("locked timing identity is invalid")
            suite = resolved.suite_for(case, execution)
            if suite == "mpc":
                semantics = case.semantic_document.get("mpc", {})
                if (
                    semantics.get("policy") != "steering_rate"
                    or semantics.get("road_aware") is not False
                    or semantics.get("soft_constraints") != "on"
                    or semantics.get("prediction_horizon_steps")
                    not in (20, 80)
                ):
                    raise ValueError("locked MPC semantics are invalid")
            else:
                algorithm = case.semantic_document.get("algorithm", {})
                vectorization = case.semantic_document.get(
                    "vectorization",
                    {},
                )
                if (
                    algorithm.get("name") != "PPO"
                    or algorithm.get("device", {}).get(
                        "effective_constructor_device"
                    )
                    != "cpu"
                    or vectorization.get("kind") != "dummy"
                    or vectorization.get("effective_n_envs") not in (1, 4)
                    or execution.execution_document.get(
                        "requested_total_environment_transitions"
                    )
                    != 100_000
                    or execution.execution_document.get(
                        "timing_protocol_digest"
                    )
                    != case.timing_protocol_digest
                ):
                    raise ValueError("locked RL semantics are invalid")
        return LockedReleaseValidation(
            True,
            source_validation.manifest_digest,
            release_commit=expected_commit,
        )
    except (AttributeError, KeyError, TypeError, ValueError):
        return LockedReleaseValidation(
            False,
            None,
            "submission validation failed",
        )


def validate_installed_benchmark_release(
    *,
    expected_commit: str,
    resolved: Any = None,
    source_root: str | Path | None = None,
    manifest: Mapping[str, Any] | None = None,
    attested_manifest: Mapping[str, Any] | None = None,
    imported_module_origins: Mapping[str, str | Path] | None = None,
) -> LockedReleaseValidation:
    """Validate installed content against an exact release-commit attestation."""

    try:
        if _COMMIT_PATTERN.fullmatch(expected_commit) is None:
            raise ValueError("release commit must be an exact lowercase commit")
        locked = resolve_locked_submission() if resolved is None else resolved
        root = (
            Path(__file__).resolve().parents[3]
            if source_root is None
            else Path(source_root)
        )
        working_manifest = manifest
        if working_manifest is None:
            resource = importlib.resources.files(
                "dreamgym.profiling.autonomous_driving.resources"
            ) / "benchmark_sources_workload_v3.json"
            working_manifest = json.loads(
                resource.read_text(encoding="utf-8")
            )
        release_manifest = attested_manifest
        if release_manifest is None:
            manifest_path = (
                "dreamgym/profiling/autonomous_driving/resources/"
                "benchmark_sources_workload_v3.json"
            )
            attested = subprocess.run(
                (
                    "git",
                    "-C",
                    str(root),
                    "show",
                    expected_commit + ":" + manifest_path,
                ),
                capture_output=True,
                text=True,
                check=False,
            )
            if attested.returncode != 0:
                raise ValueError("release manifest is unavailable")
            release_manifest = json.loads(attested.stdout)
        from dreamgym.profiling.autonomous_driving.release import (
            _benchmark_source_manifest_document,
        )

        working_manifest = _benchmark_source_manifest_document(
            dict(working_manifest)
        )
        release_manifest = _benchmark_source_manifest_document(
            dict(release_manifest)
        )
        expected_manifest_digest = hashlib.sha256(
            canonical_json_bytes(dict(release_manifest))
        ).hexdigest()
        if hashlib.sha256(
            canonical_json_bytes(dict(working_manifest))
        ).hexdigest() != expected_manifest_digest:
            raise ValueError("working manifest differs from release")
        origins = imported_module_origins
        if origins is None:
            origins = {
                name: getattr(sys.modules[name], "__file__", None)
                for name in BENCHMARK_MODULE_ORIGINS_V3
                if name in sys.modules
            }
        sources = validate_benchmark_sources(
            root,
            release_manifest,
            imported_module_origins=origins,
        )
        return validate_locked_release(
            locked,
            expected_commit=expected_commit,
            source_validation=sources,
            expected_manifest_digest=expected_manifest_digest,
        )
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return LockedReleaseValidation(
            False,
            None,
            "submission validation failed",
        )


def _expected_case_results(resolved: Any) -> dict[tuple[str, str], tuple[Any, Any]]:
    cases = tuple(resolved.workload.cases)
    if len(cases) != 4:
        raise ValueError("locked workload must contain four cases")
    expected: dict[tuple[str, str], tuple[Any, Any]] = {}
    for case, execution in cases:
        key = (case.semantic_case_id, execution.execution_spec_digest)
        if key in expected:
            raise ValueError("locked workload case identity is duplicated")
        expected[key] = (case, execution)
    return expected


def _finite_positive(value: Any) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, Real)
        or not math.isfinite(float(value))
        or float(value) <= 0.0
    ):
        raise ValueError("headline metric must be finite and positive")
    return float(value)


def _mpc_value(case: Any, execution: Any, result: Any) -> float:
    semantics = case.semantic_document.get("mpc")
    if (
        not isinstance(semantics, Mapping)
        or semantics.get("policy") != "steering_rate"
        or semantics.get("road_aware") is not False
        or semantics.get("soft_constraints") != "on"
        or semantics.get("prediction_horizon_steps") not in (20, 80)
    ):
        raise ValueError("locked MPC semantics are invalid")
    required_samples = (
        execution.execution_document["sample_count"]
        * execution.execution_document["repetitions"]
    )
    if len(result.sample_ns) != required_samples:
        raise ValueError("locked MPC sample count is invalid")
    headline = result.metrics.get("headline")
    if (
        not isinstance(headline, Mapping)
        or headline.get("metric")
        != "post_warmup_median_complete_solver_time"
        or headline.get("unit") != "ns/solve"
    ):
        raise ValueError("locked MPC headline is invalid")
    value = _finite_positive(
        headline.get("median_complete_solver_time_ns")
    )
    if value != float(median(result.sample_ns)):
        raise ValueError("locked MPC headline disagrees with raw samples")
    return value / 1_000_000.0


def _rl_value(case: Any, execution: Any, result: Any) -> float:
    algorithm = case.semantic_document.get("algorithm")
    vectorization = case.semantic_document.get("vectorization")
    requested_transitions = execution.execution_document[
        "requested_total_environment_transitions"
    ]
    required_windows = execution.execution_document["steady_state_windows"][
        "required_complete_window_count"
    ]
    cadence = (
        algorithm.get("cadence")
        if isinstance(algorithm, Mapping)
        else None
    )
    rollout_transitions = (
        cadence.get("effective_rollout_transitions")
        if isinstance(cadence, Mapping)
        else None
    )
    minimum_window_transitions = execution.execution_document[
        "steady_state_windows"
    ]["minimum_transition_count"]
    complete_window_transitions = (
        (
            (
                minimum_window_transitions
                + rollout_transitions
                - 1
            )
            // rollout_transitions
        )
        * rollout_transitions
        if (
            type(minimum_window_transitions) is int
            and minimum_window_transitions > 0
            and type(rollout_transitions) is int
            and rollout_transitions > 0
        )
        else None
    )
    expected_actual_transitions = (
        (
            (
                requested_transitions
                + rollout_transitions
                - 1
            )
            // rollout_transitions
        )
        * rollout_transitions
        if (
            type(requested_transitions) is int
            and requested_transitions > 0
            and isinstance(cadence, Mapping)
            and cadence.get("family") == "on_policy"
            and type(rollout_transitions) is int
            and rollout_transitions > 0
        )
        else None
    )
    if (
        not isinstance(algorithm, Mapping)
        or algorithm.get("name") != "PPO"
        or algorithm.get("device", {}).get(
            "effective_constructor_device"
        )
        != "cpu"
        or not isinstance(vectorization, Mapping)
        or vectorization.get("kind") != "dummy"
        or vectorization.get("effective_n_envs") not in (1, 4)
        or execution.execution_document[
            "requested_total_environment_transitions"
        ]
        != 100_000
        or expected_actual_transitions is None
        or complete_window_transitions is None
    ):
        raise ValueError("locked RL semantics are invalid")
    metrics = result.metrics
    training = metrics.get("training")
    devices = metrics.get("devices")
    measured_vectorization = metrics.get("vectorization")
    if (
        metrics.get("requested_transitions") != 100_000
        or metrics.get("actual_transitions")
        != expected_actual_transitions
        or not isinstance(training, Mapping)
        or training.get("canonical_window_requirement_met") is not True
        or training.get("complete_window_count", 0) < required_windows
        or training.get("required_complete_window_count")
        != required_windows
        or training.get("complete_window_count")
        != len(result.sample_ns)
        or len(result.sample_ns) < required_windows
        or any(
            type(sample) is not int or sample <= 0
            for sample in result.sample_ns
        )
        or not isinstance(devices, Mapping)
        or {devices.get(name) for name in ("requested", "resolved", "observed")}
        != {"cpu"}
        or not isinstance(measured_vectorization, Mapping)
        or measured_vectorization.get("kind") != "dummy"
        or measured_vectorization.get("effective_n_envs")
        != vectorization["effective_n_envs"]
        or metrics.get("algorithm", {}).get("name") != "PPO"
    ):
        raise ValueError("locked RL result is invalid")
    headline = _finite_positive(
        training.get("median_transitions_per_second")
    )
    rates = tuple(
        complete_window_transitions * 1_000_000_000.0 / sample
        for sample in result.sample_ns
    )
    if headline != float(median(rates)):
        raise ValueError("locked RL headline disagrees with raw samples")
    return headline


def format_locked_submission(
    resolved: Any,
    results: Sequence[Any],
) -> SubmissionDisplay | SubmissionDiagnostic:
    """Validate exact case identities and format the four Canvas values."""

    try:
        expected = _expected_case_results(resolved)
        actual: dict[tuple[str, str], Any] = {}
        for result in results:
            key = (result.case_id, result.execution_spec_digest)
            if key in actual:
                raise ValueError("submission case result is duplicated")
            actual[key] = result
        if set(actual) != set(expected) or len(actual) != 4:
            raise ValueError("submission case result population is invalid")
        values: list[float] = []
        for key, (case, execution) in expected.items():
            result = actual[key]
            if result.status != "completed":
                raise ValueError("submission case did not complete")
            suite = case.semantic_document.get("suite")
            values.append(
                _mpc_value(case, execution, result)
                if suite == "mpc"
                else _rl_value(case, execution, result)
            )
        labels = (
            ("MPC short horizon", "ms per solve"),
            ("MPC long horizon", "ms per solve"),
            ("PPO single environment", "steps per second"),
            ("PPO vector environments", "steps per second"),
        )
        return SubmissionDisplay(tuple(
            SubmissionRow(label, value, unit)
            for (label, unit), value in zip(labels, values, strict=True)
        ))
    except (AttributeError, KeyError, TypeError, ValueError):
        return SubmissionDiagnostic("submission result validation failed")


def _fresh_bundle_destination(output: str | Path) -> Path:
    destination = Path(output)
    if not destination.exists():
        return destination
    index = 1
    while True:
        candidate = destination.with_name(
            destination.name + "-fresh-" + str(index)
        )
        if not candidate.exists():
            return candidate
        index += 1


def _is_completed_locked_bundle(destination: Path, locked: Any) -> bool:
    from dreamgym.profiling.autonomous_driving.bundle import load_bundle
    from dreamgym.profiling.autonomous_driving.records import (
        execution_instance_id,
    )

    try:
        document = load_bundle(destination)
        if (
            document["manifest"]["workload"]["workload_digest"]
            != locked.workload.workload_digest
        ):
            return False
        expected = {
            execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            )
            for case, execution in locked.workload.cases
        }
        stored = document["results"]["cases"]
        return set(stored) == expected and all(
            result["status"] == "completed"
            for result in stored.values()
        )
    except (OSError, TypeError, ValueError):
        return False


def run_locked_submission(
    *,
    release_commit: str | None,
    output: str | Path,
    runner: Callable[..., Any],
    validation: LockedReleaseValidation | None = None,
    resolved: Any = None,
    previous: LockedSubmissionRun | None = None,
    fresh: bool = False,
    environment: str | None = None,
    progress_sink: Callable[[Any], None] | None = None,
    clear_progress: Callable[[], None] | None = None,
) -> LockedSubmissionRun | SubmissionDiagnostic:
    """Run or exactly reuse the locked benchmark with controlled output."""

    from dreamgym.profiling.autonomous_driving.workloads import (
        PROFILING_V3_NOT_RELEASED_MESSAGE,
    )

    if resolved is None:
        try:
            locked = resolve_locked_submission()
        except ValueError as error:
            if str(error) == PROFILING_V3_NOT_RELEASED_MESSAGE:
                return SubmissionDiagnostic(
                    PROFILING_V3_NOT_RELEASED_MESSAGE
                )
            raise
    else:
        locked = resolved
    if (
        getattr(locked, "canonical_status", False) is True
        or getattr(locked, "classification", None)
        in {
            "canonical",
            "locked_submission",
            "release_candidate",
            "locked_submission_candidate",
            "preset_candidate",
        }
    ):
        return SubmissionDiagnostic(PROFILING_V3_NOT_RELEASED_MESSAGE)

    return _run_validated_locked_submission(
        release_commit=release_commit,
        output=output,
        runner=runner,
        validation=validation,
        resolved=locked,
        previous=previous,
        fresh=fresh,
        environment=environment,
        progress_sink=progress_sink,
        clear_progress=clear_progress,
    )


def _run_validated_locked_submission(
    *,
    release_commit: str | None,
    output: str | Path,
    runner: Callable[..., Any],
    validation: LockedReleaseValidation | None = None,
    resolved: Any,
    previous: LockedSubmissionRun | None = None,
    fresh: bool = False,
    environment: str | None = None,
    progress_sink: Callable[[Any], None] | None = None,
    clear_progress: Callable[[], None] | None = None,
) -> LockedSubmissionRun | SubmissionDiagnostic:
    """Run post-gate submission mechanics for an already resolved fixture."""

    locked = resolved
    if release_commit is None:
        return SubmissionDiagnostic("benchmark release not frozen")
    if (
        _COMMIT_PATTERN.fullmatch(release_commit) is None
        or validation is None
        or validation.validated is not True
        or validation.release_commit != release_commit
        or re.fullmatch(r"[0-9a-f]{64}", validation.manifest_digest or "")
        is None
    ):
        return SubmissionDiagnostic("submission validation failed")
    if (
        locked.canonical_status is not True
        or locked.submission_status is not True
    ):
        return SubmissionDiagnostic("submission validation failed")
    try:
        _expected_case_results(locked)
    except (AttributeError, KeyError, TypeError, ValueError):
        return SubmissionDiagnostic("submission validation failed")
    identity = (
        release_commit,
        locked.workload.workload_digest,
        validation.manifest_digest,
    )
    if (
        not fresh
        and isinstance(previous, LockedSubmissionRun)
        and previous.compatibility_identity == identity
        and previous.result.status == "successful"
        and Path(previous.result.output) == Path(output)
    ):
        cached_display = format_locked_submission(
            locked,
            previous.result.case_results,
        )
        if isinstance(cached_display, SubmissionDisplay):
            return replace(previous, display=cached_display)
    stdout = io.StringIO()
    stderr = io.StringIO()
    destination = (
        _fresh_bundle_destination(output)
        if fresh
        else Path(output)
    )
    try:
        occupied = (
            not fresh
            and destination.is_dir()
            and any(destination.iterdir())
        )
        if occupied and _is_completed_locked_bundle(
            destination,
            locked,
        ):
            destination = _fresh_bundle_destination(destination)
            resume = None
        else:
            resume = destination if occupied else None
        with (
            contextlib.redirect_stdout(stdout),
            contextlib.redirect_stderr(stderr),
        ):
            result = runner(
                locked,
                output=destination,
                resume=resume,
                progress_sink=(
                    progress_sink
                    if progress_sink is not None
                    else lambda _event: None
                ),
                terminal_stream=stdout,
                source_validation=validation.to_dict(),
            )
    except (KeyboardInterrupt, Exception):
        return SubmissionDiagnostic("submission benchmark failed")
    finally:
        _clear_progress_best_effort(clear_progress)
    if result.status != "successful":
        return SubmissionDiagnostic("submission benchmark failed")
    display = format_locked_submission(locked, result.case_results)
    if isinstance(display, SubmissionDiagnostic):
        return display
    return LockedSubmissionRun(
        display=display,
        result=result,
        compatibility_identity=identity,
        environment=environment or detect_notebook_environment(),
        resolved=locked,
    )


__all__ = [
    "ColabSetupPlan",
    "ConfigurableProfileRun",
    "LocalSetupPlan",
    "LockedReleaseValidation",
    "LockedSubmissionRun",
    "PlotSeries",
    "SourceValidation",
    "SubmissionDiagnostic",
    "SubmissionDisplay",
    "SubmissionRow",
    "SuiteView",
    "build_colab_setup_plan",
    "build_local_setup_plan",
    "copy_bundle_to_drive",
    "default_notebook_output",
    "detect_notebook_environment",
    "format_locked_submission",
    "matching_completed_cases",
    "prepare_bundle_download",
    "render_full_suite_views",
    "resolve_configurable_profile",
    "resolve_locked_submission",
    "run_configurable_profile",
    "run_locked_submission",
    "validate_benchmark_sources",
    "validate_installed_benchmark_release",
    "validate_locked_release",
]
