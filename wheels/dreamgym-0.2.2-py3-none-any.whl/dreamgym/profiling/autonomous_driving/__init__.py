"""Lazy public API for unified autonomous-driving profiling."""

__all__ = [
    "ProfileRequest",
    "ProfileRunResult",
    "resolve_profile_request",
    "run_profile",
    "MachineProfileConfig",
    "profile_machine",
]


def __getattr__(name):
    if name in {"ProfileRequest", "resolve_profile_request"}:
        from dreamgym.profiling.autonomous_driving.workloads import (
            ProfileRequest,
            resolve_profile_request,
        )

        values = {
            "ProfileRequest": ProfileRequest,
            "resolve_profile_request": resolve_profile_request,
        }
    elif name in {"ProfileRunResult", "run_profile"}:
        from dreamgym.profiling.autonomous_driving.runner import (
            ProfileRunResult,
            run_profile,
        )

        values = {
            "ProfileRunResult": ProfileRunResult,
            "run_profile": run_profile,
        }
    elif name in {"MachineProfileConfig", "profile_machine"}:
        from dreamgym.profiling.autonomous_driving.machine import (
            MachineProfileConfig,
            profile_machine,
        )

        values = {
            "MachineProfileConfig": MachineProfileConfig,
            "profile_machine": profile_machine,
        }
    else:
        raise AttributeError(
            f"module {__name__!r} has no attribute {name!r}"
        )

    globals().update(values)
    return values[name]
