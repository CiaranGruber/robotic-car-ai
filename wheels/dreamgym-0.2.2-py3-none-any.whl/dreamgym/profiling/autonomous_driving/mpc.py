"""Controlled computation-time profiling for the teaching MPC policies."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import copy
from dataclasses import dataclass, replace
import importlib
import math
from numbers import Real
from statistics import median
import time
from types import MappingProxyType
from typing import Any

import numpy as np

from dreamgym.profiling.autonomous_driving.measurement import (
    summarize_sample_ns,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    case_measurement_diagnostic,
    sanitize_diagnostic_message,
    validate_case_diagnostic,
)
from dreamgym.profiling.autonomous_driving.records import (
    PROFILE_RESULTS_SCHEMA_VERSION,
    CaseResult,
    CaseSpec,
    ExecutionSpec,
    ProgressEvent,
    canonical_json_digest,
)
from dreamgym.profiling.autonomous_driving.workloads import (
    WORKLOAD_RESOURCE_SCHEMA_VERSION,
    WORKLOAD_VERSION,
    ResolvedProfileWorkload,
    load_workload_resource,
    resolve_development_workload,
)


_CANONICAL_POLICIES = ("direct_steering", "steering_rate")
_CANONICAL_HORIZONS = (10, 20, 40, 80)
_SOFT_STATE_BOUND_FIELDS = (
    "soft_speed_state_lower_mps",
    "recommended_speed_soft_upper_margin_mps",
    "soft_lateral_error_state_lower_metres",
    "soft_lateral_error_state_upper_metres",
    "soft_heading_error_state_lower_radians",
    "soft_heading_error_state_upper_radians",
)
_STRUCTURAL_FIELDS = (
    "decision_variable_count",
    "constraint_row_count",
    "hessian_nonzero_count",
    "constraint_matrix_nonzero_count",
)
MPC_FIXTURE_SEQUENCE_VERSION = "dreamgym-mpc-fixture-sequence-v1"
MPC_FIXTURE_SEQUENCE_DIGEST_V1 = (
    "b3b6a828eb20640199a7e6d750287769e27938c06eac2e506aafadd5482d6cf8"
)
MPC_ROAD_AWARE_FIXTURE_SEQUENCE_DIGEST_V1 = (
    "db07f29b55a374dbfdaf877aff39559d1683c3ade1c6a688045055a017ad6f8a"
)
_SUBMISSION_WORKLOAD_RELEASE_ID = (
    "dreamgym-machine-profile-submission-v2"
)
_SUBMISSION_TIMING_PROTOCOL_RELEASE_ID = (
    "dreamgym-profile-timing-v1"
)


@dataclass(frozen=True)
class _MPCSubmissionReleaseSource:
    """Checked-in authority required before numeric submission projection."""

    workload: ResolvedProfileWorkload
    workload_resource_schema_version: str | None
    workload_release_id: str | None
    workload_digest: str | None
    timing_protocol_release_id: str | None
    timing_protocol_digests: Mapping[str, str] | None
    result_schema_version: str | None
    benchmark_source_manifest_digest: str | None
    benchmark_source_manifest_validated: bool
    release_reference: str | None
    active_release_reference: str | None


def _load_mpc_submission_release_authority(
) -> _MPCSubmissionReleaseSource:
    """Load release facts from the strict checked-in authorities."""

    workload = load_workload_resource("submission_workload_v2.json")
    profile_release = load_workload_resource("workload_v2.json")
    from dreamgym.profiling.autonomous_driving.release import (
        validate_current_benchmark_sources,
    )

    source_validation = validate_current_benchmark_sources()
    source_release_reference = source_validation.get("release_commit")
    return _MPCSubmissionReleaseSource(
        workload=workload,
        workload_resource_schema_version=WORKLOAD_RESOURCE_SCHEMA_VERSION,
        workload_release_id=workload.workload_release_id,
        workload_digest=workload.workload.workload_digest,
        timing_protocol_release_id=(
            profile_release.timing_protocol_release_id
        ),
        timing_protocol_digests={
            case.semantic_case_id: case.timing_protocol_digest
            for case, _execution in workload.workload.cases
            if case.semantic_document.get("suite") == "mpc"
        },
        result_schema_version=profile_release.result_schema_release_id,
        benchmark_source_manifest_digest=(
            source_validation.get("manifest_digest")
        ),
        benchmark_source_manifest_validated=(
            source_validation.get("validated") is True
        ),
        release_reference=source_release_reference,
        active_release_reference=source_release_reference,
    )


def _is_lower_hex(value: object, length: int) -> bool:
    return (
        type(value) is str
        and len(value) == length
        and value == value.lower()
        and any(character != "0" for character in value)
        and all(character in "0123456789abcdef" for character in value)
    )


def _resolve_mpc_submission_release() -> _MPCSubmissionReleaseSource:
    """Validate every release gate before exposing submission identities."""

    source = _load_mpc_submission_release_authority()
    if not isinstance(source, _MPCSubmissionReleaseSource):
        raise TypeError(
            "MPC submission release source has an invalid internal type"
        )
    workload = source.workload
    mpc_pairs = tuple(
        (case, execution)
        for case, execution in workload.workload.cases
        if case.semantic_document.get("suite") == "mpc"
    )
    expected_mpc_semantics = (
        ("steering_rate", 20, "on"),
        ("steering_rate", 80, "on"),
    )
    actual_mpc_semantics = tuple(
        (
            case.semantic_document["mpc"]["policy"],
            case.semantic_document["mpc"]["prediction_horizon_steps"],
            case.semantic_document["mpc"]["soft_constraints"],
        )
        for case, _execution in mpc_pairs
    )
    expected_timing_digests = {
        case.semantic_case_id: case.timing_protocol_digest
        for case, _execution in mpc_pairs
    }
    gates = {
        "workload v2": (
            source.workload_resource_schema_version
            == WORKLOAD_RESOURCE_SCHEMA_VERSION
            and source.workload_release_id
            == _SUBMISSION_WORKLOAD_RELEASE_ID
            and workload.workload.workload_version == WORKLOAD_VERSION
            and source.workload_digest
            == workload.workload.workload_digest
            and workload.classification == "locked_submission"
            and workload.canonical_status
            and workload.submission_status
            and actual_mpc_semantics == expected_mpc_semantics
            and all(
                execution.execution_document.get(
                    "candidate_execution"
                )
                is False
                for _case, execution in workload.workload.cases
            )
        ),
        "timing protocol": (
            source.timing_protocol_release_id
            == _SUBMISSION_TIMING_PROTOCOL_RELEASE_ID
            and bool(mpc_pairs)
            and isinstance(source.timing_protocol_digests, Mapping)
            and dict(source.timing_protocol_digests)
            == expected_timing_digests
            and all(
                case.timing_protocol.get("version")
                == "dreamgym-mpc-solve-timing-v1"
                for case, _execution in mpc_pairs
            )
        ),
        "result schema": (
            source.result_schema_version
            == PROFILE_RESULTS_SCHEMA_VERSION
            and all(
                case.schema_version == PROFILE_RESULTS_SCHEMA_VERSION
                and execution.schema_version
                == PROFILE_RESULTS_SCHEMA_VERSION
                for case, execution in workload.workload.cases
            )
        ),
        "benchmark-source manifest": _is_lower_hex(
            source.benchmark_source_manifest_digest,
            64,
        )
        and source.benchmark_source_manifest_validated is True,
        "release reference": (
            _is_lower_hex(source.release_reference, 40)
            and source.active_release_reference
            == source.release_reference
        ),
    }
    failed = tuple(name for name, approved in gates.items() if not approved)
    if failed:
        raise ValueError(
            "benchmark release is not frozen; unapproved gates: "
            + ", ".join(failed)
        )
    return source


def _finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(name + " must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(name + " must be finite")
    return converted


def _copy_fixture_value(name: str, value: object) -> object:
    if isinstance(value, np.ndarray):
        if value.dtype.kind not in "biuf":
            raise TypeError(name + " arrays must have a JSON numeric dtype")
        if value.dtype.kind == "f" and not np.isfinite(value).all():
            raise ValueError(name + " arrays must contain finite values")
        copied = np.array(value, copy=True)
        copied.setflags(write=False)
        return copied
    if isinstance(value, Mapping):
        return MappingProxyType(
            {
                str(key): _copy_fixture_value(
                    name + "." + str(key),
                    item,
                )
                for key, item in value.items()
            }
        )
    if isinstance(value, tuple):
        return tuple(
            _copy_fixture_value(name + "[]", item) for item in value
        )
    if value is None or type(value) in (bool, int, float, str):
        if type(value) is float and not math.isfinite(value):
            raise ValueError(name + " must contain finite values")
        return value
    raise TypeError(name + " contains an unsupported fixture value")


def _fixture_json(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Mapping):
        return {key: _fixture_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_fixture_json(item) for item in value]
    return value


def _fixture_call_value(value: object) -> object:
    """Detach immutable fixture storage into ordinary policy input containers."""

    if isinstance(value, np.ndarray):
        return np.array(value, copy=True)
    if isinstance(value, Mapping):
        return {
            key: _fixture_call_value(item) for key, item in value.items()
        }
    if isinstance(value, tuple):
        return tuple(_fixture_call_value(item) for item in value)
    return value


@dataclass(frozen=True, slots=True)
class MPCInputFixture:
    """One complete, fixed input to a controlled MPC policy invocation."""

    observation: object
    info: Mapping[str, Any]
    terminated: bool
    truncated: bool
    drive_command: float
    steering_rate: float
    steering_angle: float

    def __post_init__(self) -> None:
        observation = _copy_fixture_value("observation", self.observation)
        if not isinstance(self.info, Mapping):
            raise TypeError("info must be a mapping")
        info = _copy_fixture_value("info", self.info)
        assert isinstance(info, Mapping)
        if not isinstance(self.terminated, bool):
            raise TypeError("terminated must be a bool")
        if not isinstance(self.truncated, bool):
            raise TypeError("truncated must be a bool")
        object.__setattr__(self, "observation", observation)
        object.__setattr__(self, "info", info)
        for field_name in (
            "drive_command",
            "steering_rate",
            "steering_angle",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_float(field_name, getattr(self, field_name)),
            )

    def digest_document(self) -> dict[str, Any]:
        return {
            "observation": _fixture_json(self.observation),
            "info": _fixture_json(self.info),
            "terminated": self.terminated,
            "truncated": self.truncated,
            "applied_action": {
                "drive_command": self.drive_command,
                "steering_rate": self.steering_rate,
                "steering_angle": self.steering_angle,
            },
        }


def _validated_fixture_sequence(
    fixtures: Sequence[MPCInputFixture],
) -> tuple[MPCInputFixture, ...]:
    if isinstance(fixtures, (str, bytes)):
        raise TypeError("fixtures must be a sequence of MPCInputFixture")
    normalized = tuple(fixtures)
    if not normalized:
        raise ValueError("fixtures must not be empty")
    if not all(isinstance(item, MPCInputFixture) for item in normalized):
        raise TypeError("fixtures must contain MPCInputFixture records")
    return normalized


def fixture_sequence_digest(
    fixtures: Sequence[MPCInputFixture],
) -> str:
    """Return the canonical digest shared by every controlled matrix case."""

    normalized = _validated_fixture_sequence(fixtures)
    return canonical_json_digest(
        [fixture.digest_document() for fixture in normalized]
    )


def build_mpc_case_specs(
    resolved: ResolvedProfileWorkload | None = None,
) -> tuple[CaseSpec, ...]:
    """Return the workload-owned canonical non-road-aware 2 x 4 x 2 matrix."""

    if resolved is None:
        resolved = resolve_development_workload()
    if not isinstance(resolved, ResolvedProfileWorkload):
        raise TypeError("resolved must be a ResolvedProfileWorkload or None")
    cases = tuple(
        case
        for case in resolved.mpc_cases()
        if not case.semantic_document["mpc"]["road_aware"]
        and case.semantic_document["mpc"]["policy"] in _CANONICAL_POLICIES
    )
    matrix = tuple(
        (
            case.semantic_document["mpc"]["policy"],
            case.semantic_document["mpc"]["prediction_horizon_steps"],
            case.semantic_document["mpc"]["soft_constraints"],
        )
        for case in cases
    )
    expected = tuple(
        (policy, horizon, soft_mode)
        for policy in _CANONICAL_POLICIES
        for horizon in _CANONICAL_HORIZONS
        for soft_mode in ("off", "on")
    )
    if matrix != expected:
        raise ValueError("canonical MPC workload matrix has drifted")
    return cases


def _mpc_semantics(case: CaseSpec) -> Mapping[str, Any]:
    if not isinstance(case, CaseSpec):
        raise TypeError("case must be a CaseSpec")
    if case.semantic_document.get("suite") != "mpc":
        raise ValueError("case is not an MPC profiling case")
    semantics = case.semantic_document.get("mpc")
    if not isinstance(semantics, Mapping):
        raise ValueError("MPC case semantics are malformed")
    return semantics


def build_mpc_policy_config(case: CaseSpec):
    """Build one case from its public teaching baseline."""

    from dreamgym.policies.autonomous_driving.mpc_config import (
        AutonomousDrivingDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareSteeringRateMPCConfig,
        AutonomousDrivingSteeringRateMPCConfig,
    )

    semantics = _mpc_semantics(case)
    policy = semantics.get("policy")
    horizon = semantics.get("prediction_horizon_steps")
    soft_mode = semantics.get("soft_constraints")
    if type(horizon) is not int or horizon <= 0:
        raise ValueError("prediction_horizon_steps must be a positive integer")
    if policy == "direct_steering":
        config = AutonomousDrivingDirectSteeringMPCConfig.teaching_baseline(
            horizon_steps=horizon,
        )
    elif policy == "steering_rate":
        config = AutonomousDrivingSteeringRateMPCConfig.teaching_baseline(
            horizon_steps=horizon,
        )
    elif policy == "road_aware_direct_steering":
        config = (
            AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            .fully_road_aware_teaching_preset(horizon_steps=horizon)
        )
    elif policy == "road_aware_steering_rate":
        config = (
            AutonomousDrivingRoadAwareSteeringRateMPCConfig
            .fully_road_aware_teaching_preset(horizon_steps=horizon)
        )
    else:
        raise ValueError("unsupported MPC policy family")
    if soft_mode == "on":
        return config
    if soft_mode != "off":
        raise ValueError("soft_constraints must be off or on")
    disabled_soft_fields = {
        field_name: None for field_name in _SOFT_STATE_BOUND_FIELDS
    }
    road_aware = policy.startswith("road_aware_")
    if road_aware:
        disabled_soft_fields.update(
            {
                "speed_limit_soft_upper_margin_mps": None,
                "maximum_lateral_acceleration_mps2": None,
            }
        )
    constraints = replace(
        config.constraints,
        **disabled_soft_fields,
    )
    return replace(
        config,
        constraints=constraints,
        **({"use_lane_bound_constraints": False} if road_aware else {}),
    )


def _required_observation_config(
    *,
    include_road_preview: bool = False,
) -> dict[str, object]:
    routed = {"destination": "observation", "scaling_factor": 1.0}
    parameters: dict[str, object] = {
        "body_longitudinal_velocity_mps": dict(routed),
        "front_wheel_steering_angle_rad": dict(routed),
        "lateral_error_from_target_line_m": dict(routed),
        "heading_error_from_target_line_rad": dict(routed),
        "recommended_speed_mps": dict(routed),
        "next_recommended_speed_change": {
            "value_mps": dict(routed),
            "reference_line_distance_m": dict(routed),
        },
    }
    if include_road_preview:
        parameters["road_preview"] = {
            "target_line_distances_m": [
                float(distance) for distance in range(0, 161, 5)
            ],
            "lane_bounds": {
                "mode": "reference_lane",
                "require_active_lane": True,
            },
            "target_line_curvatures_per_m": dict(routed),
            "recommended_speeds_mps": dict(routed),
            "speed_limits_mps": dict(routed),
            "right_lane_bound_offsets_from_target_line_m": dict(routed),
            "left_lane_bound_offsets_from_target_line_m": dict(routed),
            "is_spatially_valid": {"destination": "observation"},
            "lane_bounds_are_available": {"destination": "observation"},
        }
    return parameters


def _fixed_initial_state_config() -> dict[str, Any]:
    def fixed(value: float) -> dict[str, float]:
        return {"lower": value, "upper": value}

    return {
        "bounds": {
            "world_pose": {
                "x_m": fixed(2.0),
                "y_m": fixed(0.0),
                "heading_rad": fixed(0.0),
            },
            "body_motion": {
                "longitudinal_velocity_mps": fixed(15.0),
                "lateral_velocity_mps": fixed(0.0),
                "yaw_rate_rad_per_s": fixed(0.0),
            },
            "front_wheel_steering_angle_rad": fixed(0.0),
        },
        "reference_line_progress_search": None,
    }


def _mpc_fixture_environment_spec(
    *,
    road_aware: bool = False,
) -> dict[str, Any]:
    specification = {
        "render_mode": None,
        "bicycle_model_config": {
            "axle_geometry": {
                "front_axle_distance_from_center_of_mass_m": 1.25,
                "rear_axle_distance_from_center_of_mass_m": 1.75,
            },
            "mass_properties": {
                "mass_kg": 1200.0,
                "yaw_moment_of_inertia_kg_m2": 1800.0,
            },
            "longitudinal_force_model": {
                "normalized_motor_command_force_gain_n": 2400.0,
                "quadratic_aerodynamic_drag_coefficient_kg_per_m": 0.0,
            },
            "steering": {
                "physical_front_wheel_angle_offset_from_request_rad": 0.0,
                "requested_front_wheel_angle_magnitude_limit_rad": 0.6,
                "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                    "lower": -0.7,
                    "upper": 0.8,
                },
            },
            "kinematic_dynamic_transition": {
                "body_longitudinal_speed_range_mps": {
                    "lower": 1000.0,
                    "upper": 1001.0,
                }
            },
        },
        "road_spec": {
            "elements": [
                {
                    "geometry": {"type": "straight", "length_m": 40.0},
                    "speed_limit_kph": 72.0,
                },
                {
                    "geometry": {"type": "straight", "length_m": 80.0},
                    "speed_limit_kph": 54.0,
                },
            ]
        },
        "integration_config": {
            "method": "rk4",
            "environment_step_duration_s": 0.1,
            "substep_count": 1,
        },
        "termination_config": {
            "planar_speed_bounds_mps": {"lower": 0.0, "upper": 100.0},
            "absolute_lateral_error_from_target_line_upper_bound_m": 100.0,
        },
        "initial_state_config": _fixed_initial_state_config(),
        "observation_config": _required_observation_config(
            include_road_preview=road_aware,
        ),
        "target_line_config": {"mode": "reference_line"},
        "internal_policy_config": {
            "action_interface": "full",
            "lane_keeping": {"enabled": False},
            "cruise_control": {"enabled": False},
        },
        "observation_format": "dict",
    }
    if road_aware:
        specification["road_spec"]["elements"][0]["lanes"] = {
            "reference_line_role": "lane_center",
            "reference_lane": {"width_m": {"start": 4.0}},
        }
        specification["road_spec"]["elements"][1]["geometry"][
            "length_m"
        ] = 240.0
    return specification


def mpc_fixture_sequence_spec(
    *,
    road_aware: bool = False,
) -> dict[str, Any]:
    """Return every deterministic input consumed by the v1 fixture builder."""

    return {
        "version": MPC_FIXTURE_SEQUENCE_VERSION,
        "generation_seed": 0,
        "sequence_length": 4,
        "step_actions": [
            [0.05, -0.02],
            [0.06, -0.01],
            [0.07, 0.0],
        ],
        "environment": _mpc_fixture_environment_spec(
            road_aware=road_aware,
        ),
        "expected_fixture_digest": (
            MPC_ROAD_AWARE_FIXTURE_SEQUENCE_DIGEST_V1
            if road_aware
            else MPC_FIXTURE_SEQUENCE_DIGEST_V1
        ),
    }


def _make_teaching_environment(
    environment_spec: Mapping[str, Any] | None = None,
):
    from dreamgym.envs.autonomous_driving_env import AutonomousDrivingEnv

    spec = (
        _mpc_fixture_environment_spec()
        if environment_spec is None
        else copy.deepcopy(dict(environment_spec))
    )
    return AutonomousDrivingEnv(**spec)


def prepare_mpc_fixture_sequence(
    *,
    item_count: int = 4,
    seed: int = 0,
    specification: Mapping[str, Any] | None = None,
) -> tuple[MPCInputFixture, ...]:
    """Generate one deterministic shared sequence outside timed regions."""

    step_actions = [
        [0.05 + 0.01 * index, -0.02 + 0.01 * index]
        for index in range(max(item_count - 1, 0))
    ]
    environment_spec = None
    if specification is not None:
        supplied = copy.deepcopy(dict(specification))
        expected_fields = {
            "version",
            "generation_seed",
            "sequence_length",
            "step_actions",
            "environment",
            "expected_fixture_digest",
        }
        if set(supplied) != expected_fields:
            raise ValueError("MPC fixture sequence specification is malformed")
        if supplied["version"] != MPC_FIXTURE_SEQUENCE_VERSION:
            raise ValueError("MPC fixture sequence version is unsupported")
        item_count = supplied["sequence_length"]
        seed = supplied["generation_seed"]
        step_actions = supplied["step_actions"]
        environment_spec = supplied["environment"]
    if type(item_count) is not int or item_count <= 0:
        raise ValueError("item_count must be a positive integer")
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    if (
        type(step_actions) is not list
        or len(step_actions) != item_count - 1
        or any(
            type(action) is not list
            or len(action) != 2
            or any(type(value) not in (int, float) for value in action)
            for action in step_actions
        )
    ):
        raise ValueError("MPC fixture step actions are malformed")
    environment = _make_teaching_environment(environment_spec)
    try:
        observation, info = environment.reset(seed=seed)
        fixtures: list[MPCInputFixture] = []
        for index in range(item_count):
            model_action = environment.car.current_model_action
            drive_command = model_action["normalized_drive_command"]
            steering_rate = model_action[
                "physical_front_wheel_angle_rate_rad_per_s"
            ]
            fixtures.append(
                MPCInputFixture(
                    observation=observation,
                    info=info,
                    terminated=False,
                    truncated=False,
                    drive_command=float(drive_command),
                    steering_rate=float(steering_rate),
                    steering_angle=float(
                        environment.car.state[
                            "front_wheel_steering_angle_rad"
                        ]
                    ),
                )
            )
            if index + 1 < item_count:
                action = np.array(step_actions[index], dtype=np.float32)
                observation, _, terminated, truncated, info = (
                    environment.step(action)
                )
                if terminated or truncated:
                    raise RuntimeError(
                        "deterministic MPC fixture rollout ended early"
                    )
        return tuple(fixtures)
    finally:
        environment.close()


def _default_policy_factory(environment, case: CaseSpec):
    from dreamgym.policies.autonomous_driving.mpc import (
        AutonomousDrivingDirectSteeringMPCPolicy,
        AutonomousDrivingSteeringRateMPCPolicy,
    )

    config = build_mpc_policy_config(case)
    policy_name = _mpc_semantics(case)["policy"]
    if policy_name == "direct_steering":
        return AutonomousDrivingDirectSteeringMPCPolicy.from_env(
            environment,
            config,
        )
    if policy_name == "steering_rate":
        return AutonomousDrivingSteeringRateMPCPolicy.from_env(
            environment,
            config,
        )
    if policy_name == "road_aware_direct_steering":
        from dreamgym.policies.autonomous_driving.road_aware_mpc import (
            AutonomousDrivingRoadAwareDirectSteeringMPCPolicy,
        )

        return AutonomousDrivingRoadAwareDirectSteeringMPCPolicy.from_env(
            environment,
            config,
        )
    if policy_name == "road_aware_steering_rate":
        from dreamgym.policies.autonomous_driving.road_aware_mpc import (
            AutonomousDrivingRoadAwareSteeringRateMPCPolicy,
        )

        return AutonomousDrivingRoadAwareSteeringRateMPCPolicy.from_env(
            environment,
            config,
        )
    raise ValueError("unsupported MPC policy family")


def _execution_counts(execution: ExecutionSpec) -> tuple[int, int, int]:
    if not isinstance(execution, ExecutionSpec):
        raise TypeError("execution must be an ExecutionSpec")
    document = execution.execution_document
    values = (
        document.get("warmup_iterations", 0),
        document.get("sample_count", 1),
        document.get("repetitions", 1),
    )
    for name, value, minimum in zip(
        ("warmup_iterations", "sample_count", "repetitions"),
        values,
        (0, 1, 1),
        strict=True,
    ):
        if type(value) is not int or value < minimum:
            qualifier = "non-negative" if minimum == 0 else "positive"
            raise ValueError(name + " must be a " + qualifier + " integer")
    return values


def _tick(clock_ns: Callable[[], int]) -> int:
    value = clock_ns()
    if type(value) is not int or value < 0:
        raise ValueError("clock_ns must produce non-negative integer ticks")
    return value


def _seconds_to_ns(name: str, value: object) -> int:
    seconds = _finite_float(name, value)
    if seconds < 0.0:
        raise ValueError(name + " must be nonnegative")
    return int(round(seconds * 1_000_000_000.0))


def _enum_value(value: object) -> object:
    return getattr(value, "value", value)


def _invocation_record(
    *,
    phase: str,
    index: int,
    fixture_index: int,
    fixture_digest: str,
    policy_result: object | None,
    policy_wall_time_ns: int | None,
    error: BaseException | None,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "phase": phase,
        "index": index,
        "fixture_index": fixture_index,
        "fixture_digest": fixture_digest,
        "policy_wall_time_ns": policy_wall_time_ns,
        "policy_total_time_seconds": None,
        "road_horizon_time_seconds": None,
        "model_schedule_time_seconds": None,
        "policy_postprocessing_time_seconds": None,
        "outer_policy_time_seconds": None,
        "solver_status": None,
        "solver_status_code": None,
        "solver_usable": False,
        "solver_iterations": None,
        "solver_primal_residual": None,
        "solver_dual_residual": None,
        "formulation_time_seconds": None,
        "backend_setup_time_seconds": None,
        "backend_solve_time_seconds": None,
        "backend_run_time_seconds": None,
        "solver_postprocessing_time_seconds": None,
        "complete_solver_time_seconds": None,
        "complete_solver_time_ns": None,
        "decision_variable_count": None,
        "constraint_row_count": None,
        "hessian_nonzero_count": None,
        "constraint_matrix_nonzero_count": None,
        "fallback_mode": None,
        "fallback_action_used": False,
        "policy_failure": None,
        "exclusion_reason": None,
    }
    if error is not None:
        try:
            detail = str(error) or type(error).__name__
        except BaseException:
            detail = type(error).__name__
        record["exclusion_reason"] = sanitize_diagnostic_message(
            "invocation raised " + type(error).__name__ + ": " + detail
        )
        return record
    if policy_result is None:
        record["exclusion_reason"] = "policy returned no result"
        return record

    for name in (
        "total_time_seconds",
        "road_horizon_time_seconds",
        "model_schedule_time_seconds",
        "postprocessing_time_seconds",
    ):
        value = getattr(policy_result, name, None)
        if value is not None:
            _finite_float(name, value)
    policy_total = getattr(policy_result, "total_time_seconds", None)
    road_horizon = getattr(policy_result, "road_horizon_time_seconds", None)
    scheduling = getattr(policy_result, "model_schedule_time_seconds", None)
    postprocessing = getattr(
        policy_result,
        "postprocessing_time_seconds",
        None,
    )
    record["policy_total_time_seconds"] = policy_total
    record["road_horizon_time_seconds"] = road_horizon
    record["model_schedule_time_seconds"] = scheduling
    record["policy_postprocessing_time_seconds"] = postprocessing
    solve_result = getattr(policy_result, "solve_result", None)
    failure = getattr(policy_result, "failure", None)
    if failure is not None:
        failure_message = failure.message
        if isinstance(failure_message, str):
            failure_message = str(failure_message)
            if failure_message:
                failure_message = sanitize_diagnostic_message(failure_message)
        record["policy_failure"] = {
            "stage": _enum_value(failure.stage),
            "reason": failure.reason,
            "field_name": failure.field_name,
            "message": failure_message,
        }
    fallback = bool(getattr(policy_result, "fallback_action_used", False))
    record["fallback_action_used"] = fallback
    record["fallback_mode"] = _enum_value(
        getattr(policy_result, "fallback_mode", None)
    )
    if solve_result is None:
        record["exclusion_reason"] = "policy did not reach a solver result"
        return record
    diagnostics = solve_result.diagnostics
    record.update(
        {
            "solver_status": solve_result.status,
            "solver_status_code": solve_result.status_code,
            "solver_usable": solve_result.usable,
            "solver_iterations": diagnostics.iterations,
            "solver_primal_residual": diagnostics.primal_residual,
            "solver_dual_residual": diagnostics.dual_residual,
            "formulation_time_seconds": (
                diagnostics.formulation_time_seconds
            ),
            "backend_setup_time_seconds": diagnostics.setup_time_seconds,
            "backend_solve_time_seconds": diagnostics.solve_time_seconds,
            "backend_run_time_seconds": diagnostics.run_time_seconds,
            "solver_postprocessing_time_seconds": (
                diagnostics.postprocessing_time_seconds
            ),
            "complete_solver_time_seconds": diagnostics.total_time_seconds,
            "complete_solver_time_ns": _seconds_to_ns(
                "total_time_seconds",
                diagnostics.total_time_seconds,
            ),
        }
    )
    for field_name in _STRUCTURAL_FIELDS:
        value = getattr(diagnostics, field_name)
        record[field_name] = value
        if type(value) is not int or value < 0:
            record["exclusion_reason"] = (
                "required solver structural count is missing: "
                + field_name
            )
            return record
    if policy_total is not None:
        record["outer_policy_time_seconds"] = max(
            0.0,
            float(policy_total) - diagnostics.total_time_seconds,
        )
    if not solve_result.usable:
        record["exclusion_reason"] = (
            "solver result is not usable: " + solve_result.status
        )
    elif fallback:
        record["exclusion_reason"] = "fallback action was activated"
    return record


def _invoke_controlled(
    *,
    case: CaseSpec,
    fixture: MPCInputFixture,
    fixture_index: int,
    fixture_digest: str,
    phase: str,
    index: int,
    policy_factory: Callable[[CaseSpec], object],
    clock_ns: Callable[[], int],
) -> tuple[dict[str, Any], bool]:
    try:
        policy = policy_factory(case)
        policy.reset(seed=0)
        policy.record_applied_action(
            drive_command=fixture.drive_command,
            steering_rate=fixture.steering_rate,
            steering_angle=fixture.steering_angle,
        )
        timed = phase != "warmup"
        started = _tick(clock_ns) if timed else None
        policy_result = policy.compute_action_result(
            _fixture_call_value(fixture.observation),
            _fixture_call_value(fixture.info),
            fixture.terminated,
            fixture.truncated,
        )
        if timed:
            assert started is not None
            elapsed = _tick(clock_ns) - started
            if elapsed < 0:
                raise ValueError(
                    "clock_ns must produce non-decreasing integer ticks"
                )
        else:
            elapsed = None
    except Exception as error:
        return (
            _invocation_record(
                phase=phase,
                index=index,
                fixture_index=fixture_index,
                fixture_digest=fixture_digest,
                policy_result=None,
                policy_wall_time_ns=None,
                error=error,
            ),
            True,
        )
    return (
        _invocation_record(
            phase=phase,
            index=index,
            fixture_index=fixture_index,
            fixture_digest=fixture_digest,
            policy_result=policy_result,
            policy_wall_time_ns=elapsed,
            error=None,
        ),
        False,
    )


def _summary_without_samples(samples: Sequence[int]) -> dict[str, Any]:
    summary = summarize_sample_ns(samples)
    return {
        key: value
        for key, value in summary.items()
        if key not in {"samples_ns", "sample_unit"}
    }


def execute_mpc_case(
    case: CaseSpec,
    execution: ExecutionSpec,
    fixtures: Sequence[MPCInputFixture] | None = None,
    *,
    policy_factory: Callable[[CaseSpec], object] | None = None,
    preflight: Callable[[], None] | None = None,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
    emit: Callable[[ProgressEvent], None] | None = None,
) -> CaseResult:
    """Execute one controlled case without a policy-driven closed loop."""

    _mpc_semantics(case)
    if not isinstance(execution, ExecutionSpec):
        raise TypeError("execution must be an ExecutionSpec")
    if execution.semantic_case_id != case.semantic_case_id:
        raise ValueError("execution does not belong to case")
    warmup_count, sample_count, repetitions = _execution_counts(execution)
    fixture_spec = case.to_dict()["semantic_document"]["mpc"].get(
        "fixture_sequence"
    )
    environment = None
    if fixtures is None:
        fixtures = prepare_mpc_fixture_sequence(
            specification=fixture_spec
            if isinstance(fixture_spec, Mapping)
            else None,
        )
    fixed_inputs = _validated_fixture_sequence(fixtures)
    digest = fixture_sequence_digest(fixed_inputs)
    if (
        isinstance(fixture_spec, Mapping)
        and digest != fixture_spec.get("expected_fixture_digest")
    ):
        raise ValueError(
            "realized MPC fixture sequence does not match semantic identity"
        )
    if policy_factory is None:
        environment = _make_teaching_environment(
            fixture_spec["environment"]
            if isinstance(fixture_spec, Mapping)
            else None
        )

        def policy_factory(active_case: CaseSpec) -> object:
            return _default_policy_factory(environment, active_case)

    if preflight is None:
        preflight = lambda: importlib.import_module("osqp")

    records: list[dict[str, Any]] = []
    source_sanitized_exclusions: list[dict[str, Any]] = []
    try:
        preflight()
        total_index = 0

        def invoke(phase: str, phase_index: int) -> dict[str, Any]:
            nonlocal total_index
            fixture_index = total_index % len(fixed_inputs)
            record, source_sanitized = _invoke_controlled(
                case=case,
                fixture=fixed_inputs[fixture_index],
                fixture_index=fixture_index,
                fixture_digest=digest,
                phase=phase,
                index=phase_index,
                policy_factory=policy_factory,
                clock_ns=clock_ns,
            )
            total_index += 1
            records.append(record)
            if source_sanitized and record["exclusion_reason"] is not None:
                source_sanitized_exclusions.append(record)
            return record

        cold = invoke("cold", 0)
        warmups: list[dict[str, Any]] = []
        measured: list[dict[str, Any]] = []
        if cold["exclusion_reason"] is None:
            for index in range(warmup_count * repetitions):
                warmup = invoke("warmup", index)
                warmups.append(warmup)
                if warmup["exclusion_reason"] is not None:
                    break
        if (
            cold["exclusion_reason"] is None
            and all(
                record["exclusion_reason"] is None
                for record in warmups
            )
        ):
            if emit is not None:
                emit(
                    ProgressEvent(
                        case.semantic_case_id,
                        "milestone",
                        0,
                        sample_count * repetitions,
                    )
                )
            for index in range(sample_count * repetitions):
                sample = invoke("measured", index)
                measured.append(sample)
                if sample["exclusion_reason"] is not None:
                    break
    finally:
        if environment is not None:
            environment.close()

    excluded = next(
        (
            record
            for record in records
            if record["exclusion_reason"] is not None
        ),
        None,
    )
    inaccurate_count = sum(
        record["solver_status"] == "solved inaccurate"
        for record in records
    )
    metrics: dict[str, Any] = {
        "fixture_digest": digest,
        "fixture_count": len(fixed_inputs),
        "controlled_shared_input": True,
        "policy_driven_closed_loop": False,
        "cold": cold,
        "warmup_invocations": warmups,
        "measured_invocations": measured,
        "invocations": records,
        "solved_inaccurate_count": inaccurate_count,
        "backend_timing_semantics": "optional_non_additive",
        "cold_complete_solver_time_seconds": cold[
            "complete_solver_time_seconds"
        ],
        "cold_policy_total_time_seconds": cold[
            "policy_total_time_seconds"
        ],
        "complete_solver_time": None,
        "policy_total_time": None,
        "warmed_complete_solver_time": None,
        "warmed_policy_total_time": None,
        "warmed_policy_wall_time": None,
        "post_warmup_median_complete_solver_time_seconds": None,
        "headline": None,
        "failure_reason": (
            None if excluded is None else excluded["exclusion_reason"]
        ),
    }
    if excluded is not None:
        if any(
            record is excluded for record in source_sanitized_exclusions
        ):
            diagnostic = validate_case_diagnostic(
                {
                    "stage": "measurement_validation",
                    "exception_type": "CaseMeasurementError",
                    "message": excluded["exclusion_reason"],
                    "source_locations": [],
                }
            )
        else:
            diagnostic = case_measurement_diagnostic(
                "measurement_validation",
                excluded["exclusion_reason"],
            )
        return CaseResult(
            case_id=case.semantic_case_id,
            execution_spec_digest=execution.execution_spec_digest,
            status="failed",
            sample_ns=(),
            metrics=metrics,
            errors=(diagnostic,),
        )
    solver_samples = [
        record["complete_solver_time_ns"] for record in measured
    ]
    policy_sample_seconds = [
        record["policy_total_time_seconds"]
        for record in measured
    ]
    policy_wall_samples = [
        record["policy_wall_time_ns"] for record in measured
    ]
    if (
        len(solver_samples) != sample_count * repetitions
        or any(type(value) is not int for value in solver_samples)
        or any(
            isinstance(value, bool)
            or not isinstance(value, Real)
            or not math.isfinite(float(value))
            for value in policy_sample_seconds
        )
        or any(type(value) is not int for value in policy_wall_samples)
    ):
        metrics["failure_reason"] = "required measured invocations are missing"
        return CaseResult(
            case_id=case.semantic_case_id,
            execution_spec_digest=execution.execution_spec_digest,
            status="failed",
            sample_ns=(),
            metrics=metrics,
            errors=(
                case_measurement_diagnostic(
                    "measurement_validation",
                    metrics["failure_reason"],
                ),
            ),
        )
    policy_samples = [
        _seconds_to_ns(
            "policy_total_time_seconds",
            value,
        )
        for value in policy_sample_seconds
    ]
    solver_summary = _summary_without_samples(solver_samples)
    metrics["complete_solver_time"] = solver_summary
    metrics["policy_total_time"] = _summary_without_samples(policy_samples)
    metrics["warmed_complete_solver_time"] = solver_summary
    metrics["warmed_policy_total_time"] = metrics["policy_total_time"]
    metrics["warmed_policy_wall_time"] = _summary_without_samples(
        policy_wall_samples
    )
    metrics["post_warmup_median_complete_solver_time_seconds"] = (
        float(solver_summary["median_ns"]) / 1_000_000_000.0
    )
    metrics["headline"] = {
        "metric": "post_warmup_median_complete_solver_time",
        "median_complete_solver_time_ns": solver_summary["median_ns"],
        "unit": "ns/solve",
    }
    return CaseResult(
        case_id=case.semantic_case_id,
        execution_spec_digest=execution.execution_spec_digest,
        status="completed",
        sample_ns=solver_samples,
        metrics=metrics,
    )


def execute_mpc_closed_loop_compatibility(
    *,
    step_count: int = 3,
    policy_families: Sequence[str] = _CANONICAL_POLICIES,
) -> tuple[dict[str, Any], ...]:
    """Run a short public Gym lifecycle smoke outside controlled timing."""

    if type(step_count) is not int or step_count <= 0:
        raise ValueError("step_count must be a positive integer")
    families = tuple(policy_families)
    if not families or any(
        family not in _CANONICAL_POLICIES for family in families
    ):
        raise ValueError("policy_families contains an unsupported family")
    cases = build_mpc_case_specs()
    baseline_cases = {
        case.semantic_document["mpc"]["policy"]: case
        for case in cases
        if case.semantic_document["mpc"]["prediction_horizon_steps"] == 20
        and case.semantic_document["mpc"]["soft_constraints"] == "on"
    }
    outcomes: list[dict[str, Any]] = []
    for family in families:
        environment = _make_teaching_environment()
        statuses: list[str] = []
        try:
            policy = _default_policy_factory(
                environment,
                baseline_cases[family],
            )
            observation, info = environment.reset(seed=0)
            policy.reset(seed=0)
            for _ in range(step_count):
                result = policy.compute_action_result(
                    observation,
                    info,
                    False,
                    False,
                )
                statuses.append(result.solve_status or "pre_solver_failure")
                action = result.environment_action
                if action is None:
                    raise RuntimeError(
                        "closed-loop MPC smoke produced no action"
                    )
                observation, _, terminated, truncated, info = (
                    environment.step(action)
                )
                model_action = environment.car.current_model_action
                drive_command = model_action["normalized_drive_command"]
                steering_rate = model_action[
                    "physical_front_wheel_angle_rate_rad_per_s"
                ]
                policy.record_applied_action(
                    drive_command=float(drive_command),
                    steering_rate=float(steering_rate),
                    steering_angle=float(
                        environment.car.state[
                            "front_wheel_steering_angle_rad"
                        ]
                    ),
                )
                if terminated or truncated:
                    break
            outcomes.append(
                {
                    "policy": family,
                    "status": "completed",
                    "completed_steps": len(statuses),
                    "solver_statuses": statuses,
                    "controlled_timing_samples_included": False,
                }
            )
        except Exception as error:
            try:
                detail = str(error) or type(error).__name__
            except BaseException:
                detail = type(error).__name__
            outcomes.append(
                {
                    "policy": family,
                    "status": "failed",
                    "completed_steps": len(statuses),
                    "solver_statuses": statuses,
                    "controlled_timing_samples_included": False,
                    "failure_reason": sanitize_diagnostic_message(
                        type(error).__name__ + ": " + detail
                    ),
                }
            )
        finally:
            environment.close()
    return tuple(outcomes)


def select_mpc_submission_values(
    results: Sequence[CaseResult],
) -> tuple[dict[str, Any], ...]:
    """Project the locked steering-rate h20/h80 medians to ms per solve."""

    if isinstance(results, (str, bytes)):
        raise TypeError("results must be a sequence of CaseResult")
    release_source = _resolve_mpc_submission_release()
    release_workload = release_source.workload
    by_case_id: dict[str, CaseResult] = {}
    for result in results:
        if not isinstance(result, CaseResult):
            raise TypeError("results must contain CaseResult records")
        if result.schema_version != release_source.result_schema_version:
            raise ValueError(
                "MPC submission result schema is not release-approved"
            )
        by_case_id[result.case_id] = result
    selected: list[dict[str, Any]] = []
    locked_pairs = tuple(
        (case, execution)
        for case, execution in release_workload.workload.cases
        if case.semantic_document.get("suite") == "mpc"
    )
    for case, execution in locked_pairs:
        result = by_case_id.get(case.semantic_case_id)
        if (
            result is None
            or result.status != "completed"
            or result.execution_spec_digest
            != execution.execution_spec_digest
        ):
            raise ValueError(
                "a completed locked MPC submission result is missing"
            )
        required_sample_count = (
            execution.execution_document["sample_count"]
            * execution.execution_document["repetitions"]
        )
        if len(result.sample_ns) != required_sample_count:
            raise ValueError(
                "locked MPC submission result has the wrong sample count"
            )
        headline = result.metrics.get("headline")
        if (
            not isinstance(headline, Mapping)
            or headline.get("metric")
            != "post_warmup_median_complete_solver_time"
            or headline.get("unit") != "ns/solve"
        ):
            raise ValueError("MPC submission result has no numeric headline")
        median_ns = headline.get("median_complete_solver_time_ns")
        if (
            isinstance(median_ns, bool)
            or not isinstance(median_ns, Real)
            or not math.isfinite(float(median_ns))
            or float(median_ns) < 0.0
        ):
            raise ValueError("MPC submission result has no numeric headline")
        if (
            not result.sample_ns
            or float(median_ns) != float(median(result.sample_ns))
        ):
            raise ValueError(
                "MPC submission headline does not match warmed raw samples"
            )
        semantics = case.semantic_document["mpc"]
        selected.append(
            {
                "case_id": case.semantic_case_id,
                "policy": "steering_rate",
                "prediction_horizon_steps": semantics[
                    "prediction_horizon_steps"
                ],
                "soft_constraints": "on",
                "metric": (
                    "post_warmup_median_complete_solver_time"
                ),
                "value": float(median_ns) / 1_000_000.0,
                "unit": "ms/solve",
            }
        )
    return tuple(selected)
