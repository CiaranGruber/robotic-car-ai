"""Generic parent-process orchestration for unified profiling workloads.

Executors own only their measured operation.  This runner resolves workload
identity, validates the durable bundle contract, handles progress and commits
completed case transactions outside executor-owned timing intervals.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
import importlib
import importlib.util
import itertools
import math
from pathlib import Path
import shutil
from statistics import median
import sys
import time
from typing import Any, TextIO
import uuid

import numpy as np

from dreamgym.profiling.autonomous_driving.bundle import (
    BundleCompatibilityError,
    BundleIntegrityError,
    BundleWriter,
    STRUCTURED_RECORDS_SCHEMA_VERSION,
    _has_reparse_point,
    _validate_rl_resume_snapshot,
    import_compatible_case,
    load_bundle,
)
from dreamgym.profiling.autonomous_driving.metadata import (
    collect_metadata,
    validate_metadata_record,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    case_diagnostic_from_exception,
    case_measurement_diagnostic,
    is_controlled_diagnostic_stage,
    sanitize_case_warning,
    validate_case_warning,
)
from dreamgym.profiling.autonomous_driving.records import (
    CaseResult,
    CaseSpec,
    ExecutionSpec,
    PROFILE_RESULTS_SCHEMA_VERSION,
    ProgressEvent,
    exception_class_identity,
    execution_instance_id,
)
from dreamgym.profiling.autonomous_driving.workloads import (
    PROFILING_V3_NOT_RELEASED_MESSAGE,
    ProfileRequest,
    ResolvedProfileWorkload,
    WORKLOAD_VERSION,
    resolve_profile_request,
)
from dreamgym.training.autonomous_driving.config_validation import thaw_json


Executor = Callable[[CaseSpec, ExecutionSpec], CaseResult]
ProgressSink = Callable[[ProgressEvent], None]
Preflight = Callable[[ResolvedProfileWorkload, Mapping[str, Any], Path, str | Path | None], None]
Renderer = Callable[["ProfileRunResult", BundleWriter], object]

_STATUS_EXIT_CODES = {
    "successful": 0,
    "incomplete": 2,
    "interrupted": 130,
    "failed": 1,
}
_CASE_SEMANTIC_PROJECTION_VERSION = (
    "dreamgym-case-record-semantic-projection-v1"
)
_SUITE_DEPENDENCIES = {
    "rl": ("stable_baselines3",),
    "mpc": ("scipy", "osqp"),
}
_SUITE_EXTRAS = {"rl": "rl", "mpc": "mpc"}


@dataclass(frozen=True)
class ProfileRunResult:
    """Parent-owned durable state returned by :func:`run_profile`."""

    status: str
    output: Path
    case_results: tuple[CaseResult, ...]
    warnings: tuple[str, ...] = ()
    estimated_remaining_seconds: float = 0.0

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "warnings",
            tuple(validate_case_warning(value) for value in self.warnings),
        )

    @property
    def exit_code(self) -> int:
        return exit_code_for_status(self.status)


@dataclass
class _RunInterruptState:
    """Mutable durable-lifecycle state visible to the outer interrupt boundary."""

    output: Path
    writer: BundleWriter | None = None
    run_attempt_id: str | None = None
    case_results: list[CaseResult] | None = None
    warnings: list[str] | None = None
    estimated_remaining_seconds: float = 0.0


@dataclass(frozen=True)
class CaseImportPlan:
    """One immutable source measurement satisfying a destination case."""

    source_bundle: Path
    source_execution_instance_id: str
    destination_semantic_case_id: str
    destination_execution_spec_digest: str
    reuse_authority: Mapping[str, Any] | None = None


def exit_code_for_status(status: str) -> int:
    """Map terminal run state to the stable command-line contract."""

    try:
        return _STATUS_EXIT_CODES[status]
    except KeyError as error:
        raise ValueError("unsupported profiling status") from error


def missing_extra_guidance(suites: Sequence[str]) -> str:
    """Return the exact, narrow installation guidance for unavailable suites."""

    missing = {suite for suite in suites if suite in _SUITE_EXTRAS}
    extras = {_SUITE_EXTRAS[suite] for suite in missing}
    if extras == {"rl", "mpc"}:
        return 'python -m pip install -e ".[rl,mpc]"'
    if extras == {"rl"}:
        return 'python -m pip install -e ".[rl]"'
    if extras == {"mpc"}:
        return 'python -m pip install -e ".[mpc]"'
    return ""


def _missing_suite_dependencies(suites: Sequence[str]) -> tuple[str, ...]:
    """Return missing runtime modules without importing optional suites."""

    missing = []
    for suite in suites:
        for dependency in _SUITE_DEPENDENCIES.get(suite, ()):
            if importlib.util.find_spec(dependency) is None:
                missing.append(dependency)
    return tuple(missing)


def _suite(
    resolved: ResolvedProfileWorkload,
    case: CaseSpec,
    execution: ExecutionSpec,
) -> str:
    return resolved.suite_for(case, execution)


def _workload_manifest(resolved: ResolvedProfileWorkload) -> dict[str, Any]:
    return {
        "workload_version": resolved.workload.workload_version,
        "workload_digest": resolved.workload.workload_digest,
        "release_identity": {
            "workload_release_id": resolved.workload_release_id,
            "result_schema_release_id": resolved.result_schema_release_id,
            "timing_protocol_release_id": (
                resolved.timing_protocol_release_id
            ),
        },
        "release_status": {
            "classification": resolved.classification,
            "canonical_status": resolved.canonical_status,
            "submission_status": resolved.submission_status,
        },
    }


def _validate_preflight(
    resolved: ResolvedProfileWorkload,
    metadata: Mapping[str, Any],
    destination: Path,
    resume: str | Path | None,
    available_suites: Sequence[str],
    *,
    check_dependencies: bool,
    allow_provisional_auto_metadata: bool,
) -> None:
    """Validate all non-measured prerequisites before any executor starts."""

    validate_metadata_record(metadata)
    if resolved.workload.schema_version != PROFILE_RESULTS_SCHEMA_VERSION:
        raise ValueError("unsupported workload result schema version")
    required_suites: set[str] = set()
    for case, execution in resolved.workload.cases:
        if case.schema_version != PROFILE_RESULTS_SCHEMA_VERSION or execution.schema_version != PROFILE_RESULTS_SCHEMA_VERSION:
            raise ValueError("case result schema version is unsupported")
        if not case.timing_protocol.get("version") or not execution.execution_document.get("execution_spec_version"):
            raise ValueError("case timing or execution version is missing")
        required_suites.add(_suite(resolved, case, execution))
    unavailable = sorted(
        suite for suite in required_suites if suite not in available_suites
    )
    if unavailable:
        guidance = missing_extra_guidance(unavailable)
        message = "no executor is registered for " + ", ".join(unavailable)
        if guidance:
            message += "; install with " + guidance
        raise ValueError(message)
    missing_dependencies = (
        _missing_suite_dependencies(sorted(required_suites))
        if check_dependencies
        else ()
    )
    if missing_dependencies:
        missing_suites = tuple(
            suite
            for suite in sorted(required_suites)
            if any(
                dependency in missing_dependencies
                for dependency in _SUITE_DEPENDENCIES.get(suite, ())
            )
        )
        raise ValueError(
            "missing optional dependency; install with "
            + missing_extra_guidance(missing_suites)
        )
    _validate_metadata_rl_device_declaration(
        resolved,
        metadata,
        allow_provisional_auto=allow_provisional_auto_metadata,
    )
    if destination.exists() and not destination.is_dir():
        raise ValueError("output destination must be a directory")
    if resume is not None:
        source = Path(resume)
        if source != destination:
            raise BundleCompatibilityError("resume destination must equal the existing bundle")
        document = load_bundle(source)
        if document["manifest"]["workload"] != _workload_manifest(resolved):
            raise BundleCompatibilityError("resume workload is incompatible")
        current_attempt_id = document["manifest"].get(
            "current_run_attempt_id"
        )
        if current_attempt_id is not None:
            current_attempt = document["manifest"]["run_attempts"][
                current_attempt_id
            ]
            if current_attempt["status"] == "successful":
                raise BundleCompatibilityError(
                    "successful bundles cannot be resumed"
                )
            if (
                current_attempt["status"] == "failed"
                and current_attempt["fatal"]
            ):
                raise BundleCompatibilityError(
                    "fatal failed bundles cannot be resumed"
                )
        statuses = []
        for case, execution in resolved.workload.cases:
            instance_id = execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            )
            stored_case = document["manifest"]["cases"].get(
                instance_id
            )
            stored_result = document["results"]["cases"].get(
                instance_id
            )
            if stored_case is None:
                continue
            expected = _case_record(
                case,
                execution,
                resolved.classification,
                reusable=_case_is_reusable(
                    resolved,
                    case,
                    execution,
                    metadata,
                ),
            )
            for field in (
                "semantic_case_id",
                "semantic_case_digest",
                "execution_spec_digest",
                "timing_protocol_digest",
                "result_schema_version",
                "benchmark_release",
                "semantic_projection_digest",
            ):
                if stored_case[field] != expected[field]:
                    raise BundleCompatibilityError(
                        "resume mismatch: " + field
                    )
            if stored_case.get(
                "semantic_projection_version"
            ) != _case_projection_version(case):
                raise BundleCompatibilityError(
                    "resume mismatch: semantic_projection_version"
                )
            if _suite(resolved, case, execution) == "rl":
                destination_requested_config_digest = None
                if (
                    stored_case.get("snapshot") is not None
                    and stored_case.get("imported_from") is None
                ):
                    destination_requested_config_digest = (
                        resolved.rl_binding_for(
                            case,
                            execution,
                        ).requested_config_digest
                    )
                _validate_rl_resume_snapshot(
                    stored_case,
                    stored_result,
                    destination_requested_config_digest=(
                        destination_requested_config_digest
                    ),
                )
            status = stored_result["status"]
            statuses.append(status)
            if status == "failed" and stored_result["fatal"]:
                raise BundleCompatibilityError(
                    "fatal failed bundles cannot be resumed"
                )
            if status not in {"completed", "failed", "interrupted"}:
                raise BundleCompatibilityError(
                    "bundle contains a non-resumable case status"
                )
        if (
            current_attempt_id is None
            and len(statuses) == len(resolved.workload.cases)
            and all(status == "completed" for status in statuses)
        ):
            raise BundleCompatibilityError(
                "completed bundles cannot be resumed"
            )


def _case_is_reusable(
    resolved: ResolvedProfileWorkload,
    case: CaseSpec,
    execution: ExecutionSpec,
    metadata: Mapping[str, Any],
) -> bool:
    """Resolve reuse eligibility without treating absent device facts as CPU."""

    if metadata["rl_device"]["requested"] == "auto":
        return False
    if _suite(resolved, case, execution) != "rl":
        return True
    algorithm = case.semantic_document.get("algorithm")
    device = (
        algorithm.get("device")
        if isinstance(algorithm, Mapping)
        else None
    )
    return not (
        isinstance(device, Mapping)
        and device.get("policy") == "auto"
    )


def _predeclared_rl_device(
    resolved: ResolvedProfileWorkload,
) -> tuple[str | None, str | None, str | None]:
    """Derive the bundle device declaration from timed RL semantics."""

    policies: set[str] = set()
    for case, execution in resolved.workload.cases:
        if _suite(resolved, case, execution) != "rl":
            continue
        algorithm = case.semantic_document.get("algorithm")
        device = (
            algorithm.get("device")
            if isinstance(algorithm, Mapping)
            else None
        )
        if not isinstance(device, Mapping):
            raise ValueError("RL semantic device declaration is missing")
        policy = device.get("policy")
        if policy == "auto":
            policies.add("auto")
        else:
            concrete = device.get("effective_constructor_device")
            if concrete not in {"cpu", "cuda"}:
                raise ValueError(
                    "RL semantic device declaration is not concrete"
                )
            policies.add(str(concrete))
    if not policies:
        return None, None, None
    if len(policies) != 1:
        raise ValueError(
            "one bundle cannot mix incompatible RL device policies"
        )
    policy = next(iter(policies))
    if policy == "auto":
        return None, None, None
    return policy, policy, policy


def _validate_metadata_rl_device_declaration(
    resolved: ResolvedProfileWorkload,
    metadata: Mapping[str, Any],
    *,
    allow_provisional_auto: bool,
) -> None:
    """Require metadata to agree with the workload's semantic RL device."""

    policies: set[str] = set()
    for case, execution in resolved.workload.cases:
        if _suite(resolved, case, execution) != "rl":
            continue
        algorithm = case.semantic_document.get("algorithm")
        device = (
            algorithm.get("device")
            if isinstance(algorithm, Mapping)
            else None
        )
        if not isinstance(device, Mapping):
            raise ValueError("RL semantic device declaration is missing")
        policy = device.get("policy")
        if policy == "auto":
            policies.add("auto")
        else:
            concrete = device.get("effective_constructor_device")
            if concrete not in {"cpu", "cuda"}:
                raise ValueError(
                    "RL semantic device declaration is not concrete"
                )
            policies.add(str(concrete))
    if len(policies) > 1:
        raise ValueError(
            "one bundle cannot mix incompatible RL device policies"
        )
    declared = next(iter(policies), None)
    recorded = metadata["rl_device"]
    all_null = all(recorded[field] is None for field in recorded)
    if declared is None:
        if not all_null:
            raise ValueError(
                "non-RL workloads require null RL device metadata"
            )
        return
    if declared == "auto" and all_null:
        if allow_provisional_auto:
            return
        raise ValueError(
            "supplied auto RL metadata must record a concrete observation"
        )
    if recorded["requested"] != declared:
        raise ValueError(
            "metadata RL device does not match the semantic declaration"
        )
    if declared == "cpu" and recorded != {
        "requested": "cpu",
        "resolved": "cpu",
        "observed": "cpu",
    }:
        raise ValueError(
            "canonical CPU semantics require an exact CPU metadata triple"
        )


def _case_record(
    case: CaseSpec,
    execution: ExecutionSpec,
    classification: str,
    *,
    reusable: bool,
    snapshot: Mapping[str, Any] | None = None,
    run_attempt_id: str | None = None,
    measurement_segment_id: str | None = None,
    live_session_fingerprint: str | None = None,
    timing_valid: bool | None = None,
) -> dict[str, Any]:
    if type(reusable) is not bool:
        raise TypeError("reusable must be a boolean")
    lifecycle_values = (
        run_attempt_id,
        measurement_segment_id,
        live_session_fingerprint,
    )
    if any(value is None for value in lifecycle_values) and not all(
        value is None for value in lifecycle_values
    ):
        raise ValueError(
            "run attempt, measurement segment, and live session must be paired"
        )
    semantic = case.to_dict()["semantic_document"]
    timing_protocol = case.to_dict()["timing_protocol"]
    execution_document = execution.to_dict()["execution_document"]
    record = {
        "case_id": execution_instance_id(
            case.semantic_case_id,
            execution.execution_spec_digest,
        ),
        "semantic_case_id": case.semantic_case_id,
        "semantic_case_digest": case.semantic_case_digest,
        "execution_spec_digest": execution.execution_spec_digest,
        "timing_protocol_digest": case.timing_protocol_digest,
        "result_schema_version": PROFILE_RESULTS_SCHEMA_VERSION,
        "benchmark_release": classification,
        "semantic_projection_digest": case.semantic_case_digest,
        "eligibility": {"semantic_reuse_import": reusable, "sample_aggregation": reusable},
        "fixed_seeds": _fixed_seed_projection(semantic),
    }
    if run_attempt_id is not None:
        suite = _semantic_suite(semantic)
        if type(suite) is not str or not suite:
            raise ValueError("semantic suite must be a non-empty string")
        projection_version = _case_projection_version(case)
        record.update(
            {
                "suite": suite,
                "category": case.readable_prefix,
                "semantic_projection_version": projection_version,
                "semantic_projection": semantic,
                "timing_protocol": timing_protocol,
                "execution_spec": execution_document,
                "fixture_identity": _fixture_identity(
                    case,
                    semantic,
                ),
                "required": bool(
                    execution_document.get("required", True)
                ),
                "timing_validity": {
                    "valid": bool(timing_valid),
                    "status": (
                        "valid" if timing_valid else "invalid"
                    ),
                },
                "run_attempt_id": run_attempt_id,
                "measurement_segment_id": measurement_segment_id,
                "live_session_fingerprint": live_session_fingerprint,
            }
        )
    if snapshot is not None:
        record["snapshot"] = dict(snapshot)
    return record


def _case_projection_version(case: CaseSpec) -> str:
    semantic = case.to_dict()["semantic_document"]
    version = semantic.get(
        "semantic_projection_version",
        _CASE_SEMANTIC_PROJECTION_VERSION,
    )
    if type(version) is not str or not version:
        raise ValueError(
            "semantic projection version must be a non-empty string"
        )
    return version


def _fixed_seed_projection(value: Mapping[str, Any]) -> dict[str, Any]:
    """Retain deterministic seed inputs without inventing a root seed."""

    seeds: dict[str, Any] = {}

    def visit(item: Any, path: tuple[str, ...]) -> None:
        if not isinstance(item, Mapping):
            return
        for key, child in item.items():
            name = str(key)
            child_path = (*path, name)
            if "seed" in name.lower():
                destination = name
                if destination in seeds and seeds[destination] != child:
                    destination = ".".join(child_path)
                seeds[destination] = thaw_json(child)
            elif isinstance(child, Mapping):
                visit(child, child_path)

    visit(value, ())
    return seeds


def _fixture_identity(
    case: CaseSpec,
    semantic: Mapping[str, Any],
) -> dict[str, Any]:
    suite = _semantic_suite(semantic)
    if suite == "core":
        core = semantic.get("core")
        if isinstance(core, Mapping) and isinstance(
            core.get("fixture"), Mapping
        ):
            return thaw_json(core["fixture"])
    if suite == "mpc":
        mpc = semantic.get("mpc")
        if isinstance(mpc, Mapping) and isinstance(
            mpc.get("fixture_sequence"), Mapping
        ):
            return thaw_json(mpc["fixture_sequence"])
    return {
        "fixture_kind": (
            "production_training" if suite == "rl" else "semantic_case"
        ),
        "semantic_case_digest": case.semantic_case_digest,
    }


def _semantic_suite(semantic: Mapping[str, Any]) -> str | None:
    suite = semantic.get("suite")
    if type(suite) is str and suite:
        return suite
    if {
        "algorithm",
        "vectorization",
        "environment",
        "training_seeds",
    } <= set(semantic):
        return "rl"
    return None


def _publish_staged_bundle(staging: Path, destination: Path) -> None:
    """Publish one complete bundle without replacing destination contents."""

    destination_present = (
        destination.exists()
        or destination.is_symlink()
        or _has_reparse_point(destination)
    )
    if destination_present:
        if (
            not destination.is_dir()
            or destination.is_symlink()
            or _has_reparse_point(destination)
        ):
            raise BundleIntegrityError(
                "bundle destination cannot be a link"
            )
        destination.rmdir()
    staging.replace(destination)


def _bundle_result(
    result: CaseResult,
    measurement_segment_id: str | int,
    *,
    fatal: bool = False,
) -> dict[str, Any]:
    if type(measurement_segment_id) is int:
        measurement_segment_id = (
            "segment-" + str(measurement_segment_id).zfill(4)
        )
    if type(measurement_segment_id) is not str:
        raise TypeError("measurement_segment_id must be a string")
    native_result = result.to_dict()
    native_metrics = native_result["metrics"]
    completed = native_metrics.get("actual_transitions", 0)
    if type(completed) is not int or completed < 0:
        completed = 0
    metrics = _portable_metrics(native_metrics, sample_count=len(result.sample_ns))
    return {
        "status": result.status,
        "fatal": fatal,
        "segment_id": measurement_segment_id,
        "actual_completed_transitions": completed,
        "metrics": metrics,
        "warnings": native_result["warnings"],
        "errors": native_result["errors"],
    }


def _structured_case_records(
    result: CaseResult,
    suite: str,
    measurement_segment_id: str,
) -> dict[str, Any] | None:
    """Retain suite evidence omitted from the numeric headline projection."""

    if result.status not in {"completed", "failed"}:
        return None
    metrics = result.to_dict()["metrics"]
    def owned(items: Any, path: str) -> list[dict[str, Any]]:
        if type(items) is not list:
            raise TypeError(path + " must be an array")
        detached: list[dict[str, Any]] = []
        for index, item in enumerate(items):
            if not isinstance(item, Mapping):
                raise TypeError(
                    path + "[" + str(index) + "] must be an object"
                )
            record = thaw_json(item)
            record["measurement_segment_id"] = measurement_segment_id
            detached.append(record)
        return detached

    if suite == "mpc":
        invocations = metrics.get("invocations")
        if result.status == "failed" and invocations is None:
            return None
        records = {
            "mpc_invocations": owned(
                invocations,
                "metrics.invocations",
            )
        }
        if result.status == "failed" and not records["mpc_invocations"]:
            return None
    elif suite == "rl":
        training = metrics.get("training")
        if result.status == "failed" and training is None:
            return None
        if not isinstance(training, Mapping):
            raise TypeError("metrics.training must be an object")
        partial = training.get("partial_final_window")
        if partial is None:
            detached_partial = None
        elif isinstance(partial, Mapping):
            detached_partial = thaw_json(partial)
            detached_partial[
                "measurement_segment_id"
            ] = measurement_segment_id
        else:
            raise TypeError(
                "metrics.training.partial_final_window "
                "must be an object or null"
            )
        records = {
            "rl_complete_windows": owned(
                training.get("complete_windows"),
                "metrics.training.complete_windows",
            ),
            "rl_partial_final_window": detached_partial,
        }
    else:
        return None
    return {
        "schema_version": STRUCTURED_RECORDS_SCHEMA_VERSION,
        "measurement_segment_id": measurement_segment_id,
        "records": records,
    }


def _metric_unit(path: tuple[str, ...]) -> str:
    name = path[-1].lower()
    if name.endswith("_ns"):
        return "ns"
    if "per_second" in name or name.endswith("_per_s"):
        return "1/s"
    if name.endswith("_seconds") or name.endswith("_s"):
        return "s"
    if (
        name.endswith("_count")
        or "transitions" in name
        or name.endswith("_steps")
        or name == "n_envs"
    ):
        return "count"
    return "value"


def _portable_metrics(
    metrics: Mapping[str, Any],
    *,
    sample_count: int,
) -> dict[str, dict[str, Any]]:
    """Project rich native suite diagnostics into portable numeric metrics."""

    if metrics and all(
        isinstance(metric, Mapping)
        and set(metric) == {"definition", "unit", "value"}
        and type(metric["definition"]) is str
        and type(metric["unit"]) is str
        and type(metric["value"]) in (int, float)
        for metric in metrics.values()
    ):
        return {name: dict(metric) for name, metric in metrics.items()}

    portable: dict[str, dict[str, Any]] = {}

    def visit(value: Any, path: tuple[str, ...]) -> None:
        if isinstance(value, Mapping):
            for name, item in value.items():
                visit(item, (*path, str(name)))
        elif type(value) in (int, float):
            name = ".".join(path)
            portable[name] = {
                "definition": "Native suite metric at metrics." + name + ".",
                "unit": _metric_unit(path),
                "value": value,
            }

    visit(metrics, ())
    if not portable and sample_count:
        portable["sample_count"] = {
            "definition": "Number of retained timing samples.",
            "unit": "count",
            "value": sample_count,
        }
    return portable


def _failure_result(
    case: CaseSpec,
    execution: ExecutionSpec,
    status: str,
    error: BaseException,
) -> CaseResult:
    stage = "case_execution"
    exception_type = None
    message = None
    if (
        exception_class_identity(error)[0]
        == "dreamgym.profiling.autonomous_driving.rl_worker"
    ):
        from dreamgym.profiling.autonomous_driving.rl_worker import (
            RLRemoteWorkerError,
        )

        if type(error) is RLRemoteWorkerError:
            if is_controlled_diagnostic_stage(error.stage):
                stage = error.stage
                exception_type = error.exception_type
                message = error.remote_message
            else:
                exception_type = "RLWorkerProtocolError"
                message = (
                    "remote worker diagnostic payload was invalid."
                )
    return CaseResult(
        case_id=case.semantic_case_id,
        execution_spec_digest=execution.execution_spec_digest,
        status=status,
        sample_ns=(),
        metrics={},
        errors=(
            case_diagnostic_from_exception(
                stage,
                error,
                exception_type=exception_type,
                message=message,
            ),
        ),
    )


def _stored_portable_metric(
    metrics: Mapping[str, Any],
    name: str,
    unit: str,
) -> int | float:
    record = metrics.get(name)
    expected_definition = (
        "Native suite metric at metrics." + name + "."
    )
    if (
        not isinstance(record, Mapping)
        or set(record) != {"definition", "unit", "value"}
        or record.get("definition") != expected_definition
        or record.get("unit") != unit
        or type(record.get("value")) not in (int, float)
        or not math.isfinite(float(record["value"]))
    ):
        raise ValueError("stored portable metric is incompatible: " + name)
    return record["value"]


def _stored_resolved_rl_snapshot(
    document: Mapping[str, Any],
    destination: Path,
    case_record: Mapping[str, Any],
) -> Mapping[str, Any]:
    reference = case_record.get("snapshot")
    if not isinstance(reference, Mapping):
        raise ValueError("stored RL result has no resolved snapshot")
    digest = reference.get("requested_config_digest")
    indexed = document["manifest"]["configurations"].get(digest)
    if indexed != reference or "resolved_config_path" not in reference:
        raise ValueError("stored RL snapshot reference is not exact")
    relative = Path(reference["resolved_config_path"])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("stored RL snapshot path is invalid")
    from dreamgym.training.autonomous_driving.snapshots import (
        load_snapshot_json,
    )

    snapshot = load_snapshot_json(destination / relative)
    if (
        snapshot.get("snapshot_type") != "resolved"
        or snapshot.get("requested_config_digest") != digest
    ):
        raise ValueError("stored RL resolved snapshot is incompatible")
    return snapshot


def _validate_stored_rl_snapshot_authority(
    case: CaseSpec,
    snapshot: Mapping[str, Any],
) -> tuple[str, int, str, str, str]:
    from dreamgym.profiling.autonomous_driving.production_rl import (
        compare_rl_projection_to_finalized_snapshot,
    )

    comparison = compare_rl_projection_to_finalized_snapshot(
        {
            "semantic_document": thaw_json(case.semantic_document),
            "timing_protocol_digest": case.timing_protocol_digest,
        },
        snapshot,
    )
    semantics = case.semantic_document
    algorithm = semantics.get("algorithm")
    vectorization = semantics.get("vectorization")
    if (
        not isinstance(algorithm, Mapping)
        or not isinstance(vectorization, Mapping)
    ):
        raise ValueError("stored RL semantic authority is invalid")
    cadence = algorithm.get("cadence")
    if (
        not isinstance(cadence, Mapping)
        or vectorization.get("kind") != "dummy"
        or type(vectorization.get("effective_n_envs")) is not int
    ):
        raise ValueError("stored RL semantic authority is invalid")
    algorithm_name = algorithm.get("name")
    n_envs = vectorization["effective_n_envs"]
    if (
        type(algorithm_name) is not str
        or not algorithm_name
        or type(comparison.get("requested_device_policy")) is not str
        or type(comparison.get("actual_device")) is not str
    ):
        raise ValueError("stored RL snapshot authority is invalid")
    family = cadence.get("family")
    if family not in {"on_policy", "off_policy"}:
        raise ValueError("stored RL cadence authority is invalid")
    return (
        algorithm_name,
        n_envs,
        comparison["requested_device_policy"],
        comparison["actual_device"],
        family,
    )


def _expected_stored_rl_transitions(
    case: CaseSpec,
    execution: ExecutionSpec,
    *,
    n_envs: int,
    cadence_family: str,
) -> tuple[int, int]:
    requested = execution.execution_document.get(
        "requested_total_environment_transitions"
    )
    cadence = case.semantic_document["algorithm"]["cadence"]
    if type(requested) is not int or requested <= 0:
        raise ValueError("stored RL transition request is invalid")
    if cadence_family == "on_policy":
        block = cadence.get("effective_rollout_transitions")
    else:
        block = n_envs
    if type(block) is not int or block <= 0:
        raise ValueError("stored RL transition cadence is invalid")
    actual = ((requested + block - 1) // block) * block
    return requested, actual


def _stored_submission_metrics(
    document: Mapping[str, Any],
    destination: Path,
    case_record: Mapping[str, Any],
    result_record: Mapping[str, Any],
    case: CaseSpec,
    execution: ExecutionSpec,
    samples: tuple[int, ...],
) -> Mapping[str, Any]:
    portable = result_record["metrics"]
    if case_record.get("benchmark_release") != "locked_submission":
        return portable
    suite = case.semantic_document.get("suite")
    if suite == "mpc":
        if result_record["actual_completed_transitions"] != 0:
            raise ValueError("stored MPC transition count is invalid")
        headline = _stored_portable_metric(
            portable,
            "headline.median_complete_solver_time_ns",
            "ns",
        )
        return {
            "headline": {
                "metric": (
                    "post_warmup_median_complete_solver_time"
                ),
                "median_complete_solver_time_ns": headline,
                "unit": "ns/solve",
            }
        }

    if not (
        isinstance(case.semantic_document.get("algorithm"), Mapping)
        and isinstance(
            case.semantic_document.get("vectorization"),
            Mapping,
        )
    ):
        return portable

    snapshot = _stored_resolved_rl_snapshot(
        document,
        destination,
        case_record,
    )
    algorithm, n_envs, requested_device, actual_device, family = (
        _validate_stored_rl_snapshot_authority(case, snapshot)
    )
    requested, expected_actual = _expected_stored_rl_transitions(
        case,
        execution,
        n_envs=n_envs,
        cadence_family=family,
    )
    stored_requested = _stored_portable_metric(
        portable,
        "requested_transitions",
        "count",
    )
    stored_actual = _stored_portable_metric(
        portable,
        "actual_transitions",
        "count",
    )
    stored_n_envs = _stored_portable_metric(
        portable,
        "vectorization.effective_n_envs",
        "value",
    )
    complete_windows = _stored_portable_metric(
        portable,
        "training.complete_window_count",
        "count",
    )
    required_windows = _stored_portable_metric(
        portable,
        "training.required_complete_window_count",
        "count",
    )
    median_rate = _stored_portable_metric(
        portable,
        "training.median_transitions_per_second",
        "1/s",
    )
    expected_required = execution.execution_document[
        "steady_state_windows"
    ]["required_complete_window_count"]
    if (
        type(stored_requested) is not int
        or stored_requested != requested
        or type(stored_actual) is not int
        or stored_actual != expected_actual
        or result_record["actual_completed_transitions"]
        != expected_actual
        or type(stored_n_envs) is not int
        or stored_n_envs != n_envs
        or type(complete_windows) is not int
        or type(required_windows) is not int
        or required_windows != expected_required
        or complete_windows < required_windows
        or complete_windows != len(samples)
        or any(sample <= 0 for sample in samples)
        or float(median_rate) <= 0.0
    ):
        raise ValueError("stored RL measurement authority is invalid")
    if family == "on_policy":
        rollout = case.semantic_document["algorithm"]["cadence"].get(
            "effective_rollout_transitions"
        )
        minimum = execution.execution_document[
            "steady_state_windows"
        ].get("minimum_transition_count")
        if (
            type(rollout) is not int
            or rollout <= 0
            or type(minimum) is not int
            or minimum <= 0
        ):
            raise ValueError("stored RL timing cadence is invalid")
        window_transitions = (
            (minimum + rollout - 1) // rollout
        ) * rollout
        rates = tuple(
            window_transitions * 1_000_000_000.0 / sample
            for sample in samples
        )
        if float(median_rate) != float(median(rates)):
            raise ValueError(
                "stored RL headline disagrees with raw samples"
            )
    return {
        "requested_transitions": requested,
        "actual_transitions": expected_actual,
        "training": {
            "canonical_window_requirement_met": True,
            "complete_window_count": complete_windows,
            "required_complete_window_count": required_windows,
            "median_transitions_per_second": median_rate,
        },
        "vectorization": {
            "kind": "dummy",
            "effective_n_envs": n_envs,
        },
        "algorithm": {"name": algorithm},
        "devices": {
            "requested": requested_device,
            "resolved": actual_device,
            "observed": actual_device,
        },
    }


def _stored_completed_result(
    document: Mapping[str, Any],
    destination: Path,
    case: CaseSpec,
    execution: ExecutionSpec,
) -> CaseResult:
    instance_id = execution_instance_id(
        case.semantic_case_id,
        execution.execution_spec_digest,
    )
    case_record = document["manifest"]["cases"][instance_id]
    result_record = document["results"]["cases"][instance_id]
    samples: tuple[int, ...] = ()
    raw_samples = case_record.get("raw_samples")
    if raw_samples is not None:
        with np.load(
            destination / Path(raw_samples["path"]),
            allow_pickle=False,
        ) as archive:
            if "sample_ns" in archive.files:
                samples = tuple(
                    int(value) for value in archive["sample_ns"].tolist()
                )
    metrics = _stored_submission_metrics(
        document,
        destination,
        case_record,
        result_record,
        case,
        execution,
        samples,
    )
    return CaseResult(
        case_id=case.semantic_case_id,
        execution_spec_digest=execution.execution_spec_digest,
        status="completed",
        sample_ns=samples,
        metrics=metrics,
        warnings=result_record["warnings"],
        errors=result_record["errors"],
    )


def _case_persistence_warning(error: BaseException) -> str:
    diagnostic = case_diagnostic_from_exception(
        "case_persistence",
        error,
        message="case persistence failed.",
    )
    return sanitize_case_warning(
        "case persistence failed; stage="
        + diagnostic["stage"]
        + "; exception_type="
        + diagnostic["exception_type"]
    )


def _case_weight(execution: ExecutionSpec) -> float:
    document = execution.execution_document
    for field in ("weight", "requested_total_environment_transitions", "sample_count", "repetitions"):
        value = document.get(field)
        if type(value) is int and value > 0:
            return float(value)
    return 1.0


def estimate_remaining_seconds(
    weights: Sequence[float], completed_durations: Sequence[float],
) -> float:
    """Estimate remaining wall time without observing an executor's timer.

    Before any case completes, checked-in workload weights provide a stable
    one-second-per-weight starting estimate.  Completed parent-side durations
    then replace that prior with the measured seconds-per-weight rate.
    """

    normalized = tuple(float(weight) for weight in weights)
    durations = tuple(float(duration) for duration in completed_durations)
    if len(durations) > len(normalized) or any(weight <= 0.0 for weight in normalized):
        raise ValueError("weights and completed durations are incompatible")
    if any(duration < 0.0 for duration in durations):
        raise ValueError("completed durations must be non-negative")
    completed_weight = sum(normalized[: len(durations)])
    remaining_weight = sum(normalized[len(durations) :])
    if not durations:
        return remaining_weight
    return sum(durations) * remaining_weight / completed_weight


def _emit(sink: ProgressSink | None, event: ProgressEvent) -> None:
    if sink is not None:
        sink(event)


def _default_renderers(terminal_stream: TextIO | None) -> tuple[Renderer, ...]:
    """Bind presentation-only defaults without importing them in executors."""

    from dreamgym.profiling.autonomous_driving import reporting

    def terminal(result: ProfileRunResult, writer: BundleWriter) -> None:
        del writer
        reporting.print_terminal(
            result,
            sys.stdout if terminal_stream is None else terminal_stream,
        )

    def markdown(result: ProfileRunResult, writer: BundleWriter) -> None:
        writer.persist_artifact(
            "summary.md",
            reporting.render_markdown_bytes(result),
            media_type="text/markdown; charset=utf-8",
        )

    def csv_summary(result: ProfileRunResult, writer: BundleWriter) -> None:
        writer.persist_artifact(
            "tables/cases.csv",
            reporting.render_csv_bytes(result),
            media_type="text/csv; charset=utf-8",
        )

    return csv_summary, markdown, terminal


class _DefaultExecutorRegistry(dict[str, Executor]):
    """Lazy suite adapters bound to one exact parent-owned writer."""

    def __init__(
        self,
        resolved: ResolvedProfileWorkload,
        writer: BundleWriter,
    ) -> None:
        self._resolved = resolved
        self._writer = writer
        self._snapshots: dict[tuple[str, str], dict[str, Any]] = {}
        super().__init__(
            core=self._execute_core,
            mpc=self._execute_mpc,
            rl=self._execute_rl,
        )

    @staticmethod
    def _execute_core(
        case: CaseSpec,
        execution: ExecutionSpec,
        *,
        emit: Callable[[ProgressEvent], None],
    ) -> CaseResult:
        module = importlib.import_module(
            "dreamgym.profiling.autonomous_driving.core_suites"
        )
        return module.execute_core_case(case, execution, emit=emit)

    @staticmethod
    def _execute_mpc(
        case: CaseSpec,
        execution: ExecutionSpec,
        *,
        emit: Callable[[ProgressEvent], None],
    ) -> CaseResult:
        module = importlib.import_module(
            "dreamgym.profiling.autonomous_driving.mpc"
        )
        return module.execute_mpc_case(case, execution, emit=emit)

    def _execute_rl(
        self,
        case: CaseSpec,
        execution: ExecutionSpec,
        *,
        emit: Callable[[ProgressEvent], None],
    ) -> CaseResult:
        binding = self._resolved.rl_binding_for(case, execution)
        module = importlib.import_module(
            "dreamgym.profiling.autonomous_driving.rl_worker"
        )

        def progress(message: Any) -> None:
            emit(
                ProgressEvent(
                    case.semantic_case_id,
                    "milestone",
                    int(message.completed),
                    int(message.total),
                )
            )

        try:
            worker_result = module.run_spawned_rl_worker(
                binding.request,
                self._writer,
                progress=progress,
            )
        except BaseException as error:
            snapshot = (
                getattr(error, "resolved_snapshot_reference", None)
                or getattr(error, "requested_snapshot_reference", None)
            )
            if snapshot is not None:
                self._snapshots[
                    (
                        case.semantic_case_digest,
                        execution.execution_spec_digest,
                    )
                ] = dict(snapshot)
            raise
        if (
            worker_result.case_id != case.semantic_case_id
            or worker_result.execution_spec_digest
            != binding.worker_execution_spec_digest
        ):
            raise ValueError("RL worker result does not match its binding")
        snapshot = dict(worker_result.resolved_snapshot_reference)
        requested = dict(worker_result.requested_snapshot_reference)
        if any(snapshot.get(key) != value for key, value in requested.items()):
            raise ValueError("RL worker snapshot references disagree")
        self._snapshots[
            (case.semantic_case_digest, execution.execution_spec_digest)
        ] = snapshot
        metrics = thaw_json(worker_result.metrics)
        warnings = tuple(
            sanitize_case_warning(value)
            for value in metrics.pop("warnings", [])
        )
        errors = ()
        if worker_result.status == "failed":
            training = metrics.get("training", {})
            completed = training.get("complete_window_count", 0)
            required = training.get(
                "required_complete_window_count",
                "required",
            )
            errors = (
                case_measurement_diagnostic(
                    "measurement_validation",
                    "insufficient complete RL timing windows: "
                    + str(completed)
                    + " of "
                    + str(required),
                ),
            )
        return CaseResult(
            case_id=case.semantic_case_id,
            execution_spec_digest=execution.execution_spec_digest,
            status=worker_result.status,
            sample_ns=worker_result.sample_ns,
            metrics=metrics,
            warnings=warnings,
            errors=errors,
        )

    def snapshot_for(
        self,
        case: CaseSpec,
        execution: ExecutionSpec,
    ) -> Mapping[str, Any] | None:
        return self._snapshots.get(
            (case.semantic_case_digest, execution.execution_spec_digest)
        )


def _default_executor_registry(
    resolved: ResolvedProfileWorkload,
    writer: BundleWriter,
) -> _DefaultExecutorRegistry:
    """Build lazy production adapters after the writer exists."""

    return _DefaultExecutorRegistry(resolved, writer)


def _run_profile_impl(
    request: ProfileRequest | ResolvedProfileWorkload,
    *,
    output: str | Path,
    resume: str | Path | None = None,
    imports: Sequence[CaseImportPlan] = (),
    progress_sink: ProgressSink | None = None,
    executor_registry: Mapping[str, Executor] | None = None,
    metadata: Mapping[str, Any] | None = None,
    preflight: Preflight | None = None,
    renderers: Sequence[Renderer] | None = None,
    clock: Callable[[], float] = time.monotonic,
    terminal_stream: TextIO | None = None,
    source_validation: Mapping[str, Any] | None = None,
    _interrupt_state: _RunInterruptState | None = None,
) -> ProfileRunResult:
    """Run an already-resolved or student-facing workload through injected executors.

    The optional metadata/preflight seams let callers provide a concrete valid
    RL device triple (or all nulls) before real RL construction is introduced.
    """

    if (
        isinstance(request, ResolvedProfileWorkload)
        and (
            request.classification not in {"custom", "development"}
            or request.canonical_status is not False
            or request.submission_status is not False
            or request.workload_release_id is not None
            or request.result_schema_release_id is not None
            or request.timing_protocol_release_id is not None
            or request.workload.workload_version != WORKLOAD_VERSION
        )
    ):
        raise ValueError(PROFILING_V3_NOT_RELEASED_MESSAGE)
    resolved = request if isinstance(request, ResolvedProfileWorkload) else resolve_profile_request(request)
    destination = Path(output)
    cases = resolved.workload.cases
    expected_instance_ids = tuple(
        execution_instance_id(
            case.semantic_case_id,
            execution.execution_spec_digest,
        )
        for case, execution in cases
    )
    import_plans = tuple(imports)
    if any(not isinstance(plan, CaseImportPlan) for plan in import_plans):
        raise TypeError("imports must contain CaseImportPlan values")
    required_suites = {
        _suite(resolved, case, execution)
        for case, execution in resolved.workload.cases
    }
    if metadata is None:
        declared_device = _predeclared_rl_device(resolved)
        live_metadata = collect_metadata(
            requested_rl_device=declared_device[0],
            resolved_rl_device=declared_device[1],
            observed_rl_device=declared_device[2],
            include_torch_threads="rl" in required_suites,
        )
    else:
        live_metadata = metadata
    injected_registry = (
        None if executor_registry is None else dict(executor_registry)
    )
    available_suites = (
        tuple(_SUITE_DEPENDENCIES) + ("core",)
        if injected_registry is None
        else tuple(injected_registry)
    )
    warnings: list[str] = []
    results: list[CaseResult] = []
    if _interrupt_state is not None:
        _interrupt_state.case_results = results
        _interrupt_state.warnings = warnings
    staging_destination: Path | None = None
    writer: BundleWriter | None = None
    run_attempt_id: str | None = None
    try:
        if resume is not None and import_plans:
            raise BundleCompatibilityError(
                "same-session import is distinct from resume"
            )
        if (
            resolved.canonical_status or resolved.submission_status
        ) and source_validation is None:
            raise BundleCompatibilityError(
                "canonical profiling requires validated benchmark sources"
            )
        _validate_preflight(
            resolved,
            live_metadata,
            destination,
            resume,
            available_suites,
            check_dependencies=injected_registry is None,
            allow_provisional_auto_metadata=metadata is None,
        )
        if preflight is not None:
            preflight(resolved, live_metadata, destination, resume)
        workload = _workload_manifest(resolved)
        writer_destination = destination
        if import_plans:
            destination.parent.mkdir(parents=True, exist_ok=True)
            staging_destination = destination.with_name(
                "."
                + destination.name
                + ".importing-"
                + uuid.uuid4().hex
            )
            writer_destination = staging_destination
        writer = (
            BundleWriter(
                destination,
                live_metadata=live_metadata,
                workload=workload,
                source_validation=source_validation,
            )
            if resume is not None
            else BundleWriter.create(
                writer_destination,
                workload=workload,
                metadata=live_metadata,
                source_validation=source_validation,
            )
        )
        existing_document = load_bundle(writer.path)
        initially_completed = [
            case_id
            for case_id in expected_instance_ids
            if existing_document["results"]["cases"].get(
                case_id,
                {},
            ).get("status")
            == "completed"
        ]
        run_attempt_id = writer.begin_run_attempt(
            expected_instance_ids,
            completed_case_ids=initially_completed,
        )
        if _interrupt_state is not None:
            _interrupt_state.writer = writer
            _interrupt_state.run_attempt_id = run_attempt_id
        imported_instance_ids: set[str] = set()
        if import_plans:
            destination_cases = {
                (
                    case.semantic_case_id,
                    execution.execution_spec_digest,
                ): (case, execution)
                for case, execution in resolved.workload.cases
            }
            for plan in import_plans:
                destination_pair = destination_cases.get(
                    (
                        plan.destination_semantic_case_id,
                        plan.destination_execution_spec_digest,
                    )
                )
                if destination_pair is None:
                    raise BundleCompatibilityError(
                        "import destination case does not exist"
                    )
                case, execution = destination_pair
                measurement_segment_id = (
                    "measurement-" + uuid.uuid4().hex
                )
                destination_case = _case_record(
                    case,
                    execution,
                    resolved.classification,
                    reusable=_case_is_reusable(
                        resolved,
                        case,
                        execution,
                        live_metadata,
                    ),
                    run_attempt_id=run_attempt_id,
                    measurement_segment_id=measurement_segment_id,
                    live_session_fingerprint=live_metadata[
                        "live_session_fingerprint"
                    ],
                    timing_valid=True,
                )
                if destination_case["case_id"] in imported_instance_ids:
                    raise BundleCompatibilityError(
                        "duplicate import destination case"
                    )
                import_compatible_case(
                    plan.source_bundle,
                    writer,
                    plan.source_execution_instance_id,
                    destination_case=destination_case,
                    reuse_authority=plan.reuse_authority,
                )
                imported_instance_ids.add(destination_case["case_id"])
            _publish_staged_bundle(writer.path, destination)
            writer.path = destination
            staging_destination = None
        registry: Mapping[str, Executor] = (
            _default_executor_registry(resolved, writer)
            if injected_registry is None
            else injected_registry
        )
    except (KeyboardInterrupt, Exception) as error:
        if writer is not None and run_attempt_id is not None:
            try:
                writer.finalize_run_attempt(
                    "interrupted"
                    if isinstance(error, KeyboardInterrupt)
                    else "failed",
                    fatal=not isinstance(error, KeyboardInterrupt),
                    warnings=(
                        "profiling interrupted during preflight"
                        if isinstance(error, KeyboardInterrupt)
                        else "profiling preflight failed",
                    ),
                )
            except Exception:
                pass
        if staging_destination is not None:
            shutil.rmtree(staging_destination, ignore_errors=True)
        status = "interrupted" if isinstance(error, KeyboardInterrupt) else "failed"
        if isinstance(error, KeyboardInterrupt):
            message = "profiling interrupted during preflight"
        else:
            try:
                preflight_message = str(error).strip()
            except BaseException:
                preflight_message = type(error).__name__
            message = sanitize_case_warning(
                preflight_message or type(error).__name__
            )
        warnings.append(message)
        return ProfileRunResult(status, destination, tuple(results), tuple(warnings))

    completed_document = (
        load_bundle(destination)
        if resume is not None or imported_instance_ids
        else None
    )
    weights = tuple(_case_weight(execution) for _, execution in cases)
    results_by_instance_id: dict[str, CaseResult] = {}
    durations_by_instance_id: dict[str, float] = {}
    active_progress_sink = progress_sink

    def emit_progress(event: ProgressEvent) -> None:
        nonlocal active_progress_sink
        if active_progress_sink is None:
            return
        try:
            active_progress_sink(event)
        except Exception:
            active_progress_sink = None
            warnings.append("progress reporting failed and was disabled")

    emit_progress(ProgressEvent("run", "run_start", 0, len(cases)))
    interrupted = False
    for suite, block in itertools.groupby(
        cases,
        key=lambda pair: _suite(resolved, pair[0], pair[1]),
    ):
        suite_cases = tuple(block)
        emit_progress(
            ProgressEvent(
                "suite:" + suite,
                "suite_start",
                0,
                len(suite_cases),
            )
        )
        for case, execution in suite_cases:
            if interrupted:
                break
            instance_id = execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            )
            if (
                completed_document is not None
                and completed_document["results"]["cases"].get(
                    instance_id,
                    {},
                ).get("status") == "completed"
            ):
                result = _stored_completed_result(
                        completed_document,
                        destination,
                        case,
                        execution,
                )
                results.append(result)
                results_by_instance_id[instance_id] = result
                durations_by_instance_id[instance_id] = 0.0
                emit_progress(
                    ProgressEvent(instance_id, "case_skip", 1, 1),
                )
                continue
            emit_progress(
                ProgressEvent(instance_id, "case_start", 0, 1),
            )
            measurement_segment_id = (
                "measurement-" + uuid.uuid4().hex
            )
            milestone_count = 0
            milestone_total: int | None = None
            last_milestone = -1

            def executor_emit(event: ProgressEvent) -> None:
                nonlocal milestone_count, milestone_total, last_milestone
                if not isinstance(event, ProgressEvent):
                    raise TypeError("executor progress must be a ProgressEvent")
                if (
                    event.schema_version != PROFILE_RESULTS_SCHEMA_VERSION
                    or event.case_id != case.semantic_case_id
                    or event.phase != "milestone"
                ):
                    raise ValueError(
                        "executor progress must be a matching milestone event"
                    )
                if (
                    milestone_count >= 4
                    or event.completed <= last_milestone
                    or (
                        milestone_total is not None
                        and event.total != milestone_total
                    )
                ):
                    raise ValueError(
                        "executor milestones must be bounded, monotonic, "
                        "and share one total"
                    )
                if suite == "rl" and (
                    event.total != 4
                    or event.completed != milestone_count + 1
                ):
                    raise ValueError(
                        "RL executor milestones must be exactly 1/4, "
                        "2/4, 3/4, and 4/4"
                    )
                milestone_count += 1
                milestone_total = event.total
                last_milestone = event.completed
                emit_progress(
                    ProgressEvent(
                        instance_id,
                        event.phase,
                        event.completed,
                        event.total,
                    ),
                )

            started = clock()
            try:
                result = registry[suite](
                    case,
                    execution,
                    emit=executor_emit,
                )
                if not isinstance(result, CaseResult):
                    raise TypeError("executor must return CaseResult")
                if result.case_id != case.semantic_case_id or result.execution_spec_digest != execution.execution_spec_digest:
                    raise ValueError("executor result does not match its resolved case")
                if (
                    suite == "rl"
                    and result.status == "completed"
                    and milestone_count != 4
                ):
                    raise ValueError(
                        "completed RL execution requires all four milestones"
                    )
            except KeyboardInterrupt as error:
                result = _failure_result(
                    case,
                    execution,
                    "interrupted",
                    error,
                )
                interrupted = True
            except Exception as error:
                result = _failure_result(
                    case,
                    execution,
                    "failed",
                    error,
                )
            elapsed = max(0.0, clock() - started)
            try:
                if suite == "rl":
                    native_metrics = result.to_dict()["metrics"]
                    devices = native_metrics.get("devices")
                    if isinstance(devices, Mapping):
                        requested_device = devices.get("requested")
                        observed_device = devices.get("observed")
                        if (
                            type(requested_device) is not str
                            or type(observed_device) is not str
                        ):
                            raise ValueError(
                                "RL result device observation is invalid"
                            )
                        live_metadata = writer.observe_rl_device(
                            requested_device=requested_device,
                            observed_device=observed_device,
                        )
                    elif injected_registry is None and result.status == "completed":
                        raise ValueError(
                            "completed RL result has no device observation"
                        )
                raw_samples = {"sample_ns": list(result.sample_ns)} if result.status == "completed" and result.sample_ns else None
                snapshot_for = getattr(registry, "snapshot_for", None)
                snapshot = (
                    snapshot_for(case, execution)
                    if callable(snapshot_for)
                    else None
                )
                writer.commit_case(
                    _case_record(
                        case,
                        execution,
                        resolved.classification,
                        reusable=_case_is_reusable(
                            resolved,
                            case,
                            execution,
                            live_metadata,
                        ),
                        snapshot=snapshot,
                        run_attempt_id=run_attempt_id,
                        measurement_segment_id=measurement_segment_id,
                        live_session_fingerprint=live_metadata[
                            "live_session_fingerprint"
                        ],
                        timing_valid=result.status == "completed",
                    ),
                    _bundle_result(
                        result,
                        measurement_segment_id,
                    ),
                    raw_samples=raw_samples,
                    structured_records=_structured_case_records(
                        result,
                        suite,
                        measurement_segment_id,
                    ),
                    resume=resume is not None,
                )
            except Exception as error:
                warnings.append(_case_persistence_warning(error))
                try:
                    writer.finalize_run_attempt(
                        "failed",
                        fatal=True,
                        warnings=tuple(warnings),
                    )
                except Exception:
                    pass
                return ProfileRunResult(
                    "failed",
                    destination,
                    tuple(results),
                    tuple(warnings),
                )
            results.append(result)
            results_by_instance_id[instance_id] = result
            durations_by_instance_id[instance_id] = elapsed
            phase = "case_complete" if result.status == "completed" else "case_fail"
            emit_progress(ProgressEvent(instance_id, phase, 1, 1))
        if interrupted:
            break
        emit_progress(
            ProgressEvent(
                "suite:" + suite,
                "suite_complete",
                len(suite_cases),
                len(suite_cases),
            )
        )
    if interrupted:
        status = "interrupted"
    elif any(
        results_by_instance_id[
            execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            )
        ].status != "completed"
        and bool(execution.execution_document.get("required", True))
        for case, execution in cases
    ):
        status = "incomplete"
    else:
        status = "successful"
    completed_durations = tuple(
        durations_by_instance_id[instance_id]
        for instance_id in expected_instance_ids
        if instance_id in durations_by_instance_id
    )
    estimate = estimate_remaining_seconds(weights, completed_durations)
    if _interrupt_state is not None:
        _interrupt_state.estimated_remaining_seconds = estimate
    result = ProfileRunResult(status, destination, tuple(results), tuple(warnings), estimate)
    csv_summary, markdown, terminal = _default_renderers(terminal_stream)
    optional_renderers = (terminal,) if renderers is None else tuple(renderers)
    fatal_renderer_failure = False
    for renderer in optional_renderers:
        try:
            renderer(result, writer)
        except Exception:
            warnings.append("optional renderer failed")
    if warnings:
        result = ProfileRunResult(
            status,
            destination,
            tuple(results),
            tuple(warnings),
            estimate,
        )
    for renderer in (csv_summary, markdown):
        try:
            renderer(result, writer)
        except Exception:
            warnings.append("required bundle renderer failed")
            status = "failed"
            fatal_renderer_failure = True
            break
    if warnings:
        result = ProfileRunResult(status, destination, tuple(results), tuple(warnings), estimate)
    emit_progress(
        ProgressEvent("run", "run_complete", len(results), len(cases))
    )
    if (
        result.status != status
        or result.warnings != tuple(warnings)
    ):
        result = ProfileRunResult(
            status,
            destination,
            tuple(results),
            tuple(warnings),
            estimate,
        )
    try:
        writer.finalize_run_attempt(
            status,
            fatal=fatal_renderer_failure,
            warnings=tuple(warnings),
        )
    except Exception:
        warnings.append("run-attempt finalization failed")
        result = ProfileRunResult(
            "failed",
            destination,
            tuple(results),
            tuple(warnings),
            estimate,
        )
    return result


def run_profile(
    request: ProfileRequest | ResolvedProfileWorkload,
    *,
    output: str | Path,
    resume: str | Path | None = None,
    imports: Sequence[CaseImportPlan] = (),
    progress_sink: ProgressSink | None = None,
    executor_registry: Mapping[str, Executor] | None = None,
    metadata: Mapping[str, Any] | None = None,
    preflight: Preflight | None = None,
    renderers: Sequence[Renderer] | None = None,
    clock: Callable[[], float] = time.monotonic,
    terminal_stream: TextIO | None = None,
    source_validation: Mapping[str, Any] | None = None,
) -> ProfileRunResult:
    """Run one workload behind a durable outer ``KeyboardInterrupt`` boundary.

    Injected executors own source-time sanitization of free-form
    :class:`CaseResult` warnings and diagnostics via the shared source APIs.
    """

    interrupt_state = _RunInterruptState(Path(output))
    try:
        return _run_profile_impl(
            request,
            output=output,
            resume=resume,
            imports=imports,
            progress_sink=progress_sink,
            executor_registry=executor_registry,
            metadata=metadata,
            preflight=preflight,
            renderers=renderers,
            clock=clock,
            terminal_stream=terminal_stream,
            source_validation=source_validation,
            _interrupt_state=interrupt_state,
        )
    except KeyboardInterrupt:
        case_results = tuple(interrupt_state.case_results or ())
        warnings = list(interrupt_state.warnings or ())
        warning = "profiling interrupted during run lifecycle"
        if warning not in warnings:
            warnings.append(warning)
        status = "interrupted"
        if (
            interrupt_state.writer is not None
            and interrupt_state.run_attempt_id is not None
        ):
            try:
                status, persisted_warnings = (
                    interrupt_state.writer
                    .recover_run_attempt_after_interrupt(
                        warnings=tuple(warnings),
                    )
                )
                warnings = list(persisted_warnings)
            except BaseException:
                status = "failed"
                warnings.append(
                    "interrupted run finalization failed"
                )
        return ProfileRunResult(
            status,
            interrupt_state.output,
            case_results,
            tuple(warnings),
            interrupt_state.estimated_remaining_seconds,
        )
