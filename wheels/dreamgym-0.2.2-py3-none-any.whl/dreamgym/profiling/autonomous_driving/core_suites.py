"""Shared structured execution for core autonomous-driving profiling suites."""

from __future__ import annotations

import copy
import dataclasses
import gc
import math
import time
from collections.abc import Callable, Mapping
from typing import Any

import numpy as np

from dreamgym.profiling.autonomous_driving.measurement import (
    summarize_sample_ns,
)
from dreamgym.profiling.autonomous_driving.records import (
    CaseResult,
    CaseSpec,
    ExecutionSpec,
    canonical_json_digest,
)


CORE_TIMING_PROTOCOL = {
    "version": "dreamgym-core-timing-v1",
    "clock": "perf_counter_ns",
}
_PREVIEW_SAMPLE_COUNTS = (10, 20, 40, 80)
_BICYCLE_SPEEDS = {
    "kinematic": 2.0,
    "blended": 4.0,
    "dynamic": 12.0,
}
SHARED_SPECIALIST_OVERLAP_INVENTORY = (
    "road.main.full",
    "road.cones.road_info_only",
    "road.cones.cone_filter_only",
    "road.cones.road_info_plus_cones",
    "road.extra.fixed_offset",
    "road.extra.rollout_speed_changes",
    "road.extra.global_search",
    "road.extra.rollout_large_lookahead",
    "road.extra.rollout_tapered",
    "road.construction.constant_width",
    "road.critical_repeat.full",
    "road.critical_component.full",
    "road.critical_component.closest_point",
    "environment.main.full",
    "environment.cones.full",
    "environment.extra.info_output",
    "environment.extra.vector_points",
    "environment.extra.speed_changes",
    "environment.extra.acceleration",
    "environment.extra.cones",
    "environment.extra.reference_info_output",
    "environment.breakdown.full",
    "environment.breakdown.road_query",
    "environment.breakdown.assembly",
    "environment.flat_vs_dict.full",
    "environment.reset.fixed",
    "environment.bicycle.integration",
)


def _core_case(
    readable_prefix: str,
    case_kind: str,
    fixture: Mapping[str, Any],
) -> CaseSpec:
    fixture_document = copy.deepcopy(dict(fixture))
    return CaseSpec(
        readable_prefix=readable_prefix,
        semantic_document={
            "suite": "core",
            "core": {
                "case_kind": case_kind,
                "fixture": fixture_document,
                "fixture_digest": canonical_json_digest(fixture_document),
            },
        },
        timing_protocol=CORE_TIMING_PROTOCOL,
    )


def build_road_profile_case(fixture: Mapping[str, Any]) -> CaseSpec:
    """Build the single semantic identity used by Road core/specialist paths."""

    fixture_document = copy.deepcopy(dict(fixture))
    return _core_case(
        "core-road-" + str(fixture_document["variant"]),
        "road",
        fixture_document,
    )


def build_observation_profile_case(fixture: Mapping[str, Any]) -> CaseSpec:
    """Build the shared observation identity used by both profiling surfaces."""

    fixture_document = copy.deepcopy(dict(fixture))
    return _core_case(
        "core-observation-" + str(fixture_document["variant"]),
        "observation",
        fixture_document,
    )


def build_reset_profile_case(fixture: Mapping[str, Any]) -> CaseSpec:
    fixture_document = copy.deepcopy(dict(fixture))
    return _core_case(
        "core-reset-" + str(fixture_document["variant"]),
        "reset",
        fixture_document,
    )


def build_bicycle_profile_case(fixture: Mapping[str, Any]) -> CaseSpec:
    fixture_document = copy.deepcopy(dict(fixture))
    return _core_case(
        "core-bicycle-" + str(fixture_document["variant"]),
        "bicycle",
        fixture_document,
    )


def _preview_case(preview_sample_count: int) -> CaseSpec:
    # Keep the released case population/order while using the final public
    # representation that A2 will bind into the successor workload.
    fixture = _preview_fixture_document(preview_sample_count)
    return CaseSpec(
        readable_prefix="core-preview-" + str(preview_sample_count),
        semantic_document={
            "suite": "core",
            "core": {
                "case_kind": "preview",
                "preview_sample_count": preview_sample_count,
                "road_aware": False,
                "fixture": fixture,
                "fixture_digest": canonical_json_digest(fixture),
            },
        },
        timing_protocol=CORE_TIMING_PROTOCOL,
    )


def _road_case_specs() -> list[CaseSpec]:
    variants = (
        ("reference_line", "reference_line", 10, False, False, False, "full"),
        ("target_lane", "target_lane", 10, False, False, False, "full"),
        ("fixed_offset", "fixed_offset_1p5m", 10, False, False, False, "full"),
        ("local_hint", "target_lane", 10, False, False, False, "local_hint"),
        ("global_search", "target_lane", 10, False, False, False, "global_search"),
        ("no_lookahead", "target_lane", 0, False, False, False, "full"),
        ("large_lookahead", "target_lane", 100, False, False, False, "full"),
        ("cones", "target_lane", 0, True, False, False, "cone_filter_only"),
        ("tapered_lanes", "target_lane", 10, False, True, False, "full"),
        ("speed_changes", "target_lane", 10, False, False, True, "full"),
        ("construction", "target_lane", 0, False, False, False, "construction"),
        (
            "component_breakdown",
            "target_lane",
            100,
            False,
            False,
            False,
            "closest_point_component",
        ),
    )
    return [
        build_road_profile_case(
            {
                "variant": variant,
                "num_elements": 6,
                "tracking_mode": tracking,
                "lookahead_points": lookahead,
                "include_cones": cones,
                "tapered_lane": tapered,
                "include_next_speed_changes": speed_changes,
                "operation": operation,
                **(
                    {"cone_generation_seed": 123}
                    if operation
                    in {"cone_filter_only", "road_info_plus_cones"}
                    else {}
                ),
            },
        )
        for (
            variant,
            tracking,
            lookahead,
            cones,
            tapered,
            speed_changes,
            operation,
        ) in variants
    ]


def _observation_case_specs() -> list[CaseSpec]:
    fixtures: list[dict[str, Any]] = []
    for observation_format in ("flat", "dict"):
        for payload in ("basic", "rich"):
            fixtures.append(
                {
                    "variant": observation_format + "_" + payload,
                    "num_elements": 6,
                    "tracking_mode": "target_lane",
                    "lookahead_points": 10 if payload == "rich" else 0,
                    "observation_format": observation_format,
                    "payload": payload,
                    "operation": "full",
                    "include_cones": payload == "rich",
                    "include_vector_points": payload == "rich",
                    "include_next_speed_changes": payload == "rich",
                    "include_accel": payload == "rich",
                    "output_destination": "observation",
                }
            )
    fixtures.extend(
        [
            {
                "variant": "road_query_breakdown",
                "num_elements": 6,
                "tracking_mode": "target_lane",
                "lookahead_points": 10,
                "observation_format": "dict",
                "payload": "rich",
                "operation": "road_query",
                "include_cones": False,
                "include_vector_points": True,
                "include_next_speed_changes": True,
                "include_accel": True,
                "output_destination": "observation",
            },
            {
                "variant": "assembly_breakdown",
                "num_elements": 6,
                "tracking_mode": "target_lane",
                "lookahead_points": 10,
                "observation_format": "dict",
                "payload": "rich",
                "operation": "assembly",
                "include_cones": True,
                "include_vector_points": True,
                "include_next_speed_changes": True,
                "include_accel": True,
                "output_destination": "observation",
            },
            {
                "variant": "output_to_info",
                "num_elements": 6,
                "tracking_mode": "target_lane",
                "lookahead_points": 10,
                "observation_format": "dict",
                "payload": "rich",
                "operation": "full",
                "include_cones": True,
                "include_vector_points": True,
                "include_next_speed_changes": True,
                "include_accel": True,
                "output_destination": "info",
            },
        ]
    )
    for fixture in fixtures:
        fixture["initial_reset_seed"] = 123
        if fixture["operation"] == "assembly":
            fixture["assembly_reset_seed"] = 456
    return [
        build_observation_profile_case(fixture)
        for fixture in fixtures
    ]


def _production_reset_fixture() -> dict[str, Any]:
    from dreamgym.training.autonomous_driving.configs import (
        default_training_config,
    )
    from dreamgym.training.autonomous_driving.resolution import (
        resolve_training_request,
    )

    config = default_training_config()
    build = resolve_training_request(config)
    roads = build.roads_dict()
    seeds = build.seeds_dict()
    requested = dataclasses.asdict(config.roads.train_randomization)
    return {
        "variant": "production_schema_v2_reset",
        "schema_version": config.schema_version,
        "requested_train_randomization": requested,
        "winning_source": roads["winning_training_source"],
        "resolved_train_randomization": roads["train_randomization"],
        "road_randomizer_seed": requested["seed"],
        "root_reset_seed": 17,
        "road_seed_derivation": seeds["training_road"],
        "reset_road_sampling_mode": requested["reset_road_sampling_mode"],
        "reusable_pool_size": requested["n_road_specs_in_reusable_pool"],
        "target_relative_reset": build.environment_dict()[
            "target_relative_reset"
        ],
    }


def _reset_case_specs() -> list[CaseSpec]:
    fixed = {
        "variant": "fixed_road_public_reset",
        "num_elements": 6,
        "tracking_mode": "target_lane",
        "lookahead_points": 10,
        "reset_seed": 17,
    }
    production = _production_reset_fixture()
    return [
        build_reset_profile_case(fixed),
        build_reset_profile_case(production),
    ]


def _bicycle_case_specs() -> list[CaseSpec]:
    cases = []
    for velocity_regime, initial_vx in _BICYCLE_SPEEDS.items():
        for method in ("euler", "midpoint", "heun", "rk4"):
            for num_substeps in (1, 4):
                for tire_force_condition in (None, "dry"):
                    condition_label = (
                        "default" if tire_force_condition is None else "dry"
                    )
                    fixture = {
                        "variant": (
                            velocity_regime
                            + "_"
                            + method
                            + "_"
                            + str(num_substeps)
                            + "_"
                            + condition_label
                        ),
                        "velocity_regime": velocity_regime,
                        "initial_vx_mps": initial_vx,
                        "method": method,
                        "num_substeps": num_substeps,
                        "tire_force_condition": tire_force_condition,
                        "Ts_s": 0.05,
                    }
                    cases.append(
                        build_bicycle_profile_case(fixture)
                    )
    return cases


def _gym_case_specs() -> list[CaseSpec]:
    cases = []
    for observation_format in ("flat", "dict"):
        for payload in ("basic", "rich"):
            for timing_boundary in (
                "step_only",
                "reset_encountering_rollout",
            ):
                fixture = {
                    "variant": (
                        observation_format
                        + "_"
                        + payload
                        + "_"
                        + timing_boundary
                    ),
                    "observation_format": observation_format,
                    "payload": payload,
                    "timing_boundary": timing_boundary,
                    "reset_seed": 17,
                    "public_path": "outer_env_step",
                }
                cases.append(
                    _core_case(
                        "core-gym-step-" + fixture["variant"],
                        "gym_step",
                        fixture,
                    )
                )
    cases.append(
        _core_case(
            "core-gymnasium-registration",
            "registration",
            {
                "variant": "gymnasium_make",
                "environment_id": "dreamgym/autonomous_driving_env",
                "timing_boundary": "construction",
            },
        )
    )
    return cases


def build_core_case_specs() -> tuple[CaseSpec, ...]:
    """Return the checked-in core cases plus shared specialist overlap cases."""

    return tuple(
        [
            *(_preview_case(count) for count in _PREVIEW_SAMPLE_COUNTS),
            *_road_case_specs(),
            *_observation_case_specs(),
            *_reset_case_specs(),
            *_bicycle_case_specs(),
            *_gym_case_specs(),
        ]
    )


def _preview_fixture_document(preview_sample_count: int) -> dict[str, Any]:
    return {
        "fixture_version": "dreamgym-core-preview-fixture-v1",
        "num_elements": 6,
        "origin_reference_line_progress_m": 5.0,
        "preview_sample_count": preview_sample_count,
        "target_line_distance_start_m": 0.0,
        "target_line_distance_end_m": 100.0,
        "strictly_increasing": True,
        "target_line_config": {
            "mode": "lane_center",
            "lane_index": 1,
            "require_active_lane": True,
        },
        "lane_bounds_config": {
            "mode": "lane_index",
            "lane_index": 1,
            "require_active_lane": True,
        },
    }


def build_core_fixture(case: CaseSpec) -> dict[str, Any]:
    """Materialize deterministic fixture inputs without entering timing."""

    if not isinstance(case, CaseSpec):
        raise TypeError("case must be a CaseSpec")
    core = case.to_dict()["semantic_document"].get("core")
    if not isinstance(core, Mapping):
        raise ValueError("case does not contain a core semantic record")
    fixture = core.get("fixture")
    if not isinstance(fixture, Mapping):
        raise ValueError("core fixture identity must be a mapping")
    if canonical_json_digest(fixture) != core.get("fixture_digest"):
        raise ValueError(
            "core fixture identity does not match fixture_digest"
        )
    if "preview_sample_count" in core:
        count = int(core["preview_sample_count"])
        if dict(fixture) != _preview_fixture_document(count):
            raise ValueError(
                "core fixture identity does not match preview semantics"
            )
        document = copy.deepcopy(dict(fixture))
        document["target_line_distances_m"] = np.linspace(
            0.0,
            100.0,
            num=count,
            endpoint=True,
            dtype=np.float64,
        )
        return document
    return fixture


def _tick(clock_ns: Callable[[], int]) -> int:
    value = clock_ns()
    if type(value) is not int or value < 0:
        raise ValueError("clock_ns must produce non-negative integer ticks")
    return value


def measure_indexed_callable_ns(
    callback: Callable[[int], float],
    *,
    warmup_calls: int,
    sample_count: int,
    repetitions: int = 1,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
    suppress_gc: bool = True,
    prepare: Callable[[int], None] | None = None,
) -> tuple[list[int], float]:
    """Measure an indexed callback with preparation outside each timed bracket."""

    for name, value, positive in (
        ("warmup_calls", warmup_calls, False),
        ("sample_count", sample_count, True),
        ("repetitions", repetitions, True),
    ):
        if type(value) is not int or value < (1 if positive else 0):
            qualifier = "positive" if positive else "non-negative"
            raise ValueError(name + " must be a " + qualifier + " integer")

    sink = 0.0
    samples: list[int] = []
    prior_gc_enabled = gc.isenabled()
    if suppress_gc:
        gc.disable()
    try:
        for _ in range(repetitions):
            for index in range(warmup_calls):
                if prepare is not None:
                    prepare(index)
                sink += float(callback(index))
            for index in range(sample_count):
                if prepare is not None:
                    prepare(index)
                started = _tick(clock_ns)
                sink += float(callback(index))
                elapsed = _tick(clock_ns) - started
                if elapsed < 0:
                    raise ValueError(
                        "clock_ns must produce non-decreasing integer ticks"
                    )
                samples.append(elapsed)
        return samples, sink
    finally:
        if suppress_gc:
            if prior_gc_enabled:
                gc.enable()
            else:
                gc.disable()


def specialist_timing_row(
    samples_ns: list[int] | np.ndarray,
    *,
    sink: float | None = None,
) -> dict[str, float]:
    """Adapt shared nanosecond samples to the mature specialist report fields."""

    samples = [int(value) for value in samples_ns]
    summary = summarize_sample_ns(samples)
    times_us = np.asarray(samples, dtype=np.float64) / 1000.0
    mean_us = float(summary["mean_ns"]) / 1000.0
    row = {
        "mean_us": mean_us,
        "median_us": float(summary["median_ns"]) / 1000.0,
        "p90_us": float(np.percentile(times_us, 90.0)),
        "p95_us": float(summary["p95_ns"]) / 1000.0,
        "p99_us": float(np.percentile(times_us, 99.0)),
        "min_us": float(summary["min_ns"]) / 1000.0,
        "max_us": float(summary["max_ns"]) / 1000.0,
        "calls_per_s": (
            float(1_000_000.0 / mean_us)
            if mean_us > 0.0
            else float("nan")
        ),
    }
    if sink is not None:
        row["sink"] = float(sink)
    return row


def _execution_counts(execution: ExecutionSpec) -> tuple[int, int, int]:
    if not isinstance(execution, ExecutionSpec):
        raise TypeError("execution must be an ExecutionSpec")
    document = execution.execution_document
    return (
        int(document.get("warmup_iterations", 0)),
        int(document.get("sample_count", 1)),
        int(document.get("repetitions", 1)),
    )


def _result(
    case: CaseSpec,
    execution: ExecutionSpec,
    samples: list[int],
    fixture_digest: str,
    details: Mapping[str, Any],
) -> CaseResult:
    summary = summarize_sample_ns(samples)
    metrics = {
        key: value
        for key, value in summary.items()
        if key not in {"samples_ns", "sample_unit"}
    }
    metrics.update(copy.deepcopy(dict(details)))
    metrics["fixture_digest"] = fixture_digest
    return CaseResult(
        case_id=case.semantic_case_id,
        execution_spec_digest=execution.execution_spec_digest,
        status="completed",
        sample_ns=samples,
        metrics=metrics,
    )


def build_specialist_execution_spec(
    case: CaseSpec,
    *,
    warmup_iterations: int,
    sample_count: int,
) -> ExecutionSpec:
    """Build the execution record used by an overlapping specialist case."""

    return ExecutionSpec(
        semantic_case_id=case.semantic_case_id,
        execution_document={
            "execution_spec_version": "dreamgym-core-execution-v1",
            "candidate_execution": False,
            "warmup_iterations": warmup_iterations,
            "sample_count": sample_count,
            "repetitions": 1,
        },
    )


def specialist_row_from_case_result(
    case: CaseSpec,
    result: CaseResult,
) -> dict[str, Any]:
    """Adapt a shared structured result without rebuilding timing statistics."""

    if result.case_id != case.semantic_case_id:
        raise ValueError("result does not belong to specialist case")
    row = specialist_timing_row(list(result.sample_ns))
    row.update(result.to_dict()["metrics"])
    row.update(
        {
            "semantic_case_id": case.semantic_case_id,
            "fixture_digest": case.semantic_document["core"][
                "fixture_digest"
            ],
            "semantic_fixture": case.to_dict()["semantic_document"][
                "core"
            ]["fixture"],
            "samples_ns": list(result.sample_ns),
            "structured_sample_count": len(result.sample_ns),
        }
    )
    return row


def execute_specialist_overlap(
    shared_overlap_key: str,
    case_kind: str,
    fixture: Mapping[str, Any],
    *,
    warmup_iterations: int,
    sample_count: int,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> dict[str, Any]:
    """Execute one specialist overlap through the shared structured seam."""

    if case_kind == "road":
        case = build_road_profile_case(fixture)
    elif case_kind == "observation":
        case = build_observation_profile_case(fixture)
    elif case_kind == "reset":
        case = build_reset_profile_case(fixture)
    elif case_kind == "bicycle":
        case = build_bicycle_profile_case(fixture)
    else:
        raise ValueError("unsupported specialist overlap kind: " + case_kind)
    execution = build_specialist_execution_spec(
        case,
        warmup_iterations=warmup_iterations,
        sample_count=sample_count,
    )
    result = execute_core_case(case, execution, clock_ns=clock_ns)
    row = specialist_row_from_case_result(case, result)
    row["shared_overlap_key"] = shared_overlap_key
    return row


def _fixture_digest(case: CaseSpec, fixture: Mapping[str, Any]) -> str:
    core = case.semantic_document["core"]
    digest = core.get("fixture_digest")
    if type(digest) is str:
        return digest
    identity = {
        key: value
        for key, value in fixture.items()
        if key != "target_line_distances_m"
    }
    return canonical_json_digest(identity)


def _execute_preview(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.envs.road import Road
    from dreamgym.profiling.autonomous_driving import road as road_profile

    road = Road(
        road_spec=road_profile.build_road_spec(
            int(fixture["num_elements"])
        )
    )
    distances = fixture["target_line_distances_m"]

    def callback(_: int) -> float:
        sample = road.sample_target_line_horizon(
            fixture["origin_reference_line_progress_m"],
            distances,
            target_line_config=fixture["target_line_config"],
            lane_bounds_config=fixture["lane_bounds_config"],
        )
        return float(sample.positions_in_world_frame_m[-1, 0])

    samples, sink = measure_indexed_callable_ns(
        callback,
        warmup_calls=warmup,
        sample_count=sample_count,
        repetitions=repetitions,
        clock_ns=clock_ns,
    )
    return samples, {
        "preview_sample_count": len(distances),
        "strictly_increasing_distances": bool(np.all(np.diff(distances) > 0)),
        "target_line_config": copy.deepcopy(fixture["target_line_config"]),
        "lane_bounds_config": copy.deepcopy(fixture["lane_bounds_config"]),
        "sink": sink,
    }


def _execute_road(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.envs.road import Road
    from dreamgym.profiling.autonomous_driving import road as profile

    road_spec = profile.build_road_spec(
        int(fixture["num_elements"]),
        include_cones=bool(fixture["include_cones"]),
        tapered_lane=bool(fixture["tapered_lane"]),
        include_lane=bool(fixture.get("include_lane", True)),
    )
    operation = fixture["operation"]
    cone_xy = None
    cone_color = None
    cone_generation_ms = None
    if operation in {"cone_filter_only", "road_info_plus_cones"}:
        road_for_cones = Road(road_spec=road_spec)
        generation_started = time.perf_counter_ns()
        cone_xy, cone_color = road_for_cones.get_cone_arrays_from_spec(
            rng=np.random.default_rng(
                int(fixture["cone_generation_seed"])
            )
        )
        cone_generation_ms = (
            time.perf_counter_ns() - generation_started
        ) / 1_000_000.0
    if operation == "construction":
        def callback(_: int) -> float:
            return float(Road(road_spec=road_spec).total_length_m)
    else:
        road = (
            road_for_cones
            if operation in {"cone_filter_only", "road_info_plus_cones"}
            else Road(road_spec=road_spec)
        )
        total_calls = max(
            (warmup + sample_count) * repetitions,
            1,
        )
        tracking_mode = str(fixture["tracking_mode"])
        poses = profile.precompute_rollout_poses(
            road,
            total_calls,
            target_offset_m=profile.target_offset_for_tracking_mode(
                tracking_mode
            ),
        )
        if operation == "closest_point_component":
            callback = profile.closest_point_component_callback_factory(
                road,
                poses,
            )
        elif operation == "cone_filter_only":
            def callback(index: int) -> float:
                cone_info = (
                    road.cone_info_for_cone_point_arrays_at_given_pose_and_fov(
                        cone_xy,
                        cone_color,
                        px=float(poses["px"][index]),
                        py=float(poses["py"][index]),
                        theta=float(poses["theta"][index]),
                        fov_horizontal_degrees=120.0,
                        body_x_upper_bound=30.0,
                        max_results=profile.CONE_DETECTIONS_NUM_CONES_MAX,
                    )
                )
                return float(cone_info["num_cones"])
        elif operation == "global_search":
            queries = profile.make_lookahead_queries(
                int(fixture["lookahead_points"])
            )
            field_mode = fixture.get("lookahead_output_fields", "environment")
            fields = (
                Road.LOOKAHEAD_RESULT_FIELDS
                if field_mode == "all"
                else (
                    profile.ENV_LOOKAHEAD_FIELDS
                    if fixture["lookahead_points"]
                    else frozenset()
                )
            )

            def callback(index: int) -> float:
                return profile.call_road_info_global_search(
                    road,
                    poses,
                    index,
                    progress_queries=queries,
                    tracking_mode=tracking_mode,
                    lookahead_output_fields=fields,
                )
        else:
            state = profile.RolloutState()
            queries = profile.make_lookahead_queries(
                int(fixture["lookahead_points"])
            )
            field_mode = fixture.get("lookahead_output_fields", "environment")
            fields = (
                Road.LOOKAHEAD_RESULT_FIELDS
                if field_mode == "all"
                else (
                    profile.ENV_LOOKAHEAD_FIELDS
                    if fixture["lookahead_points"]
                    else frozenset()
                )
            )

            def road_callback(index: int) -> float:
                value, _ = profile.call_road_info_rl_style(
                    road,
                    poses,
                    state,
                    index,
                    progress_queries=queries,
                    tracking_mode=tracking_mode,
                    lookahead_output_fields=fields,
                    include_next_speed_changes=bool(
                        fixture["include_next_speed_changes"]
                    ),
                )
                return value

            if operation == "local_hint":
                local_progress = np.empty(total_calls, dtype=np.float64)
                for pose_index in range(total_calls):
                    closest = road.find_closest_point_to(
                        px=float(poses["px"][pose_index]),
                        py=float(poses["py"][pose_index]),
                    )
                    local_progress[pose_index] = float(closest[4])
                cursor = 0

                def callback(_: int) -> float:
                    nonlocal cursor
                    pose_index = cursor
                    cursor += 1
                    return profile.call_road_info_with_precomputed_hint(
                        road,
                        poses,
                        pose_index,
                        reference_line_progress_m=float(
                            local_progress[pose_index]
                        ),
                        progress_queries=queries,
                        tracking_mode=tracking_mode,
                        lookahead_output_fields=fields,
                        include_next_speed_changes=bool(
                            fixture["include_next_speed_changes"]
                        ),
                    )
            elif operation == "road_info_plus_cones":
                def callback(index: int) -> float:
                    road_value = road_callback(index)
                    cone_info = (
                        road.cone_info_for_cone_point_arrays_at_given_pose_and_fov(
                            cone_xy,
                            cone_color,
                            px=float(poses["px"][index]),
                            py=float(poses["py"][index]),
                            theta=float(poses["theta"][index]),
                            fov_horizontal_degrees=120.0,
                            body_x_upper_bound=30.0,
                            max_results=profile.CONE_DETECTIONS_NUM_CONES_MAX,
                        )
                    )
                    return road_value + float(cone_info["num_cones"])
            else:
                callback = road_callback

    samples, sink = measure_indexed_callable_ns(
        callback,
        warmup_calls=warmup,
        sample_count=sample_count,
        repetitions=repetitions,
        clock_ns=clock_ns,
    )
    details = {
        "variant": fixture["variant"],
        "operation": operation,
        "search_mode": (
            "local_hint"
            if operation == "local_hint"
            else (
                "global_search"
                if operation == "global_search"
                else "rollout"
            )
        ),
        "sink": sink,
    }
    if cone_xy is not None:
        details.update(
            {
                "cone_points": len(cone_xy),
                "cone_generation_ms": cone_generation_ms,
                "cone_result_limit": profile.CONE_DETECTIONS_NUM_CONES_MAX,
            }
        )
    return samples, details


def _execute_observation(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.profiling.autonomous_driving import environment as profile

    profile._ensure_environment_runtime_imports()
    road_spec = profile.build_road_spec(
        int(fixture["num_elements"]),
        include_cones=bool(fixture["include_cones"]),
    )
    observation_config = profile.make_observation_config(
        tracking_mode=str(fixture["tracking_mode"]),
        lookahead_points=int(fixture["lookahead_points"]),
        include_cones=bool(fixture["include_cones"]),
        include_vector_points=bool(fixture["include_vector_points"]),
        include_next_speed_changes=bool(
            fixture["include_next_speed_changes"]
        ),
        include_accel=bool(fixture["include_accel"]),
        output_destination=str(fixture["output_destination"]),
    )
    env = profile.create_env(
        road_spec,
        observation_config,
        tracking_mode=str(fixture["tracking_mode"]),
        observation_format=str(fixture["observation_format"]),
    )
    try:
        total_calls = max(warmup, sample_count, 1)
        poses = profile.precompute_rollout_poses(
            env,
            total_calls,
            target_offset_m=(
                0.0
                if fixture["tracking_mode"] == "reference_line"
                else profile.TARGET_LANE_CENTER_OFFSET_M
            ),
        )
        reset_started = time.perf_counter_ns()
        env.reset(
            seed=int(fixture["initial_reset_seed"]),
            options=profile.initial_state_from_pose(poses),
        )
        reset_ms = (
            time.perf_counter_ns() - reset_started
        ) / 1_000_000.0
        operation = fixture["operation"]
        if operation == "road_query":
            callback = lambda index: profile.call_env_road_info_only(
                env,
                poses,
                index,
            )
        elif operation == "assembly":
            road_infos, cone_infos = profile.precompute_observation_inputs(
                env,
                poses,
                total_calls,
            )
            env.reset(
                seed=int(fixture["assembly_reset_seed"]),
                options=profile.initial_state_from_pose(poses),
            )
            callback = lambda index: profile.call_env_observation_assembly_only(
                env,
                poses,
                road_infos,
                cone_infos,
                index,
            )
        else:
            callback = lambda index: profile.call_env_observation(
                env,
                poses,
                index,
            )
        samples, sink = measure_indexed_callable_ns(
            callback,
            warmup_calls=warmup,
            sample_count=sample_count,
            repetitions=repetitions,
            clock_ns=clock_ns,
        )
        details = {
            "variant": fixture["variant"],
            "operation": operation,
            "observation_format": fixture["observation_format"],
            "payload": fixture["payload"],
            "initial_reset_seed": fixture["initial_reset_seed"],
            "flat_size": env.flat_observation_size,
            "reset_ms": reset_ms,
            "sink": sink,
        }
        if operation == "assembly":
            details["assembly_reset_seed"] = fixture[
                "assembly_reset_seed"
            ]
        if bool(fixture["include_cones"]):
            details.update(
                {
                    "cone_points": len(env._road_spec_cone_xy),
                    "cone_result_limit": (
                        profile.CONE_DETECTIONS_NUM_CONES_MAX
                    ),
                }
            )
        return samples, details
    finally:
        env.close()


def _execute_bicycle(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.profiling.autonomous_driving import environment as profile

    profile._ensure_environment_runtime_imports()
    car = profile.BicycleModelDynamic(
        profile.profile_bicycle_model_config()
    )
    regime = fixture["velocity_regime"]
    car.reset(
        state={
            "world_pose": {"x_m": 0.0, "y_m": 0.0, "heading_rad": 0.0},
            "body_motion": {
                "longitudinal_velocity_mps": float(fixture["initial_vx_mps"]),
                "lateral_velocity_mps": (
                    0.0 if regime == "kinematic" else 0.05
                ),
                "yaw_rate_rad_per_s": (
                    0.0 if regime == "kinematic" else 0.02
                ),
            },
            "front_wheel_steering_angle_rad": 0.0,
        }
    )
    if fixture["tire_force_condition"] is not None:
        car.set_tire_force_condition(fixture["tire_force_condition"])

    def callback(index: int) -> float:
        car.set_action_request(
            normalized_drive_command=(
                0.02 + 0.005 * math.sin(0.017 * index)
            ),
            requested_front_wheel_angle_rad=(
                0.01 * math.sin(0.013 * index)
            ),
        )
        state = car.integrate(
            duration_s=float(fixture["Ts_s"]),
            method=str(fixture["method"]),
            substep_count=int(fixture["num_substeps"]),
            update_stored_state=True,
        )
        return float(sum(state))

    samples, sink = measure_indexed_callable_ns(
        callback,
        warmup_calls=warmup,
        sample_count=sample_count,
        repetitions=repetitions,
        clock_ns=clock_ns,
    )
    return samples, {
        "velocity_regime": regime,
        "method": fixture["method"],
        "num_substeps": fixture["num_substeps"],
        "tire_force_condition": fixture["tire_force_condition"],
        "sink": sink,
    }


def _execute_fixed_reset(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.profiling.autonomous_driving import environment as profile

    profile._ensure_environment_runtime_imports()
    road_spec = profile.build_road_spec(
        int(fixture["num_elements"]),
        include_cones=bool(fixture.get("include_cones", False)),
    )
    config = profile.make_observation_config(
        tracking_mode=str(fixture["tracking_mode"]),
        lookahead_points=int(fixture["lookahead_points"]),
        include_cones=bool(fixture.get("include_cones", False)),
    )
    env = profile.create_env(
        road_spec,
        config,
        tracking_mode=str(fixture["tracking_mode"]),
    )
    try:
        options = None
        if fixture.get("initial_state_mode") == "rollout_pose":
            poses = profile.precompute_rollout_poses(
                env,
                max(warmup, sample_count, 1),
                target_offset_m=profile.TARGET_LANE_CENTER_OFFSET_M,
            )
            options = profile.initial_state_from_pose(poses)

        seed_counter = int(fixture["reset_seed"]) - 1

        def callback(index: int) -> float:
            nonlocal seed_counter
            seed_counter += 1
            observation, info = env.reset(
                seed=seed_counter,
                options=options,
            )
            return float(len(observation) + len(info))

        samples, sink = measure_indexed_callable_ns(
            callback,
            warmup_calls=warmup,
            sample_count=sample_count,
            repetitions=repetitions,
            clock_ns=clock_ns,
            suppress_gc=False,
        )
        return samples, {
            "variant": fixture["variant"],
            "reset_path": "direct_public_fixed_road",
            "include_cones": bool(fixture.get("include_cones", False)),
            "sink": sink,
        }
    finally:
        env.close()


def _production_build():
    from dreamgym.training.autonomous_driving.configs import (
        default_training_config,
    )
    from dreamgym.training.autonomous_driving.resolution import (
        resolve_training_request,
    )

    return resolve_training_request(default_training_config())


def _state_tuple(env: Any) -> tuple[float, ...]:
    car = env.unwrapped.car
    return (
        float(car._px),
        float(car._py),
        float(car._theta),
        float(car._vx),
        float(car._vy),
        float(car._omega),
        float(car._delta),
    )


def _independent_target_reset_expectation(
    fixture: Mapping[str, Any],
) -> dict[str, Any]:
    """Build the reset oracle from deterministic fixture inputs only."""

    base_point = np.asarray(fixture["base_point_m"], dtype=np.float64)
    base_angle = float(fixture["base_angle_radians"])
    curvature = float(fixture["curvature_per_m"])
    progress = float(fixture["arc_progress_m"])
    target_angle = base_angle + curvature * progress
    if curvature == 0.0:
        target_point = base_point + progress * np.array(
            [math.cos(base_angle), math.sin(base_angle)],
            dtype=np.float64,
        )
    else:
        target_point = base_point + np.array(
            [
                (math.sin(target_angle) - math.sin(base_angle)) / curvature,
                -(math.cos(target_angle) - math.cos(base_angle)) / curvature,
            ],
            dtype=np.float64,
        )
    left = np.array(
        [-math.sin(target_angle), math.cos(target_angle)],
        dtype=np.float64,
    )
    position = target_point + (
        float(fixture["lane_offset_m"])
        + float(fixture["lateral_error_m"])
    ) * left
    recommended = float(fixture["recommended_speed_mps"])
    target_speed = (
        recommended
        if math.isfinite(recommended) and recommended > 0.0
        else float(fixture["speed_limit_mps"])
    )
    state = {
        "px": float(position[0]),
        "py": float(position[1]),
        "theta": target_angle,
        "vx": target_speed + float(fixture["speed_error_kph"]) / 3.6,
        "vy": 0.0,
        "omega": 0.0,
        "delta": 0.0,
    }
    exact_bounds = {
        "world_pose": {
            "x_m": state["px"],
            "y_m": state["py"],
            "heading_rad": state["theta"],
        },
        "body_motion": {
            "longitudinal_velocity_mps": state["vx"],
            "lateral_velocity_mps": state["vy"],
            "yaw_rate_rad_per_s": state["omega"],
        },
    }
    reset_options = {
        "initial_state_config": {
            "bounds": {
                group: {
                    leaf: {"lower": value, "upper": value}
                    for leaf, value in leaves.items()
                }
                for group, leaves in exact_bounds.items()
            },
            "reference_line_progress_search": {
                "lower_bound_m": 0.0,
                "upper_bound_m": 0.0,
            },
        }
    }
    reset_options["initial_state_config"]["bounds"][
        "front_wheel_steering_angle_rad"
    ] = {"lower": state["delta"], "upper": state["delta"]}
    return {
        "target_point_m": target_point.tolist(),
        "target_angle_radians": target_angle,
        "left_normal": left.tolist(),
        "lane_offset_m": float(fixture["lane_offset_m"]),
        "lateral_error_m": float(fixture["lateral_error_m"]),
        "target_speed_mps": target_speed,
        "speed_error_kph": float(fixture["speed_error_kph"]),
        "state": state,
        "reset_options": reset_options,
    }


class _AnalyticTargetRoad:
    def __init__(self, fixture: Mapping[str, Any]) -> None:
        self.fixture = copy.deepcopy(dict(fixture))
        self.lane_offset = float(fixture["lane_offset_m"])
        self.speed_limit = float(fixture["speed_limit_mps"])
        self.recommended = float(fixture["recommended_speed_mps"])

    def _target_pose(self):
        base_point = np.asarray(
            self.fixture["base_point_m"],
            dtype=np.float64,
        )
        base_angle = float(self.fixture["base_angle_radians"])
        curvature = float(self.fixture["curvature_per_m"])
        arc_progress = float(self.fixture["arc_progress_m"])
        angle = base_angle + curvature * arc_progress
        if curvature == 0.0:
            point = base_point + arc_progress * np.array(
                [math.cos(base_angle), math.sin(base_angle)]
            )
        else:
            point = base_point + np.array(
                [
                    (math.sin(angle) - math.sin(base_angle)) / curvature,
                    -(math.cos(angle) - math.cos(base_angle)) / curvature,
                ]
            )
        left = np.array([-math.sin(angle), math.cos(angle)])
        return point + self.lane_offset * left, angle

    def sample_target_line_horizon(
        self,
        reference_line_progress_m,
        target_line_lookahead_distances_m,
        *,
        target_line_config,
    ):
        from types import SimpleNamespace

        if reference_line_progress_m != 0.0:
            raise AssertionError("unexpected reference-line progress")
        np.testing.assert_allclose(
            target_line_lookahead_distances_m,
            np.array([0.0], dtype=np.float64),
        )
        if target_line_config != {
            "mode": "lane_center",
            "lane_index": 1,
            "require_active_lane": True,
        }:
            raise AssertionError("unexpected target-line configuration")
        point, angle = self._target_pose()
        return SimpleNamespace(
            positions_in_world_frame_m=point.reshape(1, 2),
            headings_in_world_frame_rad=np.array(
                [angle], dtype=np.float64
            ),
        )

    def convert_progression_to_speed_limits(self, progression):
        np.testing.assert_allclose(
            progression,
            np.array([0.0], dtype=np.float64),
        )
        return (
            np.array([self.speed_limit], dtype=np.float64),
            np.array([self.recommended], dtype=np.float64),
        )


def _capture_target_relative_scenario(spec: Mapping[str, Any]) -> dict[str, Any]:
    import gymnasium as gym
    from gymnasium import spaces
    from types import SimpleNamespace

    from dreamgym.training.autonomous_driving.envs import (
        TargetRelativeInitialStateResetWrapper,
    )

    expected = _independent_target_reset_expectation(spec)
    road = _AnalyticTargetRoad(spec)

    class CaptureEnv(gym.Env):
        metadata = {}

        def __init__(self):
            self.road = road
            self.car = SimpleNamespace(
                _px=0.0,
                _py=0.0,
                _theta=0.0,
                _vx=0.0,
                _vy=0.0,
                _omega=0.0,
                _delta=0.0,
            )
            self.action_space = spaces.Box(-1.0, 1.0, shape=(1,))
            self.observation_space = spaces.Box(-1.0, 1.0, shape=(1,))
            self._previous_reference_line_progress_m = None
            self.last_reset_options = None

        def reset(self, *, seed=None, options=None, **kwargs):
            super().reset(seed=seed)
            self.last_reset_options = copy.deepcopy(options)
            config = options["initial_state_config"]
            bounds = config["bounds"]
            world_pose = bounds["world_pose"]
            body_motion = bounds["body_motion"]
            self.car._px = float(world_pose["x_m"]["lower"])
            self.car._py = float(world_pose["y_m"]["lower"])
            self.car._theta = float(world_pose["heading_rad"]["lower"])
            self.car._vx = float(
                body_motion["longitudinal_velocity_mps"]["lower"]
            )
            self.car._vy = float(
                body_motion["lateral_velocity_mps"]["lower"]
            )
            self.car._omega = float(
                body_motion["yaw_rate_rad_per_s"]["lower"]
            )
            self.car._delta = float(
                bounds["front_wheel_steering_angle_rad"]["lower"]
            )
            self._previous_reference_line_progress_m = float(
                config["reference_line_progress_search"]["lower_bound_m"]
            )
            return np.zeros((1,), dtype=np.float32), {}

    environment = _production_build().environment_dict()
    reset = environment["target_relative_reset"]
    reset["lateral_error_from_target_line_range_m"] = {
        "lower": float(spec["lateral_error_m"]),
        "upper": float(spec["lateral_error_m"]),
    }
    reset["body_longitudinal_velocity_target"]["error_range_kph"] = {
        "lower": float(spec["speed_error_kph"]),
        "upper": float(spec["speed_error_kph"]),
    }
    base = CaptureEnv()
    wrapper = TargetRelativeInitialStateResetWrapper(
        base,
        environment_record=environment,
        root_seed=0,
    )
    try:
        wrapper.reset(seed=9)
        state = {
            name: float(getattr(base.car, "_" + name))
            for name in ("px", "py", "theta", "vx", "vy", "omega", "delta")
        }
        return {
            "name": spec["name"],
            "fixture": copy.deepcopy(dict(spec)),
            "expected": expected,
            "observed_progress_hint_m": (
                base._previous_reference_line_progress_m
            ),
            "observed_state": state,
            "observed_reset_options": copy.deepcopy(
                base.last_reset_options
            ),
        }
    finally:
        wrapper.close()


def _capture_wrapper_order_counterexample() -> dict[str, Any]:
    import gymnasium as gym
    from gymnasium import spaces
    from types import SimpleNamespace
    from unittest import mock

    from dreamgym.training.autonomous_driving import envs as training_envs

    common = {
        "lateral_error_m": 1.25,
        "speed_error_kph": -3.6,
    }
    construction_fixture = {
        "name": "construction",
        "base_point_m": [41.0, -19.0],
        "base_angle_radians": -0.4,
        "curvature_per_m": 0.0,
        "arc_progress_m": 0.0,
        "lane_offset_m": 1.0,
        "speed_limit_mps": 6.0,
        "recommended_speed_mps": 5.0,
        **common,
    }
    replacement_fixture = {
        "name": "replacement",
        "base_point_m": [2.0, -3.0],
        "base_angle_radians": 0.25,
        "curvature_per_m": 0.04,
        "arc_progress_m": 7.0,
        "lane_offset_m": 3.0,
        "speed_limit_mps": 12.0,
        "recommended_speed_mps": 9.0,
        **common,
    }
    roads = {
        "construction": _AnalyticTargetRoad(construction_fixture),
        "replacement": _AnalyticTargetRoad(replacement_fixture),
    }

    class CaptureEnv(gym.Env):
        metadata = {}

        def __init__(self):
            self.road = roads["construction"]
            self._requested_road_spec = {"fixture_id": "construction"}
            self.car = SimpleNamespace(
                _px=0.0,
                _py=0.0,
                _theta=0.0,
                _vx=0.0,
                _vy=0.0,
                _omega=0.0,
                _delta=0.0,
            )
            self.action_space = spaces.Box(-1.0, 1.0, shape=(1,))
            self.observation_space = spaces.Box(-1.0, 1.0, shape=(1,))
            self._previous_reference_line_progress_m = None
            self.last_reset_options = None

        @property
        def requested_road_spec(self):
            return copy.deepcopy(self._requested_road_spec)

        def reset(self, *, seed=None, options=None, **kwargs):
            super().reset(seed=seed)
            self.last_reset_options = copy.deepcopy(options)
            config = options["initial_state_config"]
            bounds = config["bounds"]
            world_pose = bounds["world_pose"]
            body_motion = bounds["body_motion"]
            self.car._px = float(world_pose["x_m"]["lower"])
            self.car._py = float(world_pose["y_m"]["lower"])
            self.car._theta = float(world_pose["heading_rad"]["lower"])
            self.car._vx = float(
                body_motion["longitudinal_velocity_mps"]["lower"]
            )
            self.car._vy = float(
                body_motion["lateral_velocity_mps"]["lower"]
            )
            self.car._omega = float(
                body_motion["yaw_rate_rad_per_s"]["lower"]
            )
            self.car._delta = float(
                bounds["front_wheel_steering_angle_rad"]["lower"]
            )
            self._previous_reference_line_progress_m = float(
                config["reference_line_progress_search"]["lower_bound_m"]
            )
            return np.zeros((1,), dtype=np.float32), {}

    build = _production_build()
    environment = build.environment_dict()
    reset = environment["target_relative_reset"]
    reset["lateral_error_from_target_line_range_m"] = {
        "lower": common["lateral_error_m"],
        "upper": common["lateral_error_m"],
    }
    reset["body_longitudinal_velocity_target"]["error_range_kph"] = {
        "lower": common["speed_error_kph"],
        "upper": common["speed_error_kph"],
    }

    def apply_fixture(base_env, road_spec):
        fixture_id = road_spec["fixture_id"]
        base_env._requested_road_spec = copy.deepcopy(road_spec)
        base_env.road = roads[fixture_id]

    def run_stack(*, correct_order: bool) -> dict[str, Any]:
        base = CaptureEnv()
        if correct_order:
            target = training_envs.TargetRelativeInitialStateResetWrapper(
                base,
                environment_record=environment,
                root_seed=0,
            )
            wrapped = training_envs.RandomRoadResetWrapper(target, build)
        else:
            random_road = training_envs.RandomRoadResetWrapper(base, build)
            wrapped = training_envs.TargetRelativeInitialStateResetWrapper(
                random_road,
                environment_record=environment,
                root_seed=0,
            )
        try:
            wrapped.reset(seed=9)
            return {
                "observed_road_spec": base.requested_road_spec,
                "observed_reset_options": copy.deepcopy(
                    base.last_reset_options
                ),
                "observed_state": {
                    name: float(getattr(base.car, "_" + name))
                    for name in (
                        "px",
                        "py",
                        "theta",
                        "vx",
                        "vy",
                        "omega",
                        "delta",
                    )
                },
            }
        finally:
            wrapped.close()

    with (
        mock.patch.object(
            training_envs.Road,
            "generate_random_spec",
            return_value={"fixture_id": "replacement"},
        ),
        mock.patch.object(
            training_envs,
            "apply_road_spec_to_env",
            side_effect=apply_fixture,
        ),
    ):
        correct = run_stack(correct_order=True)
        reversed_order = run_stack(correct_order=False)

    return {
        "construction_fixture": construction_fixture,
        "replacement_fixture": replacement_fixture,
        "construction_expected_reset_options": (
            _independent_target_reset_expectation(construction_fixture)[
                "reset_options"
            ]
        ),
        "replacement_expected_reset_options": (
            _independent_target_reset_expectation(replacement_fixture)[
                "reset_options"
            ]
        ),
        "observed_road_spec": correct["observed_road_spec"],
        "observed_reset_options": correct["observed_reset_options"],
        "observed_state": correct["observed_state"],
        "wrong_order_observed_road_spec": reversed_order[
            "observed_road_spec"
        ],
        "wrong_order_observed_reset_options": reversed_order[
            "observed_reset_options"
        ],
    }


def collect_production_reset_verification() -> dict[str, Any]:
    """Capture numeric reset evidence from production wrappers and state."""

    from dreamgym.training.autonomous_driving.envs import make_env

    scenarios = [
        _capture_target_relative_scenario(spec)
        for spec in (
            {
                "name": "translated_straight",
                "base_point_m": [17.0, -4.0],
                "base_angle_radians": 0.0,
                "curvature_per_m": 0.0,
                "arc_progress_m": 0.0,
                "lane_offset_m": 3.0,
                "speed_limit_mps": 12.0,
                "recommended_speed_mps": 10.0,
                "lateral_error_m": 1.25,
                "speed_error_kph": -3.6,
            },
            {
                "name": "rotated_straight",
                "base_point_m": [-6.0, 8.0],
                "base_angle_radians": math.pi / 3.0,
                "curvature_per_m": 0.0,
                "arc_progress_m": 0.0,
                "lane_offset_m": 2.5,
                "speed_limit_mps": 11.0,
                "recommended_speed_mps": 9.0,
                "lateral_error_m": -0.5,
                "speed_error_kph": 1.8,
            },
            {
                "name": "curved_target",
                "base_point_m": [3.0, 2.0],
                "base_angle_radians": 0.15,
                "curvature_per_m": 1.0 / 50.0,
                "arc_progress_m": 10.0,
                "lane_offset_m": 2.0,
                "speed_limit_mps": 11.0,
                "recommended_speed_mps": 9.0,
                "lateral_error_m": 0.5,
                "speed_error_kph": -1.8,
            },
            {
                "name": "recommended_speed",
                "base_point_m": [0.0, 0.0],
                "base_angle_radians": 0.0,
                "curvature_per_m": 0.0,
                "arc_progress_m": 0.0,
                "lane_offset_m": 1.75,
                "speed_limit_mps": 12.0,
                "recommended_speed_mps": 8.0,
                "lateral_error_m": -0.25,
                "speed_error_kph": 3.6,
            },
            {
                "name": "speed_limit_fallback",
                "base_point_m": [0.0, 0.0],
                "base_angle_radians": 0.0,
                "curvature_per_m": 0.0,
                "arc_progress_m": 0.0,
                "lane_offset_m": 1.75,
                "speed_limit_mps": 12.0,
                "recommended_speed_mps": float("nan"),
                "lateral_error_m": 0.25,
                "speed_error_kph": -3.6,
            },
        )
    ]
    ordered_composition = _capture_wrapper_order_counterexample()

    replay_env = make_env(_production_build(), apply_reward=False)
    try:
        replay_env.reset(seed=100)
        first_road = replay_env.unwrapped.requested_road_spec
        first_state = list(_state_tuple(replay_env))
        replay_env.reset(seed=100)
        replay = {
            "first_road_spec": first_road,
            "replayed_road_spec": copy.deepcopy(
                replay_env.unwrapped.requested_road_spec
            ),
            "first_state": first_state,
            "replayed_state": list(_state_tuple(replay_env)),
        }
    finally:
        replay_env.close()

    return {
        "ordered_composition": ordered_composition,
        "target_scenarios": scenarios,
        "replay": replay,
    }


def _validate_production_reset_evidence(
    evidence: Mapping[str, Any],
) -> dict[str, Any]:
    def option_error(
        observed: Mapping[str, Any],
        expected: Mapping[str, Any],
    ) -> float:
        differences = []

        def compare(observed_value, expected_value):
            if isinstance(expected_value, Mapping):
                if not isinstance(observed_value, Mapping):
                    differences.append(float("inf"))
                    return
                for name, value in expected_value.items():
                    compare(observed_value[name], value)
                return
            differences.append(
                abs(float(observed_value) - float(expected_value))
            )

        compare(observed, expected)
        return max(differences, default=0.0)

    ordered = evidence["ordered_composition"]
    construction_expected = ordered[
        "construction_expected_reset_options"
    ]
    replacement_expected = ordered[
        "replacement_expected_reset_options"
    ]
    correct_order_error = option_error(
        ordered["observed_reset_options"],
        replacement_expected,
    )
    wrong_order_construction_error = option_error(
        ordered["wrong_order_observed_reset_options"],
        construction_expected,
    )
    wrong_order_replacement_error = option_error(
        ordered["wrong_order_observed_reset_options"],
        replacement_expected,
    )
    replacement_ok = (
        construction_expected != replacement_expected
        and ordered["observed_road_spec"]
        == {"fixture_id": "replacement"}
        and ordered["wrong_order_observed_road_spec"]
        == {"fixture_id": "replacement"}
        and correct_order_error <= 1.0e-8
        and wrong_order_construction_error <= 1.0e-8
        and wrong_order_replacement_error > 1.0e-3
    )
    max_position_error = 0.0
    max_speed_error = 0.0
    max_zero_state = 0.0
    max_option_error = 0.0
    for item in evidence["target_scenarios"]:
        expected = item["expected"]
        expected_state = expected["state"]
        state = item["observed_state"]
        max_position_error = max(
            max_position_error,
            abs(float(state["px"]) - float(expected_state["px"])),
            abs(float(state["py"]) - float(expected_state["py"])),
            abs(float(state["theta"]) - float(expected_state["theta"])),
            abs(float(item["observed_progress_hint_m"])),
        )
        max_speed_error = max(
            max_speed_error,
            abs(float(state["vx"]) - float(expected_state["vx"])),
        )
        max_zero_state = max(
            max_zero_state,
            *(
                abs(float(state[name]) - float(expected_state[name]))
                for name in ("vy", "omega", "delta")
            ),
        )
        max_option_error = max(
            max_option_error,
            option_error(
                item["observed_reset_options"],
                expected["reset_options"],
            ),
        )
    replay = evidence["replay"]
    replay_ok = (
        replay["first_road_spec"] == replay["replayed_road_spec"]
        and np.allclose(
            replay["first_state"],
            replay["replayed_state"],
            atol=0.0,
            rtol=0.0,
        )
    )
    if not (
        replacement_ok
        and replay_ok
        and max_position_error <= 1.0e-8
        and max_speed_error <= 1.0e-8
        and max_zero_state == 0.0
        and max_option_error <= 1.0e-8
    ):
        raise AssertionError("production reset verification failed")
    return {
        "road_replaced_before_target_sampling": replacement_ok,
        "explicit_reset_seed_replay": replay_ok,
        "target_scenario_count": len(evidence["target_scenarios"]),
        "max_position_heading_progress_error": max_position_error,
        "max_speed_error_mps": max_speed_error,
        "zero_state_observed_max_abs": max_zero_state,
        "max_base_reset_option_error": max_option_error,
        "wrong_order_replacement_error": wrong_order_replacement_error,
    }


def _execute_production_reset(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.training.autonomous_driving.envs import make_env

    build = _production_build()
    env = make_env(build, apply_reward=True)
    seed = int(fixture["root_reset_seed"])
    try:
        verification = _validate_production_reset_evidence(
            collect_production_reset_verification()
        )

        def callback(index: int) -> float:
            observation, info = env.reset(seed=seed + index)
            return float(
                env.unwrapped.car._vx
                + len(info)
            ) + (
                float(len(observation)) * 1.0e-12
            )

        samples, sink = measure_indexed_callable_ns(
            callback,
            warmup_calls=warmup,
            sample_count=sample_count,
            repetitions=repetitions,
            clock_ns=clock_ns,
            suppress_gc=False,
        )
        details = {
            "variant": fixture["variant"],
            "reset_path": "production_schema_v2",
            "winning_source": fixture["winning_source"],
            "reset_road_sampling_mode": fixture[
                "reset_road_sampling_mode"
            ],
            "reusable_pool_size": fixture["reusable_pool_size"],
            "target_progress_m": 0.0,
            "zero_state_components": [
                "body_lateral_velocity_mps",
                "yaw_rate_rad_per_s",
                "front_wheel_steering_angle_rad",
            ],
            "sink": sink,
        }
        details.update(verification)
        return samples, details
    finally:
        env.close()


def _execute_gym_step(
    fixture: Mapping[str, Any],
    *,
    warmup: int,
    sample_count: int,
    repetitions: int,
    clock_ns: Callable[[], int],
) -> tuple[list[int], dict[str, Any]]:
    from dreamgym.profiling.autonomous_driving import gym_step

    env = gym_step.make_public_step_environment(
        observation_format=str(fixture["observation_format"]),
        payload=str(fixture["payload"]),
    )
    try:
        kwargs = {
            "warmup_iterations": warmup,
            "sample_count": sample_count,
            "repetitions": repetitions,
            "reset_seed": int(fixture["reset_seed"]),
            "clock_ns": clock_ns,
        }
        if fixture["timing_boundary"] == "step_only":
            samples, details = gym_step.profile_public_steps(env, **kwargs)
        else:
            samples, details = (
                gym_step.profile_reset_encountering_rollout(env, **kwargs)
            )
        details.update(
            {
                "observation_format": fixture["observation_format"],
                "payload": fixture["payload"],
                "public_path": fixture["public_path"],
            }
        )
        return samples, details
    finally:
        env.close()


def execute_core_case(
    case: CaseSpec,
    execution: ExecutionSpec,
    *,
    emit: Callable[[Any], None] | None = None,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> CaseResult:
    """Execute one core case without invoking or parsing specialist commands."""

    if not isinstance(case, CaseSpec):
        raise TypeError("case must be a CaseSpec")
    if execution.semantic_case_id != case.semantic_case_id:
        raise ValueError("execution specification does not belong to case")
    if case.semantic_document.get("suite") != "core":
        raise ValueError("execute_core_case requires a core suite case")
    warmup, sample_count, repetitions = _execution_counts(execution)
    fixture = build_core_fixture(case)
    core = case.semantic_document["core"]
    case_kind = core.get(
        "case_kind",
        "preview" if "preview_sample_count" in core else None,
    )
    kwargs = {
        "warmup": warmup,
        "sample_count": sample_count,
        "repetitions": repetitions,
        "clock_ns": clock_ns,
    }
    if case_kind == "preview":
        samples, details = _execute_preview(fixture, **kwargs)
    elif case_kind == "road":
        samples, details = _execute_road(fixture, **kwargs)
    elif case_kind == "observation":
        samples, details = _execute_observation(fixture, **kwargs)
    elif case_kind == "bicycle":
        samples, details = _execute_bicycle(fixture, **kwargs)
    elif case_kind == "reset":
        if fixture["variant"] == "production_schema_v2_reset":
            samples, details = _execute_production_reset(fixture, **kwargs)
        else:
            samples, details = _execute_fixed_reset(fixture, **kwargs)
    elif case_kind == "gym_step":
        samples, details = _execute_gym_step(fixture, **kwargs)
    elif case_kind == "registration":
        from dreamgym.profiling.autonomous_driving.gym_step import (
            profile_gymnasium_registration,
        )

        samples, details = profile_gymnasium_registration(
            environment_id=str(fixture["environment_id"]),
            warmup_iterations=warmup,
            sample_count=sample_count,
            repetitions=repetitions,
            clock_ns=clock_ns,
        )
    else:
        raise ValueError("unsupported core case kind")
    return _result(
        case,
        execution,
        samples,
        _fixture_digest(case, fixture),
        details,
    )
