"""Canonical in-process machine profiling front end."""

from __future__ import annotations

import argparse
from dataclasses import dataclass, fields
from datetime import datetime, timezone
from pathlib import Path
import sys
from typing import Sequence, TextIO
import warnings

from dreamgym.profiling.autonomous_driving.release import (
    validate_current_benchmark_sources,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    sanitize_diagnostic_message,
)
from dreamgym.profiling.autonomous_driving.runner import (
    ProfileRunResult,
    run_profile,
)
from dreamgym.profiling.autonomous_driving.workloads import (
    WORKLOAD_VERSION,
    ProfileRequest,
    ResolvedProfileWorkload,
    resolve_profile_request,
)
from dreamgym.profiling.common import default_profiling_output_dir


_LEGACY_TUNING_FIELDS = (
    "road_iterations",
    "road_warmup",
    "road_repeats",
    "env_iterations",
    "env_warmup",
    "env_reset_iterations",
    "env_reset_warmup",
    "rl_learn_timesteps",
)


@dataclass(frozen=True)
class MachineProfileConfig:
    """Compatibility adapter over the canonical :class:`ProfileRequest`."""

    preset: str | None = None
    output: Path | str | None = None
    resume: Path | str | None = None
    mpc_prediction_horizon_steps: Sequence[int] | None = None
    mpc_soft_constraint_modes: Sequence[str] | None = None
    rl_algorithms: Sequence[str] | None = None
    rl_training_steps: Sequence[int] | None = None
    rl_n_envs: Sequence[int] | None = None
    mode: str | None = None
    output_dir: Path | str | None = None
    include_rl: str | None = None
    road_iterations: int | None = None
    road_warmup: int | None = None
    road_repeats: int | None = None
    env_iterations: int | None = None
    env_warmup: int | None = None
    env_reset_iterations: int | None = None
    env_reset_warmup: int | None = None
    rl_learn_timesteps: int | None = None

    def to_profile_request(self) -> ProfileRequest:
        for field in fields(self):
            if (
                field.name in _LEGACY_TUNING_FIELDS
                and getattr(self, field.name) is not None
            ):
                raise ValueError(
                    "legacy fine-grained machine timing overrides cannot be "
                    "translated to the versioned workload; use the five "
                    "student comparison controls"
                )
        preset = _coalesce_preset(self.preset, self.mode)
        output = _coalesce_output(self.output, self.output_dir)
        _handle_include_rl(self.include_rl)
        return ProfileRequest(
            preset=preset,
            mpc_prediction_horizon_steps=(
                self.mpc_prediction_horizon_steps
            ),
            mpc_soft_constraint_modes=self.mpc_soft_constraint_modes,
            rl_algorithms=self.rl_algorithms,
            rl_training_steps=self.rl_training_steps,
            rl_n_envs=self.rl_n_envs,
            output_dir=output,
            resume_from=(
                None if self.resume is None else Path(self.resume)
            ),
        )


# Kept only for direct-module callers from the previous command.
MachineProfileResult = ProfileRunResult


def _warn_alias(option: str, replacement: str) -> None:
    warnings.warn(
        option
        + " is deprecated for one compatibility period; use "
        + replacement,
        FutureWarning,
        stacklevel=3,
    )


def _coalesce_preset(preset: str | None, mode: str | None) -> str:
    translated = None
    if mode is not None:
        try:
            translated = {"quick": "quick", "detailed": "medium"}[mode]
        except KeyError as error:
            raise ValueError("mode must be quick or detailed") from error
        _warn_alias("--mode", "--preset")
    effective = "quick" if preset is None else preset
    if translated is not None and preset is not None and translated != preset:
        raise ValueError("conflicting --preset and --mode values")
    return translated if translated is not None else effective


def _coalesce_output(
    output: Path | str | None,
    output_dir: Path | str | None,
) -> Path | None:
    canonical = None if output is None else Path(output)
    legacy = None if output_dir is None else Path(output_dir)
    if legacy is not None:
        _warn_alias("--output-dir", "--output")
    if canonical is not None and legacy is not None and canonical != legacy:
        raise ValueError("conflicting --output and --output-dir values")
    return canonical if canonical is not None else legacy


def _handle_include_rl(include_rl: str | None) -> None:
    if include_rl is None:
        return
    if include_rl not in {"auto", "yes", "no"}:
        raise ValueError("include_rl must be auto, yes, or no")
    _warn_alias(
        "--include-rl",
        "a canonical preset (all presets already include RL)",
    )


def _argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Profile this machine across Road, environment, and RL workloads. "
            "Profiling v3 is not yet released: unmodified quick, medium, and "
            "long presets fail closed; comparison overrides whose normalized "
            "selection differs from the base preset run as custom, "
            "noncanonical diagnostics."
        ),
    )
    parser.add_argument(
        "--preset",
        choices=("quick", "medium", "long"),
        help=(
            "Base workload size (default: quick); an unmodified preset fails "
            "closed until profiling v3 is released."
        ),
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Output bundle directory.",
    )
    parser.add_argument(
        "--resume",
        type=Path,
        help="Resume this compatible existing bundle.",
    )
    parser.add_argument(
        "--mpc-horizons",
        type=int,
        nargs="+",
        help="MPC prediction horizon values in control steps.",
    )
    parser.add_argument(
        "--mpc-soft-constraints",
        nargs="+",
        metavar="{off,on}",
        help="MPC soft-constraint values: off and/or on.",
    )
    parser.add_argument(
        "--rl-algorithms",
        nargs="+",
        help="RL algorithm values: PPO, SAC, TD3, DDPG, and A2C.",
    )
    parser.add_argument(
        "--rl-training-steps",
        type=int,
        nargs="+",
        help=(
            "Requested aggregate environment-transition targets for the PPO "
            "scaling comparison; not vector calls or steps per environment."
        ),
    )
    parser.add_argument(
        "--rl-n-envs",
        type=int,
        nargs="+",
        help="DummyVecEnv member-count values (n_envs).",
    )
    parser.add_argument(
        "--mode",
        choices=("quick", "detailed"),
        help="Deprecated alias: quick -> quick, detailed -> medium.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="Deprecated alias for --output.",
    )
    parser.add_argument(
        "--include-rl",
        choices=("auto", "yes", "no"),
        help="Deprecated; preset definitions already include RL.",
    )
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return _argument_parser().parse_args(argv)


def profile_request_from_args(args: argparse.Namespace) -> ProfileRequest:
    """Translate canonical options and compatibility aliases once."""

    return MachineProfileConfig(
        preset=args.preset,
        output=args.output,
        resume=args.resume,
        mpc_prediction_horizon_steps=args.mpc_horizons,
        mpc_soft_constraint_modes=args.mpc_soft_constraints,
        rl_algorithms=args.rl_algorithms,
        rl_training_steps=args.rl_training_steps,
        rl_n_envs=args.rl_n_envs,
        mode=args.mode,
        output_dir=args.output_dir,
        include_rl=args.include_rl,
    ).to_profile_request()


def _workload_label(resolved: ResolvedProfileWorkload) -> str:
    if resolved.classification == "custom":
        return "custom"
    return resolved.normalized_request.preset


def _default_output(resolved: ResolvedProfileWorkload) -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return default_profiling_output_dir() / (
        WORKLOAD_VERSION
        + "-"
        + _workload_label(resolved)
        + "-"
        + timestamp
    )


def _operational_paths(
    resolved: ResolvedProfileWorkload,
) -> tuple[Path, Path | None]:
    request = resolved.normalized_request
    resume = (
        None if request.resume_from is None else Path(request.resume_from)
    )
    output = (
        None if request.output_dir is None else Path(request.output_dir)
    )
    if resume is not None:
        if output is not None and output != resume:
            raise ValueError("--output and --resume must name the same bundle")
        return resume, resume
    return (_default_output(resolved) if output is None else output), None


def _canonical_source_validation(
    resolved: ResolvedProfileWorkload,
) -> dict[str, object] | None:
    """Fail closed for released presets while leaving custom runs diagnostic."""

    if resolved.canonical_status is not True:
        return None
    return validate_current_benchmark_sources()


def _privacy_safe_output_label(path: str | Path) -> str:
    """Describe a bundle without printing an external absolute path."""

    try:
        return str(
            Path(path)
            .resolve()
            .relative_to(default_profiling_output_dir().parent.resolve())
        )
    except (OSError, ValueError):
        return "external output directory"


def _SparseTerminalProgress(
    resolved: ResolvedProfileWorkload,
    stream: TextIO,
):
    """Lazily construct the benchmark-controlled progress presenter."""

    from dreamgym.profiling.autonomous_driving.progress import (
        SparseProgressPresenter,
    )

    return SparseProgressPresenter(resolved, stream)


def _run_request(
    request: ProfileRequest,
    *,
    progress_sink=None,
    terminal_stream: TextIO | None = None,
) -> ProfileRunResult:
    resolved = resolve_profile_request(request)
    output, resume = _operational_paths(resolved)
    source_validation = (
        _canonical_source_validation(resolved)
        if resolved.canonical_status is True
        else None
    )
    sink = (
        _SparseTerminalProgress(
            resolved,
            sys.stdout if terminal_stream is None else terminal_stream
        )
        if progress_sink is None
        else progress_sink
    )
    return run_profile(
        resolved,
        output=output,
        resume=resume,
        progress_sink=sink,
        terminal_stream=terminal_stream,
        source_validation=source_validation,
    )


def profile_machine(
    config: MachineProfileConfig,
    *,
    progress_sink=None,
    terminal_stream: TextIO | None = None,
) -> ProfileRunResult:
    """Compatibility entry point delegated to the shared runner."""

    if not isinstance(config, MachineProfileConfig):
        raise TypeError("config must be a MachineProfileConfig")
    return _run_request(
        config.to_profile_request(),
        progress_sink=progress_sink,
        terminal_stream=terminal_stream,
    )


def profile_machine_main(argv: list[str] | None = None) -> int:
    parser = _argument_parser()
    args = parser.parse_args(argv)
    try:
        request = profile_request_from_args(args)
        resolved = resolve_profile_request(request)
        output, resume = _operational_paths(resolved)
    except (TypeError, ValueError) as error:
        parser.error(sanitize_diagnostic_message(str(error)))
    print("Workload: " + _workload_label(resolved))
    try:
        source_validation = (
            _canonical_source_validation(resolved)
            if resolved.canonical_status is True
            else None
        )
    except (OSError, TypeError, ValueError):
        print(
            "Profiling failed: benchmark source validation failed",
            file=sys.stderr,
        )
        return 1
    try:
        result = run_profile(
            resolved,
            output=output,
            resume=resume,
            progress_sink=_SparseTerminalProgress(resolved, sys.stdout),
            source_validation=source_validation,
        )
    except KeyboardInterrupt:
        print("Profiling interrupted.", file=sys.stderr)
        return 130
    for warning in result.warnings:
        print("Warning: " + warning, file=sys.stderr)
    print("Bundle: " + _privacy_safe_output_label(result.output))
    return result.exit_code
