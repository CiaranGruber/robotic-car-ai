#!/usr/bin/env python

"""Profile AutonomousDrivingEnv observation-generation and car-model paths.

The benchmark is deterministic and repo-local. It builds synthetic roads,
precomputes representative vehicle poses outside the timed region, then times
the environment observation method in a sequential loop that mirrors an RL
rollout: successive calls use the previous closest reference-line progress and
element index as hints.
"""

from __future__ import annotations

import argparse
import datetime as _datetime
import math
from pathlib import Path
import platform
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from dreamgym.profiling.common import (
    display_output_path,
    resolve_profile_output_path,
)
from dreamgym.profiling.autonomous_driving import core_suites


AutonomousDrivingEnv: Any = None
BicycleModelDynamic: Any = None


def _ensure_environment_runtime_imports() -> None:
    global AutonomousDrivingEnv, BicycleModelDynamic

    if AutonomousDrivingEnv is None:
        from dreamgym.envs.autonomous_driving_env import (
            AutonomousDrivingEnv as AutonomousDrivingEnvClass,
        )

        AutonomousDrivingEnv = AutonomousDrivingEnvClass
    if BicycleModelDynamic is None:
        from dreamgym.envs.bicycle_model_dynamic import (
            BicycleModelDynamic as BicycleModelDynamicClass,
        )

        BicycleModelDynamic = BicycleModelDynamicClass


ELEMENT_COUNTS = (10, 50, 100, 200)
LOOKAHEAD_POINT_COUNTS = (0, 1, 2, 10, 100)
LOOKAHEAD_DISTANCE_M = 100.0
TARGET_LANE_INDEX = 1
TARGET_LANE_CENTER_OFFSET_M = 1.5
CONE_DETECTIONS_NUM_CONES_MAX = 20
CAR_PROFILE_METHODS = ("euler", "midpoint", "heun", "rk4")
CAR_PROFILE_NUM_SUBSTEPS = (1, 4)
CAR_PROFILE_VELOCITY_REGIMES = (
    ("kinematic", 2.0),
    ("blended", 4.0),
    ("dynamic", 12.0),
)
CAR_PROFILE_TIRE_FORCE_CONDITIONS = (None, "dry")


def minimal_bicycle_model_config() -> Dict[str, Any]:
    return {
        "axle_geometry": {
            "front_axle_distance_from_center_of_mass_m": 1.0,
            "rear_axle_distance_from_center_of_mass_m": 1.0,
        },
        "mass_properties": {
            "mass_kg": 1000.0,
            "yaw_moment_of_inertia_kg_m2": 1000.0,
        },
        "longitudinal_force_model": {
            "normalized_motor_command_force_gain_n": 1000.0,
            "quadratic_aerodynamic_drag_coefficient_kg_per_m": 0.0,
        },
        "steering": {
            "physical_front_wheel_angle_offset_from_request_rad": 0.0,
            "requested_front_wheel_angle_magnitude_limit_rad": math.radians(45.0),
            "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                "lower": -math.radians(90.0),
                "upper": math.radians(90.0),
            },
        },
        "tire_force_model": {
            "road_conditions": {
                "dry": {
                    "peak_factor_d": 1.0,
                    "shape_factor_c": 1.9,
                    "stiffness_factor_b": 10.0,
                    "curvature_factor_e": 0.97,
                },
                "wet": {
                    "peak_factor_d": 0.82,
                    "shape_factor_c": 2.3,
                    "stiffness_factor_b": 12.0,
                    "curvature_factor_e": 1.0,
                },
                "snow": {
                    "peak_factor_d": 0.3,
                    "shape_factor_c": 2.0,
                    "stiffness_factor_b": 5.0,
                    "curvature_factor_e": 1.0,
                },
                "ice": {
                    "peak_factor_d": 0.1,
                    "shape_factor_c": 2.0,
                    "stiffness_factor_b": 4.0,
                    "curvature_factor_e": 1.0,
                },
            }
        },
        "kinematic_dynamic_transition": {
            "body_longitudinal_speed_range_mps": {
                "lower": 1000.0,
                "upper": 1001.0,
            }
        },
        "body_geometry": {
            "front_extent_from_center_of_mass_m": 1.125,
            "rear_extent_from_center_of_mass_m": 1.125,
            "width_m": 0.8,
        },
    }


def profile_bicycle_model_config() -> Dict[str, Any]:
    config = minimal_bicycle_model_config()
    speed_range = config["kinematic_dynamic_transition"][
        "body_longitudinal_speed_range_mps"
    ]
    speed_range["lower"] = 3.0
    speed_range["upper"] = 5.0
    return config


def fixed_initial_state_config(
    px: float = 0.0,
    py: float = 0.0,
    theta: float = 0.0,
) -> Dict[str, Any]:
    def fixed(value: float) -> Dict[str, float]:
        return {"lower": value, "upper": value}

    return {
        "bounds": {
            "world_pose": {
                "x_m": fixed(px),
                "y_m": fixed(py),
                "heading_rad": fixed(theta),
            },
            "body_motion": {
                "longitudinal_velocity_mps": fixed(12.0),
                "lateral_velocity_mps": fixed(0.0),
                "yaw_rate_rad_per_s": fixed(0.0),
            },
            "front_wheel_steering_angle_rad": fixed(0.0),
        },
        "reference_line_progress_search": None,
    }


def build_road_spec(num_elements: int, *, include_cones: bool = False) -> Dict:
    elements = []
    for element_idx in range(num_elements):
        speed_limit_kph = 80.0 if element_idx % 5 else 60.0
        if element_idx % 3 == 1:
            curvature_sign = 1.0 if (element_idx // 3) % 2 == 0 else -1.0
            element = {
                "geometry": {
                    "type": "circular_arc",
                    "curvature_per_m": (
                        curvature_sign / (45.0 + 5.0 * (element_idx % 4))
                    ),
                    "length_m": 20.0 + 2.0 * (element_idx % 5),
                },
                "speed_limit_kph": speed_limit_kph,
            }
        else:
            element = {
                "geometry": {
                    "type": "straight",
                    "length_m": 28.0 + 3.0 * (element_idx % 4),
                },
                "speed_limit_kph": speed_limit_kph,
            }

        if element_idx == 0:
            element["lanes"] = {
                "reference_line_role": "lane_boundary",
                "left": [{"width_m": {"start": 3.0}}],
                "right": [],
            }
            element["cross_section_width_interpolation"] = "linear"
            if include_cones:
                element["cones"] = [
                    {
                        "placement": {
                            "mode": "reference_line",
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "yellow",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                    {
                        "placement": {
                            "mode": "lane_line",
                            "lane_line_index": 1,
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "blue",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                ]

        elements.append(element)

    return {
        "active_lane_minimum_width_m": 0.02,
        "defaults": {"speed_limit_kph": 80.0},
        "elements": elements,
    }


def make_observation_config(
    *,
    tracking_mode: str,
    lookahead_points: int = 0,
    include_cones: bool = False,
    include_vector_points: bool = False,
    include_next_speed_changes: bool = False,
    include_accel: bool = False,
    output_destination: str = "observation",
) -> Dict:
    if output_destination not in ("observation", "info"):
        raise ValueError(
            "output_destination must be 'observation' or 'info'."
        )
    destination = output_destination

    routed = {"destination": destination, "scaling_factor": 1.0}
    observation_config = {
        "body_longitudinal_velocity_mps": dict(routed),
        "front_wheel_steering_angle_rad": dict(routed),
        "lateral_error_from_target_line_m": dict(routed),
        "heading_error_from_target_line_rad": dict(routed),
        "target_line_curvature_per_m": dict(routed),
        "speed_limit_mps": dict(routed),
        "recommended_speed_mps": dict(routed),
        "target_line_lookahead": {
            "maximum_distance_m": LOOKAHEAD_DISTANCE_M,
            "sample_count": max(1, int(lookahead_points)),
            "positions_in_body_frame_m": {
                "destination": destination if lookahead_points > 0 else "neither",
                "scaling_factor": 1.0,
            },
            "curvatures_per_m": {
                "destination": destination if lookahead_points > 0 else "neither",
                "scaling_factor": 1.0,
            },
        },
    }

    if tracking_mode == "target_lane":
        pass
    elif tracking_mode != "reference_line":
        raise ValueError("Unknown tracking_mode: " + str(tracking_mode))

    if lookahead_points > 0:
        pass

    if include_cones:
        observation_config["cone_detections"] = {
            "maximum_detection_count": CONE_DETECTIONS_NUM_CONES_MAX,
            "acquisition": {
                "horizontal_field_of_view_deg": 120.0,
                "forward_position_upper_bound_m": 30.0,
            },
            "positions_in_body_frame_m": dict(routed),
            "color_ids": {"destination": destination},
            "count": {"destination": destination},
        }

    if include_vector_points:
        observation_config[
            "target_line_position_at_closest_reference_line_progress_in_body_frame_m"
        ] = dict(routed)
        observation_config[
            "reference_line_closest_point_position_in_body_frame_m"
        ] = dict(routed)

    if include_next_speed_changes:
        for family in (
            "next_speed_limit_change",
            "next_recommended_speed_change",
        ):
            observation_config[family] = {
                "value_mps": dict(routed),
                "reference_line_distance_m": dict(routed),
            }

    if include_accel:
        observation_config["body_longitudinal_acceleration_mps2"] = dict(routed)
        observation_config["body_lateral_acceleration_mps2"] = dict(routed)

    return observation_config


def target_line_config_for_tracking_mode(tracking_mode: str) -> Dict[str, Any]:
    if tracking_mode == "target_lane":
        return {
            "mode": "lane_center",
            "lane_index": TARGET_LANE_INDEX,
            "require_active_lane": True,
        }
    if tracking_mode == "reference_line":
        return {"mode": "reference_line"}
    raise ValueError("Unknown tracking_mode: " + str(tracking_mode))


def create_env(
    road_spec: Dict,
    observation_config: Dict,
    *,
    initial_state_config: Optional[Dict[str, Any]] = None,
    tracking_mode: str = "target_lane",
    observation_format: str = "dict",
) -> AutonomousDrivingEnv:
    return AutonomousDrivingEnv(
        render_mode=None,
        bicycle_model_config=minimal_bicycle_model_config(),
        road_spec=road_spec,
        integration_config={
            "method": "rk4",
            "environment_step_duration_s": 0.05,
            "substep_count": 1,
        },
        termination_config={},
        initial_state_config=(
            initial_state_config
            if initial_state_config is not None
            else fixed_initial_state_config()
        ),
        observation_config=observation_config,
        target_line_config=target_line_config_for_tracking_mode(tracking_mode),
        observation_format=observation_format,
    )


def precompute_rollout_poses(
    env: AutonomousDrivingEnv,
    num_steps: int,
    *,
    target_offset_m: float,
    step_m: float = 2.0,
) -> Dict[str, np.ndarray]:
    road = env.road
    total_length = float(road.total_length_m)
    start_progress = 5.0
    usable_length = max(total_length - LOOKAHEAD_DISTANCE_M - start_progress - 5.0, 1.0)
    raw_distance = np.arange(num_steps, dtype=np.float32) * np.float32(step_m)
    progress = start_progress + np.mod(raw_distance, usable_length)
    wraps = np.empty(progress.shape, dtype=bool)
    wraps[0] = True
    wraps[1:] = progress[1:] < progress[:-1]

    reference_points, reference_angles = road.convert_progression_to_coordinates(progress)
    left_normals = np.column_stack((-np.sin(reference_angles), np.cos(reference_angles))).astype(np.float32)
    lateral_error = (0.15 * np.sin(0.11 * np.arange(num_steps))).astype(np.float32)
    pose_offsets = target_offset_m + lateral_error
    pose_points = reference_points + pose_offsets[:, None] * left_normals
    theta = (reference_angles + 0.03 * np.cos(0.07 * np.arange(num_steps))).astype(np.float32)

    movement_l1 = np.zeros((num_steps,), dtype=np.float32)
    if num_steps > 1:
        movement_l1[1:] = (
            np.abs(pose_points[1:, 0] - pose_points[:-1, 0]) +
            np.abs(pose_points[1:, 1] - pose_points[:-1, 1])
        )

    return {
        "progress": progress.astype(np.float32),
        "px": pose_points[:, 0].astype(np.float32),
        "py": pose_points[:, 1].astype(np.float32),
        "theta": theta,
        "vx": np.full((num_steps,), 12.0, dtype=np.float32),
        "vy": np.zeros((num_steps,), dtype=np.float32),
        "omega": (0.02 * np.sin(0.05 * np.arange(num_steps))).astype(np.float32),
        "delta": (0.02 * np.cos(0.09 * np.arange(num_steps))).astype(np.float32),
        "wraps": wraps,
        "movement_l1": movement_l1,
    }


def initial_state_from_pose(poses: Dict[str, np.ndarray], step_idx: int = 0) -> Dict[str, float]:
    return {
        "initial_state_config": fixed_initial_state_config(
            px=float(poses["px"][step_idx]),
            py=float(poses["py"][step_idx]),
            theta=float(poses["theta"][step_idx]),
        )
    }


def set_env_pose(env: AutonomousDrivingEnv, poses: Dict[str, np.ndarray], step_idx: int) -> None:
    car = env.car
    car._px = float(poses["px"][step_idx])
    car._py = float(poses["py"][step_idx])
    car._theta = float(poses["theta"][step_idx])
    car._vx = float(poses["vx"][step_idx])
    car._vy = float(poses["vy"][step_idx])
    car._omega = float(poses["omega"][step_idx])
    car._delta = float(poses["delta"][step_idx])


def prepare_progress_hint(env: AutonomousDrivingEnv, poses: Dict[str, np.ndarray], step_idx: int) -> None:
    if bool(poses["wraps"][step_idx]):
        env.should_use_reference_line_progress_hint = False
        env._previous_reference_line_road_element_index = None
        env.reference_line_progress_search_radius_m = None
    else:
        env.should_use_reference_line_progress_hint = True
        env.reference_line_progress_search_radius_m = (
            2.0 * float(poses["movement_l1"][step_idx]) + 1e-6
        )


def finalize_progress_hint(env: AutonomousDrivingEnv) -> None:
    ground_truth = env._current_ground_truth
    env._previous_reference_line_progress_m = ground_truth[
        "reference_line_progress_m"
    ]
    env._previous_reference_line_road_element_index = ground_truth[
        "reference_line_road_element_index"
    ]
    env.should_use_reference_line_progress_hint = True
    env.reference_line_progress_search_radius_m = 0.0


def finalize_progress_hint_from_road_info(env: AutonomousDrivingEnv, road_info_dict: Dict) -> None:
    env._previous_reference_line_progress_m = road_info_dict[
        "reference_line_progress_at_closest_point"
    ]
    env._previous_reference_line_road_element_index = road_info_dict[
        "closest_element_idx"
    ]
    env.should_use_reference_line_progress_hint = True
    env.reference_line_progress_search_radius_m = 0.0


def call_env_observation(
    env: AutonomousDrivingEnv,
    poses: Dict[str, np.ndarray],
    step_idx: int,
) -> float:
    set_env_pose(env, poses, step_idx)
    prepare_progress_hint(env, poses, step_idx)
    observation, info = env._get_observation_and_info_and_update_ground_truth()
    finalize_progress_hint(env)

    sink = float(
        env._current_ground_truth["lateral_error_from_target_line_m"]
    )
    if isinstance(observation, dict):
        if "target_line_lookahead_positions_in_body_frame_m" in observation:
            sink += float(
                observation[
                    "target_line_lookahead_positions_in_body_frame_m"
                ].ravel()[-1]
            )
        if "target_line_lookahead_curvatures_per_m" in observation:
            sink += float(
                np.sum(observation["target_line_lookahead_curvatures_per_m"])
            )
        if "cone_detections_count" in observation:
            sink += float(observation["cone_detections_count"][0])
    elif isinstance(observation, np.ndarray) and observation.size > 0:
        sink += float(observation[-1]) * 1e-12
    if "target_line_lookahead_positions_in_body_frame_m" in info:
        sink += float(
            info["target_line_lookahead_positions_in_body_frame_m"].ravel()[-1]
        )
    if "cone_detections_count" in info:
        sink += float(info["cone_detections_count"][0])
    return sink


def call_env_road_info_only(
    env: AutonomousDrivingEnv,
    poses: Dict[str, np.ndarray],
    step_idx: int,
) -> float:
    set_env_pose(env, poses, step_idx)
    prepare_progress_hint(env, poses, step_idx)
    progress_queries = env._lookahead_progress_queries_for_source()

    if env.should_use_lookahead_localized_map_latency:
        road_info_dict = env._get_road_info(np.array([], dtype=np.float32))
        env._append_lookahead_localization_sample_if_needed(road_info_dict)
        road_info_dict = env._merge_delayed_localized_map_lookahead_if_needed(road_info_dict)
    else:
        road_info_dict = env._get_road_info(progress_queries)

    finalize_progress_hint_from_road_info(env, road_info_dict)

    sink = float(road_info_dict["lateral_error_from_target_line"])
    if "target_line_points_in_body_frame" in road_info_dict:
        points = road_info_dict["target_line_points_in_body_frame"]
        if len(points) > 0:
            sink += float(points[-1, 0])
    if "target_line_curvatures" in road_info_dict:
        sink += float(np.sum(road_info_dict["target_line_curvatures"]))
    return sink


def precompute_observation_inputs(
    env: AutonomousDrivingEnv,
    poses: Dict[str, np.ndarray],
    num_steps: int,
) -> Tuple[List[Dict], Optional[List[Dict]]]:
    road_infos = []
    cone_infos = [] if env.should_compute_cone_detections else None

    for step_idx in range(num_steps):
        set_env_pose(env, poses, step_idx)
        prepare_progress_hint(env, poses, step_idx)
        progress_queries = env._lookahead_progress_queries_for_source()

        if env.should_use_lookahead_localized_map_latency:
            road_info_dict = env._get_road_info(np.array([], dtype=np.float32))
            env._append_lookahead_localization_sample_if_needed(road_info_dict)
            road_info_dict = env._merge_delayed_localized_map_lookahead_if_needed(road_info_dict)
        else:
            road_info_dict = env._get_road_info(progress_queries)

        road_infos.append(road_info_dict)
        if cone_infos is not None:
            cone_infos.append(env._get_cone_info_at_current_pose())
        finalize_progress_hint_from_road_info(env, road_info_dict)

    return road_infos, cone_infos


def call_env_observation_assembly_only(
    env: AutonomousDrivingEnv,
    poses: Dict[str, np.ndarray],
    road_infos: Sequence[Dict],
    cone_infos: Optional[Sequence[Dict]],
    step_idx: int,
) -> float:
    set_env_pose(env, poses, step_idx)
    obs_dict, info_dict = env._new_observation_and_info_dicts()
    road_info_dict = road_infos[step_idx]

    road_truth = env._update_current_ground_truth_from_road_info(road_info_dict)
    env._write_ground_truth_state_observations(obs_dict, info_dict)
    env._write_scalar_observations(obs_dict, info_dict, road_info_dict, road_truth)
    env._write_vector_observations(obs_dict, info_dict, road_info_dict)

    if cone_infos is not None:
        env._write_cone_detections_to_dicts(cone_infos[step_idx], obs_dict, info_dict)

    observation = env._format_observation_for_return(obs_dict)
    sink = float(
        env._current_ground_truth["lateral_error_from_target_line_m"]
    )
    if isinstance(observation, dict):
        if "target_line_lookahead_positions_in_body_frame_m" in observation:
            sink += float(
                observation[
                    "target_line_lookahead_positions_in_body_frame_m"
                ].ravel()[-1]
            )
        if "target_line_lookahead_curvatures_per_m" in observation:
            sink += float(
                np.sum(observation["target_line_lookahead_curvatures_per_m"])
            )
        if "cone_detections_count" in observation:
            sink += float(observation["cone_detections_count"][0])
    elif isinstance(observation, np.ndarray) and observation.size > 0:
        sink += float(observation[-1]) * 1e-12
    if "target_line_lookahead_positions_in_body_frame_m" in info_dict:
        sink += float(
            info_dict[
                "target_line_lookahead_positions_in_body_frame_m"
            ].ravel()[-1]
        )
    if "cone_detections_count" in info_dict:
        sink += float(info_dict["cone_detections_count"][0])
    return sink


def summarize_times(times_ns: np.ndarray) -> Dict[str, float]:
    return core_suites.specialist_timing_row(times_ns)


def time_loop(
    callback: Callable[[int], float],
    *,
    iterations: int,
    warmup: int,
) -> Dict[str, float]:
    samples_ns, sink = core_suites.measure_indexed_callable_ns(
        callback,
        warmup_calls=warmup,
        sample_count=iterations,
        clock_ns=time.perf_counter_ns,
        suppress_gc=True,
    )
    return core_suites.specialist_timing_row(samples_ns, sink=sink)


def benchmark_main_matrix(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = ELEMENT_COUNTS,
    lookahead_counts: Sequence[int] = LOOKAHEAD_POINT_COUNTS,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    for num_elements in element_counts:
        for tracking_mode in ("reference_line", "target_lane"):
            for lookahead_points in lookahead_counts:
                fixture = {
                    "variant": (
                        tracking_mode
                        + "_"
                        + str(lookahead_points)
                        + "_lookahead_"
                        + str(num_elements)
                        + "_elements_dict"
                    ),
                    "num_elements": num_elements,
                    "tracking_mode": tracking_mode,
                    "lookahead_points": lookahead_points,
                    "observation_format": "dict",
                    "payload": "basic",
                    "operation": "full",
                    "include_cones": False,
                    "initial_reset_seed": 123,
                    "include_vector_points": False,
                    "include_next_speed_changes": False,
                    "include_accel": False,
                    "output_destination": "observation",
                }
                case = core_suites.build_observation_profile_case(fixture)
                execution = core_suites.build_specialist_execution_spec(
                    case,
                    warmup_iterations=warmup,
                    sample_count=iterations,
                )
                result = core_suites.execute_core_case(
                    case,
                    execution,
                    clock_ns=clock_ns,
                )
                row = {
                    "category": "main",
                    "num_elements": num_elements,
                    "tracking_mode": tracking_mode,
                    "lookahead_points": lookahead_points,
                    "output_destination": "observation",
                    "include_cones": False,
                }
                row.update(
                    core_suites.specialist_row_from_case_result(case, result)
                )
                row["shared_overlap_key"] = "environment.main.full"
                rows.append(row)
    return rows


def benchmark_cone_cases(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = ELEMENT_COUNTS,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    for num_elements in element_counts:
        fixture = {
            "variant": "target_lane_cones_no_lookahead",
            "num_elements": num_elements,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "observation_format": "dict",
            "payload": "rich",
            "operation": "full",
            "include_cones": True,
            "initial_reset_seed": 123,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
            "output_destination": "observation",
        }
        row = {
            "category": "cones",
            "num_elements": num_elements,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
        }
        row.update(
            core_suites.execute_specialist_overlap(
                "environment.cones.full",
                "observation",
                fixture,
                warmup_iterations=warmup,
                sample_count=iterations,
                clock_ns=clock_ns,
            )
        )
        rows.append(row)
    return rows


def benchmark_extra_cases(
    iterations: int,
    warmup: int,
    *,
    num_elements: int = 50,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    extra_specs = (
        {
            "variant": "target_lane_no_lookahead_info_outputs",
            "shared_overlap_key": "environment.extra.info_output",
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
            "output_destination": "info",
        },
        {
            "variant": "target_lane_no_lookahead_with_vector_points",
            "shared_overlap_key": "environment.extra.vector_points",
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": True,
            "include_next_speed_changes": False,
            "include_accel": False,
            "output_destination": "observation",
        },
        {
            "variant": "target_lane_no_lookahead_with_next_speed_changes",
            "shared_overlap_key": "environment.extra.speed_changes",
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": True,
            "include_accel": False,
            "output_destination": "observation",
        },
        {
            "variant": "target_lane_no_lookahead_with_accel",
            "shared_overlap_key": "environment.extra.acceleration",
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": True,
            "output_destination": "observation",
        },
        {
            "variant": "target_lane_100_lookahead_with_cones",
            "shared_overlap_key": "environment.extra.cones",
            "tracking_mode": "target_lane",
            "lookahead_points": 100,
            "include_cones": True,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
            "output_destination": "observation",
        },
        {
            "variant": "reference_line_100_lookahead_info_outputs",
            "shared_overlap_key": (
                "environment.extra.reference_info_output"
            ),
            "tracking_mode": "reference_line",
            "lookahead_points": 100,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
            "output_destination": "info",
        },
    )

    for spec in extra_specs:
        payload = (
            "rich"
            if any(
                bool(spec[key])
                for key in (
                    "include_cones",
                    "include_vector_points",
                    "include_next_speed_changes",
                    "include_accel",
                )
            )
            else "basic"
        )
        fixture = {
            **{
                key: value
                for key, value in spec.items()
                if key != "shared_overlap_key"
            },
            "num_elements": num_elements,
            "initial_reset_seed": 123,
            "observation_format": "dict",
            "payload": payload,
            "operation": "full",
        }
        row = {
            "category": "extra",
            "num_elements": num_elements,
            "variant": spec["variant"],
            "tracking_mode": spec["tracking_mode"],
            "lookahead_points": spec["lookahead_points"],
            "output_destination": spec["output_destination"],
            "include_cones": spec["include_cones"],
        }
        row.update(
            core_suites.execute_specialist_overlap(
                spec["shared_overlap_key"],
                "observation",
                fixture,
                warmup_iterations=warmup,
                sample_count=iterations,
                clock_ns=clock_ns,
            )
        )
        rows.append(row)
    return rows


def benchmark_observation_assembly_breakdown(
    iterations: int,
    warmup: int,
    *,
    breakdown_specs: Sequence[Dict] | None = None,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    if breakdown_specs is None:
        breakdown_specs = (
        {
            "variant": "reference_line_core_no_lookahead",
            "num_elements": 50,
            "tracking_mode": "reference_line",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_no_lookahead",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_1_lookahead",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 1,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_100_lookahead",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 100,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_expanded_no_lookahead",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": True,
            "include_next_speed_changes": True,
            "include_accel": True,
        },
        {
            "variant": "target_lane_cones_no_lookahead",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": True,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_no_lookahead_200_elements",
            "num_elements": 200,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_100_lookahead_200_elements",
            "num_elements": 200,
            "tracking_mode": "target_lane",
            "lookahead_points": 100,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        )

    for spec in breakdown_specs:
        payload = (
            "rich"
            if any(
                bool(spec[key])
                for key in (
                    "include_cones",
                    "include_vector_points",
                    "include_next_speed_changes",
                    "include_accel",
                )
            )
            else "basic"
        )
        base_fixture = {
            **spec,
            "initial_reset_seed": 123,
            "observation_format": "dict",
            "payload": payload,
            "output_destination": "observation",
        }
        full_summary = core_suites.execute_specialist_overlap(
            "environment.breakdown.full",
            "observation",
            {**base_fixture, "operation": "full"},
            warmup_iterations=warmup,
            sample_count=iterations,
            clock_ns=clock_ns,
        )
        road_summary = core_suites.execute_specialist_overlap(
            "environment.breakdown.road_query",
            "observation",
            {**base_fixture, "operation": "road_query"},
            warmup_iterations=warmup,
            sample_count=iterations,
            clock_ns=clock_ns,
        )
        assembly_summary = core_suites.execute_specialist_overlap(
            "environment.breakdown.assembly",
            "observation",
            {
                **base_fixture,
                "operation": "assembly",
                "assembly_reset_seed": 456,
            },
            warmup_iterations=warmup,
            sample_count=iterations,
            clock_ns=clock_ns,
        )

        full_median_us = full_summary["median_us"]
        road_median_us = road_summary["median_us"]
        assembly_median_us = assembly_summary["median_us"]

        row = {
            "category": "assembly_breakdown",
            "variant": spec["variant"],
            "num_elements": spec["num_elements"],
            "tracking_mode": spec["tracking_mode"],
            "lookahead_points": spec["lookahead_points"],
            "include_cones": spec["include_cones"],
            "include_vector_points": spec["include_vector_points"],
            "include_next_speed_changes": spec["include_next_speed_changes"],
            "include_accel": spec["include_accel"],
            "full_median_us": full_median_us,
            "road_only_median_us": road_median_us,
            "assembly_only_median_us": assembly_median_us,
            "assembly_share_pct": 100.0 * assembly_median_us / full_median_us if full_median_us > 0.0 else float("nan"),
            "road_share_pct": 100.0 * road_median_us / full_median_us if full_median_us > 0.0 else float("nan"),
            "non_road_estimate_us": max(0.0, full_median_us - road_median_us),
            "full_p95_us": full_summary["p95_us"],
            "assembly_p95_us": assembly_summary["p95_us"],
            "full_calls_per_s": full_summary["calls_per_s"],
            "sink": (
                full_summary.get("sink", 0.0) +
                road_summary.get("sink", 0.0) +
                assembly_summary.get("sink", 0.0)
            ),
            "shared_overlap_results": [
                full_summary,
                road_summary,
                assembly_summary,
            ],
        }
        rows.append(row)

    return rows


def benchmark_flat_vs_dict_cases(
    iterations: int,
    warmup: int,
    *,
    comparison_specs: Sequence[Dict] | None = None,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    if comparison_specs is None:
        comparison_specs = (
        {
            "variant": "target_lane_core_no_lookahead_50_elements",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_no_lookahead_200_elements",
            "num_elements": 200,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_1_lookahead_50_elements",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 1,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_core_100_lookahead_50_elements",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 100,
            "include_cones": False,
            "include_vector_points": False,
            "include_next_speed_changes": False,
            "include_accel": False,
        },
        {
            "variant": "target_lane_expanded_no_lookahead_50_elements",
            "num_elements": 50,
            "tracking_mode": "target_lane",
            "lookahead_points": 0,
            "include_cones": False,
            "include_vector_points": True,
            "include_next_speed_changes": True,
            "include_accel": True,
        },
        )

    for spec in comparison_specs:
        variant_rows = []
        for observation_format in ("dict", "flat"):
            payload = (
                "rich"
                if any(
                    bool(spec[key])
                    for key in (
                        "include_cones",
                        "include_vector_points",
                        "include_next_speed_changes",
                        "include_accel",
                    )
                )
                else "basic"
            )
            fixture = {
                **spec,
                "initial_reset_seed": 123,
                "observation_format": observation_format,
                "payload": payload,
                "operation": "full",
                "output_destination": "observation",
            }
            case = core_suites.build_observation_profile_case(fixture)
            execution = core_suites.build_specialist_execution_spec(
                case,
                warmup_iterations=warmup,
                sample_count=iterations,
            )
            result = core_suites.execute_core_case(
                case,
                execution,
                clock_ns=clock_ns,
            )
            row = {
                "category": "flat_vs_dict",
                "variant": spec["variant"],
                "num_elements": spec["num_elements"],
                "tracking_mode": spec["tracking_mode"],
                "lookahead_points": spec["lookahead_points"],
                "observation_format": observation_format,
            }
            row.update(
                core_suites.specialist_row_from_case_result(case, result)
            )
            row["shared_overlap_key"] = "environment.flat_vs_dict.full"
            variant_rows.append(row)

        dict_median_us = next(
            row["median_us"] for row in variant_rows
            if row["observation_format"] == "dict"
        )
        for row in variant_rows:
            if row["observation_format"] == "flat":
                row["speedup_vs_dict_pct"] = (
                    100.0 * (dict_median_us - row["median_us"]) / dict_median_us
                    if dict_median_us > 0.0 else float("nan")
                )
            else:
                row["speedup_vs_dict_pct"] = 0.0
            rows.append(row)

    return rows


def benchmark_reset_cases(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = (50, 200),
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    variants = (
        {
            "variant": "target_lane_no_lookahead",
            "include_cones": False,
            "lookahead_points": 0,
        },
        {
            "variant": "target_lane_100_lookahead",
            "include_cones": False,
            "lookahead_points": 100,
        },
        {
            "variant": "target_lane_cones_no_lookahead",
            "include_cones": True,
            "lookahead_points": 0,
        },
    )

    for num_elements in element_counts:
        for variant in variants:
            fixture = {
                **variant,
                "num_elements": num_elements,
                "tracking_mode": "target_lane",
                "reset_seed": 1,
                "initial_state_mode": "rollout_pose",
            }
            case = core_suites.build_reset_profile_case(fixture)
            execution = core_suites.build_specialist_execution_spec(
                case,
                warmup_iterations=warmup,
                sample_count=iterations,
            )
            result = core_suites.execute_core_case(
                case,
                execution,
                clock_ns=clock_ns,
            )
            row = {
                "category": "reset",
                "num_elements": num_elements,
                "variant": variant["variant"],
                "lookahead_points": variant["lookahead_points"],
                "include_cones": variant["include_cones"],
            }
            row.update(
                core_suites.specialist_row_from_case_result(case, result)
            )
            row["shared_overlap_key"] = "environment.reset.fixed"
            row["median_ms"] = row["median_us"] / 1000.0
            row["p95_ms"] = row["p95_us"] / 1000.0
            row["mean_ms"] = row["mean_us"] / 1000.0
            rows.append(row)
    return rows


def benchmark_bicycle_model_cases(
    iterations: int,
    warmup: int,
    *,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    eom_evals_per_substep = {
        "euler": 1,
        "midpoint": 2,
        "heun": 2,
        "rk4": 4,
    }
    Ts = 0.05

    for velocity_regime, initial_vx in CAR_PROFILE_VELOCITY_REGIMES:
        for method in CAR_PROFILE_METHODS:
            for num_substeps in CAR_PROFILE_NUM_SUBSTEPS:
                for tire_force_condition in CAR_PROFILE_TIRE_FORCE_CONDITIONS:
                    condition_label = (
                        "default"
                        if tire_force_condition is None
                        else str(tire_force_condition)
                    )
                    fixture = {
                        "variant": (
                            velocity_regime
                            + "_"
                            + method
                            + "_"
                            + str(num_substeps)
                            + "_"
                            + condition_label
                        ),
                        "velocity_regime": velocity_regime,
                        "initial_vx_mps": initial_vx,
                        "method": method,
                        "num_substeps": num_substeps,
                        "tire_force_condition": tire_force_condition,
                        "Ts_s": Ts,
                    }
                    case = core_suites.build_bicycle_profile_case(fixture)
                    execution = core_suites.build_specialist_execution_spec(
                        case,
                        warmup_iterations=warmup,
                        sample_count=iterations,
                    )
                    result = core_suites.execute_core_case(
                        case,
                        execution,
                        clock_ns=clock_ns,
                    )
                    row = {
                        "category": "bicycle_model",
                        "velocity_regime": velocity_regime,
                        "initial_vx_mps": initial_vx,
                        "method": method,
                        "num_substeps": num_substeps,
                        "eom_evals_per_integration": eom_evals_per_substep[method] * num_substeps,
                        "tire_force_condition": tire_force_condition,
                        "Ts_s": Ts,
                    }
                    row.update(
                        core_suites.specialist_row_from_case_result(
                            case,
                            result,
                        )
                    )
                    row["shared_overlap_key"] = (
                        "environment.bicycle.integration"
                    )
                    rows.append(row)
    return rows


def format_float(value: float, digits: int = 2) -> str:
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return str(value)
    return f"{value:.{digits}f}"


def markdown_table(rows: Sequence[Dict], columns: Sequence[Tuple[str, str]], *, digits: int = 2) -> str:
    lines = []
    lines.append("| " + " | ".join(header for _, header in columns) + " |")
    lines.append("| " + " | ".join("---" for _ in columns) + " |")
    for row in rows:
        values = []
        for key, _ in columns:
            value = row.get(key, "")
            if isinstance(value, float):
                if key == "calls_per_s":
                    values.append(format_float(value, 0))
                elif key.endswith("_ms"):
                    values.append(format_float(value, 3))
                else:
                    values.append(format_float(value, digits))
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def write_markdown_report(
    output_path: Path,
    *,
    main_rows: Sequence[Dict],
    cone_rows: Sequence[Dict],
    extra_rows: Sequence[Dict],
    assembly_rows: Sequence[Dict],
    flat_rows: Sequence[Dict],
    reset_rows: Sequence[Dict],
    car_rows: Sequence[Dict],
    iterations: int,
    warmup: int,
    reset_iterations: int,
    reset_warmup: int,
    elapsed_s: float,
) -> None:
    now = _datetime.datetime.now().astimezone()

    fastest_main = min(main_rows, key=lambda row: row["median_us"])
    slowest_main = max(main_rows, key=lambda row: row["median_us"])
    no_lookahead_target_200 = [
        row for row in main_rows
        if row["num_elements"] == 200 and row["tracking_mode"] == "target_lane" and row["lookahead_points"] == 0
    ][0]
    lookahead_100_target_200 = [
        row for row in main_rows
        if row["num_elements"] == 200 and row["tracking_mode"] == "target_lane" and row["lookahead_points"] == 100
    ][0]
    highest_assembly_share = max(assembly_rows, key=lambda row: row["assembly_share_pct"])
    lowest_assembly_share = min(assembly_rows, key=lambda row: row["assembly_share_pct"])
    flat_speedup_rows = [
        row for row in flat_rows
        if row["observation_format"] == "flat"
    ]
    best_flat_speedup = max(flat_speedup_rows, key=lambda row: row["speedup_vs_dict_pct"])
    no_lookahead_flat = [
        row for row in flat_speedup_rows
        if row["variant"] == "target_lane_core_no_lookahead_50_elements"
    ][0]
    fastest_car = min(car_rows, key=lambda row: row["median_us"])
    slowest_car = max(car_rows, key=lambda row: row["median_us"])
    dynamic_rk4_dry_one_step = [
        row for row in car_rows
        if (
            row["velocity_regime"] == "dynamic" and
            row["method"] == "rk4" and
            row["num_substeps"] == 1 and
            row["tire_force_condition"] == "dry"
        )
    ][0]
    dynamic_rk4_dry_four_step = [
        row for row in car_rows
        if (
            row["velocity_regime"] == "dynamic" and
            row["method"] == "rk4" and
            row["num_substeps"] == 4 and
            row["tire_force_condition"] == "dry"
        )
    ][0]

    text = []
    text.append("# AutonomousDrivingEnv Observation-Time Profile")
    text.append("")
    text.append("This file is generated by `python scripts/profile_environment.py`.")
    text.append("")
    text.append("## Environment")
    text.append("")
    text.append(f"- Generated: {now.isoformat(timespec='seconds')}")
    text.append(f"- Python: {platform.python_version()}")
    text.append(f"- NumPy: {np.__version__}")
    text.append(f"- Platform: {platform.platform()}")
    text.append(f"- Timed observation iterations per case: {iterations}")
    text.append(f"- Warmup observation iterations per case: {warmup}")
    text.append(f"- Timed bicycle-model integration iterations per case: {iterations}")
    text.append(f"- Warmup bicycle-model integration iterations per case: {warmup}")
    text.append(f"- Timed reset iterations per case: {reset_iterations}")
    text.append(f"- Warmup reset iterations per case: {reset_warmup}")
    text.append(f"- Total script runtime: {elapsed_s:.2f} s")
    text.append("")
    text.append("## Method")
    text.append("")
    text.append(
        "The main benchmark times `AutonomousDrivingEnv._get_observation_and_info_and_update_ground_truth()` "
        "directly. Vehicle poses are precomputed outside the timed region, then assigned to the environment "
        "before each timed call. This isolates observation generation from vehicle dynamics integration."
    )
    text.append("")
    text.append(
        "The timed loop mirrors a steady RL rollout. Each call advances along the road, passes the previous "
        "closest reference-line progress and element index back into Road through the environment, and uses a "
        "conservative local search radius based on the pose movement. At episode-like wrap points the hint is "
        "reset so the next observation uses global closest-point search."
    )
    text.append("")
    text.append(
        "The main observation set is a typical lane-following set: "
        "`body_longitudinal_velocity_mps`, `front_wheel_steering_angle_rad`, "
        "`lateral_error_from_target_line_m`, `heading_error_from_target_line_rad`, "
        "`target_line_curvature_per_m`, `speed_limit_mps`, and `recommended_speed_mps`. "
        "Lookahead cases additionally include body-frame target-line points and target-line curvatures."
    )
    text.append("")
    text.append(
        "The bicycle-model benchmark times `BicycleModelDynamic.integrate()` directly. "
        "Any explicit tire-force condition is selected before timing. It does not include Road "
        "queries, observation assembly, termination checks, or Gymnasium wrapper overhead."
    )
    text.append("")
    text.append(
        "`reference_line` means the target line is the road reference line. `target_lane` means lane index `+1`, "
        "the center of the first lane to the left of the reference line."
    )
    text.append("")
    text.append("## Quick Read")
    text.append("")
    text.append(
        f"- Fastest main case: {fastest_main['num_elements']} elements, {fastest_main['tracking_mode']}, "
        f"{fastest_main['lookahead_points']} lookahead points, median {fastest_main['median_us']:.2f} us."
    )
    text.append(
        f"- Slowest main case: {slowest_main['num_elements']} elements, {slowest_main['tracking_mode']}, "
        f"{slowest_main['lookahead_points']} lookahead points, median {slowest_main['median_us']:.2f} us."
    )
    text.append(
        f"- For the 200-element target-lane case, no lookahead is {no_lookahead_target_200['median_us']:.2f} us "
        f"median; 100 lookahead points is {lookahead_100_target_200['median_us']:.2f} us median."
    )
    text.append(
        f"- Observation assembly share ranges from {lowest_assembly_share['assembly_share_pct']:.1f}% "
        f"({lowest_assembly_share['variant']}) to {highest_assembly_share['assembly_share_pct']:.1f}% "
        f"({highest_assembly_share['variant']}) in the breakdown cases."
    )
    text.append(
        f"- Flat observations improve the 50-element target-lane no-lookahead case by "
        f"{no_lookahead_flat['speedup_vs_dict_pct']:.1f}% median versus Dict observations."
    )
    text.append(
        f"- Largest flat-observation speedup in the comparison cases: "
        f"{best_flat_speedup['speedup_vs_dict_pct']:.1f}% ({best_flat_speedup['variant']})."
    )
    text.append(
        f"- Bicycle model, dynamic regime, dry road, RK4, 1 substep: "
        f"{dynamic_rk4_dry_one_step['median_us']:.2f} us median."
    )
    text.append(
        f"- Bicycle model, dynamic regime, dry road, RK4, 4 substeps: "
        f"{dynamic_rk4_dry_four_step['median_us']:.2f} us median."
    )
    text.append(
        f"- Fastest bicycle-model case: {fastest_car['velocity_regime']} / {fastest_car['method']} / "
        f"{fastest_car['num_substeps']} substep(s) / tire_force_condition={fastest_car['tire_force_condition']}, "
        f"median {fastest_car['median_us']:.2f} us. Slowest: {slowest_car['velocity_regime']} / "
        f"{slowest_car['method']} / {slowest_car['num_substeps']} substep(s) / "
        f"tire_force_condition={slowest_car['tire_force_condition']}, median {slowest_car['median_us']:.2f} us."
    )
    text.append("")
    text.append("## Main Observation Cases")
    text.append("")
    text.append(markdown_table(
        main_rows,
        (
            ("num_elements", "elements"),
            ("tracking_mode", "tracking"),
            ("lookahead_points", "lookahead pts"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Cone Observation Cases")
    text.append("")
    text.append(
        "Cone cases use road-owned cone specs, target-lane tracking, and no lookahead points. The timed "
        "observation call filters cached cone coordinate/color arrays and writes "
        "`cone_detections_positions_in_body_frame_m`, `cone_detections_color_ids`, "
        "and `cone_detections_count`."
    )
    text.append("")
    text.append(markdown_table(
        cone_rows,
        (
            ("num_elements", "elements"),
            ("cone_points", "cached cone pts"),
            ("cone_result_limit", "result cap"),
            ("reset_ms", "one reset ms"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Extra Observation Cases")
    text.append("")
    text.append(
        "These cases isolate common questions about observation assembly: writing to `info` instead of the observation, "
        "requesting vector closest-point outputs, requesting next-speed-change outputs, including body-frame "
        "accelerations, and combining 100 lookahead points with cones."
    )
    text.append("")
    text.append(markdown_table(
        extra_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("tracking_mode", "tracking"),
            ("lookahead_points", "lookahead pts"),
            ("output_destination", "dest"),
            ("include_cones", "cones"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Observation Assembly Breakdown")
    text.append("")
    text.append(
        "These cases split the environment observation path into three profiler-only timings. "
        "`full` is the normal `_get_observation_and_info_and_update_ground_truth()` path. "
        "`road only` calls the Road query through the environment with the same progress-hint setup. "
        "`assembly only` uses precomputed `road_info` and `cone_info` inputs, then times fresh dict allocation, "
        "ground-truth updates, noise/scaling/clipping, and writing enabled observation/info fields."
    )
    text.append("")
    text.append(
        "`assembly %` is `assembly only / full`. It is the most useful column for judging whether "
        "precomputed writer lists could matter; if this percentage is small, Road/geometry work is still dominant."
    )
    text.append("")
    text.append(markdown_table(
        assembly_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("lookahead_points", "lookahead pts"),
            ("include_cones", "cones"),
            ("full_median_us", "full us"),
            ("road_only_median_us", "road only us"),
            ("assembly_only_median_us", "assembly only us"),
            ("assembly_share_pct", "assembly %"),
            ("non_road_estimate_us", "full-road us"),
            ("full_calls_per_s", "full calls/s"),
        ),
    ))
    text.append("")
    text.append("## Dict Versus Flat Observations")
    text.append("")
    text.append(
        "These cases compare the default `observation_format=\"dict\"` against "
        "`observation_format=\"flat\"`. Flat mode keeps `info` as a dictionary, "
        "but returns the enabled observations as one float32 `Box` vector. The "
        "`speedup` column is the median-time improvement of flat mode relative "
        "to the matching Dict case."
    )
    text.append("")
    text.append(markdown_table(
        flat_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("lookahead_points", "lookahead pts"),
            ("observation_format", "format"),
            ("flat_size", "flat size"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
            ("speedup_vs_dict_pct", "speedup %"),
        ),
    ))
    text.append("")
    text.append("## Bicycle Model Integration Cases")
    text.append("")
    text.append(
        "These cases time the car dynamics integration directly. `velocity regime` is determined by the initial "
        "longitudinal velocity relative to the 3-to-5 m/s kinematic/dynamic transition: kinematic is "
        "below the transition, blended is inside it, and dynamic is above it. A null `tire_force_condition` "
        "leaves the model's default dry parameters untouched; `dry` selects the same condition before timing."
    )
    text.append("")
    text.append(markdown_table(
        car_rows,
        (
            ("velocity_regime", "velocity regime"),
            ("initial_vx_mps", "initial vx m/s"),
            ("method", "method"),
            ("num_substeps", "substeps"),
            ("eom_evals_per_integration", "EOM evals"),
            ("tire_force_condition", "tire force condition"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Reset Cases")
    text.append("")
    text.append(
        "Reset timing is separate because reset includes RNG seeding, optional road-spec cone regeneration, "
        "car reset, one observation call, and progress-hint initialization. It is less important than per-step "
        "observation timing unless training performs very frequent resets or domain randomization."
    )
    text.append("")
    text.append(markdown_table(
        reset_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("lookahead_points", "lookahead pts"),
            ("include_cones", "cones"),
            ("median_ms", "median ms"),
            ("p95_ms", "p95 ms"),
            ("mean_ms", "mean ms"),
            ("calls_per_s", "resets/s"),
        ),
        digits=3,
    ))
    text.append("")
    text.append("## Notes")
    text.append("")
    text.append(
        "- These timings measure Python-level wall-clock time on the machine that generated the report. "
        "Absolute values vary with CPU, Python build, background load, and power settings."
    )
    text.append(
        "- The main matrix excludes cone observations and next-speed-change outputs so it focuses on the "
        "normal lane-following observation path."
    )
    text.append(
        "- The benchmark intentionally does not call `env.step()` in the main matrix. `step()` includes "
        "vehicle integration, termination checks, action-interface handling, and optional internal policies; "
        "the bicycle-model table profiles the vehicle integration component separately."
    )
    text.append(
        "- The sink values used inside the timing loop prevent benchmark work from becoming completely unused, "
        "but the report omits those values because they have no physical meaning."
    )
    text.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(text), encoding="utf-8")


@dataclass
class EnvironmentProfileConfig:
    iterations: int = 800
    warmup: int = 150
    reset_iterations: int = 150
    reset_warmup: int = 20
    output: Path | None = None


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Profile AutonomousDrivingEnv observation-generation and BicycleModelDynamic "
            "integration time, then write a Markdown report."
        ),
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=800,
        help="Timed observation iterations per case. Default: 800.",
    )
    parser.add_argument(
        "--warmup",
        type=int,
        default=150,
        help="Untimed observation warmup iterations per case. Default: 150.",
    )
    parser.add_argument(
        "--reset-iterations",
        type=int,
        default=150,
        help="Timed reset iterations per reset case. Default: 150.",
    )
    parser.add_argument(
        "--reset-warmup",
        type=int,
        default=20,
        help="Untimed reset warmup iterations per reset case. Default: 20.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help=(
            "Markdown output path. Default: "
            "profiling_results/env_observation_time_profile.md."
        ),
    )
    return parser.parse_args(argv)


def profile_environment(config: EnvironmentProfileConfig) -> Path:
    _ensure_environment_runtime_imports()

    if config.iterations <= 0:
        raise ValueError("iterations must be positive.")
    if config.warmup < 0:
        raise ValueError("warmup must be non-negative.")
    if config.reset_iterations <= 0:
        raise ValueError("reset_iterations must be positive.")
    if config.reset_warmup < 0:
        raise ValueError("reset_warmup must be non-negative.")

    output_path = resolve_profile_output_path(
        config.output,
        "env_observation_time_profile.md",
    )

    start_time = time.perf_counter()
    main_rows = benchmark_main_matrix(config.iterations, config.warmup)
    cone_rows = benchmark_cone_cases(config.iterations, config.warmup)
    extra_rows = benchmark_extra_cases(config.iterations, config.warmup)
    assembly_rows = benchmark_observation_assembly_breakdown(
        config.iterations,
        config.warmup,
    )
    flat_rows = benchmark_flat_vs_dict_cases(config.iterations, config.warmup)
    reset_rows = benchmark_reset_cases(config.reset_iterations, config.reset_warmup)
    car_rows = benchmark_bicycle_model_cases(config.iterations, config.warmup)
    elapsed_s = time.perf_counter() - start_time

    for row in [*main_rows, *cone_rows, *extra_rows, *assembly_rows, *flat_rows, *reset_rows, *car_rows]:
        row.pop("sink", None)

    write_markdown_report(
        output_path,
        main_rows=main_rows,
        cone_rows=cone_rows,
        extra_rows=extra_rows,
        assembly_rows=assembly_rows,
        flat_rows=flat_rows,
        reset_rows=reset_rows,
        car_rows=car_rows,
        iterations=config.iterations,
        warmup=config.warmup,
        reset_iterations=config.reset_iterations,
        reset_warmup=config.reset_warmup,
        elapsed_s=elapsed_s,
    )
    return output_path


def profile_environment_main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    output_path = profile_environment(
        EnvironmentProfileConfig(
            iterations=args.iterations,
            warmup=args.warmup,
            reset_iterations=args.reset_iterations,
            reset_warmup=args.reset_warmup,
            output=args.output,
        )
    )
    print(f"Wrote {display_output_path(output_path)}")


def main() -> None:
    profile_environment_main()


if __name__ == "__main__":
    main()
