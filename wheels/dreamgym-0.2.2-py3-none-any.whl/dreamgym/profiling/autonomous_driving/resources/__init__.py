"""Packaged versioned workload resources."""
