"""Read-only compatibility checks for comparing result bundles."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Callable, Mapping

from dreamgym.profiling.autonomous_driving.bundle import (
    BundleCompatibilityError,
    _preflight_bundle_identity,
    load_bundle,
)


Migration = Callable[[dict[str, Any]], dict[str, Any]]


def _identity(value: dict[str, Any]) -> dict[str, Any]:
    return value


MIGRATION_REGISTRY: dict[tuple[str, str], Migration] = {
    ("dreamgym-profile-results-v1", "dreamgym-profile-results-v1"): _identity,
}


_ENVIRONMENT_CONTEXT_FIELDS = (
    "schema_version",
    "environment_classification",
    "python",
    "os",
    "architecture",
    "cpu",
    "memory",
    "dependencies",
    "threads",
    "rl_device",
    "dependency_compatibility_digest",
    "runtime_hardware_compatibility_digest",
    "device_compatibility_digest",
    "live_session_fingerprint",
)


def _preflight_comparison_bundle_identities(
    first: str | Path,
    second: str | Path,
) -> None:
    """Inspect both manifests so other poison cannot mask archival identity."""

    archival_error: BundleCompatibilityError | None = None
    first_other_error: Exception | None = None
    for operand in (first, second):
        try:
            _preflight_bundle_identity(operand)
        except BundleCompatibilityError as error:
            if archival_error is None:
                archival_error = error
        except (OSError, TypeError, ValueError) as error:
            if first_other_error is None:
                first_other_error = error
    if archival_error is not None:
        raise archival_error
    if first_other_error is not None:
        raise first_other_error


def _comparison_context(
    document: Mapping[str, Any],
    case: Mapping[str, Any],
    result: Mapping[str, Any],
) -> dict[str, Any]:
    """Select only validated, public comparison context."""

    manifest = document["manifest"]
    workload = manifest["workload"]
    metadata = manifest["metadata"]
    destination_release_authority = {
        "workload": copy.deepcopy(workload),
        "source_validation": copy.deepcopy(
            manifest.get("source_validation"),
        ),
    }
    imported_from = copy.deepcopy(case.get("imported_from"))
    measurement_release_authority = (
        copy.deepcopy(destination_release_authority)
        if imported_from is None
        else copy.deepcopy(imported_from.get("source_authority"))
    )
    return {
        "destination_bundle_id": manifest["bundle_id"],
        "workload": {
            "workload_version": workload["workload_version"],
            "workload_digest": workload["workload_digest"],
            "release_status": copy.deepcopy(
                workload["release_status"],
            ),
        },
        "destination_release_authority": destination_release_authority,
        "measurement_release_authority": measurement_release_authority,
        "benchmark_release": case["benchmark_release"],
        "result_schema_version": case["result_schema_version"],
        "case": {
            "case_id": case["case_id"],
            "execution_instance_id": case["case_id"],
            "semantic_case_id": case["semantic_case_id"],
            "execution_spec_digest": case["execution_spec_digest"],
            "segment_id": result["segment_id"],
            "snapshot": copy.deepcopy(case.get("snapshot")),
            "imported_from": imported_from,
        },
        "environment": {
            field: copy.deepcopy(metadata[field])
            for field in _ENVIRONMENT_CONTEXT_FIELDS
        },
    }


def _context_differences(
    first: Any,
    second: Any,
    *,
    prefix: str = "",
) -> dict[str, list[Any]]:
    """Return stable dotted paths for context values that differ."""

    if isinstance(first, Mapping) and isinstance(second, Mapping):
        differences: dict[str, list[Any]] = {}
        for key in sorted(set(first) | set(second)):
            path = str(key) if not prefix else prefix + "." + str(key)
            if key not in first or key not in second:
                differences[path] = [
                    copy.deepcopy(first.get(key)),
                    copy.deepcopy(second.get(key)),
                ]
                continue
            differences.update(
                _context_differences(
                    first[key],
                    second[key],
                    prefix=path,
                )
            )
        return differences
    if first == second:
        return {}
    return {prefix: [copy.deepcopy(first), copy.deepcopy(second)]}


def compare_bundles(
    first: str | Path,
    second: str | Path,
    *,
    case_id: str | None = None,
    first_case_id: str | None = None,
    second_case_id: str | None = None,
    metric_name: str | None = None,
    migration_registry: Mapping[tuple[str, str], Migration] | None = None,
) -> dict[str, Any]:
    """Compare separate compatible metrics without merging raw samples."""

    if case_id is not None:
        if first_case_id is not None or second_case_id is not None:
            raise TypeError(
                "case_id cannot be combined with per-bundle case ids"
            )
        selected_case_ids = (case_id, case_id)
    else:
        if first_case_id is None or second_case_id is None:
            raise TypeError(
                "provide case_id or both first_case_id and second_case_id"
            )
        selected_case_ids = (first_case_id, second_case_id)
    _preflight_comparison_bundle_identities(first, second)
    documents = (load_bundle(first), load_bundle(second))
    try:
        cases = tuple(
            document["manifest"]["cases"][selected]
            for document, selected in zip(
                documents,
                selected_case_ids,
                strict=True,
            )
        )
        results = tuple(
            document["results"]["cases"][selected]
            for document, selected in zip(
                documents,
                selected_case_ids,
                strict=True,
            )
        )
    except KeyError as error:
        raise BundleCompatibilityError("comparison case is missing") from error
    if any(result["status"] != "completed" for result in results):
        raise BundleCompatibilityError(
            "comparison requires completed results"
        )
    for field in (
        "semantic_case_id",
        "semantic_case_digest",
        "semantic_projection_digest",
        "semantic_projection_version",
        "timing_protocol_digest",
    ):
        if cases[0].get(field) != cases[1].get(field):
            raise BundleCompatibilityError("comparison mismatch: " + field)
    versions = tuple(case["result_schema_version"] for case in cases)
    registry = MIGRATION_REGISTRY if migration_registry is None else migration_registry
    migration = registry.get(versions)
    if migration is None:
        raise BundleCompatibilityError(
            "comparison requires an explicit result schema migration"
        )
    migrated = (results[0], migration(results[1]))
    names = set(migrated[0]["metrics"]) & set(migrated[1]["metrics"])
    if metric_name is None:
        if len(names) != 1:
            raise BundleCompatibilityError("metric_name is required")
        metric_name = next(iter(names))
    if metric_name not in names:
        raise BundleCompatibilityError("metric is missing from one bundle")
    metrics = tuple(result["metrics"][metric_name] for result in migrated)
    if metrics[0]["definition"] != metrics[1]["definition"]:
        raise BundleCompatibilityError("metric definitions do not match")
    if metrics[0]["unit"] != metrics[1]["unit"]:
        raise BundleCompatibilityError("metric units do not match")
    contexts = [
        _comparison_context(document, case, result)
        for document, case, result in zip(
            documents,
            cases,
            results,
            strict=True,
        )
    ]
    destination_release_authorities = [
        copy.deepcopy(context["destination_release_authority"])
        for context in contexts
    ]
    measurement_release_authorities = [
        copy.deepcopy(context["measurement_release_authority"])
        for context in contexts
    ]
    return {
        "case_id": (
            selected_case_ids[0]
            if selected_case_ids[0] == selected_case_ids[1]
            else None
        ),
        "case_ids": list(selected_case_ids),
        "execution_spec_digests": [
            cases[0]["execution_spec_digest"],
            cases[1]["execution_spec_digest"],
        ],
        "metric_name": metric_name,
        "metric_definition": metrics[0]["definition"],
        "unit": metrics[0]["unit"],
        "values": [metrics[0]["value"], metrics[1]["value"]],
        "benchmark_releases": [
            cases[0]["benchmark_release"],
            cases[1]["benchmark_release"],
        ],
        "destination_release_authorities": (
            destination_release_authorities
        ),
        "measurement_release_authorities": (
            measurement_release_authorities
        ),
        "contexts": contexts,
        "differences": _context_differences(
            contexts[0],
            contexts[1],
        ),
    }
