#!/usr/bin/env python

"""Profile Road computation paths used by autonomous-driving observations.

The benchmark is intentionally deterministic and repo-local. It builds synthetic
roads, precomputes representative vehicle poses outside the timed region, then
times the Road methods in a sequential loop that mirrors an RL rollout:
successive calls pass the previous closest reference-line progress and element
index as hints.
"""

from __future__ import annotations

import argparse
import datetime as _datetime
import math
from pathlib import Path
import platform
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from dreamgym.profiling.common import (
    activate_matplotlib_profile_cache,
    display_output_path,
    resolve_profile_output_path,
)
from dreamgym.profiling.autonomous_driving import core_suites


Road: Any = None


def _ensure_road_runtime_imports() -> None:
    global Road

    activate_matplotlib_profile_cache("road-profile")
    if Road is None:
        from dreamgym.envs.road import Road as RoadClass

        Road = RoadClass


ELEMENT_COUNTS = (10, 50, 100, 200)
LOOKAHEAD_POINT_COUNTS = (0, 1, 2, 10, 100)
LOOKAHEAD_DISTANCE_M = 100.0
TARGET_LANE_INDEX = 1
TARGET_LANE_CENTER_OFFSET_M = 1.5
CONE_DETECTIONS_NUM_CONES_MAX = 20
ENV_LOOKAHEAD_FIELDS = frozenset((
    "target_line_lookahead.positions_in_body_frame_m",
    "target_line_lookahead.curvatures_per_m",
))
CRITICAL_REPEAT_CASES = (
    {
        "variant": "target_lane_no_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "target_lane",
        "lookahead_points": 0,
    },
    {
        "variant": "target_lane_1_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "target_lane",
        "lookahead_points": 1,
    },
    {
        "variant": "target_lane_100_lookahead_50_elements",
        "num_elements": 50,
        "tracking_mode": "target_lane",
        "lookahead_points": 100,
    },
    {
        "variant": "target_lane_100_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "target_lane",
        "lookahead_points": 100,
    },
    {
        "variant": "reference_line_100_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "reference_line",
        "lookahead_points": 100,
    },
    {
        "variant": "fixed_offset_1p5m_100_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "fixed_offset_1p5m",
        "lookahead_points": 100,
    },
)
CRITICAL_COMPONENT_CASES = (
    {
        "variant": "target_lane_100_lookahead_50_elements",
        "num_elements": 50,
        "tracking_mode": "target_lane",
        "lookahead_points": 100,
    },
    {
        "variant": "target_lane_100_lookahead_200_elements",
        "num_elements": 200,
        "tracking_mode": "target_lane",
        "lookahead_points": 100,
    },
)


class RolloutState:
    def __init__(self) -> None:
        self.previous_progress: Optional[float] = None
        self.previous_element_idx: Optional[int] = None
        self.previous_px: Optional[float] = None
        self.previous_py: Optional[float] = None

    def reset_hint(self) -> None:
        self.previous_progress = None
        self.previous_element_idx = None
        self.previous_px = None
        self.previous_py = None


def build_road_spec(
    num_elements: int,
    *,
    include_cones: bool = False,
    tapered_lane: bool = False,
    include_lane: bool = True,
) -> Dict:
    elements = []
    for element_idx in range(num_elements):
        speed_limit_kph = 80.0 if element_idx % 5 else 60.0
        if element_idx % 3 == 1:
            curvature_sign = 1.0 if (element_idx // 3) % 2 == 0 else -1.0
            element = {
                "geometry": {
                    "type": "circular_arc",
                    "curvature_per_m": (
                        curvature_sign / (45.0 + 5.0 * (element_idx % 4))
                    ),
                    "length_m": 20.0 + 2.0 * (element_idx % 5),
                },
                "speed_limit_kph": speed_limit_kph,
            }
        else:
            element = {
                "geometry": {
                    "type": "straight",
                    "length_m": 28.0 + 3.0 * (element_idx % 4),
                },
                "speed_limit_kph": speed_limit_kph,
            }

        if include_lane and element_idx == 0:
            element["lanes"] = {
                "reference_line_role": "lane_boundary",
                "left": [{"width_m": {"start": 3.0}}],
                "right": [],
            }
            element["cross_section_width_interpolation"] = "linear"
            if include_cones:
                element["cones"] = [
                    {
                        "placement": {
                            "mode": "reference_line",
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "yellow",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                    {
                        "placement": {
                            "mode": "lane_line",
                            "lane_line_index": 1,
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "blue",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                ]

        if include_lane and tapered_lane and element_idx % 10 == 4:
            element["lanes"] = {
                "reference_line_role": "lane_boundary",
                "left": [{"width_m": {"start": 3.0, "end": 2.4}}],
                "right": [],
            }
            element["cross_section_width_interpolation"] = "smoothstep"
        elif include_lane and tapered_lane and element_idx % 10 == 5:
            element["lanes"] = {
                "reference_line_role": "lane_boundary",
                "left": [{"width_m": {"start": 2.4, "end": 3.0}}],
                "right": [],
            }
            element["cross_section_width_interpolation"] = "smoothstep"

        elements.append(element)

    return {
        "active_lane_minimum_width_m": 0.02,
        "defaults": {"speed_limit_kph": 80.0},
        "elements": elements,
    }


def make_lookahead_queries(num_points: int) -> np.ndarray:
    if num_points <= 0:
        return np.array([], dtype=np.float32)
    increment = LOOKAHEAD_DISTANCE_M / float(num_points)
    return np.linspace(
        increment,
        LOOKAHEAD_DISTANCE_M,
        num=num_points,
        endpoint=True,
        dtype=np.float32,
    )


def target_offset_for_tracking_mode(tracking_mode: str) -> float:
    if tracking_mode == "reference_line":
        return 0.0
    if tracking_mode in ("target_lane", "fixed_offset_1p5m"):
        return TARGET_LANE_CENTER_OFFSET_M
    raise ValueError("Unknown tracking_mode: " + str(tracking_mode))


def target_line_config_for_tracking_mode(tracking_mode: str) -> Dict:
    if tracking_mode == "target_lane":
        return {
            "mode": "lane_center",
            "lane_index": TARGET_LANE_INDEX,
            "require_active_lane": True,
        }
    if tracking_mode == "fixed_offset_1p5m":
        return {
            "mode": "fixed_offset",
            "offset_from_reference_line_m": TARGET_LANE_CENTER_OFFSET_M,
        }
    if tracking_mode == "reference_line":
        return {"mode": "reference_line"}
    raise ValueError("Unknown tracking_mode: " + str(tracking_mode))


def precompute_rollout_poses(
    road: Road,
    num_steps: int,
    *,
    target_offset_m: float,
    step_m: float = 2.0,
) -> Dict[str, np.ndarray]:
    total_length = float(road.total_length_m)
    start_progress = 5.0
    usable_length = max(total_length - LOOKAHEAD_DISTANCE_M - start_progress - 5.0, 1.0)
    raw_distance = np.arange(num_steps, dtype=np.float32) * np.float32(step_m)
    progress = start_progress + np.mod(raw_distance, usable_length)
    wraps = np.empty(progress.shape, dtype=bool)
    wraps[0] = True
    wraps[1:] = progress[1:] < progress[:-1]

    reference_points, reference_angles = road.convert_progression_to_coordinates(progress)
    left_normals = np.column_stack((-np.sin(reference_angles), np.cos(reference_angles))).astype(np.float32)
    lateral_error = (0.15 * np.sin(0.11 * np.arange(num_steps))).astype(np.float32)
    pose_offsets = target_offset_m + lateral_error
    pose_points = reference_points + pose_offsets[:, None] * left_normals
    theta = (reference_angles + 0.03 * np.cos(0.07 * np.arange(num_steps))).astype(np.float32)

    movement_l1 = np.zeros((num_steps,), dtype=np.float32)
    if num_steps > 1:
        movement_l1[1:] = (
            np.abs(pose_points[1:, 0] - pose_points[:-1, 0]) +
            np.abs(pose_points[1:, 1] - pose_points[:-1, 1])
        )

    return {
        "progress": progress.astype(np.float32),
        "px": pose_points[:, 0].astype(np.float32),
        "py": pose_points[:, 1].astype(np.float32),
        "theta": theta,
        "wraps": wraps,
        "movement_l1": movement_l1,
    }


def call_road_info_rl_style(
    road: Road,
    poses: Dict[str, np.ndarray],
    state: RolloutState,
    step_idx: int,
    *,
    progress_queries: np.ndarray,
    tracking_mode: str,
    lookahead_output_fields: Iterable[str],
    include_next_speed_changes: bool = False,
) -> Tuple[float, Dict]:
    if bool(poses["wraps"][step_idx]):
        state.reset_hint()

    px = float(poses["px"][step_idx])
    py = float(poses["py"][step_idx])
    theta = float(poses["theta"][step_idx])

    if state.previous_progress is None:
        progress_search = None
    else:
        search_radius = float(poses["movement_l1"][step_idx]) + 0.5
        progress_search = {
            "lower_bound_m": max(0.0, state.previous_progress - search_radius),
            "upper_bound_m": min(
                float(road.total_length_m),
                state.previous_progress + search_radius,
            ),
        }

    info = road.road_info_at_given_pose_and_progress_queries(
        px=px,
        py=py,
        theta=theta,
        target_line_lookahead_distances_m=progress_queries,
        target_line_config=target_line_config_for_tracking_mode(tracking_mode),
        reference_line_progress_search=progress_search,
        include_next_speed_limit_change=include_next_speed_changes,
        include_next_recommended_speed_change=include_next_speed_changes,
        lookahead_result_fields=lookahead_output_fields,
    )

    closest = info["reference_line"]["closest_point"]
    state.previous_progress = float(closest["progress_m"])
    state.previous_element_idx = int(closest["road_element_index"])
    state.previous_px = px
    state.previous_py = py

    sink = float(
        info["target_line"]["tracking_error"][
            "lateral_error_from_target_line_m"
        ]
    )
    lookahead = info.get("target_line_lookahead", {})
    curvatures = lookahead.get("curvatures_per_m")
    if curvatures is not None and len(curvatures) > 0:
        sink += float(np.sum(curvatures))
    points = lookahead.get("positions_in_body_frame_m")
    if points is not None and len(points) > 0:
        sink += float(points[-1, 0])
    next_speed_limit = info.get("next_speed_limit_change")
    if next_speed_limit is not None:
        sink += float(next_speed_limit["value_mps"])
    return sink, info


def call_road_info_global_search(
    road: Road,
    poses: Dict[str, np.ndarray],
    step_idx: int,
    *,
    progress_queries: np.ndarray,
    tracking_mode: str,
    lookahead_output_fields: Iterable[str],
) -> float:
    info = road.road_info_at_given_pose_and_progress_queries(
        px=float(poses["px"][step_idx]),
        py=float(poses["py"][step_idx]),
        theta=float(poses["theta"][step_idx]),
        target_line_lookahead_distances_m=progress_queries,
        target_line_config=target_line_config_for_tracking_mode(tracking_mode),
        reference_line_progress_search=None,
        include_next_speed_limit_change=False,
        include_next_recommended_speed_change=False,
        lookahead_result_fields=lookahead_output_fields,
    )
    return float(
        info["target_line"]["tracking_error"][
            "lateral_error_from_target_line_m"
        ]
    )


def call_road_info_with_precomputed_hint(
    road: Road,
    poses: Dict[str, np.ndarray],
    step_idx: int,
    *,
    reference_line_progress_m: float,
    progress_queries: np.ndarray,
    tracking_mode: str,
    lookahead_output_fields: Iterable[str],
    include_next_speed_changes: bool = False,
) -> float:
    """Query one pose with its independently primed local hint only."""

    info = road.road_info_at_given_pose_and_progress_queries(
        px=float(poses["px"][step_idx]),
        py=float(poses["py"][step_idx]),
        theta=float(poses["theta"][step_idx]),
        target_line_lookahead_distances_m=progress_queries,
        target_line_config=target_line_config_for_tracking_mode(tracking_mode),
        reference_line_progress_search={
            "lower_bound_m": max(0.0, reference_line_progress_m - 0.5),
            "upper_bound_m": min(
                float(road.total_length_m),
                reference_line_progress_m + 0.5,
            ),
        },
        include_next_speed_limit_change=include_next_speed_changes,
        include_next_recommended_speed_change=include_next_speed_changes,
        lookahead_result_fields=lookahead_output_fields,
    )
    sink = float(
        info["target_line"]["tracking_error"][
            "lateral_error_from_target_line_m"
        ]
    )
    lookahead = info.get("target_line_lookahead", {})
    curvatures = lookahead.get("curvatures_per_m")
    if curvatures is not None:
        sink += float(np.sum(curvatures))
    points = lookahead.get("positions_in_body_frame_m")
    if points is not None and len(points) > 0:
        sink += float(points[-1, 0])
    next_speed_limit = info.get("next_speed_limit_change")
    if next_speed_limit is not None:
        sink += float(next_speed_limit["value_mps"])
    return sink


def summarize_times(times_ns: np.ndarray) -> Dict[str, float]:
    return core_suites.specialist_timing_row(times_ns)


def time_loop(
    callback: Callable[[int], float],
    *,
    iterations: int,
    warmup: int,
) -> Dict[str, float]:
    samples_ns, sink = core_suites.measure_indexed_callable_ns(
        callback,
        warmup_calls=warmup,
        sample_count=iterations,
        clock_ns=time.perf_counter_ns,
        suppress_gc=True,
    )
    return core_suites.specialist_timing_row(samples_ns, sink=sink)


def repeated_time_loop(
    callback_factory: Callable[[], Callable[[int], float]],
    *,
    repeats: int,
    iterations: int,
    warmup: int,
) -> List[Dict[str, float]]:
    rows = []
    for repeat_idx in range(repeats):
        row = time_loop(
            callback_factory(),
            iterations=iterations,
            warmup=warmup,
        )
        row["repeat_idx"] = repeat_idx
        rows.append(row)
    return rows


def summarize_repeated_timing_rows(repeat_rows: Sequence[Dict[str, float]]) -> Dict[str, float]:
    medians = np.array([row["median_us"] for row in repeat_rows], dtype=np.float64)
    p95s = np.array([row["p95_us"] for row in repeat_rows], dtype=np.float64)
    means = np.array([row["mean_us"] for row in repeat_rows], dtype=np.float64)
    median_of_medians = float(np.median(medians))
    if median_of_medians > 0.0:
        spread_pct = float((np.max(medians) - np.min(medians)) / median_of_medians * 100.0)
    else:
        spread_pct = float("nan")

    return {
        "repeats": len(repeat_rows),
        "min_run_median_us": float(np.min(medians)),
        "median_run_median_us": median_of_medians,
        "max_run_median_us": float(np.max(medians)),
        "median_run_p95_us": float(np.median(p95s)),
        "median_run_mean_us": float(np.median(means)),
        "run_median_spread_pct": spread_pct,
        "run_medians_us": ", ".join(format_float(float(value), 1) for value in medians),
    }


def benchmark_main_matrix(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = ELEMENT_COUNTS,
    lookahead_counts: Sequence[int] = LOOKAHEAD_POINT_COUNTS,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    for num_elements in element_counts:
        for tracking_mode in ("reference_line", "target_lane"):
            for num_lookahead_points in lookahead_counts:
                fixture = {
                    "variant": (
                        tracking_mode
                        + "_"
                        + str(num_lookahead_points)
                        + "_lookahead_"
                        + str(num_elements)
                        + "_elements"
                    ),
                    "num_elements": num_elements,
                    "tracking_mode": tracking_mode,
                    "lookahead_points": num_lookahead_points,
                    "include_cones": False,
                    "tapered_lane": False,
                    "include_next_speed_changes": False,
                    "operation": "full",
                }
                case = core_suites.build_road_profile_case(fixture)
                execution = core_suites.build_specialist_execution_spec(
                    case,
                    warmup_iterations=warmup,
                    sample_count=iterations,
                )
                result = core_suites.execute_core_case(
                    case,
                    execution,
                    clock_ns=clock_ns,
                )
                row = {
                    "category": "main",
                    "num_elements": num_elements,
                    "tracking_mode": tracking_mode,
                    "lookahead_points": num_lookahead_points,
                    "lookahead_fields": "env_body_points_plus_curvature" if num_lookahead_points > 0 else "none",
                    "include_next_speed_changes": False,
                }
                row.update(
                    core_suites.specialist_row_from_case_result(case, result)
                )
                row["shared_overlap_key"] = "road.main.full"
                rows.append(row)
    return rows


def benchmark_cone_cases(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = ELEMENT_COUNTS,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    operations = (
        ("road_info_only", "full"),
        ("cone_filter_only_cached_points", "cone_filter_only"),
        ("road_info_plus_cones", "road_info_plus_cones"),
    )
    for num_elements in element_counts:
        for variant_name, operation in operations:
            fixture = {
                "variant": variant_name,
                "num_elements": num_elements,
                "tracking_mode": "target_lane",
                "lookahead_points": 0,
                "include_cones": True,
                "tapered_lane": False,
                "include_next_speed_changes": False,
                "operation": operation,
                **(
                    {"cone_generation_seed": 123}
                    if operation
                    in {"cone_filter_only", "road_info_plus_cones"}
                    else {}
                ),
            }
            case = core_suites.build_road_profile_case(fixture)
            execution = core_suites.build_specialist_execution_spec(
                case,
                warmup_iterations=warmup,
                sample_count=iterations,
            )
            result = core_suites.execute_core_case(
                case,
                execution,
                clock_ns=clock_ns,
            )
            row = {
                "category": "cones",
                "num_elements": num_elements,
                "variant": variant_name,
                "tracking_mode": "target_lane",
                "lookahead_points": 0,
            }
            row.update(
                core_suites.specialist_row_from_case_result(case, result)
            )
            row["shared_overlap_key"] = {
                "road_info_only": "road.cones.road_info_only",
                "cone_filter_only_cached_points": (
                    "road.cones.cone_filter_only"
                ),
                "road_info_plus_cones": (
                    "road.cones.road_info_plus_cones"
                ),
            }[variant_name]
            rows.append(row)
    return rows


def benchmark_construction_cases(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = ELEMENT_COUNTS,
    variants: Sequence[Tuple[str, Dict]] | None = None,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    if variants is None:
        variants = (
            ("reference_line_only", {"include_lane": False}),
            ("constant_width_lane", {}),
            ("with_cone_specs_no_generation", {"include_cones": True}),
            ("tapered_lane", {"tapered_lane": True}),
        )

    for num_elements in element_counts:
        for variant_name, build_kwargs in variants:
            fixture = {
                "variant": variant_name,
                "num_elements": num_elements,
                "tracking_mode": "target_lane",
                "lookahead_points": 0,
                "include_cones": bool(
                    build_kwargs.get("include_cones", False)
                ),
                "tapered_lane": bool(
                    build_kwargs.get("tapered_lane", False)
                ),
                "include_lane": bool(
                    build_kwargs.get("include_lane", True)
                ),
                "include_next_speed_changes": False,
                "operation": "construction",
            }
            row = {
                "category": "construction",
                "num_elements": num_elements,
                "variant": variant_name,
            }
            row.update(
                core_suites.execute_specialist_overlap(
                    (
                        "road.construction.constant_width"
                        if variant_name == "constant_width_lane"
                        else "road.construction.specialist." + variant_name
                    ),
                    "road",
                    fixture,
                    warmup_iterations=warmup,
                    sample_count=iterations,
                    clock_ns=clock_ns,
                )
            )
            row["median_ms"] = row["median_us"] / 1000.0
            row["p95_ms"] = row["p95_us"] / 1000.0
            row["mean_ms"] = row["mean_us"] / 1000.0
            rows.append(row)
    return rows


def benchmark_extra_cases(
    iterations: int,
    warmup: int,
    *,
    element_counts: Sequence[int] = (50, 200),
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    for num_elements in element_counts:
        extra_specs = (
            {
                "variant": "fixed_offset_1p5m_no_lookahead",
                "tracking_mode": "fixed_offset_1p5m",
                "lookahead_points": 0,
                "lookahead_output_fields": "none",
                "include_next_speed_changes": False,
                "operation": "full",
                "tapered_lane": False,
                "shared_overlap_key": "road.extra.fixed_offset",
            },
            {
                "variant": "target_lane_no_lookahead_with_next_speed_changes",
                "tracking_mode": "target_lane",
                "lookahead_points": 0,
                "lookahead_output_fields": "none",
                "include_next_speed_changes": True,
                "operation": "full",
                "tapered_lane": False,
                "shared_overlap_key": "road.extra.rollout_speed_changes",
            },
            {
                "variant": "reference_line_no_lookahead_global_search",
                "tracking_mode": "reference_line",
                "lookahead_points": 0,
                "lookahead_output_fields": "none",
                "include_next_speed_changes": False,
                "operation": "global_search",
                "tapered_lane": False,
                "shared_overlap_key": "road.extra.global_search",
            },
            {
                "variant": "target_lane_100_point_full_lookahead_fields",
                "tracking_mode": "target_lane",
                "lookahead_points": 100,
                "lookahead_output_fields": "all",
                "include_next_speed_changes": False,
                "operation": "full",
                "tapered_lane": False,
                "shared_overlap_key": (
                    "road.extra.rollout_large_lookahead"
                ),
            },
            {
                "variant": "tapered_target_lane_100_point_env_lookahead",
                "tracking_mode": "target_lane",
                "lookahead_points": 100,
                "lookahead_output_fields": "environment",
                "include_next_speed_changes": False,
                "operation": "full",
                "tapered_lane": True,
                "shared_overlap_key": "road.extra.rollout_tapered",
            },
        )

        for spec in extra_specs:
            fixture = {
                "variant": spec["variant"],
                "num_elements": num_elements,
                "tracking_mode": spec["tracking_mode"],
                "lookahead_points": spec["lookahead_points"],
                "lookahead_output_fields": spec[
                    "lookahead_output_fields"
                ],
                "include_cones": False,
                "tapered_lane": spec["tapered_lane"],
                "include_next_speed_changes": spec[
                    "include_next_speed_changes"
                ],
                "operation": spec["operation"],
            }
            row = {
                "category": "extra",
                "num_elements": num_elements,
                "variant": spec["variant"],
                "tracking_mode": spec["tracking_mode"],
                "lookahead_points": spec["lookahead_points"],
                "lookahead_fields": (
                    "all"
                    if spec["lookahead_output_fields"] == "all"
                    else (
                        "env_body_points_plus_curvature"
                        if spec["lookahead_output_fields"] == "environment"
                        else "none"
                    )
                ),
                "include_next_speed_changes": spec["include_next_speed_changes"],
                "search_mode": (
                    "global_every_call"
                    if spec["operation"] == "global_search"
                    else "rl_local_hints"
                ),
            }
            row.update(
                core_suites.execute_specialist_overlap(
                    spec["shared_overlap_key"],
                    "road",
                    fixture,
                    warmup_iterations=warmup,
                    sample_count=iterations,
                    clock_ns=clock_ns,
                )
            )
            rows.append(row)
    return rows


def benchmark_critical_repeat_cases(
    *,
    repeats: int,
    iterations: int,
    warmup: int,
    case_specs: Sequence[Dict] = CRITICAL_REPEAT_CASES,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    rows = []
    for spec in case_specs:
        fixture = {
            **spec,
            "include_cones": False,
            "tapered_lane": False,
            "include_next_speed_changes": False,
            "lookahead_output_fields": "environment",
            "operation": "full",
        }
        repeat_rows = [
            core_suites.execute_specialist_overlap(
                "road.critical_repeat.full",
                "road",
                fixture,
                warmup_iterations=warmup,
                sample_count=iterations,
                clock_ns=clock_ns,
            )
            for _ in range(repeats)
        ]
        row = {
            "category": "critical_repeat",
            "variant": spec["variant"],
            "num_elements": spec["num_elements"],
            "tracking_mode": spec["tracking_mode"],
            "lookahead_points": spec["lookahead_points"],
            "lookahead_fields": "env_body_points_plus_curvature" if spec["lookahead_points"] > 0 else "none",
        }
        row.update(summarize_repeated_timing_rows(repeat_rows))
        row["shared_overlap_key"] = "road.critical_repeat.full"
        row["shared_overlap_results"] = repeat_rows
        rows.append(row)

    return rows


def precompute_critical_component_inputs(
    road: Road,
    poses: Dict[str, np.ndarray],
    *,
    tracking_mode: str,
    progress_queries: np.ndarray,
    num_steps: int,
) -> Dict:
    geom = road._Road__target_geometry()
    target_line_config = target_line_config_for_tracking_mode(tracking_mode)

    px = poses["px"].astype(np.float32, copy=False)
    py = poses["py"].astype(np.float32, copy=False)
    theta = poses["theta"].astype(np.float32, copy=False)
    cos_theta = np.cos(theta).astype(np.float32, copy=False)
    sin_theta = np.sin(theta).astype(np.float32, copy=False)
    closest_progresses = np.empty((num_steps,), dtype=np.float32)

    state = RolloutState()
    for step_idx in range(num_steps):
        if bool(poses["wraps"][step_idx]):
            state.reset_hint()

        if state.previous_progress is None:
            progress_hint = None
            element_hint = None
            search_radius = None
            allow_global = True
        else:
            progress_hint = state.previous_progress
            element_hint = state.previous_element_idx
            search_radius = float(poses["movement_l1"][step_idx]) + 0.5
            allow_global = False

        result = road.find_closest_point_to(
            px=float(px[step_idx]),
            py=float(py[step_idx]),
            reference_line_progress_hint=progress_hint,
            reference_line_element_index_hint=element_hint,
            reference_line_progress_search_radius_m=search_radius,
            allow_global_closest_point_fallback=allow_global,
        )
        closest_progresses[step_idx] = np.float32(result[4])
        state.previous_progress = float(result[4])
        state.previous_element_idx = int(result[6])

    mapped_progresses = []
    mapped_metadata = []
    reference_samples = []
    for step_idx in range(num_steps):
        progresses, metadata = (
            geom.reference_progresses_for_target_line_config_distances(
            float(closest_progresses[step_idx]),
            progress_queries,
            target_line_config,
            return_metadata=True,
        )
        )
        mapped_progresses.append(progresses)
        mapped_metadata.append(metadata)
        reference_samples.append(
            geom.reference_line_samples_at_progresses(
                progresses,
                include_coordinates=True,
                include_angles=True,
                include_curvatures=True,
                include_speeds=False,
                include_element_indices=False,
                element_indices=metadata["element_indices"],
                element_indices_are_trusted=metadata["element_indices_are_trusted"],
                progression_queries_are_in_bounds=metadata["progression_queries_are_in_bounds"],
            )
        )

    return {
        "geom": geom,
        "target_line_config": target_line_config,
        "px": px,
        "py": py,
        "cos_theta": cos_theta,
        "sin_theta": sin_theta,
        "closest_progresses": closest_progresses,
        "mapped_progresses": mapped_progresses,
        "mapped_metadata": mapped_metadata,
        "reference_samples": reference_samples,
    }


def closest_point_component_callback_factory(road: Road, poses: Dict[str, np.ndarray]) -> Callable[[int], float]:
    state = RolloutState()

    def callback(step_idx: int) -> float:
        if bool(poses["wraps"][step_idx]):
            state.reset_hint()

        if state.previous_progress is None:
            progress_hint = None
            element_hint = None
            search_radius = None
            allow_global = True
        else:
            progress_hint = state.previous_progress
            element_hint = state.previous_element_idx
            search_radius = float(poses["movement_l1"][step_idx]) + 0.5
            allow_global = False

        result = road.find_closest_point_to(
            px=float(poses["px"][step_idx]),
            py=float(poses["py"][step_idx]),
            reference_line_progress_hint=progress_hint,
            reference_line_element_index_hint=element_hint,
            reference_line_progress_search_radius_m=search_radius,
            allow_global_closest_point_fallback=allow_global,
        )
        state.previous_progress = float(result[4])
        state.previous_element_idx = int(result[6])
        return float(result[4])

    return callback


def benchmark_critical_component_breakdown(
    *,
    repeats: int,
    iterations: int,
    warmup: int,
    case_specs: Sequence[Dict] = CRITICAL_COMPONENT_CASES,
    clock_ns: Callable[[], int] = time.perf_counter_ns,
) -> List[Dict]:
    _ensure_road_runtime_imports()
    rows = []
    num_steps = max(iterations, warmup, 1)

    for spec in case_specs:
        road = Road(road_spec=build_road_spec(spec["num_elements"]))
        poses = precompute_rollout_poses(
            road,
            num_steps,
            target_offset_m=target_offset_for_tracking_mode(spec["tracking_mode"]),
        )
        progress_queries = make_lookahead_queries(spec["lookahead_points"])
        lookahead_fields = ENV_LOOKAHEAD_FIELDS
        component_inputs = precompute_critical_component_inputs(
            road,
            poses,
            tracking_mode=spec["tracking_mode"],
            progress_queries=progress_queries,
            num_steps=num_steps,
        )
        geom = component_inputs["geom"]
        target_line_config = component_inputs["target_line_config"]

        def full_callback_factory(
            road=road,
            poses=poses,
            progress_queries=progress_queries,
            tracking_mode=spec["tracking_mode"],
            lookahead_fields=lookahead_fields,
        ) -> Callable[[int], float]:
            state = RolloutState()

            def callback(step_idx: int) -> float:
                value, _ = call_road_info_rl_style(
                    road,
                    poses,
                    state,
                    step_idx,
                    progress_queries=progress_queries,
                    tracking_mode=tracking_mode,
                    lookahead_output_fields=lookahead_fields,
                    include_next_speed_changes=False,
                )
                return value

            return callback

        def mapping_callback(step_idx: int) -> float:
            progresses, _metadata = (
                geom.reference_progresses_for_target_line_config_distances(
                float(component_inputs["closest_progresses"][step_idx]),
                progress_queries,
                target_line_config,
                return_metadata=True,
            )
            )
            return float(progresses[-1]) if progresses.size > 0 else 0.0

        def reference_sampling_callback(step_idx: int) -> float:
            metadata = component_inputs["mapped_metadata"][step_idx]
            samples = geom.reference_line_samples_at_progresses(
                component_inputs["mapped_progresses"][step_idx],
                include_coordinates=True,
                include_angles=True,
                include_curvatures=True,
                include_speeds=False,
                include_element_indices=False,
                element_indices=metadata["element_indices"],
                element_indices_are_trusted=metadata["element_indices_are_trusted"],
                progression_queries_are_in_bounds=metadata["progression_queries_are_in_bounds"],
            )
            sink = 0.0
            if "coordinates" in samples and samples["coordinates"].size > 0:
                sink += float(samples["coordinates"][-1, 0])
            if "curvatures" in samples and samples["curvatures"].size > 0:
                sink += float(np.sum(samples["curvatures"]))
            return sink

        def target_geometry_callback(step_idx: int) -> float:
            samples = (
                geom.target_line_geometry_from_reference_samples_for_config(
                component_inputs["mapped_progresses"][step_idx],
                component_inputs["reference_samples"][step_idx],
                target_line_config,
                include_offsets=False,
                include_points=False,
                include_body_points=True,
                body_frame_pose=(
                    float(component_inputs["px"][step_idx]),
                    float(component_inputs["py"][step_idx]),
                    float(component_inputs["cos_theta"][step_idx]),
                    float(component_inputs["sin_theta"][step_idx]),
                ),
                include_angles=False,
                include_curvatures=True,
                include_speed_scale=False,
            )
            )
            sink = 0.0
            if "body_points" in samples and samples["body_points"].size > 0:
                sink += float(samples["body_points"][-1, 0])
            if "curvatures" in samples and samples["curvatures"].size > 0:
                sink += float(np.sum(samples["curvatures"]))
            return sink

        def direct_constant_offset_lookahead_callback(step_idx: int) -> float:
            samples = (
                geom.constant_target_line_body_points_lookahead_for_config_if_available(
                float(component_inputs["closest_progresses"][step_idx]),
                progress_queries,
                float(component_inputs["px"][step_idx]),
                float(component_inputs["py"][step_idx]),
                float(component_inputs["cos_theta"][step_idx]),
                float(component_inputs["sin_theta"][step_idx]),
                target_line_config,
                include_curvatures=True,
            )
            )
            if samples is None:
                return 0.0
            sink = 0.0
            if "body_points" in samples and samples["body_points"].size > 0:
                sink += float(samples["body_points"][-1, 0])
            if "curvatures" in samples and samples["curvatures"].size > 0:
                sink += float(np.sum(samples["curvatures"]))
            return sink

        component_factories = (
            ("full_road_info", full_callback_factory),
            ("closest_point_search", lambda road=road, poses=poses: closest_point_component_callback_factory(road, poses)),
            ("constant_offset_direct_body_points_curvature", lambda: direct_constant_offset_lookahead_callback),
            ("target_distance_to_reference_progress", lambda: mapping_callback),
            ("reference_line_sampling", lambda: reference_sampling_callback),
            ("target_line_geometry_body_points_curvature", lambda: target_geometry_callback),
        )

        case_rows = []
        for component_name, callback_factory in component_factories:
            shared_overlap_key = None
            shared_results = None
            if component_name in ("full_road_info", "closest_point_search"):
                shared_overlap_key = (
                    "road.critical_component.full"
                    if component_name == "full_road_info"
                    else "road.critical_component.closest_point"
                )
                fixture = {
                    **spec,
                    "include_cones": False,
                    "tapered_lane": False,
                    "include_next_speed_changes": False,
                    "lookahead_output_fields": "environment",
                    "operation": (
                        "full"
                        if component_name == "full_road_info"
                        else "closest_point_component"
                    ),
                }
                shared_results = [
                    core_suites.execute_specialist_overlap(
                        shared_overlap_key,
                        "road",
                        fixture,
                        warmup_iterations=warmup,
                        sample_count=iterations,
                        clock_ns=clock_ns,
                    )
                    for _ in range(repeats)
                ]
                repeat_rows = shared_results
            else:
                repeat_rows = repeated_time_loop(
                    callback_factory,
                    repeats=repeats,
                    iterations=iterations,
                    warmup=warmup,
                )
            row = {
                "category": "critical_component",
                "variant": spec["variant"],
                "num_elements": spec["num_elements"],
                "tracking_mode": spec["tracking_mode"],
                "lookahead_points": spec["lookahead_points"],
                "component": component_name,
            }
            row.update(summarize_repeated_timing_rows(repeat_rows))
            if shared_overlap_key is not None:
                row["shared_overlap_key"] = shared_overlap_key
                row["shared_overlap_results"] = shared_results
            case_rows.append(row)

        full_median = [
            row["median_run_median_us"]
            for row in case_rows
            if row["component"] == "full_road_info"
        ][0]
        for row in case_rows:
            row["share_of_full_median_pct"] = (
                100.0 * row["median_run_median_us"] / full_median
                if full_median > 0.0 else float("nan")
            )
        rows.extend(case_rows)

    return rows


def format_float(value: float, digits: int = 2) -> str:
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return str(value)
    return f"{value:.{digits}f}"


def markdown_table(rows: Sequence[Dict], columns: Sequence[Tuple[str, str]], *, digits: int = 2) -> str:
    lines = []
    lines.append("| " + " | ".join(header for _, header in columns) + " |")
    lines.append("| " + " | ".join("---" for _ in columns) + " |")
    for row in rows:
        values = []
        for key, _ in columns:
            value = row.get(key, "")
            if isinstance(value, float):
                if key == "calls_per_s":
                    values.append(format_float(value, 0))
                elif key.endswith("_ms"):
                    values.append(format_float(value, 3))
                else:
                    values.append(format_float(value, digits))
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def write_markdown_report(
    output_path: Path,
    *,
    main_rows: Sequence[Dict],
    cone_rows: Sequence[Dict],
    construction_rows: Sequence[Dict],
    extra_rows: Sequence[Dict],
    iterations: int,
    warmup: int,
    construction_iterations: int,
    construction_warmup: int,
    elapsed_s: float,
) -> None:
    now = _datetime.datetime.now().astimezone()

    fastest_main = min(main_rows, key=lambda row: row["median_us"])
    slowest_main = max(main_rows, key=lambda row: row["median_us"])
    no_lookahead_target_200 = [
        row for row in main_rows
        if row["num_elements"] == 200 and row["tracking_mode"] == "target_lane" and row["lookahead_points"] == 0
    ][0]
    lookahead_100_target_200 = [
        row for row in main_rows
        if row["num_elements"] == 200 and row["tracking_mode"] == "target_lane" and row["lookahead_points"] == 100
    ][0]
    construction_constant_lane_200 = [
        row for row in construction_rows
        if row["num_elements"] == 200 and row["variant"] == "constant_width_lane"
    ][0]

    text = []
    text.append("# Road Computation-Time Profile")
    text.append("")
    text.append(
        "This file is generated by `python scripts/profile_road.py`."
    )
    text.append("")
    text.append("## Environment")
    text.append("")
    text.append(f"- Generated: {now.isoformat(timespec='seconds')}")
    text.append(f"- Python: {platform.python_version()}")
    text.append(f"- NumPy: {np.__version__}")
    text.append(f"- Platform: {platform.platform()}")
    text.append(f"- Timed iterations per case: {iterations}")
    text.append(f"- Warmup iterations per case: {warmup}")
    text.append(f"- Construction timed iterations per case: {construction_iterations}")
    text.append(f"- Construction warmup iterations per case: {construction_warmup}")
    text.append(f"- Total script runtime: {elapsed_s:.2f} s")
    text.append("")
    text.append("## Method")
    text.append("")
    text.append(
        "Each case uses a deterministic synthetic road with alternating straight "
        "and curved elements. The first element defines a 3.0 m lane on the left "
        "of the reference line, and later elements inherit that lane metadata."
    )
    text.append("")
    text.append(
        "Vehicle poses are precomputed outside the timed region. During timing, "
        "the call sequence advances along the road like an RL rollout. Each call "
        "passes the previous closest reference-line progress and element index "
        "back into `Road.road_info_at_given_pose_and_progress_queries`, together "
        "with a conservative local search radius derived from pose movement. "
        "At episode-like wrap points the hint is reset and the first call uses "
        "global closest-point search."
    )
    text.append("")
    text.append(
        "Lookahead queries match the Gym environment convention: for `N` lookahead "
        "points, the query distances are evenly spaced from `100/N` m to `100` m "
        "along the target line. The main lookahead cases request only the fields "
        "that the environment normally needs for lookahead observations: body-frame "
        "target-line points and target-line curvatures."
    )
    text.append("")
    text.append(
        "`reference_line` means the target line is the reference line. "
        "`target_lane` means lane index `+1`, i.e. the center of the first lane "
        "to the left of the reference line."
    )
    text.append("")
    text.append("## Quick Read")
    text.append("")
    text.append(
        f"- Fastest main case: {fastest_main['num_elements']} elements, "
        f"{fastest_main['tracking_mode']}, {fastest_main['lookahead_points']} lookahead points, "
        f"median {fastest_main['median_us']:.2f} us."
    )
    text.append(
        f"- Slowest main case: {slowest_main['num_elements']} elements, "
        f"{slowest_main['tracking_mode']}, {slowest_main['lookahead_points']} lookahead points, "
        f"median {slowest_main['median_us']:.2f} us."
    )
    text.append(
        f"- For the 200-element target-lane case, no lookahead is "
        f"{no_lookahead_target_200['median_us']:.2f} us median; "
        f"100 lookahead points is {lookahead_100_target_200['median_us']:.2f} us median."
    )
    text.append(
        f"- Building a 200-element constant-width lane road is "
        f"{construction_constant_lane_200['median_ms']:.3f} ms median."
    )
    text.append("")
    text.append("## Main Road Info Cases")
    text.append("")
    text.append(markdown_table(
        main_rows,
        (
            ("num_elements", "elements"),
            ("tracking_mode", "tracking"),
            ("lookahead_points", "lookahead pts"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Cone Observation Cases")
    text.append("")
    text.append(
        "Cone cases use road-owned cone specs and no lookahead points. Cone point "
        "generation is timed separately because the environment prepares road-spec "
        "cones once per episode, then filters cached cone points each step."
    )
    text.append("")
    text.append(markdown_table(
        cone_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("cone_points", "cached cone pts"),
            ("cone_result_limit", "result cap"),
            ("cone_generation_ms", "cone gen ms"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Road Construction Cases")
    text.append("")
    text.append(
        "Construction cases time `Road(road_spec=...)` itself. This matters for "
        "domain randomization setups that create a fresh road during many resets. "
        "Cone-spec construction does not include generated cone point arrays; "
        "those are reported separately in the cone section."
    )
    text.append("")
    text.append(markdown_table(
        construction_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("median_ms", "median ms"),
            ("p95_ms", "p95 ms"),
            ("mean_ms", "mean ms"),
            ("calls_per_s", "roads/s"),
        ),
        digits=3,
    ))
    text.append("")
    text.append("## Extra Comparison Cases")
    text.append("")
    text.append(
        "These cases are not part of the full matrix, but they isolate useful "
        "implementation questions: fixed offset versus lane selector, next-speed "
        "change outputs, global search without hints, all lookahead fields, and "
        "tapered lane geometry."
    )
    text.append("")
    text.append(markdown_table(
        extra_rows,
        (
            ("num_elements", "elements"),
            ("variant", "variant"),
            ("tracking_mode", "tracking"),
            ("lookahead_points", "lookahead pts"),
            ("lookahead_fields", "lookahead fields"),
            ("search_mode", "search"),
            ("median_us", "median us"),
            ("p95_us", "p95 us"),
            ("mean_us", "mean us"),
            ("calls_per_s", "calls/s"),
        ),
    ))
    text.append("")
    text.append("## Notes")
    text.append("")
    text.append(
        "- These timings measure Python-level wall-clock time on the machine that "
        "generated the report. Absolute values will vary by CPU, Python build, "
        "background load, and power settings."
    )
    text.append(
        "- The main matrix intentionally excludes next speed-change outputs because "
        "the environment now asks Road for those only when such observations are "
        "requested."
    )
    text.append(
        "- The cone filtering cases use the same cached coordinate/color arrays as "
        "the environment and cap returned detections to "
        f"`CONE_DETECTIONS_NUM_CONES_MAX={CONE_DETECTIONS_NUM_CONES_MAX}` before "
        "sorting the nearest visible cones."
    )
    text.append(
        "- The `global_search_no_hint` extra case is deliberately less representative "
        "of steady RL rollouts, but it shows the benefit of progress/element hints "
        "and is a useful regression check."
    )
    text.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(text), encoding="utf-8")


def write_critical_markdown_report(
    output_path: Path,
    *,
    critical_rows: Sequence[Dict],
    component_rows: Sequence[Dict],
    repeats: int,
    iterations: int,
    warmup: int,
    elapsed_s: float,
) -> None:
    now = _datetime.datetime.now().astimezone()

    target_200_100 = [
        row for row in critical_rows
        if row["variant"] == "target_lane_100_lookahead_200_elements"
    ][0]
    target_200_no_lookahead = [
        row for row in critical_rows
        if row["variant"] == "target_lane_no_lookahead_200_elements"
    ][0]
    component_200_rows = [
        row for row in component_rows
        if row["variant"] == "target_lane_100_lookahead_200_elements"
    ]
    direct_component_200 = [
        row for row in component_200_rows
        if row["component"] == "constant_offset_direct_body_points_curvature"
    ][0]
    general_path_component_200 = max(
        [
            row for row in component_200_rows
            if row["component"] in (
                "target_distance_to_reference_progress",
                "reference_line_sampling",
                "target_line_geometry_body_points_curvature",
            )
        ],
        key=lambda row: row["median_run_median_us"],
    )

    text = []
    text.append("# Road Critical Computation-Time Profile")
    text.append("")
    text.append(
        "This file is generated by `python scripts/profile_road.py --quick-critical`."
    )
    text.append("")
    text.append("## Environment")
    text.append("")
    text.append(f"- Generated: {now.isoformat(timespec='seconds')}")
    text.append(f"- Python: {platform.python_version()}")
    text.append(f"- NumPy: {np.__version__}")
    text.append(f"- Platform: {platform.platform()}")
    text.append(f"- Repeated runs per case: {repeats}")
    text.append(f"- Timed iterations per repeated run: {iterations}")
    text.append(f"- Warmup iterations per repeated run: {warmup}")
    text.append(f"- Total script runtime: {elapsed_s:.2f} s")
    text.append("")
    text.append("## Method")
    text.append("")
    text.append(
        "This focused report is for regression checking of the Road hot path. "
        "It times a small set of representative cases several times and reports "
        "the min, median, and max of the per-run medians. The min run is often "
        "the least contaminated local estimate on a desktop machine; the spread "
        "is a useful warning about timing noise."
    )
    text.append("")
    text.append(
        "The component breakdown isolates the optimized constant-offset lookahead "
        "sampler and the older staged lookahead pieces: target-distance to "
        "reference-progress mapping, reference-line sampling, and target-line "
        "body-point/curvature generation. Some components are timed with "
        "precomputed intermediate inputs, so the component rows are diagnostic "
        "and are not expected to sum exactly to the full Road call."
    )
    text.append("")
    text.append("## Quick Read")
    text.append("")
    text.append(
        f"- 200-element target-lane no-lookahead: min run median "
        f"{target_200_no_lookahead['min_run_median_us']:.2f} us; repeated-run median "
        f"{target_200_no_lookahead['median_run_median_us']:.2f} us."
    )
    text.append(
        f"- 200-element target-lane 100-lookahead: min run median "
        f"{target_200_100['min_run_median_us']:.2f} us; repeated-run median "
        f"{target_200_100['median_run_median_us']:.2f} us."
    )
    text.append(
        f"- In the 200-element target-lane 100-lookahead component breakdown, "
        f"the optimized direct lookahead sampler is "
        f"{direct_component_200['median_run_median_us']:.2f} us median "
        f"({direct_component_200['share_of_full_median_pct']:.1f}% of the full-call median)."
    )
    text.append(
        f"- The largest old staged-path component for that same case is "
        f"`{general_path_component_200['component']}` at "
        f"{general_path_component_200['median_run_median_us']:.2f} us median. "
        "That staged path is now bypassed for the common constant-width target-line lookahead request."
    )
    text.append("")
    text.append("## Repeated Critical Cases")
    text.append("")
    text.append(markdown_table(
        critical_rows,
        (
            ("variant", "variant"),
            ("tracking_mode", "tracking"),
            ("lookahead_points", "lookahead pts"),
            ("repeats", "runs"),
            ("min_run_median_us", "min median us"),
            ("median_run_median_us", "median of medians us"),
            ("max_run_median_us", "max median us"),
            ("median_run_p95_us", "median p95 us"),
            ("run_median_spread_pct", "spread %"),
            ("run_medians_us", "run medians us"),
        ),
    ))
    text.append("")
    text.append("## Lookahead Component Breakdown")
    text.append("")
    text.append(markdown_table(
        component_rows,
        (
            ("variant", "variant"),
            ("component", "component"),
            ("repeats", "runs"),
            ("min_run_median_us", "min median us"),
            ("median_run_median_us", "median of medians us"),
            ("max_run_median_us", "max median us"),
            ("median_run_p95_us", "median p95 us"),
            ("share_of_full_median_pct", "share of full %"),
            ("run_median_spread_pct", "spread %"),
            ("run_medians_us", "run medians us"),
        ),
    ))
    text.append("")
    text.append("## Notes")
    text.append("")
    text.append(
        "- Use this report when checking whether Road observation changes affected "
        "the critical RL rollout path. Use the broader Road report when checking "
        "feature coverage across all cases."
    )
    text.append(
        "- A large `spread %` means the local machine was noisy enough that the "
        "single-run broad profiler may be misleading."
    )
    text.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(text), encoding="utf-8")


@dataclass
class RoadProfileConfig:
    quick_critical: bool = False
    critical_repeats: int = 7
    iterations: int = 1200
    warmup: int = 200
    construction_iterations: int = 200
    construction_warmup: int = 20
    output: Path | None = None


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Profile Road computation-time paths and write a Markdown report.",
    )
    parser.add_argument(
        "--quick-critical",
        action="store_true",
        help=(
            "Run only focused repeated critical Road cases and write "
            "profiling_results/road_critical_computation_time_profile.md by default."
        ),
    )
    parser.add_argument(
        "--critical-repeats",
        type=int,
        default=7,
        help="Repeated runs per quick-critical case. Default: 7.",
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=1200,
        help="Timed iterations per case. Default: 1200.",
    )
    parser.add_argument(
        "--warmup",
        type=int,
        default=200,
        help="Untimed warmup iterations per case. Default: 200.",
    )
    parser.add_argument(
        "--construction-iterations",
        type=int,
        default=200,
        help="Timed iterations per Road construction case. Default: 200.",
    )
    parser.add_argument(
        "--construction-warmup",
        type=int,
        default=20,
        help="Untimed warmup iterations per Road construction case. Default: 20.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help=(
            "Markdown output path. Default: profiling_results/road_computation_time_profile.md, "
            "or profiling_results/road_critical_computation_time_profile.md with --quick-critical."
        ),
    )
    return parser.parse_args(argv)


def profile_road_computation(config: RoadProfileConfig) -> Path:
    _ensure_road_runtime_imports()

    if config.iterations <= 0:
        raise ValueError("iterations must be positive.")
    if config.warmup < 0:
        raise ValueError("warmup must be non-negative.")
    if config.critical_repeats <= 0:
        raise ValueError("critical_repeats must be positive.")
    if config.construction_iterations <= 0:
        raise ValueError("construction_iterations must be positive.")
    if config.construction_warmup < 0:
        raise ValueError("construction_warmup must be non-negative.")

    default_name = (
        "road_critical_computation_time_profile.md"
        if config.quick_critical else
        "road_computation_time_profile.md"
    )
    output_path = resolve_profile_output_path(config.output, default_name)

    start_time = time.perf_counter()
    if config.quick_critical:
        critical_rows = benchmark_critical_repeat_cases(
            repeats=config.critical_repeats,
            iterations=config.iterations,
            warmup=config.warmup,
        )
        component_rows = benchmark_critical_component_breakdown(
            repeats=config.critical_repeats,
            iterations=config.iterations,
            warmup=config.warmup,
        )
        elapsed_s = time.perf_counter() - start_time

        for row in [*critical_rows, *component_rows]:
            row.pop("sink", None)

        write_critical_markdown_report(
            output_path,
            critical_rows=critical_rows,
            component_rows=component_rows,
            repeats=config.critical_repeats,
            iterations=config.iterations,
            warmup=config.warmup,
            elapsed_s=elapsed_s,
        )
        return output_path

    main_rows = benchmark_main_matrix(config.iterations, config.warmup)
    cone_rows = benchmark_cone_cases(config.iterations, config.warmup)
    construction_rows = benchmark_construction_cases(
        config.construction_iterations,
        config.construction_warmup,
    )
    extra_rows = benchmark_extra_cases(config.iterations, config.warmup)
    elapsed_s = time.perf_counter() - start_time

    # Drop the sink values from report rows after preserving their side effect.
    for row in [*main_rows, *cone_rows, *construction_rows, *extra_rows]:
        row.pop("sink", None)

    write_markdown_report(
        output_path,
        main_rows=main_rows,
        cone_rows=cone_rows,
        construction_rows=construction_rows,
        extra_rows=extra_rows,
        iterations=config.iterations,
        warmup=config.warmup,
        construction_iterations=config.construction_iterations,
        construction_warmup=config.construction_warmup,
        elapsed_s=elapsed_s,
    )
    return output_path


def profile_road_main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    output_path = profile_road_computation(
        RoadProfileConfig(
            quick_critical=args.quick_critical,
            critical_repeats=args.critical_repeats,
            iterations=args.iterations,
            warmup=args.warmup,
            construction_iterations=args.construction_iterations,
            construction_warmup=args.construction_warmup,
            output=args.output,
        )
    )
    print(f"Wrote {display_output_path(output_path)}")


def main() -> None:
    profile_road_main()


if __name__ == "__main__":
    main()
