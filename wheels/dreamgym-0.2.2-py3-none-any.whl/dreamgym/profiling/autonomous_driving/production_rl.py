"""Production configuration and identity resolution for RL profiling.

This module stops at the preconstruction boundary.  It deliberately does not
construct a vector environment or model and does not execute a benchmark.
"""

from __future__ import annotations

import copy
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from pathlib import PurePosixPath
import re
from typing import Any, ClassVar, Literal

from dreamgym.profiling.autonomous_driving.records import (
    CaseSpec,
    ExecutionSpec,
    canonical_json_digest,
    execution_instance_id,
)
from dreamgym.training.autonomous_driving.algorithm_profiles import (
    ALGORITHM_PROFILES,
    ALGORITHM_PROFILE_VERSION,
)
from dreamgym.training.autonomous_driving.config_validation import (
    canonical_snapshot_digest,
    freeze_json,
    thaw_json,
    validate_json_value,
    validate_requested_config,
)
from dreamgym.training.autonomous_driving.configs import (
    TrainingConfig,
    config_from_dict,
    default_training_config,
)
from dreamgym.training.autonomous_driving.resolution import (
    RESOLVER_VERSION,
    TrainingBuildConfig,
    resolve_training_request,
)
from dreamgym.training.autonomous_driving.seeds import (
    SEED_DERIVATION_VERSION,
)
from dreamgym.training.autonomous_driving.snapshots import (
    preconstruction_snapshot,
    requested_snapshot,
    validate_resolved_snapshot,
)


RL_SEMANTIC_PROJECTION_VERSION = "dreamgym-rl-semantic-projection-v2"
RL_EXECUTION_SPEC_VERSION = "dreamgym-rl-execution-spec-v1"
RL_TIMING_PROTOCOL_VERSION = "dreamgym-rl-rollout-lifecycle-timing-v1"
RL_WORKLOAD_VECTOR_KIND = "dummy"
RL_DEVICE_AUTO_INELIGIBILITY = "device_auto_diagnostic_only"
RL_WARMUP_RULE = "first_rollout_start_after_at_least_one_optimizer_update"
RL_PARTIAL_WINDOW_RULE = "retain_diagnostic_exclude_from_headline"
RL_WORKER_RUNTIME_POLICY = "spawn_isolated_production_runtime"
RL_WORKER_PROTOCOL_VERSION = "dreamgym-rl-worker-protocol-v3"
RL_PROGRESS_MILESTONE_COUNT = 4

AlgorithmName = Literal["PPO", "A2C", "SAC", "TD3", "DDPG"]
DevicePolicy = Literal["cpu", "cuda", "auto"]

_SUPPORTED_ALGORITHMS = frozenset(("PPO", "A2C", "SAC", "TD3", "DDPG"))
_DIAGNOSTIC_STAGE_RE = re.compile(r"^[a-z][a-z0-9_]*$")
_CASE_FAMILIES = frozenset(
    ("generic", "algorithm_comparison", "ppo_step_scaling", "ppo_vector_scaling")
)
_REQUESTED_SNAPSHOT_REFERENCE_FIELDS = (
    "requested_config_path",
    "requested_config_digest",
    "requested_file_sha256",
)
_RESOLVED_SNAPSHOT_REFERENCE_FIELDS = (
    *_REQUESTED_SNAPSHOT_REFERENCE_FIELDS,
    "resolved_config_path",
    "resolved_config_digest",
    "resolved_file_sha256",
)


def _require_case_id(value: Any) -> str:
    if type(value) is not str or not value:
        raise ValueError("case_id must be a non-empty string.")
    return value


def _freeze_message_object(value: Any, path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    detached = validate_json_value(dict(value), path=path)
    return freeze_json(detached)


def _freeze_snapshot_reference(
    value: Any,
    *,
    fields: tuple[str, ...],
    path: str,
) -> Mapping[str, Any]:
    reference = _freeze_message_object(value, path)
    if set(reference) != set(fields):
        missing = sorted(set(fields) - set(reference))
        unexpected = sorted(set(reference) - set(fields))
        name = missing[0] if missing else unexpected[0]
        raise ValueError(path + "." + name + " is missing or unsupported.")
    for name in fields:
        item = reference[name]
        if name.endswith("_path"):
            if type(item) is not str or not item:
                raise ValueError(
                    path + "." + name + " must be a non-empty relative path."
                )
            parsed = PurePosixPath(item)
            if (
                parsed.is_absolute()
                or parsed.as_posix() != item
                or any(part in (".", "..") for part in parsed.parts)
                or "\\" in item
                or ":" in item
            ):
                raise ValueError(
                    path + "." + name + " must be a safe relative path."
                )
        else:
            _require_digest(item, path + "." + name)
    return reference


def _strict_message_fields(
    value: Mapping[str, Any],
    fields: set[str],
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("worker message must be a mapping.")
    detached = validate_json_value(dict(value), path="worker_message")
    missing = sorted(fields - set(detached))
    unexpected = sorted(set(detached) - fields)
    if missing or unexpected:
        name = missing[0] if missing else unexpected[0]
        raise ValueError(
            "worker_message." + name + " is missing or unsupported."
        )
    if detached["protocol_version"] != RL_WORKER_PROTOCOL_VERSION:
        raise ValueError("worker message protocol_version is unsupported.")
    return detached


class _RLWorkerMessage:
    kind: ClassVar[str]
    protocol_version: ClassVar[str] = RL_WORKER_PROTOCOL_VERSION


@dataclass(frozen=True)
class RLRequestedReady(_RLWorkerMessage):
    """Worker-to-parent requested snapshot persistence barrier."""

    case_id: str
    snapshot: Mapping[str, Any]
    requested_config_digest: str
    kind: ClassVar[str] = "requested-ready"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        _require_digest(
            self.requested_config_digest,
            "requested_config_digest",
        )
        object.__setattr__(
            self,
            "snapshot",
            _freeze_message_object(self.snapshot, "snapshot"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "snapshot": thaw_json(self.snapshot),
            "requested_config_digest": self.requested_config_digest,
        }


@dataclass(frozen=True)
class RLRequestedPersisted(_RLWorkerMessage):
    """Parent-to-worker acknowledgement of durable requested persistence."""

    case_id: str
    snapshot_reference: Mapping[str, Any]
    kind: ClassVar[str] = "requested-persisted"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        object.__setattr__(
            self,
            "snapshot_reference",
            _freeze_message_object(
                self.snapshot_reference,
                "snapshot_reference",
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "snapshot_reference": thaw_json(self.snapshot_reference),
        }


@dataclass(frozen=True)
class RLResolvedReady(_RLWorkerMessage):
    """Worker-to-parent finalized resolved snapshot persistence barrier."""

    case_id: str
    snapshot: Mapping[str, Any]
    requested_config_digest: str
    kind: ClassVar[str] = "resolved-ready"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        _require_digest(
            self.requested_config_digest,
            "requested_config_digest",
        )
        object.__setattr__(
            self,
            "snapshot",
            _freeze_message_object(self.snapshot, "snapshot"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "snapshot": thaw_json(self.snapshot),
            "requested_config_digest": self.requested_config_digest,
        }


@dataclass(frozen=True)
class RLResolvedPersisted(_RLWorkerMessage):
    """Parent-to-worker acknowledgement of durable resolved persistence."""

    case_id: str
    snapshot_reference: Mapping[str, Any]
    kind: ClassVar[str] = "resolved-persisted"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        object.__setattr__(
            self,
            "snapshot_reference",
            _freeze_message_object(
                self.snapshot_reference,
                "snapshot_reference",
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "snapshot_reference": thaw_json(self.snapshot_reference),
        }


@dataclass(frozen=True)
class RLWorkerProgress(_RLWorkerMessage):
    """One sparse in-training worker milestone."""

    case_id: str
    completed: int
    total: int
    kind: ClassVar[str] = "progress"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        if type(self.completed) is not int or self.completed < 0:
            raise ValueError("completed must be a non-negative integer.")
        if type(self.total) is not int or self.total <= 0:
            raise ValueError("total must be a positive integer.")
        if self.completed > self.total:
            raise ValueError("completed must not exceed total.")

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "completed": self.completed,
            "total": self.total,
        }


@dataclass(frozen=True)
class RLWorkerResult(_RLWorkerMessage):
    """Immutable worker result; all persistence remains parent-owned."""

    case_id: str
    execution_spec_digest: str
    requested_snapshot_reference: Mapping[str, Any]
    resolved_snapshot_reference: Mapping[str, Any]
    sample_ns: tuple[int, ...]
    metrics: Mapping[str, Any]
    status: str = "completed"
    kind: ClassVar[str] = "result"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        _require_digest(
            self.execution_spec_digest,
            "execution_spec_digest",
        )
        samples = tuple(self.sample_ns)
        if any(type(value) is not int or value < 0 for value in samples):
            raise ValueError(
                "sample_ns must contain non-negative integer nanoseconds."
            )
        if self.status not in ("completed", "failed"):
            raise ValueError("status must be completed or failed.")
        object.__setattr__(self, "sample_ns", samples)
        object.__setattr__(
            self,
            "requested_snapshot_reference",
            _freeze_message_object(
                self.requested_snapshot_reference,
                "requested_snapshot_reference",
            ),
        )
        object.__setattr__(
            self,
            "resolved_snapshot_reference",
            _freeze_message_object(
                self.resolved_snapshot_reference,
                "resolved_snapshot_reference",
            ),
        )
        object.__setattr__(
            self,
            "metrics",
            _freeze_message_object(self.metrics, "metrics"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "execution_spec_digest": self.execution_spec_digest,
            "requested_snapshot_reference": thaw_json(
                self.requested_snapshot_reference
            ),
            "resolved_snapshot_reference": thaw_json(
                self.resolved_snapshot_reference
            ),
            "sample_ns": list(self.sample_ns),
            "metrics": thaw_json(self.metrics),
            "status": self.status,
        }


@dataclass(frozen=True)
class RLWorkerFailure(_RLWorkerMessage):
    """Worker diagnostic emitted without fabricating measurement data."""

    case_id: str
    stage: str
    exception_type: str
    message: str
    requested_snapshot_reference: Mapping[str, Any] | None = None
    resolved_snapshot_reference: Mapping[str, Any] | None = None
    kind: ClassVar[str] = "failure"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        if (
            type(self.stage) is not str
            or _DIAGNOSTIC_STAGE_RE.fullmatch(self.stage) is None
        ):
            raise ValueError(
                "stage must be a stable controlled token."
            )
        for field_name in ("exception_type", "message"):
            value = getattr(self, field_name)
            if type(value) is not str or not value:
                raise ValueError(field_name + " must be a non-empty string.")
        requested_reference = self.requested_snapshot_reference
        resolved_reference = self.resolved_snapshot_reference
        if requested_reference is None:
            if resolved_reference is not None:
                raise ValueError(
                    "resolved_snapshot_reference requires an acknowledged "
                    "requested_snapshot_reference."
                )
            return
        requested_reference = _freeze_snapshot_reference(
            requested_reference,
            fields=_REQUESTED_SNAPSHOT_REFERENCE_FIELDS,
            path="requested_snapshot_reference",
        )
        if resolved_reference is not None:
            resolved_reference = _freeze_snapshot_reference(
                resolved_reference,
                fields=_RESOLVED_SNAPSHOT_REFERENCE_FIELDS,
                path="resolved_snapshot_reference",
            )
            if {
                name: resolved_reference[name]
                for name in _REQUESTED_SNAPSHOT_REFERENCE_FIELDS
            } != dict(requested_reference):
                raise ValueError(
                    "resolved_snapshot_reference does not preserve the "
                    "requested snapshot reference."
                )
        object.__setattr__(
            self,
            "requested_snapshot_reference",
            requested_reference,
        )
        object.__setattr__(
            self,
            "resolved_snapshot_reference",
            resolved_reference,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "stage": self.stage,
            "exception_type": self.exception_type,
            "message": self.message,
            "requested_snapshot_reference": (
                None
                if self.requested_snapshot_reference is None
                else thaw_json(self.requested_snapshot_reference)
            ),
            "resolved_snapshot_reference": (
                None
                if self.resolved_snapshot_reference is None
                else thaw_json(self.resolved_snapshot_reference)
            ),
        }


@dataclass(frozen=True)
class RLWorkerAbort(_RLWorkerMessage):
    """Parent-to-worker cancellation that is honored at either barrier."""

    case_id: str
    reason: str
    kind: ClassVar[str] = "abort"

    def __post_init__(self) -> None:
        _require_case_id(self.case_id)
        if type(self.reason) is not str or not self.reason:
            raise ValueError("reason must be a non-empty string.")

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "kind": self.kind,
            "case_id": self.case_id,
            "reason": self.reason,
        }


def rl_worker_message_from_dict(
    value: Mapping[str, Any],
) -> _RLWorkerMessage:
    """Parse one strict protocol-v3 parent/worker message."""

    if not isinstance(value, Mapping):
        raise TypeError("worker message must be a mapping.")
    kind = value.get("kind")
    common = {"protocol_version", "kind", "case_id"}
    fields_by_kind = {
        "requested-ready": common
        | {"snapshot", "requested_config_digest"},
        "requested-persisted": common | {"snapshot_reference"},
        "resolved-ready": common
        | {"snapshot", "requested_config_digest"},
        "resolved-persisted": common | {"snapshot_reference"},
        "progress": common | {"completed", "total"},
        "result": common
        | {
            "execution_spec_digest",
            "requested_snapshot_reference",
            "resolved_snapshot_reference",
            "sample_ns",
            "metrics",
            "status",
        },
        "failure": common
        | {
            "stage",
            "exception_type",
            "message",
            "requested_snapshot_reference",
            "resolved_snapshot_reference",
        },
        "abort": common | {"reason"},
    }
    if kind not in fields_by_kind:
        raise ValueError("worker_message.kind is unsupported.")
    detached = _strict_message_fields(value, fields_by_kind[kind])
    constructors = {
        "requested-ready": lambda: RLRequestedReady(
            detached["case_id"],
            detached["snapshot"],
            detached["requested_config_digest"],
        ),
        "requested-persisted": lambda: RLRequestedPersisted(
            detached["case_id"],
            detached["snapshot_reference"],
        ),
        "resolved-ready": lambda: RLResolvedReady(
            detached["case_id"],
            detached["snapshot"],
            detached["requested_config_digest"],
        ),
        "resolved-persisted": lambda: RLResolvedPersisted(
            detached["case_id"],
            detached["snapshot_reference"],
        ),
        "progress": lambda: RLWorkerProgress(
            detached["case_id"],
            detached["completed"],
            detached["total"],
        ),
        "result": lambda: RLWorkerResult(
            detached["case_id"],
            detached["execution_spec_digest"],
            detached["requested_snapshot_reference"],
            detached["resolved_snapshot_reference"],
            tuple(detached["sample_ns"]),
            detached["metrics"],
            detached["status"],
        ),
        "failure": lambda: RLWorkerFailure(
            detached["case_id"],
            detached["stage"],
            detached["exception_type"],
            detached["message"],
            detached["requested_snapshot_reference"],
            detached["resolved_snapshot_reference"],
        ),
        "abort": lambda: RLWorkerAbort(
            detached["case_id"],
            detached["reason"],
        ),
    }
    return constructors[kind]()


def _default_timing_protocol() -> dict[str, Any]:
    return {
        "version": RL_TIMING_PROTOCOL_VERSION,
        "clock": "perf_counter_ns",
        "boundary": "rollout_start_to_next_rollout_start",
        "included_work": "complete_rollout_collection_plus_optimizer_update",
    }


def _freeze_object(value: Mapping[str, Any], path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    detached = validate_json_value(dict(value), path=path)
    return freeze_json(detached)


def _exact_positive_int(value: Any, path: str) -> int:
    if type(value) is not int:
        raise TypeError(path + " must be an integer.")
    if value <= 0:
        raise ValueError(path + " must be positive.")
    return value


@dataclass(frozen=True)
class RLCaseRequest:
    """Typed preconstruction request for one production RL profiling case."""

    case_name: str = "rl-production"
    algorithm: AlgorithmName = "PPO"
    rl_training_steps: int = 100_000
    vec_env: str = RL_WORKLOAD_VECTOR_KIND
    n_envs: int | Literal["algorithm_default"] = "algorithm_default"
    n_rollout_transitions_per_update: int | Literal[
        "algorithm_default"
    ] = "algorithm_default"
    algorithm_hyperparameters: Mapping[str, Any] = field(default_factory=dict)
    policy_kwargs: Mapping[str, Any] = field(default_factory=dict)
    device_policy: DevicePolicy | None = None
    timing_protocol: Mapping[str, Any] = field(
        default_factory=_default_timing_protocol
    )
    warmup_rule: str = RL_WARMUP_RULE
    complete_window_transition_target: int = 2_048
    required_complete_window_count: int = 3
    partial_window_rule: str = RL_PARTIAL_WINDOW_RULE
    worker_runtime_policy: str = RL_WORKER_RUNTIME_POLICY
    case_family: str = "generic"

    def __post_init__(self) -> None:
        if type(self.case_name) is not str or not self.case_name:
            raise ValueError("case_name must be a non-empty string.")
        if self.algorithm not in _SUPPORTED_ALGORITHMS:
            raise ValueError("algorithm is not supported.")
        _exact_positive_int(self.rl_training_steps, "rl_training_steps")
        if self.vec_env != RL_WORKLOAD_VECTOR_KIND:
            raise ValueError(
                "RL workload v1 supports only vec_env='dummy'; "
                "SubprocVecEnv requests are not custom v1 cases."
            )
        if self.n_envs != "algorithm_default":
            _exact_positive_int(self.n_envs, "n_envs")
        if self.n_rollout_transitions_per_update != "algorithm_default":
            _exact_positive_int(
                self.n_rollout_transitions_per_update,
                "n_rollout_transitions_per_update",
            )
        if self.device_policy not in (None, "cpu", "cuda", "auto"):
            raise ValueError("device_policy must be cpu, cuda, auto, or null.")
        if self.case_family not in _CASE_FAMILIES:
            raise ValueError("case_family is not supported.")
        for field_name in (
            "warmup_rule",
            "partial_window_rule",
            "worker_runtime_policy",
        ):
            value = getattr(self, field_name)
            if type(value) is not str or not value:
                raise ValueError(field_name + " must be a non-empty string.")
        _exact_positive_int(
            self.complete_window_transition_target,
            "complete_window_transition_target",
        )
        _exact_positive_int(
            self.required_complete_window_count,
            "required_complete_window_count",
        )

        hyperparameters = _freeze_object(
            self.algorithm_hyperparameters,
            "algorithm_hyperparameters",
        )
        if "device" in hyperparameters:
            raise ValueError(
                "algorithm_hyperparameters.device is reserved; "
                "use device_policy."
            )
        policy_kwargs = _freeze_object(self.policy_kwargs, "policy_kwargs")
        timing_protocol = _freeze_object(
            self.timing_protocol,
            "timing_protocol",
        )
        if thaw_json(timing_protocol) != _default_timing_protocol():
            raise ValueError(
                "timing_protocol must exactly equal the supported workload-v1 "
                "document; different timing semantics require a future "
                "version and design."
            )
        object.__setattr__(self, "algorithm_hyperparameters", hyperparameters)
        object.__setattr__(self, "policy_kwargs", policy_kwargs)
        object.__setattr__(self, "timing_protocol", timing_protocol)

    @property
    def timing_protocol_digest(self) -> str:
        return canonical_json_digest(thaw_json(self.timing_protocol))


@dataclass(frozen=True)
class RLEligibility:
    """Identity/reuse eligibility kept separate from execution permission."""

    canonical_status: bool
    submission_status: bool
    semantic_reuse_import: bool
    sample_aggregation: bool
    diagnostic_execution: bool


@dataclass(frozen=True)
class ResolvedRLProfileCase:
    """Complete preconstruction RL profiling record."""

    request: RLCaseRequest
    build: TrainingBuildConfig
    requested_snapshot: Mapping[str, Any]
    requested_config_digest: str
    semantic_projection: Mapping[str, Any]
    case_spec: CaseSpec
    execution_spec: ExecutionSpec
    classification: str
    eligibility: RLEligibility
    warnings: tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.request, RLCaseRequest):
            raise TypeError("request must be an RLCaseRequest.")
        if not isinstance(self.build, TrainingBuildConfig):
            raise TypeError("build must be a TrainingBuildConfig.")
        requested = validate_json_value(
            thaw_json(self.requested_snapshot),
            path="requested_snapshot",
        )
        projection = validate_json_value(
            thaw_json(self.semantic_projection),
            path="semantic_projection",
        )
        if canonical_snapshot_digest(requested) != self.requested_config_digest:
            raise ValueError(
                "requested_config_digest does not match requested_snapshot."
            )
        if self.build.requested_digest != self.requested_config_digest:
            raise ValueError(
                "requested_config_digest does not match the production build."
            )
        if thaw_json(self.build.requested_dict) != requested:
            raise ValueError(
                "requested_snapshot does not match the production build."
            )
        expected_config = build_requested_training_config(self.request)
        expected_requested = requested_snapshot(expected_config)
        if expected_requested != requested:
            raise ValueError(
                "requested_snapshot does not match the profiling request."
            )
        expected_build = resolve_training_request(expected_config)
        if self.build != expected_build:
            raise ValueError(
                "build does not match a fresh production resolution of the "
                "profiling request."
            )
        expected_projection = rl_semantic_projection(
            self.build,
            self.request.timing_protocol_digest,
        )
        if projection != expected_projection:
            raise ValueError(
                "semantic_projection does not match the production build."
            )
        if canonical_json_digest(projection) != self.case_spec.semantic_case_digest:
            raise ValueError(
                "semantic_projection does not match case_spec."
            )
        if self.case_spec.readable_prefix != self.request.case_name:
            raise ValueError(
                "case_spec readable prefix does not match the profiling request."
            )
        if (
            thaw_json(self.case_spec.semantic_document)
            != projection["semantic_document"]
        ):
            raise ValueError(
                "case_spec semantic document does not match semantic_projection."
            )
        if (
            thaw_json(self.case_spec.timing_protocol)
            != thaw_json(self.request.timing_protocol)
        ):
            raise ValueError(
                "case_spec timing protocol does not match the profiling request."
            )
        if (
            projection.get("timing_protocol_digest")
            != self.request.timing_protocol_digest
        ):
            raise ValueError(
                "semantic_projection timing protocol does not match request."
            )
        if (
            self.case_spec.timing_protocol_digest
            != self.request.timing_protocol_digest
        ):
            raise ValueError(
                "case_spec timing protocol does not match request."
            )
        if self.execution_spec.semantic_case_id != self.case_spec.semantic_case_id:
            raise ValueError("execution_spec does not belong to case_spec.")
        expected_execution = _execution_document(
            self.request,
            self.request.timing_protocol_digest,
        )
        if self.execution_spec.to_dict()["execution_document"] != expected_execution:
            raise ValueError(
                "execution_spec does not match the profiling request."
            )
        expected_classification = _classification(self.request, self.build)
        if self.classification != expected_classification:
            raise ValueError(
                "classification does not match the profiling request."
            )
        if self.eligibility != _eligibility(expected_classification):
            raise ValueError(
                "eligibility does not match the profiling classification."
            )
        warnings = tuple(self.warnings)
        if warnings != _profile_warnings(self.build):
            raise ValueError(
                "warnings do not match the production build."
            )
        object.__setattr__(self, "requested_snapshot", freeze_json(requested))
        object.__setattr__(self, "semantic_projection", freeze_json(projection))
        object.__setattr__(self, "warnings", warnings)

    @property
    def semantic_case_digest(self) -> str:
        return self.case_spec.semantic_case_digest

    @property
    def semantic_case_id(self) -> str:
        return self.case_spec.semantic_case_id

    @property
    def execution_spec_digest(self) -> str:
        return self.execution_spec.execution_spec_digest

    @property
    def timing_protocol_digest(self) -> str:
        return self.request.timing_protocol_digest

    @property
    def requested_config(self) -> TrainingConfig:
        """Reconstruct a fresh strict requested config without default overlay."""

        return config_from_dict(thaw_json(self.requested_snapshot))

    @property
    def resolved_profile_rollout_transitions(self) -> int | None:
        algorithm = self.build.algorithm
        effective = algorithm.n_rollout_transitions_per_update_effective
        rounding = algorithm.n_rollout_transitions_rounding_amount
        if effective is None or rounding is None:
            return None
        return effective - rounding


def _enforce_no_output(config: TrainingConfig) -> None:
    config.evaluation.interval_steps = 0
    config.artifacts.save_model_at_evaluations = False
    config.artifacts.save_final_model = False
    config.artifacts.save_plots_at_evaluations = False
    config.artifacts.save_final_plots = False
    config.artifacts.animation_evaluation_steps = []
    config.artifacts.save_final_policy_animation = False
    config.logging.progress_interval_steps = 0
    config.logging.print_progress_to_console = False
    config.logging.save_monitor_csv = False
    config.logging.enable_tensorboard_logging = False


def build_requested_training_config(case: RLCaseRequest) -> TrainingConfig:
    """Apply the detached profiling delta to a fresh production default."""

    if not isinstance(case, RLCaseRequest):
        raise TypeError("case must be an RLCaseRequest.")
    config = default_training_config()
    config.algorithm.name = case.algorithm
    config.requested_total_environment_transitions = case.rl_training_steps
    config.vectorization.vec_env = case.vec_env
    config.vectorization.n_envs = case.n_envs
    config.algorithm.n_rollout_transitions_per_update = (
        case.n_rollout_transitions_per_update
    )
    _enforce_no_output(config)

    config.algorithm.hyperparameters = thaw_json(
        case.algorithm_hyperparameters
    )
    config.algorithm.policy_kwargs = thaw_json(case.policy_kwargs)
    if case.device_policy is not None:
        config.algorithm.hyperparameters["device"] = case.device_policy

    # The worker output contract is invariant, including for advanced cases.
    _enforce_no_output(config)
    return validate_requested_config(config)


def _resolved_profile_rollout(algorithm: Mapping[str, Any]) -> int | None:
    effective = algorithm["n_rollout_transitions_per_update_effective"]
    rounding = algorithm["n_rollout_transitions_rounding_amount"]
    if effective is None or rounding is None:
        return None
    return effective - rounding


def _algorithm_semantics(algorithm: Mapping[str, Any]) -> dict[str, Any]:
    constructor_kwargs = copy.deepcopy(algorithm["constructor_kwargs"])
    constructor_device = constructor_kwargs.pop("device")
    native_n_steps = algorithm["native_n_steps_per_environment"]
    if native_n_steps is not None:
        constructor_kwargs["n_steps"] = native_n_steps

    if constructor_device == "auto":
        device = {
            "policy": "auto",
            "ineligibility_marker": RL_DEVICE_AUTO_INELIGIBILITY,
        }
    else:
        device = {
            "policy": "concrete",
            "effective_constructor_device": constructor_device,
        }

    policy_kwargs = copy.deepcopy(algorithm["policy_kwargs"])
    policy_alias = algorithm["policy_alias"]
    feature_extractor_class = {
        "MlpPolicy": (
            "stable_baselines3.common.torch_layers.FlattenExtractor"
        ),
        "MultiInputPolicy": (
            "stable_baselines3.common.torch_layers.CombinedExtractor"
        ),
    }[policy_alias]
    if algorithm["n_rollout_transitions_per_update_applicability"] == "applicable":
        cadence = {
            "family": "on_policy",
            "resolved_profile_rollout_transitions": (
                _resolved_profile_rollout(algorithm)
            ),
            "native_n_steps_per_environment": native_n_steps,
            "effective_rollout_transitions": algorithm[
                "n_rollout_transitions_per_update_effective"
            ],
            "upward_rounding_transitions": algorithm[
                "n_rollout_transitions_rounding_amount"
            ],
            "ppo_minibatch_remainder": algorithm["ppo_minibatch_remainder"],
        }
    else:
        cadence = {
            "family": "off_policy",
            "train_freq": constructor_kwargs["train_freq"],
            "n_steps": constructor_kwargs["n_steps"],
            "gradient_steps": constructor_kwargs["gradient_steps"],
            "transitions_per_collection": algorithm[
                "transitions_per_collection"
            ],
            "gradient_steps_per_collection": algorithm[
                "gradient_steps_per_collection"
            ],
            "update_to_data_ratio": algorithm["update_to_data_ratio"],
            "replay": {
                key: copy.deepcopy(constructor_kwargs[key])
                for key in (
                    "buffer_size",
                    "learning_starts",
                    "batch_size",
                    "optimize_memory_usage",
                )
            },
        }

    return {
        "name": algorithm["name"],
        "profile_version": algorithm["profile_version"],
        "buffer_family": algorithm["buffer_kind"],
        "device": device,
        "constructor_kwargs": constructor_kwargs,
        "policy": {
            "alias": policy_alias,
            "effective_policy_kwargs": policy_kwargs,
            "activation": policy_kwargs["activation_fn"],
            "net_arch": copy.deepcopy(policy_kwargs["net_arch"]),
            "feature_extractor": {
                "source": "policy_alias_default",
                "class": feature_extractor_class,
            },
        },
        "cadence": cadence,
    }


_ACTIVE_PUBLIC_CONSTRUCTOR_FIELDS = (
    "bicycle_model_config",
    "integration_config",
    "termination_config",
    "initial_state_config",
    "observation_config",
    "target_line_config",
    "internal_policy_config",
    "ground_truth_mode",
    "observation_format",
)


def _environment_semantics(environment: Mapping[str, Any]) -> dict[str, Any]:
    public = environment["public_constructor_template"]
    return {
        "training": copy.deepcopy(environment["training"]),
        "public_constructor_template": {
            key: copy.deepcopy(public[key])
            for key in _ACTIVE_PUBLIC_CONSTRUCTOR_FIELDS
        },
        "postconstruction_settings": copy.deepcopy(
            environment["postconstruction_settings"]
        ),
        "target_relative_reset": copy.deepcopy(
            environment["target_relative_reset"]
        ),
    }


def _training_road_semantics(roads: Mapping[str, Any]) -> dict[str, Any]:
    winning_source = roads["winning_training_source"]
    active: dict[str, Any]
    if winning_source == "fixed_train_road_spec":
        active = {
            "fixed_train_road_spec": copy.deepcopy(
                roads["fixed_train_road_spec"]
            )
        }
    elif winning_source == "train_randomization":
        active = {
            "train_randomization": copy.deepcopy(
                roads["train_randomization"]
            )
        }
    elif winning_source == "default_training_road":
        active = {
            "default_training_road_spec": copy.deepcopy(
                roads["default_training_road_spec"]
            )
        }
    else:
        raise ValueError("resolved training road source is not supported.")
    return {
        "source_precedence": copy.deepcopy(
            roads["training_source_precedence"]
        ),
        "winning_source": winning_source,
        "active_source": active,
    }


def _training_seed_semantics(
    seeds: Mapping[str, Any],
    winning_training_source: str,
) -> dict[str, Any]:
    inputs = seeds["inputs"]
    semantics = {
        "root_seed": inputs["training_root_seed"],
        "member_seed_rule": {
            "owner": "stable_baselines3",
            "formula": "training_root_seed + vector_index",
            "factory_seed_offset": None,
        },
        "training_initial_state": copy.deepcopy(
            seeds["training_initial_state"]
        ),
        "counter_rule": seeds["counter_rule"],
    }
    if winning_training_source == "train_randomization":
        semantics["training_road_randomizer_seed"] = inputs[
            "training_road_randomizer_seed"
        ]
        semantics["training_road"] = copy.deepcopy(seeds["training_road"])
    return semantics


def _semantic_document_from_snapshot(
    snapshot: Mapping[str, Any],
) -> dict[str, Any]:
    wrapper_names = copy.deepcopy(
        snapshot["wrappers"]["exact_inner_to_outer"]
    )
    if wrapper_names[-1:] != ["VecMonitor"]:
        raise ValueError(
            "RL semantic projection requires one intended outer VecMonitor."
        )
    if wrapper_names.count("VecMonitor") != 1:
        raise ValueError(
            "RL semantic projection requires exactly one VecMonitor."
        )
    return {
        "semantic_projection_version": RL_SEMANTIC_PROJECTION_VERSION,
        "production_versions": {
            "resolver_version": snapshot["resolver_version"],
            "algorithm_profile_version": snapshot[
                "algorithm_profile_version"
            ],
            "seed_derivation_version": snapshot[
                "seed_derivation_version"
            ],
        },
        "algorithm": _algorithm_semantics(snapshot["algorithm"]),
        "vectorization": {
            "kind": snapshot["vectorization"]["vec_env"],
            "effective_n_envs": snapshot["vectorization"][
                "effective_n_envs"
            ],
        },
        "environment": _environment_semantics(snapshot["environment"]),
        "training_road": _training_road_semantics(snapshot["roads"]),
        "reward": {
            "effective": copy.deepcopy(snapshot["reward"]["effective"]),
        },
        "wrappers": {
            "exact_inner_to_outer": wrapper_names,
            "outer_vec_monitor": {"count": 1, "filename": None},
        },
        "training_seeds": _training_seed_semantics(
            snapshot["seeds"],
            snapshot["roads"]["winning_training_source"],
        ),
    }


def _preconstruction_wrappers(build: TrainingBuildConfig) -> list[str]:
    """Use the production snapshot authority for the logical wrapper stack."""

    try:
        snapshot = preconstruction_snapshot(build)
    except ValueError:
        version_changed = (
            build.resolver_version != RESOLVER_VERSION
            or build.seed_derivation_version != SEED_DERIVATION_VERSION
            or build.algorithm.profile_version != ALGORITHM_PROFILE_VERSION
        )
        if not version_changed:
            raise
        supported_build = replace(
            build,
            resolver_version=RESOLVER_VERSION,
            seed_derivation_version=SEED_DERIVATION_VERSION,
            algorithm=replace(
                build.algorithm,
                profile_version=ALGORITHM_PROFILE_VERSION,
            ),
        )
        snapshot = preconstruction_snapshot(supported_build)
    wrappers = snapshot["wrappers"]["exact_inner_to_outer"]
    if wrappers.count("VecMonitor"):
        raise ValueError(
            "preconstruction wrapper authority unexpectedly contains VecMonitor."
        )
    return wrappers + ["VecMonitor"]


def _projection_snapshot_from_build(
    build: TrainingBuildConfig,
) -> dict[str, Any]:
    """Expose only build facts needed by the semantic allowlist."""

    return {
        "resolver_version": build.resolver_version,
        "algorithm_profile_version": build.algorithm.profile_version,
        "seed_derivation_version": build.seed_derivation_version,
        "algorithm": build.algorithm.to_dict(),
        "vectorization": {
            "vec_env": build.requested_dict["vectorization"]["vec_env"],
            "effective_n_envs": build.effective_n_envs,
        },
        "environment": build.environment_dict(),
        "roads": build.roads_dict(),
        "seeds": build.seeds_dict(),
        "reward": build.reward_dict(),
        "wrappers": {
            "exact_inner_to_outer": _preconstruction_wrappers(build),
        },
    }


def _require_digest(value: Any, path: str) -> str:
    if (
        type(value) is not str
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(path + " must be a lowercase SHA-256 digest.")
    return value


def rl_semantic_projection(
    build: TrainingBuildConfig,
    timing_protocol_digest: str,
) -> dict[str, Any]:
    """Return the explicit pre-execution timed-training semantic allowlist."""

    if not isinstance(build, TrainingBuildConfig):
        raise TypeError("build must be a TrainingBuildConfig.")
    timing_digest = _require_digest(
        timing_protocol_digest,
        "timing_protocol_digest",
    )
    snapshot = _projection_snapshot_from_build(build)
    if snapshot["vectorization"]["vec_env"] != RL_WORKLOAD_VECTOR_KIND:
        raise ValueError("RL workload v1 requires DummyVecEnv.")
    return {
        "semantic_document": _semantic_document_from_snapshot(snapshot),
        "timing_protocol_digest": timing_digest,
    }


def _execution_document(
    request: RLCaseRequest,
    timing_protocol_digest: str,
) -> dict[str, Any]:
    return {
        "execution_spec_version": RL_EXECUTION_SPEC_VERSION,
        "timing_protocol_digest": timing_protocol_digest,
        "requested_total_environment_transitions": request.rl_training_steps,
        "warmup": {"rule": request.warmup_rule},
        "steady_state_windows": {
            "minimum_transition_count": (
                request.complete_window_transition_target
            ),
            "required_complete_window_count": (
                request.required_complete_window_count
            ),
            "partial_window_rule": request.partial_window_rule,
        },
        "worker_runtime": {
            "policy": request.worker_runtime_policy,
            "vector_kind": RL_WORKLOAD_VECTOR_KIND,
            "production_runtime_behavior": "unchanged",
        },
    }


def _has_intrinsically_custom_semantics(
    request: RLCaseRequest,
    build: TrainingBuildConfig,
) -> bool:
    if request.device_policy is not None:
        return True
    if thaw_json(request.timing_protocol) != _default_timing_protocol():
        return True
    if request.warmup_rule != RL_WARMUP_RULE:
        return True
    if request.partial_window_rule != RL_PARTIAL_WINDOW_RULE:
        return True
    if request.worker_runtime_policy != RL_WORKER_RUNTIME_POLICY:
        return True

    profile = ALGORITHM_PROFILES[request.algorithm]
    profile_n_envs = int(profile["algorithm_default_n_envs"])
    structurally_eligible_n_envs = (
        request.n_envs == "algorithm_default"
        or request.n_envs == profile_n_envs
        or request.n_envs == 1
        or (
            request.algorithm == "PPO"
            and request.n_envs in (2, 4, 8)
        )
    )
    if not structurally_eligible_n_envs:
        return True

    profile_constructor = thaw_json(profile["constructor_kwargs"])
    profile_policy = thaw_json(profile["policy_kwargs"])
    if thaw_json(build.algorithm.constructor_kwargs) != profile_constructor:
        return True
    if thaw_json(build.algorithm.policy_kwargs) != profile_policy:
        return True
    if request.algorithm in ("PPO", "A2C"):
        profile_rollout = int(
            profile["algorithm_default_rollout_transitions"]
        )
        if (
            build.algorithm.n_rollout_transitions_per_update_effective
            - build.algorithm.n_rollout_transitions_rounding_amount
            != profile_rollout
        ):
            return True
    return False


def _classification(
    request: RLCaseRequest,
    build: TrainingBuildConfig,
) -> str:
    if request.device_policy == "auto":
        return "diagnostic"
    if _has_intrinsically_custom_semantics(request, build):
        return "custom"
    return "preset_candidate"


def _eligibility(classification: str) -> RLEligibility:
    diagnostic = classification == "diagnostic"
    return RLEligibility(
        canonical_status=False,
        submission_status=False,
        semantic_reuse_import=not diagnostic,
        sample_aggregation=not diagnostic,
        diagnostic_execution=True,
    )


def _profile_warnings(build: TrainingBuildConfig) -> tuple[str, ...]:
    warnings = list(build.warnings)
    rounding = build.algorithm.n_rollout_transitions_rounding_amount
    if rounding:
        warnings.append(
            build.algorithm.name
            + " requested aggregate rollout transitions require upward "
            "rounding by "
            + str(rounding)
            + " transition(s) for the selected environment count."
        )
    return tuple(warnings)


def resolve_rl_profile_case(
    case: RLCaseRequest,
) -> ResolvedRLProfileCase:
    """Resolve one request through the strict production authorities."""

    if not isinstance(case, RLCaseRequest):
        raise TypeError("case must be an RLCaseRequest.")
    config = build_requested_training_config(case)
    complete_requested_snapshot = requested_snapshot(config)
    requested_digest = canonical_snapshot_digest(
        complete_requested_snapshot
    )
    build = resolve_training_request(config)
    if build.requested_digest != requested_digest:
        raise ValueError(
            "production resolver requested digest disagrees with the "
            "requested snapshot authority."
        )

    timing_digest = case.timing_protocol_digest
    projection = rl_semantic_projection(build, timing_digest)
    case_spec = CaseSpec(
        readable_prefix=case.case_name,
        semantic_document=projection["semantic_document"],
        timing_protocol=thaw_json(case.timing_protocol),
    )
    if case_spec.timing_protocol_digest != timing_digest:
        raise ValueError("timing protocol digest changed during resolution.")
    if case_spec.semantic_case_digest != canonical_json_digest(projection):
        raise ValueError(
            "RL projection and CaseSpec semantic digests disagree."
        )
    execution_spec = ExecutionSpec(
        semantic_case_id=case_spec.semantic_case_id,
        execution_document=_execution_document(case, timing_digest),
    )
    classification = _classification(case, build)
    return ResolvedRLProfileCase(
        request=case,
        build=build,
        requested_snapshot=copy.deepcopy(complete_requested_snapshot),
        requested_config_digest=requested_digest,
        semantic_projection=copy.deepcopy(projection),
        case_spec=case_spec,
        execution_spec=execution_spec,
        classification=classification,
        eligibility=_eligibility(classification),
        warnings=_profile_warnings(build),
    )


def build_algorithm_comparison_case(
    algorithm: AlgorithmName,
    rl_training_steps: int,
    **overrides: Any,
) -> RLCaseRequest:
    """Build one controlled common-single-environment algorithm case."""

    return RLCaseRequest(
        case_name="rl-algorithm-" + str(algorithm).lower(),
        algorithm=algorithm,
        rl_training_steps=rl_training_steps,
        n_envs=1,
        case_family="algorithm_comparison",
        **overrides,
    )


def build_ppo_step_scaling_case(
    rl_training_steps: int,
    **overrides: Any,
) -> RLCaseRequest:
    """Build one controlled PPO aggregate-transition scaling case."""

    return RLCaseRequest(
        case_name="rl-ppo-steps-" + str(rl_training_steps),
        algorithm="PPO",
        rl_training_steps=rl_training_steps,
        n_envs=1,
        case_family="ppo_step_scaling",
        **overrides,
    )


def build_ppo_vectorization_case(
    n_envs: int,
    *,
    rl_training_steps: int = 100_000,
    **overrides: Any,
) -> RLCaseRequest:
    """Build one PPO DummyVecEnv scaling case."""

    return RLCaseRequest(
        case_name="rl-ppo-vector-" + str(n_envs),
        algorithm="PPO",
        rl_training_steps=rl_training_steps,
        n_envs=n_envs,
        case_family="ppo_vector_scaling",
        **overrides,
    )


def compare_rl_projection_to_finalized_snapshot(
    projection: Mapping[str, Any],
    finalized_snapshot: Mapping[str, Any],
) -> dict[str, Any]:
    """Purely compare precomputed semantics with stable finalized facts."""

    if not isinstance(projection, Mapping):
        raise TypeError("projection must be a mapping.")
    if not isinstance(finalized_snapshot, Mapping):
        raise TypeError("finalized_snapshot must be a mapping.")
    detached_projection = validate_json_value(
        thaw_json(projection),
        path="projection",
    )
    detached_snapshot = validate_resolved_snapshot(
        thaw_json(finalized_snapshot)
    )
    timing_digest = _require_digest(
        detached_projection.get("timing_protocol_digest"),
        "projection.timing_protocol_digest",
    )
    candidate = {
        "semantic_document": _semantic_document_from_snapshot(
            detached_snapshot
        ),
        "timing_protocol_digest": timing_digest,
    }
    if candidate != detached_projection:
        raise ValueError(
            "finalized stable training facts do not match the precomputed "
            "RL semantic projection."
        )

    runtime_model = detached_snapshot.get("runtime_model")
    if type(runtime_model) is not dict:
        raise ValueError(
            "finalized_snapshot.runtime_model must be an object."
        )
    actual_device = runtime_model.get("device")
    if type(actual_device) is not str or not actual_device:
        raise ValueError(
            "finalized_snapshot.runtime_model.device must be a string."
        )
    device = detached_projection["semantic_document"]["algorithm"]["device"]
    diagnostic = device["policy"] == "auto"
    if diagnostic:
        if (
            device.get("ineligibility_marker")
            != RL_DEVICE_AUTO_INELIGIBILITY
        ):
            raise ValueError("diagnostic auto device marker is missing.")
        requested_device_policy = "auto"
    else:
        requested_device_policy = device["effective_constructor_device"]
        if actual_device != requested_device_policy:
            raise ValueError(
                "observed runtime device does not match the concrete "
                "predeclared device."
            )
    return {
        "matches": True,
        "diagnostic": diagnostic,
        "requested_device_policy": requested_device_policy,
        "actual_device": actual_device,
    }


def rl_case_request_to_dict(request: RLCaseRequest) -> dict[str, Any]:
    """Return the plain JSON-native request transferred to a spawned worker."""

    if not isinstance(request, RLCaseRequest):
        raise TypeError("request must be an RLCaseRequest.")
    return {
        "case_name": request.case_name,
        "algorithm": request.algorithm,
        "rl_training_steps": request.rl_training_steps,
        "vec_env": request.vec_env,
        "n_envs": request.n_envs,
        "n_rollout_transitions_per_update": (
            request.n_rollout_transitions_per_update
        ),
        "algorithm_hyperparameters": thaw_json(
            request.algorithm_hyperparameters
        ),
        "policy_kwargs": thaw_json(request.policy_kwargs),
        "device_policy": request.device_policy,
        "timing_protocol": thaw_json(request.timing_protocol),
        "warmup_rule": request.warmup_rule,
        "complete_window_transition_target": (
            request.complete_window_transition_target
        ),
        "required_complete_window_count": (
            request.required_complete_window_count
        ),
        "partial_window_rule": request.partial_window_rule,
        "worker_runtime_policy": request.worker_runtime_policy,
        "case_family": request.case_family,
    }


def rl_case_request_from_dict(value: Mapping[str, Any]) -> RLCaseRequest:
    """Strictly reconstruct a spawned worker request without default overlay."""

    if not isinstance(value, Mapping):
        raise TypeError("RL request wire value must be a mapping.")
    detached = validate_json_value(dict(value), path="request")
    expected = {
        "case_name",
        "algorithm",
        "rl_training_steps",
        "vec_env",
        "n_envs",
        "n_rollout_transitions_per_update",
        "algorithm_hyperparameters",
        "policy_kwargs",
        "device_policy",
        "timing_protocol",
        "warmup_rule",
        "complete_window_transition_target",
        "required_complete_window_count",
        "partial_window_rule",
        "worker_runtime_policy",
        "case_family",
    }
    missing = sorted(expected - set(detached))
    unexpected = sorted(set(detached) - expected)
    if missing or unexpected:
        name = missing[0] if missing else unexpected[0]
        raise ValueError("request." + name + " is missing or unsupported.")
    return RLCaseRequest(**detached)


def rl_reuse_record(
    source: ResolvedRLProfileCase,
    destination: ResolvedRLProfileCase,
    *,
    source_execution_reference: str,
    source_execution_spec_digest: str,
    destination_execution_spec_digest: str,
    source_snapshot_reference: Mapping[str, Any],
    source_actual_completed_transitions: int,
    source_complete_window_count: int,
    source_status: str = "completed",
    runtime_compatibility_digest: str,
    destination_runtime_compatibility_digest: str,
) -> dict[str, Any]:
    """Decide execution-strength reuse without combining learn invocations."""

    if not isinstance(source, ResolvedRLProfileCase) or not isinstance(
        destination,
        ResolvedRLProfileCase,
    ):
        raise TypeError(
            "source and destination must be ResolvedRLProfileCase values."
        )
    if (
        type(source_execution_reference) is not str
        or not source_execution_reference
    ):
        raise ValueError(
            "source_execution_reference must be a non-empty string."
        )
    source_execution_digest = _require_digest(
        source_execution_spec_digest,
        "source_execution_spec_digest",
    )
    destination_execution_digest = _require_digest(
        destination_execution_spec_digest,
        "destination_execution_spec_digest",
    )
    expected_source_reference = execution_instance_id(
        source.semantic_case_id,
        source_execution_digest,
    )
    if source_execution_reference != expected_source_reference:
        raise ValueError(
            "source_execution_reference must identify the source execution."
        )
    if source_status not in ("completed", "failed", "interrupted", "skipped"):
        raise ValueError("source_status is unsupported.")
    actual_transitions = _exact_positive_int(
        source_actual_completed_transitions,
        "source_actual_completed_transitions",
    )
    complete_windows = _exact_positive_int(
        source_complete_window_count,
        "source_complete_window_count",
    )
    snapshot_reference = validate_json_value(
        dict(source_snapshot_reference),
        path="source_snapshot_reference",
    )
    source_runtime = _require_digest(
        runtime_compatibility_digest,
        "runtime_compatibility_digest",
    )
    destination_runtime = _require_digest(
        destination_runtime_compatibility_digest,
        "destination_runtime_compatibility_digest",
    )
    source_document = thaw_json(
        source.execution_spec.execution_document
    )
    destination_document = thaw_json(
        destination.execution_spec.execution_document
    )
    source_windows = source_document["steady_state_windows"]
    destination_windows = destination_document["steady_state_windows"]
    same_rules = (
        source.semantic_case_digest == destination.semantic_case_digest
        and source.timing_protocol_digest
        == destination.timing_protocol_digest
        and source_document["warmup"] == destination_document["warmup"]
        and source_document["worker_runtime"]
        == destination_document["worker_runtime"]
        and source_windows["minimum_transition_count"]
        == destination_windows["minimum_transition_count"]
        and source_windows["partial_window_rule"]
        == destination_windows["partial_window_rule"]
    )
    stronger_or_equal = (
        source_document["requested_total_environment_transitions"]
        >= destination_document[
            "requested_total_environment_transitions"
        ]
        and source_windows["required_complete_window_count"]
        >= destination_windows["required_complete_window_count"]
        and actual_transitions
        >= destination_document[
            "requested_total_environment_transitions"
        ]
        and complete_windows
        >= destination_windows["required_complete_window_count"]
    )
    compatible = (
        same_rules
        and stronger_or_equal
        and source_status == "completed"
        and source_runtime == destination_runtime
        and source.eligibility.semantic_reuse_import
        and destination.eligibility.semantic_reuse_import
        and source.eligibility.sample_aggregation
        and destination.eligibility.sample_aggregation
    )
    return {
        "compatible": compatible,
        "source_execution_reference": source_execution_reference,
        "source_execution_spec_digest": (
            source_execution_digest
        ),
        "destination_execution_spec_digest": (
            destination_execution_digest
        ),
        "source_snapshot_reference": snapshot_reference,
        "source_actual_completed_transitions": actual_transitions,
        "source_complete_window_count": complete_windows,
        "runtime_compatibility_digest": source_runtime,
        "window_ownership": "single_model_learn_call",
    }


# Short aliases retained for callers that describe the comparison as validation.
validate_rl_projection_against_finalized_snapshot = (
    compare_rl_projection_to_finalized_snapshot
)
build_step_scaling_case = build_ppo_step_scaling_case
build_vectorization_case = build_ppo_vectorization_case
