#!/usr/bin/env python

"""Profile RL-style timing for the autonomous-driving environment.

This script has two profiling modes:

* ``rollout`` runs a manual Gymnasium rollout with an SB3 PPO policy object and
  explicit per-step timers around policy inference, wrappers, env.step,
  bicycle integration, road queries, observation generation, reward shaping,
  and resets.
* ``sb3-learn`` runs a short SB3 PPO.learn call with a timed PPO subclass. This
  captures full SB3 training overhead, including rollout collection and policy
  updates, while the same runtime env instrumentation records nested env costs.

The benchmark is intentionally deterministic and repo-local. It does not train
for quality; it measures where wall-clock time goes in an RL-shaped workload.
"""

from __future__ import annotations

import argparse
import copy
import cProfile
import datetime as _datetime
import gc
import hashlib
import io
import math
from pathlib import Path
import platform
import pstats
import random
import shutil
import sys
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from dreamgym.profiling.common import (
    activate_matplotlib_profile_cache,
    display_output_path,
    resolve_profile_output_path,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    sanitize_diagnostic_message,
)


import gymnasium as gym  # noqa: E402
from gymnasium import spaces  # noqa: E402

import dreamgym  # noqa: F401,E402  # Registers the Gymnasium env.


Road: Any = None
CombinedLaneSpeedRewardWrapper: Any = None


def _ensure_rl_runtime_imports() -> None:
    global Road, CombinedLaneSpeedRewardWrapper

    activate_matplotlib_profile_cache("rl-profile")
    if Road is None:
        from dreamgym.envs.road import Road as RoadClass

        Road = RoadClass
    if CombinedLaneSpeedRewardWrapper is None:
        from dreamgym.training.autonomous_driving.rewards import (
            CombinedLaneSpeedRewardWrapper as CombinedLaneSpeedRewardWrapperClass,
        )

        CombinedLaneSpeedRewardWrapper = CombinedLaneSpeedRewardWrapperClass


LOOKAHEAD_DISTANCE_M = 100.0
TARGET_LANE_INDEX = 1
CONE_DETECTIONS_NUM_CONES_MAX = 20


class TimingRecorder:
    def __init__(self) -> None:
        self.samples_ns: Dict[str, List[int]] = {}
        self.enabled = True

    def record(self, bucket: str, elapsed_ns: int) -> None:
        if not self.enabled:
            return
        self.samples_ns.setdefault(bucket, []).append(int(elapsed_ns))

    def clear(self) -> None:
        self.samples_ns.clear()

    def timed_call(self, bucket: str, fn: Callable, *args: Any, **kwargs: Any) -> Any:
        if not self.enabled:
            return fn(*args, **kwargs)
        tic = time.perf_counter_ns()
        try:
            return fn(*args, **kwargs)
        finally:
            self.record(bucket, time.perf_counter_ns() - tic)

    def summarize(self) -> List[Dict[str, float]]:
        rows = []
        for bucket, samples in self.samples_ns.items():
            if len(samples) == 0:
                continue
            arr_ns = np.asarray(samples, dtype=np.float64)
            arr_us = arr_ns / 1000.0
            total_ns = float(np.sum(arr_ns))
            mean_us = float(np.mean(arr_us))
            rows.append({
                "bucket": bucket,
                "calls": int(len(samples)),
                "total_ns": total_ns,
                "total_ms": total_ns / 1_000_000.0,
                "mean_us": mean_us,
                "median_us": float(np.median(arr_us)),
                "p95_us": float(np.percentile(arr_us, 95.0)),
                "p99_us": float(np.percentile(arr_us, 99.0)),
                "min_us": float(np.min(arr_us)),
                "max_us": float(np.max(arr_us)),
            })
        rows.sort(key=lambda row: row["total_ns"], reverse=True)
        return rows

    def total_ns_for(self, bucket: str) -> float:
        samples = self.samples_ns.get(bucket, ())
        return float(sum(samples))

    def mean_ns_for(self, bucket: str) -> float:
        samples = self.samples_ns.get(bucket, ())
        if len(samples) == 0:
            return 0.0
        return float(sum(samples)) / float(len(samples))


class RuntimeInstrumentation:
    """Patch hot methods on one env stack and record inclusive timings."""

    def __init__(
        self,
        recorder: TimingRecorder,
        final_env: gym.Env,
        base_env: gym.Env,
        wrappers: Dict[str, Optional[gym.Wrapper]],
    ) -> None:
        self.recorder = recorder
        self.final_env = final_env
        self.base_env = base_env
        self.wrappers = wrappers
        self._patches: List[Tuple[Any, str, Any]] = []

    def install(self) -> None:
        self._patch_method(self.base_env, "step", "base_env_step_total")
        self._patch_method(self.base_env, "reset", "base_env_reset_total")
        self._patch_method(self.base_env.car, "integrate", "bicycle_integration")
        self._patch_method(
            self.base_env,
            "_get_observation_and_info_and_update_ground_truth",
            "observation_total",
        )
        self._patch_method(self.base_env, "_get_road_info_for_pose", "road_info_total")
        self._patch_method(
            self.base_env,
            "_get_cone_info_for_observation_if_needed",
            "cone_info_total",
        )
        self._patch_method(self.base_env, "_default_lane_keep_delta", "internal_lane_keep")
        self._patch_method(self.base_env, "_default_cruise_drive_command", "internal_cruise")

        for key, bucket in (
            ("rescale", "rescale_action_step_total"),
            ("domain_randomization", "domain_randomization_step_total"),
            ("time_limit", "time_limit_step_total"),
            ("reward", "reward_wrapper_step_total"),
        ):
            wrapper = self.wrappers.get(key)
            if wrapper is not None:
                self._patch_method(wrapper, "step", bucket)
        self._patch_method(self.final_env, "reset", "final_env_reset_total")

    def restore(self) -> None:
        for obj, method_name, original in reversed(self._patches):
            setattr(obj, method_name, original)
        self._patches = []

    def _patch_method(self, obj: Any, method_name: str, bucket: str) -> None:
        if obj is None or not hasattr(obj, method_name):
            return
        original = getattr(obj, method_name)

        def timed_method(*args: Any, **kwargs: Any) -> Any:
            return self.recorder.timed_call(bucket, original, *args, **kwargs)

        setattr(obj, method_name, timed_method)
        self._patches.append((obj, method_name, original))


class ProfileDomainRandomizationWrapper(gym.Wrapper):
    """Small deterministic road-randomization wrapper for profiling resets."""

    def __init__(self, env: gym.Env, seed: int = 0) -> None:
        super().__init__(env)
        self.rng = random.Random(int(seed))

    def _generate_random_road_spec(self) -> Dict:
        num_elements = self.rng.randint(2, 5)
        elements = []
        for element_idx in range(num_elements):
            if self.rng.random() < 0.55:
                element = {
                    "geometry": {
                        "type": "straight",
                        "length_m": self.rng.uniform(50.0, 200.0),
                    },
                }
            else:
                curvature = self.rng.uniform(-1.0 / 500.0, 1.0 / 500.0)
                if abs(curvature) < 1e-5:
                    curvature = 1.0 / 500.0
                angle_degrees = self.rng.uniform(10.0, 60.0)
                element = {
                    "geometry": {
                        "type": "circular_arc",
                        "curvature_per_m": curvature,
                        "length_m": (
                            math.radians(angle_degrees) / abs(curvature)
                        ),
                    },
                }
            if element_idx == 0:
                element["lanes"] = {
                    "reference_line_role": "lane_boundary",
                    "left": [{"width_m": {"start": 3.0}}],
                    "right": [],
                }
                element["cross_section_width_interpolation"] = "linear"
            elements.append(element)
        return {
            "active_lane_minimum_width_m": 0.02,
            "defaults": {"speed_limit_kph": 80.0},
            "elements": elements,
        }

    def reset(self, **kwargs: Any) -> Tuple[Any, Dict]:
        base_env = self.env.unwrapped
        road_spec = self._generate_random_road_spec()
        base_env._install_road(
            Road(
                road_spec=road_spec,
                minimum_curvature_magnitude_per_m=(1 / 10000),
            )
        )
        if hasattr(base_env, "_configure_observation_flags_spaces_and_blanks"):
            # Road-owned cone count can depend on the generated road. The profile
            # currently uses a fixed cone cap, so no observation-space rebuild is
            # needed for the default cases.
            pass
        return self.env.reset(**kwargs)


def build_road_spec(num_elements: int, include_cones: bool = False) -> Dict:
    elements = []
    for element_idx in range(num_elements):
        speed_limit_kph = 80.0 if element_idx % 5 else 60.0
        if element_idx % 3 == 1:
            curvature_sign = 1.0 if (element_idx // 3) % 2 == 0 else -1.0
            element = {
                "geometry": {
                    "type": "circular_arc",
                    "curvature_per_m": (
                        curvature_sign / (45.0 + 5.0 * (element_idx % 4))
                    ),
                    "length_m": 20.0 + 2.0 * (element_idx % 5),
                },
                "speed_limit_kph": speed_limit_kph,
            }
        else:
            element = {
                "geometry": {
                    "type": "straight",
                    "length_m": 28.0 + 3.0 * (element_idx % 4),
                },
                "speed_limit_kph": speed_limit_kph,
            }

        if element_idx == 0:
            element["lanes"] = {
                "reference_line_role": "lane_boundary",
                "left": [{"width_m": {"start": 3.0}}],
                "right": [],
            }
            element["cross_section_width_interpolation"] = "linear"
            if include_cones:
                element["cones"] = [
                    {
                        "placement": {
                            "mode": "reference_line",
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "yellow",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                    {
                        "placement": {
                            "mode": "lane_line",
                            "lane_line_index": 1,
                            "lateral_offset_from_anchor_m": 0.0,
                        },
                        "color": "blue",
                        "inter_cone_spacing": {
                            "distribution": "clipped_normal",
                            "mean_m": 4.0,
                            "standard_deviation_m": 0.15,
                            "lower_bound_m": 3.0,
                            "upper_bound_m": 5.0,
                        },
                    },
                ]

        elements.append(element)

    return {
        "active_lane_minimum_width_m": 0.02,
        "defaults": {"speed_limit_kph": 80.0},
        "elements": elements,
    }


def bicycle_model_config(profile: str) -> Dict[str, Any]:
    base = {
        "axle_geometry": {
            "front_axle_distance_from_center_of_mass_m": 0.55 * 2.875,
            "rear_axle_distance_from_center_of_mass_m": 0.45 * 2.875,
        },
        "mass_properties": {
            "mass_kg": 2000.0,
            "yaw_moment_of_inertia_kg_m2": (
                (1.0 / 12.0) * 2000.0 * (4.692**2 + 1.850**2)
            ),
        },
        "longitudinal_force_model": {
            "normalized_motor_command_force_gain_n": (
                (1.0 * 400.0 * 9.0) / 0.2286
            ),
            "quadratic_aerodynamic_drag_coefficient_kg_per_m": (
                0.5 * 0.24 * 2.2204 * 1.202
            ),
        },
        "steering": {
            "physical_front_wheel_angle_offset_from_request_rad": 0.0,
            "requested_front_wheel_angle_magnitude_limit_rad": math.radians(45.0),
            "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                "lower": -math.radians(45.0),
                "upper": math.radians(45.0),
            },
        },
        "body_geometry": {
            "front_extent_from_center_of_mass_m": (0.55 * 2.875) * 1.5,
            "rear_extent_from_center_of_mass_m": (0.45 * 2.875) * 1.5,
            "width_m": 2.50,
        },
    }
    if profile == "training":
        speed_range = {"lower": 500.0 / 3.6, "upper": 600.0 / 3.6}
    elif profile == "dynamic":
        speed_range = {"lower": 3.0, "upper": 5.0}
    else:
        raise ValueError("Unknown vehicle profile: " + str(profile))
    base["kinematic_dynamic_transition"] = {
        "body_longitudinal_speed_range_mps": speed_range
    }
    return base


def fixed_initial_state_config() -> Dict[str, Any]:
    def bounds(lower: float, upper: float) -> Dict[str, float]:
        return {"lower": lower, "upper": upper}

    return {
        "bounds": {
            "world_pose": {
                "x_m": bounds(0.0, 0.0),
                "y_m": bounds(-1.0, 1.0),
                "heading_rad": bounds(0.0, 0.0),
            },
            "body_motion": {
                "longitudinal_velocity_mps": bounds(55.0 / 3.6, 65.0 / 3.6),
                "lateral_velocity_mps": bounds(0.0, 0.0),
                "yaw_rate_rad_per_s": bounds(0.0, 0.0),
            },
            "front_wheel_steering_angle_rad": bounds(0.0, 0.0),
        },
        "reference_line_progress_search": None,
    }


def make_observation_config(
    *,
    tracking_mode: str,
    lookahead_points: int,
    include_cones: bool,
    include_next_speed_changes: bool,
    output_destination: str,
) -> Dict:
    if output_destination not in ("observation", "info"):
        raise ValueError(
            "output_destination must be 'observation' or 'info'."
        )

    routed = {"destination": output_destination, "scaling_factor": 1.0}
    observation_config = {
        "body_longitudinal_velocity_mps": dict(routed),
        "front_wheel_steering_angle_rad": dict(routed),
        "lateral_error_from_target_line_m": dict(routed),
        "heading_error_from_target_line_rad": dict(routed),
        "target_line_curvature_per_m": dict(routed),
        "speed_limit_mps": dict(routed),
        "recommended_speed_mps": dict(routed),
        "target_line_lookahead": {
            "maximum_distance_m": LOOKAHEAD_DISTANCE_M,
            "sample_count": max(1, int(lookahead_points)),
            "positions_in_body_frame_m": {
                "destination": (
                    output_destination if lookahead_points > 0 else "neither"
                ),
                "scaling_factor": 1.0,
            },
            "curvatures_per_m": {
                "destination": (
                    output_destination if lookahead_points > 0 else "neither"
                ),
                "scaling_factor": 1.0,
            },
        },
    }

    if tracking_mode not in ("target_lane", "reference_line"):
        raise ValueError("Unknown tracking_mode: " + str(tracking_mode))

    if include_next_speed_changes:
        for family in (
            "next_speed_limit_change",
            "next_recommended_speed_change",
        ):
            observation_config[family] = {
                "value_mps": dict(routed),
                "reference_line_distance_m": dict(routed),
            }

    if include_cones:
        observation_config["cone_detections"] = {
            "maximum_detection_count": CONE_DETECTIONS_NUM_CONES_MAX,
            "acquisition": {
                "horizontal_field_of_view_deg": 120.0,
                "forward_position_upper_bound_m": 30.0,
            },
            "positions_in_body_frame_m": dict(routed),
            "color_ids": {"destination": output_destination},
            "count": {"destination": output_destination},
        }

    return observation_config


def target_line_config_for_tracking_mode(tracking_mode: str) -> Dict[str, Any]:
    if tracking_mode == "target_lane":
        return {
            "mode": "lane_center",
            "lane_index": TARGET_LANE_INDEX,
            "require_active_lane": True,
        }
    if tracking_mode == "reference_line":
        return {"mode": "reference_line"}
    raise ValueError("Unknown tracking_mode: " + str(tracking_mode))


def make_env_stack(args: argparse.Namespace) -> Dict[str, Any]:
    road_spec = build_road_spec(args.num_elements, include_cones=args.include_cones)
    observation_config = make_observation_config(
        tracking_mode=args.tracking_mode,
        lookahead_points=args.lookahead_points,
        include_cones=args.include_cones,
        include_next_speed_changes=args.include_next_speed_changes,
        output_destination=args.output_destination,
    )

    env = gym.make(
        "dreamgym/autonomous_driving_env",
        render_mode=None,
        bicycle_model_config=bicycle_model_config(args.vehicle_profile),
        road_spec=road_spec,
        integration_config={
            "method": args.integration_method,
            "environment_step_duration_s": args.integration_ts,
            "substep_count": args.integration_substeps,
        },
        termination_config={
            "planar_speed_bounds_mps": {
                "lower": 0.0,
                "upper": 200.0 / 3.6,
            },
            "absolute_lateral_error_from_target_line_upper_bound_m": 20.0,
        },
        initial_state_config=fixed_initial_state_config(),
        observation_config=observation_config,
        target_line_config=target_line_config_for_tracking_mode(
            args.tracking_mode
        ),
        internal_policy_config={
            "lane_keeping": {"enabled": args.enable_lane_keep},
            "cruise_control": {
                "enabled": args.enable_cruise_control,
                "policy": {
                    "target_speed": {
                        "source": (
                            "road_recommended_speed_then_speed_limit"
                        )
                    }
                },
            },
            "action_interface": "auto",
        },
        observation_format=args.observation_format,
    )
    base_env = env.unwrapped
    base_env.set_tire_force_condition(args.tire_force_condition)

    wrappers: Dict[str, Optional[gym.Wrapper]] = {
        "rescale": None,
        "domain_randomization": None,
        "time_limit": None,
        "reward": None,
    }

    if args.rescale_action:
        if np.any(env.action_space.low == env.action_space.high):
            env.close()
            raise ValueError(
                "RescaleAction cannot be applied to action dimensions with equal bounds"
            )
        rescale_low = np.full(env.action_space.shape, -1.0, dtype=np.float32)
        rescale_high = np.full(env.action_space.shape, 1.0, dtype=np.float32)
        env = gym.wrappers.RescaleAction(env, min_action=rescale_low, max_action=rescale_high)
        wrappers["rescale"] = env

    if args.domain_randomization:
        env = ProfileDomainRandomizationWrapper(env, seed=args.domain_seed)
        wrappers["domain_randomization"] = env

    if args.max_episode_steps is not None:
        env = gym.wrappers.TimeLimit(env, max_episode_steps=args.max_episode_steps)
        wrappers["time_limit"] = env

    if args.reward_wrapper:
        env = CombinedLaneSpeedRewardWrapper(env)
        wrappers["reward"] = env

    return {
        "env": env,
        "base_env": base_env,
        "wrappers": wrappers,
        "road_spec": road_spec,
        "observation_config": observation_config,
    }


def import_sb3_modules() -> Tuple[Any, Any]:
    try:
        import stable_baselines3 as sb3
        import torch
    except ModuleNotFoundError as exc:
        missing = exc.name or "stable_baselines3"
        raise SystemExit(
            "Missing optional RL dependency: " + missing + "\n"
            "Install the RL extra with:\n"
            "  python -m pip install -e .[rl]"
        ) from exc
    return sb3, torch


def sb3_policy_name(observation_space: spaces.Space) -> str:
    if isinstance(observation_space, spaces.Dict):
        return "MultiInputPolicy"
    return "MlpPolicy"


def make_timed_ppo_class(ppo_class: Any, recorder: Optional[TimingRecorder]) -> Any:
    if recorder is None:
        return ppo_class

    class TimedPPO(ppo_class):  # type: ignore[misc,valid-type]
        def collect_rollouts(self, *args: Any, **kwargs: Any) -> Any:
            return recorder.timed_call(
                "sb3_collect_rollouts_total",
                super().collect_rollouts,
                *args,
                **kwargs,
            )

        def train(self) -> Any:
            return recorder.timed_call("sb3_train_total", super().train)

    return TimedPPO


def make_ppo_model(
    sb3: Any,
    env: Any,
    args: argparse.Namespace,
    recorder: Optional[TimingRecorder] = None,
) -> Any:
    ppo_class = make_timed_ppo_class(sb3.PPO, recorder)
    policy = sb3_policy_name(env.observation_space)
    return ppo_class(
        policy,
        env,
        n_steps=args.n_steps,
        batch_size=args.batch_size,
        n_epochs=args.n_epochs,
        learning_rate=args.learning_rate,
        gamma=args.gamma,
        gae_lambda=args.gae_lambda,
        clip_range=args.clip_range,
        ent_coef=args.ent_coef,
        vf_coef=args.vf_coef,
        seed=args.seed,
        device=args.device,
        verbose=0,
    )


def make_progress_callback(args: argparse.Namespace) -> Optional[Any]:
    if not getattr(args, "progress", False):
        return None

    from stable_baselines3.common.callbacks import BaseCallback

    target_timesteps = effective_sb3_timesteps(args)
    interval_pct = float(args.progress_interval_pct)
    label = getattr(args, "progress_label", "learn")

    def format_pct(value: float) -> str:
        if abs(value - round(value)) < 1e-9:
            return f"{int(round(value))}%"
        return f"{value:.1f}%"

    def format_duration(seconds: float) -> str:
        if not np.isfinite(seconds) or seconds < 0.0:
            return "unknown"
        seconds_int = int(round(seconds))
        hours, remainder = divmod(seconds_int, 3600)
        minutes, seconds_part = divmod(remainder, 60)
        if hours > 0:
            return f"{hours:d}:{minutes:02d}:{seconds_part:02d}"
        return f"{minutes:d}:{seconds_part:02d}"

    class PercentProgressCallback(BaseCallback):  # type: ignore[misc,valid-type]
        def __init__(self) -> None:
            super().__init__(verbose=0)
            self._next_pct = interval_pct
            self._last_printed_pct = -1.0
            self._start_time_s = 0.0

        def _on_training_start(self) -> None:
            self._start_time_s = time.perf_counter()
            self._print_progress(0.0)

        def _on_step(self) -> bool:
            if target_timesteps <= 0:
                return True

            current_pct = min(100.0, float(self.num_timesteps) / float(target_timesteps) * 100.0)
            while current_pct + 1e-12 >= self._next_pct and self._next_pct < 100.0:
                self._print_progress(self._next_pct)
                self._next_pct += interval_pct
            if current_pct >= 100.0 and self._last_printed_pct < 100.0:
                self._print_progress(100.0)
            return True

        def _print_progress(self, pct_value: float) -> None:
            pct_value = min(100.0, max(0.0, pct_value))
            if pct_value <= self._last_printed_pct:
                return
            current_steps = min(int(self.num_timesteps), int(target_timesteps))
            elapsed_s = time.perf_counter() - self._start_time_s
            if current_steps > 0:
                steps_per_s = float(current_steps) / max(elapsed_s, 1e-12)
                eta_s = float(target_timesteps - current_steps) / max(steps_per_s, 1e-12)
                eta_text = format_duration(eta_s)
            else:
                eta_text = "calculating"
            print(
                f"{label}: {format_pct(pct_value)} "
                f"({current_steps}/{target_timesteps} steps), "
                f"elapsed {format_duration(elapsed_s)}, eta {eta_text}",
                flush=True,
            )
            self._last_printed_pct = pct_value

    return PercentProgressCallback()


def close_env_safely(env: Optional[gym.Env]) -> None:
    if env is None:
        return
    try:
        env.close()
    except Exception:
        pass


def clone_args(args: argparse.Namespace, **overrides: Any) -> argparse.Namespace:
    cloned = copy.copy(args)
    for key, value in overrides.items():
        setattr(cloned, key, value)
    return cloned


def effective_vec_env_kind(args: argparse.Namespace) -> str:
    if args.vec_env == "auto":
        return "raw" if args.n_envs == 1 else "dummy"
    return str(args.vec_env)


def effective_sb3_timesteps(args: argparse.Namespace, metadata: Optional[Dict[str, Any]] = None) -> int:
    if metadata is not None:
        actual = metadata.get("actual_timesteps")
        if actual is not None:
            return int(actual)
    rollout_size = int(args.n_steps) * int(args.n_envs)
    return int(math.ceil(float(args.learn_timesteps) / float(rollout_size)) * rollout_size)


def make_env_stack_for_vector(args: argparse.Namespace, env_index: int) -> Dict[str, Any]:
    env_args = clone_args(args, domain_seed=int(args.domain_seed) + int(env_index))
    return make_env_stack(env_args)


def make_training_env(
    args: argparse.Namespace,
    recorder: TimingRecorder,
) -> Tuple[Any, List[RuntimeInstrumentation], str, bool]:
    """Build the env passed to PPO and install parent-process timing hooks.

    Child-process env internals are not timed for SubprocVecEnv because the
    in-memory recorder is intentionally process-local. SB3 collect/train/learn
    timings are still recorded in the parent process.
    """

    vec_kind = effective_vec_env_kind(args)
    instrumentations: List[RuntimeInstrumentation] = []

    if vec_kind == "raw":
        profile_stack = make_env_stack(args)
        instrumentation = RuntimeInstrumentation(
            recorder,
            final_env=profile_stack["env"],
            base_env=profile_stack["base_env"],
            wrappers=profile_stack["wrappers"],
        )
        instrumentation.install()
        instrumentations.append(instrumentation)
        return profile_stack["env"], instrumentations, vec_kind, True

    if vec_kind == "dummy":
        from stable_baselines3.common.vec_env import DummyVecEnv

        def make_dummy_thunk(env_index: int) -> Callable[[], gym.Env]:
            def _init() -> gym.Env:
                profile_stack = make_env_stack_for_vector(args, env_index)
                instrumentation = RuntimeInstrumentation(
                    recorder,
                    final_env=profile_stack["env"],
                    base_env=profile_stack["base_env"],
                    wrappers=profile_stack["wrappers"],
                )
                instrumentation.install()
                instrumentations.append(instrumentation)
                return profile_stack["env"]

            return _init

        env = DummyVecEnv([make_dummy_thunk(idx) for idx in range(args.n_envs)])
        return env, instrumentations, vec_kind, True

    if vec_kind == "subproc":
        from stable_baselines3.common.vec_env import SubprocVecEnv

        def make_subproc_thunk(env_index: int) -> Callable[[], gym.Env]:
            def _init() -> gym.Env:
                return make_env_stack_for_vector(args, env_index)["env"]

            return _init

        env = SubprocVecEnv(
            [make_subproc_thunk(idx) for idx in range(args.n_envs)],
            start_method=args.subproc_start_method,
        )
        return env, instrumentations, vec_kind, False

    raise ValueError("Unknown vector env kind: " + str(vec_kind))


def restore_instrumentations(instrumentations: Iterable[RuntimeInstrumentation]) -> None:
    for instrumentation in instrumentations:
        instrumentation.restore()


def run_manual_rollout(
    sb3: Any,
    args: argparse.Namespace,
) -> Tuple[List[Dict[str, float]], Dict[str, Any]]:
    model_stack = make_env_stack(args)
    model = make_ppo_model(sb3, model_stack["env"], args)
    close_env_safely(model_stack["env"])

    profile_stack = make_env_stack(args)
    env = profile_stack["env"]
    base_env = profile_stack["base_env"]
    recorder = TimingRecorder()
    instrumentation = RuntimeInstrumentation(
        recorder,
        final_env=env,
        base_env=base_env,
        wrappers=profile_stack["wrappers"],
    )
    instrumentation.install()

    metadata: Dict[str, Any] = {
        "timed_steps": int(args.rollout_steps),
        "warmup_steps": int(args.warmup_steps),
        "timed_resets": 0,
        "timed_terminated": 0,
        "timed_truncated": 0,
        "reward_sum": 0.0,
    }

    was_gc_enabled = gc.isenabled()
    try:
        obs, _ = env.reset(seed=args.seed)

        recorder.enabled = False
        for _ in range(args.warmup_steps):
            action, _ = model.predict(obs, deterministic=args.deterministic_predict)
            obs, _, terminated, truncated, _ = env.step(action)
            if terminated or truncated:
                obs, _ = env.reset()

        recorder.clear()
        recorder.enabled = True
        if args.disable_gc:
            gc.disable()

        rollout_tic = time.perf_counter_ns()
        for _ in range(args.rollout_steps):
            action = recorder.timed_call(
                "policy_predict",
                lambda: model.predict(obs, deterministic=args.deterministic_predict)[0],
            )
            tic = time.perf_counter_ns()
            obs, reward, terminated, truncated, _ = env.step(action)
            recorder.record("rollout_env_step_total", time.perf_counter_ns() - tic)
            metadata["reward_sum"] += float(reward)

            if terminated or truncated:
                if terminated:
                    metadata["timed_terminated"] += 1
                if truncated:
                    metadata["timed_truncated"] += 1
                obs, _ = recorder.timed_call("rollout_reset_total", env.reset)
                metadata["timed_resets"] += 1

        recorder.record("rollout_profile_total", time.perf_counter_ns() - rollout_tic)
    finally:
        if was_gc_enabled:
            gc.enable()
        instrumentation.restore()
        close_env_safely(env)

    return recorder.summarize(), metadata


def run_sb3_learn(
    sb3: Any,
    args: argparse.Namespace,
) -> Tuple[List[Dict[str, float]], Dict[str, Any], Optional[str], Optional[Any]]:
    recorder = TimingRecorder()
    env, instrumentations, vec_kind, has_env_timing = make_training_env(args, recorder)

    metadata: Dict[str, Any] = {
        "total_timesteps": int(args.learn_timesteps),
        "warmup_timesteps": int(args.learn_warmup_timesteps),
        "n_envs": int(args.n_envs),
        "vec_env": vec_kind,
        "env_timing_available": has_env_timing,
        "estimated_effective_timesteps": effective_sb3_timesteps(args),
    }
    cprofile_text = None
    was_gc_enabled = gc.isenabled()
    model = None
    try:
        model = make_ppo_model(sb3, env, args, recorder=recorder)

        if args.learn_warmup_timesteps > 0:
            recorder.enabled = False
            model.learn(total_timesteps=args.learn_warmup_timesteps, reset_num_timesteps=True, progress_bar=False)
            recorder.clear()
            recorder.enabled = True

        if args.disable_gc:
            gc.disable()

        progress_callback = make_progress_callback(args)

        def learn_call() -> None:
            recorder.timed_call(
                "sb3_learn_total",
                model.learn,
                total_timesteps=args.learn_timesteps,
                reset_num_timesteps=True,
                progress_bar=False,
                callback=progress_callback,
            )

        if args.cprofile:
            profiler = cProfile.Profile()
            profiler.enable()
            learn_call()
            profiler.disable()
            stream = io.StringIO()
            stats = pstats.Stats(profiler, stream=stream)
            stats.strip_dirs().sort_stats("cumtime").print_stats(args.cprofile_top)
            cprofile_text = stream.getvalue()
        else:
            learn_call()
        metadata["actual_timesteps"] = int(getattr(model, "num_timesteps", 0))
    finally:
        if was_gc_enabled:
            gc.enable()
        restore_instrumentations(instrumentations)
        close_env_safely(env)

    return recorder.summarize(), metadata, cprofile_text, model


def add_share(rows: Sequence[Dict[str, float]], denominator_bucket: str) -> List[Dict[str, float]]:
    denominator = 0.0
    for row in rows:
        if row["bucket"] == denominator_bucket:
            denominator = float(row["total_ns"])
            break
    copied = []
    for row in rows:
        item = dict(row)
        item["share_pct"] = (float(row["total_ns"]) / denominator * 100.0) if denominator > 0.0 else float("nan")
        copied.append(item)
    return copied


def derived_mean_rows(rows: Sequence[Dict[str, float]]) -> List[Dict[str, float]]:
    by_bucket = {row["bucket"]: row for row in rows}

    def mean_us(bucket: str) -> float:
        row = by_bucket.get(bucket)
        return 0.0 if row is None else float(row["mean_us"])

    derived = []
    base_step = mean_us("base_env_step_total")
    if base_step > 0.0:
        derived.append({
            "name": "base_env_step_minus_bicycle_and_observation",
            "mean_us": base_step - mean_us("bicycle_integration") - mean_us("observation_total"),
        })
    observation = mean_us("observation_total")
    if observation > 0.0:
        derived.append({
            "name": "observation_minus_road_and_cones",
            "mean_us": observation - mean_us("road_info_total") - mean_us("cone_info_total"),
        })
    reward = mean_us("reward_wrapper_step_total")
    rescale = mean_us("rescale_action_step_total")
    if reward > 0.0 and rescale > 0.0:
        derived.append({
            "name": "reward_wrapper_increment_over_inner_step",
            "mean_us": reward - rescale,
        })
    if rescale > 0.0 and base_step > 0.0:
        derived.append({
            "name": "rescale_action_increment_over_base_env_step",
            "mean_us": rescale - base_step,
        })
    collect = mean_us("sb3_collect_rollouts_total")
    train = mean_us("sb3_train_total")
    learn = mean_us("sb3_learn_total")
    if learn > 0.0:
        derived.append({
            "name": "sb3_learn_minus_collect_and_train",
            "mean_us": learn - collect - train,
        })
    return derived


def format_float(value: float, digits: int = 2) -> str:
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return str(value)
    return f"{value:.{digits}f}"


def markdown_table(rows: Sequence[Dict[str, Any]], columns: Sequence[Tuple[str, str]], digits: int = 2) -> str:
    lines = []
    lines.append("| " + " | ".join(header for _, header in columns) + " |")
    lines.append("| " + " | ".join("---" for _ in columns) + " |")
    for row in rows:
        values = []
        for key, _ in columns:
            value = row.get(key, "")
            if isinstance(value, float):
                values.append(format_float(value, digits))
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def bucket_row(rows: Sequence[Dict[str, float]], bucket: str) -> Optional[Dict[str, float]]:
    for row in rows:
        if row["bucket"] == bucket:
            return row
    return None


def bucket_total_ms(rows: Sequence[Dict[str, float]], bucket: str) -> float:
    row = bucket_row(rows, bucket)
    return float("nan") if row is None else float(row["total_ms"])


def bucket_mean_us(rows: Sequence[Dict[str, float]], bucket: str) -> float:
    row = bucket_row(rows, bucket)
    return float("nan") if row is None else float(row["mean_us"])


def pct(part_ms: float, total_ms: float) -> float:
    if not np.isfinite(part_ms) or not np.isfinite(total_ms) or total_ms <= 0.0:
        return float("nan")
    return part_ms / total_ms * 100.0


def sanitize_markdown_cell(value: Any) -> Any:
    if value is None:
        return "unknown"
    if isinstance(value, str):
        return value.replace("|", "/").replace("\n", " ")
    return value


def _exception_error_text(exc: BaseException) -> str:
    """Return a stable error string even when an exception cannot render."""

    try:
        detail = str(exc)
    except Exception:
        detail = type(exc).__name__
    return type(exc).__name__ + ": " + detail


def summarize_learn_case(
    scenario: str,
    case_name: str,
    case_args: argparse.Namespace,
    timing_rows: Sequence[Dict[str, float]],
    metadata: Dict[str, Any],
    elapsed_s: float,
) -> Dict[str, Any]:
    learn_ms = bucket_total_ms(timing_rows, "sb3_learn_total")
    collect_ms = bucket_total_ms(timing_rows, "sb3_collect_rollouts_total")
    train_ms = bucket_total_ms(timing_rows, "sb3_train_total")
    actual_timesteps = effective_sb3_timesteps(case_args, metadata)
    learn_s = learn_ms / 1000.0 if np.isfinite(learn_ms) else float("nan")
    steps_per_s = actual_timesteps / learn_s if learn_s > 0.0 else float("nan")

    return {
        "scenario": scenario,
        "case": case_name,
        "status": "ok",
        "profile_scope": "specialist_diagnostic",
        "canonical_bundle_case": False,
        "observation_format": case_args.observation_format,
        "n_envs": int(case_args.n_envs),
        "vec_env": metadata.get("vec_env", effective_vec_env_kind(case_args)),
        "n_steps": int(case_args.n_steps),
        "n_epochs": int(case_args.n_epochs),
        "batch_size": int(case_args.batch_size),
        "requested_timesteps": int(case_args.learn_timesteps),
        "actual_timesteps": int(actual_timesteps),
        "learn_s": learn_s,
        "steps_per_s": steps_per_s,
        "collect_pct": pct(collect_ms, learn_ms),
        "train_pct": pct(train_ms, learn_ms),
        "collect_s": collect_ms / 1000.0 if np.isfinite(collect_ms) else float("nan"),
        "train_s": train_ms / 1000.0 if np.isfinite(train_ms) else float("nan"),
        "base_env_step_mean_us": bucket_mean_us(timing_rows, "base_env_step_total"),
        "observation_mean_us": bucket_mean_us(timing_rows, "observation_total"),
        "road_info_mean_us": bucket_mean_us(timing_rows, "road_info_total"),
        "env_timing_available": bool(metadata.get("env_timing_available", False)),
        "script_case_runtime_s": float(elapsed_s),
        "error": "",
        "_args": case_args,
        "_timing_rows": list(timing_rows),
        "_metadata": dict(metadata),
    }


def error_learn_case(
    scenario: str,
    case_name: str,
    case_args: argparse.Namespace,
    exc: BaseException,
    elapsed_s: float,
) -> Dict[str, Any]:
    error_text = sanitize_diagnostic_message(_exception_error_text(exc))
    return {
        "scenario": scenario,
        "case": case_name,
        "status": "error",
        "profile_scope": "specialist_diagnostic",
        "canonical_bundle_case": False,
        "observation_format": getattr(case_args, "observation_format", ""),
        "n_envs": int(getattr(case_args, "n_envs", 0)),
        "vec_env": effective_vec_env_kind(case_args),
        "n_steps": int(getattr(case_args, "n_steps", 0)),
        "n_epochs": int(getattr(case_args, "n_epochs", 0)),
        "batch_size": int(getattr(case_args, "batch_size", 0)),
        "requested_timesteps": int(getattr(case_args, "learn_timesteps", 0)),
        "actual_timesteps": 0,
        "learn_s": float("nan"),
        "steps_per_s": float("nan"),
        "collect_pct": float("nan"),
        "train_pct": float("nan"),
        "collect_s": float("nan"),
        "train_s": float("nan"),
        "base_env_step_mean_us": float("nan"),
        "observation_mean_us": float("nan"),
        "road_info_mean_us": float("nan"),
        "env_timing_available": False,
        "script_case_runtime_s": float(elapsed_s),
        "error": sanitize_markdown_cell(error_text[:500]),
        "_args": case_args,
    }


def run_learn_case(
    sb3: Any,
    scenario: str,
    case_name: str,
    case_args: argparse.Namespace,
) -> Dict[str, Any]:
    tic = time.perf_counter()
    try:
        validate_args(case_args)
        timing_rows, metadata, _, model = run_sb3_learn(sb3, case_args)
        row = summarize_learn_case(
            scenario,
            case_name,
            case_args,
            timing_rows,
            metadata,
            time.perf_counter() - tic,
        )
        row["_model"] = model
        return row
    except Exception as exc:
        return error_learn_case(
            scenario,
            case_name,
            case_args,
            exc,
            time.perf_counter() - tic,
        )


def scalar_ground_truth(ground_truth: Dict[str, Any], key: str) -> float:
    value = ground_truth.get(key, float("nan"))
    try:
        arr = np.asarray(value, dtype=np.float64).reshape(-1)
    except Exception:
        return float("nan")
    if arr.size == 0:
        return float("nan")
    return float(arr[0])


def evaluate_model(model: Any, args: argparse.Namespace, evaluation_steps: int) -> Dict[str, Any]:
    eval_stack = make_env_stack(args)
    env = eval_stack["env"]
    base_env = eval_stack["base_env"]

    total_reward = 0.0
    terminated = False
    truncated = False
    lateral_errors = []
    speeds = []
    steps = 0

    try:
        obs, _ = env.reset(seed=int(args.seed) + 100_000)
        initial_gt = base_env.get_current_ground_truth()
        initial_progress = scalar_ground_truth(
            initial_gt, "reference_line_progress_m"
        )
        final_progress = initial_progress

        for _ in range(evaluation_steps):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += float(reward)
            steps += 1

            gt = base_env.get_current_ground_truth()
            final_progress = scalar_ground_truth(
                gt, "reference_line_progress_m"
            )
            lateral_errors.append(
                abs(
                    scalar_ground_truth(
                        gt, "lateral_error_from_target_line_m"
                    )
                )
            )
            speeds.append(
                scalar_ground_truth(
                    gt, "body_longitudinal_velocity_mps"
                )
            )

            if terminated or truncated:
                break
    finally:
        close_env_safely(env)

    progress_delta = final_progress - initial_progress
    return {
        "eval_steps": int(steps),
        "eval_reward_sum": float(total_reward),
        "eval_progress_m": float(progress_delta),
        "eval_mean_abs_lateral_error_m": float(np.nanmean(lateral_errors)) if lateral_errors else float("nan"),
        "eval_mean_vx_mps": float(np.nanmean(speeds)) if speeds else float("nan"),
        "eval_terminated": bool(terminated),
        "eval_truncated": bool(truncated),
    }


def run_baseline_matrix(sb3: Any, args: argparse.Namespace) -> List[Dict[str, Any]]:
    rows = []
    for observation_format in ("dict", "flat"):
        for n_epochs in (1, 2, 4):
            for batch_size in (64, 128, 256):
                case_name = f"{observation_format}-e{n_epochs}-b{batch_size}"
                case_args = clone_args(
                    args,
                    mode="sb3-learn",
                    observation_format=observation_format,
                    n_envs=1,
                    vec_env="auto",
                    n_epochs=n_epochs,
                    batch_size=batch_size,
                    cprofile=False,
                    progress_label=f"baseline {case_name}",
                )
                rows.append(run_learn_case(sb3, "baseline", case_name, case_args))
                print(f"Completed baseline case {case_name}: {rows[-1]['status']}")
    return rows


def fastest_successful_row(rows: Sequence[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    candidates = [
        row for row in rows
        if row.get("status") == "ok" and np.isfinite(float(row.get("learn_s", float("nan"))))
    ]
    if not candidates:
        return None
    return min(candidates, key=lambda row: float(row["learn_s"]))


def run_vectorization_matrix(
    sb3: Any,
    args: argparse.Namespace,
    baseline_rows: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Run the shared PPO DummyVecEnv cases as standalone diagnostics."""

    del sb3, baseline_rows
    from dreamgym.profiling.autonomous_driving import production_rl, rl_worker

    rows = []

    snapshot_root = (
        Path(__file__).resolve().parents[3]
        / ".profiling-temp"
        / ("rl-specialist-" + uuid.uuid4().hex)
    )
    snapshot_root.mkdir(parents=True)
    try:
        writer = _SpecialistSnapshotWriter(snapshot_root)
        for n_envs in (1, 2, 4, 8):
            request = production_rl.build_ppo_vectorization_case(
                n_envs,
                rl_training_steps=int(args.learn_timesteps),
            )
            resolved = production_rl.resolve_rl_profile_case(request)
            try:
                worker_result = rl_worker.run_spawned_rl_worker(
                    request,
                    writer,
                )
                row = production_vectorization_row(
                    resolved,
                    worker_result,
                )
            except Exception as error:
                row = production_vectorization_error_row(
                    resolved,
                    error,
                )
            rows.append(row)
            print(
                "Completed shared production vectorization case "
                + row["case"]
                + ": "
                + row["status"]
            )
    finally:
        shutil.rmtree(snapshot_root)

    return rows


class _SpecialistSnapshotWriter:
    """Persist worker barriers ephemerally without creating a result bundle."""

    def __init__(self, root: Path):
        self.root = Path(root)

    @staticmethod
    def _snapshot_payload(snapshot: Any) -> tuple[str, bytes, str]:
        from dreamgym.training.autonomous_driving.config_validation import (
            canonical_json_text,
            canonical_snapshot_digest,
            thaw_json,
        )

        detached = thaw_json(snapshot)
        payload = canonical_json_text(detached).encode("utf-8")
        return (
            canonical_snapshot_digest(detached),
            payload,
            hashlib.sha256(payload).hexdigest(),
        )

    def _persist(self, relative_path: str, payload: bytes) -> None:
        destination = self.root / relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(payload)

    def persist_requested_config(self, snapshot: Any) -> Dict[str, str]:
        digest, payload, checksum = self._snapshot_payload(snapshot)
        relative_path = "requested/" + digest + ".json"
        self._persist(relative_path, payload)
        return {
            "requested_config_path": relative_path,
            "requested_config_digest": digest,
            "requested_file_sha256": checksum,
        }

    def persist_resolved_config(
        self,
        requested_reference: Dict[str, str],
        snapshot: Any,
    ) -> Dict[str, str]:
        digest, payload, checksum = self._snapshot_payload(snapshot)
        relative_path = "resolved/" + digest + ".json"
        self._persist(relative_path, payload)
        return {
            **dict(requested_reference),
            "resolved_config_path": relative_path,
            "resolved_config_digest": digest,
            "resolved_file_sha256": checksum,
        }


def _production_vectorization_args(resolved: Any) -> argparse.Namespace:
    algorithm_config = resolved.build.algorithm.to_dict()
    constructor = algorithm_config["constructor_kwargs"]
    native_n_steps = int(
        algorithm_config["native_n_steps_per_environment"]
    )
    return clone_args(
        argparse.Namespace(**RLProfileConfig().__dict__),
        mode="sb3-learn",
        observation_format=resolved.build.requested_dict["env"][
            "observation_format"
        ],
        tire_force_condition=resolved.build.requested_dict["env"][
            "tire_force_condition"
        ],
        n_envs=int(resolved.build.effective_n_envs),
        vec_env="dummy",
        n_steps=native_n_steps,
        batch_size=int(constructor["batch_size"]),
        n_epochs=int(constructor["n_epochs"]),
        learn_timesteps=int(
            resolved.build.requested_total_environment_transitions
        ),
        cprofile=False,
    )


def production_vectorization_error_row(
    resolved: Any,
    error: Exception,
) -> Dict[str, Any]:
    case_args = _production_vectorization_args(resolved)
    row = error_learn_case(
        "vectorization",
        "dummy-n" + str(case_args.n_envs),
        case_args,
        error,
        0.0,
    )
    row.update(
        {
            "worker_status": "error",
            "shared_production_semantics": True,
            "canonical_bundle_case": False,
            "algorithm": "PPO",
            "requested_total_environment_transitions": int(
                resolved.build.requested_total_environment_transitions
            ),
            "actual_transitions": None,
            "actual_timesteps": None,
            "transition_overshoot": None,
            "canonical_window_requirement_met": False,
            "complete_window_count": 0,
        }
    )
    return row


def production_vectorization_row(
    resolved: Any,
    worker_result: Any,
) -> Dict[str, Any]:
    """Adapt one spawned production result to the mature matrix report."""

    metrics = worker_result.metrics
    training = metrics["training"]
    vectorization = metrics["vectorization"]
    algorithm = metrics["algorithm"]
    algorithm_config = resolved.build.algorithm.to_dict()
    constructor = algorithm_config["constructor_kwargs"]
    native_n_steps = int(
        algorithm_config["native_n_steps_per_environment"]
    )
    requested = int(metrics["requested_transitions"])
    actual = int(metrics["actual_transitions"])
    learn_ns = int(training["model_learn_ns"])
    learn_s = learn_ns / 1_000_000_000.0
    steps_per_s = training["total_transitions_per_second"]
    if steps_per_s is None:
        steps_per_s = (
            actual / learn_s if learn_s > 0.0 else float("nan")
        )
    case_args = _production_vectorization_args(resolved)
    window_requirement_met = bool(
        training["canonical_window_requirement_met"]
    )
    completed = (
        worker_result.status == "completed"
        and window_requirement_met
    )
    return {
        "scenario": "vectorization",
        "case": "dummy-n" + str(vectorization["effective_n_envs"]),
        "status": "ok" if completed else worker_result.status,
        "worker_status": worker_result.status,
        "profile_scope": "specialist_diagnostic",
        "shared_production_semantics": True,
        "canonical_bundle_case": False,
        "algorithm": algorithm["name"],
        "observation_format": case_args.observation_format,
        "n_envs": int(vectorization["effective_n_envs"]),
        "vec_env": vectorization["kind"],
        "n_steps": native_n_steps,
        "n_epochs": int(constructor["n_epochs"]),
        "batch_size": int(constructor["batch_size"]),
        "requested_total_environment_transitions": requested,
        "actual_transitions": actual,
        "transition_overshoot": int(metrics["transition_overshoot"]),
        # Retain mature report fields as compatibility aliases. The values
        # come from the production request and observed model respectively.
        "requested_timesteps": requested,
        "actual_timesteps": actual,
        "learn_s": learn_s,
        "steps_per_s": float(steps_per_s),
        "collect_pct": float("nan"),
        "train_pct": float("nan"),
        "collect_s": float("nan"),
        "train_s": float("nan"),
        "base_env_step_mean_us": float("nan"),
        "observation_mean_us": float("nan"),
        "road_info_mean_us": float("nan"),
        "env_timing_available": False,
        "script_case_runtime_s": learn_s,
        "canonical_window_requirement_met": window_requirement_met,
        "complete_window_count": int(training["complete_window_count"]),
        "error": (
            ""
            if completed
            else (
                "production worker status: "
                + str(worker_result.status)
                + "; canonical timing-window requirement was not met"
            )
        ),
        "_args": case_args,
        "_worker_metrics": metrics,
    }


def select_learning_check_candidates(
    rows: Sequence[Dict[str, Any]],
    count: int,
) -> List[Dict[str, Any]]:
    candidates = [
        row for row in rows
        if row.get("status") == "ok" and np.isfinite(float(row.get("learn_s", float("nan"))))
    ]
    candidates.sort(key=lambda row: float(row["learn_s"]))

    selected = []
    seen = set()
    for row in candidates:
        key = (
            row.get("observation_format"),
            row.get("n_envs"),
            row.get("vec_env"),
            row.get("n_epochs"),
            row.get("batch_size"),
        )
        if key in seen:
            continue
        selected.append(row)
        seen.add(key)
        if len(selected) >= count:
            break
    return selected


def run_learning_checks(
    sb3: Any,
    args: argparse.Namespace,
    candidate_rows: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows = []
    for idx, candidate in enumerate(
        select_learning_check_candidates(candidate_rows, args.matrix_learning_checks),
        start=1,
    ):
        candidate_args = candidate["_args"]
        case_name = f"check{idx}-{candidate['case']}"
        case_args = clone_args(
            candidate_args,
            mode="sb3-learn",
            learn_timesteps=args.learning_check_timesteps,
            cprofile=False,
            progress_label=f"learning_check {case_name}",
        )
        row = run_learn_case(sb3, "learning_check", case_name, case_args)
        model = row.pop("_model", None)
        if row.get("status") == "ok" and model is not None:
            row.update(evaluate_model(model, case_args, args.evaluation_steps))
        rows.append(row)
        print(f"Completed learning check {case_name}: {rows[-1]['status']}")
    return rows


def run_matrix(sb3: Any, args: argparse.Namespace) -> Dict[str, List[Dict[str, Any]]]:
    baseline_rows: List[Dict[str, Any]] = []
    vector_rows: List[Dict[str, Any]] = []
    learning_rows: List[Dict[str, Any]] = []

    if args.matrix in ("baseline", "all"):
        baseline_rows = run_baseline_matrix(sb3, args)

    if args.matrix in ("vectorization", "all"):
        print(
            "Compatibility note: vectorization now uses shared production "
            "semantics for PPO DummyVecEnv 1/2/4/8. This standalone report "
            "remains a specialist diagnostic, not a canonical bundle."
        )
        vector_rows = run_vectorization_matrix(sb3, args, baseline_rows)

    if args.matrix == "all":
        learning_rows = run_learning_checks(sb3, args, baseline_rows)

    return {
        "baseline": baseline_rows,
        "vectorization": vector_rows,
        "learning_check": learning_rows,
    }


def public_rows(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cleaned = []
    for row in rows:
        cleaned.append({
            key: sanitize_markdown_cell(value)
            for key, value in row.items()
            if not key.startswith("_")
        })
    return cleaned


def successful_timing_rows(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    successful = [
        row for row in rows
        if row.get("status") == "ok" and np.isfinite(float(row.get("steps_per_s", float("nan"))))
    ]
    successful.sort(key=lambda row: float(row["steps_per_s"]), reverse=True)
    return successful


def print_vectorization_summary(matrix_results: Dict[str, List[Dict[str, Any]]]) -> None:
    rows = matrix_results.get("vectorization", [])
    if not rows:
        return

    ranked_rows = successful_timing_rows(rows)
    error_rows = [row for row in rows if row.get("status") != "ok"]

    print("")
    print("Vectorization timing summary, ranked by training throughput:")
    if ranked_rows:
        summary_rows = []
        for rank, row in enumerate(ranked_rows, start=1):
            summary_rows.append({
                "rank": rank,
                "case": row["case"],
                "vec": row["vec_env"],
                "envs": row["n_envs"],
                "steps": row["actual_timesteps"],
                "learn_s": row["learn_s"],
                "steps_per_s": row["steps_per_s"],
                "collect_pct": row["collect_pct"],
                "train_pct": row["train_pct"],
            })
        print(markdown_table(
            summary_rows,
            (
                ("rank", "rank"),
                ("case", "case"),
                ("vec", "vec"),
                ("envs", "envs"),
                ("steps", "steps"),
                ("learn_s", "learn s"),
                ("steps_per_s", "steps/s"),
                ("collect_pct", "collect %"),
                ("train_pct", "train %"),
            ),
        ))
    else:
        print("No successful vectorization timing rows were recorded.")

    if error_rows:
        print("")
        print("Failed vectorization cases:")
        print(markdown_table(
            public_rows(error_rows),
            (("case", "case"), ("status", "status"), ("vec_env", "vec"), ("n_envs", "envs"), ("error", "error")),
        ))

    if ranked_rows:
        fastest = ranked_rows[0]
        print("")
        print(
            "Recommended fastest training setting on this machine: "
            f"--vec-env {fastest['vec_env']} --n-envs {fastest['n_envs']} "
            f"({fastest['case']}, {format_float(float(fastest['steps_per_s']))} steps/s)."
        )


def write_matrix_report(
    output_path: Path,
    *,
    args: argparse.Namespace,
    sb3_version: str,
    torch_version: str,
    matrix_results: Dict[str, List[Dict[str, Any]]],
    elapsed_s: float,
) -> None:
    now = _datetime.datetime.now().astimezone()
    text = []
    text.append("# RL Timing Matrix")
    text.append("")
    text.append("This file is generated by `python scripts/profile_rl.py --matrix ...`.")
    text.append("")
    text.append(
        "This standalone command is a specialist diagnostic, not a canonical "
        "bundle. Its vectorization section uses the shared production PPO "
        "DummyVecEnv semantics."
    )
    text.append("")
    text.append("## Environment")
    text.append("")
    text.append(f"- Generated: {now.isoformat(timespec='seconds')}")
    text.append(f"- Python: {platform.python_version()}")
    text.append(f"- NumPy: {np.__version__}")
    text.append(f"- Gymnasium: {getattr(gym, '__version__', 'unknown')}")
    text.append(f"- Stable-Baselines3: {sb3_version}")
    text.append(f"- Torch: {torch_version}")
    text.append(f"- Platform: {platform.platform()}")
    text.append(f"- Total script runtime: {elapsed_s:.2f} s")
    text.append("")
    text.append("## Matrix Configuration")
    text.append("")
    config_rows = [
        ("matrix", args.matrix),
        ("learn_timesteps", args.learn_timesteps),
        ("learning_check_timesteps", args.learning_check_timesteps),
        ("evaluation_steps", args.evaluation_steps),
        ("n_steps", args.n_steps),
        ("tracking_mode", args.tracking_mode),
        ("num_elements", args.num_elements),
        ("lookahead_points", args.lookahead_points),
        ("vehicle_profile", args.vehicle_profile),
        ("integration_method", args.integration_method),
        ("tire_force_condition", args.tire_force_condition),
        ("reward_wrapper", args.reward_wrapper),
        ("rescale_action", args.rescale_action),
        ("skip_subproc", args.skip_subproc),
    ]
    text.append(markdown_table(
        [{"key": key, "value": value} for key, value in config_rows],
        (("key", "setting"), ("value", "value")),
    ))

    timing_columns = (
        ("case", "case"),
        ("status", "status"),
        ("observation_format", "observation"),
        ("n_envs", "envs"),
        ("vec_env", "vec"),
        ("n_epochs", "epochs"),
        ("batch_size", "batch"),
        ("actual_timesteps", "steps"),
        ("learn_s", "learn s"),
        ("steps_per_s", "steps/s"),
        ("collect_pct", "collect %"),
        ("train_pct", "train %"),
        ("base_env_step_mean_us", "env step us"),
        ("observation_mean_us", "observation us"),
        ("road_info_mean_us", "road us"),
        ("error", "error"),
    )

    for key, title in (
        ("baseline", "Baseline Matrix"),
        ("vectorization", "Vectorization Matrix"),
    ):
        rows = public_rows(matrix_results.get(key, []))
        if not rows:
            continue
        text.append("")
        text.append(f"## {title}")
        text.append("")
        text.append(markdown_table(rows, timing_columns))

    learning_rows = public_rows(matrix_results.get("learning_check", []))
    if learning_rows:
        learning_columns = timing_columns[:-1] + (
            ("eval_steps", "eval steps"),
            ("eval_reward_sum", "eval reward"),
            ("eval_progress_m", "eval progress m"),
            ("eval_mean_abs_lateral_error_m", "eval abs lat err m"),
            ("eval_mean_vx_mps", "eval vx m/s"),
            ("eval_terminated", "terminated"),
            ("eval_truncated", "truncated"),
            ("error", "error"),
        )
        text.append("")
        text.append("## Learning Checks")
        text.append("")
        text.append(markdown_table(learning_rows, learning_columns))

    fastest_rows = public_rows([
        row for row in matrix_results.get("baseline", []) + matrix_results.get("vectorization", [])
        if row.get("status") == "ok"
    ])
    if fastest_rows:
        fastest_rows.sort(key=lambda row: float(row["learn_s"]))
        text.append("")
        text.append("## Fastest Screening Cases")
        text.append("")
        text.append(markdown_table(fastest_rows[:5], timing_columns))

    text.append("")
    text.append("## Notes")
    text.append("")
    text.append(
        "- `learn_timesteps` maps to requested total environment transitions; "
        "`actual_timesteps` records the worker-observed transitions separately "
        "because SB3 PPO collects whole rollout buffers."
    )
    text.append(
        "- Canonical-overlap vectorization rows use production DummyVecEnv "
        "1/2/4/8. Legacy baseline and learning-check rows remain specialist "
        "diagnostics."
    )
    text.append(
        "- Learning checks are short sanity checks, not policy-quality claims."
    )
    text.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(text), encoding="utf-8")


def write_report(
    output_path: Path,
    *,
    args: argparse.Namespace,
    sb3_version: str,
    torch_version: str,
    rollout_rows: Optional[Sequence[Dict[str, float]]],
    rollout_metadata: Optional[Dict[str, Any]],
    learn_rows: Optional[Sequence[Dict[str, float]]],
    learn_metadata: Optional[Dict[str, Any]],
    cprofile_text: Optional[str],
    elapsed_s: float,
) -> None:
    now = _datetime.datetime.now().astimezone()
    text = []
    text.append("# RL Timing Profile")
    text.append("")
    text.append("This file is generated by `python scripts/profile_rl.py`.")
    text.append("")
    text.append(
        "This standalone command contains specialist diagnostics, not a "
        "canonical bundle. Manual rollout and direct legacy PPO instrumentation "
        "remain intentionally local to this report."
    )
    text.append("")
    text.append("## Environment")
    text.append("")
    text.append(f"- Generated: {now.isoformat(timespec='seconds')}")
    text.append(f"- Python: {platform.python_version()}")
    text.append(f"- NumPy: {np.__version__}")
    text.append(f"- Gymnasium: {getattr(gym, '__version__', 'unknown')}")
    text.append(f"- Stable-Baselines3: {sb3_version}")
    text.append(f"- Torch: {torch_version}")
    text.append(f"- Platform: {platform.platform()}")
    text.append(f"- Total script runtime: {elapsed_s:.2f} s")
    text.append("")
    text.append("## Configuration")
    text.append("")
    config_rows = [
        ("mode", args.mode),
        ("observation_format", args.observation_format),
        ("tracking_mode", args.tracking_mode),
        ("num_elements", args.num_elements),
        ("lookahead_points", args.lookahead_points),
        ("include_cones", args.include_cones),
        ("include_next_speed_changes", args.include_next_speed_changes),
        ("vehicle_profile", args.vehicle_profile),
        ("integration_method", args.integration_method),
        ("integration_ts", args.integration_ts),
        ("integration_substeps", args.integration_substeps),
        ("tire_force_condition", args.tire_force_condition),
        ("rescale_action", args.rescale_action),
        ("reward_wrapper", args.reward_wrapper),
        ("domain_randomization", args.domain_randomization),
        ("max_episode_steps", args.max_episode_steps),
        ("n_steps", args.n_steps),
        ("batch_size", args.batch_size),
        ("n_epochs", args.n_epochs),
        ("n_envs", args.n_envs),
        ("vec_env", effective_vec_env_kind(args)),
        ("device", args.device),
    ]
    text.append(markdown_table(
        [{"key": key, "value": value} for key, value in config_rows],
        (("key", "setting"), ("value", "value")),
    ))

    timing_columns = (
        ("bucket", "bucket"),
        ("calls", "calls"),
        ("total_ms", "total ms"),
        ("share_pct", "share %"),
        ("mean_us", "mean us"),
        ("median_us", "median us"),
        ("p95_us", "p95 us"),
        ("p99_us", "p99 us"),
    )

    if rollout_rows is not None:
        rows_with_share = add_share(rollout_rows, "rollout_profile_total")
        text.append("")
        text.append("## Manual SB3-Policy Rollout")
        text.append("")
        if rollout_metadata is not None:
            text.append(markdown_table(
                [{"key": key, "value": value} for key, value in rollout_metadata.items()],
                (("key", "metric"), ("value", "value")),
            ))
            text.append("")
        text.append(
            "Shares are inclusive percentages of `rollout_profile_total`; nested "
            "buckets are expected to sum to more than 100%."
        )
        text.append("")
        text.append(markdown_table(rows_with_share, timing_columns))
        derived = derived_mean_rows(rollout_rows)
        if derived:
            text.append("")
            text.append("### Derived Mean Estimates")
            text.append("")
            text.append(markdown_table(derived, (("name", "estimate"), ("mean_us", "mean us"))))

    if learn_rows is not None:
        rows_with_share = add_share(learn_rows, "sb3_learn_total")
        text.append("")
        text.append("## SB3 PPO Learn")
        text.append("")
        if learn_metadata is not None:
            text.append(markdown_table(
                [{"key": key, "value": value} for key, value in learn_metadata.items()],
                (("key", "metric"), ("value", "value")),
            ))
            text.append("")
        text.append(
            "Shares are inclusive percentages of `sb3_learn_total`; env buckets "
            "are nested inside SB3 rollout collection."
        )
        text.append("")
        text.append(markdown_table(rows_with_share, timing_columns))
        derived = derived_mean_rows(learn_rows)
        if derived:
            text.append("")
            text.append("### Derived Mean Estimates")
            text.append("")
            text.append(markdown_table(derived, (("name", "estimate"), ("mean_us", "mean us"))))

    if cprofile_text:
        text.append("")
        text.append("## cProfile Top Cumulative Time")
        text.append("")
        text.append("```text")
        text.append(cprofile_text.rstrip())
        text.append("```")

    text.append("")
    text.append("## Notes")
    text.append("")
    text.append(
        "- The manual rollout mode uses SB3 policy inference but does not run PPO "
        "backpropagation; use the SB3 learn section for full training overhead."
    )
    text.append(
        "- Instrumentation buckets are inclusive. Use the derived mean estimates "
        "for rough non-overlapping components, and use the raw inclusive rows "
        "for regression comparisons."
    )
    text.append(
        "- Absolute timings depend on CPU, Python, Torch, BLAS, background load, "
        "and power settings."
    )
    text.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(text), encoding="utf-8")


def non_negative_int(value: str) -> int:
    parsed = int(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("must be non-negative")
    return parsed


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def positive_float(value: str) -> float:
    parsed = float(value)
    if parsed <= 0.0 or not np.isfinite(parsed):
        raise argparse.ArgumentTypeError("must be finite and positive")
    return parsed


@dataclass
class RLProfileConfig:
    mode: str = "both"
    matrix: str = "none"
    output: Path | None = None
    rollout_steps: int = 1000
    warmup_steps: int = 100
    learn_timesteps: int = 2048
    learn_warmup_timesteps: int = 0
    learning_check_timesteps: int = 4096
    evaluation_steps: int = 500
    matrix_learning_checks: int = 3
    num_elements: int = 50
    tracking_mode: str = "target_lane"
    lookahead_points: int = 10
    include_cones: bool = False
    include_next_speed_changes: bool = False
    output_destination: str = "observation"
    observation_format: str = "dict"
    vehicle_profile: str = "training"
    integration_method: str = "rk4"
    integration_ts: float = 0.05
    integration_substeps: int = 1
    tire_force_condition: str = "wet"
    rescale_action: bool = False
    reward_wrapper: bool = True
    domain_randomization: bool = False
    domain_seed: int = 0
    max_episode_steps: int | None = None
    enable_lane_keep: bool = False
    enable_cruise_control: bool = False
    n_steps: int = 256
    batch_size: int = 64
    n_epochs: int = 4
    n_envs: int = 1
    vec_env: str = "auto"
    skip_subproc: bool = False
    subproc_start_method: str = "spawn"
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_range: float = 0.2
    ent_coef: float = 0.0
    vf_coef: float = 0.5
    device: str = "cpu"
    seed: int = 0
    deterministic_predict: bool = True
    disable_gc: bool = True
    cprofile: bool = False
    cprofile_top: int = 30
    progress: bool = False
    progress_interval_pct: float = 5.0


def build_rl_vectorization_command(
    *,
    learn_timesteps: int = 100_000,
    output: str | Path | None = None,
) -> list[str]:
    import sys

    command = [
        sys.executable,
        "-m",
        "dreamgym.profiling.autonomous_driving.rl",
        "--matrix",
        "vectorization",
        "--learn-timesteps",
        str(int(learn_timesteps)),
        "--progress",
    ]
    if output is not None:
        command.extend(["--output", str(output)])
    return command


def config_to_namespace(config: RLProfileConfig) -> argparse.Namespace:
    namespace = argparse.Namespace(**config.__dict__)
    namespace._explicit_options = frozenset()
    return namespace


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Profile RL-style rollout and SB3 PPO training timing.",
    )
    parser.add_argument("--mode", choices=("rollout", "sb3-learn", "both"), default="both")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--matrix", choices=("none", "baseline", "vectorization", "all"), default="none")

    parser.add_argument("--rollout-steps", type=positive_int, default=1000)
    parser.add_argument("--warmup-steps", type=non_negative_int, default=100)
    parser.add_argument("--learn-timesteps", type=positive_int, default=2048)
    parser.add_argument("--learn-warmup-timesteps", type=non_negative_int, default=0)
    parser.add_argument("--learning-check-timesteps", type=positive_int, default=4096)
    parser.add_argument("--evaluation-steps", type=positive_int, default=500)
    parser.add_argument("--matrix-learning-checks", type=positive_int, default=3)

    parser.add_argument("--num-elements", type=positive_int, default=50)
    parser.add_argument("--tracking-mode", choices=("reference_line", "target_lane"), default="target_lane")
    parser.add_argument("--lookahead-points", type=non_negative_int, default=10)
    parser.add_argument("--include-cones", action="store_true")
    parser.add_argument("--include-next-speed-changes", action="store_true")
    parser.add_argument(
        "--output-destination",
        choices=("observation", "info"),
        default="observation",
    )
    parser.add_argument("--observation-format", choices=("dict", "flat"), default="dict")

    parser.add_argument("--vehicle-profile", choices=("training", "dynamic"), default="training")
    parser.add_argument("--integration-method", choices=("euler", "midpoint", "heun", "rk4"), default="rk4")
    parser.add_argument("--integration-ts", type=float, default=0.05)
    parser.add_argument("--integration-substeps", type=positive_int, default=1)
    parser.add_argument(
        "--tire-force-condition",
        choices=("dry", "wet", "snow", "ice"),
        default="wet",
    )

    parser.add_argument("--rescale-action", dest="rescale_action", action="store_true")
    parser.add_argument("--no-rescale-action", dest="rescale_action", action="store_false")
    parser.set_defaults(rescale_action=False)
    parser.add_argument("--no-reward-wrapper", dest="reward_wrapper", action="store_false")
    parser.set_defaults(reward_wrapper=True)
    parser.add_argument("--domain-randomization", action="store_true")
    parser.add_argument("--domain-seed", type=int, default=0)
    parser.add_argument("--max-episode-steps", type=positive_int, default=None)
    parser.add_argument("--enable-lane-keep", action="store_true")
    parser.add_argument("--enable-cruise-control", action="store_true")

    parser.add_argument("--n-steps", type=positive_int, default=256)
    parser.add_argument("--batch-size", type=positive_int, default=64)
    parser.add_argument("--n-epochs", type=positive_int, default=4)
    parser.add_argument("--n-envs", type=positive_int, default=1)
    parser.add_argument("--vec-env", choices=("auto", "raw", "dummy", "subproc"), default="auto")
    parser.add_argument("--skip-subproc", action="store_true")
    parser.add_argument("--subproc-start-method", choices=("spawn", "forkserver", "fork"), default="spawn")
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--gae-lambda", type=float, default=0.95)
    parser.add_argument("--clip-range", type=float, default=0.2)
    parser.add_argument("--ent-coef", type=float, default=0.0)
    parser.add_argument("--vf-coef", type=float, default=0.5)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--stochastic-predict", dest="deterministic_predict", action="store_false")
    parser.set_defaults(deterministic_predict=True)

    parser.add_argument("--disable-gc", action="store_true", default=True)
    parser.add_argument("--keep-gc", dest="disable_gc", action="store_false")
    parser.add_argument("--cprofile", action="store_true")
    parser.add_argument("--cprofile-top", type=positive_int, default=30)
    parser.add_argument("--progress", action="store_true")
    parser.add_argument("--progress-interval-pct", type=positive_float, default=5.0)
    source_argv = list(sys.argv[1:] if argv is None else argv)
    namespace = parser.parse_args(source_argv)
    namespace._explicit_options = frozenset(
        token.partition("=")[0]
        for token in source_argv
        if token.startswith("--")
    )
    return namespace


def validate_args(args: argparse.Namespace) -> None:
    if args.matrix in ("vectorization", "all"):
        allowed_matrix_options = {
            "--learn-timesteps",
            "--matrix",
            "--output",
            "--progress",
            "--progress-interval-pct",
        }
        if args.matrix == "all":
            allowed_matrix_options.update(
                {
                    "--clip-range",
                    "--device",
                    "--disable-gc",
                    "--domain-randomization",
                    "--domain-seed",
                    "--enable-cruise-control",
                    "--enable-lane-keep",
                    "--ent-coef",
                    "--evaluation-steps",
                    "--gae-lambda",
                    "--gamma",
                    "--include-cones",
                    "--include-next-speed-changes",
                    "--integration-method",
                    "--integration-substeps",
                    "--integration-ts",
                    "--keep-gc",
                    "--learn-warmup-timesteps",
                    "--learning-check-timesteps",
                    "--learning-rate",
                    "--lookahead-points",
                    "--matrix-learning-checks",
                    "--max-episode-steps",
                    "--n-steps",
                    "--no-rescale-action",
                    "--no-reward-wrapper",
                    "--num-elements",
                    "--output-destination",
                    "--rescale-action",
                    "--tire-force-condition",
                    "--seed",
                    "--tracking-mode",
                    "--vehicle-profile",
                    "--vf-coef",
                }
            )
        conflicting = sorted(
            set(getattr(args, "_explicit_options", ()))
            - allowed_matrix_options
        )
        if conflicting:
            raise ValueError(
                f"--matrix {args.matrix} uses shared production semantics; "
                "these legacy specialist options conflict with that meaning: "
                + ", ".join(conflicting)
                + ". Use --matrix baseline or --matrix none for those options."
            )
    if args.integration_ts <= 0.0 or not np.isfinite(args.integration_ts):
        raise ValueError("--integration-ts must be finite and positive.")
    rollout_buffer_size = int(args.n_steps) * int(args.n_envs)
    if args.batch_size > rollout_buffer_size:
        raise ValueError("--batch-size must be <= --n-steps * --n-envs for PPO.")
    if rollout_buffer_size < 2:
        raise ValueError("--n-steps * --n-envs must be at least 2 for PPO.")
    if args.vec_env == "raw" and args.n_envs != 1:
        raise ValueError("--vec-env raw supports only --n-envs 1.")
    if (
        args.matrix in ("vectorization", "all")
        and args.vec_env in ("raw", "subproc")
    ):
        raise ValueError(
            "--matrix vectorization uses shared production semantics with "
            "DummyVecEnv only; --vec-env raw/subproc conflicts with that "
            "meaning. Use --matrix baseline or --matrix none for legacy "
            "specialist diagnostics."
        )
    if args.mode in ("rollout", "both") and args.matrix == "none" and args.n_envs != 1:
        raise ValueError("Manual rollout timing supports only --n-envs 1. Use --mode sb3-learn for vector envs.")
    if args.progress_interval_pct > 100.0:
        raise ValueError("--progress-interval-pct must be <= 100.")
    if args.learning_rate <= 0.0:
        raise ValueError("--learning-rate must be positive.")
    if args.enable_lane_keep and args.enable_cruise_control:
        raise ValueError(
            "Enabling both internal policies makes the env action interface "
            "constant/no-op, which is not a useful SB3 PPO profiling setup. "
            "Enable at most one internal policy for this harness."
        )
    if args.lookahead_points == 0 and args.include_cones:
        # Valid, but this is often the cone-specific hot path; keep as no-op.
        pass


def profile_rl(config: RLProfileConfig) -> Path:
    args = config_to_namespace(config)
    validate_args(args)
    _ensure_rl_runtime_imports()

    if args.output is None and args.matrix != "none":
        output_path = resolve_profile_output_path(None, "rl_timing_matrix.md")
    else:
        output_path = resolve_profile_output_path(args.output, "rl_timing_profile.md")

    sb3, torch = import_sb3_modules()
    start_time = time.perf_counter()

    if args.matrix != "none":
        matrix_results = run_matrix(sb3, args)
        elapsed_s = time.perf_counter() - start_time
        write_matrix_report(
            output_path,
            args=args,
            sb3_version=getattr(sb3, "__version__", "unknown"),
            torch_version=getattr(torch, "__version__", "unknown"),
            matrix_results=matrix_results,
            elapsed_s=elapsed_s,
        )
        print_vectorization_summary(matrix_results)
        return output_path

    rollout_rows = None
    rollout_metadata = None
    learn_rows = None
    learn_metadata = None
    cprofile_text = None

    if args.mode in ("rollout", "both"):
        rollout_rows, rollout_metadata = run_manual_rollout(sb3, args)
    if args.mode in ("sb3-learn", "both"):
        learn_rows, learn_metadata, cprofile_text, _ = run_sb3_learn(sb3, args)

    elapsed_s = time.perf_counter() - start_time
    write_report(
        output_path,
        args=args,
        sb3_version=getattr(sb3, "__version__", "unknown"),
        torch_version=getattr(torch, "__version__", "unknown"),
        rollout_rows=rollout_rows,
        rollout_metadata=rollout_metadata,
        learn_rows=learn_rows,
        learn_metadata=learn_metadata,
        cprofile_text=cprofile_text,
        elapsed_s=elapsed_s,
    )
    return output_path


def profile_rl_main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    validate_args(args)
    output_path = profile_rl(
        RLProfileConfig(
            **{
                key: value
                for key, value in vars(args).items()
                if not key.startswith("_")
            }
        )
    )
    print(f"Wrote {display_output_path(output_path)}")


def main() -> None:
    profile_rl_main()


if __name__ == "__main__":
    main()
