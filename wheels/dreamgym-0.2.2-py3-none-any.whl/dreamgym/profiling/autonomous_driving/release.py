"""Retain historical profiling evidence behind fail-closed v3 release seams.

Track A keeps read-only historical source validation and active v3 identities.
Legacy v2 mutation and canonical v3 activation remain disabled pending their
separately reviewed release tracks.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import copy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
from types import MappingProxyType
from typing import Any

from dreamgym.profiling.autonomous_driving.records import (
    BENCHMARK_MODULE_ORIGINS_V1,
    BENCHMARK_MODULE_ORIGINS_V3,
    canonical_json_bytes,
    validate_benchmark_module_origins,
)


HISTORICAL_WORKLOAD_RELEASE_ID_V1 = "dreamgym-machine-profile-v1"
HISTORICAL_SUBMISSION_RELEASE_ID_V1 = (
    "dreamgym-machine-profile-submission-v1"
)
HISTORICAL_WORKLOAD_RELEASE_ID_V2 = "dreamgym-machine-profile-v2"
HISTORICAL_SUBMISSION_RELEASE_ID_V2 = (
    "dreamgym-machine-profile-submission-v2"
)
WORKLOAD_RELEASE_ID = "dreamgym-machine-profile-v3"
SUBMISSION_RELEASE_ID = "dreamgym-machine-profile-submission-v3"
RESULT_SCHEMA_RELEASE_ID = "dreamgym-profile-results-v1"
TIMING_PROTOCOL_RELEASE_ID = "dreamgym-profile-timing-v1"
BENCHMARK_SOURCE_MANIFEST_SCHEMA_VERSION = "benchmark-sources-v1"

APPROVED_CANDIDATE_SHA256 = (
    "99b1d69f25ad60fed8d2e5cc26ad02eabc1303cfca579b4e644a3758cb071b56"
)
APPROVED_CANDIDATE_AUTHORITY_V1 = MappingProxyType({
    "resource_sha256": APPROVED_CANDIDATE_SHA256,
    "aggregate_resource_digest": (
        "04f9dc9e0b358d93bb19b679efbeb5140df7b321fdf53ed5c510b9f8f0baee3f"
    ),
    "preset_workload_digests": {
        "quick": (
            "983a21d8ed6dc9ccb6292961305d41a285faf773f9ac9fac06b8f850cfd17f22"
        ),
        "medium": (
            "304ad9cc08147cc798eb354e411770d5e01de2ad59572e814e8faad8aae96e04"
        ),
        "long": (
            "0b2e26f20ef87e1cd10dc536574aede52c40ab54cad371750312451851d6ee42"
        ),
    },
    "submission_resource_sha256": (
        "7b74c663427e617395cd3cc0d2ba9c3314a9be38a47c7b78747e0ce1ad6c2246"
    ),
    "submission_workload_digest": (
        "baf4022b9f7653d02d3f10dd1dac46a5329334161fc3a6e1bf2b4d9eac12739e"
    ),
})

# This authority is populated only after the exact transient v2 candidate has
# been rendered and approved.  ``None`` is deliberately non-authorizing: the
# release builder fails closed until every value is replaced by Step 9's
# reviewed literal authority.
APPROVED_RELEASE_CANDIDATE_AUTHORITY_V2 = MappingProxyType({
    "resource_sha256": (
        "c4e4c2163d0fa7d1ae5a534f2dfb6980"
        "adf5a87696c473a1cca11b64d349d2fe"
    ),
    "aggregate_resource_digest": (
        "4f3a3cf5f98f42cea3044bfaa34bcd32"
        "e8d03948d4ab609aa74a1a5923f0dcff"
    ),
    "preset_workload_digests": {
        "quick": (
            "a355df88edcf27d33a2d3dd153b36ab8"
            "2b5139e1ba09360a7420fc22d5979c19"
        ),
        "medium": (
            "3eeb39a393e9d303a9106d2067f55396"
            "500186a5bfbb2f9b748748863e583372"
        ),
        "long": (
            "974932b289fd78f7035dde5d9c8ab9f7"
            "ce2476f974ef5e1f6fc3be14d180422d"
        ),
    },
    "submission_resource_sha256": (
        "6292ca00d982534a8bef0ea1f21972ff"
        "9fd3d41c3f7316e8d28401820a54c98f"
    ),
    "submission_workload_digest": (
        "200a23050d671d33853bce76d2859b4d"
        "421bf04cb6d3a0c8efd64d9ebfb13fc8"
    ),
})

HISTORICAL_WORKLOAD_RESOURCE_SHA256_V1 = (
    "3fed0ff1b55681dbe173c36fb96a49c707c6475c652736ecd69c1103a94b80cb"
)
HISTORICAL_SUBMISSION_RESOURCE_SHA256_V1 = (
    "0bb2c21c100ea1b43b795fec9f0769bdebd9ceda06e9d65b1929295f46efad2d"
)
HISTORICAL_RESULT_SCHEMA_SHA256_V1 = (
    "8e9cad9bc060e27b19d60fb0749491fe35e92c47288dc9d4394bab6afecbc5fd"
)
HISTORICAL_CALIBRATION_RECORD_SHA256_V1 = (
    "6a2fc3f896acc02e9701c35dbc0b28e096ad55da0ef2437ac296d1ca98306fd8"
)
HISTORICAL_SOURCE_MANIFEST_SHA256_V1 = (
    "f003bd185ea01682a009b95fef739727e82fdc781920394ca0122f4278694e89"
)
HISTORICAL_SOURCE_RELEASE_COMMIT_V1 = (
    "43a82965282512df44538a9c472bf553c094b052"
)
HISTORICAL_LINEAGE_EVIDENCE_SCHEMA_VERSION_V2 = (
    "dreamgym-profile-workload-v2-lineage-v1"
)
LINEAGE_EVIDENCE_SCHEMA_VERSION = (
    "dreamgym-profile-workload-v3-lineage-v1"
)
HISTORICAL_RL_SEMANTIC_PROJECTION_VERSION_V1 = (
    "dreamgym-rl-semantic-projection-v1"
)
_PERMITTED_LINEAGE_DIFFERENCE_KINDS = (
    "resolver_version",
    "release_identity",
    "derived_identity",
)

_FULL_COMMIT_RE = re.compile(r"[0-9a-f]{40}\Z")


def validate_installed_v3_benchmark_sources(
    *,
    repository_root: str | Path | None = None,
) -> dict[str, Any]:
    """Validate installed v3 source authority, failing closed while absent."""

    try:
        return validate_current_benchmark_sources(
            repository_root=repository_root,
        )
    except (OSError, RuntimeError, TypeError, ValueError):
        return {
            "validated": False,
            "diagnostic": "profiling v3 is not yet released",
        }

HISTORICAL_WORKLOAD_SOURCE_AUTHORITY_V1 = (
    "dreamgym/__init__.py",
    "dreamgym/envs/__init__.py",
    "dreamgym/envs/_render_overlay.py",
    "dreamgym/envs/autonomous_driving_env.py",
    "dreamgym/envs/autonomous_driving_renderer.py",
    "dreamgym/envs/bicycle_model_dynamic.py",
    "dreamgym/envs/config_validation.py",
    "dreamgym/envs/observation_specs.py",
    "dreamgym/envs/road.py",
    "dreamgym/envs/road_core/__init__.py",
    "dreamgym/envs/road_core/cones.py",
    "dreamgym/envs/road_core/constants.py",
    "dreamgym/envs/road_core/horizon_samples.py",
    "dreamgym/envs/road_core/lane_geometry.py",
    "dreamgym/envs/road_core/observations.py",
    "dreamgym/envs/road_core/random_generation.py",
    "dreamgym/envs/road_core/reference_geometry.py",
    "dreamgym/envs/road_core/rendering.py",
    "dreamgym/envs/road_core/schema.py",
    "dreamgym/envs/road_core/schema_utils.py",
    "dreamgym/envs/road_core/speeds.py",
    "dreamgym/envs/road_core/target_arc_length.py",
    "dreamgym/envs/road_core/target_geometry.py",
    "dreamgym/envs/road_core/target_offsets.py",
    "dreamgym/envs/road_core/target_samples.py",
    "dreamgym/envs/road_core/utils.py",
    "dreamgym/envs/road_preview.py",
    "dreamgym/policies/__init__.py",
    "dreamgym/policies/autonomous_driving/__init__.py",
    "dreamgym/policies/autonomous_driving/_mpc_adapter.py",
    "dreamgym/policies/autonomous_driving/_mpc_control.py",
    "dreamgym/policies/autonomous_driving/_mpc_failures.py",
    "dreamgym/policies/autonomous_driving/_mpc_formulations.py",
    "dreamgym/policies/autonomous_driving/_mpc_policy_base.py",
    "dreamgym/policies/autonomous_driving/_mpc_rollout.py",
    "dreamgym/policies/autonomous_driving/mpc.py",
    "dreamgym/policies/autonomous_driving/mpc_config.py",
    "dreamgym/policies/autonomous_driving/mpc_results.py",
    "dreamgym/policies/autonomous_driving/pid.py",
    "dreamgym/policies/autonomous_driving/rl.py",
    "dreamgym/policies/mpc/__init__.py",
    "dreamgym/policies/mpc/_diagnostics.py",
    "dreamgym/policies/mpc/_formulation.py",
    "dreamgym/policies/mpc/config.py",
    "dreamgym/policies/mpc/problem.py",
    "dreamgym/policies/mpc/results.py",
    "dreamgym/policies/mpc/solver.py",
    "dreamgym/profiling/__init__.py",
    "dreamgym/profiling/autonomous_driving/__init__.py",
    "dreamgym/profiling/autonomous_driving/bundle.py",
    "dreamgym/profiling/autonomous_driving/core_suites.py",
    "dreamgym/profiling/autonomous_driving/environment.py",
    "dreamgym/profiling/autonomous_driving/gym_step.py",
    "dreamgym/profiling/autonomous_driving/machine.py",
    "dreamgym/profiling/autonomous_driving/measurement.py",
    "dreamgym/profiling/autonomous_driving/metadata.py",
    "dreamgym/profiling/autonomous_driving/mpc.py",
    "dreamgym/profiling/autonomous_driving/privacy.py",
    "dreamgym/profiling/autonomous_driving/production_rl.py",
    "dreamgym/profiling/autonomous_driving/records.py",
    "dreamgym/profiling/autonomous_driving/reporting.py",
    "dreamgym/profiling/autonomous_driving/resources/__init__.py",
    "dreamgym/profiling/autonomous_driving/resources/result_bundle_v1.schema.json",
    "dreamgym/profiling/autonomous_driving/resources/submission_workload_v1.json",
    "dreamgym/profiling/autonomous_driving/resources/workload_v1.json",
    "dreamgym/profiling/autonomous_driving/rl_worker.py",
    "dreamgym/profiling/autonomous_driving/road.py",
    "dreamgym/profiling/autonomous_driving/runner.py",
    "dreamgym/profiling/autonomous_driving/workloads.py",
    "dreamgym/profiling/common.py",
    "dreamgym/training/__init__.py",
    "dreamgym/training/autonomous_driving/__init__.py",
    "dreamgym/training/autonomous_driving/algorithm_profiles.py",
    "dreamgym/training/autonomous_driving/config_validation.py",
    "dreamgym/training/autonomous_driving/configs.py",
    "dreamgym/training/autonomous_driving/envs.py",
    "dreamgym/training/autonomous_driving/model_discovery.py",
    "dreamgym/training/autonomous_driving/models.py",
    "dreamgym/training/autonomous_driving/resolution.py",
    "dreamgym/training/autonomous_driving/rewards.py",
    "dreamgym/training/autonomous_driving/seeds.py",
    "dreamgym/training/autonomous_driving/snapshots.py",
    "scripts/profile_machine.py",
)

WORKLOAD_SOURCE_AUTHORITY_V2 = (
    "dreamgym/__init__.py",
    "dreamgym/envs/__init__.py",
    "dreamgym/envs/_render_config.py",
    "dreamgym/envs/_render_overlay.py",
    "dreamgym/envs/autonomous_driving_env.py",
    "dreamgym/envs/bicycle_model_dynamic.py",
    "dreamgym/envs/config_validation.py",
    "dreamgym/envs/observation_specs.py",
    "dreamgym/envs/road.py",
    "dreamgym/envs/road_core/__init__.py",
    "dreamgym/envs/road_core/cones.py",
    "dreamgym/envs/road_core/constants.py",
    "dreamgym/envs/road_core/horizon_samples.py",
    "dreamgym/envs/road_core/lane_geometry.py",
    "dreamgym/envs/road_core/observations.py",
    "dreamgym/envs/road_core/random_generation.py",
    "dreamgym/envs/road_core/reference_geometry.py",
    "dreamgym/envs/road_core/schema.py",
    "dreamgym/envs/road_core/schema_utils.py",
    "dreamgym/envs/road_core/speeds.py",
    "dreamgym/envs/road_core/target_arc_length.py",
    "dreamgym/envs/road_core/target_geometry.py",
    "dreamgym/envs/road_core/target_offsets.py",
    "dreamgym/envs/road_core/target_samples.py",
    "dreamgym/envs/road_core/utils.py",
    "dreamgym/envs/road_preview.py",
    "dreamgym/policies/__init__.py",
    "dreamgym/policies/autonomous_driving/__init__.py",
    "dreamgym/policies/autonomous_driving/_mpc_adapter.py",
    "dreamgym/policies/autonomous_driving/_mpc_control.py",
    "dreamgym/policies/autonomous_driving/_mpc_failures.py",
    "dreamgym/policies/autonomous_driving/_mpc_formulations.py",
    "dreamgym/policies/autonomous_driving/_mpc_policy_base.py",
    "dreamgym/policies/autonomous_driving/_mpc_rollout.py",
    "dreamgym/policies/autonomous_driving/mpc.py",
    "dreamgym/policies/autonomous_driving/mpc_config.py",
    "dreamgym/policies/autonomous_driving/mpc_results.py",
    "dreamgym/policies/autonomous_driving/pid.py",
    "dreamgym/policies/autonomous_driving/rl.py",
    "dreamgym/policies/mpc/__init__.py",
    "dreamgym/policies/mpc/_diagnostics.py",
    "dreamgym/policies/mpc/_formulation.py",
    "dreamgym/policies/mpc/config.py",
    "dreamgym/policies/mpc/problem.py",
    "dreamgym/policies/mpc/results.py",
    "dreamgym/policies/mpc/solver.py",
    "dreamgym/profiling/__init__.py",
    "dreamgym/profiling/autonomous_driving/__init__.py",
    "dreamgym/profiling/autonomous_driving/bundle.py",
    "dreamgym/profiling/autonomous_driving/core_suites.py",
    "dreamgym/profiling/autonomous_driving/environment.py",
    "dreamgym/profiling/autonomous_driving/gym_step.py",
    "dreamgym/profiling/autonomous_driving/machine.py",
    "dreamgym/profiling/autonomous_driving/measurement.py",
    "dreamgym/profiling/autonomous_driving/metadata.py",
    "dreamgym/profiling/autonomous_driving/mpc.py",
    "dreamgym/profiling/autonomous_driving/privacy.py",
    "dreamgym/profiling/autonomous_driving/production_rl.py",
    "dreamgym/profiling/autonomous_driving/records.py",
    "dreamgym/profiling/autonomous_driving/reporting.py",
    "dreamgym/profiling/autonomous_driving/resources/__init__.py",
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "result_bundle_v1.schema.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "submission_workload_v2.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "workload_v2.json"
    ),
    "dreamgym/profiling/autonomous_driving/rl_worker.py",
    "dreamgym/profiling/autonomous_driving/road.py",
    "dreamgym/profiling/autonomous_driving/runner.py",
    "dreamgym/profiling/autonomous_driving/workloads.py",
    "dreamgym/profiling/common.py",
    "dreamgym/training/__init__.py",
    "dreamgym/training/autonomous_driving/__init__.py",
    "dreamgym/training/autonomous_driving/algorithm_profiles.py",
    "dreamgym/training/autonomous_driving/config_validation.py",
    "dreamgym/training/autonomous_driving/configs.py",
    "dreamgym/training/autonomous_driving/envs.py",
    "dreamgym/training/autonomous_driving/model_discovery.py",
    "dreamgym/training/autonomous_driving/models.py",
    "dreamgym/training/autonomous_driving/resolution.py",
    "dreamgym/training/autonomous_driving/rewards.py",
    "dreamgym/training/autonomous_driving/seeds.py",
    "dreamgym/training/autonomous_driving/snapshots.py",
    "scripts/profile_machine.py",
)

WORKLOAD_SOURCE_AUTHORITY_V3 = (
    "dreamgym/__init__.py",
    "dreamgym/envs/__init__.py",
    "dreamgym/envs/_render_config.py",
    "dreamgym/envs/_render_overlay.py",
    "dreamgym/envs/autonomous_driving_env.py",
    "dreamgym/envs/bicycle_model_dynamic.py",
    "dreamgym/envs/config_validation.py",
    "dreamgym/envs/observation_specs.py",
    "dreamgym/envs/road.py",
    "dreamgym/envs/road_core/__init__.py",
    "dreamgym/envs/road_core/cones.py",
    "dreamgym/envs/road_core/constants.py",
    "dreamgym/envs/road_core/horizon_samples.py",
    "dreamgym/envs/road_core/lane_geometry.py",
    "dreamgym/envs/road_core/observations.py",
    "dreamgym/envs/road_core/random_generation.py",
    "dreamgym/envs/road_core/reference_geometry.py",
    "dreamgym/envs/road_core/schema.py",
    "dreamgym/envs/road_core/schema_utils.py",
    "dreamgym/envs/road_core/_target_config.py",
    "dreamgym/envs/road_core/speeds.py",
    "dreamgym/envs/road_core/target_arc_length.py",
    "dreamgym/envs/road_core/target_geometry.py",
    "dreamgym/envs/road_core/target_offsets.py",
    "dreamgym/envs/road_core/target_samples.py",
    "dreamgym/envs/road_core/utils.py",
    "dreamgym/envs/road_preview.py",
    "dreamgym/policies/__init__.py",
    "dreamgym/policies/autonomous_driving/__init__.py",
    "dreamgym/policies/autonomous_driving/_mpc_adapter.py",
    "dreamgym/policies/autonomous_driving/_mpc_control.py",
    "dreamgym/policies/autonomous_driving/_mpc_failures.py",
    "dreamgym/policies/autonomous_driving/_mpc_formulations.py",
    "dreamgym/policies/autonomous_driving/_mpc_policy_base.py",
    "dreamgym/policies/autonomous_driving/_mpc_rollout.py",
    "dreamgym/policies/autonomous_driving/mpc.py",
    "dreamgym/policies/autonomous_driving/mpc_config.py",
    "dreamgym/policies/autonomous_driving/mpc_results.py",
    "dreamgym/policies/autonomous_driving/pid.py",
    "dreamgym/policies/autonomous_driving/rl.py",
    "dreamgym/policies/mpc/__init__.py",
    "dreamgym/policies/mpc/_diagnostics.py",
    "dreamgym/policies/mpc/_formulation.py",
    "dreamgym/policies/mpc/config.py",
    "dreamgym/policies/mpc/problem.py",
    "dreamgym/policies/mpc/results.py",
    "dreamgym/policies/mpc/solver.py",
    "dreamgym/profiling/__init__.py",
    "dreamgym/profiling/autonomous_driving/__init__.py",
    "dreamgym/profiling/autonomous_driving/bundle.py",
    "dreamgym/profiling/autonomous_driving/core_suites.py",
    "dreamgym/profiling/autonomous_driving/environment.py",
    "dreamgym/profiling/autonomous_driving/gym_step.py",
    "dreamgym/profiling/autonomous_driving/machine.py",
    "dreamgym/profiling/autonomous_driving/measurement.py",
    "dreamgym/profiling/autonomous_driving/metadata.py",
    "dreamgym/profiling/autonomous_driving/mpc.py",
    "dreamgym/profiling/autonomous_driving/privacy.py",
    "dreamgym/profiling/autonomous_driving/production_rl.py",
    "dreamgym/profiling/autonomous_driving/records.py",
    "dreamgym/profiling/autonomous_driving/reporting.py",
    "dreamgym/profiling/autonomous_driving/resources/__init__.py",
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "result_bundle_v1.schema.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "submission_workload_v3.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "workload_v3.json"
    ),
    "dreamgym/profiling/autonomous_driving/rl_worker.py",
    "dreamgym/profiling/autonomous_driving/road.py",
    "dreamgym/profiling/autonomous_driving/runner.py",
    "dreamgym/profiling/autonomous_driving/workloads.py",
    "dreamgym/profiling/common.py",
    "dreamgym/training/__init__.py",
    "dreamgym/training/autonomous_driving/__init__.py",
    "dreamgym/training/autonomous_driving/algorithm_profiles.py",
    "dreamgym/training/autonomous_driving/config_validation.py",
    "dreamgym/training/autonomous_driving/configs.py",
    "dreamgym/training/autonomous_driving/envs.py",
    "dreamgym/training/autonomous_driving/model_discovery.py",
    "dreamgym/training/autonomous_driving/models.py",
    "dreamgym/training/autonomous_driving/resolution.py",
    "dreamgym/training/autonomous_driving/rewards.py",
    "dreamgym/training/autonomous_driving/seeds.py",
    "dreamgym/training/autonomous_driving/snapshots.py",
    "scripts/profile_machine.py",
)

_V3_CANONICAL_RESOURCE_PATHS = frozenset({
    "dreamgym/profiling/autonomous_driving/resources/"
    "submission_workload_v3.json",
    "dreamgym/profiling/autonomous_driving/resources/workload_v3.json",
})

CANDIDATE_RUNTIME_SOURCE_AUTHORITY_V3 = tuple(
    path
    for path in WORKLOAD_SOURCE_AUTHORITY_V3
    if path not in _V3_CANONICAL_RESOURCE_PATHS
)

_CURRENT_BENCHMARK_NON_MODULE_SOURCE_PATHS_V1 = (
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "result_bundle_v1.schema.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "submission_workload_v2.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "workload_v2.json"
    ),
    "scripts/profile_machine.py",
)

_CURRENT_BENCHMARK_NON_MODULE_SOURCE_PATHS_V3 = (
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "result_bundle_v1.schema.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "submission_workload_v3.json"
    ),
    (
        "dreamgym/profiling/autonomous_driving/resources/"
        "workload_v3.json"
    ),
    "scripts/profile_machine.py",
)

BENCHMARK_SOURCE_PATHS_V1 = tuple(sorted((
    *BENCHMARK_MODULE_ORIGINS_V1.values(),
    *_CURRENT_BENCHMARK_NON_MODULE_SOURCE_PATHS_V1,
)))

BENCHMARK_SOURCE_PATHS_V3 = tuple(sorted((
    *BENCHMARK_MODULE_ORIGINS_V3.values(),
    *_CURRENT_BENCHMARK_NON_MODULE_SOURCE_PATHS_V3,
)))

_BENCHMARK_SOURCE_MANIFEST_PATH = (
    "dreamgym/profiling/autonomous_driving/resources/"
    "benchmark_sources_workload_v3.json"
)
_HISTORICAL_BENCHMARK_SOURCE_MANIFEST_PATH_V1 = (
    "dreamgym/profiling/autonomous_driving/resources/"
    "benchmark_sources_workload_v1.json"
)
_HISTORICAL_BENCHMARK_SOURCE_MANIFEST_SHA256_V1 = (
    "f003bd185ea01682a009b95fef739727e82fdc781920394ca0122f4278694e89"
)
_HISTORICAL_BENCHMARK_SOURCE_RELEASE_REFERENCE_V1 = (
    "43a82965282512df44538a9c472bf553c094b052"
)


@dataclass(frozen=True)
class BenchmarkSourceReleaseAuthority:
    """One packaged manifest bound to its real source-release commit."""

    manifest_digest: str
    release_reference: str
    _manifest_bytes: bytes

    @property
    def manifest(self) -> dict[str, Any]:
        """Return a detached JSON-native copy of the frozen manifest."""

        return json.loads(self._manifest_bytes.decode("utf-8"))


def load_historical_benchmark_source_release_authority_v1(
    *,
    repository_root: str | Path | None = None,
    manifest: Mapping[str, Any] | None = None,
) -> BenchmarkSourceReleaseAuthority:
    """Load the exact archived workload-v1 path/digest authority."""

    root = (
        Path(__file__).resolve().parents[3]
        if repository_root is None
        else Path(repository_root).resolve(strict=True)
    )
    try:
        raw_archive = root.joinpath(
            *_safe_repository_path(
                _HISTORICAL_BENCHMARK_SOURCE_MANIFEST_PATH_V1
            ).parts
        ).read_bytes()
        if hashlib.sha256(raw_archive).hexdigest() != (
            _HISTORICAL_BENCHMARK_SOURCE_MANIFEST_SHA256_V1
        ):
            raise ValueError
        archive = json.loads(raw_archive.decode("utf-8"))
        expected_paths = tuple(sorted((
            *HISTORICAL_WORKLOAD_SOURCE_AUTHORITY_V1,
            "dreamgym/profiling/autonomous_driving/notebook.py",
            "dreamgym/profiling/autonomous_driving/release.py",
        )))
        if (
            type(archive) is not dict
            or set(archive) != {"schema_version", "files"}
            or archive["schema_version"]
            != BENCHMARK_SOURCE_MANIFEST_SCHEMA_VERSION
            or type(archive["files"]) is not dict
            or tuple(archive["files"]) != expected_paths
            or any(
                type(digest) is not str
                or re.fullmatch(r"[0-9a-f]{64}", digest) is None
                for digest in archive["files"].values()
            )
        ):
            raise ValueError
        if manifest is not None and (
            type(manifest) is not dict
            or manifest != archive
            or manifest["files"] != archive["files"]
        ):
            raise ValueError
        canonical_bytes = canonical_json_bytes(archive)
        return BenchmarkSourceReleaseAuthority(
            manifest_digest=hashlib.sha256(canonical_bytes).hexdigest(),
            release_reference=(
                _HISTORICAL_BENCHMARK_SOURCE_RELEASE_REFERENCE_V1
            ),
            _manifest_bytes=canonical_bytes,
        )
    except (
        OSError,
        TypeError,
        ValueError,
        json.JSONDecodeError,
        UnicodeDecodeError,
    ) as error:
        raise ValueError(
            "historical benchmark source release authority is invalid"
        ) from error


def _benchmark_source_manifest_document(
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    if type(manifest) is not dict or set(manifest) != {
        "schema_version",
        "files",
    }:
        raise ValueError("benchmark source release authority is invalid")
    if (
        manifest["schema_version"]
        != BENCHMARK_SOURCE_MANIFEST_SCHEMA_VERSION
    ):
        raise ValueError("benchmark source release authority is invalid")
    files = manifest["files"]
    if (
        type(files) is not dict
        or tuple(files) != BENCHMARK_SOURCE_PATHS_V3
        or any(
            type(digest) is not str
            or re.fullmatch(r"[0-9a-f]{64}", digest) is None
            for digest in files.values()
        )
    ):
        raise ValueError("benchmark source release authority is invalid")
    return json.loads(canonical_json_bytes(manifest).decode("utf-8"))


def load_benchmark_source_release_authority(
    *,
    repository_root: str | Path | None = None,
    manifest: Mapping[str, Any] | None = None,
) -> BenchmarkSourceReleaseAuthority:
    """Load the exact manifest and bind it to its source-release commit.

    This validates the packaged authority itself, independently of whether
    the current working source files still match it.  Timed-workload callers
    use :func:`validate_current_benchmark_sources` for that second check.
    """

    root = (
        Path(__file__).resolve().parents[3]
        if repository_root is None
        else Path(repository_root).resolve(strict=True)
    )
    try:
        raw_manifest = (
            json.loads(
                root.joinpath(
                    *_safe_repository_path(
                        _BENCHMARK_SOURCE_MANIFEST_PATH
                    ).parts
                ).read_text(encoding="utf-8")
            )
            if manifest is None
            else dict(manifest)
        )
        document = _benchmark_source_manifest_document(raw_manifest)
        canonical_bytes = canonical_json_bytes(document)
        history = _git(
            root,
            [
                "log",
                "--format=%H",
                "--",
                _BENCHMARK_SOURCE_MANIFEST_PATH,
            ],
            text=True,
        )
        if history.returncode != 0:
            raise ValueError
        release_reference = None
        for candidate in history.stdout.splitlines():
            if _FULL_COMMIT_RE.fullmatch(candidate) is None:
                continue
            committed = _git(
                root,
                [
                    "show",
                    candidate + ":" + _BENCHMARK_SOURCE_MANIFEST_PATH,
                ],
                text=True,
            )
            if committed.returncode != 0:
                continue
            try:
                committed_document = _benchmark_source_manifest_document(
                    json.loads(committed.stdout)
                )
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if canonical_json_bytes(committed_document) == canonical_bytes:
                release_reference = candidate
                break
        if release_reference is None:
            raise ValueError
        return BenchmarkSourceReleaseAuthority(
            manifest_digest=hashlib.sha256(canonical_bytes).hexdigest(),
            release_reference=release_reference,
            _manifest_bytes=canonical_bytes,
        )
    except (
        OSError,
        TypeError,
        ValueError,
        json.JSONDecodeError,
        UnicodeDecodeError,
    ) as error:
        raise ValueError(
            "benchmark source release authority is invalid"
        ) from error


def validate_current_benchmark_sources(
    *,
    repository_root: str | Path | None = None,
) -> dict[str, Any]:
    """Validate current source bytes/origins against the frozen manifest."""

    from dreamgym.profiling.autonomous_driving.notebook import (
        validate_benchmark_sources,
    )

    root = (
        Path(__file__).resolve().parents[3]
        if repository_root is None
        else Path(repository_root).resolve(strict=True)
    )
    authority = load_benchmark_source_release_authority(
        repository_root=root,
    )
    origins = {
        name: getattr(sys.modules[name], "__file__", None)
        for name in BENCHMARK_MODULE_ORIGINS_V3
        if name in sys.modules
    }
    validation = validate_benchmark_sources(
        root,
        authority.manifest,
        imported_module_origins=origins,
    )
    if (
        validation.validated is not True
        or validation.manifest_digest != authority.manifest_digest
    ):
        raise ValueError("benchmark source validation failed")
    return {
        **validation.to_dict(),
        "release_commit": authority.release_reference,
    }


def _safe_repository_path(value: str) -> PurePosixPath:
    if type(value) is not str or not value or "\\" in value:
        raise ValueError("benchmark source path must be canonical POSIX text")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or path.as_posix() != value
        or any(part in {"", ".", ".."} for part in path.parts)
        or ":" in path.parts[0]
    ):
        raise ValueError("benchmark source path is not repository-relative")
    return path


def validate_benchmark_source_paths(
    paths: Sequence[str],
) -> tuple[str, ...]:
    """Accept only the exact reviewed v3 boundary, never a supplied subset."""

    if isinstance(paths, (str, bytes)):
        raise TypeError("benchmark source paths must be a sequence")
    candidate = tuple(paths)
    for value in candidate:
        _safe_repository_path(value)
    if (
        candidate != BENCHMARK_SOURCE_PATHS_V3
        or candidate != tuple(sorted(candidate))
        or len(candidate) != len(set(candidate))
    ):
        raise ValueError(
            "benchmark sources must equal the exact reviewed v3 authority"
        )
    return BENCHMARK_SOURCE_PATHS_V3


def _git(
    repository_root: Path,
    arguments: Sequence[str],
    *,
    text: bool,
) -> subprocess.CompletedProcess[Any]:
    return subprocess.run(
        ["git", "-C", str(repository_root), *arguments],
        check=False,
        capture_output=True,
        text=text,
    )


def benchmark_source_manifest_entries(
    repository_root: str | Path,
    release_commit: str,
) -> tuple[dict[str, str], ...]:
    """Hash exact clean working-tree bytes attested by one full Git commit."""

    if type(release_commit) is not str or _FULL_COMMIT_RE.fullmatch(
        release_commit
    ) is None:
        raise ValueError("release_commit must be an exact full commit hash")
    root = Path(repository_root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("repository_root must be a directory")
    resolved_commit = _git(
        root,
        ["rev-parse", "--verify", release_commit + "^{commit}"],
        text=True,
    )
    if (
        resolved_commit.returncode != 0
        or resolved_commit.stdout.strip() != release_commit
    ):
        raise ValueError("release_commit is not the exact approved commit")

    entries = []
    resolved_keys: set[str] = set()
    for relative in validate_benchmark_source_paths(
        BENCHMARK_SOURCE_PATHS_V3
    ):
        canonical = _safe_repository_path(relative)
        current_path = root.joinpath(*canonical.parts)
        resolved_path = current_path.resolve(strict=True)
        try:
            resolved_path.relative_to(root)
        except ValueError as error:
            raise ValueError(
                "benchmark source resolves outside repository: " + relative
            ) from error
        resolved_key = str(resolved_path).casefold()
        if resolved_key in resolved_keys:
            raise ValueError("benchmark source paths do not resolve uniquely")
        resolved_keys.add(resolved_key)
        parent = current_path.parent
        parent_is_symlink = False
        while parent != root:
            if parent.is_symlink():
                parent_is_symlink = True
                break
            parent = parent.parent
        if (
            not current_path.is_file()
            or current_path.is_symlink()
            or parent_is_symlink
        ):
            raise ValueError(
                "benchmark source must be a regular non-symlink file: "
                + relative
            )
        tracked = _git(
            root,
            ["ls-files", "--error-unmatch", "--", relative],
            text=True,
        )
        if tracked.returncode != 0 or tracked.stdout.strip() != relative:
            raise ValueError(
                "benchmark source is not exactly tracked: " + relative
            )
        for arguments in (
            ["diff", "--quiet", "--", relative],
            [
                "diff",
                "--cached",
                "--quiet",
                release_commit,
                "--",
                relative,
            ],
        ):
            clean = _git(root, arguments, text=False)
            if clean.returncode != 0:
                raise ValueError(
                    "benchmark source has staged or unstaged changes: "
                    + relative
                )
        tree_entry = _git(
            root,
            ["ls-tree", release_commit, "--", relative],
            text=True,
        )
        fields = tree_entry.stdout.strip().split(maxsplit=3)
        if (
            tree_entry.returncode != 0
            or len(fields) != 4
            or fields[0] not in {"100644", "100755"}
            or fields[1] != "blob"
            or fields[3] != relative
        ):
            raise ValueError(
                "benchmark source is not a regular file at release commit: "
                + relative
            )
        committed = _git(
            root,
            ["show", release_commit + ":" + relative],
            text=False,
        )
        if committed.returncode != 0:
            raise ValueError(
                "benchmark source is missing at release commit: " + relative
            )
        current_bytes = current_path.read_bytes()
        if current_bytes != committed.stdout:
            raise ValueError(
                "benchmark source bytes differ from release commit: "
                + relative
            )
        entries.append(
            {
                "path": relative,
                "sha256": hashlib.sha256(current_bytes).hexdigest(),
            }
        )
    return tuple(entries)


def validate_loaded_source_origins(
    repository_root: str | Path,
    module_origins: Mapping[str, str | Path],
) -> dict[str, str]:
    """Require the complete exact 81-name runtime source authority."""

    return validate_benchmark_module_origins(
        repository_root,
        module_origins,
        require_exact=True,
    )


def audit_benchmark_source_origins(
    repository_root: str | Path,
) -> dict[str, str]:
    """Import and validate all benchmark modules in an isolated process."""

    root = Path(repository_root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("repository_root must be a directory")
    probe = (
        "import importlib,json,pathlib,sys\n"
        "root=pathlib.Path(sys.argv[1]).resolve(strict=True)\n"
        "sys.path.insert(0,str(root))\n"
        "from dreamgym.profiling.autonomous_driving.records import "
        "BENCHMARK_MODULE_ORIGINS_V3,"
        "collect_loaded_benchmark_module_origins,"
        "validate_benchmark_module_origins\n"
        "for name in BENCHMARK_MODULE_ORIGINS_V3:\n"
        "    importlib.import_module(name)\n"
        "loaded=collect_loaded_benchmark_module_origins()\n"
        "origins={name:loaded[name] "
        "for name in BENCHMARK_MODULE_ORIGINS_V3}\n"
        "validated=validate_benchmark_module_origins("
        "root,origins,require_exact=True)\n"
        "sys.stdout.write(json.dumps(validated,sort_keys=True))\n"
    )
    completed = subprocess.run(
        [
            sys.executable,
            "-I",
            "-B",
            "-c",
            probe,
            str(root),
        ],
        cwd=root,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise ValueError(
            "fresh-process benchmark source-origin audit failed"
            + (": " + detail if detail else "")
        )
    try:
        validated = json.loads(completed.stdout)
    except json.JSONDecodeError as error:
        raise ValueError(
            "fresh-process source-origin audit returned invalid output"
        ) from error
    if validated != dict(BENCHMARK_MODULE_ORIGINS_V3):
        raise ValueError(
            "fresh-process source-origin audit returned an incomplete "
            "authority"
        )
    return validated


@dataclass(frozen=True)
class HistoricalReleaseResourcesV1:
    """Detached, fixed-hash profiling-v1 ancestry documents."""

    _workload_bytes: bytes
    _submission_bytes: bytes
    _result_schema_bytes: bytes
    _source_manifest_bytes: bytes

    @property
    def workload(self) -> dict[str, Any]:
        return json.loads(self._workload_bytes.decode("utf-8"))

    @property
    def submission(self) -> dict[str, Any]:
        return json.loads(self._submission_bytes.decode("utf-8"))

    @property
    def result_schema(self) -> dict[str, Any]:
        return json.loads(self._result_schema_bytes.decode("utf-8"))

    @property
    def source_manifest(self) -> dict[str, Any]:
        return json.loads(self._source_manifest_bytes.decode("utf-8"))

    @property
    def source_authority(self) -> tuple[str, ...]:
        return tuple(self.workload["source_authority"])

    @property
    def resource_sha256(self) -> dict[str, str]:
        return {
            "workload": HISTORICAL_WORKLOAD_RESOURCE_SHA256_V1,
            "submission": HISTORICAL_SUBMISSION_RESOURCE_SHA256_V1,
            "result_schema": HISTORICAL_RESULT_SCHEMA_SHA256_V1,
            "calibration": HISTORICAL_CALIBRATION_RECORD_SHA256_V1,
            "source_manifest": HISTORICAL_SOURCE_MANIFEST_SHA256_V1,
        }


_HISTORICAL_WORKLOAD_PATH_V1 = (
    "dreamgym/profiling/autonomous_driving/resources/workload_v1.json"
)
_HISTORICAL_SUBMISSION_PATH_V1 = (
    "dreamgym/profiling/autonomous_driving/resources/"
    "submission_workload_v1.json"
)
_HISTORICAL_RESULT_SCHEMA_PATH_V1 = (
    "dreamgym/profiling/autonomous_driving/resources/"
    "result_bundle_v1.schema.json"
)
_HISTORICAL_CALIBRATION_PATH_V1 = (
    "docs/profiling_workload_v1_calibration.md"
)
_COMPARISON_INPUT_KEYS = {
    "resolved_workload",
    "rl_destination_views",
}
_DESTINATION_VIEW_KEYS = {
    "readable_identity",
    "family",
    "requested_transition_target",
    "semantic_case_digest",
    "destination_execution_spec_digest",
    "destination_requested_config_digest",
    "destination_requested_config_path",
    "selected_source_case_id",
    "selected_source_execution_spec_digest",
    "selected_source_requested_config_digest",
    "selected_source_requested_config_path",
    "selected_source_resolved_config_path",
}
_METRIC_DEFINITION_KEYS = {
    "order",
    "case_id",
    "execution_spec_digest",
    "label",
    "suite",
    "metric",
    "definition",
    "source_path",
    "source_unit",
    "display_unit",
    "conversion",
}
_LINEAGE_COUNTS = {
    "quick": (48, 9, 11),
    "medium": (108, 10, 12),
    "long": (109, 11, 13),
    "submission": (4, 2, 2),
}


def _is_sha256(value: object) -> bool:
    return (
        type(value) is str
        and re.fullmatch(r"[0-9a-f]{64}", value) is not None
    )


def _read_fixed_historical_json(
    root: Path,
    *,
    relative_path: str,
    expected_sha256: str,
    label: str,
) -> tuple[bytes, dict[str, Any]]:
    """Hash one archival resource before any decoding or JSON parsing."""

    try:
        raw = _safe_source_bytes(root, relative_path)
    except OSError as error:
        raise ValueError(label + " is unavailable") from error
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError(label + " does not match its fixed raw SHA-256")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError(label + " is not strict UTF-8 JSON") from error
    if type(document) is not dict:
        raise ValueError(label + " must be a JSON object")
    return raw, document


def _validate_structural_workload(
    document: Mapping[str, Any],
) -> dict[str, tuple[dict[str, Any], dict[str, Any]]]:
    """Recompute every stored case, execution, timing, and workload identity."""

    from dreamgym.profiling.autonomous_driving.records import (
        CaseSpec,
        ExecutionSpec,
        ResolvedWorkload,
    )

    if type(document) is not dict or set(document) != {
        "schema_version",
        "workload_version",
        "workload_digest",
        "cases",
    }:
        raise ValueError("workload snapshot has an invalid shape")
    if type(document["cases"]) is not list:
        raise ValueError("workload cases must be an array")
    pairs = []
    indexed: dict[str, tuple[dict[str, Any], dict[str, Any]]] = {}
    for item in document["cases"]:
        if type(item) is not dict or set(item) != {
            "case_spec",
            "execution_spec",
        }:
            raise ValueError("workload case record has an invalid shape")
        case_document = item["case_spec"]
        execution_document = item["execution_spec"]
        if type(case_document) is not dict or type(execution_document) is not dict:
            raise ValueError("workload case records must be objects")
        try:
            case = CaseSpec(
                readable_prefix=case_document["readable_prefix"],
                semantic_document=case_document["semantic_document"],
                timing_protocol=case_document["timing_protocol"],
                schema_version=case_document["schema_version"],
            )
            execution = ExecutionSpec(
                semantic_case_id=execution_document["semantic_case_id"],
                execution_document=execution_document["execution_document"],
                schema_version=execution_document["schema_version"],
            )
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError("stored case identity is invalid") from error
        if case.to_dict() != case_document or execution.to_dict() != execution_document:
            raise ValueError("stored case identity does not recompute exactly")
        if case.semantic_case_id in indexed:
            raise ValueError("semantic case identities must be unique")
        indexed[case.semantic_case_id] = (case_document, execution_document)
        pairs.append((case, execution))
    try:
        workload = ResolvedWorkload(
            workload_version=document["workload_version"],
            cases=pairs,
            schema_version=document["schema_version"],
        )
    except (TypeError, ValueError) as error:
        raise ValueError("stored workload identity is invalid") from error
    if workload.to_dict() != document:
        raise ValueError("stored workload digest does not recompute exactly")
    return indexed


def _requested_config_path(digest: str, filename: str) -> str:
    return "training_configs/" + digest + "/" + filename


def _validate_lineage_comparison_input(
    name: str,
    value: Mapping[str, Any],
) -> dict[str, tuple[dict[str, Any], dict[str, Any]]]:
    expected_keys = set(_COMPARISON_INPUT_KEYS)
    if name == "submission":
        expected_keys.add("metric_definitions")
    if type(value) is not dict or set(value) != expected_keys:
        raise ValueError("lineage comparison input has an invalid shape")
    indexed = _validate_structural_workload(value["resolved_workload"])
    views = value["rl_destination_views"]
    if type(views) is not list:
        raise ValueError("destination views must be an array")
    identities: set[str] = set()
    for view in views:
        if type(view) is not dict or set(view) != _DESTINATION_VIEW_KEYS:
            raise ValueError("destination view has an invalid shape")
        identity = view["readable_identity"]
        if type(identity) is not str or not identity or identity in identities:
            raise ValueError("destination view identities must be unique")
        identities.add(identity)
        selected = indexed.get(view["selected_source_case_id"])
        if selected is None:
            raise ValueError("destination view selects an unknown case")
        case, execution = selected
        selected_digest = view["selected_source_requested_config_digest"]
        destination_digest = view["destination_requested_config_digest"]
        if (
            view["semantic_case_digest"] != case["semantic_case_digest"]
            or view["selected_source_execution_spec_digest"]
            != execution["execution_spec_digest"]
            or view["destination_execution_spec_digest"]
            != execution["execution_spec_digest"]
            or not _is_sha256(selected_digest)
            or not _is_sha256(destination_digest)
            or view["selected_source_requested_config_path"]
            != _requested_config_path(selected_digest, "config.json")
            or view["selected_source_resolved_config_path"]
            != _requested_config_path(selected_digest, "resolved_config.json")
            or view["destination_requested_config_path"]
            != _requested_config_path(destination_digest, "config.json")
        ):
            raise ValueError("destination view cross-reference is invalid")
    if name != "submission":
        return indexed
    metrics = value["metric_definitions"]
    if type(metrics) is not list or len(metrics) != 4:
        raise ValueError("submission metric definitions are not exact")
    for order, metric in enumerate(metrics, start=1):
        if (
            type(metric) is not dict
            or set(metric) != _METRIC_DEFINITION_KEYS
            or metric["order"] != order
        ):
            raise ValueError("submission metric definition has an invalid shape")
        selected = indexed.get(metric["case_id"])
        if selected is None:
            raise ValueError("submission metric selects an unknown case")
        case, execution = selected
        semantic = case["semantic_document"]
        expected_suite = (
            "rl"
            if (
                semantic.get("semantic_projection_version")
                == "dreamgym-rl-semantic-projection-v1"
                and "resolver_version"
                in semantic.get("production_versions", {})
            )
            else semantic.get("suite")
        )
        if (
            metric["suite"] != expected_suite
            or metric["execution_spec_digest"]
            != execution["execution_spec_digest"]
        ):
            raise ValueError("submission metric cross-reference is invalid")
    return indexed


def _historical_submission_comparison_input(
    workload: Mapping[str, Any],
    submission: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "resolved_workload": copy.deepcopy(submission["resolved_workload"]),
        "rl_destination_views": copy.deepcopy(
            submission["rl_destination_views"]
        ),
        "metric_definitions": copy.deepcopy(
            workload["submission_authority"]["metric_definitions"]
        ),
    }


def load_historical_release_resources_v1(
    *,
    repository_root: str | Path | None = None,
) -> HistoricalReleaseResourcesV1:
    """Load fixed profiling-v1 ancestry without current-v2 re-resolution."""

    root = (
        Path(__file__).resolve().parents[3]
        if repository_root is None
        else Path(repository_root).resolve(strict=True)
    )
    workload_raw, workload = _read_fixed_historical_json(
        root,
        relative_path=_HISTORICAL_WORKLOAD_PATH_V1,
        expected_sha256=HISTORICAL_WORKLOAD_RESOURCE_SHA256_V1,
        label="historical workload resource",
    )
    submission_raw, submission = _read_fixed_historical_json(
        root,
        relative_path=_HISTORICAL_SUBMISSION_PATH_V1,
        expected_sha256=HISTORICAL_SUBMISSION_RESOURCE_SHA256_V1,
        label="historical submission resource",
    )
    result_schema_raw, result_schema = _read_fixed_historical_json(
        root,
        relative_path=_HISTORICAL_RESULT_SCHEMA_PATH_V1,
        expected_sha256=HISTORICAL_RESULT_SCHEMA_SHA256_V1,
        label="historical result schema resource",
    )
    source_manifest_raw, source_manifest = _read_fixed_historical_json(
        root,
        relative_path=_HISTORICAL_BENCHMARK_SOURCE_MANIFEST_PATH_V1,
        expected_sha256=HISTORICAL_SOURCE_MANIFEST_SHA256_V1,
        label="historical source manifest resource",
    )
    calibration_path = root.joinpath(
        *_safe_repository_path(_HISTORICAL_CALIBRATION_PATH_V1).parts
    )
    _record, calibration_sha256 = load_reviewed_calibration_record(
        calibration_path
    )
    if calibration_sha256 != HISTORICAL_CALIBRATION_RECORD_SHA256_V1:
        raise ValueError("historical calibration authority is invalid")

    if type(workload) is not dict or set(workload) != {
        "aggregate_resource_digest",
        "presets",
        "release",
        "release_status",
        "resource_schema_version",
        "source",
        "source_authority",
        "submission_authority",
    }:
        raise ValueError("historical workload resource has an invalid shape")
    if type(submission) is not dict or set(submission) != {
        "release",
        "release_status",
        "resolved_workload",
        "resource_schema_version",
        "rl_destination_views",
        "source",
    }:
        raise ValueError("historical submission resource has an invalid shape")
    if type(result_schema) is not dict or set(result_schema) != {
        "$schema",
        "$id",
        "title",
        "type",
        "additionalProperties",
        "required",
        "properties",
        "$defs",
    }:
        raise ValueError("historical result schema has an invalid shape")
    if (
        type(source_manifest) is not dict
        or set(source_manifest) != {"schema_version", "files"}
    ):
        raise ValueError("historical source manifest has an invalid shape")
    if (
        workload["resource_schema_version"]
        != "dreamgym-autonomous-driving-workload-resource-v1"
        or workload["release_status"]
        != {
            "classification": "canonical",
            "canonical_status": True,
            "submission_status": False,
        }
        or workload["source"]
        != {"kind": "release", "presets": ["quick", "medium", "long"]}
        or type(workload["source_authority"]) is not list
        or tuple(workload["source_authority"])
        != HISTORICAL_WORKLOAD_SOURCE_AUTHORITY_V1
        or type(workload["presets"]) is not dict
        or set(workload["presets"]) != {"quick", "medium", "long"}
    ):
        raise ValueError("historical workload release authority is invalid")
    expected_release = {
        "identifiers": {
            "workload_release_id": HISTORICAL_WORKLOAD_RELEASE_ID_V1,
            "submission_release_id": HISTORICAL_SUBMISSION_RELEASE_ID_V1,
            "result_schema_release_id": RESULT_SCHEMA_RELEASE_ID,
            "timing_protocol_release_id": TIMING_PROTOCOL_RELEASE_ID,
        },
        "candidate": dict(APPROVED_CANDIDATE_AUTHORITY_V1),
        "calibration_record_sha256": HISTORICAL_CALIBRATION_RECORD_SHA256_V1,
    }
    if workload["release"] != expected_release:
        raise ValueError("historical workload release envelope is invalid")
    for preset in ("quick", "medium", "long"):
        snapshot = workload["presets"][preset]
        _validate_lineage_comparison_input(preset, snapshot)
        expected_cases, expected_rl, expected_views = _LINEAGE_COUNTS[preset]
        semantic_cases = snapshot["resolved_workload"]["cases"]
        resolver_cases = sum(
            "resolver_version"
            in item["case_spec"]["semantic_document"].get(
                "production_versions", {}
            )
            for item in semantic_cases
        )
        if (
            len(semantic_cases) != expected_cases
            or resolver_cases != expected_rl
            or len(snapshot["rl_destination_views"]) != expected_views
        ):
            raise ValueError("historical preset population is invalid")
    submission_input = _historical_submission_comparison_input(
        workload,
        submission,
    )
    _validate_lineage_comparison_input("submission", submission_input)
    if (
        submission["resource_schema_version"]
        != "dreamgym-autonomous-driving-workload-resource-v1"
        or submission["release_status"]
        != {
            "classification": "locked_submission",
            "canonical_status": True,
            "submission_status": True,
        }
        or submission["source"] != {"kind": "submission_release"}
        or submission["release"]
        != {
            "workload_release_id": HISTORICAL_SUBMISSION_RELEASE_ID_V1,
            "result_schema_release_id": RESULT_SCHEMA_RELEASE_ID,
            "timing_protocol_release_id": TIMING_PROTOCOL_RELEASE_ID,
            "candidate_resource_sha256": APPROVED_CANDIDATE_SHA256,
            "calibration_record_sha256": HISTORICAL_CALIBRATION_RECORD_SHA256_V1,
        }
        or len(submission["resolved_workload"]["cases"]) != 4
        or len(submission["rl_destination_views"]) != 2
    ):
        raise ValueError("historical submission release authority is invalid")
    submission_authority = workload["submission_authority"]
    if (
        type(submission_authority) is not dict
        or set(submission_authority)
        != {
            "metric_definitions",
            "resource_name",
            "resource_sha256",
            "workload_digest",
        }
        or submission_authority["resource_name"]
        != "submission_workload_v1.json"
        or submission_authority["resource_sha256"]
        != HISTORICAL_SUBMISSION_RESOURCE_SHA256_V1
        or submission_authority["workload_digest"]
        != submission["resolved_workload"]["workload_digest"]
    ):
        raise ValueError("historical submission cross-reference is invalid")
    from dreamgym.profiling.autonomous_driving.records import canonical_json_digest

    if workload["aggregate_resource_digest"] != canonical_json_digest({
        key: value
        for key, value in workload.items()
        if key != "aggregate_resource_digest"
    }):
        raise ValueError("historical aggregate resource digest is invalid")
    # Reuse the separately raw-hashed archive validator for its literal 85-path
    # path/digest contract.  It never reads current working-tree source bytes.
    load_historical_benchmark_source_release_authority_v1(
        repository_root=root,
        manifest=source_manifest,
    )
    return HistoricalReleaseResourcesV1(
        _workload_bytes=workload_raw,
        _submission_bytes=submission_raw,
        _result_schema_bytes=result_schema_raw,
        _source_manifest_bytes=source_manifest_raw,
    )


def _approved_calibration_record() -> dict[str, Any]:
    accepted = (
        (
            "quick-01-r4",
            "quick",
            "55bf20bad0f248d7b86b65986bc24079",
            1948.726,
            "a009683c1aaa5c9da56bb04a3205347f3e1ff95d38ff16283f9317f4b8bb5575",
            "4e438c1e3ef1f706dc47fd0fb8db0053bcc2cdf114d41fa969fe4eee431ea15c",
        ),
        (
            "quick-02",
            "quick",
            "b2085bca4d794736b6569e4923e410cb",
            1934.343,
            "60815424d90e2d31e71f90281cd804be9fdf607cc7f8de57930ed27a97753c7e",
            "deaa3d428d71d63bdd0b20bbb4b6677df0a351e4d3709eb4358a9e98160258f8",
        ),
        (
            "quick-03",
            "quick",
            "57363bf6b43247c8a59ca2063789d719",
            1938.998,
            "1a5a48f806c23f91defcb7ee908f5b8b6d8e2fac7b91ea16a9aa7580b9a90a98",
            "c0a15334ffe7b4323caf76618b197c31245309d2dd8dd0d945ec3fd60c3f3019",
        ),
        (
            "medium-01",
            "medium",
            "9f88fe01dae54b98be232ce5b9a19b5a",
            3317.226,
            "7ab9ae5ebb6b178614cf20178ba83e8451032f181f0a115935403a926d090e76",
            "c484955462a31f39e3fa0d1eb9eeef2d4cc6de7a6341a0a60a4733d0f067222f",
        ),
        (
            "medium-02",
            "medium",
            "3aa5ca0af0084362ab6f58992d0bcf3d",
            2303.016,
            "fb7e5f9becb75f2ec98d854acad79badaf1120f863f712bd143b37947a404779",
            "e3a36b75f55ed4fb94929b92b0716772b9d83d81eeeb14a907ba58e941e918f4",
        ),
        (
            "medium-03",
            "medium",
            "b0de0ee4180b46cdb4c99468d466383f",
            2312.545,
            "33b3ccade9c7f3d690fba46cea465696de271b2748c45fc0267b0099064c33f7",
            "3aa21aa031093481a873d4b53d1e3786e96036fd77b9f8fa3e3ab184e2bb0bd2",
        ),
        (
            "long-01-r2",
            "long",
            "41581ecf25744e21a65f8241b02b01b5",
            13537.097,
            "c00ebeb40919e91610c272fcdc375decbff661ad8060375a879d338c651d14aa",
            "4b4d9be993c385cce9525e4b43d104f0e0be6aa0c9637e77160be223f7a531d6",
        ),
        (
            "long-02",
            "long",
            "1e4fcbfda1eb489489407c59806a39e5",
            12132.653,
            "328fdd725edaf079df37997374ff6a3124940fdb90c6734970a65106846eee69",
            "9de146b1388ec47a0d5fac98d462cb1f1c90226d98fdd4fab00d0a998852890d",
        ),
    )
    rejected = (
        (
            "quick-01",
            "ea9c2acb9e6441349c51801bf511109c",
            "sandbox_execution_failure",
        ),
        (
            "quick-01-r2",
            "75f76eb362564fb4a375c7a3a2f1e666",
            "incomplete_rl_terminal_failure",
        ),
        (
            "quick-01-r3",
            "462c91bfc7124e6ebe45931f235b94e5",
            "result_persistence_failure",
        ),
        (
            "long-01",
            "24e699840663454097118bc05bb96d76",
            "deliberate_interruption",
        ),
    )
    return {
        "schema_version": "dreamgym-calibration-review-v1",
        "decision": "approved",
        "review_status": "GO",
        "release": {
            "workload_release_id": HISTORICAL_WORKLOAD_RELEASE_ID_V1,
            "submission_release_id": HISTORICAL_SUBMISSION_RELEASE_ID_V1,
            "result_schema_release_id": RESULT_SCHEMA_RELEASE_ID,
            "timing_protocol_release_id": TIMING_PROTOCOL_RELEASE_ID,
        },
        "candidate": dict(APPROVED_CANDIDATE_AUTHORITY_V1),
        "accepted_bundles": [
            {
                "attempt": attempt,
                "preset": preset,
                "bundle_id": bundle_id,
                "duration_s": duration_s,
                "manifest_sha256": manifest_sha256,
                "results_sha256": results_sha256,
            }
            for (
                attempt,
                preset,
                bundle_id,
                duration_s,
                manifest_sha256,
                results_sha256,
            ) in accepted
        ],
        "median_duration_s": {
            "quick": 1938.998,
            "medium": 2312.545,
            "long": 12834.875,
        },
        "rejected_diagnostics": [
            {
                "attempt": attempt,
                "bundle_id": bundle_id,
                "reason": reason,
            }
            for attempt, bundle_id, reason in rejected
        ],
        "validation": {
            "accepted_bundle_count": 8,
            "all_required_cases_completed": True,
            "zero_warnings_errors_fatal_nonfinite": True,
            "strict_loader_schema_privacy_checksums": True,
            "source_snapshot_integrity": True,
            "canonical_rl_cpu": True,
            "rl_minimum_complete_windows_met": True,
            "mpc_all_required_invocations_usable": True,
            "all_review_triggers_investigated": True,
            "independent_final_audits": 3,
        },
    }


def load_reviewed_calibration_record(
    calibration_path: str | Path,
) -> tuple[dict[str, Any], str]:
    """Load only the exact human-approved calibration record."""

    path = Path(calibration_path).resolve(strict=True)
    if not path.is_file():
        raise ValueError("approved calibration evidence must be a file")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
        HISTORICAL_CALIBRATION_RECORD_SHA256_V1
    ):
        raise ValueError(
            "approved calibration evidence does not match its fixed raw SHA-256"
        )
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(
            "approved calibration evidence must be UTF-8"
        ) from error
    start_marker = "```json dreamgym-calibration-record-v1\n"
    end_marker = "\n```"
    if text.count(start_marker) != 1:
        raise ValueError(
            "approved calibration record marker is not exact"
        )
    payload = text.split(start_marker, 1)[1]
    if end_marker not in payload:
        raise ValueError(
            "approved calibration record is incomplete"
        )
    encoded, _suffix = payload.split(end_marker, 1)
    try:
        record = json.loads(encoded)
    except json.JSONDecodeError as error:
        raise ValueError(
            "approved calibration record is not valid JSON"
        ) from error
    if record != _approved_calibration_record():
        raise ValueError(
            "approved calibration record does not match v1 authority"
        )
    return record, HISTORICAL_CALIBRATION_RECORD_SHA256_V1


def _resolver_projection_case(
    semantic_document: Mapping[str, Any],
) -> bool:
    versions = semantic_document.get("production_versions")
    has_resolver = (
        type(versions) is dict and "resolver_version" in versions
    )
    has_projection = (
        semantic_document.get("semantic_projection_version")
        == "dreamgym-rl-semantic-projection-v1"
    )
    if has_resolver != has_projection:
        raise ValueError(
            "resolver-bearing lineage cases require the exact RL projection marker"
        )
    return has_resolver


def _case_token(index: int, readable_prefix: str) -> tuple[str, str]:
    digest = f"<case-digest:{index}:{readable_prefix}>"
    return digest, readable_prefix + "-" + digest


def _project_lineage_comparison(
    name: str,
    predecessor: Mapping[str, Any],
    successor: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Apply only the six release-lineage substitutions to valid inputs."""

    if name not in _LINEAGE_COUNTS:
        raise ValueError("lineage comparison name is not supported")
    predecessor_document = copy.deepcopy(dict(predecessor))
    successor_document = copy.deepcopy(dict(successor))
    predecessor_index = _validate_lineage_comparison_input(
        name,
        predecessor_document,
    )
    successor_index = _validate_lineage_comparison_input(
        name,
        successor_document,
    )
    predecessor_cases = predecessor_document["resolved_workload"]["cases"]
    successor_cases = successor_document["resolved_workload"]["cases"]
    predecessor_views = predecessor_document["rl_destination_views"]
    successor_views = successor_document["rl_destination_views"]
    expected_cases, expected_rl, expected_views = _LINEAGE_COUNTS[name]
    if (
        len(predecessor_cases) != expected_cases
        or len(successor_cases) != expected_cases
        or len(predecessor_views) != expected_views
        or len(successor_views) != expected_views
    ):
        raise ValueError("lineage population count is not exact")

    prefixes: set[str] = set()
    resolver_case_count = 0
    predecessor_case_locations = {
        case["case_spec"]["semantic_case_id"]: index
        for index, case in enumerate(predecessor_cases)
    }
    successor_case_locations = {
        case["case_spec"]["semantic_case_id"]: index
        for index, case in enumerate(successor_cases)
    }

    # Transform 1: release workload identity only.
    predecessor_document["resolved_workload"]["workload_version"] = (
        "<workload-version>"
    )
    successor_document["resolved_workload"]["workload_version"] = (
        "<workload-version>"
    )

    for index, (predecessor_item, successor_item) in enumerate(
        zip(predecessor_cases, successor_cases, strict=True)
    ):
        predecessor_case = predecessor_item["case_spec"]
        successor_case = successor_item["case_spec"]
        predecessor_semantic = predecessor_case["semantic_document"]
        successor_semantic = successor_case["semantic_document"]
        readable_prefix = predecessor_case["readable_prefix"]
        if (
            type(readable_prefix) is not str
            or not readable_prefix
            or readable_prefix in prefixes
            or successor_case["readable_prefix"] != readable_prefix
        ):
            raise ValueError("lineage case prefixes are not exact and unique")
        prefixes.add(readable_prefix)
        predecessor_has_suite = "suite" in predecessor_semantic
        successor_has_suite = "suite" in successor_semantic
        if (
            predecessor_has_suite != successor_has_suite
            or predecessor_semantic.get("suite")
            != successor_semantic.get("suite")
        ):
            raise ValueError("lineage case suite identity changed")
        predecessor_is_rl = _resolver_projection_case(predecessor_semantic)
        successor_is_rl = _resolver_projection_case(successor_semantic)
        if predecessor_is_rl != successor_is_rl:
            raise ValueError("lineage resolver-bearing case pairing changed")
        if not predecessor_is_rl:
            continue
        resolver_case_count += 1
        predecessor_versions = predecessor_semantic["production_versions"]
        successor_versions = successor_semantic["production_versions"]
        if (
            predecessor_versions["resolver_version"]
            != "dreamgym-training-resolver-v1"
            or successor_versions["resolver_version"]
            != "dreamgym-training-resolver-v2"
        ):
            raise ValueError("lineage resolver transition is not exact")
        # Transform 2: the exact resolver marker.
        predecessor_versions["resolver_version"] = "<resolver-version>"
        successor_versions["resolver_version"] = "<resolver-version>"
        # Transform 3: only resolver-dependent case identities.
        digest_token, case_id_token = _case_token(index, readable_prefix)
        for item in (predecessor_item, successor_item):
            item["case_spec"]["semantic_case_digest"] = digest_token
            item["case_spec"]["semantic_case_id"] = case_id_token
            item["execution_spec"]["semantic_case_id"] = case_id_token
    if resolver_case_count != expected_rl:
        raise ValueError("lineage resolver-bearing case count is not exact")

    # Transform 4: the derived ordered workload digest.
    predecessor_document["resolved_workload"]["workload_digest"] = (
        "<workload-digest>"
    )
    successor_document["resolved_workload"]["workload_digest"] = (
        "<workload-digest>"
    )

    predecessor_view_identities: set[str] = set()
    successor_view_identities: set[str] = set()
    for predecessor_view, successor_view in zip(
        predecessor_views,
        successor_views,
        strict=True,
    ):
        readable_identity = predecessor_view["readable_identity"]
        if (
            type(readable_identity) is not str
            or not readable_identity
            or readable_identity in predecessor_view_identities
            or successor_view["readable_identity"] != readable_identity
            or successor_view["readable_identity"]
            in successor_view_identities
        ):
            raise ValueError(
                "lineage destination identities are not exact and unique"
            )
        predecessor_view_identities.add(readable_identity)
        successor_view_identities.add(successor_view["readable_identity"])
        predecessor_selected = predecessor_view["selected_source_case_id"]
        successor_selected = successor_view["selected_source_case_id"]
        predecessor_location = predecessor_case_locations.get(
            predecessor_selected
        )
        successor_location = successor_case_locations.get(successor_selected)
        if (
            predecessor_location is None
            or successor_location is None
            or predecessor_location != successor_location
        ):
            raise ValueError("lineage destination selection changed")
        predecessor_prefix = predecessor_index[predecessor_selected][0][
            "readable_prefix"
        ]
        successor_prefix = successor_index[successor_selected][0][
            "readable_prefix"
        ]
        if predecessor_prefix != successor_prefix:
            raise ValueError("lineage destination selected prefix changed")
        # Transform 5: only the selected logical case and its semantic digest.
        digest_token, case_id_token = _case_token(
            predecessor_location,
            predecessor_prefix,
        )
        for view in (predecessor_view, successor_view):
            view["selected_source_case_id"] = case_id_token
            view["semantic_case_digest"] = digest_token

    # Transform 6: only RL submission metric case identities.
    if name == "submission":
        for side, indexed, locations in (
            (
                predecessor_document,
                predecessor_index,
                predecessor_case_locations,
            ),
            (
                successor_document,
                successor_index,
                successor_case_locations,
            ),
        ):
            for metric in side["metric_definitions"]:
                if metric["suite"] != "rl":
                    continue
                case_id = metric["case_id"]
                location = locations.get(case_id)
                if location is None:
                    raise ValueError("RL metric selects an unknown case")
                case = indexed[case_id][0]
                digest_token, case_id_token = _case_token(
                    location,
                    case["readable_prefix"],
                )
                # Keep the digest token construction explicit even though the
                # metric stores only the logical case identifier.
                if not digest_token:
                    raise AssertionError("unreachable empty digest token")
                metric["case_id"] = case_id_token

    from dreamgym.profiling.autonomous_driving.records import canonical_json_bytes

    if canonical_json_bytes(predecessor_document) != canonical_json_bytes(
        successor_document
    ):
        raise ValueError("lineage comparison contains a non-permitted difference")
    return predecessor_document, successor_document


def build_release_lineage_evidence(
    *,
    repository_root: str | Path | None = None,
) -> dict[str, Any]:
    """Reject historical lineage rebuilding until archival tooling owns it."""

    del repository_root
    raise RuntimeError(
        "historical v2 release validation is disabled pending B1"
    )


def _validate_candidate_authority_shape(
    authority: Mapping[str, Any],
    *,
    allow_unfilled: bool,
) -> dict[str, Any]:
    if type(authority) not in {dict, MappingProxyType} or set(authority) != {
        "resource_sha256",
        "aggregate_resource_digest",
        "preset_workload_digests",
        "submission_resource_sha256",
        "submission_workload_digest",
    }:
        raise ValueError("v2 release candidate authority has an invalid shape")
    presets = authority["preset_workload_digests"]
    if type(presets) is not dict or set(presets) != {
        "quick",
        "medium",
        "long",
    }:
        raise ValueError("v2 release candidate preset authority is invalid")
    values = [
        authority["resource_sha256"],
        authority["aggregate_resource_digest"],
        *presets.values(),
        authority["submission_resource_sha256"],
        authority["submission_workload_digest"],
    ]
    if allow_unfilled and all(value is None for value in values):
        return {
            key: (
                dict(value) if key == "preset_workload_digests" else value
            )
            for key, value in authority.items()
        }
    if not all(_is_sha256(value) for value in values):
        raise ValueError("v2 release candidate authority is not approved")
    return {
        key: (
            dict(value) if key == "preset_workload_digests" else value
        )
        for key, value in authority.items()
    }


def _build_v2_release_envelopes(
    *,
    candidate_authority: Mapping[str, Any],
    calibration_record_sha256: str,
    lineage_evidence: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Reject historical envelope rebuilding until archival tooling owns it."""

    del candidate_authority, calibration_record_sha256, lineage_evidence
    raise RuntimeError(
        "historical v2 release validation is disabled pending B1"
    )


def _resource_json_bytes(document: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            dict(document),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _safe_source_bytes(root: Path, relative: str) -> bytes:
    canonical = _safe_repository_path(relative)
    path = root.joinpath(*canonical.parts)
    resolved = path.resolve(strict=True)
    try:
        resolved.relative_to(root)
    except ValueError as error:
        raise ValueError(
            "benchmark source resolves outside repository"
        ) from error
    parent = path.parent
    while parent != root:
        if parent.is_symlink():
            raise ValueError(
                "benchmark source parent uses filesystem indirection"
            )
        parent = parent.parent
    if not path.is_file() or path.is_symlink():
        raise ValueError(
            "benchmark source must be a regular non-symlink file"
        )
    return path.read_bytes()


def build_benchmark_source_manifest(
    repository_root: str | Path,
    *,
    source_paths: Sequence[str] = BENCHMARK_SOURCE_PATHS_V3,
    content_overrides: Mapping[str, bytes] | None = None,
) -> dict[str, Any]:
    """Hash the exact reviewed final source boundary deterministically."""

    root = Path(repository_root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("repository_root must be a directory")
    paths = validate_benchmark_source_paths(source_paths)
    overrides = dict(content_overrides or {})
    if set(overrides) - set(paths):
        raise ValueError("benchmark source override is outside authority")
    if any(type(value) is not bytes for value in overrides.values()):
        raise TypeError("benchmark source override content must be bytes")
    files: dict[str, str] = {}
    resolved_keys: set[str] = set()
    for relative in paths:
        if relative in overrides:
            content = overrides[relative]
            key = relative.casefold()
        else:
            path = root.joinpath(
                *_safe_repository_path(relative).parts
            )
            content = _safe_source_bytes(root, relative)
            key = str(path.resolve(strict=True)).casefold()
        if key in resolved_keys:
            raise ValueError(
                "benchmark sources do not resolve uniquely"
            )
        resolved_keys.add(key)
        files[relative] = hashlib.sha256(content).hexdigest()
    return {
        "schema_version": BENCHMARK_SOURCE_MANIFEST_SCHEMA_VERSION,
        "files": files,
    }


def build_release_artifacts(
    *,
    repository_root: str | Path,
    candidate_path: str | Path,
    calibration_path: str | Path,
) -> dict[str, bytes]:
    """Reject the retired unversioned v2 release builder."""

    del repository_root, candidate_path, calibration_path
    raise RuntimeError("legacy v2 profiling mutation is disabled")


def write_release_artifacts(
    *,
    repository_root: str | Path,
    artifacts: Mapping[str, bytes],
    candidate_path: str | Path,
) -> tuple[Path, ...]:
    """Reject the retired unversioned v2 release writer."""

    del repository_root, artifacts, candidate_path
    raise RuntimeError("legacy v2 profiling mutation is disabled")
