"""Immutable, portable records used by unified autonomous-driving profiling."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
import sys
from typing import Any

PROFILE_RESULTS_SCHEMA_VERSION = "dreamgym-profile-results-v1"


class CaseMeasurementError(RuntimeError):
    """Stable diagnostic type for a non-exception measurement failure."""


def exception_class_identity(error: Any) -> tuple[str, str]:
    """Return available class identity fields without trusting a metaclass."""

    module = ""
    name = ""
    try:
        error_class = type(error)
        try:
            candidate_module = error_class.__module__
        except BaseException:
            pass
        else:
            if type(candidate_module) is str and candidate_module:
                module = candidate_module
        try:
            candidate_name = error_class.__name__
        except BaseException:
            pass
        else:
            if type(candidate_name) is str and candidate_name:
                name = candidate_name
    except BaseException:
        pass
    return module, name


_BENCHMARK_MODULE_SOURCE_PATHS_V1 = (
    "dreamgym/__init__.py",
    "dreamgym/envs/__init__.py",
    "dreamgym/envs/_render_config.py",
    "dreamgym/envs/_render_overlay.py",
    "dreamgym/envs/autonomous_driving_env.py",
    "dreamgym/envs/bicycle_model_dynamic.py",
    "dreamgym/envs/config_validation.py",
    "dreamgym/envs/observation_specs.py",
    "dreamgym/envs/road.py",
    "dreamgym/envs/road_core/__init__.py",
    "dreamgym/envs/road_core/cones.py",
    "dreamgym/envs/road_core/constants.py",
    "dreamgym/envs/road_core/horizon_samples.py",
    "dreamgym/envs/road_core/lane_geometry.py",
    "dreamgym/envs/road_core/observations.py",
    "dreamgym/envs/road_core/random_generation.py",
    "dreamgym/envs/road_core/reference_geometry.py",
    "dreamgym/envs/road_core/schema.py",
    "dreamgym/envs/road_core/schema_utils.py",
    "dreamgym/envs/road_core/speeds.py",
    "dreamgym/envs/road_core/target_arc_length.py",
    "dreamgym/envs/road_core/target_geometry.py",
    "dreamgym/envs/road_core/target_offsets.py",
    "dreamgym/envs/road_core/target_samples.py",
    "dreamgym/envs/road_core/utils.py",
    "dreamgym/envs/road_preview.py",
    "dreamgym/policies/__init__.py",
    "dreamgym/policies/autonomous_driving/__init__.py",
    "dreamgym/policies/autonomous_driving/_mpc_adapter.py",
    "dreamgym/policies/autonomous_driving/_mpc_control.py",
    "dreamgym/policies/autonomous_driving/_mpc_failures.py",
    "dreamgym/policies/autonomous_driving/_mpc_formulations.py",
    "dreamgym/policies/autonomous_driving/_mpc_policy_base.py",
    "dreamgym/policies/autonomous_driving/_mpc_rollout.py",
    "dreamgym/policies/autonomous_driving/mpc.py",
    "dreamgym/policies/autonomous_driving/mpc_config.py",
    "dreamgym/policies/autonomous_driving/mpc_results.py",
    "dreamgym/policies/autonomous_driving/pid.py",
    "dreamgym/policies/autonomous_driving/rl.py",
    "dreamgym/policies/mpc/__init__.py",
    "dreamgym/policies/mpc/_diagnostics.py",
    "dreamgym/policies/mpc/_formulation.py",
    "dreamgym/policies/mpc/config.py",
    "dreamgym/policies/mpc/problem.py",
    "dreamgym/policies/mpc/results.py",
    "dreamgym/policies/mpc/solver.py",
    "dreamgym/profiling/__init__.py",
    "dreamgym/profiling/autonomous_driving/__init__.py",
    "dreamgym/profiling/autonomous_driving/bundle.py",
    "dreamgym/profiling/autonomous_driving/core_suites.py",
    "dreamgym/profiling/autonomous_driving/environment.py",
    "dreamgym/profiling/autonomous_driving/gym_step.py",
    "dreamgym/profiling/autonomous_driving/machine.py",
    "dreamgym/profiling/autonomous_driving/measurement.py",
    "dreamgym/profiling/autonomous_driving/metadata.py",
    "dreamgym/profiling/autonomous_driving/mpc.py",
    "dreamgym/profiling/autonomous_driving/notebook.py",
    "dreamgym/profiling/autonomous_driving/privacy.py",
    "dreamgym/profiling/autonomous_driving/production_rl.py",
    "dreamgym/profiling/autonomous_driving/records.py",
    "dreamgym/profiling/autonomous_driving/release.py",
    "dreamgym/profiling/autonomous_driving/reporting.py",
    "dreamgym/profiling/autonomous_driving/resources/__init__.py",
    "dreamgym/profiling/autonomous_driving/rl_worker.py",
    "dreamgym/profiling/autonomous_driving/road.py",
    "dreamgym/profiling/autonomous_driving/runner.py",
    "dreamgym/profiling/autonomous_driving/workloads.py",
    "dreamgym/profiling/common.py",
    "dreamgym/training/__init__.py",
    "dreamgym/training/autonomous_driving/__init__.py",
    "dreamgym/training/autonomous_driving/algorithm_profiles.py",
    "dreamgym/training/autonomous_driving/config_validation.py",
    "dreamgym/training/autonomous_driving/configs.py",
    "dreamgym/training/autonomous_driving/envs.py",
    "dreamgym/training/autonomous_driving/model_discovery.py",
    "dreamgym/training/autonomous_driving/models.py",
    "dreamgym/training/autonomous_driving/resolution.py",
    "dreamgym/training/autonomous_driving/rewards.py",
    "dreamgym/training/autonomous_driving/seeds.py",
    "dreamgym/training/autonomous_driving/snapshots.py",
)


def _module_name_for_source_path(source_path: str) -> str:
    parts = source_path.split("/")
    if parts[-1] == "__init__.py":
        parts = parts[:-1]
    else:
        parts[-1] = parts[-1][:-3]
    return ".".join(parts)


BENCHMARK_MODULE_ORIGINS_V1 = MappingProxyType({
    _module_name_for_source_path(source_path): source_path
    for source_path in _BENCHMARK_MODULE_SOURCE_PATHS_V1
})

_BENCHMARK_MODULE_SOURCE_PATHS_V3 = tuple(sorted((
    *_BENCHMARK_MODULE_SOURCE_PATHS_V1,
    "dreamgym/envs/road_core/_target_config.py",
)))

BENCHMARK_MODULE_ORIGINS_V3 = MappingProxyType({
    _module_name_for_source_path(source_path): source_path
    for source_path in _BENCHMARK_MODULE_SOURCE_PATHS_V3
})

SPAWNED_RL_WORKER_REQUIRED_MODULES_V1 = (
    "dreamgym",
    "dreamgym.envs",
    "dreamgym.envs._render_config",
    "dreamgym.envs._render_overlay",
    "dreamgym.envs.autonomous_driving_env",
    "dreamgym.envs.bicycle_model_dynamic",
    "dreamgym.envs.config_validation",
    "dreamgym.envs.observation_specs",
    "dreamgym.envs.road",
    "dreamgym.envs.road_core",
    "dreamgym.envs.road_core.cones",
    "dreamgym.envs.road_core.constants",
    "dreamgym.envs.road_core.horizon_samples",
    "dreamgym.envs.road_core.lane_geometry",
    "dreamgym.envs.road_core.observations",
    "dreamgym.envs.road_core.random_generation",
    "dreamgym.envs.road_core.reference_geometry",
    "dreamgym.envs.road_core.schema",
    "dreamgym.envs.road_core.schema_utils",
    "dreamgym.envs.road_core.speeds",
    "dreamgym.envs.road_core.target_arc_length",
    "dreamgym.envs.road_core.target_geometry",
    "dreamgym.envs.road_core.target_offsets",
    "dreamgym.envs.road_core.target_samples",
    "dreamgym.envs.road_core.utils",
    "dreamgym.envs.road_preview",
    "dreamgym.profiling",
    "dreamgym.profiling.autonomous_driving",
    "dreamgym.profiling.autonomous_driving.production_rl",
    "dreamgym.profiling.autonomous_driving.records",
    "dreamgym.profiling.autonomous_driving.rl_worker",
    "dreamgym.training",
    "dreamgym.training.autonomous_driving",
    "dreamgym.training.autonomous_driving.algorithm_profiles",
    "dreamgym.training.autonomous_driving.config_validation",
    "dreamgym.training.autonomous_driving.configs",
    "dreamgym.training.autonomous_driving.envs",
    "dreamgym.training.autonomous_driving.model_discovery",
    "dreamgym.training.autonomous_driving.models",
    "dreamgym.training.autonomous_driving.resolution",
    "dreamgym.training.autonomous_driving.rewards",
    "dreamgym.training.autonomous_driving.seeds",
    "dreamgym.training.autonomous_driving.snapshots",
)

SPAWNED_RL_WORKER_REQUIRED_MODULES_V2 = tuple(sorted((
    *(
        module_name
        for module_name in SPAWNED_RL_WORKER_REQUIRED_MODULES_V1
        if module_name
        != "dreamgym.training.autonomous_driving.model_discovery"
    ),
    "dreamgym.envs.road_core._target_config",
)))


def _path_uses_filesystem_indirection(path: Path) -> bool:
    """Return whether *path* is a symlink or Windows reparse point."""

    if path.is_symlink():
        return True
    try:
        attributes = getattr(path.lstat(), "st_file_attributes", 0)
    except FileNotFoundError:
        return False
    return bool(attributes & 0x400)


def collect_loaded_benchmark_module_origins() -> dict[str, str]:
    """Collect both loader-reported origins for every loaded Dream Gym module."""

    origins: dict[str, str] = {}
    for module_name, module in sorted(sys.modules.items()):
        if not (
            module_name == "dreamgym"
            or module_name.startswith("dreamgym.")
        ):
            continue
        file_origin = getattr(module, "__file__", None)
        spec = getattr(module, "__spec__", None)
        spec_origin = getattr(spec, "origin", None)
        if (
            type(file_origin) is not str
            or not file_origin
            or type(spec_origin) is not str
            or not spec_origin
        ):
            raise ValueError(
                "loaded Dream Gym module has no exact source origin: "
                + module_name
            )
        if file_origin != spec_origin:
            raise ValueError(
                "loaded Dream Gym module loader origins disagree: "
                + module_name
            )
        try:
            file_path = Path(file_origin).resolve(strict=True)
            spec_path = Path(spec_origin).resolve(strict=True)
        except OSError as error:
            raise ValueError(
                "loaded Dream Gym module origin does not exist: "
                + module_name
            ) from error
        if file_path != spec_path:
            raise ValueError(
                "loaded Dream Gym module loader origins disagree: "
                + module_name
            )
        origins[module_name] = file_origin
    return origins


def validate_benchmark_module_origins(
    repository_root: str | Path,
    module_origins: Mapping[str, str | Path],
    *,
    required_module_names: Sequence[str] = (),
    require_exact: bool = True,
) -> dict[str, str]:
    """Validate exact module names and paths against the current authority."""

    if not isinstance(module_origins, Mapping):
        raise TypeError("module_origins must be a mapping")
    if isinstance(required_module_names, (str, bytes)):
        raise TypeError("required_module_names must be a sequence")
    if type(require_exact) is not bool:
        raise TypeError("require_exact must be a bool")
    try:
        root = Path(repository_root).resolve(strict=True)
    except OSError as error:
        raise ValueError("repository_root does not exist") from error
    if not root.is_dir():
        raise ValueError("repository_root must be a directory")

    expected_names = set(BENCHMARK_MODULE_ORIGINS_V3)
    required = tuple(required_module_names)
    if (
        len(required) != len(set(required))
        or any(
            type(name) is not str or name not in expected_names
            for name in required
        )
    ):
        raise ValueError(
            "required module names are not an exact authority subset"
        )
    supplied_names = set(module_origins)
    if any(type(name) is not str for name in module_origins):
        raise ValueError("module origin names must be text")
    if require_exact:
        if supplied_names != expected_names:
            raise ValueError(
                "module origins must equal the exact 81-module authority"
            )
    elif (
        not supplied_names <= expected_names
        or not set(required) <= supplied_names
    ):
        raise ValueError(
            "loaded module origins violate the required authority closure"
        )

    normalized: dict[str, str] = {}
    seen_paths: set[str] = set()
    checked_authority_paths: set[Path] = set()
    for module_name, expected_relative in (
        BENCHMARK_MODULE_ORIGINS_V3.items()
    ):
        if module_name not in supplied_names:
            continue
        origin = module_origins[module_name]
        if not isinstance(origin, (str, Path)):
            raise TypeError("module origins must be filesystem paths")
        supplied_path = Path(origin)
        expected_path = root.joinpath(
            *expected_relative.split("/")
        )
        if str(supplied_path) != str(expected_path):
            raise ValueError(
                "loaded module does not have its exact origin: "
                + module_name
            )
        current = root
        authority_chain = [root]
        for part in expected_path.relative_to(root).parts:
            current = current / part
            authority_chain.append(current)
        for authority_path in authority_chain:
            if authority_path in checked_authority_paths:
                continue
            checked_authority_paths.add(authority_path)
            if _path_uses_filesystem_indirection(authority_path):
                raise ValueError(
                    "loaded module origin traverses filesystem indirection: "
                    + module_name
                )
        try:
            resolved = supplied_path.resolve(strict=True)
            expected = expected_path.resolve(strict=True)
        except OSError as error:
            raise ValueError(
                "loaded module origin does not exist: " + module_name
            ) from error
        try:
            resolved.relative_to(root)
            expected.relative_to(root)
        except ValueError as error:
            raise ValueError(
                "loaded module origin resolves outside repository: "
                + module_name
            ) from error
        if (
            not resolved.is_file()
            or resolved != expected
        ):
            raise ValueError(
                "loaded module does not have its exact origin: "
                + module_name
            )
        path_key = str(resolved).casefold()
        if path_key in seen_paths:
            raise ValueError(
                "loaded module origins do not resolve uniquely"
            )
        seen_paths.add(path_key)
        normalized[module_name] = expected_relative
    return normalized


def _require_schema_version(schema_version: Any) -> None:
    if type(schema_version) is not str or not schema_version:
        raise ValueError("schema_version must be a non-empty string")


def _json_value(value: Any) -> Any:
    """Validate *value* and return a detached JSON-native representation."""

    if value is None or type(value) in (bool, str):
        return value
    if type(value) is int:
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError("JSON values must not contain NaN or infinity")
        return value
    if type(value) is dict:
        copied: dict[str, Any] = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError("JSON object keys must be strings")
            copied[key] = _json_value(item)
        return copied
    if type(value) is list:
        return [_json_value(item) for item in value]
    raise TypeError(f"value is not JSON-native: {type(value).__name__}")


def json_native(value: Any) -> Any:
    """Return a detached, strictly validated JSON-native value."""

    return _json_value(value)


def _freeze_json(value: Any) -> Any:
    value = _json_value(value)
    if type(value) is dict:
        return MappingProxyType({key: _freeze_json(item) for key, item in value.items()})
    if type(value) is list:
        return tuple(_freeze_json(item) for item in value)
    return value


def _thaw_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _thaw_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_json(item) for item in value]
    return value


def _frozen_json_value(value: Any) -> Any:
    """Convert trusted frozen record state to a JSON-native representation."""

    if type(value) is MappingProxyType:
        return {key: _frozen_json_value(item) for key, item in value.items()}
    if type(value) is tuple:
        return [_frozen_json_value(item) for item in value]
    if type(value) is dict:
        return {key: _frozen_json_value(item) for key, item in value.items()}
    if type(value) is list:
        return [_frozen_json_value(item) for item in value]
    return _json_value(value)


def _canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_json_bytes(value: Any) -> bytes:
    """Encode a strict JSON value using the canonical profiling representation."""

    return _canonical_json_bytes(_json_value(value))


def canonical_json_digest(value: Any) -> str:
    """Return the SHA-256 digest of :func:`canonical_json_bytes`."""

    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def _frozen_json_digest(value: Any) -> str:
    return hashlib.sha256(_canonical_json_bytes(_frozen_json_value(value))).hexdigest()


def semantic_case_id(readable_prefix: str, semantic_document: Any) -> str:
    """Build the stable, human-readable identity for a semantic benchmark case."""

    if type(readable_prefix) is not str or not readable_prefix:
        raise ValueError("readable_prefix must be a non-empty string")
    return f"{readable_prefix}-{canonical_json_digest(semantic_document)}"


def execution_spec_digest(execution_document: Any) -> str:
    """Return the independent digest for execution-only requirements."""

    return canonical_json_digest(execution_document)


def execution_instance_id(
    semantic_case_id: str,
    execution_digest: str,
) -> str:
    """Return the durable scheduler identity for one semantic/execution pair."""

    if type(semantic_case_id) is not str or not semantic_case_id:
        raise ValueError("semantic_case_id must be a non-empty string")
    if (
        type(execution_digest) is not str
        or len(execution_digest) != 64
        or any(character not in "0123456789abcdef" for character in execution_digest)
    ):
        raise ValueError("execution_digest must be a lowercase SHA-256 digest")
    return "execution-" + canonical_json_digest(
        {
            "semantic_case_id": semantic_case_id,
            "execution_spec_digest": execution_digest,
        }
    )


def ordered_workload_digest(case_pairs: Sequence[tuple[str, str]]) -> str:
    """Return a digest for an ordered sequence of case/execution identities."""

    ordered_pairs: list[dict[str, str]] = []
    for pair in case_pairs:
        if not isinstance(pair, tuple) or len(pair) != 2:
            raise TypeError("case_pairs must contain (semantic_case_id, execution_spec_digest) tuples")
        semantic_id, execution_digest = pair
        if type(semantic_id) is not str or type(execution_digest) is not str:
            raise TypeError("case pair identities must be strings")
        ordered_pairs.append(
            {
                "semantic_case_id": semantic_id,
                "execution_spec_digest": execution_digest,
            }
        )
    return canonical_json_digest(ordered_pairs)


@dataclass(frozen=True)
class CaseSpec:
    """Versioned semantic definition of one profiling case."""

    readable_prefix: str
    semantic_document: Mapping[str, Any]
    timing_protocol: Mapping[str, Any]
    schema_version: str = PROFILE_RESULTS_SCHEMA_VERSION
    timing_protocol_digest: str = field(init=False)
    semantic_case_digest: str = field(init=False)
    semantic_case_id: str = field(init=False)

    def __post_init__(self) -> None:
        if type(self.readable_prefix) is not str or not self.readable_prefix:
            raise ValueError("readable_prefix must be a non-empty string")
        _require_schema_version(self.schema_version)
        frozen_semantic = _freeze_json(self.semantic_document)
        frozen_protocol = _freeze_json(self.timing_protocol)
        if not isinstance(frozen_semantic, Mapping) or not isinstance(frozen_protocol, Mapping):
            raise TypeError("semantic_document and timing_protocol must be JSON objects")
        protocol_digest = _frozen_json_digest(frozen_protocol)
        digest_document = {
            "semantic_document": frozen_semantic,
            "timing_protocol_digest": protocol_digest,
        }
        semantic_digest = _frozen_json_digest(digest_document)
        object.__setattr__(self, "semantic_document", frozen_semantic)
        object.__setattr__(self, "timing_protocol", frozen_protocol)
        object.__setattr__(self, "timing_protocol_digest", protocol_digest)
        object.__setattr__(self, "semantic_case_digest", semantic_digest)
        object.__setattr__(
            self,
            "semantic_case_id",
            f"{self.readable_prefix}-{semantic_digest}",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "readable_prefix": self.readable_prefix,
            "semantic_document": _thaw_json(self.semantic_document),
            "timing_protocol": _thaw_json(self.timing_protocol),
            "timing_protocol_digest": self.timing_protocol_digest,
            "semantic_case_digest": self.semantic_case_digest,
            "semantic_case_id": self.semantic_case_id,
        }


@dataclass(frozen=True)
class ExecutionSpec:
    """Versioned execution requirements for one semantic profiling case."""

    semantic_case_id: str
    execution_document: Mapping[str, Any]
    schema_version: str = PROFILE_RESULTS_SCHEMA_VERSION
    execution_spec_digest: str = field(init=False)

    def __post_init__(self) -> None:
        if type(self.semantic_case_id) is not str or not self.semantic_case_id:
            raise ValueError("semantic_case_id must be a non-empty string")
        _require_schema_version(self.schema_version)
        frozen_document = _freeze_json(self.execution_document)
        if not isinstance(frozen_document, Mapping):
            raise TypeError("execution_document must be a JSON object")
        object.__setattr__(self, "execution_document", frozen_document)
        object.__setattr__(
            self,
            "execution_spec_digest",
            _frozen_json_digest(frozen_document),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "semantic_case_id": self.semantic_case_id,
            "execution_document": _thaw_json(self.execution_document),
            "execution_spec_digest": self.execution_spec_digest,
        }


@dataclass(frozen=True)
class CaseResult:
    """Completed or diagnostic measurement data for one profiling case."""

    case_id: str
    execution_spec_digest: str
    status: str
    sample_ns: Sequence[int]
    metrics: Mapping[str, Any]
    schema_version: str = PROFILE_RESULTS_SCHEMA_VERSION
    warnings: Sequence[str] = ()
    errors: Sequence[Mapping[str, Any]] = ()

    def __post_init__(self) -> None:
        from dreamgym.profiling.autonomous_driving.privacy import (
            validate_case_diagnostic,
            validate_case_warning,
        )

        if not all(type(value) is str and value for value in (self.case_id, self.execution_spec_digest, self.status)):
            raise ValueError("case_id, execution_spec_digest, and status must be non-empty strings")
        if self.status not in {"completed", "failed", "skipped", "interrupted"}:
            raise ValueError("status must be completed, failed, skipped, or interrupted")
        _require_schema_version(self.schema_version)
        samples = tuple(self.sample_ns)
        if any(type(value) is not int or value < 0 for value in samples):
            raise ValueError("sample_ns must contain non-negative integer nanoseconds")
        frozen_metrics = _freeze_json(self.metrics)
        if not isinstance(frozen_metrics, Mapping):
            raise TypeError("metrics must be a JSON object")
        if isinstance(self.warnings, (str, bytes)) or not isinstance(
            self.warnings,
            Sequence,
        ):
            raise TypeError("warnings must be an array")
        if isinstance(self.errors, (str, bytes)) or not isinstance(
            self.errors,
            Sequence,
        ):
            raise TypeError("errors must be an array")
        warnings = tuple(
            validate_case_warning(warning)
            for warning in self.warnings
        )
        errors = tuple(
            _freeze_json(
                validate_case_diagnostic(dict(error))
            )
            for error in self.errors
        )
        if self.status == "completed" and errors:
            raise ValueError("completed results must not contain errors")
        if self.status in {"failed", "interrupted"} and not errors:
            raise ValueError(
                "failed and interrupted results must contain an error"
            )
        if self.status == "skipped" and not warnings:
            raise ValueError("skipped results must contain a warning")
        object.__setattr__(self, "sample_ns", samples)
        object.__setattr__(self, "metrics", frozen_metrics)
        object.__setattr__(self, "warnings", warnings)
        object.__setattr__(self, "errors", errors)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "execution_spec_digest": self.execution_spec_digest,
            "status": self.status,
            "sample_ns": list(self.sample_ns),
            "sample_unit": "ns",
            "metrics": _thaw_json(self.metrics),
            "warnings": list(self.warnings),
            "errors": _thaw_json(self.errors),
        }


@dataclass(frozen=True)
class ProgressEvent:
    """In-memory progress notification emitted by a profiling executor."""

    case_id: str
    phase: str
    completed: int
    total: int
    schema_version: str = PROFILE_RESULTS_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if type(self.case_id) is not str or not self.case_id:
            raise ValueError("case_id must be a non-empty string")
        if type(self.phase) is not str or not self.phase:
            raise ValueError("phase must be a non-empty string")
        _require_schema_version(self.schema_version)
        if any(type(value) is not int or value < 0 for value in (self.completed, self.total)):
            raise ValueError("completed and total must be non-negative integers")
        if self.completed > self.total:
            raise ValueError("completed cannot exceed total")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "phase": self.phase,
            "completed": self.completed,
            "total": self.total,
        }


@dataclass(frozen=True)
class ResolvedWorkload:
    """An ordered immutable workload resolved before profiling begins."""

    workload_version: str
    cases: Sequence[tuple[CaseSpec, ExecutionSpec]]
    schema_version: str = PROFILE_RESULTS_SCHEMA_VERSION
    workload_digest: str = field(init=False)

    def __post_init__(self) -> None:
        if type(self.workload_version) is not str or not self.workload_version:
            raise ValueError("workload_version must be a non-empty string")
        _require_schema_version(self.schema_version)
        normalized_cases: list[tuple[CaseSpec, ExecutionSpec]] = []
        pairs: list[tuple[str, str]] = []
        for pair in self.cases:
            try:
                case, execution = pair
            except (TypeError, ValueError) as error:
                raise TypeError("cases must contain (CaseSpec, ExecutionSpec) pairs") from error
            if not isinstance(case, CaseSpec) or not isinstance(execution, ExecutionSpec):
                raise TypeError("cases must contain (CaseSpec, ExecutionSpec) pairs")
            if execution.semantic_case_id != case.semantic_case_id:
                raise ValueError("execution specification does not belong to its case")
            normalized_cases.append((case, execution))
            pairs.append((case.semantic_case_id, execution.execution_spec_digest))
        object.__setattr__(self, "cases", tuple(normalized_cases))
        object.__setattr__(
            self,
            "workload_digest",
            canonical_json_digest(
                {
                    "workload_version": self.workload_version,
                    "ordered_cases_digest": ordered_workload_digest(pairs),
                }
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "workload_version": self.workload_version,
            "workload_digest": self.workload_digest,
            "cases": [
                {
                    "case_spec": case.to_dict(),
                    "execution_spec": execution.to_dict(),
                }
                for case, execution in self.cases
            ],
        }
