"""Presentation-only calibration and sparse progress rendering.

The constants in this module are a versioned user-interface calibration
derived from the accepted v1 preset runs on the development machine.  They
are deliberately *not* timing-protocol, workload-identity, execution-
identity, benchmark pass/fail, or result-aggregation authority.  Profiling
never reads local calibration bundles at runtime.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import io
import time
from types import MappingProxyType
from typing import TextIO

from dreamgym.profiling.autonomous_driving.records import (
    CaseSpec,
    ExecutionSpec,
    ProgressEvent,
    execution_instance_id,
)
from dreamgym.profiling.autonomous_driving.workloads import (
    ResolvedProfileWorkload,
)


PROGRESS_CALIBRATION_VERSION = (
    "dreamgym-profile-progress-calibration-v1"
)

# Accepted v1 calibration-bundle evidence.  The identifiers document where
# the checked-in values came from; they are never opened by production code.
_CALIBRATION_EVIDENCE = MappingProxyType({
    "quick": ("quick-01-r4", "quick-02", "quick-03"),
    "medium": ("medium-01", "medium-02", "medium-03"),
    "long": ("long-01-r2", "long-02"),
})

# Median durable suite duration, distributed across cases using the static
# cost model below.  Values are seconds and sum to the accepted whole-preset
# duration for each canonical preset.
_SUITE_SECONDS = MappingProxyType({
    "quick": MappingProxyType({
        "core": 2.773608,
        "mpc": 104.245306,
        "rl": 1_831.979086,
    }),
    "medium": MappingProxyType({
        "core": 10.394082,
        "mpc": 108.268074,
        "rl": 2_193.882844,
    }),
    "long": MappingProxyType({
        "core": 11.624852,
        "mpc": 133.329891,
        "rl": 12_689.920257,
    }),
})

# Canonical raw-cost sums for the exact released workload populations.  They
# make custom projections deterministic without resolving hidden data or
# consulting previous result bundles.
_CANONICAL_RAW_SUITE_COST = MappingProxyType({
    "quick": MappingProxyType({
        "core": 6_900.0,
        "mpc": 11_475_000.0,
        "rl": 1_383.3053,
    }),
    "medium": MappingProxyType({
        "core": 32_800.0,
        "mpc": 15_300_000.0,
        "rl": 1_900.9753,
    }),
    "long": MappingProxyType({
        "core": 49_200.0,
        "mpc": 22_950_000.0,
        "rl": 12_083.5634,
    }),
})

# Accepted median model.learn seconds per 100,000 aggregate transitions.
_RL_SECONDS_PER_100K = MappingProxyType({
    ("PPO", 1): 103.534,
    ("PPO", 2): 92.383,
    ("PPO", 4): 80.471,
    ("PPO", 8): 80.203,
    ("A2C", 1): 188.978,
    ("SAC", 1): 3_423.080,
    ("TD3", 1): 3_274.766,
    ("DDPG", 1): 3_276.785,
})


def _positive_int(
    document: Mapping[str, object],
    name: str,
    *,
    default: int = 1,
) -> int:
    value = document.get(name)
    return value if type(value) is int and value > 0 else default


def _mapping(
    document: Mapping[str, object],
    name: str,
) -> Mapping[str, object]:
    value = document.get(name)
    return value if isinstance(value, Mapping) else {}


def _rl_seconds_per_100k(algorithm: str, n_envs: int) -> float:
    calibrated = _RL_SECONDS_PER_100K.get((algorithm, n_envs))
    if calibrated is not None:
        return calibrated
    single = _RL_SECONDS_PER_100K.get((algorithm, 1))
    if single is None:
        single = 250.0
    # Unknown custom vector counts retain a deterministic, deliberately
    # conservative sub-linear scaling projection.
    return single / min(max(n_envs, 1), 8) ** 0.16


def _raw_case_cost(
    resolved: ResolvedProfileWorkload,
    case: CaseSpec,
    execution: ExecutionSpec,
) -> float:
    suite = resolved.suite_for(case, execution)
    execution_document = execution.execution_document
    if suite == "core":
        return float(
            _positive_int(execution_document, "sample_count")
            * _positive_int(execution_document, "repetitions")
        )
    if suite == "mpc":
        mpc = _mapping(case.semantic_document, "mpc")
        horizon = _positive_int(
            mpc,
            "prediction_horizon_steps",
        )
        soft_factor = (
            1.25 if mpc.get("soft_constraints") == "on" else 1.0
        )
        return (
            _positive_int(execution_document, "sample_count")
            * _positive_int(execution_document, "repetitions")
            * float(horizon * horizon)
            * soft_factor
        )
    if suite == "rl":
        algorithm_document = _mapping(
            case.semantic_document,
            "algorithm",
        )
        vectorization = _mapping(
            case.semantic_document,
            "vectorization",
        )
        algorithm = algorithm_document.get("name")
        if type(algorithm) is not str or not algorithm:
            algorithm = "UNKNOWN"
        n_envs = _positive_int(
            vectorization,
            "effective_n_envs",
        )
        transitions = _positive_int(
            execution_document,
            "requested_total_environment_transitions",
        )
        return (
            _rl_seconds_per_100k(algorithm.upper(), n_envs)
            * transitions
            / 100_000.0
        )
    return 1.0


def calibrated_case_seconds(
    resolved: ResolvedProfileWorkload,
) -> tuple[float, ...]:
    """Return deterministic presentation estimates in workload order.

    Canonical totals reproduce accepted v1 calibration medians.  Custom
    populations use the same explicit cost model, so adding work increases
    the estimate without changing any workload or execution document.
    """

    if not isinstance(resolved, ResolvedProfileWorkload):
        raise TypeError("resolved must be a ResolvedProfileWorkload")
    preset = resolved.normalized_request.preset
    suite_seconds = _SUITE_SECONDS[preset]
    canonical_costs = _CANONICAL_RAW_SUITE_COST[preset]
    estimates: list[float] = []
    for case, execution in resolved.workload.cases:
        suite = resolved.suite_for(case, execution)
        raw_cost = _raw_case_cost(resolved, case, execution)
        budget = suite_seconds.get(suite, 1.0)
        denominator = canonical_costs.get(suite, 1.0)
        estimates.append(max(0.001, raw_cost * budget / denominator))
    return tuple(estimates)


def _format_duration(seconds: float) -> str:
    rounded = int(round(max(0.0, seconds)))
    hours, remainder = divmod(rounded, 3_600)
    minutes, seconds_part = divmod(remainder, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds_part:02d}"
    return f"{minutes}:{seconds_part:02d}"


class SparseProgressPresenter:
    """Render readable parent-side progress without exposing opaque IDs."""

    def __init__(
        self,
        resolved: ResolvedProfileWorkload,
        stream: TextIO,
        *,
        clock: Callable[[], float] = time.monotonic,
        estimated_case_seconds: Sequence[float] | None = None,
    ) -> None:
        if not isinstance(resolved, ResolvedProfileWorkload):
            raise TypeError("resolved must be a ResolvedProfileWorkload")
        if not hasattr(stream, "write"):
            raise TypeError("stream must provide write()")
        estimates = (
            calibrated_case_seconds(resolved)
            if estimated_case_seconds is None
            else tuple(float(value) for value in estimated_case_seconds)
        )
        cases = resolved.workload.cases
        if (
            len(estimates) != len(cases)
            or any(value <= 0.0 for value in estimates)
        ):
            raise ValueError(
                "estimated_case_seconds must contain one positive value "
                "per case"
            )
        self._stream = stream
        self._clock = clock
        self._estimates = estimates
        self._case_details = {
            execution_instance_id(
                case.semantic_case_id,
                execution.execution_spec_digest,
            ): (index, case.readable_prefix)
            for index, (case, execution) in enumerate(cases)
        }
        self._run_started_at: float | None = None
        self._case_started_at: dict[str, float] = {}
        self._finished: set[str] = set()
        self._observed_seconds = 0.0
        self._observed_estimate = 0.0

    def _elapsed(self, now: float) -> float:
        if self._run_started_at is None:
            return 0.0
        return max(0.0, now - self._run_started_at)

    def _remaining(self) -> float:
        remaining = sum(
            estimate
            for identity, (index, _) in self._case_details.items()
            if identity not in self._finished
            for estimate in (self._estimates[index],)
        )
        if self._observed_estimate > 0.0:
            remaining *= (
                self._observed_seconds / self._observed_estimate
            )
        return remaining

    def _status_suffix(self, now: float) -> str:
        return (
            " | elapsed "
            + _format_duration(self._elapsed(now))
            + " | approximate ETA "
            + _format_duration(self._remaining())
        )

    def _write(self, text: str) -> None:
        self._stream.write(text + "\n")
        flush = getattr(self._stream, "flush", None)
        if callable(flush):
            flush()

    def __call__(self, event: ProgressEvent) -> None:
        if not isinstance(event, ProgressEvent):
            raise TypeError("event must be a ProgressEvent")
        now = self._clock()
        if event.phase == "run_start":
            self._run_started_at = now
            self._write(
                "Progress 0/"
                + str(len(self._case_details))
                + self._status_suffix(now)
            )
            return
        if event.phase == "suite_start":
            self._write(
                "Starting "
                + event.case_id.removeprefix("suite:")
                + " suite"
            )
            return
        if event.phase == "suite_complete":
            self._write(
                "Completed "
                + event.case_id.removeprefix("suite:")
                + " suite"
            )
            return
        if event.phase == "run_complete":
            self._write(
                "Progress "
                + str(len(self._finished))
                + "/"
                + str(len(self._case_details))
                + self._status_suffix(now)
            )
            return
        details = self._case_details.get(event.case_id)
        if details is None:
            return
        index, label = details
        ordinal = str(index + 1) + "/" + str(len(self._case_details))
        if event.phase == "case_start":
            self._case_started_at[event.case_id] = now
            self._write(
                "Case "
                + ordinal
                + ": "
                + label
                + self._status_suffix(now)
            )
            return
        if event.phase in {"case_complete", "case_fail"}:
            started_at = self._case_started_at.pop(
                event.case_id,
                now,
            )
            if event.case_id not in self._finished:
                self._observed_seconds += max(0.0, now - started_at)
                self._observed_estimate += self._estimates[index]
                self._finished.add(event.case_id)
            prefix = (
                "Completed case "
                if event.phase == "case_complete"
                else "Failed case "
            )
            self._write(
                prefix
                + ordinal
                + ": "
                + label
                + self._status_suffix(now)
            )
            return
        if event.phase == "case_skip":
            self._finished.add(event.case_id)
            self._write(
                "Reused case "
                + ordinal
                + ": "
                + label
                + self._status_suffix(now)
            )
            return
        if event.phase == "milestone":
            self._write(
                "Progress case "
                + ordinal
                + ": "
                + label
                + " "
                + str(event.completed)
                + "/"
                + str(event.total)
                + self._status_suffix(now)
            )


class TransientNotebookProgress:
    """Display only the latest sparse progress line in a notebook cell."""

    def __init__(
        self,
        resolved: ResolvedProfileWorkload,
        *,
        display: Callable[[str], object],
        clear: Callable[[], object],
        clock: Callable[[], float] = time.monotonic,
        estimated_case_seconds: Sequence[float] | None = None,
    ) -> None:
        self._buffer = io.StringIO()
        self._display = display
        self._clear_display = clear
        self._presenter = SparseProgressPresenter(
            resolved,
            self._buffer,
            clock=clock,
            estimated_case_seconds=estimated_case_seconds,
        )

    def __call__(self, event: ProgressEvent) -> None:
        before = self._buffer.tell()
        self._presenter(event)
        self._buffer.seek(before)
        new_text = self._buffer.read()
        self._buffer.seek(0, io.SEEK_END)
        lines = tuple(line for line in new_text.splitlines() if line)
        if not lines:
            return
        self._clear_display()
        self._display(lines[-1])

    def clear(self) -> None:
        self._clear_display()
