"""Privacy-safe, parent-owned transactional profiling result bundles."""

from __future__ import annotations

import copy
from datetime import datetime, timezone
import hashlib
import io
import importlib.resources
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import statistics
import tempfile
from typing import Any, Mapping
import unicodedata
import uuid

import numpy as np

from dreamgym.profiling.autonomous_driving.measurement import (
    summarize_sample_ns,
)
from dreamgym.profiling.autonomous_driving.metadata import (
    _observe_collected_rl_device,
    validate_metadata_record,
)
from dreamgym.profiling.autonomous_driving.privacy import (
    PrivacyError,
    ensure_artifact_safe,
    validate_case_diagnostic,
    validate_case_warning,
)
from dreamgym.profiling.autonomous_driving.records import (
    PROFILE_RESULTS_SCHEMA_VERSION,
    canonical_json_digest,
    execution_instance_id,
    json_native,
)
from dreamgym.training.autonomous_driving.config_validation import (
    parse_strict_json_object,
)
from dreamgym.training.autonomous_driving.snapshots import (
    canonical_snapshot_digest,
    save_snapshot_json,
    validate_resolved_snapshot,
    validate_snapshot,
)


BUNDLE_SCHEMA_VERSION = "dreamgym-result-bundle-v1"
_COMPATIBILITY_FIELDS = (
    "dependency_compatibility_digest",
    "runtime_hardware_compatibility_digest",
    "device_compatibility_digest",
    "live_session_fingerprint",
)
_DURABLE_COMPATIBILITY_FIELDS = _COMPATIBILITY_FIELDS[:3]
_RUNTIME_VERSION_FIELDS = frozenset(
    ("dreamgym", "gymnasium", "stable_baselines3", "python", "numpy", "torch")
)
_HEX_RE = re.compile(r"[0-9a-f]{64}\Z")
_CASE_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}\Z")
_ATTEMPT_RE = re.compile(r"attempt-[0-9a-f]{32}\Z")
_MEASUREMENT_RE = re.compile(r"measurement-[0-9a-f]{32}\Z")
_STATUSES = frozenset(("completed", "failed", "interrupted", "skipped"))
_RUN_STATUSES = frozenset(
    ("running", "successful", "incomplete", "interrupted", "failed")
)
_REQUIRED_SUCCESS_ARTIFACTS = {
    "summary.md": "text/markdown; charset=utf-8",
    "tables/cases.csv": "text/csv; charset=utf-8",
}
_PORTABLE_METRIC_UNITS = frozenset(("1/s", "count", "ns", "s", "value"))
STRUCTURED_RECORDS_SCHEMA_VERSION = "dreamgym-profile-case-records-v1"


class BundleIntegrityError(ValueError):
    """The bundle or a referenced artifact failed strict integrity checks."""


class BundleCompatibilityError(ValueError):
    """Runtime, identity, or lifecycle compatibility was not satisfied."""


def _strict_object(path: Path) -> dict[str, Any]:
    try:
        return parse_strict_json_object(path.read_text(encoding="utf-8"))
    except (OSError, TypeError, ValueError) as error:
        raise BundleIntegrityError(str(path.name) + " is not strict JSON") from error


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _require_digest(value: Any, path: str) -> str:
    if type(value) is not str or _HEX_RE.fullmatch(value) is None:
        raise BundleIntegrityError(path + " must be a lowercase SHA-256 digest")
    return value


def _require_exact(value: Any, fields: set[str], path: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise TypeError(path + " must be an object")
    missing = sorted(fields - set(value))
    unexpected = sorted(set(value) - fields)
    if missing or unexpected:
        name = missing[0] if missing else unexpected[0]
        raise BundleIntegrityError(path + "." + name + " is missing or unsupported")
    return value


def _relative_reference(value: Any, path: str) -> str:
    if type(value) is not str or not value or "\\" in value or "\x00" in value:
        raise BundleIntegrityError(path + " must be a POSIX relative path")
    if re.match(r"^[A-Za-z]:", value) or value.startswith(("/", "//")):
        raise BundleIntegrityError(path + " must be a POSIX relative path")
    reference = PurePosixPath(value)
    if any(part in ("", ".", "..") or ":" in part for part in reference.parts):
        raise BundleIntegrityError(path + " must remain within the bundle")
    return reference.as_posix()


def _portable_path_identity(relative_path: str) -> str:
    """Return a host-independent comparison identity for a bundle path."""

    normalized = unicodedata.normalize("NFC", relative_path)
    return unicodedata.normalize("NFC", normalized.casefold())


def _validate_portable_bundle_paths(manifest: Mapping[str, Any]) -> None:
    """Reject path aliases that cannot be transferred safely across hosts."""

    references: list[tuple[str, bool]] = [
        ("manifest.json", False),
        ("results.json", False),
        (".bundle-index-transaction.json", False),
    ]
    for snapshot in manifest["configurations"].values():
        references.append((snapshot["requested_config_path"], True))
        if "resolved_config_path" in snapshot:
            references.append((snapshot["resolved_config_path"], True))
    for case in manifest["cases"].values():
        if "raw_samples" in case:
            references.append((case["raw_samples"]["path"], True))
        if "structured_records" in case:
            references.append((case["structured_records"]["path"], True))
    references.extend(
        (artifact["path"], False)
        for artifact in manifest["artifacts"].values()
    )

    indexed: dict[str, tuple[str, bool]] = {}
    for reference, may_share in references:
        lexical_reference = _relative_reference(
            reference,
            "indexed bundle path",
        )
        identity = _portable_path_identity(lexical_reference)
        previous = indexed.get(identity)
        if previous is None:
            indexed[identity] = (reference, may_share)
            continue
        previous_reference, previous_may_share = previous
        if previous_reference != reference:
            raise BundleIntegrityError(
                "portable bundle paths collide: "
                + previous_reference
                + " and "
                + reference
            )
        if not (may_share and previous_may_share):
            raise BundleIntegrityError(
                reference + " is reserved or already indexed"
            )

    identities = set(indexed)
    for identity in identities:
        parts = identity.split("/")
        for length in range(1, len(parts)):
            ancestor = "/".join(parts[:length])
            if ancestor in identities:
                raise BundleIntegrityError(
                    "portable indexed file path "
                    + indexed[ancestor][0]
                    + " is an ancestor of "
                    + indexed[identity][0]
                )


def _validate_prospective_configuration_paths(
    manifest: Mapping[str, Any],
    requested_config_digest: str,
    snapshot_paths: Mapping[str, str],
) -> None:
    prospective = copy.deepcopy(dict(manifest))
    existing = prospective["configurations"].get(
        requested_config_digest,
        {},
    )
    prospective["configurations"][requested_config_digest] = {
        **existing,
        **snapshot_paths,
    }
    _validate_portable_bundle_paths(prospective)


def _validate_text_artifact_payload(payload: bytes, media_type: str) -> None:
    if not media_type.startswith("text/"):
        return
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as error:
        raise BundleIntegrityError(
            "text artifact payload must be UTF-8"
        ) from error
    ensure_artifact_safe(text)


def _artifact_record(value: Any, path: str) -> dict[str, str]:
    record = _require_exact(
        value,
        {"path", "media_type", "sha256"},
        path,
    )
    relative = _relative_reference(record["path"], path + ".path")
    media_type = record["media_type"]
    if type(media_type) is not str or not media_type.strip():
        raise BundleIntegrityError(path + ".media_type must be non-empty")
    return {
        "path": relative,
        "media_type": media_type,
        "sha256": _require_digest(record["sha256"], path + ".sha256"),
    }


def _segment_artifact_record(
    value: Any,
    path: str,
) -> dict[str, str]:
    record = _require_exact(
        value,
        {"path", "sha256", "measurement_segment_id"},
        path,
    )
    segment_id = record["measurement_segment_id"]
    if (
        type(segment_id) is not str
        or _MEASUREMENT_RE.fullmatch(segment_id) is None
    ):
        raise BundleIntegrityError(
            path + ".measurement_segment_id is invalid"
        )
    return {
        "path": _relative_reference(record["path"], path + ".path"),
        "sha256": _require_digest(record["sha256"], path + ".sha256"),
        "measurement_segment_id": segment_id,
    }


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _validate_utc_timestamp(value: Any, path: str) -> str:
    if type(value) is not str or not value.endswith("Z"):
        raise BundleIntegrityError(path + " must be a UTC timestamp")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as error:
        raise BundleIntegrityError(path + " must be a UTC timestamp") from error
    if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise BundleIntegrityError(path + " must be a UTC timestamp")
    return value


def _run_attempt_record(value: Any, path: str) -> dict[str, Any]:
    record = _require_exact(
        value,
        {
            "run_attempt_id",
            "started_at_utc",
            "ended_at_utc",
            "status",
            "fatal",
            "expected_case_ids",
            "completed_case_ids",
            "case_attempts",
            "warnings",
        },
        path,
    )
    attempt_id = record["run_attempt_id"]
    if (
        type(attempt_id) is not str
        or _ATTEMPT_RE.fullmatch(attempt_id) is None
    ):
        raise BundleIntegrityError(path + ".run_attempt_id is invalid")
    _validate_utc_timestamp(
        record["started_at_utc"],
        path + ".started_at_utc",
    )
    if record["ended_at_utc"] is not None:
        _validate_utc_timestamp(
            record["ended_at_utc"],
            path + ".ended_at_utc",
        )
    if record["status"] not in _RUN_STATUSES:
        raise BundleIntegrityError(path + ".status is unsupported")
    if (
        record["status"] == "running"
        and record["ended_at_utc"] is not None
    ) or (
        record["status"] != "running"
        and record["ended_at_utc"] is None
    ):
        raise BundleIntegrityError(
            path + ".status and ended_at_utc disagree"
        )
    if type(record["fatal"]) is not bool:
        raise TypeError(path + ".fatal must be a boolean")
    if record["fatal"] and record["status"] != "failed":
        raise BundleIntegrityError(
            path + ".fatal is valid only for failed attempts"
        )
    for field in ("expected_case_ids", "completed_case_ids"):
        values = record[field]
        if (
            type(values) is not list
            or len(values) != len(set(values))
            or any(
                type(item) is not str
                or _CASE_RE.fullmatch(item) is None
                for item in values
            )
        ):
            raise BundleIntegrityError(path + "." + field + " is invalid")
    if not set(record["completed_case_ids"]) <= set(
        record["expected_case_ids"]
    ):
        raise BundleIntegrityError(
            path + ".completed_case_ids are not expected"
        )
    if type(record["case_attempts"]) is not list:
        raise TypeError(path + ".case_attempts must be an array")
    seen_segments: set[str] = set()
    for index, item in enumerate(record["case_attempts"]):
        item_path = path + ".case_attempts[" + str(index) + "]"
        attempt = _require_exact(
            item,
            {"case_id", "measurement_segment_id", "status"},
            item_path,
        )
        if (
            type(attempt["case_id"]) is not str
            or _CASE_RE.fullmatch(attempt["case_id"]) is None
        ):
            raise BundleIntegrityError(item_path + ".case_id is invalid")
        segment = attempt["measurement_segment_id"]
        if (
            type(segment) is not str
            or _MEASUREMENT_RE.fullmatch(segment) is None
            or segment in seen_segments
        ):
            raise BundleIntegrityError(
                item_path + ".measurement_segment_id is invalid"
            )
        seen_segments.add(segment)
        if attempt["status"] not in _STATUSES:
            raise BundleIntegrityError(item_path + ".status is unsupported")
    if (
        type(record["warnings"]) is not list
        or any(type(item) is not str or not item for item in record["warnings"])
    ):
        raise BundleIntegrityError(path + ".warnings are invalid")
    for warning in record["warnings"]:
        validate_case_warning(warning)
    return copy.deepcopy(record)


def _source_validation_record(
    value: Any,
    path: str = "manifest.source_validation",
) -> dict[str, Any]:
    record = _require_exact(
        value,
        {"validated", "manifest_digest", "release_commit"},
        path,
    )
    if record["validated"] is not True:
        raise BundleIntegrityError(path + ".validated must be true")
    release_commit = record["release_commit"]
    if (
        type(release_commit) is not str
        or re.fullmatch(r"[0-9a-f]{40}", release_commit) is None
    ):
        raise BundleIntegrityError(
            path + ".release_commit must be a lowercase full commit"
        )
    return {
        "validated": True,
        "manifest_digest": _require_digest(
            record["manifest_digest"],
            path + ".manifest_digest",
        ),
        "release_commit": release_commit,
    }


def _workload_record(value: Any, path: str) -> dict[str, Any]:
    fields = {
        "workload_version",
        "workload_digest",
        "release_status",
    }
    if isinstance(value, Mapping) and "release_identity" in value:
        fields.add("release_identity")
    workload = _require_exact(value, fields, path)
    if (
        type(workload["workload_version"]) is not str
        or not workload["workload_version"]
    ):
        raise BundleIntegrityError(path + ".workload_version is invalid")
    _require_digest(
        workload["workload_digest"],
        path + ".workload_digest",
    )
    if "release_identity" in workload:
        release_identity = _require_exact(
            workload["release_identity"],
            {
                "workload_release_id",
                "result_schema_release_id",
                "timing_protocol_release_id",
            },
            path + ".release_identity",
        )
        for field, item in release_identity.items():
            if item is not None and (
                type(item) is not str or not item
            ):
                raise BundleIntegrityError(
                    path + ".release_identity." + field + " is invalid"
                )
    release = _require_exact(
        workload["release_status"],
        {"classification", "canonical_status", "submission_status"},
        path + ".release_status",
    )
    if (
        type(release["classification"]) is not str
        or not release["classification"]
    ):
        raise BundleIntegrityError(
            path + ".release_status.classification is invalid"
        )
    if (
        type(release["canonical_status"]) is not bool
        or type(release["submission_status"]) is not bool
    ):
        raise TypeError(path + ".release_status flags must be booleans")
    if (
        release["classification"] == "locked_submission_candidate"
        and (release["canonical_status"] or release["submission_status"])
    ):
        raise BundleCompatibilityError(
            "locked_submission_candidate cannot be promoted"
        )
    return copy.deepcopy(workload)


def _source_authority_record(
    value: Any,
    path: str,
) -> dict[str, Any]:
    authority = _require_exact(
        value,
        {"workload", "source_validation"},
        path,
    )
    source_validation = authority["source_validation"]
    if source_validation is not None:
        source_validation = _source_validation_record(
            source_validation,
            path + ".source_validation",
        )
    return {
        "workload": _workload_record(
            authority["workload"],
            path + ".workload",
        ),
        "source_validation": source_validation,
    }


def _has_reparse_point(path: Path) -> bool:
    try:
        attributes = getattr(path.lstat(), "st_file_attributes", 0)
    except FileNotFoundError:
        return False
    return bool(attributes & 0x400)


def _bundle_path(root: Path, reference: str) -> Path:
    normalized = _relative_reference(reference, "artifact.path")
    root_resolved = root.resolve(strict=True)
    candidate = root.joinpath(*PurePosixPath(normalized).parts)
    current = root
    for part in PurePosixPath(normalized).parts:
        current = current / part
        if current.exists() and (current.is_symlink() or _has_reparse_point(current)):
            raise BundleIntegrityError("artifact path traverses a link or reparse point")
    resolved = candidate.resolve(strict=False)
    try:
        resolved.relative_to(root_resolved)
    except ValueError as error:
        raise BundleIntegrityError("artifact path escapes the bundle") from error
    return candidate


def _same_directory_temp(destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(
        prefix="." + destination.name + ".",
        suffix=".recoverable.tmp",
        dir=destination.parent,
    )
    os.close(descriptor)
    return Path(name)


def _atomic_json(destination: Path, value: Mapping[str, Any]) -> None:
    detached = json_native(dict(value))
    ensure_artifact_safe(detached)
    payload = (
        json.dumps(
            detached,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")
    _atomic_bytes(destination, payload)


def _atomic_bytes(destination: Path, payload: bytes) -> None:
    temporary = _same_directory_temp(destination)
    try:
        temporary.write_bytes(payload)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def _case_evidence_paths(document: Mapping[str, Any]) -> set[str]:
    paths: set[str] = set()
    for case in document["manifest"]["cases"].values():
        for field in ("raw_samples", "structured_records"):
            artifact = case.get(field)
            if isinstance(artifact, Mapping):
                paths.add(artifact["path"])
    return paths


def _remove_atomic_temps(destination: Path) -> None:
    parent = destination.parent
    if not parent.is_dir():
        return
    prefix = "." + destination.name + "."
    suffix = ".recoverable.tmp"
    for candidate in parent.iterdir():
        if not (
            candidate.name.startswith(prefix)
            and candidate.name.endswith(suffix)
        ):
            continue
        if (
            candidate.is_symlink()
            or _has_reparse_point(candidate)
            or not candidate.is_file()
        ):
            raise BundleIntegrityError(
                "recoverable transaction temp must be a regular file"
            )
        candidate.unlink()


def _remove_case_evidence(root: Path, references: set[str]) -> None:
    for reference in sorted(references, reverse=True):
        destination = _bundle_path(root, reference)
        _remove_atomic_temps(destination)
        destination.unlink(missing_ok=True)
        parent = destination.parent
        while parent != root:
            try:
                parent.rmdir()
            except OSError:
                break
            parent = parent.parent


def _semantic_projection_suite(value: Any) -> str | None:
    """Mirror the runner-owned suite projection without importing the runner."""

    if type(value) is not dict:
        return None
    suite = value.get("suite")
    if type(suite) is str and suite:
        return suite
    if {
        "algorithm",
        "vectorization",
        "environment",
        "training_seeds",
    } <= set(value):
        return "rl"
    return None


def _lifecycle_identity_relations_are_valid(value: Any) -> bool:
    if type(value) is not dict:
        return False
    suite = value.get("suite")
    category = value.get("category")
    semantic_case_id = value.get("semantic_case_id")
    semantic_digest = value.get("semantic_case_digest")
    projection_digest = value.get("semantic_projection_digest")
    execution_digest = value.get("execution_spec_digest")
    semantic_projection = value.get("semantic_projection")
    if (
        type(suite) is not str
        or not suite
        or type(category) is not str
        or not category
        or type(semantic_digest) is not str
        or _HEX_RE.fullmatch(semantic_digest) is None
        or projection_digest != semantic_digest
        or type(execution_digest) is not str
        or _HEX_RE.fullmatch(execution_digest) is None
        or _semantic_projection_suite(semantic_projection) != suite
        or semantic_case_id != category + "-" + semantic_digest
        or value.get("case_id")
        != execution_instance_id(
            semantic_case_id,
            execution_digest,
        )
    ):
        return False
    fixture_identity = value.get("fixture_identity")
    linked_digest = (
        fixture_identity.get("semantic_case_digest")
        if type(fixture_identity) is dict
        else None
    )
    return linked_digest is None or linked_digest == semantic_digest


def _runtime_versions_from_metadata(
    metadata: Mapping[str, Any],
) -> dict[str, str]:
    dependencies = metadata["dependencies"]
    expected = {
        "python": metadata["python"]["version"],
    }
    for field in _RUNTIME_VERSION_FIELDS - {"python"}:
        value = dependencies.get(field)
        if type(value) is not str or not value:
            raise BundleCompatibilityError(
                "collected runtime metadata is missing dependency version "
                + field
            )
        expected[field] = value
    return expected


def _validate_resolved_runtime_versions(
    snapshot: Mapping[str, Any],
    expected_versions: Mapping[str, str],
) -> None:
    for name, expected in expected_versions.items():
        if snapshot["versions"][name] != expected:
            raise BundleCompatibilityError(
                "resolved snapshot version "
                + name
                + " disagrees with collected runtime metadata"
            )


def _runtime_version_matches_legacy_bundle_read(
    dependency_name: str,
    metadata_version: str,
    resolved_version: str,
) -> bool:
    """Accept exact versions plus the one historical Torch load exception."""

    return metadata_version == resolved_version or (
        dependency_name == "torch"
        and metadata_version == "2.12.1"
        and resolved_version == "2.12.1+cpu"
    )


def _snapshot_candidate(destination: Path, snapshot: Mapping[str, Any]) -> tuple[Path, bytes]:
    temporary = _same_directory_temp(destination)
    save_snapshot_json(snapshot, temporary)
    payload = temporary.read_bytes()
    return temporary, payload


def _commit_snapshot(destination: Path, snapshot: Mapping[str, Any]) -> str:
    temporary, payload = _snapshot_candidate(destination, snapshot)
    if destination.exists():
        if destination.read_bytes() != payload:
            temporary.unlink(missing_ok=True)
            raise BundleIntegrityError(
                destination.name + " already exists with different bytes"
            )
        temporary.unlink(missing_ok=True)
        return _sha256_bytes(payload)
    os.replace(temporary, destination)
    return _sha256_bytes(payload)


def _snapshot_record(value: Any, path: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise TypeError(path + " must be an object")
    requested_fields = {
        "requested_config_path",
        "requested_config_digest",
        "requested_file_sha256",
    }
    resolved_fields = {
        "resolved_config_path",
        "resolved_config_digest",
        "resolved_file_sha256",
    }
    if set(value) not in (requested_fields, requested_fields | resolved_fields):
        raise BundleIntegrityError(path + " has missing or unsupported fields")
    requested_digest = _require_digest(
        value["requested_config_digest"], path + ".requested_config_digest"
    )
    expected_requested = (
        "training_configs/" + requested_digest + "/config.json"
    )
    if (
        _relative_reference(
            value["requested_config_path"], path + ".requested_config_path"
        )
        != expected_requested
    ):
        raise BundleIntegrityError(path + ".requested_config_path is not canonical")
    _require_digest(value["requested_file_sha256"], path + ".requested_file_sha256")
    if resolved_fields <= set(value):
        expected_resolved = (
            "training_configs/" + requested_digest + "/resolved_config.json"
        )
        if (
            _relative_reference(
                value["resolved_config_path"], path + ".resolved_config_path"
            )
            != expected_resolved
        ):
            raise BundleIntegrityError(path + ".resolved_config_path is not canonical")
        _require_digest(
            value["resolved_config_digest"], path + ".resolved_config_digest"
        )
        _require_digest(
            value["resolved_file_sha256"], path + ".resolved_file_sha256"
        )
    return copy.deepcopy(value)


def _case_record(value: Any, path: str) -> dict[str, Any]:
    value = copy.deepcopy(value)
    base_fields = {
        "case_id",
        "semantic_case_id",
        "semantic_case_digest",
        "execution_spec_digest",
        "timing_protocol_digest",
        "result_schema_version",
        "benchmark_release",
        "semantic_projection_digest",
        "eligibility",
        "fixed_seeds",
        "snapshot",
        "raw_samples",
        "structured_records",
        "imported_from",
    }
    lifecycle_fields = {
        "suite",
        "category",
        "semantic_projection_version",
        "semantic_projection",
        "timing_protocol",
        "execution_spec",
        "fixture_identity",
        "required",
        "timing_validity",
        "run_attempt_id",
        "measurement_segment_id",
        "live_session_fingerprint",
    }
    allowed = base_fields | lifecycle_fields
    if type(value) is not dict:
        raise TypeError(path + " must be an object")
    required = base_fields - {
        "snapshot",
        "raw_samples",
        "structured_records",
        "imported_from",
    }
    if not required <= set(value) or not set(value) <= allowed:
        raise BundleIntegrityError(path + " has missing or unsupported fields")
    present_lifecycle = set(value) & lifecycle_fields
    if present_lifecycle and present_lifecycle != lifecycle_fields:
        missing = sorted(lifecycle_fields - present_lifecycle)[0]
        raise BundleIntegrityError(path + "." + missing + " is required")
    if type(value["case_id"]) is not str or _CASE_RE.fullmatch(value["case_id"]) is None:
        raise BundleIntegrityError(path + ".case_id is unsafe")
    if (
        type(value["semantic_case_id"]) is not str
        or _CASE_RE.fullmatch(value["semantic_case_id"]) is None
    ):
        raise BundleIntegrityError(path + ".semantic_case_id is unsafe")
    for field in (
        "semantic_case_digest",
        "execution_spec_digest",
        "timing_protocol_digest",
        "semantic_projection_digest",
    ):
        _require_digest(value[field], path + "." + field)
    if not value["semantic_case_id"].endswith(
        "-" + value["semantic_case_digest"]
    ):
        raise BundleIntegrityError(
            path + ".semantic_case_id and semantic_case_digest disagree"
        )
    for field in ("result_schema_version", "benchmark_release"):
        if type(value[field]) is not str or not value[field]:
            raise BundleIntegrityError(path + "." + field + " must be a string")
    if value["result_schema_version"] != PROFILE_RESULTS_SCHEMA_VERSION:
        raise BundleCompatibilityError(
            path + ".result_schema_version is unsupported"
        )
    eligibility = _require_exact(
        value["eligibility"],
        {"semantic_reuse_import", "sample_aggregation"},
        path + ".eligibility",
    )
    if any(type(item) is not bool for item in eligibility.values()):
        raise TypeError(path + ".eligibility values must be booleans")
    if type(value["fixed_seeds"]) is not dict:
        raise TypeError(path + ".fixed_seeds must be an object")
    json_native(value["fixed_seeds"])
    if present_lifecycle:
        for field in (
            "suite",
            "category",
            "semantic_projection_version",
        ):
            if type(value[field]) is not str or not value[field]:
                raise BundleIntegrityError(
                    path + "." + field + " must be a non-empty string"
                )
        for field in (
            "semantic_projection",
            "timing_protocol",
            "execution_spec",
            "fixture_identity",
            "timing_validity",
        ):
            if type(value[field]) is not dict:
                raise TypeError(path + "." + field + " must be an object")
            json_native(value[field])
        if not _lifecycle_identity_relations_are_valid(value):
            raise BundleIntegrityError(
                path
                + " lifecycle suite, category, semantic case identity, "
                "and linked digest disagree"
            )
        if type(value["required"]) is not bool:
            raise TypeError(path + ".required must be a boolean")
        attempt_id = value["run_attempt_id"]
        if (
            type(attempt_id) is not str
            or _ATTEMPT_RE.fullmatch(attempt_id) is None
        ):
            raise BundleIntegrityError(path + ".run_attempt_id is invalid")
        segment_id = value["measurement_segment_id"]
        if (
            type(segment_id) is not str
            or _MEASUREMENT_RE.fullmatch(segment_id) is None
        ):
            raise BundleIntegrityError(
                path + ".measurement_segment_id is invalid"
            )
        _require_digest(
            value["live_session_fingerprint"],
            path + ".live_session_fingerprint",
        )
        if canonical_json_digest(value["timing_protocol"]) != value[
            "timing_protocol_digest"
        ]:
            raise BundleIntegrityError(
                path + ".timing_protocol digest disagrees"
            )
        projection_identity = {
            "semantic_document": value["semantic_projection"],
            "timing_protocol_digest": value["timing_protocol_digest"],
        }
        if canonical_json_digest(projection_identity) != value[
            "semantic_projection_digest"
        ]:
            raise BundleIntegrityError(
                path + ".semantic_projection digest disagrees"
            )
        if canonical_json_digest(value["execution_spec"]) != value[
            "execution_spec_digest"
        ]:
            raise BundleIntegrityError(
                path + ".execution_spec digest disagrees"
            )
    if "snapshot" in value:
        _snapshot_record(value["snapshot"], path + ".snapshot")
    if "raw_samples" in value:
        if type(value["raw_samples"]) is not dict:
            raise TypeError(path + ".raw_samples must be an object")
        artifact_fields = set(value["raw_samples"])
        if artifact_fields == {"path", "sha256"}:
            if present_lifecycle:
                raise BundleIntegrityError(
                    path
                    + ".raw_samples.measurement_segment_id is required"
                )
            artifact = _require_exact(
                value["raw_samples"],
                {"path", "sha256"},
                path + ".raw_samples",
            )
            _relative_reference(
                artifact["path"], path + ".raw_samples.path"
            )
            _require_digest(
                artifact["sha256"], path + ".raw_samples.sha256"
            )
        else:
            artifact = _segment_artifact_record(
                value["raw_samples"],
                path + ".raw_samples",
            )
            if (
                present_lifecycle
                and artifact["measurement_segment_id"]
                != value["measurement_segment_id"]
            ):
                raise BundleIntegrityError(
                    path + ".raw_samples segment disagrees"
                )
    if "structured_records" in value:
        if not present_lifecycle:
            raise BundleIntegrityError(
                path + ".structured_records require lifecycle case identity"
            )
        artifact = _segment_artifact_record(
            value["structured_records"],
            path + ".structured_records",
        )
        if (
            present_lifecycle
            and artifact["measurement_segment_id"]
            != value["measurement_segment_id"]
        ):
            raise BundleIntegrityError(
                path + ".structured_records segment disagrees"
            )
    if "imported_from" in value:
        imported_path = path + ".imported_from"
        imported = value["imported_from"]
        required_imported = {
            "source_bundle_id",
            "source_case_id",
            "source_segment_id",
            "source_snapshot",
        }
        allowed_imported = required_imported | {
            "source_execution_spec_digest",
            "source_authority",
            "import_chain",
        }
        if type(imported) is not dict:
            raise TypeError(imported_path + " must be an object")
        if (
            not required_imported <= set(imported)
            or not set(imported) <= allowed_imported
        ):
            raise BundleIntegrityError(
                imported_path + " has missing or unsupported fields"
            )
        for field in ("source_bundle_id", "source_case_id", "source_segment_id"):
            if type(imported[field]) is not str or not imported[field]:
                raise BundleIntegrityError(
                    imported_path + "." + field + " is invalid"
                )
        if "source_execution_spec_digest" not in imported:
            imported["source_execution_spec_digest"] = value[
                "execution_spec_digest"
            ]
        else:
            _require_digest(
                imported["source_execution_spec_digest"],
                imported_path + ".source_execution_spec_digest",
            )
        if "import_chain" in imported:
            chain = imported["import_chain"]
            if type(chain) is not list or not chain:
                raise BundleIntegrityError(
                    imported_path + ".import_chain must be non-empty"
                )
            validated_chain = []
            for index, item in enumerate(chain):
                item_path = (
                    imported_path
                    + ".import_chain["
                    + str(index)
                    + "]"
                )
                hop = _require_exact(
                    item,
                    {
                        "source_bundle_id",
                        "source_case_id",
                        "source_execution_spec_digest",
                        "source_segment_id",
                    },
                    item_path,
                )
                for field in (
                    "source_bundle_id",
                    "source_case_id",
                    "source_segment_id",
                ):
                    if type(hop[field]) is not str or not hop[field]:
                        raise BundleIntegrityError(
                            item_path + "." + field + " is invalid"
                        )
                _require_digest(
                    hop["source_execution_spec_digest"],
                    item_path + ".source_execution_spec_digest",
                )
                validated_chain.append(copy.deepcopy(hop))
            root_hop = {
                key: imported[key]
                for key in (
                    "source_bundle_id",
                    "source_case_id",
                    "source_execution_spec_digest",
                    "source_segment_id",
                )
            }
            if validated_chain[0] != root_hop:
                raise BundleIntegrityError(
                    imported_path
                    + ".import_chain does not begin at root authority"
                )
            imported["import_chain"] = validated_chain
        if "source_authority" in imported:
            imported["source_authority"] = _source_authority_record(
                imported["source_authority"],
                imported_path + ".source_authority",
            )
        if imported["source_snapshot"] is not None:
            _snapshot_record(
                imported["source_snapshot"],
                imported_path + ".source_snapshot",
            )
    ensure_artifact_safe(value)
    return copy.deepcopy(value)


def _result_record(value: Any, path: str) -> dict[str, Any]:
    detached = copy.deepcopy(value)
    result = _require_exact(
        detached,
        {
            "status",
            "fatal",
            "segment_id",
            "actual_completed_transitions",
            "metrics",
            "warnings",
            "errors",
        },
        path,
    )
    if result["status"] not in _STATUSES:
        raise BundleIntegrityError(path + ".status is unsupported")
    if type(result["fatal"]) is not bool:
        raise TypeError(path + ".fatal must be a boolean")
    if type(result["segment_id"]) is not str or not result["segment_id"]:
        raise BundleIntegrityError(path + ".segment_id must be a string")
    if (
        result["segment_id"].startswith("measurement-")
        and _MEASUREMENT_RE.fullmatch(result["segment_id"]) is None
    ):
        raise BundleIntegrityError(path + ".segment_id is invalid")
    transitions = result["actual_completed_transitions"]
    if type(transitions) is not int or transitions < 0:
        raise BundleIntegrityError(
            path + ".actual_completed_transitions must be non-negative"
        )
    if type(result["metrics"]) is not dict:
        raise TypeError(path + ".metrics must be an object")
    if result["status"] == "completed" and not result["metrics"]:
        raise BundleIntegrityError(
            path + ".metrics must be non-empty for a completed result"
        )
    if type(result["warnings"]) is not list:
        raise TypeError(path + ".warnings must be an array")
    if type(result["errors"]) is not list:
        raise TypeError(path + ".errors must be an array")
    result["warnings"] = [
        validate_case_warning(warning)
        for warning in result["warnings"]
    ]
    result["errors"] = [
        validate_case_diagnostic(error)
        for error in result["errors"]
    ]
    if result["status"] == "completed" and result["errors"]:
        raise BundleIntegrityError(
            path + ".errors must be empty for a completed result"
        )
    if (
        result["status"] in {"failed", "interrupted"}
        and not result["errors"]
    ):
        raise BundleIntegrityError(
            path + ".errors must be non-empty for failed or interrupted results"
        )
    if result["status"] == "skipped" and not result["warnings"]:
        raise BundleIntegrityError(
            path + ".warnings must explain a skipped result"
        )
    for name, metric in result["metrics"].items():
        if type(name) is not str or not name:
            raise BundleIntegrityError(path + ".metrics names must be strings")
        metric = _require_exact(
            metric, {"definition", "unit", "value"}, path + ".metrics." + name
        )
        if any(
            type(metric[field]) is not str or not metric[field]
            for field in ("definition", "unit")
        ):
            raise BundleIntegrityError("metric definition and unit must be strings")
        if metric["unit"] not in _PORTABLE_METRIC_UNITS:
            raise BundleIntegrityError(
                path + ".metrics." + name + ".unit is unsupported"
            )
        measured = metric["value"]
        if type(measured) not in (int, float) or (
            type(measured) is float and not math.isfinite(measured)
        ):
            raise BundleIntegrityError("metric value must be finite numeric data")
    ensure_artifact_safe(result)
    return copy.deepcopy(result)


def validate_bundle_document(value: Mapping[str, Any]) -> dict[str, Any]:
    """Strict repository-owned v1 schema validation."""

    document = _require_exact(value, {"manifest", "results"}, "bundle")
    manifest_value = document["manifest"]
    if type(manifest_value) is not dict:
        raise TypeError("manifest must be an object")
    required_manifest_fields = {
        "schema_version",
        "bundle_id",
        "workload",
        "compatibility",
        "metadata",
        "configurations",
        "cases",
    }
    allowed_manifest_fields = required_manifest_fields | {
        "artifacts",
        "source_validation",
        "current_run_attempt_id",
        "run_attempts",
    }
    if set(manifest_value) - allowed_manifest_fields:
        name = sorted(set(manifest_value) - allowed_manifest_fields)[0]
        raise BundleIntegrityError(
            "manifest." + name + " is missing or unsupported"
        )
    if required_manifest_fields - set(manifest_value):
        name = sorted(required_manifest_fields - set(manifest_value))[0]
        raise BundleIntegrityError(
            "manifest." + name + " is missing or unsupported"
        )
    manifest = copy.deepcopy(manifest_value)
    manifest.setdefault("artifacts", {})
    lifecycle_manifest_fields = {
        "current_run_attempt_id",
        "run_attempts",
    }
    present_lifecycle = set(manifest) & lifecycle_manifest_fields
    if present_lifecycle and present_lifecycle != lifecycle_manifest_fields:
        missing = sorted(lifecycle_manifest_fields - present_lifecycle)[0]
        raise BundleIntegrityError("manifest." + missing + " is required")
    if "source_validation" in manifest:
        manifest["source_validation"] = _source_validation_record(
            manifest["source_validation"]
        )
    if manifest["schema_version"] != BUNDLE_SCHEMA_VERSION:
        raise BundleIntegrityError("unsupported bundle schema_version")
    if type(manifest["bundle_id"]) is not str or not manifest["bundle_id"]:
        raise BundleIntegrityError("manifest.bundle_id is invalid")
    workload = _workload_record(
        manifest["workload"],
        "manifest.workload",
    )
    manifest["workload"] = workload
    compatibility = _require_exact(
        manifest["compatibility"], set(_COMPATIBILITY_FIELDS), "manifest.compatibility"
    )
    for field in _COMPATIBILITY_FIELDS:
        _require_digest(compatibility[field], "manifest.compatibility." + field)
    metadata = validate_metadata_record(manifest["metadata"])
    if any(metadata[field] != compatibility[field] for field in _COMPATIBILITY_FIELDS):
        raise BundleIntegrityError("manifest compatibility disagrees with metadata")
    if (
        type(manifest["configurations"]) is not dict
        or type(manifest["cases"]) is not dict
        or type(manifest["artifacts"]) is not dict
    ):
        raise TypeError(
            "manifest configurations, cases, and artifacts must be objects"
        )
    if present_lifecycle:
        current_attempt_id = manifest["current_run_attempt_id"]
        if (
            type(current_attempt_id) is not str
            or _ATTEMPT_RE.fullmatch(current_attempt_id) is None
        ):
            raise BundleIntegrityError(
                "manifest.current_run_attempt_id is invalid"
            )
        if type(manifest["run_attempts"]) is not dict:
            raise TypeError("manifest.run_attempts must be an object")
        if current_attempt_id not in manifest["run_attempts"]:
            raise BundleIntegrityError(
                "manifest.current_run_attempt_id is not indexed"
            )
        for attempt_id, attempt in manifest["run_attempts"].items():
            if (
                type(attempt_id) is not str
                or _ATTEMPT_RE.fullmatch(attempt_id) is None
            ):
                raise BundleIntegrityError(
                    "manifest.run_attempts key is invalid"
                )
            validated_attempt = _run_attempt_record(
                attempt,
                "manifest.run_attempts." + attempt_id,
            )
            if validated_attempt["run_attempt_id"] != attempt_id:
                raise BundleIntegrityError(
                    "run-attempt key and identity disagree"
                )
            manifest["run_attempts"][attempt_id] = validated_attempt
    for reference, record in manifest["artifacts"].items():
        normalized = _relative_reference(reference, "manifest.artifacts key")
        validated = _artifact_record(
            record,
            "manifest.artifacts." + normalized,
        )
        if validated["path"] != normalized:
            raise BundleIntegrityError(
                "artifact key and relative path disagree"
            )
    for digest, record in manifest["configurations"].items():
        if digest != _require_digest(digest, "manifest.configurations key"):
            raise BundleIntegrityError("configuration key is invalid")
        if _snapshot_record(record, "manifest.configurations." + digest)[
            "requested_config_digest"
        ] != digest:
            raise BundleIntegrityError("configuration key and digest disagree")
    for case_id, case in manifest["cases"].items():
        validated_case = _case_record(
            case,
            "manifest.cases." + case_id,
        )
        if validated_case["case_id"] != case_id:
            raise BundleIntegrityError("case key and case_id disagree")
        manifest["cases"][case_id] = validated_case
    results = _require_exact(
        document["results"],
        {"schema_version", "result_schema_version", "cases"},
        "results",
    )
    if results["schema_version"] != BUNDLE_SCHEMA_VERSION:
        raise BundleIntegrityError("unsupported results schema_version")
    if results["result_schema_version"] != PROFILE_RESULTS_SCHEMA_VERSION:
        raise BundleIntegrityError("unsupported result_schema_version")
    if type(results["cases"]) is not dict:
        raise TypeError("results.cases must be an object")
    if set(results["cases"]) != set(manifest["cases"]):
        raise BundleIntegrityError("manifest and results case indices disagree")
    for case_id, result in results["cases"].items():
        validated_result = _result_record(
            result,
            "results.cases." + case_id,
        )
        case = manifest["cases"][case_id]
        if (
            "measurement_segment_id" in case
            and validated_result["segment_id"]
            != case["measurement_segment_id"]
        ):
            raise BundleIntegrityError(
                "case and result measurement segments disagree"
            )
        if "run_attempt_id" in case:
            attempt = manifest["run_attempts"].get(case["run_attempt_id"])
            if attempt is None:
                raise BundleIntegrityError(
                    "case run attempt is not indexed"
                )
            matching_attempts = [
                item
                for item in attempt["case_attempts"]
                if item["case_id"] == case_id
                and item["measurement_segment_id"]
                == case["measurement_segment_id"]
            ]
            if len(matching_attempts) != 1:
                raise BundleIntegrityError(
                    "case measurement segment is not indexed by its attempt"
                )
            if matching_attempts[0]["status"] != validated_result["status"]:
                raise BundleIntegrityError(
                    "case-attempt and result statuses disagree"
                )
    if present_lifecycle:
        current_attempt = manifest["run_attempts"][
            manifest["current_run_attempt_id"]
        ]
        if current_attempt["status"] == "successful":
            expected = set(current_attempt["expected_case_ids"])
            if not expected <= set(manifest["cases"]):
                raise BundleIntegrityError(
                    "successful attempt is missing expected cases"
                )
            completed = {
                case_id
                for case_id in expected
                if results["cases"][case_id]["status"] == "completed"
            }
            if completed != set(current_attempt["completed_case_ids"]):
                raise BundleIntegrityError(
                    "successful attempt completed-case index disagrees"
                )
            if any(
                manifest["cases"][case_id].get("required", True)
                and case_id not in completed
                for case_id in expected
            ):
                raise BundleIntegrityError(
                    "successful attempt has an incomplete required case"
                )
            for path, media_type in _REQUIRED_SUCCESS_ARTIFACTS.items():
                artifact = manifest["artifacts"].get(path)
                if (
                    artifact is None
                    or artifact["path"] != path
                    or artifact["media_type"] != media_type
                ):
                    raise BundleIntegrityError(
                        "successful attempt is missing required artifact "
                        + path
                    )
    _validate_portable_bundle_paths(manifest)
    normalized = {"manifest": manifest, "results": results}
    json_native(normalized)
    ensure_artifact_safe(normalized)
    return copy.deepcopy(normalized)


def _schema_error(path: str, message: str) -> BundleIntegrityError:
    return BundleIntegrityError(path + " " + message)


def _schema_values_equal(left: Any, right: Any) -> bool:
    """Compare JSON values using JSON Schema instance-equality rules."""

    if type(left) is bool or type(right) is bool:
        return type(left) is bool and type(right) is bool and left == right
    if type(left) in (int, float) and type(right) in (int, float):
        return left == right
    if type(left) is not type(right):
        return False
    if type(left) is list:
        return len(left) == len(right) and all(
            _schema_values_equal(left_item, right_item)
            for left_item, right_item in zip(left, right, strict=True)
        )
    if type(left) is dict:
        return set(left) == set(right) and all(
            _schema_values_equal(left[key], right[key])
            for key in left
        )
    return left == right


def _validate_schema_node(
    value: Any,
    node: Mapping[str, Any],
    root: Mapping[str, Any],
    path: str,
) -> None:
    if "$ref" in node:
        reference = node["$ref"]
        if type(reference) is not str or not reference.startswith("#/$defs/"):
            raise _schema_error(path, "uses an unsupported schema reference")
        target = root["$defs"][reference.removeprefix("#/$defs/")]
        _validate_schema_node(value, target, root, path)
        return
    if "oneOf" in node:
        matches = 0
        for option in node["oneOf"]:
            try:
                _validate_schema_node(value, option, root, path)
            except (BundleIntegrityError, TypeError, ValueError):
                continue
            matches += 1
        if matches != 1:
            raise _schema_error(path, "must match exactly one schema branch")
    for child in node.get("allOf", ()):
        _validate_schema_node(value, child, root, path)
    if "if" in node:
        try:
            _validate_schema_node(value, node["if"], root, path)
        except (BundleIntegrityError, TypeError, ValueError):
            condition = False
        else:
            condition = True
        if condition and "then" in node:
            _validate_schema_node(value, node["then"], root, path)
        if not condition and "else" in node:
            _validate_schema_node(value, node["else"], root, path)
    if "const" in node and value != node["const"]:
        raise _schema_error(path, "does not equal its schema constant")
    if "enum" in node and value not in node["enum"]:
        raise _schema_error(path, "is not in its schema enum")

    expected_type = node.get("type")
    valid_type = {
        "object": type(value) is dict,
        "array": type(value) is list,
        "string": type(value) is str,
        "integer": type(value) is int,
        "number": type(value) in (int, float),
        "boolean": type(value) is bool,
        "null": value is None,
    }.get(expected_type, True)
    if not valid_type:
        raise _schema_error(path, "has the wrong JSON type")
    if type(value) is str:
        if len(value) < node.get("minLength", 0):
            raise _schema_error(path, "is shorter than minLength")
        if "pattern" in node and re.search(node["pattern"], value) is None:
            raise _schema_error(path, "does not match its schema pattern")
    if type(value) in (int, float) and not isinstance(value, bool):
        if "minimum" in node and value < node["minimum"]:
            raise _schema_error(path, "is below its schema minimum")
    if type(value) is dict:
        required = set(node.get("required", ()))
        missing = sorted(required - set(value))
        if missing:
            raise _schema_error(path + "." + missing[0], "is required")
        properties = node.get("properties", {})
        additional = node.get("additionalProperties", True)
        for key, item in value.items():
            child_path = path + "." + key
            if key in properties:
                _validate_schema_node(item, properties[key], root, child_path)
            elif additional is False:
                raise _schema_error(child_path, "is unsupported")
            elif type(additional) is dict:
                _validate_schema_node(item, additional, root, child_path)
        for key, dependencies in node.get("dependentRequired", {}).items():
            if key in value:
                missing_dependencies = sorted(set(dependencies) - set(value))
                if missing_dependencies:
                    raise _schema_error(
                        path + "." + missing_dependencies[0],
                        "is required by " + key,
                    )
        if len(value) < node.get("minProperties", 0):
            raise _schema_error(path, "has too few properties")
    if type(value) is list:
        if len(value) < node.get("minItems", 0):
            raise _schema_error(path, "has too few items")
        if "maxItems" in node and len(value) > node["maxItems"]:
            raise _schema_error(path, "has too many items")
        if node.get("uniqueItems") is True:
            for index, item in enumerate(value):
                if any(
                    _schema_values_equal(item, previous)
                    for previous in value[:index]
                ):
                    raise _schema_error(
                        path + "[" + str(index) + "]",
                        "duplicates an earlier item",
                    )
        if "items" in node:
            for index, item in enumerate(value):
                _validate_schema_node(
                    item,
                    node["items"],
                    root,
                    path + "[" + str(index) + "]",
                )


def validate_bundle_against_schema(
    value: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate a bundle using the checked-in dependency-free schema subset."""

    schema_text = (
        importlib.resources.files(
            "dreamgym.profiling.autonomous_driving.resources"
        )
        .joinpath("result_bundle_v1.schema.json")
        .read_text(encoding="utf-8")
    )
    schema = parse_strict_json_object(schema_text)
    detached = json_native(dict(value))
    _validate_schema_node(detached, schema, schema, "bundle")
    return copy.deepcopy(detached)


def _verify_reference(root: Path, reference: str, expected_sha256: str) -> None:
    path = _bundle_path(root, reference)
    if not path.is_file():
        raise BundleIntegrityError(reference + " is missing")
    if _sha256_bytes(path.read_bytes()) != expected_sha256:
        raise BundleIntegrityError(reference + " checksum mismatch")


_ARCHIVAL_BUNDLE_DIAGNOSTIC = (
    "profiling-v1 and profiling-v2 bundles are archival; regenerate with "
    "workload v3 or use the matching historical Dream Gym release for "
    "archival inspection."
)

_ARCHIVAL_WORKLOAD_VERSIONS = frozenset({
    "dreamgym-autonomous-driving-workload-v1",
    "dreamgym-autonomous-driving-workload-v2",
})


def _preflight_bundle_identity(path: str | Path) -> Path:
    """Reject recognized archival identity after reading only the manifest."""

    root = Path(path)
    if not root.is_dir() or root.is_symlink() or _has_reparse_point(root):
        raise BundleIntegrityError("bundle root must be a real directory")
    manifest_path = root / "manifest.json"
    if (
        not manifest_path.is_file()
        or manifest_path.is_symlink()
        or _has_reparse_point(manifest_path)
    ):
        raise BundleIntegrityError(
            "manifest.json must be a regular bundle file"
        )
    manifest = _strict_object(manifest_path)
    workload = manifest.get("workload")
    workload_version = (
        workload.get("workload_version")
        if isinstance(workload, Mapping)
        else None
    )
    if workload_version in _ARCHIVAL_WORKLOAD_VERSIONS:
        raise BundleCompatibilityError(_ARCHIVAL_BUNDLE_DIAGNOSTIC)
    return root


def _require_current_workload_identity(document: Mapping[str, Any]) -> None:
    """Reject archival or non-current executable workload identities."""

    from dreamgym.profiling.autonomous_driving.release import (
        RESULT_SCHEMA_RELEASE_ID,
        SUBMISSION_RELEASE_ID,
        TIMING_PROTOCOL_RELEASE_ID,
        WORKLOAD_RELEASE_ID,
    )
    from dreamgym.profiling.autonomous_driving.workloads import (
        WORKLOAD_VERSION,
    )

    workload = document["manifest"]["workload"]
    if workload["workload_version"] != WORKLOAD_VERSION:
        raise BundleCompatibilityError("bundle workload identity is not current")
    release_status = workload["release_status"]
    release_identity = workload.get("release_identity")
    classification = release_status["classification"]
    expected_status_and_identity = {
        "canonical": (
            {
                "classification": "canonical",
                "canonical_status": True,
                "submission_status": False,
            },
            {
                "workload_release_id": WORKLOAD_RELEASE_ID,
                "result_schema_release_id": RESULT_SCHEMA_RELEASE_ID,
                "timing_protocol_release_id": TIMING_PROTOCOL_RELEASE_ID,
            },
        ),
        "locked_submission": (
            {
                "classification": "locked_submission",
                "canonical_status": True,
                "submission_status": True,
            },
            {
                "workload_release_id": SUBMISSION_RELEASE_ID,
                "result_schema_release_id": RESULT_SCHEMA_RELEASE_ID,
                "timing_protocol_release_id": TIMING_PROTOCOL_RELEASE_ID,
            },
        ),
        "custom": (
            {
                "classification": "custom",
                "canonical_status": False,
                "submission_status": False,
            },
            {
                "workload_release_id": None,
                "result_schema_release_id": None,
                "timing_protocol_release_id": None,
            },
        ),
        "development": (
            {
                "classification": "development",
                "canonical_status": False,
                "submission_status": False,
            },
            {
                "workload_release_id": None,
                "result_schema_release_id": None,
                "timing_protocol_release_id": None,
            },
        ),
    }.get(classification)
    if (
        expected_status_and_identity is None
        or release_status != expected_status_and_identity[0]
        or release_identity != expected_status_and_identity[1]
    ):
        raise BundleCompatibilityError(
            "bundle workload identity is not current"
        )


def load_bundle(path: str | Path) -> dict[str, Any]:
    root = _preflight_bundle_identity(path)
    for index_name in ("results.json",):
        index = root / index_name
        if (
            not index.is_file()
            or index.is_symlink()
            or _has_reparse_point(index)
        ):
            raise BundleIntegrityError(index_name + " must be a regular bundle file")
    transaction_path = root / ".bundle-index-transaction.json"
    transaction = None
    if transaction_path.exists():
        if transaction_path.is_symlink() or _has_reparse_point(transaction_path):
            raise BundleIntegrityError("transaction marker cannot be a link")
        transaction = _strict_object(transaction_path)
    actual = {
        "manifest": _strict_object(root / "manifest.json"),
        "results": _strict_object(root / "results.json"),
    }
    if transaction is not None:
        transaction = _require_exact(
            transaction,
            {"previous", "next"},
            "transaction",
        )
        previous = validate_bundle_document(transaction["previous"])
        following = validate_bundle_document(transaction["next"])
        if actual == following:
            actual = following
        elif (
            actual["manifest"] in (previous["manifest"], following["manifest"])
            and actual["results"] in (previous["results"], following["results"])
        ):
            actual = previous
        else:
            raise BundleIntegrityError("index transaction cannot be recovered")
    document = validate_bundle_document(actual)
    _require_current_workload_identity(document)
    for snapshot in document["manifest"]["configurations"].values():
        _verify_reference(
            root,
            snapshot["requested_config_path"],
            snapshot["requested_file_sha256"],
        )
        requested = validate_snapshot(
            _strict_object(_bundle_path(root, snapshot["requested_config_path"]))
        )
        ensure_artifact_safe(requested)
        if canonical_snapshot_digest(requested) != snapshot["requested_config_digest"]:
            raise BundleIntegrityError("requested snapshot digest mismatch")
        if "resolved_config_path" in snapshot:
            _verify_reference(
                root,
                snapshot["resolved_config_path"],
                snapshot["resolved_file_sha256"],
            )
            resolved = validate_resolved_snapshot(
                _strict_object(_bundle_path(root, snapshot["resolved_config_path"]))
            )
            ensure_artifact_safe(resolved)
            try:
                expected_versions = _runtime_versions_from_metadata(
                    document["manifest"]["metadata"]
                )
            except BundleCompatibilityError as error:
                raise BundleIntegrityError(
                    "bundle metadata cannot bind resolved runtime versions"
                ) from error
            for name, expected_version in expected_versions.items():
                if not _runtime_version_matches_legacy_bundle_read(
                    name,
                    expected_version,
                    resolved["versions"][name],
                ):
                    raise BundleIntegrityError(
                        "resolved snapshot version "
                        + name
                        + " disagrees with bundle metadata"
                    )
            if canonical_snapshot_digest(resolved) != snapshot["resolved_config_digest"]:
                raise BundleIntegrityError("resolved snapshot digest mismatch")
            if resolved["requested_config_digest"] != snapshot["requested_config_digest"]:
                raise BundleIntegrityError("resolved snapshot link mismatch")
    for case in document["manifest"]["cases"].values():
        raw_arrays = None
        structured_payload = None
        if "snapshot" in case:
            indexed = document["manifest"]["configurations"].get(
                case["snapshot"]["requested_config_digest"]
            )
            if indexed != case["snapshot"]:
                raise BundleIntegrityError("case snapshot is not indexed exactly")
        if "raw_samples" in case:
            _verify_reference(
                root, case["raw_samples"]["path"], case["raw_samples"]["sha256"]
            )
            with np.load(
                _bundle_path(root, case["raw_samples"]["path"]), allow_pickle=False
            ) as archive:
                raw_arrays = {
                    name: _validate_array(name, archive[name]).copy()
                    for name in archive.files
                }
        if "structured_records" in case:
            artifact = case["structured_records"]
            _verify_reference(
                root,
                artifact["path"],
                artifact["sha256"],
            )
            structured_payload = _strict_object(
                _bundle_path(root, artifact["path"])
            )
            if (
                structured_payload.get("measurement_segment_id")
                != artifact["measurement_segment_id"]
            ):
                raise BundleIntegrityError(
                    "structured record measurement segment mismatch"
                )
            ensure_artifact_safe(structured_payload)
        _validate_case_evidence(
            case,
            document["results"]["cases"][case["case_id"]],
            raw_arrays,
            structured_payload,
        )
    for artifact in document["manifest"]["artifacts"].values():
        _verify_reference(root, artifact["path"], artifact["sha256"])
        _validate_text_artifact_payload(
            _bundle_path(root, artifact["path"]).read_bytes(),
            artifact["media_type"],
        )
    return document


def _validate_array(name: str, value: Any) -> np.ndarray:
    if type(name) is not str or _CASE_RE.fullmatch(name) is None:
        raise BundleIntegrityError("NPZ member name is unsafe")
    array = np.asarray(value)
    if (
        array.dtype.hasobject
        or array.dtype.fields is not None
        or array.dtype.metadata is not None
        or array.dtype.kind not in "biuf"
    ):
        raise BundleIntegrityError("NPZ arrays must use plain numeric dtypes")
    if array.dtype.kind == "f" and not np.isfinite(array).all():
        raise BundleIntegrityError("NPZ arrays must contain finite values")
    return array


_MPC_INVOCATION_FIELDS = {
    "phase",
    "index",
    "fixture_index",
    "fixture_digest",
    "policy_wall_time_ns",
    "policy_total_time_seconds",
    "road_horizon_time_seconds",
    "model_schedule_time_seconds",
    "policy_postprocessing_time_seconds",
    "outer_policy_time_seconds",
    "solver_status",
    "solver_status_code",
    "solver_usable",
    "solver_iterations",
    "solver_primal_residual",
    "solver_dual_residual",
    "formulation_time_seconds",
    "backend_setup_time_seconds",
    "backend_solve_time_seconds",
    "backend_run_time_seconds",
    "solver_postprocessing_time_seconds",
    "complete_solver_time_seconds",
    "complete_solver_time_ns",
    "decision_variable_count",
    "constraint_row_count",
    "hessian_nonzero_count",
    "constraint_matrix_nonzero_count",
    "fallback_mode",
    "fallback_action_used",
    "policy_failure",
    "exclusion_reason",
    "measurement_segment_id",
}
_RL_COMPLETE_WINDOW_FIELDS = {
    "start_transition",
    "end_transition",
    "transition_count",
    "start_vector_call",
    "end_vector_call",
    "start_update",
    "end_update",
    "update_count",
    "start_ns",
    "end_ns",
    "elapsed_ns",
    "effective_n_envs",
    "vector_call_count",
    "aggregate_transitions_per_second",
    "vector_calls_per_second",
    "measurement_segment_id",
}
_RL_PARTIAL_WINDOW_FIELDS = {
    "start_transition",
    "end_transition",
    "transition_count",
    "start_vector_call",
    "end_vector_call",
    "vector_call_count",
    "start_update",
    "end_update",
    "update_count",
    "start_ns",
    "end_ns",
    "elapsed_ns",
    "effective_n_envs",
    "complete",
    "headline_eligible",
    "measurement_segment_id",
}


def _evidence_integer(
    value: Any,
    path: str,
    *,
    minimum: int = 0,
) -> int:
    if type(value) is not int or value < minimum:
        raise BundleIntegrityError(
            path + " must be an integer >= " + str(minimum)
        )
    return value


def _evidence_number(
    value: Any,
    path: str,
    *,
    optional: bool = False,
) -> int | float | None:
    if value is None and optional:
        return None
    if type(value) not in (int, float) or not math.isfinite(float(value)):
        raise BundleIntegrityError(path + " must be finite numeric data")
    if value < 0:
        raise BundleIntegrityError(path + " must be non-negative")
    return value


def _portable_metric_value(
    result: Mapping[str, Any],
    name: str,
    unit: str,
    *,
    integer: bool = False,
) -> int | float:
    metric = result["metrics"].get(name)
    if not isinstance(metric, Mapping) or set(metric) != {
        "definition",
        "unit",
        "value",
    }:
        raise BundleIntegrityError(
            "result.metrics." + name + " is required for evidence"
        )
    expected_definition = "Native suite metric at metrics." + name + "."
    if (
        metric["definition"] != expected_definition
        or metric["unit"] != unit
    ):
        raise BundleIntegrityError(
            "result.metrics." + name + " has incompatible semantics"
        )
    measured = metric["value"]
    if integer and type(measured) is not int:
        raise BundleIntegrityError(
            "result.metrics." + name + " must be an integer"
        )
    return measured


def _validate_portable_metric(
    result: Mapping[str, Any],
    name: str,
    expected: int | float,
    unit: str,
    *,
    integer: bool = False,
    required: bool = True,
) -> None:
    if name not in result["metrics"] and not required:
        return
    if (
        _portable_metric_value(
            result,
            name,
            unit,
            integer=integer,
        )
        != expected
    ):
        raise BundleIntegrityError(
            "result.metrics." + name + " disagrees with evidence"
        )


_SUMMARY_METRIC_UNITS = {
    "sample_count": "count",
    "total_ns": "ns",
    "total_s": "s",
    "mean_ns": "ns",
    "median_ns": "ns",
    "min_ns": "ns",
    "max_ns": "ns",
    "p95_ns": "ns",
    "throughput_per_s": "1/s",
}


def _validate_summary_metrics(
    result: Mapping[str, Any],
    prefix: str,
    samples: list[int],
) -> None:
    summary = summarize_sample_ns(samples)
    for field, unit in _SUMMARY_METRIC_UNITS.items():
        name = prefix + "." + field
        expected = summary[field]
        if expected is None:
            if name in result["metrics"]:
                raise BundleIntegrityError(
                    "result.metrics." + name + " must be absent"
                )
            continue
        _validate_portable_metric(
            result,
            name,
            expected,
            unit,
            integer=field == "sample_count",
            required=False,
        )


def _validate_mpc_evidence(
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    sample_ns: np.ndarray,
    records: Mapping[str, Any],
) -> None:
    payload = _require_exact(
        records,
        {"mpc_invocations"},
        "structured_records.records",
    )
    invocations = payload["mpc_invocations"]
    if type(invocations) is not list:
        raise TypeError(
            "structured_records.records.mpc_invocations must be an array"
        )

    execution = case["execution_spec"]
    warmups = _evidence_integer(
        execution.get("warmup_iterations"),
        "case.execution_spec.warmup_iterations",
    )
    samples = _evidence_integer(
        execution.get("sample_count"),
        "case.execution_spec.sample_count",
        minimum=1,
    )
    repetitions = _evidence_integer(
        execution.get("repetitions"),
        "case.execution_spec.repetitions",
        minimum=1,
    )
    expected_phases = [
        ("cold", 0),
        *(
            ("warmup", index)
            for index in range(warmups * repetitions)
        ),
        *(
            ("measured", index)
            for index in range(samples * repetitions)
        ),
    ]
    if len(invocations) != len(expected_phases):
        raise BundleIntegrityError(
            "MPC invocation count disagrees with execution_spec"
        )

    projection = case["semantic_projection"]
    mpc = projection.get("mpc")
    fixture_sequence = (
        mpc.get("fixture_sequence")
        if isinstance(mpc, Mapping)
        else None
    )
    if not isinstance(fixture_sequence, Mapping):
        raise BundleIntegrityError(
            "case.semantic_projection.mpc.fixture_sequence is required"
        )
    sequence_length = _evidence_integer(
        fixture_sequence.get("sequence_length"),
        "case.semantic_projection.mpc.fixture_sequence.sequence_length",
        minimum=1,
    )
    fixture_digest = _require_digest(
        fixture_sequence.get("expected_fixture_digest"),
        "case.semantic_projection.mpc.fixture_sequence."
        "expected_fixture_digest",
    )
    segment_id = case["measurement_segment_id"]
    measured_ns: list[int] = []
    measured_records: list[Mapping[str, Any]] = []
    for ordinal, (value, expected_phase) in enumerate(
        zip(invocations, expected_phases, strict=True)
    ):
        path = (
            "structured_records.records.mpc_invocations["
            + str(ordinal)
            + "]"
        )
        record = _require_exact(value, _MPC_INVOCATION_FIELDS, path)
        if (record["phase"], record["index"]) != expected_phase:
            raise BundleIntegrityError(
                path + " phase/index disagrees with execution order"
            )
        if (
            record["measurement_segment_id"] != segment_id
            or record["fixture_index"] != ordinal % sequence_length
            or record["fixture_digest"] != fixture_digest
        ):
            raise BundleIntegrityError(
                path + " ownership or fixture identity disagrees"
            )
        _evidence_integer(record["fixture_index"], path + ".fixture_index")
        if record["phase"] != "warmup":
            _evidence_integer(
                record["policy_wall_time_ns"],
                path + ".policy_wall_time_ns",
            )
        elif record["policy_wall_time_ns"] is not None:
            raise BundleIntegrityError(
                path + ".policy_wall_time_ns must be null for warmup"
            )
        policy_total = _evidence_number(
            record["policy_total_time_seconds"],
            path + ".policy_total_time_seconds",
        )
        for name in (
            "road_horizon_time_seconds",
            "model_schedule_time_seconds",
            "policy_postprocessing_time_seconds",
            "backend_setup_time_seconds",
            "backend_solve_time_seconds",
            "backend_run_time_seconds",
            "solver_primal_residual",
            "solver_dual_residual",
        ):
            _evidence_number(
                record[name],
                path + "." + name,
                optional=True,
            )
        formulation = _evidence_number(
            record["formulation_time_seconds"],
            path + ".formulation_time_seconds",
        )
        postprocessing = _evidence_number(
            record["solver_postprocessing_time_seconds"],
            path + ".solver_postprocessing_time_seconds",
        )
        complete_seconds = _evidence_number(
            record["complete_solver_time_seconds"],
            path + ".complete_solver_time_seconds",
        )
        complete_ns = _evidence_integer(
            record["complete_solver_time_ns"],
            path + ".complete_solver_time_ns",
        )
        outer = _evidence_number(
            record["outer_policy_time_seconds"],
            path + ".outer_policy_time_seconds",
        )
        if complete_ns != int(round(float(complete_seconds) * 1_000_000_000.0)):
            raise BundleIntegrityError(
                path + " complete solver seconds/ns disagree"
            )
        if outer != max(0.0, float(policy_total) - float(complete_seconds)):
            raise BundleIntegrityError(
                path + " outer-policy timing disagrees"
            )
        if float(complete_seconds) < float(formulation) + float(postprocessing):
            raise BundleIntegrityError(
                path + " complete solver time does not enclose local timings"
            )
        if record["solver_usable"] is not True:
            raise BundleIntegrityError(path + " solver must be usable")
        if (
            type(record["solver_status"]) is not str
            or not record["solver_status"]
        ):
            raise BundleIntegrityError(path + ".solver_status is invalid")
        status_code = _evidence_integer(
            record["solver_status_code"],
            path + ".solver_status_code",
        )
        if status_code not in (1, 2):
            raise BundleIntegrityError(
                path + ".solver_status_code cannot be usable"
            )
        if record["solver_iterations"] is not None:
            _evidence_integer(
                record["solver_iterations"],
                path + ".solver_iterations",
            )
        for name in (
            "decision_variable_count",
            "constraint_row_count",
            "hessian_nonzero_count",
            "constraint_matrix_nonzero_count",
        ):
            _evidence_integer(record[name], path + "." + name)
        if (
            record["fallback_mode"] is not None
            or record["fallback_action_used"] is not False
            or record["policy_failure"] is not None
            or record["exclusion_reason"] is not None
        ):
            raise BundleIntegrityError(
                path + " is not a successful canonical invocation"
            )
        if record["phase"] == "measured":
            measured_ns.append(complete_ns)
            measured_records.append(record)
    if measured_ns != sample_ns.tolist():
        raise BundleIntegrityError(
            "MPC measured invocation timings disagree with sample_ns"
        )
    for prefix in (
        "complete_solver_time",
        "warmed_complete_solver_time",
    ):
        _validate_summary_metrics(result, prefix, measured_ns)
    policy_samples = [
        int(
            round(
                float(record["policy_total_time_seconds"])
                * 1_000_000_000.0
            )
        )
        for record in measured_records
    ]
    for prefix in (
        "policy_total_time",
        "warmed_policy_total_time",
    ):
        _validate_summary_metrics(result, prefix, policy_samples)
    _validate_summary_metrics(
        result,
        "warmed_policy_wall_time",
        [
            int(record["policy_wall_time_ns"])
            for record in measured_records
        ],
    )
    cold = invocations[0]
    _validate_portable_metric(
        result,
        "cold_complete_solver_time_seconds",
        cold["complete_solver_time_seconds"],
        "s",
        required=False,
    )
    _validate_portable_metric(
        result,
        "cold_policy_total_time_seconds",
        cold["policy_total_time_seconds"],
        "s",
        required=False,
    )
    median_ns = summarize_sample_ns(measured_ns)["median_ns"]
    _validate_portable_metric(
        result,
        "post_warmup_median_complete_solver_time_seconds",
        float(median_ns) / 1_000_000_000.0,
        "s",
        required=False,
    )
    _validate_portable_metric(
        result,
        "headline.median_complete_solver_time_ns",
        median_ns,
        "ns",
        required=False,
    )


def _validate_rl_complete_window(
    value: Any,
    path: str,
    *,
    segment_id: str,
    n_envs: int,
    minimum_transitions: int,
) -> dict[str, Any]:
    window = _require_exact(value, _RL_COMPLETE_WINDOW_FIELDS, path)
    for name in (
        "start_transition",
        "start_vector_call",
        "start_update",
        "start_ns",
    ):
        _evidence_integer(window[name], path + "." + name)
    for start, end, count in (
        ("start_transition", "end_transition", "transition_count"),
        ("start_vector_call", "end_vector_call", "vector_call_count"),
        ("start_update", "end_update", "update_count"),
        ("start_ns", "end_ns", "elapsed_ns"),
    ):
        end_value = _evidence_integer(
            window[end],
            path + "." + end,
        )
        count_value = _evidence_integer(
            window[count],
            path + "." + count,
            minimum=1,
        )
        if end_value - window[start] != count_value:
            raise BundleIntegrityError(
                path + "." + count + " disagrees with endpoints"
            )
    if (
        window["measurement_segment_id"] != segment_id
        or window["effective_n_envs"] != n_envs
    ):
        raise BundleIntegrityError(path + " ownership/vectorization disagrees")
    if (
        window["transition_count"]
        != window["vector_call_count"] * n_envs
        or window["transition_count"] < minimum_transitions
    ):
        raise BundleIntegrityError(
            path + " transition/vector-call semantics disagree"
        )
    expected_rate = (
        window["transition_count"]
        * 1_000_000_000.0
        / window["elapsed_ns"]
    )
    expected_vector_rate = (
        window["vector_call_count"]
        * 1_000_000_000.0
        / window["elapsed_ns"]
    )
    if (
        window["aggregate_transitions_per_second"] != expected_rate
        or window["vector_calls_per_second"] != expected_vector_rate
    ):
        raise BundleIntegrityError(path + " derived rates disagree")
    return window


def _validate_rl_partial_window(
    value: Any,
    path: str,
    *,
    segment_id: str,
    n_envs: int,
) -> dict[str, Any]:
    window = _require_exact(value, _RL_PARTIAL_WINDOW_FIELDS, path)
    for name in (
        "start_transition",
        "start_vector_call",
        "start_update",
        "start_ns",
    ):
        _evidence_integer(window[name], path + "." + name)
    for start, end, count in (
        ("start_transition", "end_transition", "transition_count"),
        ("start_vector_call", "end_vector_call", "vector_call_count"),
        ("start_update", "end_update", "update_count"),
        ("start_ns", "end_ns", "elapsed_ns"),
    ):
        end_value = _evidence_integer(window[end], path + "." + end)
        count_value = _evidence_integer(window[count], path + "." + count)
        if end_value < window[start] or end_value - window[start] != count_value:
            raise BundleIntegrityError(
                path + "." + count + " disagrees with endpoints"
            )
    if (
        window["measurement_segment_id"] != segment_id
        or window["effective_n_envs"] != n_envs
        or window["transition_count"]
        != window["vector_call_count"] * n_envs
        or window["complete"] is not False
        or window["headline_eligible"] is not False
    ):
        raise BundleIntegrityError(path + " partial-window semantics disagree")
    return window


def _validate_rl_evidence(
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    sample_ns: np.ndarray,
    records: Mapping[str, Any],
) -> None:
    payload = _require_exact(
        records,
        {"rl_complete_windows", "rl_partial_final_window"},
        "structured_records.records",
    )
    windows = payload["rl_complete_windows"]
    if type(windows) is not list or not windows:
        raise BundleIntegrityError(
            "structured_records.records.rl_complete_windows "
            "must be a non-empty array"
        )
    vectorization = case["semantic_projection"].get("vectorization")
    if not isinstance(vectorization, Mapping):
        raise BundleIntegrityError(
            "case.semantic_projection.vectorization is required"
        )
    n_envs = _evidence_integer(
        vectorization.get("effective_n_envs"),
        "case.semantic_projection.vectorization.effective_n_envs",
        minimum=1,
    )
    steady = case["execution_spec"].get("steady_state_windows")
    if not isinstance(steady, Mapping):
        raise BundleIntegrityError(
            "case.execution_spec.steady_state_windows is required"
        )
    minimum = _evidence_integer(
        steady.get("minimum_transition_count"),
        "case.execution_spec.steady_state_windows.minimum_transition_count",
        minimum=1,
    )
    required = _evidence_integer(
        steady.get("required_complete_window_count"),
        "case.execution_spec.steady_state_windows."
        "required_complete_window_count",
        minimum=1,
    )
    if len(windows) < required or len(windows) != len(sample_ns):
        raise BundleIntegrityError(
            "RL complete-window count disagrees with execution/raw evidence"
        )
    recorded_required = _portable_metric_value(
        result,
        "training.required_complete_window_count",
        "count",
        integer=True,
    )
    if (
        recorded_required != required
        if "imported_from" not in case
        else recorded_required < required
    ) or recorded_required > len(windows):
        raise BundleIntegrityError(
            "result.metrics.training.required_complete_window_count "
            "disagrees with RL evidence"
        )
    metric_expectations = (
        ("training.complete_window_count", len(windows), "count"),
        (
            "training.minimum_window_transition_count",
            minimum,
            "count",
        ),
        ("vectorization.effective_n_envs", n_envs, "value"),
        (
            "actual_transitions",
            result["actual_completed_transitions"],
            "count",
        ),
    )
    for name, expected, unit in metric_expectations:
        _validate_portable_metric(
            result,
            name,
            expected,
            unit,
            integer=True,
        )

    segment_id = case["measurement_segment_id"]
    validated = [
        _validate_rl_complete_window(
            value,
            "structured_records.records.rl_complete_windows["
            + str(index)
            + "]",
            segment_id=segment_id,
            n_envs=n_envs,
            minimum_transitions=minimum,
        )
        for index, value in enumerate(windows)
    ]
    for previous, following in zip(validated, validated[1:]):
        for end, start in (
            ("end_transition", "start_transition"),
            ("end_vector_call", "start_vector_call"),
            ("end_update", "start_update"),
            ("end_ns", "start_ns"),
        ):
            if previous[end] != following[start]:
                raise BundleIntegrityError(
                    "RL complete windows are not contiguous"
                )
    if [window["elapsed_ns"] for window in validated] != sample_ns.tolist():
        raise BundleIntegrityError(
            "RL complete-window elapsed_ns values disagree with sample_ns"
        )
    _validate_portable_metric(
        result,
        "training.median_transitions_per_second",
        statistics.median(
            [
                window["aggregate_transitions_per_second"]
                for window in validated
            ]
        ),
        "1/s",
        required=False,
    )
    _validate_portable_metric(
        result,
        "training.median_vector_calls_per_second",
        statistics.median(
            [window["vector_calls_per_second"] for window in validated]
        ),
        "1/s",
        required=False,
    )

    partial_value = payload["rl_partial_final_window"]
    actual = result["actual_completed_transitions"]
    final = validated[-1]
    if partial_value is None:
        if final["end_transition"] != actual:
            raise BundleIntegrityError(
                "null RL partial window does not reach actual transitions"
            )
        return
    partial = _validate_rl_partial_window(
        partial_value,
        "structured_records.records.rl_partial_final_window",
        segment_id=segment_id,
        n_envs=n_envs,
    )
    for end, start in (
        ("end_transition", "start_transition"),
        ("end_vector_call", "start_vector_call"),
        ("end_update", "start_update"),
        ("end_ns", "start_ns"),
    ):
        if final[end] != partial[start]:
            raise BundleIntegrityError(
                "RL partial window is not contiguous with complete evidence"
            )
    if partial["end_transition"] != actual:
        raise BundleIntegrityError(
            "RL partial window disagrees with actual completed transitions"
        )


def _validate_failed_mpc_evidence(
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    records: Mapping[str, Any],
) -> None:
    del result
    payload = _require_exact(
        records,
        {"mpc_invocations"},
        "structured_records.records",
    )
    invocations = payload["mpc_invocations"]
    if type(invocations) is not list or not invocations:
        raise BundleIntegrityError(
            "failed MPC evidence must contain invocation records"
        )
    execution = case["execution_spec"]
    warmups = _evidence_integer(
        execution.get("warmup_iterations"),
        "case.execution_spec.warmup_iterations",
    )
    samples = _evidence_integer(
        execution.get("sample_count"),
        "case.execution_spec.sample_count",
        minimum=1,
    )
    repetitions = _evidence_integer(
        execution.get("repetitions"),
        "case.execution_spec.repetitions",
        minimum=1,
    )
    expected_phases = [
        ("cold", 0),
        *(
            ("warmup", index)
            for index in range(warmups * repetitions)
        ),
        *(
            ("measured", index)
            for index in range(samples * repetitions)
        ),
    ]
    if len(invocations) > len(expected_phases):
        raise BundleIntegrityError(
            "failed MPC invocation count exceeds execution_spec"
        )
    mpc = case["semantic_projection"].get("mpc")
    fixture_sequence = (
        mpc.get("fixture_sequence")
        if isinstance(mpc, Mapping)
        else None
    )
    if not isinstance(fixture_sequence, Mapping):
        raise BundleIntegrityError(
            "case.semantic_projection.mpc.fixture_sequence is required"
        )
    sequence_length = _evidence_integer(
        fixture_sequence.get("sequence_length"),
        "case.semantic_projection.mpc.fixture_sequence.sequence_length",
        minimum=1,
    )
    fixture_digest = _require_digest(
        fixture_sequence.get("expected_fixture_digest"),
        "case.semantic_projection.mpc.fixture_sequence."
        "expected_fixture_digest",
    )
    segment_id = case["measurement_segment_id"]
    optional_numbers = (
        "policy_total_time_seconds",
        "road_horizon_time_seconds",
        "model_schedule_time_seconds",
        "policy_postprocessing_time_seconds",
        "outer_policy_time_seconds",
        "solver_primal_residual",
        "solver_dual_residual",
        "formulation_time_seconds",
        "backend_setup_time_seconds",
        "backend_solve_time_seconds",
        "backend_run_time_seconds",
        "solver_postprocessing_time_seconds",
        "complete_solver_time_seconds",
    )
    optional_integers = (
        "policy_wall_time_ns",
        "solver_status_code",
        "solver_iterations",
        "complete_solver_time_ns",
        "decision_variable_count",
        "constraint_row_count",
        "hessian_nonzero_count",
        "constraint_matrix_nonzero_count",
    )
    for ordinal, value in enumerate(invocations):
        path = (
            "structured_records.records.mpc_invocations["
            + str(ordinal)
            + "]"
        )
        record = _require_exact(value, _MPC_INVOCATION_FIELDS, path)
        _evidence_integer(record["index"], path + ".index")
        _evidence_integer(record["fixture_index"], path + ".fixture_index")
        if (record["phase"], record["index"]) != expected_phases[ordinal]:
            raise BundleIntegrityError(
                path + " phase/index disagrees with execution order"
            )
        if (
            record["measurement_segment_id"] != segment_id
            or record["fixture_index"] != ordinal % sequence_length
            or record["fixture_digest"] != fixture_digest
        ):
            raise BundleIntegrityError(
                path + " ownership or fixture identity disagrees"
            )
        for name in optional_numbers:
            _evidence_number(
                record[name],
                path + "." + name,
                optional=True,
            )
        for name in optional_integers:
            if record[name] is not None:
                _evidence_integer(record[name], path + "." + name)
        if type(record["solver_usable"]) is not bool:
            raise TypeError(path + ".solver_usable must be a boolean")
        if (
            record["solver_usable"]
            and record["solver_status_code"] not in (1, 2)
        ):
            raise BundleIntegrityError(
                path + ".solver_status_code cannot be usable"
            )
        if record["solver_status_code"] is not None and (
            type(record["solver_status"]) is not str
            or not record["solver_status"]
        ):
            raise BundleIntegrityError(path + ".solver_status is invalid")
        if type(record["fallback_action_used"]) is not bool:
            raise TypeError(
                path + ".fallback_action_used must be a boolean"
            )
        if record["fallback_mode"] is not None and (
            type(record["fallback_mode"]) is not str
            or not record["fallback_mode"]
        ):
            raise BundleIntegrityError(path + ".fallback_mode is invalid")
        if record["policy_failure"] is not None and not isinstance(
            record["policy_failure"],
            Mapping,
        ):
            raise TypeError(path + ".policy_failure must be an object or null")
        if record["exclusion_reason"] is not None and (
            type(record["exclusion_reason"]) is not str
            or not record["exclusion_reason"]
        ):
            raise BundleIntegrityError(path + ".exclusion_reason is invalid")
        complete_seconds = record["complete_solver_time_seconds"]
        complete_ns = record["complete_solver_time_ns"]
        if (
            complete_seconds is not None
            and complete_ns is not None
            and complete_ns
            != int(round(float(complete_seconds) * 1_000_000_000.0))
        ):
            raise BundleIntegrityError(
                path + " complete solver seconds/ns disagree"
            )


def _validate_failed_rl_evidence(
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    records: Mapping[str, Any],
) -> None:
    payload = _require_exact(
        records,
        {"rl_complete_windows", "rl_partial_final_window"},
        "structured_records.records",
    )
    windows = payload["rl_complete_windows"]
    if type(windows) is not list:
        raise TypeError(
            "structured_records.records.rl_complete_windows "
            "must be an array"
        )
    vectorization = case["semantic_projection"].get("vectorization")
    if not isinstance(vectorization, Mapping):
        raise BundleIntegrityError(
            "case.semantic_projection.vectorization is required"
        )
    n_envs = _evidence_integer(
        vectorization.get("effective_n_envs"),
        "case.semantic_projection.vectorization.effective_n_envs",
        minimum=1,
    )
    steady = case["execution_spec"].get("steady_state_windows")
    if not isinstance(steady, Mapping):
        raise BundleIntegrityError(
            "case.execution_spec.steady_state_windows is required"
        )
    minimum = _evidence_integer(
        steady.get("minimum_transition_count"),
        "case.execution_spec.steady_state_windows.minimum_transition_count",
        minimum=1,
    )
    required = _evidence_integer(
        steady.get("required_complete_window_count"),
        "case.execution_spec.steady_state_windows."
        "required_complete_window_count",
        minimum=1,
    )
    if len(windows) >= required:
        raise BundleIntegrityError(
            "failed RL evidence satisfies the complete-window requirement"
        )
    for name, expected, unit in (
        ("training.complete_window_count", len(windows), "count"),
        (
            "training.required_complete_window_count",
            required,
            "count",
        ),
        (
            "training.minimum_window_transition_count",
            minimum,
            "count",
        ),
        ("vectorization.effective_n_envs", n_envs, "value"),
        (
            "actual_transitions",
            result["actual_completed_transitions"],
            "count",
        ),
    ):
        _validate_portable_metric(
            result,
            name,
            expected,
            unit,
            integer=True,
        )
    for name in (
        "training.median_transitions_per_second",
        "training.median_vector_calls_per_second",
    ):
        if name in result["metrics"]:
            raise BundleIntegrityError(
                "failed RL evidence cannot publish " + name
            )
    segment_id = case["measurement_segment_id"]
    validated = [
        _validate_rl_complete_window(
            value,
            "structured_records.records.rl_complete_windows["
            + str(index)
            + "]",
            segment_id=segment_id,
            n_envs=n_envs,
            minimum_transitions=minimum,
        )
        for index, value in enumerate(windows)
    ]
    for previous, following in zip(validated, validated[1:]):
        for end, start in (
            ("end_transition", "start_transition"),
            ("end_vector_call", "start_vector_call"),
            ("end_update", "start_update"),
            ("end_ns", "start_ns"),
        ):
            if previous[end] != following[start]:
                raise BundleIntegrityError(
                    "RL complete windows are not contiguous"
                )
    partial_value = payload["rl_partial_final_window"]
    if not validated and partial_value is None:
        raise BundleIntegrityError("failed RL evidence contains no records")
    partial = (
        None
        if partial_value is None
        else _validate_rl_partial_window(
            partial_value,
            "structured_records.records.rl_partial_final_window",
            segment_id=segment_id,
            n_envs=n_envs,
        )
    )
    if validated and partial is not None:
        final = validated[-1]
        for end, start in (
            ("end_transition", "start_transition"),
            ("end_vector_call", "start_vector_call"),
            ("end_update", "start_update"),
            ("end_ns", "start_ns"),
        ):
            if final[end] != partial[start]:
                raise BundleIntegrityError(
                    "RL partial window is not contiguous with complete evidence"
                )
    final_transition = (
        partial["end_transition"]
        if partial is not None
        else validated[-1]["end_transition"]
    )
    if final_transition != result["actual_completed_transitions"]:
        raise BundleIntegrityError(
            "failed RL evidence disagrees with actual transitions"
        )


def _structured_evidence_records(
    case: Mapping[str, Any],
    structured_records: Mapping[str, Any],
) -> Mapping[str, Any]:
    envelope = _require_exact(
        structured_records,
        {"schema_version", "measurement_segment_id", "records"},
        "structured_records",
    )
    if (
        envelope["schema_version"] != STRUCTURED_RECORDS_SCHEMA_VERSION
        or envelope["measurement_segment_id"]
        != case["measurement_segment_id"]
        or not isinstance(envelope["records"], Mapping)
    ):
        raise BundleIntegrityError(
            "structured record schema or measurement ownership disagrees"
        )
    return envelope["records"]


def _validate_case_evidence(
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    raw_samples: Mapping[str, np.ndarray] | None,
    structured_records: Mapping[str, Any] | None,
) -> None:
    """Validate authoritative v1 MPC/RL evidence against case identity."""

    if (
        "run_attempt_id" not in case
        or case["suite"] not in {"mpc", "rl"}
    ):
        return
    if result["status"] == "interrupted":
        if raw_samples is not None or structured_records is not None:
            raise BundleIntegrityError(
                "interrupted MPC/RL evidence must discard partial records"
            )
        return
    if result["status"] == "failed":
        if raw_samples is not None:
            raise BundleIntegrityError(
                "failed MPC/RL evidence cannot retain raw timing samples"
            )
        if structured_records is None:
            return
        records = _structured_evidence_records(case, structured_records)
        validator = (
            _validate_failed_mpc_evidence
            if case["suite"] == "mpc"
            else _validate_failed_rl_evidence
        )
        validator(case, result, records)
        return
    if result["status"] != "completed":
        return
    if raw_samples is None or set(raw_samples) != {"sample_ns"}:
        raise BundleIntegrityError(
            "completed lifecycle MPC/RL evidence requires exactly sample_ns"
        )
    sample_ns = raw_samples["sample_ns"]
    if (
        sample_ns.ndim != 1
        or sample_ns.dtype.kind not in "iu"
        or len(sample_ns) == 0
        or bool(np.any(sample_ns < 0))
    ):
        raise BundleIntegrityError(
            "sample_ns must be a non-empty one-dimensional "
            "non-negative-integer array"
        )
    if structured_records is None:
        raise BundleIntegrityError(
            "completed lifecycle MPC/RL evidence requires structured records"
        )
    records = _structured_evidence_records(case, structured_records)
    validator = (
        _validate_mpc_evidence
        if case["suite"] == "mpc"
        else _validate_rl_evidence
    )
    validator(case, result, sample_ns, records)


class BundleWriter:
    """The sole parent-process owner of one destination bundle."""

    def __init__(
        self,
        path: Path,
        *,
        live_metadata: Mapping[str, Any],
        workload: Mapping[str, Any],
        source_validation: Mapping[str, Any] | None = None,
    ):
        path = Path(path)
        self.path = path
        loaded = load_bundle(path)
        validated_live = validate_metadata_record(live_metadata)
        if dict(workload) != loaded["manifest"]["workload"]:
            raise BundleCompatibilityError("writer workload is incompatible")
        supplied_source_validation = (
            None
            if source_validation is None
            else _source_validation_record(source_validation)
        )
        if (
            loaded["manifest"].get("source_validation")
            != supplied_source_validation
        ):
            raise BundleCompatibilityError(
                "writer source validation is incompatible"
            )
        if any(
            validated_live[field]
            != loaded["manifest"]["compatibility"][field]
            for field in _DURABLE_COMPATIBILITY_FIELDS
        ):
            raise BundleCompatibilityError("writer live runtime is incompatible")
        self._live_compatibility = {
            field: validated_live[field] for field in _COMPATIBILITY_FIELDS
        }
        self._live_metadata = live_metadata
        for index_name in (
            "manifest.json",
            "results.json",
            ".bundle-index-transaction.json",
        ):
            _remove_atomic_temps(path / index_name)
        transaction_path = path / ".bundle-index-transaction.json"
        if transaction_path.exists():
            transaction = _require_exact(
                _strict_object(transaction_path),
                {"previous", "next"},
                "transaction",
            )
            previous = validate_bundle_document(transaction["previous"])
            following = validate_bundle_document(transaction["next"])
            _atomic_json(path / "manifest.json", loaded["manifest"])
            _atomic_json(path / "results.json", loaded["results"])
            if loaded == previous:
                _remove_case_evidence(
                    path,
                    _case_evidence_paths(following)
                    - _case_evidence_paths(previous),
                )
            transaction_path.unlink(missing_ok=True)
            loaded = load_bundle(path)
        self._manifest = loaded["manifest"]
        self._results = loaded["results"]

    @property
    def bundle_id(self) -> str:
        return self._manifest["bundle_id"]

    def observe_rl_device(
        self,
        *,
        requested_device: str,
        observed_device: str,
    ) -> dict[str, Any]:
        """Verify, or once finalize, the bundle's model-observed RL device."""

        try:
            metadata, changed = _observe_collected_rl_device(
                self._live_metadata,
                requested_device=requested_device,
                observed_device=observed_device,
            )
        except (TypeError, ValueError) as error:
            raise BundleCompatibilityError(
                "model-observed RL device is incompatible with bundle metadata"
            ) from error
        if not changed:
            return validate_metadata_record(metadata)
        validated = validate_metadata_record(metadata)
        previous_live_session = self._live_compatibility[
            "live_session_fingerprint"
        ]
        manifest = copy.deepcopy(self._manifest)
        manifest["metadata"] = validated
        manifest["compatibility"] = {
            field: validated[field] for field in _COMPATIBILITY_FIELDS
        }
        if validated["rl_device"]["requested"] == "auto":
            for case in manifest["cases"].values():
                case["eligibility"] = {
                    "semantic_reuse_import": False,
                    "sample_aggregation": False,
                }
                if (
                    case.get("live_session_fingerprint")
                    == previous_live_session
                ):
                    case["live_session_fingerprint"] = validated[
                        "live_session_fingerprint"
                    ]
        self._save_manifest(manifest)
        self._live_metadata = metadata
        self._live_compatibility = {
            field: validated[field] for field in _COMPATIBILITY_FIELDS
        }
        return copy.deepcopy(validated)

    @classmethod
    def create(
        cls,
        destination: str | Path,
        *,
        workload: Mapping[str, Any],
        metadata: Mapping[str, Any],
        source_validation: Mapping[str, Any] | None = None,
    ) -> "BundleWriter":
        path = Path(destination)
        if path.exists():
            if not path.is_dir() or any(path.iterdir()):
                raise FileExistsError("bundle destination already exists and is nonempty")
            if path.is_symlink() or _has_reparse_point(path):
                raise BundleIntegrityError("bundle destination cannot be a link")
        else:
            path.mkdir(parents=True)
        validated_metadata = validate_metadata_record(metadata)
        compatibility = {
            field: validated_metadata[field] for field in _COMPATIBILITY_FIELDS
        }
        manifest = {
            "schema_version": BUNDLE_SCHEMA_VERSION,
            "bundle_id": uuid.uuid4().hex,
            "workload": copy.deepcopy(dict(workload)),
            "compatibility": compatibility,
            "metadata": validated_metadata,
            "configurations": {},
            "cases": {},
            "artifacts": {},
        }
        if source_validation is not None:
            manifest["source_validation"] = _source_validation_record(
                source_validation
            )
        results = {
            "schema_version": BUNDLE_SCHEMA_VERSION,
            "result_schema_version": PROFILE_RESULTS_SCHEMA_VERSION,
            "cases": {},
        }
        validate_bundle_document({"manifest": manifest, "results": results})
        _atomic_json(path / "manifest.json", manifest)
        _atomic_json(path / "results.json", results)
        return cls(
            path,
            live_metadata=metadata,
            workload=manifest["workload"],
            source_validation=manifest.get("source_validation"),
        )

    def _save_manifest(self, manifest: dict[str, Any]) -> None:
        validate_bundle_document({"manifest": manifest, "results": self._results})
        _atomic_json(self.path / "manifest.json", manifest)
        self._manifest = manifest

    def persist_artifact(
        self,
        relative_path: str,
        payload: bytes,
        *,
        media_type: str,
    ) -> dict[str, str]:
        """Atomically persist one checksummed renderer artifact."""

        reference = _relative_reference(relative_path, "artifact.path")
        if type(payload) is not bytes:
            raise TypeError("artifact payload must be bytes")
        if type(media_type) is not str or not media_type.strip():
            raise ValueError("artifact media_type must be non-empty")
        record = {
            "path": reference,
            "media_type": media_type,
            "sha256": _sha256_bytes(payload),
        }
        manifest = copy.deepcopy(self._manifest)
        manifest["artifacts"][reference] = record
        _validate_portable_bundle_paths(manifest)
        _validate_text_artifact_payload(payload, media_type)
        destination = _bundle_path(self.path, reference)
        previous_payload = (
            destination.read_bytes() if destination.exists() else None
        )
        try:
            _atomic_bytes(destination, payload)
            self._save_manifest(manifest)
        except BaseException:
            if previous_payload is None:
                destination.unlink(missing_ok=True)
            else:
                _atomic_bytes(destination, previous_payload)
            raise
        return copy.deepcopy(record)

    def persist_requested_config(
        self, snapshot: Mapping[str, Any]
    ) -> dict[str, Any]:
        validated = validate_snapshot(dict(snapshot))
        if validated.get("snapshot_type") != "requested":
            raise ValueError("requested snapshot must have snapshot_type requested")
        ensure_artifact_safe(validated)
        digest = canonical_snapshot_digest(validated)
        relative = "training_configs/" + digest + "/config.json"
        _validate_prospective_configuration_paths(
            self._manifest,
            digest,
            {"requested_config_path": relative},
        )
        destination = _bundle_path(self.path, relative)
        checksum = _commit_snapshot(destination, validated)
        record = {
            "requested_config_path": relative,
            "requested_config_digest": digest,
            "requested_file_sha256": checksum,
        }
        existing = self._manifest["configurations"].get(digest)
        if existing is not None:
            existing_requested = {
                key: existing[key] for key in record
            }
            if existing_requested != record:
                raise BundleIntegrityError("requested configuration index conflicts")
            return copy.deepcopy(record)
        manifest = copy.deepcopy(self._manifest)
        manifest["configurations"][digest] = record
        self._save_manifest(manifest)
        return copy.deepcopy(record)

    def persist_resolved_config(
        self,
        requested_record: Mapping[str, Any],
        snapshot: Mapping[str, Any],
    ) -> dict[str, Any]:
        requested = _snapshot_record(
            dict(requested_record), "requested_record"
        )
        if "resolved_config_path" in requested:
            requested = {
                key: requested[key]
                for key in (
                    "requested_config_path",
                    "requested_config_digest",
                    "requested_file_sha256",
                )
            }
        validated = validate_resolved_snapshot(dict(snapshot))
        ensure_artifact_safe(validated)
        _validate_resolved_runtime_versions(
            validated,
            _runtime_versions_from_metadata(self._manifest["metadata"]),
        )
        if (
            validated["requested_config_digest"]
            != requested["requested_config_digest"]
        ):
            raise BundleCompatibilityError(
                "resolved requested_config_digest link does not match"
            )
        _verify_reference(
            self.path,
            requested["requested_config_path"],
            requested["requested_file_sha256"],
        )
        relative = (
            "training_configs/"
            + requested["requested_config_digest"]
            + "/resolved_config.json"
        )
        _validate_prospective_configuration_paths(
            self._manifest,
            requested["requested_config_digest"],
            {
                "requested_config_path": requested[
                    "requested_config_path"
                ],
                "resolved_config_path": relative,
            },
        )
        destination = _bundle_path(self.path, relative)
        checksum = _commit_snapshot(destination, validated)
        record = {
            **requested,
            "resolved_config_path": relative,
            "resolved_config_digest": canonical_snapshot_digest(validated),
            "resolved_file_sha256": checksum,
        }
        manifest = copy.deepcopy(self._manifest)
        manifest["configurations"][requested["requested_config_digest"]] = record
        self._save_manifest(manifest)
        return copy.deepcopy(record)

    @property
    def current_run_attempt_id(self) -> str | None:
        return self._manifest.get("current_run_attempt_id")

    def begin_run_attempt(
        self,
        expected_case_ids: list[str] | tuple[str, ...],
        *,
        completed_case_ids: list[str] | tuple[str, ...] = (),
    ) -> str:
        """Start one durable runner invocation without changing bundle identity."""

        expected = list(expected_case_ids)
        completed = list(completed_case_ids)
        for name, values in (
            ("expected_case_ids", expected),
            ("completed_case_ids", completed),
        ):
            if (
                len(values) != len(set(values))
                or any(
                    type(value) is not str
                    or _CASE_RE.fullmatch(value) is None
                    for value in values
                )
            ):
                raise BundleIntegrityError(name + " is invalid")
        if not set(completed) <= set(expected):
            raise BundleIntegrityError(
                "completed_case_ids are not expected"
            )

        manifest = copy.deepcopy(self._manifest)
        attempts = manifest.setdefault("run_attempts", {})
        current_id = manifest.get("current_run_attempt_id")
        if current_id is not None:
            current = attempts[current_id]
            if current["status"] == "successful":
                raise BundleCompatibilityError(
                    "successful bundles cannot be resumed"
                )
            if current["status"] == "failed" and current["fatal"]:
                raise BundleCompatibilityError(
                    "fatal failed bundles cannot be resumed"
                )
            if current["status"] == "running":
                current["status"] = "interrupted"
                current["ended_at_utc"] = _utc_timestamp()

        attempt_id = "attempt-" + uuid.uuid4().hex
        attempts[attempt_id] = {
            "run_attempt_id": attempt_id,
            "started_at_utc": _utc_timestamp(),
            "ended_at_utc": None,
            "status": "running",
            "fatal": False,
            "expected_case_ids": expected,
            "completed_case_ids": completed,
            "case_attempts": [],
            "warnings": [],
        }
        manifest["current_run_attempt_id"] = attempt_id
        self._save_manifest(manifest)
        return attempt_id

    def finalize_run_attempt(
        self,
        status: str,
        *,
        fatal: bool = False,
        warnings: list[str] | tuple[str, ...] = (),
    ) -> None:
        """Commit the terminal state of the current runner invocation."""

        if status not in _RUN_STATUSES - {"running"}:
            raise ValueError("run-attempt status is unsupported")
        if type(fatal) is not bool or (fatal and status != "failed"):
            raise ValueError("fatal is valid only for a failed run attempt")
        attempt_id = self._manifest.get("current_run_attempt_id")
        if attempt_id is None:
            raise BundleIntegrityError("no run attempt is active")
        manifest = copy.deepcopy(self._manifest)
        attempt = manifest["run_attempts"][attempt_id]
        if attempt["status"] != "running":
            raise BundleIntegrityError("run attempt is already finalized")
        validated_warnings = [
            validate_case_warning(value) for value in warnings
        ]
        attempt["status"] = status
        attempt["fatal"] = fatal
        attempt["ended_at_utc"] = _utc_timestamp()
        attempt["warnings"] = validated_warnings
        self._save_manifest(manifest)

    def recover_run_attempt_after_interrupt(
        self,
        *,
        warnings: list[str] | tuple[str, ...] = (),
    ) -> tuple[str, tuple[str, ...]]:
        """Rehydrate and durably close an attempt interrupted outside a case."""

        recovered = load_bundle(self.path)
        self._manifest = recovered["manifest"]
        self._results = recovered["results"]
        attempt_id = self._manifest.get("current_run_attempt_id")
        if attempt_id is None:
            raise BundleIntegrityError("no run attempt is active")
        attempt = self._manifest["run_attempts"][attempt_id]
        if attempt["status"] == "running":
            self.finalize_run_attempt(
                "interrupted",
                warnings=warnings,
            )
            recovered = load_bundle(self.path)
            self._manifest = recovered["manifest"]
            self._results = recovered["results"]
            attempt = self._manifest["run_attempts"][attempt_id]
        return attempt["status"], tuple(attempt["warnings"])

    def commit_case(
        self,
        case: Mapping[str, Any],
        result: Mapping[str, Any],
        *,
        raw_samples: Mapping[str, Any] | None = None,
        structured_records: Mapping[str, Any] | None = None,
        compatibility: Mapping[str, Any] | None = None,
        resume: bool = False,
    ) -> None:
        detached_case = _case_record(dict(case), "case")
        detached_result = _result_record(dict(result), "result")
        newly_created_evidence: list[Path] = []
        pending_evidence: list[tuple[Path, bytes]] = []
        lifecycle_case = "run_attempt_id" in detached_case
        if lifecycle_case:
            if (
                detached_case["run_attempt_id"]
                != self._manifest.get("current_run_attempt_id")
            ):
                raise BundleCompatibilityError(
                    "case does not belong to the current run attempt"
                )
            if (
                detached_case["measurement_segment_id"]
                != detached_result["segment_id"]
            ):
                raise BundleIntegrityError(
                    "case and result measurement segments disagree"
                )
            attempt = self._manifest["run_attempts"][
                detached_case["run_attempt_id"]
            ]
            if attempt["status"] != "running":
                raise BundleIntegrityError(
                    "case cannot be committed to a finalized run attempt"
                )
            if detached_case["case_id"] not in attempt["expected_case_ids"]:
                raise BundleIntegrityError(
                    "case is not expected by the current run attempt"
                )
        supplied = (
            self._live_compatibility
            if compatibility is None
            else compatibility
        )
        if type(supplied) is not dict or any(
            supplied.get(field) != self._manifest["compatibility"][field]
            for field in _DURABLE_COMPATIBILITY_FIELDS
        ):
            raise BundleCompatibilityError(
                "case runtime is incompatible with this live bundle"
            )
        if (
            lifecycle_case
            and detached_case["live_session_fingerprint"]
            != self._live_compatibility["live_session_fingerprint"]
        ):
            raise BundleCompatibilityError(
                "case measurement segment belongs to another live session"
            )
        if (
            self._manifest["metadata"]["rl_device"]["requested"] == "auto"
            and (
                detached_case["eligibility"]["semantic_reuse_import"]
                or detached_case["eligibility"]["sample_aggregation"]
            )
        ):
            raise BundleCompatibilityError(
                "device=auto diagnostics must be ineligible for reuse"
            )
        if (
            detached_case["benchmark_release"]
            != self._manifest["workload"]["release_status"]["classification"]
        ):
            raise BundleCompatibilityError(
                "case benchmark_release does not match bundle workload"
            )
        case_id = detached_case["case_id"]
        existing_case = self._manifest["cases"].get(case_id)
        if existing_case is not None:
            existing_result = self._results["cases"][case_id]
            if not resume:
                raise BundleIntegrityError("case already exists")
            if existing_result["status"] not in ("interrupted", "failed"):
                raise BundleCompatibilityError("case status is not resumable")
            if existing_result["status"] == "failed" and existing_result["fatal"]:
                raise BundleCompatibilityError("fatal failed cases cannot be resumed")
            comparable_existing = {
                key: value
                for key, value in existing_case.items()
                if key not in {
                    "raw_samples",
                    "structured_records",
                    "snapshot",
                    "run_attempt_id",
                    "measurement_segment_id",
                    "live_session_fingerprint",
                    "timing_validity",
                }
            }
            comparable_new = {
                key: value
                for key, value in detached_case.items()
                if key not in {
                    "raw_samples",
                    "structured_records",
                    "snapshot",
                    "run_attempt_id",
                    "measurement_segment_id",
                    "live_session_fingerprint",
                    "timing_validity",
                }
            }
            if comparable_existing != comparable_new:
                raise BundleCompatibilityError("resumed case identity changed")
            existing_snapshot = existing_case.get("snapshot")
            resumed_snapshot = detached_case.get("snapshot")
            if (
                existing_snapshot is not None
                and existing_snapshot != resumed_snapshot
            ):
                raise BundleCompatibilityError(
                    "resumed case snapshot changed"
                )
        if "snapshot" in detached_case:
            indexed = self._manifest["configurations"].get(
                detached_case["snapshot"]["requested_config_digest"]
            )
            if indexed != detached_case["snapshot"]:
                raise BundleIntegrityError("case snapshot is not indexed")

        arrays = None
        if raw_samples is not None:
            if type(raw_samples) is not dict or not raw_samples:
                raise BundleIntegrityError("raw_samples must be a non-empty object")
            arrays = {
                name: _validate_array(name, value)
                for name, value in raw_samples.items()
            }

        detached_records = None
        if structured_records is not None:
            if type(structured_records) is not dict:
                raise TypeError("structured_records must be an object")
            detached_records = json_native(dict(structured_records))
            if not detached_records:
                raise BundleIntegrityError(
                    "structured_records must be a non-empty object"
                )
            if not lifecycle_case:
                raise BundleIntegrityError(
                    "structured_records require lifecycle case identity"
                )
            if (
                detached_records.get("measurement_segment_id")
                != detached_case["measurement_segment_id"]
            ):
                raise BundleIntegrityError(
                    "structured_records measurement segment disagrees"
                )
            ensure_artifact_safe(detached_records)

        _validate_case_evidence(
            detached_case,
            detached_result,
            arrays,
            detached_records,
        )

        if arrays is not None:
            relative = (
                "cases/"
                + case_id
                + "/"
                + detached_result["segment_id"]
                + ".npz"
            )
            destination = _bundle_path(self.path, relative)
            if destination.exists():
                try:
                    with np.load(destination, allow_pickle=False) as archive:
                        if set(archive.files) != set(arrays) or any(
                            not np.array_equal(archive[name], arrays[name])
                            for name in arrays
                        ):
                            raise BundleIntegrityError(
                                "raw sample artifact already exists with different data"
                            )
                except (OSError, ValueError) as error:
                    raise BundleIntegrityError(
                        "existing raw sample artifact is invalid"
                    ) from error
                payload = destination.read_bytes()
            else:
                buffer = io.BytesIO()
                np.savez_compressed(buffer, **arrays)
                payload = buffer.getvalue()
                pending_evidence.append((destination, payload))
            detached_case["raw_samples"] = {
                "path": relative,
                "sha256": _sha256_bytes(payload),
            }
            if lifecycle_case:
                detached_case["raw_samples"]["measurement_segment_id"] = (
                    detached_case["measurement_segment_id"]
                )

        if detached_records is not None:
            payload = json.dumps(
                detached_records,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode("utf-8")
            relative = (
                "cases/"
                + case_id
                + "/"
                + detached_case["measurement_segment_id"]
                + ".records.json"
            )
            destination = _bundle_path(self.path, relative)
            if destination.exists():
                if destination.read_bytes() != payload:
                    raise BundleIntegrityError(
                        "structured record artifact already exists "
                        "with different data"
                    )
            else:
                pending_evidence.append((destination, payload))
            detached_case["structured_records"] = {
                "path": relative,
                "sha256": _sha256_bytes(payload),
                "measurement_segment_id": detached_case[
                    "measurement_segment_id"
                ],
            }

        manifest = copy.deepcopy(self._manifest)
        results = copy.deepcopy(self._results)
        manifest["cases"][case_id] = detached_case
        results["cases"][case_id] = detached_result
        if lifecycle_case:
            attempt = manifest["run_attempts"][
                detached_case["run_attempt_id"]
            ]
            segment_id = detached_case["measurement_segment_id"]
            if any(
                item["measurement_segment_id"] == segment_id
                for item in attempt["case_attempts"]
            ):
                raise BundleIntegrityError(
                    "measurement segment is already indexed"
                )
            attempt["case_attempts"].append(
                {
                    "case_id": case_id,
                    "measurement_segment_id": segment_id,
                    "status": detached_result["status"],
                }
            )
            if (
                detached_result["status"] == "completed"
                and case_id not in attempt["completed_case_ids"]
            ):
                attempt["completed_case_ids"].append(case_id)
        validate_bundle_document({"manifest": manifest, "results": results})
        transaction_path = self.path / ".bundle-index-transaction.json"
        previous_index_payloads = {
            self.path / "manifest.json": (
                self.path / "manifest.json"
            ).read_bytes(),
            self.path / "results.json": (
                self.path / "results.json"
            ).read_bytes(),
        }
        try:
            _atomic_json(
                transaction_path,
                {
                    "previous": {
                        "manifest": self._manifest,
                        "results": self._results,
                    },
                    "next": {"manifest": manifest, "results": results},
                },
            )
            for evidence_path, payload in pending_evidence:
                newly_created_evidence.append(evidence_path)
                _atomic_bytes(evidence_path, payload)
            _atomic_json(self.path / "results.json", results)
            _atomic_json(self.path / "manifest.json", manifest)
        except BaseException:
            try:
                for index_path, previous_payload in (
                    previous_index_payloads.items()
                ):
                    if (
                        not index_path.is_file()
                        or index_path.read_bytes() != previous_payload
                    ):
                        _atomic_bytes(index_path, previous_payload)
                _remove_case_evidence(
                    self.path,
                    {
                        evidence_path.relative_to(self.path).as_posix()
                        for evidence_path in newly_created_evidence
                    },
                )
                transaction_path.unlink(missing_ok=True)
                recovered = load_bundle(self.path)
                self._manifest = recovered["manifest"]
                self._results = recovered["results"]
            except BaseException as recovery_error:
                raise BundleIntegrityError(
                    "case index transaction rollback failed"
                ) from recovery_error
            raise
        transaction_path.unlink(missing_ok=True)
        self._manifest = manifest
        self._results = results


def _validate_rl_resume_snapshot(
    stored_case: Mapping[str, Any],
    stored_result: Mapping[str, Any],
    *,
    destination_requested_config_digest: str | None,
) -> None:
    snapshot = stored_case.get("snapshot")
    imported = stored_case.get("imported_from")
    if imported is None:
        if (
            snapshot is not None
            and snapshot.get("requested_config_digest")
            != destination_requested_config_digest
        ):
            raise BundleCompatibilityError(
                "resume mismatch: requested_config_digest"
            )
        return
    source_snapshot = imported.get("source_snapshot")
    if (
        stored_result.get("status") != "completed"
        or not isinstance(snapshot, Mapping)
        or not isinstance(source_snapshot, Mapping)
        or snapshot != source_snapshot
    ):
        raise BundleCompatibilityError(
            "resume mismatch: imported RL snapshot provenance"
        )


def validate_resume(
    bundle: str | Path,
    expected_case: Mapping[str, Any],
    *,
    live_metadata: Mapping[str, Any],
    workload: Mapping[str, Any],
) -> dict[str, Any]:
    document = load_bundle(bundle)
    if dict(workload) != document["manifest"]["workload"]:
        raise BundleCompatibilityError("resume workload is incompatible")
    validated_live = validate_metadata_record(live_metadata)
    if any(
        validated_live[field]
        != document["manifest"]["compatibility"][field]
        for field in _DURABLE_COMPATIBILITY_FIELDS
    ):
        raise BundleCompatibilityError("resume live runtime is incompatible")
    expected = _case_record(dict(expected_case), "expected_case")
    case_id = expected["case_id"]
    stored = document["manifest"]["cases"].get(case_id)
    if stored is None:
        raise BundleCompatibilityError("case is not present in the bundle")
    fields = (
        "semantic_case_digest",
        "execution_spec_digest",
        "timing_protocol_digest",
        "result_schema_version",
        "benchmark_release",
        "semantic_projection_digest",
        "semantic_projection_version",
        "snapshot",
    )
    for field in fields:
        if stored.get(field) != expected.get(field):
            raise BundleCompatibilityError("resume mismatch: " + field)
    result = document["results"]["cases"][case_id]
    if result["status"] == "completed":
        raise BundleCompatibilityError("completed cases cannot be resumed")
    if result["status"] == "failed" and result["fatal"]:
        raise BundleCompatibilityError("fatal failed cases cannot be resumed")
    if result["status"] not in ("interrupted", "failed"):
        raise BundleCompatibilityError("case status is not resumable")
    return {
        "case_id": case_id,
        "restart_from_fixed_seeds": copy.deepcopy(stored["fixed_seeds"]),
        "reuse_partial_samples": False,
    }


def import_compatible_case(
    source: str | Path,
    destination: BundleWriter,
    case_id: str,
    *,
    destination_case: Mapping[str, Any] | None = None,
    reuse_authority: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if not isinstance(destination, BundleWriter):
        raise TypeError("destination must be a BundleWriter")
    source_root = Path(source)
    document = load_bundle(source_root)
    if source_root.resolve() == destination.path.resolve():
        raise BundleCompatibilityError("import destination must be distinct")
    if (
        destination_case is None
        and document["manifest"]["workload"]
        != destination._manifest["workload"]
    ):
        raise BundleCompatibilityError("import workload is incompatible")
    if any(
        document["manifest"]["compatibility"][field]
        != destination._live_compatibility[field]
        for field in _DURABLE_COMPATIBILITY_FIELDS
    ):
        raise BundleCompatibilityError("import runtime is incompatible")
    if document["manifest"]["metadata"]["rl_device"]["requested"] == "auto":
        raise BundleCompatibilityError("device=auto records cannot be imported")
    source_case = copy.deepcopy(document["manifest"]["cases"].get(case_id))
    if source_case is None:
        raise BundleCompatibilityError("source case does not exist")
    source_live_session = source_case.get(
        "live_session_fingerprint",
        document["manifest"]["compatibility"]["live_session_fingerprint"],
    )
    if (
        source_live_session
        != destination._live_compatibility["live_session_fingerprint"]
    ):
        raise BundleCompatibilityError("import requires the same live session")
    if not source_case["eligibility"]["semantic_reuse_import"]:
        raise BundleCompatibilityError("source case is not eligible for import")
    result = copy.deepcopy(document["results"]["cases"][case_id])
    if result["status"] != "completed":
        raise BundleCompatibilityError("only completed cases can be imported")
    source_result_segment_id = result["segment_id"]
    if destination_case is None:
        case = copy.deepcopy(source_case)
    else:
        case = _case_record(
            dict(destination_case),
            "destination_case",
        )
        if not case["eligibility"]["semantic_reuse_import"]:
            raise BundleCompatibilityError(
                "destination case is not eligible for import"
            )
        for field in (
            "semantic_case_digest",
            "timing_protocol_digest",
            "result_schema_version",
            "semantic_projection_digest",
            "semantic_projection_version",
            "fixed_seeds",
        ):
            if case.get(field) != source_case.get(field):
                raise BundleCompatibilityError(
                    "import mismatch: " + field
                )
    source_snapshot = copy.deepcopy(source_case.get("snapshot"))
    requested = None
    resolved_snapshot = None
    if source_snapshot is not None:
        requested = validate_snapshot(
            _strict_object(
                _bundle_path(source_root, source_snapshot["requested_config_path"])
            )
        )
        if "resolved_config_path" in source_snapshot:
            resolved_snapshot = validate_resolved_snapshot(
                _strict_object(
                    _bundle_path(source_root, source_snapshot["resolved_config_path"])
                )
            )
    execution_matches = (
        case["execution_spec_digest"]
        == source_case["execution_spec_digest"]
    )
    if not execution_matches and reuse_authority is None:
        raise BundleCompatibilityError(
            "stronger import requires RL reuse authority"
        )
    if reuse_authority is not None:
        authority = _require_exact(
            dict(reuse_authority),
            {
                "compatible",
                "source_execution_reference",
                "source_execution_spec_digest",
                "destination_execution_spec_digest",
                "source_snapshot_reference",
                "source_actual_completed_transitions",
                "source_complete_window_count",
                "runtime_compatibility_digest",
                "window_ownership",
            },
            "reuse_authority",
        )
        if authority["compatible"] is not True:
            raise BundleCompatibilityError(
                "RL reuse authority is not compatible"
            )
        for field in (
            "source_execution_reference",
            "window_ownership",
        ):
            if type(authority[field]) is not str or not authority[field]:
                raise BundleCompatibilityError(
                    "reuse_authority." + field + " is invalid"
                )
        if authority["source_execution_reference"] != case_id:
            raise BundleCompatibilityError(
                "reuse authority source execution reference is incompatible"
            )
        if authority["window_ownership"] != "single_model_learn_call":
            raise BundleCompatibilityError(
                "RL reuse cannot merge model.learn() executions"
            )
        for field, expected in (
            (
                "source_execution_spec_digest",
                source_case["execution_spec_digest"],
            ),
            (
                "destination_execution_spec_digest",
                case["execution_spec_digest"],
            ),
            (
                "runtime_compatibility_digest",
                destination._live_compatibility[
                    "runtime_hardware_compatibility_digest"
                ],
            ),
        ):
            _require_digest(authority[field], "reuse_authority." + field)
            if authority[field] != expected:
                raise BundleCompatibilityError(
                    "reuse_authority." + field + " is incompatible"
                )
        if authority["source_snapshot_reference"] != source_snapshot:
            raise BundleCompatibilityError(
                "reuse authority source snapshot is incompatible"
            )
        if (
            type(authority["source_actual_completed_transitions"]) is not int
            or authority["source_actual_completed_transitions"]
            != result["actual_completed_transitions"]
        ):
            raise BundleCompatibilityError(
                "reuse authority transition count is incompatible"
            )
        complete_windows = result["metrics"].get(
            "training.complete_window_count"
        )
        if (
            not isinstance(complete_windows, Mapping)
            or complete_windows.get("unit") != "count"
            or type(complete_windows.get("value")) is not int
            or authority["source_complete_window_count"]
            != complete_windows["value"]
        ):
            raise BundleCompatibilityError(
                "reuse authority window count is incompatible"
            )
    if requested is not None:
        snapshot = destination.persist_requested_config(requested)
        if resolved_snapshot is not None:
            snapshot = destination.persist_resolved_config(
                snapshot,
                resolved_snapshot,
            )
        case["snapshot"] = snapshot
    inherited_provenance = source_case.get("imported_from")
    immediate_hop = {
        "source_bundle_id": document["manifest"]["bundle_id"],
        "source_case_id": case_id,
        "source_execution_spec_digest": (
            source_case["execution_spec_digest"]
        ),
        "source_segment_id": source_result_segment_id,
    }
    if inherited_provenance is None:
        provenance = {
            "source_bundle_id": document["manifest"]["bundle_id"],
            "source_case_id": case_id,
            "source_execution_spec_digest": (
                source_case["execution_spec_digest"]
            ),
            "source_segment_id": source_result_segment_id,
            "source_snapshot": source_snapshot,
            "source_authority": {
                "workload": copy.deepcopy(
                    document["manifest"]["workload"]
                ),
                "source_validation": copy.deepcopy(
                    document["manifest"].get("source_validation")
                ),
            },
            "import_chain": [immediate_hop],
        }
    else:
        provenance = copy.deepcopy(inherited_provenance)
        chain = provenance.get("import_chain")
        if chain is None:
            chain = [
                {
                    key: provenance[key]
                    for key in (
                        "source_bundle_id",
                        "source_case_id",
                        "source_execution_spec_digest",
                        "source_segment_id",
                    )
                }
            ]
        provenance["import_chain"] = [*chain, immediate_hop]
    case["imported_from"] = provenance
    destination_segment_id = case.get("measurement_segment_id")
    if destination_segment_id is not None:
        result["segment_id"] = destination_segment_id
    arrays = None
    if "raw_samples" in source_case:
        raw = source_case["raw_samples"]
        with np.load(_bundle_path(source_root, raw["path"]), allow_pickle=False) as archive:
            arrays = {name: archive[name].copy() for name in archive.files}
    structured_records = None
    if "structured_records" in source_case:
        structured_records = _strict_object(
            _bundle_path(
                source_root,
                source_case["structured_records"]["path"],
            )
        )
        if destination_segment_id is not None:
            def replace_segment(value: Any) -> None:
                if isinstance(value, dict):
                    for key, item in value.items():
                        if key == "measurement_segment_id":
                            value[key] = destination_segment_id
                        else:
                            replace_segment(item)
                elif isinstance(value, list):
                    for item in value:
                        replace_segment(item)

            replace_segment(structured_records)
    destination.commit_case(
        case,
        result,
        raw_samples=arrays,
        structured_records=structured_records,
    )
    return copy.deepcopy(provenance)
