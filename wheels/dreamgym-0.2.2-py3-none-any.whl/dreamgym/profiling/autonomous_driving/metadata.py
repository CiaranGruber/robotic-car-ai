"""Allowlisted, privacy-safe runtime metadata and compatibility identities."""

from __future__ import annotations

import copy
import importlib
import importlib.metadata
import os
import platform
import re
import secrets
import sys
from typing import Any, Mapping
import weakref

from dreamgym.profiling.autonomous_driving.privacy import ensure_artifact_safe
from dreamgym.profiling.autonomous_driving.records import canonical_json_digest


METADATA_SCHEMA_VERSION = "dreamgym-profile-metadata-v1"
_TOP_LEVEL_FIELDS = (
    "environment_classification",
    "python",
    "os",
    "architecture",
    "cpu",
    "memory",
    "dependencies",
    "threads",
    "rl_device",
)
_DEPENDENCIES = (
    "dreamgym",
    "gymnasium",
    "numpy",
    "scipy",
    "stable-baselines3",
    "torch",
)
_RUNTIME_VERSION_MODULES = {
    "gymnasium": "gymnasium",
    "numpy": "numpy",
    "stable-baselines3": "stable_baselines3",
    "torch": "torch",
}
_DEPENDENCY_KEYS = frozenset(
    distribution.replace("-", "_") for distribution in _DEPENDENCIES
)
_THREAD_FIELDS = frozenset(
    ("logical_cpu_count", "torch_intraop", "torch_interop")
)
_REQUESTED_RL_DEVICES = frozenset(("cpu", "cuda", "auto"))
_CUDA_RL_DEVICE_RE = re.compile(r"cuda(?::(?:0|[1-9][0-9]*))?")
class _CollectedMetadata(dict):
    """Distinct in-memory carrier; the class itself does not grant trust."""


def _require_exact_fields(
    value: Mapping[str, Any],
    fields: tuple[str, ...],
    path: str,
) -> None:
    if type(value) is not dict:
        raise TypeError(path + " must be an object")
    missing = sorted(set(fields) - set(value))
    if missing:
        raise ValueError(path + "." + missing[0] + " is required")
    unexpected = sorted(set(value) - set(fields))
    if unexpected:
        raise ValueError(path + "." + unexpected[0] + " is unsupported")


def _digest(domain: str, document: Mapping[str, Any]) -> str:
    return canonical_json_digest(
        {"compatibility_domain": domain, "document": copy.deepcopy(document)}
    )


def _concrete_rl_device_family(value: Any) -> str | None:
    if type(value) is not str:
        return None
    if value == "cpu":
        return "cpu"
    if _CUDA_RL_DEVICE_RE.fullmatch(value) is not None:
        return "cuda"
    return None


def _validate_rl_device(value: Mapping[str, Any]) -> None:
    requested = value["requested"]
    resolved = value["resolved"]
    observed = value["observed"]
    if requested is None and resolved is None and observed is None:
        return
    if requested is None or resolved is None or observed is None:
        raise ValueError(
            "metadata.rl_device must be entirely null or entirely present"
        )
    if type(requested) is not str or requested not in _REQUESTED_RL_DEVICES:
        raise ValueError(
            "metadata.rl_device.requested must be cpu, cuda, auto, or null"
        )
    resolved_family = _concrete_rl_device_family(resolved)
    if resolved_family is None:
        raise ValueError(
            "metadata.rl_device.resolved must be a canonical concrete device"
        )
    observed_family = _concrete_rl_device_family(observed)
    if observed_family is None:
        raise ValueError(
            "metadata.rl_device.observed must be a canonical concrete device"
        )
    if resolved_family != observed_family:
        raise ValueError(
            "metadata.rl_device.resolved and observed must share a device family"
        )
    if requested != "auto" and requested != resolved_family:
        raise ValueError(
            "metadata.rl_device.requested is incompatible with the resolved device"
        )


def _build_metadata_record(
    facts: Mapping[str, Any],
    *,
    session_nonce: str,
) -> dict[str, Any]:
    if type(facts) is not dict:
        raise TypeError("facts must be an object")
    _require_exact_fields(facts, _TOP_LEVEL_FIELDS, "metadata")
    if type(session_nonce) is not str or not session_nonce:
        raise ValueError("session_nonce must be a non-empty private string")

    record = copy.deepcopy(facts)
    if record["environment_classification"] not in ("local", "colab"):
        raise ValueError("environment_classification must be local or colab")
    _require_exact_fields(record["python"], ("version", "implementation"), "metadata.python")
    _require_exact_fields(record["os"], ("name", "version"), "metadata.os")
    _require_exact_fields(
        record["cpu"],
        ("description", "logical_cores", "physical_cores"),
        "metadata.cpu",
    )
    _require_exact_fields(record["memory"], ("total_bytes",), "metadata.memory")
    _require_exact_fields(
        record["rl_device"],
        ("requested", "resolved", "observed"),
        "metadata.rl_device",
    )
    if type(record["dependencies"]) is not dict:
        raise TypeError("metadata.dependencies must be an object")
    if type(record["threads"]) is not dict:
        raise TypeError("metadata.threads must be an object")
    unexpected_dependencies = sorted(
        set(record["dependencies"]) - _DEPENDENCY_KEYS
    )
    if unexpected_dependencies:
        raise ValueError(
            "metadata.dependencies."
            + unexpected_dependencies[0]
            + " is unsupported"
        )
    unexpected_threads = sorted(set(record["threads"]) - _THREAD_FIELDS)
    if unexpected_threads:
        raise ValueError(
            "metadata.threads." + unexpected_threads[0] + " is unsupported"
        )
    for path, value in (
        ("metadata.architecture", record["architecture"]),
        ("metadata.python.version", record["python"]["version"]),
        ("metadata.python.implementation", record["python"]["implementation"]),
        ("metadata.os.name", record["os"]["name"]),
        ("metadata.os.version", record["os"]["version"]),
        ("metadata.cpu.description", record["cpu"]["description"]),
    ):
        if type(value) is not str or not value:
            raise ValueError(path + " must be a non-empty string")
    for name, value in record["dependencies"].items():
        if type(name) is not str or type(value) is not str or not value:
            raise ValueError("dependency names and versions must be strings")
    for name, value in record["threads"].items():
        if type(name) is not str or (
            value is not None and (type(value) is not int or value <= 0)
        ):
            raise ValueError("thread settings must be positive integers or null")
    for field in ("logical_cores", "physical_cores"):
        value = record["cpu"][field]
        if value is not None and (type(value) is not int or value <= 0):
            raise ValueError("CPU core counts must be positive integers or null")
    memory = record["memory"]["total_bytes"]
    if memory is not None and (type(memory) is not int or memory <= 0):
        raise ValueError("total memory must be a positive integer or null")
    _validate_rl_device(record["rl_device"])

    ensure_artifact_safe(record)
    dependency_document = {
        "python": copy.deepcopy(record["python"]),
        "dependencies": copy.deepcopy(record["dependencies"]),
    }
    runtime_document = {
        key: copy.deepcopy(record[key])
        for key in (
            "environment_classification",
            "os",
            "architecture",
            "cpu",
            "memory",
            "threads",
        )
    }
    device_document = copy.deepcopy(record["rl_device"])
    dependency_digest = _digest("dependency-v1", dependency_document)
    runtime_digest = _digest("runtime-hardware-v1", runtime_document)
    device_digest = _digest("rl-device-v1", device_document)
    session_fingerprint = canonical_json_digest(
        {
            "compatibility_domain": "live-session-v1",
            "dependency_compatibility_digest": dependency_digest,
            "runtime_hardware_compatibility_digest": runtime_digest,
            "device_compatibility_digest": device_digest,
            "private_nonce": session_nonce,
        }
    )
    return {
        "schema_version": METADATA_SCHEMA_VERSION,
        **record,
        "dependency_compatibility_digest": dependency_digest,
        "runtime_hardware_compatibility_digest": runtime_digest,
        "device_compatibility_digest": device_digest,
        "live_session_fingerprint": session_fingerprint,
    }


def build_metadata_record(
    facts: Mapping[str, Any],
    *,
    session_nonce: str,
) -> dict[str, Any]:
    """Validate caller-supplied facts and add domain-separated fingerprints."""

    return _build_metadata_record(
        facts,
        session_nonce=session_nonce,
    )


def _validate_metadata_record(
    value: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate a record and verify all deterministic digests."""

    if type(value) not in (dict, _CollectedMetadata):
        raise TypeError("metadata must be an object")
    expected = {
        "schema_version",
        *_TOP_LEVEL_FIELDS,
        "dependency_compatibility_digest",
        "runtime_hardware_compatibility_digest",
        "device_compatibility_digest",
        "live_session_fingerprint",
    }
    if set(value) != expected:
        missing = sorted(expected - set(value))
        unexpected = sorted(set(value) - expected)
        name = missing[0] if missing else unexpected[0]
        raise ValueError("metadata." + name + " is missing or unsupported")
    if value["schema_version"] != METADATA_SCHEMA_VERSION:
        raise ValueError("unsupported metadata schema_version")
    ensure_artifact_safe(value)
    # A private nonce is intentionally unavailable on load. Rebuild with a
    # placeholder only to reuse structural validation, then verify deterministic
    # domains directly.
    facts = {key: copy.deepcopy(value[key]) for key in _TOP_LEVEL_FIELDS}
    rebuilt = _build_metadata_record(
        facts,
        session_nonce="validation-only",
    )
    for field in (
        "dependency_compatibility_digest",
        "runtime_hardware_compatibility_digest",
        "device_compatibility_digest",
    ):
        if value[field] != rebuilt[field]:
            raise ValueError("metadata." + field + " does not match its document")
    fingerprint = value["live_session_fingerprint"]
    if (
        type(fingerprint) is not str
        or len(fingerprint) != 64
        or any(character not in "0123456789abcdef" for character in fingerprint)
    ):
        raise ValueError("metadata.live_session_fingerprint is invalid")
    return copy.deepcopy(dict(value))


def validate_metadata_record(value: Mapping[str, Any]) -> dict[str, Any]:
    """Validate supplied metadata without granting serialized provenance."""

    return _validate_metadata_record(value)


def _total_memory_bytes() -> int | None:
    if os.name == "posix" and hasattr(os, "sysconf"):
        try:
            pages = int(os.sysconf("SC_PHYS_PAGES"))
            page_size = int(os.sysconf("SC_PAGE_SIZE"))
            total = pages * page_size
            return total if total > 0 else None
        except Exception:
            return None
    if os.name == "nt":
        try:
            import ctypes

            class _MemoryStatus(ctypes.Structure):
                _fields_ = [
                    ("length", ctypes.c_ulong),
                    ("memory_load", ctypes.c_ulong),
                    ("total_phys", ctypes.c_ulonglong),
                    ("avail_phys", ctypes.c_ulonglong),
                    ("total_page_file", ctypes.c_ulonglong),
                    ("avail_page_file", ctypes.c_ulonglong),
                    ("total_virtual", ctypes.c_ulonglong),
                    ("avail_virtual", ctypes.c_ulonglong),
                    ("avail_extended_virtual", ctypes.c_ulonglong),
                ]

            status = _MemoryStatus()
            status.length = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.total_phys)
        except Exception:
            return None
    return None


def _physical_cpu_count() -> int | None:
    """Return a physical-core count when a dependency-free collector exists."""

    return None


def _dependency_versions(
    *,
    include_runtime_modules: bool = True,
) -> dict[str, str]:
    versions: dict[str, str] = {}
    for distribution in _DEPENDENCIES:
        distribution_version = None
        try:
            candidate = importlib.metadata.version(distribution)
        except Exception:
            # Distribution metadata can be absent or unreadable for an
            # otherwise importable editable/runtime installation.
            pass
        else:
            if isinstance(candidate, str) and candidate:
                distribution_version = str(candidate)

        runtime_version = None
        module_name = (
            _RUNTIME_VERSION_MODULES.get(distribution)
            if include_runtime_modules
            else None
        )
        if module_name is not None:
            try:
                module_version = getattr(
                    importlib.import_module(module_name),
                    "__version__",
                    None,
                )
            except Exception:
                # Distribution metadata remains a useful best-effort fact when
                # an optional runtime import is unavailable on this machine.
                pass
            else:
                if isinstance(module_version, str) and module_version:
                    runtime_version = str(module_version)
        version = runtime_version or distribution_version
        if version is not None:
            versions[distribution.replace("-", "_")] = version
    return versions


def _best_effort_text_probe(probe) -> str:
    """Return one stable allowlisted platform fact without hiding cancellation."""

    try:
        value = probe()
    except Exception:
        return "unknown"
    return value if isinstance(value, str) and value else "unknown"


def _best_effort_cpu_count() -> int | None:
    try:
        value = os.cpu_count()
    except Exception:
        return None
    return value if type(value) is int and value > 0 else None


def _best_effort_thread_settings(
    *,
    include_torch: bool,
) -> dict[str, int | None]:
    try:
        return _thread_settings(include_torch=include_torch)
    except Exception:
        return {
            "logical_cpu_count": None,
            "torch_intraop": None,
            "torch_interop": None,
        }


def _thread_settings(
    *,
    include_torch: bool = True,
) -> dict[str, int | None]:
    settings: dict[str, int | None] = {"logical_cpu_count": os.cpu_count()}
    if not include_torch:
        settings["torch_intraop"] = None
        settings["torch_interop"] = None
        return settings
    try:
        import torch

        settings["torch_intraop"] = int(torch.get_num_threads())
        settings["torch_interop"] = int(torch.get_num_interop_threads())
    except (ImportError, RuntimeError):
        settings["torch_intraop"] = None
        settings["torch_interop"] = None
    return settings


def _collector_owned_metadata_api():
    """Bind collection and auto-device finalization to private closure state."""

    process_session_nonce = secrets.token_hex(32)
    entries: dict[
        int,
        tuple[weakref.ReferenceType[_CollectedMetadata], str, str],
    ] = {}

    def register(record: _CollectedMetadata, nonce: str) -> _CollectedMetadata:
        identity = id(record)

        def remove(
            reference: weakref.ReferenceType[_CollectedMetadata],
            *,
            identity: int = identity,
        ) -> None:
            current = entries.get(identity)
            if current is not None and current[0] is reference:
                entries.pop(identity, None)

        reference = weakref.ref(record, remove)
        entries[identity] = (
            reference,
            canonical_json_digest(dict(record)),
            nonce,
        )
        return record

    def collect_metadata(
        *,
        requested_rl_device: str | None,
        resolved_rl_device: str | None,
        observed_rl_device: str | None,
        session_nonce: str | None = None,
        include_torch_threads: bool = True,
    ) -> dict[str, Any]:
        """Collect only portable facts approved for bundle metadata."""

        logical = _best_effort_cpu_count()
        facts = {
            "environment_classification": (
                "colab" if "google.colab" in sys.modules else "local"
            ),
            "python": {
                "version": _best_effort_text_probe(
                    platform.python_version
                ),
                "implementation": _best_effort_text_probe(
                    platform.python_implementation
                ),
            },
            "os": {
                "name": _best_effort_text_probe(platform.system),
                "version": _best_effort_text_probe(platform.release),
            },
            "architecture": _best_effort_text_probe(platform.machine),
            "cpu": {
                "description": _best_effort_text_probe(platform.processor),
                "logical_cores": logical,
                "physical_cores": _physical_cpu_count(),
            },
            "memory": {"total_bytes": _total_memory_bytes()},
            "dependencies": _dependency_versions(
                include_runtime_modules=include_torch_threads
            ),
            "threads": _best_effort_thread_settings(
                include_torch=include_torch_threads
            ),
            "rl_device": {
                "requested": requested_rl_device,
                "resolved": resolved_rl_device,
                "observed": observed_rl_device,
            },
        }
        nonce = (
            process_session_nonce
            if session_nonce is None
            else session_nonce
        )
        return register(
            _CollectedMetadata(
                _build_metadata_record(
                    facts,
                    session_nonce=nonce,
                )
            ),
            nonce,
        )

    def observe_rl_device(
        value: Mapping[str, Any],
        *,
        requested_device: str,
        observed_device: str,
    ) -> tuple[Mapping[str, Any], bool]:
        """Verify a recorded device or finalize collector-owned auto metadata."""

        validated = validate_metadata_record(value)
        if requested_device not in _REQUESTED_RL_DEVICES:
            raise ValueError("requested_device must be cpu, cuda, or auto")
        if _concrete_rl_device_family(observed_device) is None:
            raise ValueError("observed_device must be a canonical concrete device")
        recorded = validated["rl_device"]
        if all(recorded[field] is None for field in recorded):
            provenance = entries.get(id(value))
            if (
                requested_device != "auto"
                or provenance is None
                or provenance[0]() is not value
                or provenance[1] != canonical_json_digest(dict(value))
            ):
                raise ValueError(
                    "provisional RL device metadata must be collector-owned auto"
                )
            entries.pop(id(value))
            facts = {
                key: copy.deepcopy(validated[key])
                for key in _TOP_LEVEL_FIELDS
            }
            facts["rl_device"] = {
                "requested": "auto",
                "resolved": observed_device,
                "observed": observed_device,
            }
            finalized = _CollectedMetadata(
                _build_metadata_record(
                    facts,
                    session_nonce=provenance[2],
                )
            )
            return register(finalized, provenance[2]), True
        expected = {
            "requested": requested_device,
            "resolved": observed_device,
            "observed": observed_device,
        }
        if recorded != expected:
            raise ValueError(
                "metadata RL device does not match the model-observed device"
            )
        return value, False

    return collect_metadata, observe_rl_device


(
    collect_metadata,
    _observe_collected_rl_device,
) = _collector_owned_metadata_api()
del _collector_owned_metadata_api
