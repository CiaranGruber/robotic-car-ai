"""Shared helpers for profiling scripts and reusable profiling modules."""

from __future__ import annotations

import atexit
import math
import os
import platform
import shutil
import sys
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from statistics import mean, median
from typing import Any

import numpy as np

from dreamgym.profiling.autonomous_driving.measurement import _linear_p95


REPO_ROOT = Path(__file__).resolve().parents[2]

_REGISTERED_CACHE_PATHS: set[Path] = set()


def default_profiling_output_dir() -> Path:
    """Return the default local directory for generated profiling reports."""

    return REPO_ROOT / "profiling_results"


def resolve_profile_output_path(output: str | Path | None, default_filename: str) -> Path:
    """Resolve and create the output path for a generated profiling report."""

    output_path = Path(output) if output is not None else default_profiling_output_dir() / default_filename
    if not output_path.is_absolute():
        output_path = REPO_ROOT / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    return output_path


def display_output_path(path: str | Path) -> str:
    """Return a concise path for status messages."""

    path = Path(path)
    try:
        return str(path.resolve().relative_to(REPO_ROOT))
    except ValueError:
        return str(path)


def activate_matplotlib_profile_cache(cache_name: str = "profiling") -> Path:
    """Use a repo-local temporary Matplotlib cache for profiling commands."""

    cache_path = REPO_ROOT / f".matplotlib-cache-{cache_name}"
    cache_path.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(cache_path)

    if cache_path not in _REGISTERED_CACHE_PATHS:
        _REGISTERED_CACHE_PATHS.add(cache_path)
        atexit.register(shutil.rmtree, cache_path, ignore_errors=True)

    return cache_path


def _nan_summary() -> dict[str, float | int]:
    return {
        "calls": 0,
        "total_s": 0.0,
        "mean_us": math.nan,
        "median_us": math.nan,
        "min_us": math.nan,
        "max_us": math.nan,
        "p95_us": math.nan,
    }


def summarize_times(times_ns: Iterable[int | float]) -> dict[str, float | int]:
    """Summarize nanosecond timing samples using microsecond statistics."""

    samples_ns = [float(value) for value in times_ns]
    if not samples_ns:
        return _nan_summary()

    # Keep the specialist callers' legacy fractional-sample compatibility while
    # delegating percentile calculation to the shared implementation.
    samples_us = [value / 1000.0 for value in samples_ns]
    return {
        "calls": len(samples_us),
        "total_s": sum(samples_ns) / 1_000_000_000.0,
        "mean_us": mean(samples_us),
        "median_us": median(samples_us),
        "min_us": min(samples_us),
        "max_us": max(samples_us),
        "p95_us": _linear_p95(samples_ns) / 1000.0,
    }


def format_float(value: Any, digits: int = 2) -> str:
    """Format floats consistently for markdown reports."""

    if isinstance(value, (np.integer,)):
        return str(int(value))
    if isinstance(value, (np.floating, float)):
        if math.isnan(float(value)):
            return "nan"
        if math.isinf(float(value)):
            return "inf" if value > 0 else "-inf"
        return f"{float(value):.{digits}f}"
    return str(value)


def markdown_table(headers: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> str:
    """Build a simple GitHub-flavored markdown table."""

    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append(
            "| "
            + " | ".join(format_float(row.get(header, "")) for header in headers)
            + " |"
        )
    return "\n".join(lines)


def environment_metadata() -> dict[str, str]:
    """Collect lightweight package and machine metadata for profile reports."""

    metadata = {
        "Python": sys.version.split()[0],
        "Platform": platform.platform(),
        "Processor": platform.processor() or "unknown",
        "NumPy": np.__version__,
    }

    try:
        import gymnasium

        metadata["Gymnasium"] = gymnasium.__version__
    except Exception:
        metadata["Gymnasium"] = "not installed"

    try:
        import stable_baselines3

        metadata["Stable-Baselines3"] = stable_baselines3.__version__
    except Exception:
        metadata["Stable-Baselines3"] = "not installed"

    try:
        import torch

        metadata["PyTorch"] = torch.__version__
        metadata["CUDA available"] = str(torch.cuda.is_available())
    except Exception:
        metadata["PyTorch"] = "not installed"
        metadata["CUDA available"] = "unknown"

    return metadata


def metadata_markdown(metadata: Mapping[str, str] | None = None) -> str:
    """Format environment metadata as markdown bullet points."""

    metadata = environment_metadata() if metadata is None else metadata
    return "\n".join(f"- {key}: {value}" for key, value in metadata.items())
