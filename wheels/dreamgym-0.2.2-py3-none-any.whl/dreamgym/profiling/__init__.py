"""Profiling utilities for measuring dream-gym performance locally."""

