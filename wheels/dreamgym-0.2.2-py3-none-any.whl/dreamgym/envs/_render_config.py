"""Dependency-light operational render configuration validation."""

from __future__ import annotations

from collections.abc import Mapping
import copy

from dreamgym.envs.config_validation import (
    finite_float,
    required_detached_mapping,
    reject_unknown_keys,
    strict_bool,
    strict_positive_int,
)


DEFAULT_RENDER_CONFIG: dict[str, object] = {
    "frame_size_px": (900, 700),
    "view": {
        "mode": "follow_vehicle",
        "minimum_width_m": 40.0,
        "minimum_height_m": 40.0,
    },
    "maximum_road_geometry_sample_spacing_m": 1.0,
    "road_content": {
        "include_lane_surfaces": True,
        "include_markings": True,
        "include_edge_bands": True,
        "include_cones": True,
        "include_reference_line": True,
    },
}


def _detached_render_value(value):
    if isinstance(value, Mapping):
        return {
            key: _detached_render_value(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_detached_render_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_detached_render_value(item) for item in value)
    return copy.deepcopy(value)


def normalize_render_config(
    render_config: Mapping[str, object] | None,
) -> dict[str, object]:
    if render_config is None:
        supplied = {}
    elif not isinstance(render_config, Mapping):
        raise TypeError("render_config must be a mapping.")
    else:
        supplied = _detached_render_value(render_config)
    reject_unknown_keys(supplied, DEFAULT_RENDER_CONFIG, "render_config")
    config: dict[str, object] = {}

    raw_frame_size = supplied.get(
        "frame_size_px",
        DEFAULT_RENDER_CONFIG["frame_size_px"],
    )
    try:
        frame_size = tuple(raw_frame_size)
    except TypeError as exc:
        raise TypeError(
            "render_config.frame_size_px must be a two-value sequence."
        ) from exc
    if len(frame_size) != 2:
        raise ValueError("render_config.frame_size_px must contain exactly two values.")
    config["frame_size_px"] = tuple(
        strict_positive_int(value, "render_config.frame_size_px")
        for value in frame_size
    )

    view_defaults = DEFAULT_RENDER_CONFIG["view"]
    view_supplied = required_detached_mapping(
        supplied.get("view", {}),
        "render_config.view",
    )
    reject_unknown_keys(view_supplied, view_defaults, "render_config.view")
    view = dict(view_defaults)
    view.update(view_supplied)
    if view["mode"] not in ("follow_vehicle", "fixed"):
        raise ValueError(
            "render_config.view.mode must be 'follow_vehicle' or 'fixed'."
        )
    for field in ("minimum_width_m", "minimum_height_m"):
        path = "render_config.view." + field
        view[field] = finite_float(view[field], path)
        if view[field] <= 0.0:
            raise ValueError(path + " must be positive.")
    config["view"] = view

    spacing_path = "render_config.maximum_road_geometry_sample_spacing_m"
    spacing = finite_float(
        supplied.get(
            "maximum_road_geometry_sample_spacing_m",
            DEFAULT_RENDER_CONFIG["maximum_road_geometry_sample_spacing_m"],
        ),
        spacing_path,
    )
    if spacing < 0.05:
        raise ValueError(spacing_path + " must be at least 0.05.")
    config["maximum_road_geometry_sample_spacing_m"] = spacing

    road_content_defaults = DEFAULT_RENDER_CONFIG["road_content"]
    road_content_supplied = required_detached_mapping(
        supplied.get("road_content", {}),
        "render_config.road_content",
    )
    reject_unknown_keys(
        road_content_supplied,
        road_content_defaults,
        "render_config.road_content",
    )
    road_content = dict(road_content_defaults)
    road_content.update(road_content_supplied)
    for field in road_content_defaults:
        road_content[field] = strict_bool(
            road_content[field],
            "render_config.road_content." + field,
        )
    config["road_content"] = road_content

    return config
