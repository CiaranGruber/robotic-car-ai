from __future__ import annotations

from collections.abc import Mapping
from numbers import Integral, Real
import copy
import math

from dreamgym.envs.road_preview import validate_road_preview_distances


def detached_mapping(value, path):
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    return copy.deepcopy(dict(value))


def required_detached_mapping(value, path):
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    return copy.deepcopy(dict(value))


def reject_unknown_keys(mapping, allowed, path):
    non_string_keys = [key for key in mapping if not isinstance(key, str)]
    if non_string_keys:
        raise TypeError(path + " keys must be strings.")
    unknown = sorted(set(mapping) - set(allowed))
    if unknown:
        raise ValueError(path + "." + unknown[0] + " is not supported.")


def strict_bool(value, path):
    if type(value) is not bool:
        raise TypeError(path + " must be boolean.")
    return value


def strict_positive_int(value, path):
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(path + " must be a positive integer.")
    value = int(value)
    if value <= 0:
        raise ValueError(path + " must be a positive integer.")
    return value


def strict_int(value, path):
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(path + " must be an integer.")
    return int(value)


def finite_float(value, path):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(path + " must be a finite number.")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(path + " must be a finite number.")
    return value


def optional_callable(value, path):
    if value is not None and not callable(value):
        raise TypeError(path + " must be callable or None.")
    return value


_DESTINATIONS = ("observation", "info", "neither")
_ORDINARY_OBSERVATION_RECORDS = (
    ("ground_truth_world_position_x_m", ()),
    ("ground_truth_world_position_y_m", ()),
    ("ground_truth_heading_in_world_frame_rad", ()),
    ("ground_truth_body_longitudinal_velocity_mps", ()),
    ("ground_truth_body_lateral_velocity_mps", ()),
    ("ground_truth_yaw_rate_rad_per_s", ()),
    ("ground_truth_front_wheel_steering_angle_rad", ()),
    ("reference_line_progress_m", ()),
    (
        "body_longitudinal_velocity_mps",
        ("bias_mps", "noise_standard_deviation_mps"),
    ),
    (
        "front_wheel_steering_angle_rad",
        ("bias_rad", "noise_standard_deviation_rad", "resolution_rad"),
    ),
    (
        "lateral_error_from_target_line_m",
        ("bias_m", "noise_standard_deviation_m"),
    ),
    (
        "heading_error_from_target_line_rad",
        ("bias_rad", "noise_standard_deviation_rad"),
    ),
    (
        "target_line_offset_from_reference_line_m",
        ("bias_m", "noise_standard_deviation_m"),
    ),
    (
        "lateral_error_from_reference_line_m",
        ("bias_m", "noise_standard_deviation_m"),
    ),
    (
        "yaw_rate_rad_per_s",
        ("bias_rad_per_s", "noise_standard_deviation_rad_per_s"),
    ),
    ("body_longitudinal_acceleration_mps2", ()),
    ("body_lateral_acceleration_mps2", ()),
    (
        "target_line_position_at_closest_reference_line_progress_in_body_frame_m",
        ("bias_m", "noise_standard_deviation_m"),
    ),
    (
        "reference_line_closest_point_position_in_body_frame_m",
        ("bias_m", "noise_standard_deviation_m"),
    ),
    (
        "target_line_curvature_per_m",
        ("bias_per_m", "noise_standard_deviation_per_m"),
    ),
    ("speed_limit_mps", ()),
    ("recommended_speed_mps", ()),
)
_ORDINARY_ERROR_NAMES = dict(_ORDINARY_OBSERVATION_RECORDS)
_OBSERVATION_TOP_LEVEL_KEYS = set(_ORDINARY_ERROR_NAMES) | {
    "target_line_lookahead",
    "road_preview",
    "next_speed_limit_change",
    "next_recommended_speed_change",
    "cone_detections",
    "fixed_noise_seed",
}


def _strict_case_insensitive_token(value, allowed, path):
    if not isinstance(value, str):
        raise TypeError(path + " must be a string.")
    value = value.lower()
    if value not in allowed:
        raise ValueError(path + " must be one of " + str(tuple(allowed)) + ".")
    return value


def _finite_nonnegative(value, path):
    value = finite_float(value, path)
    if value < 0.0:
        raise ValueError(path + " must be non-negative.")
    return value


def _normalize_routed_record(
    raw,
    path,
    *,
    error_names=(),
    supports_scaling=True,
):
    supplied = required_detached_mapping(raw, path)
    allowed = {"destination", *error_names}
    if supports_scaling:
        allowed.add("scaling_factor")
    reject_unknown_keys(supplied, allowed, path)
    resolved = {
        "destination": _strict_case_insensitive_token(
            supplied.get("destination", "neither"),
            _DESTINATIONS,
            path + ".destination",
        )
    }
    if supports_scaling:
        resolved["scaling_factor"] = finite_float(
            supplied.get("scaling_factor", 1.0),
            path + ".scaling_factor",
        )
    for name in error_names:
        error_path = path + "." + name
        if name.startswith("noise_standard_deviation") or name.startswith("resolution"):
            resolved[name] = _finite_nonnegative(supplied.get(name, 0.0), error_path)
        else:
            resolved[name] = finite_float(supplied.get(name, 0.0), error_path)
    return resolved


def _normalize_axis_position_error(raw, path, *, allow_bias):
    supplied = required_detached_mapping(raw, path)
    allowed = {"noise_standard_deviation_m"}
    if allow_bias:
        allowed.add("bias_m")
    reject_unknown_keys(supplied, allowed, path)
    resolved = {}
    if allow_bias:
        resolved["bias_m"] = finite_float(
            supplied.get("bias_m", 0.0), path + ".bias_m"
        )
    resolved["noise_standard_deviation_m"] = _finite_nonnegative(
        supplied.get("noise_standard_deviation_m", 0.0),
        path + ".noise_standard_deviation_m",
    )
    return resolved


def _normalize_lookahead_acquisition(raw, path):
    supplied = required_detached_mapping(raw, path)
    mode = _strict_case_insensitive_token(
        supplied.get("mode", "road_geometry"),
        ("road_geometry", "additive_output_error", "localized_map"),
        path + ".mode",
    )
    if mode == "road_geometry":
        reject_unknown_keys(supplied, {"mode"}, path)
        return {"mode": mode}
    if mode == "additive_output_error":
        reject_unknown_keys(
            supplied,
            {"mode", "position_error_in_body_frame", "curvature_error"},
            path,
        )
        position_path = path + ".position_error_in_body_frame"
        position = required_detached_mapping(
            supplied.get("position_error_in_body_frame", {}), position_path
        )
        reject_unknown_keys(position, {"forward", "left"}, position_path)
        curvature_path = path + ".curvature_error"
        curvature = required_detached_mapping(
            supplied.get("curvature_error", {}), curvature_path
        )
        reject_unknown_keys(
            curvature,
            {"bias_per_m", "noise_standard_deviation_per_m"},
            curvature_path,
        )
        return {
            "mode": mode,
            "position_error_in_body_frame": {
                axis: _normalize_axis_position_error(
                    position.get(axis, {}), position_path + "." + axis, allow_bias=True
                )
                for axis in ("forward", "left")
            },
            "curvature_error": {
                "bias_per_m": finite_float(
                    curvature.get("bias_per_m", 0.0), curvature_path + ".bias_per_m"
                ),
                "noise_standard_deviation_per_m": _finite_nonnegative(
                    curvature.get("noise_standard_deviation_per_m", 0.0),
                    curvature_path + ".noise_standard_deviation_per_m",
                ),
            },
        }

    reject_unknown_keys(supplied, {"mode", "query_distance_error", "latency_s"}, path)
    query_path = path + ".query_distance_error"
    query = required_detached_mapping(supplied.get("query_distance_error", {}), query_path)
    reject_unknown_keys(
        query,
        {
            "bias_m",
            "noise_standard_deviation_m",
            "random_walk_standard_deviation_m_per_sqrt_s",
        },
        query_path,
    )
    return {
        "mode": mode,
        "query_distance_error": {
            "bias_m": finite_float(query.get("bias_m", 0.0), query_path + ".bias_m"),
            "noise_standard_deviation_m": _finite_nonnegative(
                query.get("noise_standard_deviation_m", 0.0),
                query_path + ".noise_standard_deviation_m",
            ),
            "random_walk_standard_deviation_m_per_sqrt_s": _finite_nonnegative(
                query.get("random_walk_standard_deviation_m_per_sqrt_s", 0.0),
                query_path + ".random_walk_standard_deviation_m_per_sqrt_s",
            ),
        },
        "latency_s": _finite_nonnegative(
            supplied.get("latency_s", 0.0), path + ".latency_s"
        ),
    }


def _normalize_target_line_lookahead(raw):
    path = "observation_config.target_line_lookahead"
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {
            "maximum_distance_m",
            "sample_count",
            "acquisition",
            "positions_in_body_frame_m",
            "curvatures_per_m",
        },
        path,
    )
    maximum_distance = _finite_nonnegative(
        supplied.get("maximum_distance_m", 100.0), path + ".maximum_distance_m"
    )
    sample_count = strict_positive_int(
        supplied.get("sample_count", 10), path + ".sample_count"
    )
    return {
        "maximum_distance_m": maximum_distance,
        "sample_count": sample_count,
        "acquisition": _normalize_lookahead_acquisition(
            supplied.get("acquisition", {}), path + ".acquisition"
        ),
        "positions_in_body_frame_m": _normalize_routed_record(
            supplied.get("positions_in_body_frame_m", {}),
            path + ".positions_in_body_frame_m",
        ),
        "curvatures_per_m": _normalize_routed_record(
            supplied.get("curvatures_per_m", {}), path + ".curvatures_per_m"
        ),
    }


_PREVIEW_OUTPUT_ERROR_UNITS = {
    "target_line_curvatures_per_m": ("bias_per_m", "noise_standard_deviation_per_m"),
    "recommended_speeds_mps": ("bias_mps", "noise_standard_deviation_mps"),
    "speed_limits_mps": ("bias_mps", "noise_standard_deviation_mps"),
    "right_lane_bound_offsets_from_target_line_m": ("bias_m", "noise_standard_deviation_m"),
    "left_lane_bound_offsets_from_target_line_m": ("bias_m", "noise_standard_deviation_m"),
}


def _normalize_preview_acquisition(raw, path):
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {"query_origin_error_along_target_line", "latency_s", "output_errors"},
        path,
    )
    query_path = path + ".query_origin_error_along_target_line"
    query = required_detached_mapping(
        supplied.get("query_origin_error_along_target_line", {}), query_path
    )
    reject_unknown_keys(
        query,
        {
            "bias_m",
            "noise_standard_deviation_m",
            "random_walk_standard_deviation_m_per_sqrt_s",
        },
        query_path,
    )
    output_path = path + ".output_errors"
    output = required_detached_mapping(supplied.get("output_errors", {}), output_path)
    reject_unknown_keys(output, _PREVIEW_OUTPUT_ERROR_UNITS, output_path)
    normalized_output = {}
    for field_name, error_names in _PREVIEW_OUTPUT_ERROR_UNITS.items():
        field_path = output_path + "." + field_name
        field = required_detached_mapping(output.get(field_name, {}), field_path)
        reject_unknown_keys(field, error_names, field_path)
        normalized_field = {}
        for error_name in error_names:
            value = field.get(error_name, 0.0)
            if error_name.startswith("noise_standard_deviation"):
                value = _finite_nonnegative(value, field_path + "." + error_name)
            else:
                value = finite_float(value, field_path + "." + error_name)
            normalized_field[error_name] = value
        normalized_output[field_name] = normalized_field
    return {
        "query_origin_error_along_target_line": {
            "bias_m": finite_float(query.get("bias_m", 0.0), query_path + ".bias_m"),
            "noise_standard_deviation_m": _finite_nonnegative(
                query.get("noise_standard_deviation_m", 0.0),
                query_path + ".noise_standard_deviation_m",
            ),
            "random_walk_standard_deviation_m_per_sqrt_s": _finite_nonnegative(
                query.get("random_walk_standard_deviation_m_per_sqrt_s", 0.0),
                query_path + ".random_walk_standard_deviation_m_per_sqrt_s",
            ),
        },
        "latency_s": _finite_nonnegative(
            supplied.get("latency_s", 0.0), path + ".latency_s"
        ),
        "output_errors": normalized_output,
    }


def _normalize_preview_lane_bounds(raw, path):
    if raw is None:
        return None
    supplied = required_detached_mapping(raw, path)
    mode = _strict_case_insensitive_token(
        supplied.get("mode"),
        ("target_line_lane", "lane_index", "reference_lane"),
        path + ".mode",
    )
    allowed = {"mode", "require_active_lane"}
    if mode == "lane_index":
        allowed.add("lane_index")
    reject_unknown_keys(supplied, allowed, path)
    resolved = {
        "mode": mode,
        "require_active_lane": strict_bool(
            supplied.get("require_active_lane", True),
            path + ".require_active_lane",
        ),
    }
    if mode == "lane_index":
        if "lane_index" not in supplied:
            raise ValueError(path + ".lane_index is required.")
        resolved["lane_index"] = strict_int(supplied["lane_index"], path + ".lane_index")
        if resolved["lane_index"] == 0:
            raise ValueError(path + ".lane_index must be nonzero.")
    return resolved


_PREVIEW_NUMERIC_CHILDREN = (
    "target_line_curvatures_per_m",
    "recommended_speeds_mps",
    "speed_limits_mps",
    "right_lane_bound_offsets_from_target_line_m",
    "left_lane_bound_offsets_from_target_line_m",
)


def _normalize_road_preview(raw):
    path = "observation_config.road_preview"
    supplied = required_detached_mapping(raw, path)
    allowed = {
        "target_line_distances_m",
        "acquisition",
        "lane_bounds",
        *_PREVIEW_NUMERIC_CHILDREN,
        "is_spatially_valid",
        "lane_bounds_are_available",
    }
    reject_unknown_keys(supplied, allowed, path)
    raw_distances = supplied.get("target_line_distances_m")
    if raw_distances is None:
        distances = None
    else:
        distances = validate_road_preview_distances(raw_distances)
    resolved = {
        "target_line_distances_m": distances,
        "acquisition": _normalize_preview_acquisition(
            supplied.get("acquisition", {}), path + ".acquisition"
        ),
        "lane_bounds": _normalize_preview_lane_bounds(
            supplied.get("lane_bounds"), path + ".lane_bounds"
        ),
    }
    for child in _PREVIEW_NUMERIC_CHILDREN:
        resolved[child] = _normalize_routed_record(
            supplied.get(child, {}), path + "." + child
        )
    for child in ("is_spatially_valid", "lane_bounds_are_available"):
        resolved[child] = _normalize_routed_record(
            supplied.get(child, {}), path + "." + child, supports_scaling=False
        )

    routed_children = [
        child
        for child in (*_PREVIEW_NUMERIC_CHILDREN, "is_spatially_valid", "lane_bounds_are_available")
        if resolved[child]["destination"] != "neither"
    ]
    if routed_children and distances is None:
        raise ValueError(path + ".target_line_distances_m is required when a preview child is routed.")
    observation_numeric = [
        child
        for child in _PREVIEW_NUMERIC_CHILDREN
        if resolved[child]["destination"] == "observation"
    ]
    if observation_numeric and resolved["is_spatially_valid"]["destination"] != "observation":
        raise ValueError(path + ".is_spatially_valid must route to observation with numeric preview fields.")
    lane_children = {
        "right_lane_bound_offsets_from_target_line_m",
        "left_lane_bound_offsets_from_target_line_m",
        "lane_bounds_are_available",
    }
    if lane_children.intersection(routed_children) and resolved["lane_bounds"] is None:
        raise ValueError(path + ".lane_bounds is required for routed lane-bound fields.")
    return resolved


def _normalize_next_change(raw, family_name):
    path = "observation_config." + family_name
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(
        supplied, {"value_mps", "reference_line_distance_m", "exists"}, path
    )
    return {
        "value_mps": _normalize_routed_record(
            supplied.get("value_mps", {}), path + ".value_mps"
        ),
        "reference_line_distance_m": _normalize_routed_record(
            supplied.get("reference_line_distance_m", {}),
            path + ".reference_line_distance_m",
        ),
        "exists": _normalize_routed_record(
            supplied.get("exists", {}), path + ".exists", supports_scaling=False
        ),
    }


def _normalize_cone_detections(raw):
    path = "observation_config.cone_detections"
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {
            "maximum_detection_count",
            "acquisition",
            "positions_in_body_frame_m",
            "color_ids",
            "count",
        },
        path,
    )
    capacity = supplied.get("maximum_detection_count")
    if capacity is not None:
        capacity = strict_positive_int(capacity, path + ".maximum_detection_count")
    acquisition_path = path + ".acquisition"
    acquisition = required_detached_mapping(
        supplied.get("acquisition", {}), acquisition_path
    )
    reject_unknown_keys(
        acquisition,
        {
            "horizontal_field_of_view_deg",
            "forward_position_upper_bound_m",
            "position_error_in_body_frame",
        },
        acquisition_path,
    )
    fov = finite_float(
        acquisition.get("horizontal_field_of_view_deg", 80.0),
        acquisition_path + ".horizontal_field_of_view_deg",
    )
    if not 0.0 < fov <= 180.0:
        raise ValueError(acquisition_path + ".horizontal_field_of_view_deg must be in (0, 180].")
    position_error_path = acquisition_path + ".position_error_in_body_frame"
    position_error = required_detached_mapping(
        acquisition.get("position_error_in_body_frame", {}), position_error_path
    )
    reject_unknown_keys(position_error, {"forward", "left"}, position_error_path)
    return {
        "maximum_detection_count": capacity,
        "acquisition": {
            "horizontal_field_of_view_deg": fov,
            "forward_position_upper_bound_m": _finite_nonnegative(
                acquisition.get("forward_position_upper_bound_m", 4.0),
                acquisition_path + ".forward_position_upper_bound_m",
            ),
            "position_error_in_body_frame": {
                axis: _normalize_axis_position_error(
                    position_error.get(axis, {}),
                    position_error_path + "." + axis,
                    allow_bias=False,
                )
                for axis in ("forward", "left")
            },
        },
        "positions_in_body_frame_m": _normalize_routed_record(
            supplied.get("positions_in_body_frame_m", {}),
            path + ".positions_in_body_frame_m",
        ),
        "color_ids": _normalize_routed_record(
            supplied.get("color_ids", {}), path + ".color_ids", supports_scaling=False
        ),
        "count": _normalize_routed_record(
            supplied.get("count", {}), path + ".count", supports_scaling=False
        ),
    }


def normalize_observation_config(raw):
    """Return one detached, deterministic, complete observation registry."""

    supplied = required_detached_mapping(raw, "observation_config")
    reject_unknown_keys(supplied, _OBSERVATION_TOP_LEVEL_KEYS, "observation_config")
    resolved = {}
    ordinary_names = set(_ORDINARY_ERROR_NAMES)

    def add_ordinary(name):
        resolved[name] = _normalize_routed_record(
            supplied.get(name, {}),
            "observation_config." + name,
            error_names=_ORDINARY_ERROR_NAMES[name],
        )

    for name in (
        "ground_truth_world_position_x_m",
        "ground_truth_world_position_y_m",
        "ground_truth_heading_in_world_frame_rad",
        "ground_truth_body_longitudinal_velocity_mps",
        "ground_truth_body_lateral_velocity_mps",
        "ground_truth_yaw_rate_rad_per_s",
        "ground_truth_front_wheel_steering_angle_rad",
        "reference_line_progress_m",
        "body_longitudinal_velocity_mps",
        "front_wheel_steering_angle_rad",
        "lateral_error_from_target_line_m",
        "heading_error_from_target_line_rad",
        "target_line_offset_from_reference_line_m",
        "lateral_error_from_reference_line_m",
        "yaw_rate_rad_per_s",
        "body_longitudinal_acceleration_mps2",
        "body_lateral_acceleration_mps2",
        "target_line_position_at_closest_reference_line_progress_in_body_frame_m",
        "reference_line_closest_point_position_in_body_frame_m",
    ):
        add_ordinary(name)
    resolved["target_line_lookahead"] = _normalize_target_line_lookahead(
        supplied.get("target_line_lookahead", {})
    )
    add_ordinary("target_line_curvature_per_m")
    resolved["road_preview"] = _normalize_road_preview(supplied.get("road_preview", {}))
    add_ordinary("speed_limit_mps")
    add_ordinary("recommended_speed_mps")
    resolved["next_speed_limit_change"] = _normalize_next_change(
        supplied.get("next_speed_limit_change", {}), "next_speed_limit_change"
    )
    resolved["next_recommended_speed_change"] = _normalize_next_change(
        supplied.get("next_recommended_speed_change", {}),
        "next_recommended_speed_change",
    )
    resolved["cone_detections"] = _normalize_cone_detections(
        supplied.get("cone_detections", {})
    )
    seed = supplied.get("fixed_noise_seed")
    if seed is not None:
        seed = strict_int(seed, "observation_config.fixed_noise_seed")
        if seed < 0:
            raise ValueError("observation_config.fixed_noise_seed must be non-negative.")
    resolved["fixed_noise_seed"] = seed
    assert ordinary_names.issubset(resolved)
    return resolved


INITIAL_STATE_CONFIG_DEFAULTS = {
    "bounds": {
        "world_pose": {
            "x_m": {"lower": 0.0, "upper": 0.0},
            "y_m": {"lower": 0.0, "upper": 0.0},
            "heading_rad": {"lower": 0.0, "upper": 0.0},
        },
        "body_motion": {
            "longitudinal_velocity_mps": {"lower": 0.0, "upper": 0.0},
            "lateral_velocity_mps": {"lower": 0.0, "upper": 0.0},
            "yaw_rate_rad_per_s": {"lower": 0.0, "upper": 0.0},
        },
        "front_wheel_steering_angle_rad": {"lower": 0.0, "upper": 0.0},
    },
    "reference_line_progress_search": None,
}


_INITIAL_STATE_GROUP_LEAVES = {
    "world_pose": ("x_m", "y_m", "heading_rad"),
    "body_motion": (
        "longitudinal_velocity_mps",
        "lateral_velocity_mps",
        "yaw_rate_rad_per_s",
    ),
}


def _normalize_bound_record(raw, path, *, inherited=None):
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(supplied, {"lower", "upper"}, path)
    if inherited is None:
        for field in ("lower", "upper"):
            if field not in supplied:
                raise ValueError(path + "." + field + " is required.")
        resolved = supplied
    else:
        resolved = {**copy.deepcopy(inherited), **supplied}
    resolved["lower"] = finite_float(resolved["lower"], path + ".lower")
    resolved["upper"] = finite_float(resolved["upper"], path + ".upper")
    if resolved["lower"] > resolved["upper"]:
        raise ValueError(path + " must be ordered with lower <= upper.")
    return resolved


def _normalize_progress_search(raw, path):
    if raw is None:
        return None
    supplied = required_detached_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {"lower_bound_m", "upper_bound_m"},
        path,
    )
    for field in ("lower_bound_m", "upper_bound_m"):
        if field not in supplied:
            raise ValueError(path + "." + field + " is required.")
        supplied[field] = finite_float(supplied[field], path + "." + field)
    if supplied["lower_bound_m"] > supplied["upper_bound_m"]:
        raise ValueError(
            path + " must be ordered with lower_bound_m <= upper_bound_m."
        )
    return supplied


def _apply_initial_state_bounds(supplied_bounds, resolved_bounds, *, overlay):
    supplied = required_detached_mapping(supplied_bounds, "initial_state_config.bounds")
    allowed_groups = set(_INITIAL_STATE_GROUP_LEAVES) | {
        "front_wheel_steering_angle_rad"
    }
    reject_unknown_keys(supplied, allowed_groups, "initial_state_config.bounds")
    for group, leaves in _INITIAL_STATE_GROUP_LEAVES.items():
        if group not in supplied:
            continue
        group_path = "initial_state_config.bounds." + group
        supplied_group = required_detached_mapping(supplied[group], group_path)
        reject_unknown_keys(supplied_group, leaves, group_path)
        for leaf in leaves:
            if leaf not in supplied_group:
                continue
            path = group_path + "." + leaf
            inherited = resolved_bounds[group][leaf] if overlay else None
            resolved_bounds[group][leaf] = _normalize_bound_record(
                supplied_group[leaf],
                path,
                inherited=inherited,
            )
    steering = "front_wheel_steering_angle_rad"
    if steering in supplied:
        path = "initial_state_config.bounds." + steering
        inherited = resolved_bounds[steering] if overlay else None
        resolved_bounds[steering] = _normalize_bound_record(
            supplied[steering],
            path,
            inherited=inherited,
        )


def normalize_initial_state_config(raw):
    """Return a detached complete initial-state configuration."""

    supplied = required_detached_mapping(raw, "initial_state_config")
    reject_unknown_keys(
        supplied,
        {"bounds", "reference_line_progress_search"},
        "initial_state_config",
    )
    resolved = copy.deepcopy(INITIAL_STATE_CONFIG_DEFAULTS)
    if "bounds" in supplied:
        _apply_initial_state_bounds(supplied["bounds"], resolved["bounds"], overlay=False)
    if "reference_line_progress_search" in supplied:
        resolved["reference_line_progress_search"] = _normalize_progress_search(
            supplied["reference_line_progress_search"],
            "initial_state_config.reference_line_progress_search",
        )
    return resolved


def normalize_initial_state_reset_overlay(raw, constructor_config):
    """Resolve one detached sparse reset overlay over constructor bounds."""

    supplied = required_detached_mapping(raw, "initial_state_config")
    reject_unknown_keys(
        supplied,
        {"bounds", "reference_line_progress_search"},
        "initial_state_config",
    )
    resolved = copy.deepcopy(constructor_config)
    if "bounds" in supplied:
        _apply_initial_state_bounds(supplied["bounds"], resolved["bounds"], overlay=True)
    if "reference_line_progress_search" in supplied:
        resolved["reference_line_progress_search"] = _normalize_progress_search(
            supplied["reference_line_progress_search"],
            "initial_state_config.reference_line_progress_search",
        )
    return resolved
