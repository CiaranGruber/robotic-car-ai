#!/usr/bin/env python

import copy
import math
import warnings
import numpy as np

from dreamgym.envs.road_core import constants as road_constants
from dreamgym.envs.road_core import cones as road_cones
from dreamgym.envs.road_core import horizon_samples
from dreamgym.envs.road_core import lane_geometry
from dreamgym.envs.road_core import observations as road_observations
from dreamgym.envs.road_core import reference_geometry
from dreamgym.envs.road_core import schema as road_schema
from dreamgym.envs.road_core import schema_utils
from dreamgym.envs.road_core import speeds as speed_helpers
from dreamgym.envs.road_core import target_geometry
from dreamgym.envs.road_core import utils as road_utils
from dreamgym.envs.road_core._target_config import _normalize_target_line_config
from dreamgym.envs.road_preview import RoadTargetLineHorizonSample

class Road:
    """
    This class provides a road-like environment that is described by a sequence
    of straight-line and curved elements. The method for constructing a complete
    road ensure that the road is continuous and smooth. The class also includes
    function for computing the details of the road relative to a given query
    point, i.e., the details that a car may be able to measure while driving
    along the road.

    Quantities that fully specify each road element
    - c_i : the curvature of the road element (units: 1/m).
    - l_i : the length of the road element (units: m).
    - speed_limit_i : the speed limit for the road element (stored in m/s).

    From c_i and l_i, the following quantities are computed:
    - phi_i      : the angular span of curved road elements as theta_i = l_i * c_i, equal to NaN for a straight-line element (units: radians)
    - isStraight_i : A flag for whether the road element is straight, by checking |c_i| < epsilon (units: boolean)

    Additional quantities are derived from the above values as they are convenient for the
    functions that process the road:
    - recommended_speed_i : the curvature-derived, limit-capped speed (m/s).
    - start_point_i        : (x,y) coordinates of the start of the road element (units: m).
    - end_point_i          : (x,y) coordinates of the end   of the road element (units: m).
    - start_angle_i        : angle (relative to world frame x-axis) of the tangent to the road element at its start point (units: radians).
    - end_angle_i          : angle (relative to world frame x-axis) of the tangent to the road element at its end.  point (units: radians).
    - arc_center_i         : (x,y) coordinates of the center point of a curved road element (units: m).
    - l_total_at_end_i     : the total length of the road at the end point that the road element (units: m).
    - start_hyperplane_A_i : the unit normal vector that point in the opposite direction of start angle (units: m).
    - start_hyperplane_b_i : the offset value such that the hyperplane pass through the start point (units: m).
    - end_hyperplane_A_i   : the unit normal vector that point in the opposite direction of end angle (units: m).
    - end_hyperplane_b_i   : the offset value such that the hyperplane pass through the end point (units: m).

    Speed properties
    - The speed limit is a base property per element stored in m/s.
      Input via `road_spec` is in km/h and defaults to 100 km/h (converted
      internally to m/s).
    - The recommended speed (v_rec) is a derived property per element computed
      from absolute-curvature radius using a stepwise road-sign speed lookup,
      then capped by that element's maximum speed. See
      `compute_recommended_speed_mps`.
    """
    VALID_LANE_WIDTH_INTERPOLATIONS = road_constants.VALID_LANE_WIDTH_INTERPOLATIONS
    VALID_REFERENCE_LINE_ROLES = road_constants.VALID_REFERENCE_LINE_ROLES
    VALID_LANE_TRAVEL_DIRECTIONS = road_constants.VALID_LANE_TRAVEL_DIRECTIONS
    VALID_SURFACES = road_constants.VALID_SURFACES
    VALID_LANE_MARKING_PATTERNS = road_constants.VALID_LANE_MARKING_PATTERNS
    VALID_INTER_CONE_SPACING_DISTRIBUTIONS = road_constants.VALID_INTER_CONE_SPACING_DISTRIBUTIONS
    VALID_CONE_PLACEMENTS = road_constants.VALID_CONE_PLACEMENTS
    VALID_ROAD_VALIDATION_MODES = road_constants.VALID_ROAD_VALIDATION_MODES
    VALID_SPEED_TRANSITION_SOURCES = road_constants.VALID_SPEED_TRANSITION_SOURCES
    LOOKAHEAD_RESULT_FIELDS = road_constants.LOOKAHEAD_RESULT_FIELDS
    CURRENT_RESULT_FIELDS = road_constants.CURRENT_RESULT_FIELDS
    CONE_COLOR_NAMES = road_constants.CONE_COLOR_NAMES
    CONE_COLOR_TO_ID = road_constants.CONE_COLOR_TO_ID
    CONE_COLOR_ID_TO_NAME = road_constants.CONE_COLOR_ID_TO_NAME
    CONE_COLOR_UNKNOWN_ID = road_constants.CONE_COLOR_UNKNOWN_ID
    CONE_COLOR_PADDING_ID = road_constants.CONE_COLOR_PADDING_ID

    def __init__(
        self,
        road_spec=None,
        *,
        minimum_curvature_magnitude_per_m=1.0 / 10000.0,
    ):
        """
        Initialization function for the "Road" class.

        Parameters
        ----------
            road_spec : dictionary [OPTIONAL]
                Road specification dictionary. If provided, it must contain an
                "elements" list and can contain road-wide "defaults".
            minimum_curvature_magnitude_per_m : float
                Finite nonnegative lower bound for requested nonzero circular-arc
                curvature. Zero disables the lower-magnitude check.

        Returns
        -------
        Nothing
        """
        if isinstance(minimum_curvature_magnitude_per_m, (bool, np.bool_)):
            raise TypeError("minimum_curvature_magnitude_per_m must be a finite real number.")
        try:
            minimum_curvature_magnitude_per_m = float(
                minimum_curvature_magnitude_per_m
            )
        except (TypeError, ValueError, OverflowError) as exc:
            raise TypeError(
                "minimum_curvature_magnitude_per_m must be a finite real number."
            ) from exc
        if not np.isfinite(minimum_curvature_magnitude_per_m):
            raise ValueError("minimum_curvature_magnitude_per_m must be finite.")
        if minimum_curvature_magnitude_per_m < 0.0:
            raise ValueError("minimum_curvature_magnitude_per_m must be non-negative.")
        self.minimum_curvature_magnitude_per_m = minimum_curvature_magnitude_per_m
        self.__requested_road_spec = copy.deepcopy(road_spec)

        # Initialize empty vectors for each property of the road element
        # > As private class variables
        self.__c = np.empty((0,),dtype=np.float32)
        self.__l = np.empty((0,),dtype=np.float32)
        self.__phi = np.empty((0,),dtype=np.float32)
        self.__isStraight = np.empty((0,),dtype=np.bool_)
        self.__v_max = np.empty((0,),dtype=np.float32)

        # Initialize empty vectors for the derived properties of the road elements
        # > As private class variables
        self.__start_points = np.empty((0,2),dtype=np.float32)
        self.__end_points = np.empty((0,2),dtype=np.float32)
        self.__start_angles = np.empty((0,),dtype=np.float32)
        self.__end_angles = np.empty((0,),dtype=np.float32)
        self.__arc_centers = np.empty((0,2),dtype=np.float32)
        self.__l_total_at_end = np.empty((0,),dtype=np.float32)
        self.__l_total_at_start = np.empty((0,),dtype=np.float32)
        self.__start_tangent_vectors = np.empty((0,2),dtype=np.float32)
        self.__start_left_normal_vectors = np.empty((0,2),dtype=np.float32)
        self.__curvature_signs = np.empty((0,),dtype=np.float32)
        self.__inverse_abs_curvatures = np.empty((0,),dtype=np.float32)
        self.__start_hyperplane_A = np.empty((0,2),dtype=np.float32)
        self.__start_hyperplane_b = np.empty((0,),dtype=np.float32)
        self.__end_hyperplane_A = np.empty((0,2),dtype=np.float32)
        self.__end_hyperplane_b = np.empty((0,),dtype=np.float32)

        self.__v_rec = np.empty((0,),dtype=np.float32)
        self.__next_v_max = np.empty((0,),dtype=np.float32)
        self.__l_total_at_next_v_max = np.empty((0,),dtype=np.float32)
        self.__next_v_rec = np.empty((0,),dtype=np.float32)
        self.__l_total_at_next_v_rec = np.empty((0,),dtype=np.float32)

        self.__road_schema_defaults = Road.__default_road_schema_defaults()
        self.__road_validation_config = Road.__default_road_validation_config()
        self.__lane_metadata = []
        self.__source_element_lane_metadata = []
        self.__source_element_to_private_segment_indices = tuple()
        self.__private_segment_to_source_element_index = np.empty(
            (0,), dtype=np.int32
        )
        self.__schema_warnings = []
        self.__schema_warnings_emitted_count = 0
        self.__validation_warnings = []
        self.__target_line_arc_length_lookup_cache = {}
        self.__constant_target_offsets_cache = {}
        self.__constant_target_offsets_continuity_cache = {}
        self.__constant_target_distance_lookup_cache = {}
        self.__all_lane_widths_are_constant = True
        self.__active_lane_minimum_width_m = 0.05

        if (road_spec is not None):
            (
                defaults_override,
                active_lane_minimum_width_m,
                validation_override,
                elements,
            ) = self.__parse_road_spec(road_spec)
            self.__road_schema_defaults = Road.__deep_merge_dicts(
                self.__road_schema_defaults,
                defaults_override,
            )
            self.__road_validation_config = validation_override
            self.__validate_road_schema_defaults(self.__road_schema_defaults)
            self.__validate_road_validation_config(self.__road_validation_config)
            self.__active_lane_minimum_width_m = active_lane_minimum_width_m
            self.__construct_road_from_element_specs(elements)
            self.__emit_schema_warnings()
            self.__apply_road_spec_validation()


    @staticmethod
    def __default_road_schema_defaults():
        return schema_utils.default_road_schema_defaults()

    @staticmethod
    def __default_road_validation_config():
        return schema_utils.default_road_validation_config()

    @staticmethod
    def generate_random_spec(generation_config=None, seed=None):
        from dreamgym.envs.road_core.random_generation import generate_random_road_spec

        return generate_random_road_spec(
            generation_config=generation_config,
            seed=seed,
        )

    @staticmethod
    def generate_random(
        generation_config=None,
        seed=None,
        *,
        minimum_curvature_magnitude_per_m=1e-4,
    ):
        return Road(
            road_spec=Road.generate_random_spec(
                generation_config=generation_config,
                seed=seed,
            ),
            minimum_curvature_magnitude_per_m=minimum_curvature_magnitude_per_m,
        )

    @staticmethod
    def __deep_merge_dicts(base, override):
        return schema_utils.deep_merge_dicts(base, override)

    @staticmethod
    def __validate_string_option(value, field_name, valid_options):
        return schema_utils.validate_string_option(value, field_name, valid_options)

    @staticmethod
    def __lane_key(lane_idx):
        return schema_utils.lane_key(lane_idx)

    @staticmethod
    def __lane_line_key(lane_line_idx):
        return schema_utils.lane_line_key(lane_line_idx)

    @staticmethod
    def __wrap_to_pi(angle):
        return road_utils.wrap_to_pi(angle)

    def __validate_road_schema_defaults(self, defaults):
        road_schema.validate_road_schema_defaults(defaults)

    def __validate_road_validation_config(self, validation_config):
        road_schema.validate_road_validation_config(validation_config)

    @staticmethod
    def __parse_road_spec(road_spec):
        return road_schema.parse_road_spec(road_spec)

    def __apply_road_spec_validation(self):
        validation_config = self.__road_validation_config
        if validation_config["mode"] == "disabled":
            return

        speed_config = validation_config["speed_transitions"]
        validation_issues = self.validate_speed_transitions(
            speed_sources=speed_config["speed_sources"],
            deceleration_limit_mps2=speed_config["deceleration_limit_mps2"],
            reaction_time_s=speed_config["reaction_time_s"],
            distance_margin_m=speed_config["distance_margin_m"],
        )

        if len(validation_issues) == 0:
            return

        issue_messages = [
            Road.__format_speed_transition_validation_issue(issue)
            for issue in validation_issues
        ]
        validation_message = "Road validation failed:\n" + "\n".join(issue_messages)
        if validation_config["mode"] == "raise":
            raise ValueError(validation_message)

        for message in issue_messages:
            self.__validation_warnings.append(message)
            warnings.warn(message, UserWarning, stacklevel=2)

    @staticmethod
    def __format_speed_transition_validation_issue(issue):
        return road_schema.format_speed_transition_validation_issue(issue)

    def __emit_schema_warnings(self):
        for message in self.__schema_warnings[self.__schema_warnings_emitted_count:]:
            warnings.warn(message, UserWarning, stacklevel=3)
        self.__schema_warnings_emitted_count = len(self.__schema_warnings)

    def __construct_road_from_element_specs(self, elements):
        previous_metadata = None
        previous_v_max_kph = None
        expanded_parts = []
        source_element_lane_metadata = []

        for source_element_index, element in enumerate(elements):
            normalized_metadata = self.__normalize_road_element_metadata(
                element,
                previous_metadata,
                previous_v_max_kph,
            )
            v_max_kph = normalized_metadata["speed_limit_kph"]
            source_element_lane_metadata.append(normalized_metadata)

            new_parts = self.__expanded_element_parts_for_constructor(
                element,
                v_max_kph,
                normalized_metadata,
            )
            for part in new_parts:
                part["source_element_index"] = source_element_index
            expanded_parts.extend(new_parts)

            if len(new_parts) > 0:
                previous_metadata = normalized_metadata
                previous_v_max_kph = normalized_metadata["speed_limit_kph"]

        self.__replace_road_with_expanded_parts(
            expanded_parts,
            source_element_lane_metadata,
        )

    def __expanded_element_parts_for_constructor(self, element, v_max_kph, lane_metadata):
        if (element["type"] == "straight"):
            length = float(element["length"])
            if (length <= 0.0):
                raise ValueError("Road elements must have a positive length.")
            return [{
                "curvature": 0.0,
                "length": length,
                "v_max_kph": float(v_max_kph),
                "lane_metadata": lane_metadata,
            }]

        if (element["type"] != "curved"):
            raise ValueError("Road element type must be 'straight' or 'curved'.")
        if ("angle_in_degrees" in element):
            return self.__expanded_curved_angle_parts_for_constructor(
                curvature=element["curvature"],
                angle_in_degrees=element["angle_in_degrees"],
                v_max_kph=v_max_kph,
                lane_metadata=lane_metadata,
            )
        if ("length" in element):
            return self.__expanded_curved_length_parts_for_constructor(
                curvature=element["curvature"],
                length=element["length"],
                v_max_kph=v_max_kph,
                lane_metadata=lane_metadata,
            )
        raise ValueError(
            "Curved road elements must specify exactly one of "
            "'length' or 'angle_in_degrees'."
        )

    def __expanded_curved_angle_parts_for_constructor(self, curvature, angle_in_degrees, v_max_kph, lane_metadata):
        curvature = float(curvature)
        angle_in_degrees = float(angle_in_degrees)
        if (curvature == 0.0):
            raise ValueError(
                "Curved road element specified by angle must have non-zero "
                "curvature because its straight-line length is undefined."
            )
        if (angle_in_degrees <= 0.0):
            raise ValueError("Curved road element specified by angle must have a positive angle.")
        length = (np.pi / 180.0) * angle_in_degrees / abs(curvature)
        return self.__expanded_curved_length_parts_for_constructor(
            curvature=curvature,
            length=length,
            v_max_kph=v_max_kph,
            lane_metadata=lane_metadata,
        )

    def __expanded_curved_length_parts_for_constructor(self, curvature, length, v_max_kph, lane_metadata):
        curvature = float(curvature)
        length = float(length)
        v_max_kph = float(v_max_kph)
        if (length <= 0.0):
            raise ValueError("Road elements must have a positive length.")
        if (v_max_kph <= 0.0):
            raise ValueError("v_max_kph must be positive.")

        if (curvature == 0.0):
            return [{
                "curvature": 0.0,
                "length": length,
                "v_max_kph": v_max_kph,
                "lane_metadata": lane_metadata,
            }]

        if (
            self.minimum_curvature_magnitude_per_m > 0.0
            and abs(curvature) < self.minimum_curvature_magnitude_per_m
        ):
            raise ValueError(
                "Circular-arc curvature magnitude must be at least "
                "minimum_curvature_magnitude_per_m; requested curvature is not altered."
            )

        angular_span = length * abs(curvature)
        max_angular_span = 0.5 * np.pi
        if (angular_span <= max_angular_span):
            return [{
                "curvature": curvature,
                "length": length,
                "v_max_kph": v_max_kph,
                "lane_metadata": lane_metadata,
            }]

        num_segments = int(np.ceil(angular_span / max_angular_span))
        segment_length = length / num_segments
        parts = []
        for segment_idx in range(num_segments):
            segment_metadata = self.__lane_metadata_for_sub_element(
                lane_metadata,
                start_fraction=segment_idx / num_segments,
                end_fraction=(segment_idx + 1) / num_segments,
                original_element_length=length,
                sub_element_start_progress=segment_idx * segment_length,
                sub_element_length=segment_length,
            )
            parts.append({
                "curvature": curvature,
                "length": segment_length,
                "v_max_kph": v_max_kph,
                "lane_metadata": segment_metadata,
            })
        return parts

    def __replace_road_with_expanded_parts(
        self,
        expanded_parts,
        source_element_lane_metadata,
    ):
        num_elements = len(expanded_parts)
        self.__c = np.empty((num_elements,), dtype=np.float32)
        self.__l = np.empty((num_elements,), dtype=np.float32)
        self.__phi = np.empty((num_elements,), dtype=np.float32)
        self.__isStraight = np.empty((num_elements,), dtype=np.bool_)
        self.__v_max = np.empty((num_elements,), dtype=np.float32)

        self.__start_points = np.empty((num_elements, 2), dtype=np.float32)
        self.__end_points = np.empty((num_elements, 2), dtype=np.float32)
        self.__start_angles = np.empty((num_elements,), dtype=np.float32)
        self.__end_angles = np.empty((num_elements,), dtype=np.float32)
        self.__arc_centers = np.empty((num_elements, 2), dtype=np.float32)
        self.__l_total_at_end = np.empty((num_elements,), dtype=np.float32)
        self.__l_total_at_start = np.empty((num_elements,), dtype=np.float32)
        self.__start_tangent_vectors = np.empty((num_elements, 2), dtype=np.float32)
        self.__start_left_normal_vectors = np.empty((num_elements, 2), dtype=np.float32)
        self.__curvature_signs = np.empty((num_elements,), dtype=np.float32)
        self.__inverse_abs_curvatures = np.empty((num_elements,), dtype=np.float32)
        self.__start_hyperplane_A = np.empty((num_elements, 2), dtype=np.float32)
        self.__start_hyperplane_b = np.empty((num_elements,), dtype=np.float32)
        self.__end_hyperplane_A = np.empty((num_elements, 2), dtype=np.float32)
        self.__end_hyperplane_b = np.empty((num_elements,), dtype=np.float32)

        self.__lane_metadata = [part["lane_metadata"] for part in expanded_parts]
        self.__source_element_lane_metadata = list(source_element_lane_metadata)
        private_indices_by_source = [
            [] for _ in self.__source_element_lane_metadata
        ]
        self.__private_segment_to_source_element_index = np.empty(
            (num_elements,), dtype=np.int32
        )
        for private_segment_index, part in enumerate(expanded_parts):
            source_element_index = int(part["source_element_index"])
            private_indices_by_source[source_element_index].append(
                private_segment_index
            )
            self.__private_segment_to_source_element_index[
                private_segment_index
            ] = source_element_index
        self.__source_element_to_private_segment_indices = tuple(
            np.asarray(indices, dtype=np.int32)
            for indices in private_indices_by_source
        )
        self.__all_lane_widths_are_constant = all(
            bool(metadata.get("lane_widths_are_constant", road_schema.lane_widths_are_constant_in_metadata(metadata)))
            for metadata in self.__lane_metadata
        )

        start_x = 0.0
        start_y = 0.0
        start_angle = 0.0
        start_progress = 0.0

        for element_idx, part in enumerate(expanded_parts):
            curvature = float(part["curvature"])
            length = float(part["length"])
            is_straight = (curvature == 0.0)
            phi = np.nan if is_straight else length * abs(curvature)
            v_max_mps = np.float32(part["v_max_kph"]) * np.float32(1000.0 / 3600.0)

            tangent_x = math.cos(start_angle)
            tangent_y = math.sin(start_angle)
            left_normal_x = -math.sin(start_angle)
            left_normal_y = math.cos(start_angle)

            self.__c[element_idx] = curvature
            self.__l[element_idx] = length
            self.__phi[element_idx] = phi
            self.__isStraight[element_idx] = is_straight
            self.__v_max[element_idx] = v_max_mps
            self.__start_points[element_idx, :] = (start_x, start_y)
            self.__start_angles[element_idx] = start_angle
            self.__l_total_at_start[element_idx] = start_progress
            self.__start_tangent_vectors[element_idx, :] = (tangent_x, tangent_y)
            self.__start_left_normal_vectors[element_idx, :] = (left_normal_x, left_normal_y)
            self.__start_hyperplane_A[element_idx, :] = (-tangent_x, -tangent_y)
            self.__start_hyperplane_b[element_idx] = -tangent_x * start_x - tangent_y * start_y

            if is_straight:
                end_angle = start_angle
                end_x = start_x + length * tangent_x
                end_y = start_y + length * tangent_y
                arc_center_x = np.nan
                arc_center_y = np.nan
                curvature_sign = 0.0
                inverse_abs_curvature = 0.0
            else:
                curvature_sign = 1.0 if curvature >= 0.0 else -1.0
                inverse_abs_curvature = 1.0 / abs(curvature)
                end_angle = Road.__wrap_to_pi(start_angle + curvature_sign * phi)
                angle_start_to_center = start_angle + curvature_sign * 0.5 * np.pi
                arc_center_x = start_x + inverse_abs_curvature * math.cos(angle_start_to_center)
                arc_center_y = start_y + inverse_abs_curvature * math.sin(angle_start_to_center)
                angle_center_to_end = angle_start_to_center + curvature_sign * (phi - np.pi)
                end_x = arc_center_x + inverse_abs_curvature * math.cos(angle_center_to_end)
                end_y = arc_center_y + inverse_abs_curvature * math.sin(angle_center_to_end)

            end_tangent_x = math.cos(end_angle)
            end_tangent_y = math.sin(end_angle)
            end_progress = start_progress + length

            self.__end_points[element_idx, :] = (end_x, end_y)
            self.__end_angles[element_idx] = end_angle
            self.__arc_centers[element_idx, :] = (arc_center_x, arc_center_y)
            self.__l_total_at_end[element_idx] = end_progress
            self.__curvature_signs[element_idx] = curvature_sign
            self.__inverse_abs_curvatures[element_idx] = inverse_abs_curvature
            self.__end_hyperplane_A[element_idx, :] = (end_tangent_x, end_tangent_y)
            self.__end_hyperplane_b[element_idx] = end_tangent_x * end_x + end_tangent_y * end_y

            start_x = end_x
            start_y = end_y
            start_angle = end_angle
            start_progress = end_progress

        self.__v_rec = speed_helpers.compute_recommended_speeds_mps(self.__c, self.__v_max)
        self.__recompute_speed_change_points()
        self.__clear_target_line_caches()

    def __normalize_road_element_metadata(self, element, previous_metadata, previous_v_max_kph):
        return road_schema.normalize_road_element_metadata(
            element,
            previous_metadata,
            previous_v_max_kph,
            self.__road_schema_defaults,
            self.__schema_warnings,
        )

    def __clear_target_line_caches(self):
        self.__target_line_arc_length_lookup_cache.clear()
        self.__constant_target_offsets_cache.clear()
        self.__constant_target_offsets_continuity_cache.clear()
        self.__constant_target_distance_lookup_cache.clear()

    def __lane_metadata_for_sub_element(
        self,
        lane_metadata,
        start_fraction,
        end_fraction,
        original_element_length,
        sub_element_start_progress,
        sub_element_length,
    ):
        return road_schema.lane_metadata_for_sub_element(
            lane_metadata,
            start_fraction,
            end_fraction,
            original_element_length,
            sub_element_start_progress,
            sub_element_length,
        )

    def __default_reference_line_metadata(self, v_max_kph):
        return road_schema.default_reference_line_metadata(
            v_max_kph,
            self.__road_schema_defaults,
        )

    def __progress_context_at(self, progress):
        return lane_geometry.progress_context_at(progress, self.__l, self.__l_total_at_end)

    def __public_progress_context_from_private(self, private_context):
        private_segment_index = int(private_context["element_index"])
        source_element_index = int(
            self.__private_segment_to_source_element_index[private_segment_index]
        )
        private_indices = self.__source_element_to_private_segment_indices[
            source_element_index
        ]
        first_private_index = int(private_indices[0])
        last_private_index = int(private_indices[-1])
        source_start_progress = float(
            self.__l_total_at_end[first_private_index]
            - self.__l[first_private_index]
        )
        source_end_progress = float(self.__l_total_at_end[last_private_index])
        source_length = source_end_progress - source_start_progress
        source_progress = min(
            max(
                float(private_context["clamped_progress_m"])
                - source_start_progress,
                0.0,
            ),
            source_length,
        )
        source_fraction = (
            source_progress / source_length
            if source_length > 0.0
            else 0.0
        )

        public_context = dict(private_context)
        public_context.update({
            "element_index": source_element_index,
            "element_start_progress_m": source_start_progress,
            "element_progress_m": source_progress,
            "element_length_m": source_length,
            "element_fraction": source_fraction,
        })
        return public_context

    def __progress_context_arrays_at(self, progress_values):
        return lane_geometry.progress_context_arrays_at(progress_values, self.__l, self.__l_total_at_end)

    def __progress_contexts_at(self, progress_values):
        return lane_geometry.progress_contexts_at(progress_values, self.__l, self.__l_total_at_end)

    def __lane_metadata_and_context_at(self, progress):
        return lane_geometry.lane_metadata_and_context_at(
            progress,
            self.__lane_metadata,
            self.__l,
            self.__l_total_at_end,
        )

    def __lane_samples_at_progresses(self, progress_values):
        return lane_geometry.lane_samples_at_progresses(
            progress_values,
            self.__lane_metadata,
            self.__l,
            self.__l_total_at_end,
        )

    def __lane_widths_for_metadata_at_fraction(self, metadata, progress_fraction):
        return lane_geometry.lane_widths_for_metadata_at_fraction(metadata, progress_fraction)

    def __lane_width_matrix_for_metadata_at_fractions(self, metadata, side, progress_fractions):
        return lane_geometry.lane_width_matrix_for_metadata_at_fractions(metadata, side, progress_fractions)

    def __lane_center_offset_from_widths(self, widths, lane_index, require_active=True):
        return lane_geometry.lane_center_offset_from_widths(
            widths,
            lane_index,
            self.__active_lane_minimum_width_m,
            require_active,
        )

    def __lane_line_offset_from_widths(self, widths, lane_line_index):
        return lane_geometry.lane_line_offset_from_widths(widths, lane_line_index)

    @staticmethod
    def __lane_line_offsets_from_widths(widths):
        return lane_geometry.lane_line_offsets_from_widths(widths)

    def __lane_units_to_meter_offset_from_widths(self, widths, lane_units, allow_outside=False):
        return lane_geometry.lane_units_to_meter_offset_from_widths(widths, lane_units, allow_outside)

    def __lane_center_offsets_at_progresses_vectorized(self, progress_values, lane_index, require_active=True):
        return lane_geometry.lane_center_offsets_at_progresses_vectorized(
            progress_values,
            lane_index,
            self.__lane_metadata,
            self.__l,
            self.__l_total_at_end,
            self.__active_lane_minimum_width_m,
            require_active,
        )

    def __lane_units_to_meter_offsets_at_progresses_vectorized(self, progress_values, lane_units, allow_outside=False):
        return lane_geometry.lane_units_to_meter_offsets_at_progresses_vectorized(
            progress_values,
            lane_units,
            self.__lane_metadata,
            self.__l,
            self.__l_total_at_end,
            allow_outside,
        )

    def __edge_band_width_at_fraction(self, band, progress_fraction, interpolation):
        return lane_geometry.edge_band_width_at_fraction(band, progress_fraction, interpolation)

    def __require_lane_index(self, lane_idx, widths, require_active):
        return lane_geometry.require_lane_index(
            lane_idx,
            widths,
            self.__active_lane_minimum_width_m,
            require_active,
        )

    def __lane_dicts_at_progress(self, metadata, widths):
        return lane_geometry.lane_dicts_at_progress(
            metadata,
            widths,
            self.__active_lane_minimum_width_m,
        )

    def __lane_line_dicts_at_progress(self, metadata, widths):
        return lane_geometry.lane_line_dicts_at_progress(metadata, widths)

    def __edge_band_dicts_at_progress(self, metadata, widths, progress_fraction):
        return lane_geometry.edge_band_dicts_at_progress(metadata, widths, progress_fraction)

    def get_road_progress_context(self, progress):
        """
        Return the road element and local progress details for a scalar progress query.
        Progress outside the road is clamped for lookup, while the original query
        is preserved in the returned dictionary.
        """
        return copy.deepcopy(
            self.__public_progress_context_from_private(
                self.__progress_context_at(progress)
            )
        )

    def get_lane_widths_at_progress(self, progress):
        """
        Return interpolated left/right lane widths at a scalar road progress value.
        """
        metadata, context = self.__lane_metadata_and_context_at(progress)
        if metadata["lanes"]["reference_line_role"] == "lane_center":
            return {"left": [], "right": []}
        return self.__lane_widths_for_metadata_at_fraction(metadata, context["element_fraction"])

    def get_lane_width_at_progress(self, progress, lane_index, require_active=True):
        """
        Return the interpolated width of one lane. Lane indices are positive for
        left lanes and negative for right lanes. Lane 0 returns 0.0.
        """
        widths = self.get_lane_widths_at_progress(progress)
        return self.__require_lane_index(lane_index, widths, require_active)

    def get_lane_center_offset_at_progress(self, progress, lane_index, require_active=True):
        """
        Return the lateral offset of a lane center relative to the reference line.
        Positive offsets are left of increasing road progress.
        """
        widths = self.get_lane_widths_at_progress(progress)
        return self.__lane_center_offset_from_widths(widths, lane_index, require_active)

    def get_lane_center_offsets_at_progresses(self, progress_values, lane_index, require_active=True):
        """
        Return lane-center offsets for many progress values using one progress
        search pass.
        """
        if int(lane_index) != 0:
            for sample in self.__lane_samples_at_progresses(progress_values):
                if sample["metadata"]["lanes"]["reference_line_role"] == "lane_center":
                    raise ValueError("Centered reference-lane half-widths are not public signed lanes.")
        return self.__lane_center_offsets_at_progresses_vectorized(progress_values, lane_index, require_active)

    def get_lane_line_offset_at_progress(self, progress, lane_line_index):
        """
        Return the lateral offset of a lane line. The reference line has index 0.
        Positive indices are left lane lines moving outward from the reference
        line; negative indices are right lane lines moving outward.
        """
        widths = self.get_lane_widths_at_progress(progress)
        return self.__lane_line_offset_from_widths(widths, lane_line_index)

    def get_lane_line_offsets_for_progresses(self, progress_values, lane_line_index):
        """
        Return one lane-line offset for many progress values using one progress
        search pass.
        """
        samples = self.__lane_samples_at_progresses(progress_values)
        if int(lane_line_index) != 0 and any(
            sample["metadata"]["lanes"]["reference_line_role"] == "lane_center"
            for sample in samples
        ):
            raise ValueError("Centered reference-lane half-widths are not public signed lane lines.")
        return np.array(
            [
                self.__lane_line_offset_from_widths(sample["widths"], lane_line_index)
                for sample in samples
            ],
            dtype=np.float32,
        )

    def get_lane_line_offsets_at_progress(self, progress):
        """
        Return all lane line offsets at a scalar road progress value.
        """
        widths = self.get_lane_widths_at_progress(progress)
        return Road.__lane_line_offsets_from_widths(widths)

    def get_lane_line_marking_at_progress(self, progress, lane_line_index):
        """
        Return the lane marking metadata associated with a lane line index.
        """
        metadata, _ = self.__lane_metadata_and_context_at(progress)
        lane_line_index = int(lane_line_index)
        key = Road.__lane_line_key(lane_line_index)
        marking = metadata["public_lane_markings"]["lane_lines"].get(key)
        if marking is None:
            raise ValueError("Lane line " + key + " does not exist at this progress.")
        return copy.deepcopy(marking)

    def convert_lane_units_to_meter_offset(self, progress, lane_units, allow_outside=False):
        """
        Convert fractional lane units to a meter offset from the reference line.
        For example, +0.5 is the center of the first left lane and +1.5 is the
        center of the second left lane. Negative values address right-side lanes.
        """
        widths = self.get_lane_widths_at_progress(progress)
        return self.__lane_units_to_meter_offset_from_widths(widths, lane_units, allow_outside)

    def convert_lane_units_to_meter_offsets(self, progress_values, lane_units, allow_outside=False):
        """
        Convert one fractional lane-unit target to meter offsets for many progress
        values using one progress search pass.
        """
        if float(lane_units) != 0.0:
            for sample in self.__lane_samples_at_progresses(progress_values):
                if sample["metadata"]["lanes"]["reference_line_role"] == "lane_center":
                    raise ValueError("Centered reference-lane half-widths are not public lane coordinates.")
        return self.__lane_units_to_meter_offsets_at_progresses_vectorized(progress_values, lane_units, allow_outside)

    def get_edge_band_offsets_at_progress(self, progress, side=None):
        """
        Return edge-band lateral ranges at a scalar road progress value.
        """
        metadata, context = self.__lane_metadata_and_context_at(progress)
        widths = self.__lane_widths_for_metadata_at_fraction(metadata, context["element_fraction"])
        edge_bands = self.__edge_band_dicts_at_progress(metadata, widths, context["element_fraction"])
        if side is None:
            return edge_bands
        if side not in ("left", "right"):
            raise ValueError("side must be 'left', 'right', or None.")
        return copy.deepcopy(edge_bands[side])

    def get_cross_section_at_progress(self, progress):
        """
        Return lane, lane-line, and edge-band geometry at a scalar road progress
        value. The geometry is expressed as lateral offsets from the reference
        line, with positive offsets to the left of increasing road progress.
        """
        return self.__cross_section_from_lane_sample(self.__lane_samples_at_progresses([progress])[0])

    def get_cross_sections_at_progresses(self, progress_values):
        """
        Return cross-sections for many progress values using one progress search
        pass.
        """
        return [
            self.__cross_section_from_lane_sample(sample)
            for sample in self.__lane_samples_at_progresses(progress_values)
        ]

    def get_reference_lane_bounds_at_progress(self, progress):
        """
        Return lateral bounds for the convenience lane centered on the
        reference line.

        This helper is available only for road elements using
        ``reference_line_role='lane_center'``. Bounds are signed offsets from
        the reference line, so constraints can use
        ``right_bound_m <= lateral_error <= left_bound_m``.
        """
        sample = self.__lane_samples_at_progresses([progress])[0]
        result = lane_geometry.reference_lane_bounds_from_lane_sample(sample)
        result["element_index"] = self.__public_progress_context_from_private(
            sample["context"]
        )["element_index"]
        return result

    def get_reference_lane_bounds_at_progresses(self, progress_values):
        """
        Vectorized version of ``get_reference_lane_bounds_at_progress``.
        """
        result = lane_geometry.reference_lane_bounds_at_progresses(
            progress_values,
            self.__lane_metadata,
            self.__l,
            self.__l_total_at_end,
        )
        result["element_index"] = self.__private_segment_to_source_element_index[
            result["element_index"]
        ].astype(np.int32, copy=False)
        return result

    def __cross_section_from_lane_sample(self, sample):
        result = lane_geometry.cross_section_from_lane_sample(
            sample,
            self.__active_lane_minimum_width_m,
        )
        public_context = self.__public_progress_context_from_private(
            sample["context"]
        )
        result["element_index"] = public_context["element_index"]
        result["element_fraction"] = public_context["element_fraction"]
        return result

    def lookup_lateral_region_at_progress(self, progress, lateral_offset_m, tolerance=1e-9):
        """
        Classify a lateral offset at a road progress value as a lane line, lane,
        edge band, or outside the specified road cross-section.
        """
        return lane_geometry.lookup_lateral_region_in_cross_section(
            self.get_cross_section_at_progress(progress),
            lateral_offset_m,
            tolerance,
        )


    def get_c(self): return np.copy(self.__c)
    def get_l(self): return np.copy(self.__l)
    def get_phi(self): return np.copy(self.__phi)
    def get_isStraight(self): return np.copy(self.__isStraight)
    def get_start_points(self): return np.copy(self.__start_points)
    def get_end_points(self): return np.copy(self.__end_points)
    def get_start_angles(self): return np.copy(self.__start_angles)
    def get_end_angles(self): return np.copy(self.__end_angles)
    def get_arc_centers(self): return np.copy(self.__arc_centers)
    def get_l_total_at_end(self): return np.copy(self.__l_total_at_end)
    def get_start_hyperplane_A(self): return np.copy(self.__start_hyperplane_A)
    def get_start_hyperplane_b(self): return np.copy(self.__start_hyperplane_b)
    def get_end_hyperplane_A(self): return np.copy(self.__end_hyperplane_A)
    def get_end_hyperplane_b(self): return np.copy(self.__end_hyperplane_b)

    def get_speed_limits_mps(self):
        return speed_helpers.public_values_from_private_segments(
            self.__v_max,
            self.__source_element_to_private_segment_indices,
        )
    def get_recommended_speeds_mps(self):
        return speed_helpers.public_values_from_private_segments(
            self.__v_rec,
            self.__source_element_to_private_segment_indices,
        )

    def get_road_schema_defaults(self): return copy.deepcopy(self.__road_schema_defaults)
    def get_road_validation_config(self): return copy.deepcopy(self.__road_validation_config)
    def get_road_element_lane_metadata(self):
        return [
            road_schema.public_road_element_metadata(metadata)
            for metadata in self.__source_element_lane_metadata
        ]
    def get_schema_warnings(self): return list(self.__schema_warnings)
    def get_validation_warnings(self): return list(self.__validation_warnings)
    @property
    def active_lane_minimum_width_m(self):
        return float(self.__active_lane_minimum_width_m)

    @property
    def requested_road_spec(self):
        return copy.deepcopy(self.__requested_road_spec)

    def validate_speed_transitions(
        self,
        speed_sources=None,
        deceleration_limit_mps2=3.0,
        reaction_time_s=0.0,
        distance_margin_m=0.0,
    ):
        """
        Validate that adjacent speed drops leave enough distance for braking.

        The validation is performed on speed-change events, not on dense road
        samples. For example, a 100 -> 80 -> 40 km/h profile checks both
        adjacent drops, including whether the 80 -> 40 drop has enough distance.

        Parameters
        ----------
            speed_sources : list[str]
                Sources to validate. Supported values are "speed_limit" and
                "recommended_speed".
            deceleration_limit_mps2 : float
                Maximum acceptable deceleration used to compute required
                braking distance.
            reaction_time_s : float
                Optional reaction-time allowance applied before braking.
            distance_margin_m : float
                Optional extra distance margin added to the required distance.

        Returns
        -------
            issues : list[dict]
                One dictionary per violating speed drop.
        """
        if speed_sources is None:
            speed_sources = ["speed_limit", "recommended_speed"]
        elif not isinstance(speed_sources, list):
            raise TypeError("speed_sources must be a list.")
        else:
            speed_sources = list(speed_sources)
        if len(speed_sources) == 0:
            raise ValueError("speed_sources cannot be empty.")
        for speed_source in speed_sources:
            Road.__validate_string_option(
                speed_source,
                "speed_sources",
                Road.VALID_SPEED_TRANSITION_SOURCES,
            )
        if len(set(speed_sources)) != len(speed_sources):
            raise ValueError("speed_sources must contain unique values.")

        numeric_values = {
            "deceleration_limit_mps2": deceleration_limit_mps2,
            "reaction_time_s": reaction_time_s,
            "distance_margin_m": distance_margin_m,
        }
        for field_name, value in numeric_values.items():
            if isinstance(value, (bool, np.bool_)):
                raise TypeError(field_name + " must be a finite real number.")
            try:
                value = float(value)
            except (TypeError, ValueError, OverflowError) as exc:
                raise TypeError(field_name + " must be a finite real number.") from exc
            if not np.isfinite(value):
                raise ValueError(field_name + " must be finite.")
            numeric_values[field_name] = value
        deceleration_limit_mps2 = numeric_values["deceleration_limit_mps2"]
        reaction_time_s = numeric_values["reaction_time_s"]
        distance_margin_m = numeric_values["distance_margin_m"]
        if deceleration_limit_mps2 <= 0.0:
            raise ValueError("deceleration_limit_mps2 must be positive.")
        if reaction_time_s < 0.0:
            raise ValueError("reaction_time_s must be non-negative.")
        if distance_margin_m < 0.0:
            raise ValueError("distance_margin_m must be non-negative.")

        issues = []
        for speed_source in speed_sources:
            if speed_source == "speed_limit":
                speed_values = self.__next_v_max
                speed_progresses = self.__l_total_at_next_v_max
            else:
                speed_values = self.__next_v_rec
                speed_progresses = self.__l_total_at_next_v_rec

            if speed_values.shape[0] < 2:
                continue

            for transition_idx in range(1, speed_values.shape[0]):
                from_speed_mps = float(speed_values[transition_idx - 1])
                to_speed_mps = float(speed_values[transition_idx])
                if (
                    not np.isfinite(from_speed_mps) or
                    not np.isfinite(to_speed_mps) or
                    from_speed_mps <= 0.0 or
                    to_speed_mps <= 0.0 or
                    to_speed_mps >= from_speed_mps
                ):
                    continue

                from_progress_m = float(speed_progresses[transition_idx - 1])
                to_progress_m = float(speed_progresses[transition_idx])
                available_distance_m = to_progress_m - from_progress_m
                reaction_distance_m = reaction_time_s * from_speed_mps
                braking_distance_m = (
                    (from_speed_mps * from_speed_mps - to_speed_mps * to_speed_mps) /
                    (2.0 * deceleration_limit_mps2)
                )
                required_distance_m = reaction_distance_m + braking_distance_m + distance_margin_m
                effective_braking_distance_m = available_distance_m - reaction_distance_m - distance_margin_m
                if effective_braking_distance_m <= 0.0:
                    required_deceleration_mps2 = float("inf")
                else:
                    required_deceleration_mps2 = (
                        (from_speed_mps * from_speed_mps - to_speed_mps * to_speed_mps) /
                        (2.0 * effective_braking_distance_m)
                    )

                if required_distance_m <= available_distance_m + 1e-9:
                    continue

                issues.append({
                    "type": "speed_transition_validation",
                    "speed_sources": [speed_source],
                    "transition_index": transition_idx,
                    "from_progress_m": from_progress_m,
                    "to_progress_m": to_progress_m,
                    "available_distance_m": available_distance_m,
                    "from_speed_mps": from_speed_mps,
                    "to_speed_mps": to_speed_mps,
                    "from_speed_kph": from_speed_mps * 3.6,
                    "to_speed_kph": to_speed_mps * 3.6,
                    "deceleration_limit_mps2": deceleration_limit_mps2,
                    "reaction_time_s": reaction_time_s,
                    "reaction_distance_m": reaction_distance_m,
                    "distance_margin_m": distance_margin_m,
                    "braking_distance_m": braking_distance_m,
                    "required_distance_m": required_distance_m,
                    "required_deceleration_mps2": required_deceleration_mps2,
                })

        return issues

    def get_lane_counts(self):
        return [
            {
                "left": len(element_metadata["lanes"].get("left", [])),
                "right": len(element_metadata["lanes"].get("right", [])),
            }
            for element_metadata in self.__source_element_lane_metadata
        ]

    @property
    def total_length_m(self):
        if self.__l_total_at_end.shape[0] == 0:
            raise ValueError("Road has no elements.")
        return float(self.__l_total_at_end[-1])

    @staticmethod
    def compute_recommended_speed_mps(curvature_per_m, speed_limit_mps):
        """
        Compute a recommended speed from curvature and a speed limit, in SI units.

        Method:
        1) Map curvature kappa to radius r = 1/|kappa|.
        2) Lookup a posted road-sign speed (km/h) from a stepwise radius->speed table,
           where each interval maps to the nearest lower posted sign speed.
        3) Convert to m/s and cap by the provided max_speed.

        Reference: https://austroads.gov.au/publications/road-design/agrd03 (Australian Road Design Guide)

        Notes:
        - If either input is NaN or speed_limit_mps <= 0, returns NaN.
        - For |curvature_per_m| ~ 0, returns speed_limit_mps.
        """
        return speed_helpers.compute_recommended_speed_mps(
            curvature_per_m,
            speed_limit_mps,
        )

    def set_speed_limits_mps(self, speed_limits_mps):
        """
        Set per-element speed limits (m/s) and update recommendations.

        Parameters
        ----------
            v_max_array : numpy array-like, shape (num_elements,)
                Maximum speeds to assign to each road element (units: m/s).

        Returns
        -------
        Nothing
        """
        public_speed_limits_mps = speed_helpers.normalize_public_speed_limits_mps(
            speed_limits_mps,
            len(self.__source_element_to_private_segment_indices),
        )
        self.__v_max = speed_helpers.private_values_from_public_elements(
            public_speed_limits_mps,
            self.__source_element_to_private_segment_indices,
            self.__c.shape[0],
        )
        for source_element_index, speed_limit_mps in enumerate(
            public_speed_limits_mps
        ):
            self.__source_element_lane_metadata[source_element_index][
                "speed_limit_kph"
            ] = float(speed_limit_mps) * 3.6
            for private_segment_index in self.__source_element_to_private_segment_indices[
                source_element_index
            ]:
                self.__lane_metadata[int(private_segment_index)][
                    "speed_limit_kph"
                ] = float(speed_limit_mps) * 3.6
        # Recompute recommended speeds for all elements
        self.recompute_recommended_speeds()

    def set_element_speed_limit_mps(self, element_index, speed_limit_mps):
        """
        Set the maximum speed (m/s) for a specific element and update its recommended speed.
        """
        element_index = speed_helpers.normalize_public_element_index(
            element_index,
            len(self.__source_element_to_private_segment_indices),
        )
        normalized_speed = speed_helpers.normalize_public_speed_limits_mps(
            [speed_limit_mps],
            1,
        )[0]
        private_indices = self.__source_element_to_private_segment_indices[
            element_index
        ]
        self.__v_max[private_indices] = normalized_speed
        self.__v_rec[private_indices] = speed_helpers.compute_recommended_speeds_mps(
            self.__c[private_indices],
            self.__v_max[private_indices],
        )
        self.__source_element_lane_metadata[element_index]["speed_limit_kph"] = (
            float(normalized_speed) * 3.6
        )
        for private_segment_index in private_indices:
            self.__lane_metadata[int(private_segment_index)]["speed_limit_kph"] = (
                float(normalized_speed) * 3.6
            )
        self.__recompute_speed_change_points()

    def recompute_recommended_speeds(self):
        """
        Recompute recommended speeds from curvature and per-element speed limits.
        """
        # Ensure arrays exist and have correct length
        if self.__v_rec.shape[0] != self.__c.shape[0]:
            # Resize/initialize if needed (e.g., when loaded from older state)
            self.__v_rec = np.full_like(self.__c, np.nan, dtype=np.float32)
        if self.__v_max.shape[0] != self.__c.shape[0]:
            self.__v_max = np.full_like(self.__c, np.nan, dtype=np.float32)
        self.__v_rec = speed_helpers.compute_recommended_speeds_mps(self.__c, self.__v_max)
        self.__recompute_speed_change_points()

    @staticmethod
    def __speed_values_are_different(value_1, value_2):
        return speed_helpers.speed_values_are_different(value_1, value_2)

    def __recompute_speed_change_points(self):
        """
        Rebuild lookup arrays for the next speed-limit and recommended-speed changes.
        """
        self.__next_v_max = np.empty((0,), dtype=np.float32)
        self.__l_total_at_next_v_max = np.empty((0,), dtype=np.float32)
        self.__next_v_rec = np.empty((0,), dtype=np.float32)
        self.__l_total_at_next_v_rec = np.empty((0,), dtype=np.float32)

        if (
            self.__c.shape[0] == 0 or
            self.__v_max.shape[0] != self.__c.shape[0] or
            self.__v_rec.shape[0] != self.__c.shape[0]
        ):
            return

        element_start_progresses = self.__l_total_at_end - self.__l
        self.__next_v_max, self.__l_total_at_next_v_max = speed_helpers.speed_change_points(
            self.__v_max,
            element_start_progresses,
        )
        self.__next_v_rec, self.__l_total_at_next_v_rec = speed_helpers.speed_change_points(
            self.__v_rec,
            element_start_progresses,
        )

    def __coordinates_at_lateral_offsets(self, progress_values, offset_values):
        return reference_geometry.coordinates_at_lateral_offsets(
            progress_values,
            offset_values,
            self.convert_progression_to_coordinates,
        )

    @staticmethod
    def coordinates_at_lateral_offsets_from_reference_points(reference_points, reference_angles, offset_values):
        """
        Offset already-sampled reference-line points laterally without
        re-sampling road progress.
        """
        return road_utils.coordinates_at_lateral_offsets_from_reference_points(
            reference_points,
            reference_angles,
            offset_values,
        )

    def convert_progression_and_lateral_offsets_to_coordinates(self, progression_queries, lateral_offsets):
        """
        Convert road progress values plus lateral offsets into world-frame
        coordinates. Positive lateral offsets are left of increasing road
        progress.
        """
        return self.__coordinates_at_lateral_offsets(progression_queries, lateral_offsets)

    def get_cone_points_from_spec(self, rng=None):
        return road_cones.get_cone_points_from_spec(
            self,
            self.__source_element_lane_metadata,
            self.__l,
            self.__l_total_at_end,
            rng=rng,
            source_element_to_private_segment_indices=(
                self.__source_element_to_private_segment_indices
            ),
        )

    def get_cone_points_and_arrays_from_spec(self, rng=None):
        return road_cones.get_cone_points_and_arrays_from_spec(
            self,
            self.__source_element_lane_metadata,
            self.__l,
            self.__l_total_at_end,
            rng=rng,
            source_element_to_private_segment_indices=(
                self.__source_element_to_private_segment_indices
            ),
        )

    def get_cone_arrays_from_spec(self, rng=None):
        return road_cones.get_cone_arrays_from_spec(
            self,
            self.__source_element_lane_metadata,
            self.__l,
            self.__l_total_at_end,
            rng=rng,
            source_element_to_private_segment_indices=(
                self.__source_element_to_private_segment_indices
            ),
        )

    def get_cone_count_upper_bound_from_spec(self):
        return road_cones.get_cone_count_upper_bound_from_spec(
            self.__source_element_lane_metadata,
            self.__l,
            source_element_to_private_segment_indices=(
                self.__source_element_to_private_segment_indices
            ),
        )

    @staticmethod
    def cone_point_arrays_from_cone_points(cone_points):
        return road_cones.cone_point_arrays_from_cone_points(cone_points)

    def plot_road_on_matplotlib_axis(
        self,
        axis_handle,
        should_render_lanes=True,
        should_render_lane_lines=True,
        should_render_edge_bands=True,
        should_render_cones=True,
        show_lane_centers=False,
        should_render_reference_line=True,
        progress_step_m=1.0,
        cone_rng_seed=0,
        visualization_theme=None,
    ):
        from dreamgym.visualization.autonomous_driving._road_presentation import (
            _resolve_marking_colors,
            _resolve_road_presentation_style,
        )
        from dreamgym.visualization.autonomous_driving.theme import (
            resolve_autonomous_driving_visualization_theme,
        )

        style = _resolve_road_presentation_style(
            resolve_autonomous_driving_visualization_theme(visualization_theme)
        )
        resolved_marking_colors = _resolve_marking_colors(self.__lane_metadata, style)
        from dreamgym.visualization.autonomous_driving._road_matplotlib import plot_road

        return plot_road(
            self,
            axis_handle,
            self.__l,
            self.__l_total_at_end,
            self.__reference_line_samples_at_progresses,
            self.__lane_samples_at_progresses,
            self.__cross_section_from_lane_sample,
            self.get_cone_points_from_spec,
            resolved_marking_colors,
            style,
            should_render_lanes=should_render_lanes,
            should_render_lane_lines=should_render_lane_lines,
            should_render_edge_bands=should_render_edge_bands,
            should_render_cones=should_render_cones,
            show_lane_centers=show_lane_centers,
            should_render_reference_line=should_render_reference_line,
            progress_step_m=progress_step_m,
            cone_rng_seed=cone_rng_seed,
        )

    def sample_reference_line_drive(
        self,
        speed_mode="recommended_speed",
        speed_mps=None,
        speed_scale=1.0,
        start_progress_m=0.0,
        end_progress_m=None,
        fps=10.0,
        max_duration_s=None,
        min_speed_mps=0.1,
    ):
        """
        Sample a non-simulated drive along the road reference line.

        The returned trace is useful for road-owned animations and diagnostics.
        The vehicle progress advances according to the sampled speed at the
        current progress. No bicycle dynamics are simulated.
        """
        if speed_mode not in ("recommended_speed", "speed_limit", "constant"):
            raise ValueError("speed_mode must be 'recommended_speed', 'speed_limit', or 'constant'.")
        fps = float(fps)
        if fps <= 0.0:
            raise ValueError("fps must be positive.")
        speed_scale = float(speed_scale)
        if speed_scale <= 0.0:
            raise ValueError("speed_scale must be positive.")
        min_speed_mps = float(min_speed_mps)
        if min_speed_mps <= 0.0:
            raise ValueError("min_speed_mps must be positive.")
        if max_duration_s is not None and float(max_duration_s) <= 0.0:
            raise ValueError("max_duration_s must be positive or None.")

        total_length = self.total_length_m
        start_progress = float(start_progress_m)
        if end_progress_m is None:
            end_progress = total_length
        else:
            end_progress = float(end_progress_m)
        start_progress = min(max(start_progress, 0.0), total_length)
        end_progress = min(max(end_progress, 0.0), total_length)
        if end_progress < start_progress:
            raise ValueError("end_progress_m must be greater than or equal to start_progress_m.")

        if speed_mode == "constant":
            if speed_mps is None:
                speed_mps = 5.0
            speed_mps = float(speed_mps)
            if speed_mps <= 0.0:
                raise ValueError("speed_mps must be positive for constant-speed animation.")

        dt = 1.0 / fps
        progress_values = []
        time_values = []
        speed_values = []

        progress = start_progress
        elapsed = 0.0
        while True:
            samples = self.__reference_line_samples_at_progresses(
                [progress],
                include_coordinates=False,
                include_angles=False,
                include_curvatures=False,
                include_speeds=True,
                include_element_indices=False,
                progression_queries_are_in_bounds=True,
            )
            if speed_mode == "recommended_speed":
                this_speed = float(samples["recommended_speeds"][0])
            elif speed_mode == "speed_limit":
                this_speed = float(samples["speed_limits"][0])
            else:
                this_speed = float(speed_mps)
            this_speed *= speed_scale
            if (not np.isfinite(this_speed)) or this_speed <= 0.0:
                raise ValueError("Sampled drive speed must be finite and positive.")
            this_speed = max(this_speed, min_speed_mps)

            progress_values.append(progress)
            time_values.append(elapsed)
            speed_values.append(this_speed)

            if progress >= end_progress - 1e-9:
                break
            if max_duration_s is not None and elapsed >= float(max_duration_s) - 1e-9:
                break

            next_progress = min(progress + this_speed * dt, end_progress)
            if next_progress <= progress + 1e-12:
                break
            progress = next_progress
            elapsed += dt

        progress_array = np.asarray(progress_values, dtype=np.float32)
        reference_samples = self.__reference_line_samples_at_progresses(
            progress_array,
            include_coordinates=True,
            include_angles=True,
            include_curvatures=False,
            include_speeds=True,
            include_element_indices=True,
            progression_queries_are_in_bounds=True,
            return_source_element_indices=True,
        )
        coordinates = reference_samples["coordinates"]
        return {
            "time_s": np.asarray(time_values, dtype=np.float32),
            "progress_m": progress_array,
            "progress_fraction": (
                progress_array / np.float32(total_length)
                if total_length > 0.0
                else np.zeros_like(progress_array)
            ),
            "px": coordinates[:, 0].astype(np.float32, copy=False),
            "py": coordinates[:, 1].astype(np.float32, copy=False),
            "theta": reference_samples["angles"].astype(np.float32, copy=False),
            "speed_mps": np.asarray(speed_values, dtype=np.float32),
            "speed_limit_mps": reference_samples["speed_limits"].astype(np.float32, copy=False),
            "recommended_speed_mps": reference_samples["recommended_speeds"].astype(np.float32, copy=False),
            "element_index": reference_samples["element_indices"].astype(np.int32, copy=False),
        }

    def __outer_offset_for_speed_sign_at_progress(self, progress, side):
        if self.__l_total_at_end.shape[0] == 0:
            return 0.0
        if side not in ("left", "right"):
            raise ValueError("Speed sign side must be 'left' or 'right'.")
        progress = min(max(float(progress) + 1e-6, 0.0), float(self.__l_total_at_end[-1]))
        cross_section = self.get_cross_section_at_progress(progress)
        if side == "left":
            left_outer_offset = 0.0
            if len(cross_section["edge_bands"]["left"]) > 0:
                left_outer_offset = cross_section["edge_bands"]["left"][-1]["outer_offset_m"]
            elif len(cross_section["lane_widths"]["left"]) > 0:
                left_outer_offset = sum(cross_section["lane_widths"]["left"])
            return float(left_outer_offset)

        right_outer_offset = 0.0
        if len(cross_section["edge_bands"]["right"]) > 0:
            right_outer_offset = cross_section["edge_bands"]["right"][-1]["outer_offset_m"]
        elif len(cross_section["lane_widths"]["right"]) > 0:
            right_outer_offset = -sum(cross_section["lane_widths"]["right"])
        return float(right_outer_offset)

    def __speed_change_indices(self, speed_values):
        indices = []
        for idx, speed_value in enumerate(speed_values):
            if idx == 0 or Road.__speed_values_are_different(speed_values[idx - 1], speed_value):
                indices.append(idx)
        return indices

    def plot_speed_signs_on_matplotlib_axis(
        self,
        axis_handle,
        should_render_speed_limits=True,
        should_render_recommended_speeds=True,
        speed_limit_lateral_gap_m=1.0,
        recommended_speed_lateral_gap_m=1.0,
        speed_limit_side="left",
        recommended_speed_side="right",
        visualization_theme=None,
    ):
        from dreamgym.visualization.autonomous_driving._road_presentation import _resolve_road_presentation_style
        from dreamgym.visualization.autonomous_driving.theme import resolve_autonomous_driving_visualization_theme

        style = _resolve_road_presentation_style(
            resolve_autonomous_driving_visualization_theme(visualization_theme)
        )
        from dreamgym.visualization.autonomous_driving._road_matplotlib import plot_speed_signs

        return plot_speed_signs(
            axis_handle,
            self.__l_total_at_end,
            self.__l_total_at_start,
            self.__v_max,
            self.__v_rec,
            self.__outer_offset_for_speed_sign_at_progress,
            self.convert_progression_and_lateral_offsets_to_coordinates,
            self.__speed_change_indices,
            style,
            should_render_speed_limits=should_render_speed_limits,
            should_render_recommended_speeds=should_render_recommended_speeds,
            speed_limit_lateral_gap_m=speed_limit_lateral_gap_m,
            recommended_speed_lateral_gap_m=recommended_speed_lateral_gap_m,
            speed_limit_side=speed_limit_side,
            recommended_speed_side=recommended_speed_side,
        )

    def plot_speed_change_markers_on_matplotlib_axis(
        self,
        axis_handle,
        should_render_speed_limits=True,
        should_render_recommended_speeds=True,
        speed_limit_side="left",
        recommended_speed_side="right",
        speed_limit_lateral_gap_m=0.6,
        recommended_speed_lateral_gap_m=0.6,
        visualization_theme=None,
    ):
        from dreamgym.visualization.autonomous_driving._road_presentation import _resolve_road_presentation_style
        from dreamgym.visualization.autonomous_driving.theme import resolve_autonomous_driving_visualization_theme

        style = _resolve_road_presentation_style(
            resolve_autonomous_driving_visualization_theme(visualization_theme)
        )
        from dreamgym.visualization.autonomous_driving._road_matplotlib import plot_speed_change_markers

        return plot_speed_change_markers(
            axis_handle,
            self.__l_total_at_end,
            self.__l_total_at_start,
            self.__v_max,
            self.__v_rec,
            self.__outer_offset_for_speed_sign_at_progress,
            self.convert_progression_and_lateral_offsets_to_coordinates,
            self.__speed_change_indices,
            style,
            should_render_speed_limits=should_render_speed_limits,
            should_render_recommended_speeds=should_render_recommended_speeds,
            speed_limit_side=speed_limit_side,
            recommended_speed_side=recommended_speed_side,
            speed_limit_lateral_gap_m=speed_limit_lateral_gap_m,
            recommended_speed_lateral_gap_m=recommended_speed_lateral_gap_m,
        )

    def __road_width_for_animation_zoom(self):
        if self.__l_total_at_end.shape[0] == 0:
            return 2.0
        total_length = self.total_length_m
        num_samples = max(2, min(100, int(np.ceil(total_length / 2.0)) + 1))
        progress_values = np.linspace(0.0, total_length, num=num_samples, dtype=np.float32)
        max_width = 0.0
        for cross_section in self.get_cross_sections_at_progresses(progress_values):
            left_outer = 0.0
            right_outer = 0.0
            if len(cross_section["edge_bands"]["left"]) > 0:
                left_outer = cross_section["edge_bands"]["left"][-1]["outer_offset_m"]
            elif len(cross_section["lane_widths"]["left"]) > 0:
                left_outer = sum(cross_section["lane_widths"]["left"])
            if len(cross_section["edge_bands"]["right"]) > 0:
                right_outer = cross_section["edge_bands"]["right"][-1]["outer_offset_m"]
            elif len(cross_section["lane_widths"]["right"]) > 0:
                right_outer = -sum(cross_section["lane_widths"]["right"])
            max_width = max(max_width, float(left_outer - right_outer))
        return max(max_width, 2.0)

    def __minimum_lane_width_for_animation_vehicle(self):
        lane_widths = []
        for metadata in self.__lane_metadata:
            lane_widths.extend(float(width) for width in metadata.get("left_lane_widths_start", []))
            lane_widths.extend(float(width) for width in metadata.get("left_lane_widths_end", []))
            lane_widths.extend(float(width) for width in metadata.get("right_lane_widths_start", []))
            lane_widths.extend(float(width) for width in metadata.get("right_lane_widths_end", []))
        positive_widths = [width for width in lane_widths if width > 1e-9]
        if len(positive_widths) == 0:
            return 1.5
        return min(positive_widths)

    @staticmethod
    def __zoom_limits(center_x, center_y, zoom_width_m, zoom_height_m):
        half_width = 0.5 * float(zoom_width_m)
        half_height = 0.5 * float(zoom_height_m)
        return (
            (float(center_x) - half_width, float(center_x) + half_width),
            (float(center_y) - half_height, float(center_y) + half_height),
        )

    @staticmethod
    def __body_frame_limits_from_world_limits(world_xlim, world_ylim, px, py, theta):
        corners = np.array(
            [
                [world_xlim[0], world_ylim[0]],
                [world_xlim[0], world_ylim[1]],
                [world_xlim[1], world_ylim[0]],
                [world_xlim[1], world_ylim[1]],
            ],
            dtype=np.float32,
        )
        shifted_corners = corners - np.array([[float(px), float(py)]], dtype=np.float32)
        cos_theta = float(np.cos(-float(theta)))
        sin_theta = float(np.sin(-float(theta)))
        rotation = np.array(
            [
                [cos_theta, -sin_theta],
                [sin_theta, cos_theta],
            ],
            dtype=np.float32,
        )
        body_corners = shifted_corners @ rotation.T
        return (
            (float(np.min(body_corners[:, 0])), float(np.max(body_corners[:, 0]))),
            (float(np.min(body_corners[:, 1])), float(np.max(body_corners[:, 1]))),
        )

    @staticmethod
    def __interpolate_limits(start_limits, end_limits, alpha):
        return tuple(
            (1.0 - alpha) * float(start_value) + alpha * float(end_value)
            for start_value, end_value in zip(start_limits, end_limits)
        )

    def animate_reference_line_drive_with_matplotlib(
        self,
        speed_mode="recommended_speed",
        speed_mps=None,
        speed_scale=1.0,
        start_progress_m=0.0,
        end_progress_m=None,
        fps=10.0,
        max_duration_s=None,
        vehicle_style="car",
        zoom_mode="follow",
        start_view_mode="full_then_zoom",
        view_orientation="world",
        zoom_width_m=None,
        zoom_height_m=None,
        zoom_road_width_factor=10.0,
        intro_duration_s=2.0,
        figure_size=(6.0, 4.0),
        dpi=80,
        should_render_lanes=True,
        should_render_lane_lines=True,
        should_render_edge_bands=True,
        should_render_cones=True,
        should_render_reference_line=True,
        should_render_speed_signs=False,
        show_details=True,
        show_progress_bar=True,
        progress_bar_position="top",
        road_progress_step_m=1.0,
        cone_rng_seed=0,
        speed_sign_display_mode="roadside",
        should_render_speed_change_markers=True,
        save_path=None,
        should_save=True,
        writer="pillow",
        return_animation=True,
        return_details=False,
        visualization_theme=None,
    ):
        """Animate a simple non-simulated vehicle moving along the reference line."""
        if zoom_mode not in ("follow", "fixed", "full_road"):
            raise ValueError("zoom_mode must be 'follow', 'fixed', or 'full_road'.")
        if start_view_mode not in ("full_then_zoom", "zoomed"):
            raise ValueError("start_view_mode must be 'full_then_zoom' or 'zoomed'.")
        if view_orientation not in ("world", "car"):
            raise ValueError("view_orientation must be 'world' or 'car'.")
        if progress_bar_position not in ("top", "bottom"):
            raise ValueError("progress_bar_position must be 'top' or 'bottom'.")
        if speed_sign_display_mode not in ("roadside", "fixed", "both"):
            raise ValueError("speed_sign_display_mode must be 'roadside', 'fixed', or 'both'.")
        if vehicle_style not in ("none", "dot", "car"):
            raise ValueError("vehicle_style must be 'none', 'dot', or 'car'.")

        from dreamgym.visualization.autonomous_driving._road_presentation import (
            _resolve_marking_colors,
            _resolve_road_presentation_style,
        )
        from dreamgym.visualization.autonomous_driving.theme import (
            resolve_autonomous_driving_visualization_theme,
        )

        theme = resolve_autonomous_driving_visualization_theme(visualization_theme)
        style = _resolve_road_presentation_style(theme)
        resolved_marking_colors = _resolve_marking_colors(self.__lane_metadata, style)
        motion = self.sample_reference_line_drive(
            speed_mode=speed_mode,
            speed_mps=speed_mps,
            speed_scale=speed_scale,
            start_progress_m=start_progress_m,
            end_progress_m=end_progress_m,
            fps=fps,
            max_duration_s=max_duration_s,
        )
        if motion["progress_m"].shape[0] == 0:
            raise ValueError("Reference-line drive animation has no frames.")

        from dreamgym.visualization.autonomous_driving._road_matplotlib import (
            animate_reference_line_drive,
        )

        return animate_reference_line_drive(
            self,
            motion,
            self.__road_width_for_animation_zoom(),
            self.__minimum_lane_width_for_animation_vehicle(),
            resolved_marking_colors,
            style,
            theme,
            self.__l,
            self.__l_total_at_end,
            self.__l_total_at_start,
            self.__v_max,
            self.__v_rec,
            self.__reference_line_samples_at_progresses,
            self.__lane_samples_at_progresses,
            self.__cross_section_from_lane_sample,
            self.get_cone_points_from_spec,
            self.__outer_offset_for_speed_sign_at_progress,
            self.convert_progression_and_lateral_offsets_to_coordinates,
            self.__speed_change_indices,
            Road.__zoom_limits,
            Road.__body_frame_limits_from_world_limits,
            Road.__interpolate_limits,
            fps=float(fps),
            vehicle_style=vehicle_style,
            zoom_mode=zoom_mode,
            start_view_mode=start_view_mode,
            view_orientation=view_orientation,
            zoom_width_m=zoom_width_m,
            zoom_height_m=zoom_height_m,
            zoom_road_width_factor=zoom_road_width_factor,
            intro_duration_s=intro_duration_s,
            figure_size=figure_size,
            dpi=dpi,
            should_render_lanes=should_render_lanes,
            should_render_lane_lines=should_render_lane_lines,
            should_render_edge_bands=should_render_edge_bands,
            should_render_cones=should_render_cones,
            should_render_reference_line=should_render_reference_line,
            should_render_speed_signs=should_render_speed_signs,
            show_details=show_details,
            show_progress_bar=show_progress_bar,
            progress_bar_position=progress_bar_position,
            road_progress_step_m=road_progress_step_m,
            cone_rng_seed=cone_rng_seed,
            speed_sign_display_mode=speed_sign_display_mode,
            should_render_speed_change_markers=should_render_speed_change_markers,
            save_path=save_path,
            should_save=should_save,
            writer=writer,
            return_animation=return_animation,
            return_details=return_details,
        )


    def __closest_point_on_element(self, px, py, element_idx):
        return reference_geometry.closest_point_on_element(
            px,
            py,
            element_idx,
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__start_angles,
            self.__l_total_at_start,
            self.__start_tangent_vectors,
            self.__start_left_normal_vectors,
            self.__curvature_signs,
            self.__inverse_abs_curvatures,
            self.__arc_centers,
        )

    def __best_closest_point_from_element_index_range(self, px, py, first_idx, last_idx):
        return reference_geometry.best_closest_point_from_element_index_range(
            px,
            py,
            first_idx,
            last_idx,
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__start_angles,
            self.__l_total_at_start,
            self.__start_tangent_vectors,
            self.__start_left_normal_vectors,
            self.__curvature_signs,
            self.__inverse_abs_curvatures,
            self.__arc_centers,
        )

    def __element_index_range_for_progress_window(self, progress_hint, search_radius_m, element_index_hint=None):
        return reference_geometry.element_index_range_for_progress_window(
            self.__l,
            self.__l_total_at_end,
            progress_hint,
            search_radius_m,
            element_index_hint=element_index_hint,
        )

    def find_closest_point_to(
        self,
        px,
        py,
        reference_line_progress_hint=None,
        reference_line_element_index_hint=None,
        reference_line_progress_search_radius_m=None,
        allow_global_closest_point_fallback=True,
    ):
        """
        Compute the closest point on the reference line to a world-frame query point.
        """
        private_hint = self.__private_segment_index_for_source_hint(
            reference_line_element_index_hint,
            reference_line_progress_hint,
        )
        return reference_geometry.find_closest_point_to(
            px,
            py,
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__start_angles,
            self.__l_total_at_start,
            self.__l_total_at_end,
            self.__start_tangent_vectors,
            self.__start_left_normal_vectors,
            self.__curvature_signs,
            self.__inverse_abs_curvatures,
            self.__arc_centers,
            reference_line_progress_hint=reference_line_progress_hint,
            reference_line_element_index_hint=private_hint,
            reference_line_progress_search_radius_m=reference_line_progress_search_radius_m,
            allow_global_closest_point_fallback=allow_global_closest_point_fallback,
            private_segment_to_source_element_index=(
                self.__private_segment_to_source_element_index
            ),
        )

    def __private_segment_index_for_source_hint(
        self,
        source_element_index_hint,
        reference_line_progress_hint,
    ):
        if source_element_index_hint is None:
            return None
        source_element_index = min(
            max(int(source_element_index_hint), 0),
            len(self.__source_element_to_private_segment_indices) - 1,
        )
        private_indices = self.__source_element_to_private_segment_indices[
            source_element_index
        ]
        if reference_line_progress_hint is None:
            return int(private_indices[0])
        local_index = int(np.searchsorted(
            self.__l_total_at_end[private_indices],
            float(reference_line_progress_hint),
            side="left",
        ))
        local_index = min(max(local_index, 0), len(private_indices) - 1)
        return int(private_indices[local_index])

    def __find_closest_point_to_private(
        self,
        px,
        py,
        reference_line_progress_search=None,
    ):
        return reference_geometry.find_closest_point_to_with_end_tangent_continuation(
            px,
            py,
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__start_angles,
            self.__l_total_at_start,
            self.__l_total_at_end,
            self.__start_tangent_vectors,
            self.__start_left_normal_vectors,
            self.__curvature_signs,
            self.__inverse_abs_curvatures,
            self.__arc_centers,
            self.__end_points,
            self.__end_angles,
            reference_line_progress_search=reference_line_progress_search,
        )



    def __reference_line_samples_at_progresses(
        self,
        progression_queries,
        include_coordinates=True,
        include_angles=True,
        include_curvatures=True,
        include_speeds=False,
        include_element_indices=True,
        element_indices=None,
        element_indices_are_trusted=False,
        progression_queries_are_in_bounds=False,
        return_source_element_indices=False,
    ):
        return reference_geometry.reference_line_samples_at_progresses(
            progression_queries,
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__end_points,
            self.__start_angles,
            self.__end_angles,
            self.__l_total_at_end,
            self.__v_max,
            self.__v_rec,
            include_coordinates=include_coordinates,
            include_angles=include_angles,
            include_curvatures=include_curvatures,
            include_speeds=include_speeds,
            include_element_indices=include_element_indices,
            element_indices=element_indices,
            element_indices_are_trusted=element_indices_are_trusted,
            progression_queries_are_in_bounds=progression_queries_are_in_bounds,
            private_segment_to_source_element_index=(
                self.__private_segment_to_source_element_index
                if return_source_element_indices
                else None
            ),
        )

    def __target_geometry(self):
        return target_geometry.TargetLineGeometry(
            self.__c,
            self.__l,
            self.__phi,
            self.__isStraight,
            self.__start_points,
            self.__end_points,
            self.__start_angles,
            self.__end_angles,
            self.__l_total_at_end,
            self.__v_max,
            self.__v_rec,
            self.__lane_metadata,
            self.__all_lane_widths_are_constant,
            self.__active_lane_minimum_width_m,
            self.__target_line_arc_length_lookup_cache,
            self.__constant_target_offsets_cache,
            self.__constant_target_offsets_continuity_cache,
            self.__constant_target_distance_lookup_cache,
            reference_line_samples_at_progresses_callback=self.__reference_line_samples_at_progresses,
        )

    def convert_progression_to_coordinates(self, progression_queries):
        """
        Computes the world-frame coordinates of points along the road where the length of
        whole road (i.e., progression from the start of the road) equals to the query value(s).

        Parameters
        ----------
            progressing query : numpy array
                Value of road progression for which the world-frame coordinates. should be computed (units: m).

        Returns
        -------
            p_coords : numpy array
                The world frame coordinates for each progression query,
                2-dimensional array with size = number of queries -by- 2,
                (units: m).
            p_angles : numpy array
                The tangent angle of the road for each progression query,
                1-dimensional array with length = number of queries,
                (units: radians).
        """
        samples = self.__reference_line_samples_at_progresses(
            progression_queries,
            include_coordinates=True,
            include_angles=True,
            include_curvatures=False,
            include_speeds=False,
            include_element_indices=False,
        )
        return samples["coordinates"], samples["angles"]



    def convert_progression_to_curvature(self, progression_queries):
        """
        Retrieves the curvature at points along the road where the length of
        whole road (i.e., progression from the start of the road) equals to the query value(s).

        Parameters
        ----------
            progressing query : numpy array
                Value of road progression for which the world-frame coordinates. should be computed (units: m).

        Returns
        -------
            p_curvatures : numpy array
                The curvature of the road for each progression query,
                1-dimensional array with length = number of queries,
                (units: 1/m).
        """
        return self.__reference_line_samples_at_progresses(
            progression_queries,
            include_coordinates=False,
            include_angles=False,
            include_curvatures=True,
            include_speeds=False,
            include_element_indices=False,
        )["curvatures"]



    def map_target_line_displacement_to_reference_line_progress(
        self,
        origin_reference_line_progress_m,
        target_line_displacement_m,
        *,
        target_line_config=None,
    ) -> float:
        """Map a signed target-line displacement to raw reference progress.

        The origin is finite reference-line progress inside this Road's closed
        domain. The signed displacement is measured in metres along the
        selected target line: positive values move forward and negative values
        move backward. A mapped result beyond either finite Road endpoint is
        returned without clamping so a caller can diagnose endpoint saturation.

        ``target_line_config`` uses the same strict normalized target selector
        as :meth:`sample_target_line_horizon`. A zero displacement returns the
        supplied origin exactly after validating any requested physical lane.
        Fixed offsets use exact parallel-curve arc length on each traversed
        Road element; lane modes use the established target-line mapping.

        Parameters
        ----------
        origin_reference_line_progress_m : float
            Finite in-domain reference progress from which mapping starts.
        target_line_displacement_m : float
            Finite signed arc displacement along the selected target line.
        target_line_config : mapping or None, optional
            Strict target-line selection. ``None`` selects the reference line.

        Raises
        ------
        TypeError
            If a scalar, selector, or boolean has an invalid type.
        ValueError
            If a value is nonfinite, the origin is outside the Road domain,
            selectors conflict, or a traversed fixed-offset parallel curve is
            not forward with denominator greater than ``1.0e-6``.
        """
        normalized_target_line_config = _normalize_target_line_config(
            target_line_config,
            none_means_reference_line=True,
        )
        return horizon_samples.map_target_line_displacement_to_reference_line_progress(
            self,
            origin_reference_line_progress_m,
            target_line_displacement_m,
            target_line_config=normalized_target_line_config,
        )



    def sample_target_line_horizon(
        self,
        origin_reference_line_progress_m,
        target_line_distances_m,
        *,
        target_line_config=None,
        lane_bounds_config=None,
    ) -> RoadTargetLineHorizonSample:
        """Sample a forward target-line horizon aligned to a Road progress.

        Parameters
        ----------
        origin_reference_line_progress_m : float
            Finite reference-line progress used as the horizon origin, in
            metres, in the exact closed Road domain.
        target_line_distances_m : array-like
            Nonempty, finite, nonnegative, nondecreasing target-line arc
            distances from the origin, in metres. Repeated distances are
            allowed.
        target_line_config : mapping or None, optional
            Strict target-line selection. ``None`` selects the reference line.
        lane_bounds_config : mapping or None, optional
            Explicit lane-bound selection. ``None`` omits all three lane-bound
            arrays. The exact modes are ``target_line_lane``, ``lane_index``,
            and ``reference_lane``; each accepts an exact Boolean
            ``require_active_lane`` defaulting to true.

        Returns
        -------
        RoadTargetLineHorizonSample
            Detached immutable arrays aligned row-for-row. Raw mapped progress
            is preserved. After a finite endpoint, sampled channels are
            repeated at that endpoint and ``is_spatially_valid`` is false.
            ``lane_bounds_are_available`` remains independent of spatial
            validity and never causes selection of a replacement lane.

        Raises
        ------
        TypeError
            If scalar, vector, boolean, or lane-index types are invalid.
        ValueError
            If values are nonfinite or out of contract, selectors conflict,
            a requested lane target is unavailable, or a traversed fixed-offset
            parallel curve is not forward with denominator greater than
            ``1.0e-6``.
        """
        normalized_target_line_config = _normalize_target_line_config(
            target_line_config,
            none_means_reference_line=True,
        )
        return horizon_samples.sample_target_line_horizon(
            self,
            origin_reference_line_progress_m,
            target_line_distances_m,
            target_line_config=normalized_target_line_config,
            lane_bounds_config=lane_bounds_config,
        )



    @staticmethod
    def transform_points_2d( p , px_translate, py_translate, theta_rotate, p_translate_is_in_starting_frame=True):
        """
        Transform 2D points from one frame to another. The order of translate
        and rotate depends on which frame the translation vector is given in.

        If the transalation vector is expressed in the coordinates of the
        original frame (i.e., the untransformed frame), then the steps are:
            1. Translate by (px_translate,py_translate).
            2. Rotate by theta_rotate.

        If the transalation vector is expressed in the coordinates of the
        destination frame (i.e., the transformed frame), then the steps are:
            1. Rotate by theta_rotate.
            2. Translate by (px_translate,py_translate).

        Parameters
        ----------
            p : numpy array
                The point to be transformed, 2-dimensional array with:
                size = number of points to transform -by- 2,
                (units: m).
            px_translate : float
                X-axis length of the translation vector (units: m).
            py_translate : float
                Y-axis length of the translation vector (units: m).
            theta_rotate : float
                The angle of rotation between the original and destination
                frames (units: radians).
            p_translate_is_in_starting_frame : boolean
                A flag for indicating the frame of the translation vector:
                True := translation vector is in the original frame.
                True := translation vector is in the destination frame.

        Returns
        -------
            p_transformed : numpy array
                The coordinates for each point in "p" expressed in coordinates
                of the destination frame, 2-dimensional array with:
                size = number of points to transform -by- 2,
                (units: m).
        """
        return road_utils.transform_points_2d(
            p,
            px_translate,
            py_translate,
            theta_rotate,
            p_translate_is_in_starting_frame=p_translate_is_in_starting_frame,
        )



    def road_info_at_given_pose_and_progress_queries(
        self,
        px,
        py,
        theta,
        target_line_lookahead_distances_m,
        target_line_config=None,
        reference_line_progress_search=None,
        include_next_speed_limit_change=True,
        include_next_recommended_speed_change=True,
        lookahead_result_fields=None,
        current_result_fields=None,
    ):
        """
        Return road observations for a pose and target-line lookahead queries.

        The reference line remains the internal geometry backbone. The returned
        primary tracking quantities are relative to the selected target line.
        """
        normalized_target_line_config = _normalize_target_line_config(
            target_line_config,
            none_means_reference_line=True,
        )
        normalized_reference_line_progress_search = (
            reference_geometry.normalize_reference_line_progress_search(
                reference_line_progress_search,
                total_length_m=float(self.__l_total_at_end[-1]),
            )
        )
        result = road_observations.road_info_at_given_pose_and_progress_queries(
            px,
            py,
            theta,
            target_line_lookahead_distances_m,
            self.__c,
            self.__v_max,
            self.__v_rec,
            self.__next_v_max,
            self.__l_total_at_next_v_max,
            self.__next_v_rec,
            self.__l_total_at_next_v_rec,
            self.__find_closest_point_to_private,
            self.__target_geometry,
            target_line_config=normalized_target_line_config,
            reference_line_progress_search=normalized_reference_line_progress_search,
            include_next_speed_limit_change=include_next_speed_limit_change,
            include_next_recommended_speed_change=(
                include_next_recommended_speed_change
            ),
            lookahead_result_fields=lookahead_result_fields,
            current_result_fields=current_result_fields,
        )
        closest_point = result.get("reference_line", {}).get("closest_point", {})
        if "road_element_index" in closest_point:
            closest_point["road_element_index"] = int(
                self.__private_segment_to_source_element_index[
                    int(closest_point["road_element_index"])
                ]
            )
        return result

    def convert_progression_to_speed_limits(self, progression_queries):
        """
        Retrieves the speed limits and recommended speeds at points along the road
        where the length of whole road equals the query value(s).

        Parameters
        ----------
            progression_queries : numpy array
                Values of road progression at which to sample speeds (units: m).

        Returns
        -------
            p_speed_limits : numpy array (m/s)
            p_recommended_speeds : numpy array (m/s)
        """
        samples = self.__reference_line_samples_at_progresses(
            progression_queries,
            include_coordinates=False,
            include_angles=False,
            include_curvatures=False,
            include_speeds=True,
            include_element_indices=False,
        )
        return samples["speed_limits"], samples["recommended_speeds"]



    @staticmethod
    def __cone_info_from_point_arrays_at_given_pose_and_fov(p_cones, cone_color, px, py, theta, fov_horizontal_degrees=80.0, body_x_upper_bound=4.0, max_results=None):
        return road_cones.cone_info_from_point_arrays_at_given_pose_and_fov(
            p_cones,
            cone_color,
            px=px,
            py=py,
            theta=theta,
            fov_horizontal_degrees=fov_horizontal_degrees,
            body_x_upper_bound=body_x_upper_bound,
            max_results=max_results,
        )

    def cone_info_for_cone_points_at_given_pose_and_fov(self, cone_points, px, py, theta, fov_horizontal_degrees=80.0, body_x_upper_bound=4.0, max_results=None):
        return road_cones.cone_info_for_cone_points_at_given_pose_and_fov(
            cone_points,
            px=px,
            py=py,
            theta=theta,
            fov_horizontal_degrees=fov_horizontal_degrees,
            body_x_upper_bound=body_x_upper_bound,
            max_results=max_results,
        )

    def cone_info_for_cone_point_arrays_at_given_pose_and_fov(self, p_cones, cone_color, px, py, theta, fov_horizontal_degrees=80.0, body_x_upper_bound=4.0, max_results=None):
        return road_cones.cone_info_from_point_arrays_at_given_pose_and_fov(
            p_cones,
            cone_color,
            px=px,
            py=py,
            theta=theta,
            fov_horizontal_degrees=fov_horizontal_degrees,
            body_x_upper_bound=body_x_upper_bound,
            max_results=max_results,
        )

    def road_owned_cone_info_at_given_pose_and_fov(self, px, py, theta, fov_horizontal_degrees=80.0, body_x_upper_bound=4.0, rng=None, max_results=None):
        return road_cones.road_owned_cone_info_at_given_pose_and_fov(
            self,
            self.__source_element_lane_metadata,
            self.__l,
            self.__l_total_at_end,
            px=px,
            py=py,
            theta=theta,
            fov_horizontal_degrees=fov_horizontal_degrees,
            body_x_upper_bound=body_x_upper_bound,
            rng=rng,
            max_results=max_results,
            source_element_to_private_segment_indices=(
                self.__source_element_to_private_segment_indices
            ),
        )
