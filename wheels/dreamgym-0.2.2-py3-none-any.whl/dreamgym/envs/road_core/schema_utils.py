"""Small schema helpers used by Road.

The heavier road-spec parser still lives in ``road.py`` for now; this module is
only the first low-risk extraction step.
"""

import copy
import re


_AMERICAN_COLOR_NAMES = frozenset((
    "black", "blue", "brown", "cyan", "green", "magenta", "orange",
    "pink", "purple", "red", "silver", "white", "yellow", "gray",
))


def default_road_schema_defaults():
    return {
        "speed_limit_kph": 100.0,
        "reference_line_role": "lane_boundary",
        "cross_section_width_interpolation": "smoothstep",
        "lane": {
            "travel_direction": "increasing_reference_progress",
            "surface": "tarmac",
            "is_available": True,
            "is_drivable": True,
        },
        "edge_band": {
            "surface": "grass",
            "is_available": False,
            "is_drivable": False,
        },
        "lane_marking": {
            "color": None,
            "nominal_width_m": 0.12,
            "nominal_parallel_line_gap_m": 0.12,
        },
        "inter_cone_spacing": {
            "distribution": "clipped_normal",
            "mean_m": 5.0,
            "standard_deviation_m": 0.0,
            "lower_bound_m": 0.1,
            "upper_bound_m": None,
        },
    }


def default_road_validation_config():
    return {"mode": "disabled"}


def default_speed_transition_validation_config():
    return {
            "speed_sources": ["speed_limit", "recommended_speed"],
            "deceleration_limit_mps2": 3.0,
            "reaction_time_s": 0.0,
            "distance_margin_m": 0.0,
    }


def deep_merge_dicts(base, override):
    merged = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if (
            key in merged and
            isinstance(merged[key], dict) and
            isinstance(value, dict)
        ):
            merged[key] = deep_merge_dicts(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def as_float_list(value, field_name):
    try:
        values = [float(x) for x in value]
    except TypeError:
        raise ValueError(field_name + " must be a list of numbers.")
    if any(x < 0.0 for x in values):
        raise ValueError(field_name + " cannot contain negative widths.")
    return values


def as_bool_list(value, field_name):
    try:
        return [bool(x) for x in value]
    except TypeError:
        raise ValueError(field_name + " must be a list of booleans.")


def validate_string_option(value, field_name, valid_options):
    if value not in valid_options:
        raise ValueError(
            field_name + " must be one of " + str(valid_options) +
            ", got " + str(value)
        )
    return value


def normalize_road_marking_color(value, field_name):
    """Detach the headless structural form of a marking colour literal."""
    if value is None:
        return None
    if isinstance(value, str):
        lowered = value.lower()
        if lowered in _AMERICAN_COLOR_NAMES:
            return lowered
        if re.fullmatch(r"#[0-9a-fA-F]{3}", value):
            return "#" + "".join(character * 2 for character in value[1:].lower())
        if re.fullmatch(r"#[0-9a-fA-F]{6}", value):
            return lowered
        raise ValueError(field_name + " must be a supported American color name or hexadecimal RGB literal.")
    if isinstance(value, (list, tuple)):
        if len(value) != 3:
            raise ValueError(field_name + " must be an RGB triple when provided.")
        if not all(
            isinstance(component, int)
            and not isinstance(component, bool)
            and 0 <= component <= 255
            for component in value
        ):
            raise ValueError(field_name + " must be an RGB triple of integers in [0, 255].")
        return "#{:02x}{:02x}{:02x}".format(*value)
    raise TypeError(field_name + " must be None, a non-empty string, or an RGB triple.")


def lane_key(lane_idx):
    lane_idx = int(lane_idx)
    if lane_idx > 0:
        return "+" + str(lane_idx)
    return str(lane_idx)


def lane_line_key(lane_line_idx):
    lane_line_idx = int(lane_line_idx)
    if lane_line_idx > 0:
        return "+" + str(lane_line_idx)
    return str(lane_line_idx)
