"""Strict normalization for the v1 target-line configuration."""

from dreamgym.envs.config_validation import (
    detached_mapping,
    finite_float,
    reject_unknown_keys,
    strict_bool,
    strict_int,
)


_MODE_KEYS = {
    "reference_line": {"mode"},
    "fixed_offset": {"mode", "offset_from_reference_line_m"},
    "lane_center": {"mode", "lane_index", "require_active_lane"},
    "lane_coordinate": {"mode", "lane_coordinate", "allow_outside_lanes"},
}


def _normalize_target_line_config(
    config,
    *,
    none_means_reference_line=False,
) -> dict[str, object]:
    """Return a detached, strict target-line configuration mapping."""
    if config is None:
        if none_means_reference_line:
            return {"mode": "reference_line"}
        raise TypeError("target_line_config must be a mapping.")

    supplied = detached_mapping(config, "target_line_config")
    mode = supplied.get("mode", "reference_line")
    if mode not in _MODE_KEYS:
        raise ValueError(
            "target_line_config.mode must be one of " + str(tuple(_MODE_KEYS)) + "."
        )
    reject_unknown_keys(supplied, _MODE_KEYS[mode], "target_line_config")

    if mode == "reference_line":
        return {"mode": "reference_line"}
    if mode == "fixed_offset":
        if "offset_from_reference_line_m" not in supplied:
            raise ValueError(
                "target_line_config.offset_from_reference_line_m is required."
            )
        return {
            "mode": "fixed_offset",
            "offset_from_reference_line_m": finite_float(
                supplied["offset_from_reference_line_m"],
                "target_line_config.offset_from_reference_line_m",
            ),
        }
    if mode == "lane_center":
        if "lane_index" not in supplied:
            raise ValueError("target_line_config.lane_index is required.")
        lane_index = strict_int(supplied["lane_index"], "target_line_config.lane_index")
        if lane_index == 0:
            raise ValueError("target_line_config.lane_index must be nonzero.")
        return {
            "mode": "lane_center",
            "lane_index": lane_index,
            "require_active_lane": strict_bool(
                supplied.get("require_active_lane", True),
                "target_line_config.require_active_lane",
            ),
        }

    if "lane_coordinate" not in supplied:
        raise ValueError("target_line_config.lane_coordinate is required.")
    return {
        "mode": "lane_coordinate",
        "lane_coordinate": finite_float(
            supplied["lane_coordinate"], "target_line_config.lane_coordinate"
        ),
        "allow_outside_lanes": strict_bool(
            supplied.get("allow_outside_lanes", False),
            "target_line_config.allow_outside_lanes",
        ),
    }


def _target_line_config_values(config) -> tuple[float, int | None, float | None, bool, bool]:
    """Translate one normalized target record into geometry inputs."""
    mode = config["mode"]
    if mode == "reference_line":
        return 0.0, None, None, True, False
    if mode == "fixed_offset":
        return float(config["offset_from_reference_line_m"]), None, None, True, False
    if mode == "lane_center":
        return (
            0.0,
            int(config["lane_index"]),
            None,
            bool(config["require_active_lane"]),
            False,
        )
    return (
        0.0,
        None,
        float(config["lane_coordinate"]),
        True,
        bool(config["allow_outside_lanes"]),
    )
