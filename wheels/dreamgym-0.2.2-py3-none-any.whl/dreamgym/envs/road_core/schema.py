"""Road-spec parsing and metadata inheritance helpers."""

from collections.abc import Mapping
import copy

import numpy as np

from dreamgym.envs.road_core import constants
from dreamgym.envs.road_core import schema_utils
from dreamgym.envs.road_core import utils as road_utils
from dreamgym.envs.config_validation import (
    finite_float,
    reject_unknown_keys,
    strict_bool,
    strict_int,
)


_ROAD_SPEC_KEYS = {
    "defaults",
    "active_lane_minimum_width_m",
    "validation",
    "elements",
}
_ROAD_DEFAULT_KEYS = {
    "speed_limit_kph",
    "reference_line_role",
    "cross_section_width_interpolation",
    "lane",
    "edge_band",
    "lane_marking",
    "inter_cone_spacing",
}
_ROAD_LANE_DEFAULT_KEYS = {"travel_direction", "surface", "is_available", "is_drivable"}
_ROAD_EDGE_BAND_DEFAULT_KEYS = {"surface", "is_available", "is_drivable"}
_ROAD_LANE_MARKING_DEFAULT_KEYS = {
    "color",
    "nominal_width_m",
    "nominal_parallel_line_gap_m",
}
_ROAD_INTER_CONE_SPACING_DEFAULT_KEYS = {
    "distribution",
    "mean_m",
    "standard_deviation_m",
    "lower_bound_m",
    "upper_bound_m",
}
_ROAD_VALIDATION_KEYS = {"mode", "speed_transitions"}
_SPEED_TRANSITION_VALIDATION_KEYS = {
    "speed_sources",
    "deceleration_limit_mps2",
    "reaction_time_s",
    "distance_margin_m",
}
_ROAD_ELEMENT_KEYS = {
    "geometry",
    "speed_limit_kph",
    "lanes",
    "cross_section_width_interpolation",
    "edge_bands",
    "lane_markings",
    "cones",
}
_STRAIGHT_GEOMETRY_KEYS = {"type", "length_m"}
_CIRCULAR_ARC_GEOMETRY_KEYS = {
    "type",
    "curvature_per_m",
    "length_m",
    "sweep_angle_deg",
}
_LANES_KEYS = {"reference_line_role", "left", "right", "reference_lane"}
_LANE_KEYS = {"width_m", "travel_direction", "surface", "is_available", "is_drivable"}
_WIDTH_KEYS = {"start", "end"}
_EDGE_BANDS_KEYS = {"left", "right"}
_EDGE_BAND_KEYS = {"name", "width_m", "surface", "is_available", "is_drivable"}
_LANE_MARKINGS_KEYS = {"lane_lines", "lane_centerlines"}
_LANE_MARKING_KEYS = {"pattern", "color", "nominal_width_m", "nominal_parallel_line_gap_m"}
_CONE_KEYS = {"placement", "color", "radius_m", "element_progress_interval", "inter_cone_spacing"}
_CONE_PLACEMENT_KEYS = {"mode", "lateral_offset_from_anchor_m", "lane_index", "lane_line_index", "side"}
_CONE_INTERVAL_KEYS = {"lower_bound_m", "upper_bound_m"}


def _require_mapping(value, path):
    if not isinstance(value, Mapping):
        raise ValueError(path + " must be a dictionary.")
    return value


def _normalize_finite_sequence(value, path):
    if isinstance(value, (str, bytes, bytearray)):
        raise TypeError(path + " must be a sequence of finite numbers.")
    try:
        return [
            finite_float(item, path + "[" + str(index) + "]")
            for index, item in enumerate(value)
        ]
    except TypeError as exc:
        raise TypeError(path + " must be a sequence of finite numbers.") from exc


def _normalize_cone_spacing_keys(spacing, path):
    reject_unknown_keys(spacing, _CONE_SPACING_KEYS, path)
    for key in (
        "mean_spacing_m",
        "stddev_spacing_m",
        "min_spacing_m",
        "max_spacing_m",
    ):
        if key in spacing and spacing[key] is not None:
            spacing[key] = finite_float(spacing[key], path + "." + key)


def _validate_lane_marking_keys(marking, path):
    marking = _require_mapping(marking, path)
    reject_unknown_keys(marking, _LANE_MARKING_KEYS, path)
    for key in ("nominal_width_m", "nominal_parallel_line_gap_m"):
        if key in marking:
            marking[key] = finite_float(marking[key], path + "." + key)
    if "pattern" in marking and not isinstance(marking["pattern"], str):
        raise TypeError(path + ".pattern must be a string.")
    if "color" in marking:
        marking["color"] = schema_utils.normalize_road_marking_color(
            marking["color"],
            path + ".color",
        )


def _validate_road_element_keys(element, element_index):
    path = "road_spec.elements[" + str(element_index) + "]"
    element = _require_mapping(element, path)
    reject_unknown_keys(element, _ROAD_ELEMENT_KEYS, path)
    if "geometry" not in element:
        raise ValueError(path + ".geometry is required.")
    geometry_path = path + ".geometry"
    geometry = _require_mapping(element["geometry"], geometry_path)
    if "type" not in geometry:
        raise ValueError(geometry_path + ".type is required.")
    geometry_type = geometry["type"]
    if geometry_type == "straight":
        reject_unknown_keys(geometry, _STRAIGHT_GEOMETRY_KEYS, geometry_path)
        if "length_m" not in geometry:
            raise ValueError(geometry_path + ".length_m is required for straight elements.")
    elif geometry_type == "circular_arc":
        reject_unknown_keys(geometry, _CIRCULAR_ARC_GEOMETRY_KEYS, geometry_path)
        if "curvature_per_m" not in geometry:
            raise ValueError(geometry_path + ".curvature_per_m is required for circular arcs.")
        has_length = "length_m" in geometry
        has_sweep = "sweep_angle_deg" in geometry
        if has_length == has_sweep:
            raise ValueError(
                geometry_path
                + " must specify exactly one of length_m or sweep_angle_deg."
            )
    else:
        raise ValueError(geometry_path + ".type must be 'straight' or 'circular_arc'.")
    for key in ("length_m", "curvature_per_m", "sweep_angle_deg"):
        if key in geometry:
            geometry[key] = finite_float(geometry[key], geometry_path + "." + key)
    if geometry_type == "straight" and geometry["length_m"] <= 0.0:
        raise ValueError(geometry_path + ".length_m must be positive.")
    if geometry_type == "circular_arc":
        if geometry["curvature_per_m"] == 0.0:
            raise ValueError(geometry_path + ".curvature_per_m must be nonzero.")
        length_key = "length_m" if "length_m" in geometry else "sweep_angle_deg"
        if geometry[length_key] <= 0.0:
            raise ValueError(geometry_path + "." + length_key + " must be positive.")
    for key in ("speed_limit_kph",):
        if key in element:
            element[key] = finite_float(element[key], path + "." + key)
    if "lanes" in element:
        lanes = _require_mapping(element["lanes"], path + ".lanes")
        reject_unknown_keys(lanes, _LANES_KEYS, path + ".lanes")
        for field in ("left", "right"):
            if field in lanes:
                if not isinstance(lanes[field], list):
                    raise TypeError(path + ".lanes." + field + " must be a list.")
                for index, lane in enumerate(lanes[field]):
                    _validate_lane_record(lane, path + ".lanes." + field + "[" + str(index) + "]")
        if "reference_lane" in lanes:
            _validate_lane_record(lanes["reference_lane"], path + ".lanes.reference_lane")
    if "edge_bands" in element:
        bands = _require_mapping(element["edge_bands"], path + ".edge_bands")
        reject_unknown_keys(bands, _EDGE_BANDS_KEYS, path + ".edge_bands")
        for side in ("left", "right"):
            if side in bands:
                if not isinstance(bands[side], list):
                    raise TypeError(path + ".edge_bands." + side + " must be a list.")
                for index, band in enumerate(bands[side]):
                    band_path = path + ".edge_bands." + side + "[" + str(index) + "]"
                    band = _require_mapping(band, band_path)
                    reject_unknown_keys(band, _EDGE_BAND_KEYS, band_path)
                    _validate_width_mapping(band.get("width_m"), band_path + ".width_m", required=False)
                    for key in ("is_available", "is_drivable"):
                        if key in band:
                            band[key] = strict_bool(band[key], band_path + "." + key)
                    for key in ("name", "surface"):
                        if key in band and not isinstance(band[key], str):
                            raise TypeError(band_path + "." + key + " must be a string.")
    if "lane_markings" in element:
        lane_markings_path = path + ".lane_markings"
        lane_markings = _require_mapping(element["lane_markings"], lane_markings_path)
        reject_unknown_keys(lane_markings, _LANE_MARKINGS_KEYS, lane_markings_path)
        for field in ("lane_lines", "lane_centerlines"):
            values = _require_mapping(lane_markings.get(field, {}), lane_markings_path + "." + field)
            for key, marking in values.items():
                _canonical_signed_key(key, lane_markings_path + "." + field, allow_zero=(field == "lane_lines"))
                _validate_lane_marking_keys(marking, lane_markings_path + "." + field + "[" + str(key) + "]")
    if "cones" in element and not isinstance(element["cones"], list):
        raise TypeError(path + ".cones must be a list.")
    for cone_index, cone in enumerate(element.get("cones", ())):
        cone_path = path + ".cones[" + str(cone_index) + "]"
        cone = _require_mapping(cone, cone_path)
        reject_unknown_keys(cone, _CONE_KEYS, cone_path)
        _validate_cone_record(cone, cone_path)


def _validate_width_mapping(width, path, required):
    if width is None:
        if required:
            raise ValueError(path + " is required.")
        return
    width = _require_mapping(width, path)
    reject_unknown_keys(width, _WIDTH_KEYS, path)
    if required and "start" not in width:
        raise ValueError(path + ".start is required.")
    for key in ("start", "end"):
        if key in width:
            width[key] = finite_float(width[key], path + "." + key)


def _validate_lane_record(lane, path):
    lane = _require_mapping(lane, path)
    reject_unknown_keys(lane, _LANE_KEYS, path)
    _validate_width_mapping(lane.get("width_m"), path + ".width_m", required=False)
    for key in ("is_available", "is_drivable"):
        if key in lane:
            lane[key] = strict_bool(lane[key], path + "." + key)
    for key in ("travel_direction", "surface"):
        if key in lane and not isinstance(lane[key], str):
            raise TypeError(path + "." + key + " must be a string.")


def _canonical_signed_key(value, path, allow_zero):
    if not isinstance(value, str) or value == "+0":
        raise ValueError(path + " keys must be canonical signed-integer strings.")
    try:
        number = int(value)
    except ValueError as exc:
        raise ValueError(path + " keys must be canonical signed-integer strings.") from exc
    if schema_utils.lane_line_key(number) != value or (number == 0 and not allow_zero):
        raise ValueError(path + " keys must be canonical signed-integer strings.")
    return number


def _validate_cone_record(cone, path):
    placement = _require_mapping(cone.get("placement", {}), path + ".placement")
    reject_unknown_keys(placement, _CONE_PLACEMENT_KEYS, path + ".placement")
    interval = _require_mapping(cone.get("element_progress_interval", {}), path + ".element_progress_interval")
    reject_unknown_keys(interval, _CONE_INTERVAL_KEYS, path + ".element_progress_interval")
    spacing = _require_mapping(cone.get("inter_cone_spacing", {}), path + ".inter_cone_spacing")
    reject_unknown_keys(spacing, _ROAD_INTER_CONE_SPACING_DEFAULT_KEYS, path + ".inter_cone_spacing")
    for key in ("lateral_offset_from_anchor_m",):
        if key in placement:
            placement[key] = finite_float(placement[key], path + ".placement." + key)
    for key in ("lane_index", "lane_line_index"):
        if key in placement:
            placement[key] = strict_int(placement[key], path + ".placement." + key)
    for key in ("lower_bound_m", "upper_bound_m"):
        if key in interval and interval[key] is not None:
            interval[key] = finite_float(interval[key], path + ".element_progress_interval." + key)
    for key in ("mean_m", "standard_deviation_m", "lower_bound_m", "upper_bound_m"):
        if key in spacing and spacing[key] is not None:
            spacing[key] = finite_float(spacing[key], path + ".inter_cone_spacing." + key)
    if "radius_m" in cone:
        cone["radius_m"] = finite_float(cone["radius_m"], path + ".radius_m")
    for mapping, key in ((placement, "mode"), (placement, "side"), (spacing, "distribution"), (cone, "color")):
        if key in mapping and not isinstance(mapping[key], str):
            raise TypeError(path + "." + key + " must be a string.")


def validate_road_schema_defaults(defaults):
    if defaults["speed_limit_kph"] <= 0.0:
        raise ValueError("defaults.speed_limit_kph must be positive.")
    schema_utils.validate_string_option(
        defaults["reference_line_role"],
        "defaults.reference_line_role",
        constants.VALID_REFERENCE_LINE_ROLES,
    )
    schema_utils.validate_string_option(
        defaults["cross_section_width_interpolation"],
        "defaults.cross_section_width_interpolation",
        constants.VALID_LANE_WIDTH_INTERPOLATIONS,
    )
    schema_utils.validate_string_option(
        defaults["lane"]["travel_direction"],
        "defaults.lane.travel_direction",
        constants.VALID_LANE_TRAVEL_DIRECTIONS,
    )
    schema_utils.validate_string_option(
        defaults["lane"]["surface"],
        "defaults.lane.surface",
        constants.VALID_SURFACES,
    )
    schema_utils.validate_string_option(
        defaults["edge_band"]["surface"],
        "defaults.edge_band.surface",
        constants.VALID_SURFACES,
    )
    schema_utils.validate_string_option(
        defaults["inter_cone_spacing"]["distribution"],
        "defaults.inter_cone_spacing.distribution",
        constants.VALID_INTER_CONE_SPACING_DISTRIBUTIONS,
    )
    for group in ("lane", "edge_band"):
        for key in ("is_available", "is_drivable"):
            defaults[group][key] = strict_bool(
                defaults[group][key],
                "road_spec.defaults." + group + "." + key,
            )
    marking = defaults["lane_marking"]
    marking["color"] = schema_utils.normalize_road_marking_color(
        marking["color"], "defaults.lane_marking.color"
    )
    if marking["nominal_width_m"] <= 0.0:
        raise ValueError("defaults.lane_marking.nominal_width_m must be positive.")
    if marking["nominal_parallel_line_gap_m"] < 0.0:
        raise ValueError("defaults.lane_marking.nominal_parallel_line_gap_m must be non-negative.")
    spacing = defaults["inter_cone_spacing"]
    if spacing["mean_m"] <= 0.0 or spacing["standard_deviation_m"] < 0.0 or spacing["lower_bound_m"] <= 0.0:
        raise ValueError("defaults.inter_cone_spacing mean/lower must be positive and deviation non-negative.")
    if spacing["upper_bound_m"] is not None and spacing["upper_bound_m"] < spacing["lower_bound_m"]:
        raise ValueError("defaults.inter_cone_spacing.upper_bound_m must not be below lower_bound_m.")


def validate_road_validation_config(validation_config):
    if not isinstance(validation_config, dict):
        raise ValueError("road_spec.validation must be a dictionary.")

    mode = validation_config.get("mode", "disabled")
    schema_utils.validate_string_option(
        mode,
        "road_spec.validation.mode",
        constants.VALID_ROAD_VALIDATION_MODES,
    )
    validation_config["mode"] = mode
    if mode == "disabled":
        if "speed_transitions" in validation_config:
            raise ValueError("road_spec.validation.speed_transitions is not valid in disabled mode.")
        return

    speed_config = schema_utils.deep_merge_dicts(
        schema_utils.default_speed_transition_validation_config(),
        validation_config.get("speed_transitions", {}),
    )

    speed_sources = speed_config.get("speed_sources", ["speed_limit", "recommended_speed"])
    if not isinstance(speed_sources, list):
        raise ValueError("validation.speed_transitions.speed_sources must be a list.")
    if len(speed_sources) == 0:
        raise ValueError("validation.speed_transitions.speed_sources cannot be empty.")
    for source in speed_sources:
        schema_utils.validate_string_option(
            source,
            "validation.speed_transitions.speed_sources",
            constants.VALID_SPEED_TRANSITION_SOURCES,
        )
    if len(set(speed_sources)) != len(speed_sources):
        raise ValueError("validation.speed_transitions.speed_sources must contain unique values.")
    speed_config["speed_sources"] = speed_sources

    deceleration_limit_mps2 = speed_config["deceleration_limit_mps2"]
    reaction_time_s = speed_config["reaction_time_s"]
    distance_margin_m = speed_config["distance_margin_m"]
    if deceleration_limit_mps2 <= 0.0:
        raise ValueError("validation.speed_transitions.deceleration_limit_mps2 must be positive.")
    if reaction_time_s < 0.0:
        raise ValueError("validation.speed_transitions.reaction_time_s must be non-negative.")
    if distance_margin_m < 0.0:
        raise ValueError("validation.speed_transitions.distance_margin_m must be non-negative.")
    validation_config["speed_transitions"] = speed_config


def parse_road_spec(road_spec):
    if not isinstance(road_spec, Mapping):
        raise ValueError("road_spec must be a dictionary containing an 'elements' list.")
    road_spec = copy.deepcopy(dict(road_spec))
    reject_unknown_keys(road_spec, _ROAD_SPEC_KEYS, "road_spec")
    if "elements" not in road_spec:
        raise ValueError("road_spec.elements is required.")
    defaults_override = road_spec.get("defaults", {})
    validation_override = road_spec.get("validation", {})
    defaults_override = _require_mapping(defaults_override, "road_spec.defaults")
    reject_unknown_keys(defaults_override, _ROAD_DEFAULT_KEYS, "road_spec.defaults")
    if "speed_limit_kph" in defaults_override:
        defaults_override["speed_limit_kph"] = finite_float(
            defaults_override["speed_limit_kph"],
            "road_spec.defaults.speed_limit_kph",
        )
    nested_default_keys = (
        ("lane", _ROAD_LANE_DEFAULT_KEYS),
        ("edge_band", _ROAD_EDGE_BAND_DEFAULT_KEYS),
        ("lane_marking", _ROAD_LANE_MARKING_DEFAULT_KEYS),
        ("inter_cone_spacing", _ROAD_INTER_CONE_SPACING_DEFAULT_KEYS),
    )
    for group, valid_keys in nested_default_keys:
        if group in defaults_override:
            nested = _require_mapping(defaults_override[group], "road_spec.defaults." + group)
            reject_unknown_keys(nested, valid_keys, "road_spec.defaults." + group)
    for group in ("lane", "edge_band"):
        if group in defaults_override:
            for key in ("is_available", "is_drivable"):
                if key in defaults_override[group]:
                    defaults_override[group][key] = strict_bool(
                        defaults_override[group][key],
                        "road_spec.defaults." + group + "." + key,
                    )
    if "lane_marking" in defaults_override:
        marking = defaults_override["lane_marking"]
        if "color" in marking:
            marking["color"] = schema_utils.normalize_road_marking_color(
                marking["color"],
                "road_spec.defaults.lane_marking.color",
            )
        for key in ("nominal_width_m", "nominal_parallel_line_gap_m"):
            if key in marking:
                marking[key] = finite_float(marking[key], "road_spec.defaults.lane_marking." + key)
    if "inter_cone_spacing" in defaults_override:
        spacing = defaults_override["inter_cone_spacing"]
        for key in ("mean_m", "standard_deviation_m", "lower_bound_m", "upper_bound_m"):
            if key in spacing and spacing[key] is not None:
                spacing[key] = finite_float(spacing[key], "road_spec.defaults.inter_cone_spacing." + key)
    active_lane_minimum_width_m = finite_float(
        road_spec.get("active_lane_minimum_width_m", 0.05),
        "road_spec.active_lane_minimum_width_m",
    )
    if active_lane_minimum_width_m < 0.0:
        raise ValueError("road_spec.active_lane_minimum_width_m must be non-negative.")
    validation_override = _require_mapping(validation_override, "road_spec.validation")
    reject_unknown_keys(validation_override, _ROAD_VALIDATION_KEYS, "road_spec.validation")
    if "speed_transitions" in validation_override:
        speed_validation = _require_mapping(
            validation_override["speed_transitions"],
            "road_spec.validation.speed_transitions",
        )
        reject_unknown_keys(
            speed_validation,
            _SPEED_TRANSITION_VALIDATION_KEYS,
            "road_spec.validation.speed_transitions",
        )
        for key in (
            "deceleration_limit_mps2",
            "reaction_time_s",
            "distance_margin_m",
        ):
            if key in speed_validation:
                speed_validation[key] = finite_float(
                    speed_validation[key],
                    "road_spec.validation.speed_transitions." + key,
                )
    validate_road_validation_config(validation_override)
    elements = road_spec["elements"]
    if not isinstance(elements, list):
        raise ValueError("road_spec.elements must be a list.")
    if not elements:
        raise ValueError("road_spec.elements must contain at least one element.")
    for element_index, element in enumerate(elements):
        _validate_road_element_keys(element, element_index)
        geometry = element.pop("geometry")
        element["type"] = "straight" if geometry["type"] == "straight" else "curved"
        if "length_m" in geometry:
            element["length"] = geometry["length_m"]
        if "curvature_per_m" in geometry:
            element["curvature"] = geometry["curvature_per_m"]
        if "sweep_angle_deg" in geometry:
            element["angle_in_degrees"] = geometry["sweep_angle_deg"]
        if "speed_limit_kph" in element:
            element["v_max_kph"] = element.pop("speed_limit_kph")
    return defaults_override, active_lane_minimum_width_m, validation_override, elements


def format_speed_transition_validation_issue(issue):
    required_deceleration = issue["required_deceleration_mps2"]
    required_deceleration_text = (
        "inf"
        if not np.isfinite(required_deceleration)
        else "{:.3f}".format(required_deceleration)
    )
    return (
        "speed_transitions[{speed_source}] "
        "{from_speed_kph:.1f} -> {to_speed_kph:.1f} km/h "
        "from progress {from_progress_m:.3f} m to {to_progress_m:.3f} m "
        "has {available_distance_m:.3f} m available, "
        "requires {required_distance_m:.3f} m at deceleration_limit_mps2={deceleration_limit_mps2:.3f}, "
        "and implies required_deceleration_mps2=" + required_deceleration_text + "."
    ).format(speed_source=issue["speed_sources"][0], **issue)


def normalize_road_element_metadata(element, previous_metadata, previous_v_max_kph, defaults, schema_warnings):
    if not isinstance(element, dict):
        raise ValueError("Each road element must be a dictionary.")
    if "type" not in element:
        raise ValueError("Each road element must specify a type.")
    if element["type"] not in ("straight", "curved"):
        raise ValueError("Road element type must be 'straight' or 'curved'.")
    if element["type"] == "straight":
        if "length" not in element:
            raise ValueError("Straight road elements must specify 'length'.")
    else:
        if "curvature" not in element:
            raise ValueError("Curved road elements must specify 'curvature'.")
        has_length = "length" in element
        has_angle = "angle_in_degrees" in element
        if has_length == has_angle:
            raise ValueError(
                "Curved road elements must specify exactly one of "
                "'length' or 'angle_in_degrees'."
            )

    if "v_max_kph" in element:
        v_max_kph = float(element["v_max_kph"])
    elif previous_v_max_kph is not None:
        v_max_kph = float(previous_v_max_kph)
    else:
        v_max_kph = float(defaults["speed_limit_kph"])
    if v_max_kph <= 0.0:
        raise ValueError("v_max_kph must be positive.")

    lanes = resolve_v1_lanes(element, previous_metadata, defaults)
    reference_line_role = lanes["reference_line_role"]
    if reference_line_role == "lane_center":
        reference_lane = lanes["reference_lane"]
        reference_lane_width_start_m = reference_lane["width_m"]["start"]
        reference_lane_width_end_m = reference_lane["width_m"]["end"]
        left_start = [0.5 * reference_lane_width_start_m]
        right_start = [0.5 * reference_lane_width_start_m]
        left_end = [0.5 * reference_lane_width_end_m]
        right_end = [0.5 * reference_lane_width_end_m]
        left_lanes = [reference_lane]
        right_lanes = [reference_lane]
    else:
        reference_lane_width_start_m = None
        reference_lane_width_end_m = None
        left_lanes = lanes["left"]
        right_lanes = lanes["right"]
        left_start = [lane["width_m"]["start"] for lane in left_lanes]
        left_end = [lane["width_m"]["end"] for lane in left_lanes]
        right_start = [lane["width_m"]["start"] for lane in right_lanes]
        right_end = [lane["width_m"]["end"] for lane in right_lanes]

    interpolation = element.get(
        "cross_section_width_interpolation",
        previous_metadata.get("cross_section_width_interpolation", defaults["cross_section_width_interpolation"])
        if previous_metadata else defaults["cross_section_width_interpolation"],
    )
    schema_utils.validate_string_option(
        interpolation,
        "cross_section_width_interpolation",
        constants.VALID_LANE_WIDTH_INTERPOLATIONS,
    )
    if interpolation == "constant":
        if not (np.allclose(left_start, left_end) and np.allclose(right_start, right_end)):
            raise ValueError("constant cross_section_width_interpolation requires matching start and end widths.")

    metadata = {
        "speed_limit_kph": v_max_kph,
        "lanes": copy.deepcopy(lanes),
        "reference_line_role": reference_line_role,
        "reference_lane_width_start_m": reference_lane_width_start_m,
        "reference_lane_width_end_m": reference_lane_width_end_m,
        "left_lane_widths_start": left_start,
        "left_lane_widths_end": left_end,
        "right_lane_widths_start": right_start,
        "right_lane_widths_end": right_end,
        "cross_section_width_interpolation": interpolation,
        "lane_width_interpolation": interpolation,
        "lane_widths_are_constant": (
            lane_width_lists_are_constant(left_start, left_end) and
            lane_width_lists_are_constant(right_start, right_end)
        ),
    }

    metadata["left_lane_directions"] = [_private_travel_direction(lane["travel_direction"]) for lane in left_lanes]
    metadata["right_lane_directions"] = [_private_travel_direction(lane["travel_direction"]) for lane in right_lanes]
    metadata["left_lane_surfaces"] = [lane["surface"] for lane in left_lanes]
    metadata["right_lane_surfaces"] = [lane["surface"] for lane in right_lanes]
    metadata["left_lane_available"] = [lane["is_available"] for lane in left_lanes]
    metadata["right_lane_available"] = [lane["is_available"] for lane in right_lanes]
    metadata["left_lane_drivable"] = [lane["is_drivable"] for lane in left_lanes]
    metadata["right_lane_drivable"] = [lane["is_drivable"] for lane in right_lanes]

    metadata["edge_bands"] = resolve_v1_edge_bands(element, previous_metadata, defaults)
    if interpolation == "constant":
        for side in ("left", "right"):
            for band in metadata["edge_bands"][side]:
                if band["width_m"]["start"] != band["width_m"]["end"]:
                    raise ValueError(
                        "constant cross_section_width_interpolation requires "
                        "matching edge-band start and end widths."
                    )
    metadata["left_edge_bands"] = [_private_edge_band(band) for band in metadata["edge_bands"]["left"]]
    metadata["right_edge_bands"] = [_private_edge_band(band) for band in metadata["edge_bands"]["right"]]
    metadata["public_lane_markings"] = resolve_v1_lane_markings(element, previous_metadata, metadata, defaults)
    metadata["lane_markings"] = _private_lane_markings(metadata["public_lane_markings"], len(left_start), len(right_start))
    metadata["cones"] = resolve_v1_cones(element, previous_metadata, metadata, defaults)

    return metadata


def _resolve_width(record, previous_record, path, positive):
    width = record.get("width_m")
    if width is None:
        if previous_record is None:
            raise ValueError(path + ".width_m.start is required for a newly introduced record.")
        start = previous_record["width_m"]["end"]
        end = start
    else:
        if "start" in width:
            start = float(width["start"])
        elif previous_record is not None:
            start = float(previous_record["width_m"]["end"])
        else:
            raise ValueError(path + ".width_m.start is required for a newly introduced record.")
        end = float(width.get("end", start))
    if (start <= 0.0 or end <= 0.0) if positive else (start < 0.0 or end < 0.0):
        raise ValueError(path + ".width_m must be " + ("positive." if positive else "non-negative."))
    return {"start": start, "end": end}


def _private_travel_direction(value):
    return "forward" if value == "increasing_reference_progress" else "reverse"


def _resolve_lane_record(record, previous_record, defaults, path, positive=False):
    lane = {"width_m": _resolve_width(record, previous_record, path, positive)}
    for key in ("travel_direction", "surface", "is_available", "is_drivable"):
        lane[key] = copy.deepcopy(record.get(key, previous_record.get(key) if previous_record else defaults[key]))
    schema_utils.validate_string_option(lane["travel_direction"], path + ".travel_direction", constants.VALID_LANE_TRAVEL_DIRECTIONS)
    schema_utils.validate_string_option(lane["surface"], path + ".surface", constants.VALID_SURFACES)
    lane["is_available"] = strict_bool(lane["is_available"], path + ".is_available")
    lane["is_drivable"] = strict_bool(lane["is_drivable"], path + ".is_drivable")
    return lane


def resolve_v1_lanes(element, previous_metadata, defaults):
    previous = previous_metadata.get("lanes") if previous_metadata else None
    supplied = element.get("lanes")
    if supplied is None:
        if previous is not None:
            return _continued_lanes(previous)
        role = defaults["reference_line_role"]
        if role == "lane_center":
            raise ValueError("The first lane_center element must provide lanes.reference_lane.")
        return {"reference_line_role": "lane_boundary", "left": [], "right": []}
    role = supplied.get("reference_line_role", previous["reference_line_role"] if previous else defaults["reference_line_role"])
    schema_utils.validate_string_option(role, "lanes.reference_line_role", constants.VALID_REFERENCE_LINE_ROLES)
    if role == "lane_center":
        if "left" in supplied or "right" in supplied:
            raise ValueError("lane_center lanes reject left and right side lists.")
        if "reference_lane" not in supplied:
            if previous is None or previous["reference_line_role"] != "lane_center":
                raise ValueError("lanes.reference_lane is required for lane_center role.")
            return _continued_lanes(previous)
        prior_lane = previous.get("reference_lane") if previous and previous["reference_line_role"] == "lane_center" else None
        return {"reference_line_role": role, "reference_lane": _resolve_lane_record(supplied["reference_lane"], prior_lane, defaults["lane"], "lanes.reference_lane", positive=True)}
    if "reference_lane" in supplied:
        raise ValueError("lane_boundary lanes reject reference_lane.")
    result = {"reference_line_role": role}
    for side in ("left", "right"):
        if side not in supplied:
            result[side] = _continued_lane_records(previous.get(side, [])) if previous and previous["reference_line_role"] == "lane_boundary" else []
            continue
        prior = previous.get(side, []) if previous and previous["reference_line_role"] == "lane_boundary" else []
        result[side] = [_resolve_lane_record(record, prior[index] if index < len(prior) else None, defaults["lane"], "lanes." + side + "[" + str(index) + "]") for index, record in enumerate(supplied[side])]
    return result


def _continued_lane_records(records):
    continued = copy.deepcopy(records)
    for record in continued:
        previous_end = record["width_m"]["end"]
        record["width_m"] = {"start": previous_end, "end": previous_end}
    return continued


def _continued_lanes(lanes):
    if lanes["reference_line_role"] == "lane_center":
        return {"reference_line_role": "lane_center", "reference_lane": _continued_lane_records([lanes["reference_lane"]])[0]}
    return {"reference_line_role": "lane_boundary", "left": _continued_lane_records(lanes["left"]), "right": _continued_lane_records(lanes["right"])}


def resolve_v1_edge_bands(element, previous_metadata, defaults):
    previous = previous_metadata.get("edge_bands", {"left": [], "right": []}) if previous_metadata else {"left": [], "right": []}
    supplied = element.get("edge_bands")
    if supplied is None:
        return {side: _continued_lane_records(previous[side]) for side in ("left", "right")}
    result = {}
    for side in ("left", "right"):
        if side not in supplied:
            result[side] = _continued_lane_records(previous[side])
            continue
        result[side] = []
        for index, record in enumerate(supplied[side]):
            prior = previous[side][index] if index < len(previous[side]) else None
            band = {"width_m": _resolve_width(record, prior, "edge_bands." + side + "[" + str(index) + "]", False)}
            if "name" in record:
                if not record["name"]:
                    raise ValueError("edge band name must be nonempty.")
                band["name"] = record["name"]
            elif prior is not None and "name" in prior:
                band["name"] = prior["name"]
            for key in ("surface", "is_available", "is_drivable"):
                band[key] = copy.deepcopy(record.get(key, prior.get(key) if prior else defaults["edge_band"][key]))
            schema_utils.validate_string_option(band["surface"], "edge_bands." + side + ".surface", constants.VALID_SURFACES)
            band["is_available"] = strict_bool(band["is_available"], "edge_bands." + side + ".is_available")
            band["is_drivable"] = strict_bool(band["is_drivable"], "edge_bands." + side + ".is_drivable")
            result[side].append(band)
    return result


def _private_edge_band(band):
    result = {"name": band.get("name", "edge_band"), "width_start": band["width_m"]["start"], "width_end": band["width_m"]["end"], "surface": band["surface"], "available": band["is_available"], "drivable": band["is_drivable"]}
    return result


def _default_marking(defaults, pattern):
    return {
        "pattern": pattern,
        "color": copy.deepcopy(defaults["lane_marking"]["color"]),
        "nominal_width_m": float(defaults["lane_marking"]["nominal_width_m"]),
        "nominal_parallel_line_gap_m": float(defaults["lane_marking"]["nominal_parallel_line_gap_m"]),
    }


def _positional_markings(metadata, defaults):
    role = metadata["lanes"]["reference_line_role"]
    if role == "lane_center":
        return {"lane_lines": {"0": _default_marking(defaults, "dotted")}, "lane_centerlines": {}}
    left_count = len(metadata["lanes"]["left"])
    right_count = len(metadata["lanes"]["right"])
    lines = {"0": _default_marking(defaults, "dotted")}
    for index in range(1, left_count + 1):
        lines["+" + str(index)] = _default_marking(defaults, "dashed" if index < left_count else "solid")
    for index in range(1, right_count + 1):
        lines["-" + str(index)] = _default_marking(defaults, "dashed" if index < right_count else "solid")
    centers = {key: _default_marking(defaults, "none") for key in lines if key != "0"}
    return {"lane_lines": lines, "lane_centerlines": centers}


def _normalize_v1_marking(base, override, defaults, path):
    marking = schema_utils.deep_merge_dicts(base, override)
    schema_utils.validate_string_option(marking["pattern"], path + ".pattern", constants.VALID_LANE_MARKING_PATTERNS)
    marking["color"] = schema_utils.normalize_road_marking_color(marking.get("color"), path + ".color")
    marking["nominal_width_m"] = finite_float(marking["nominal_width_m"], path + ".nominal_width_m")
    marking["nominal_parallel_line_gap_m"] = finite_float(marking["nominal_parallel_line_gap_m"], path + ".nominal_parallel_line_gap_m")
    if marking["nominal_width_m"] <= 0.0:
        raise ValueError(path + ".nominal_width_m must be positive.")
    if marking["nominal_parallel_line_gap_m"] < 0.0:
        raise ValueError(path + ".nominal_parallel_line_gap_m must be non-negative.")
    return marking


def resolve_v1_lane_markings(element, previous_metadata, metadata, defaults):
    positional = _positional_markings(metadata, defaults)
    previous = previous_metadata.get("public_lane_markings") if previous_metadata else None
    if previous is not None:
        for field in ("lane_lines", "lane_centerlines"):
            for key in positional[field]:
                if key in previous[field]:
                    positional[field][key] = copy.deepcopy(previous[field][key])
    supplied = element.get("lane_markings", {})
    for field in ("lane_lines", "lane_centerlines"):
        for key, override in supplied.get(field, {}).items():
            if key not in positional[field]:
                raise ValueError("lane_markings." + field + "[" + key + "] does not exist on this element.")
            positional[field][key] = _normalize_v1_marking(positional[field][key], override, defaults, "lane_markings." + field + "[" + key + "]")
    return positional


def _private_marking(marking):
    result = copy.deepcopy(marking)
    private_pattern = {
        "right_solid_left_dashed": "solid_dashed",
        "right_dashed_left_solid": "dashed_solid",
    }.get(marking["pattern"], marking["pattern"])
    result.update({"style": private_pattern, "width_m": marking["nominal_width_m"], "gap_m": marking["nominal_parallel_line_gap_m"]})
    return result


def _private_lane_markings(markings, left_count, right_count):
    none = {"pattern": "none", "color": None, "nominal_width_m": 0.12, "nominal_parallel_line_gap_m": 0.12}
    return {
        "reference_line": _private_marking(markings["lane_lines"]["0"]),
        "left_lane_lines": [_private_marking(markings["lane_lines"].get("+" + str(index), none)) for index in range(1, left_count + 1)],
        "right_lane_lines": [_private_marking(markings["lane_lines"].get("-" + str(index), none)) for index in range(1, right_count + 1)],
        "lane_center_lines": {key: _private_marking(value) for key, value in markings["lane_centerlines"].items()},
    }


def _element_length_m(element):
    if "length" in element:
        return float(element["length"])
    return abs(np.deg2rad(float(element["angle_in_degrees"])) / float(element["curvature"]))


def _normalize_v1_spacing(spacing, defaults, path):
    normalized = schema_utils.deep_merge_dicts(defaults["inter_cone_spacing"], spacing or {})
    distribution = normalized["distribution"]
    schema_utils.validate_string_option(distribution, path + ".distribution", constants.VALID_INTER_CONE_SPACING_DISTRIBUTIONS)
    if distribution == "uniform":
        if spacing is None or "lower_bound_m" not in spacing or "upper_bound_m" not in spacing:
            raise ValueError(path + " uniform spacing requires lower_bound_m and upper_bound_m.")
        irrelevant = {"mean_m", "standard_deviation_m"}.intersection(spacing)
        if irrelevant:
            raise ValueError(path + " contains fields irrelevant to uniform spacing.")
        lower = float(normalized["lower_bound_m"])
        upper = float(normalized["upper_bound_m"])
        if lower <= 0.0 or upper < lower:
            raise ValueError(path + " uniform bounds must be positive and ordered.")
        return {"distribution": distribution, "lower_bound_m": lower, "upper_bound_m": upper}
    mean = float(normalized["mean_m"])
    standard_deviation = float(normalized["standard_deviation_m"])
    lower = float(normalized["lower_bound_m"])
    upper = normalized["upper_bound_m"]
    upper = None if upper is None else float(upper)
    if mean <= 0.0 or lower <= 0.0 or standard_deviation < 0.0 or (upper is not None and upper < lower):
        raise ValueError(path + " clipped_normal values must be positive/ordered.")
    return {"distribution": distribution, "mean_m": mean, "standard_deviation_m": standard_deviation, "lower_bound_m": lower, "upper_bound_m": upper}


def _normalize_v1_placement(value, metadata, path):
    placement = copy.deepcopy(value)
    if "mode" not in placement:
        raise ValueError(path + ".mode is required.")
    mode = placement["mode"]
    schema_utils.validate_string_option(mode, path + ".mode", constants.VALID_CONE_PLACEMENTS)
    required = {"mode", "lateral_offset_from_anchor_m"}
    if mode == "lane_center":
        required.add("lane_index")
    elif mode == "lane_line":
        required.add("lane_line_index")
    elif mode == "road_edge":
        required.add("side")
    if set(placement) != required:
        raise ValueError(path + " has missing or irrelevant fields for mode " + mode + ".")
    offset = float(placement["lateral_offset_from_anchor_m"])
    result = {"mode": mode, "lateral_offset_from_anchor_m": offset}
    if mode == "lane_center":
        index = strict_int(placement["lane_index"], path + ".lane_index")
        if index == 0 or not _signed_lane_exists(index, metadata):
            raise ValueError(path + ".lane_index must name an existing nonzero lane.")
        result["lane_index"] = index
    elif mode == "lane_line":
        index = strict_int(placement["lane_line_index"], path + ".lane_line_index")
        if index == 0 or not _signed_lane_line_exists(index, metadata):
            raise ValueError(path + ".lane_line_index must name an existing nonzero lane line.")
        result["lane_line_index"] = index
    elif mode == "road_edge":
        if placement["side"] not in ("left", "right"):
            raise ValueError(path + ".side must be 'left' or 'right'.")
        result["side"] = placement["side"]
    return result


def _signed_lane_exists(index, metadata):
    if metadata["lanes"]["reference_line_role"] == "lane_center":
        return False
    widths = metadata["left_lane_widths_start"] if index > 0 else metadata["right_lane_widths_start"]
    return abs(index) <= len(widths)


def _signed_lane_line_exists(index, metadata):
    if metadata["lanes"]["reference_line_role"] == "lane_center":
        return abs(index) == 1
    return _signed_lane_exists(index, metadata)


def _normalize_v1_cone(cone, metadata, defaults, element_length, path):
    placement = _normalize_v1_placement(cone.get("placement", {}), metadata, path + ".placement")
    color = str(cone.get("color", "orange")).lower()
    if color not in constants.CONE_COLOR_NAMES[:-1]:
        raise ValueError(path + ".color is not a supported configurable cone color.")
    radius = finite_float(cone.get("radius_m", 0.08), path + ".radius_m")
    if radius <= 0.0:
        raise ValueError(path + ".radius_m must be positive.")
    interval = copy.deepcopy(cone.get("element_progress_interval", {}))
    lower = float(interval.get("lower_bound_m", 0.0))
    upper = interval.get("upper_bound_m", None)
    upper = None if upper is None else float(upper)
    effective_upper = element_length if upper is None else upper
    if lower < 0.0 or lower > effective_upper or effective_upper > element_length:
        raise ValueError(path + ".element_progress_interval must be ordered and within the element.")
    spacing = _normalize_v1_spacing(cone.get("inter_cone_spacing"), defaults, path + ".inter_cone_spacing")
    return {"placement": placement, "color": color, "radius_m": radius, "element_progress_interval": {"lower_bound_m": lower, "upper_bound_m": upper}, "inter_cone_spacing": spacing}


def resolve_v1_cones(element, previous_metadata, metadata, defaults):
    if "cones" in element:
        specs = element["cones"]
    elif previous_metadata is not None:
        specs = previous_metadata["cones"]
    else:
        specs = []
    length = _element_length_m(element)
    return [_normalize_v1_cone(spec, metadata, defaults, length, "cones[" + str(index) + "]") for index, spec in enumerate(specs)]


def public_road_element_metadata(metadata):
    return {
        "speed_limit_kph": float(metadata["speed_limit_kph"]),
        "cross_section_width_interpolation": metadata["cross_section_width_interpolation"],
        "lanes": copy.deepcopy(metadata["lanes"]),
        "edge_bands": copy.deepcopy(metadata["edge_bands"]),
        "lane_markings": copy.deepcopy(metadata["public_lane_markings"]),
        "cones": copy.deepcopy(metadata["cones"]),
    }


def resolve_reference_line_role(element, previous_metadata, defaults):
    if "reference_line_role" in element:
        role = element["reference_line_role"]
    elif previous_metadata is not None:
        role = previous_metadata.get("reference_line_role", defaults["reference_line_role"])
    else:
        role = defaults["reference_line_role"]
    return schema_utils.validate_string_option(
        role,
        "reference_line_role",
        constants.VALID_REFERENCE_LINE_ROLES,
    )


def resolve_reference_lane_widths(element, previous_metadata, defaults, reference_line_role):
    width_fields = (
        "reference_lane_width_m",
        "reference_lane_width_start_m",
        "reference_lane_width_end_m",
    )
    side_lane_width_fields = (
        "left_lane_widths_start",
        "left_lane_widths_end",
        "right_lane_widths_start",
        "right_lane_widths_end",
    )

    if reference_line_role != "lane_center":
        for field in width_fields:
            if field in element:
                raise ValueError(field + " requires reference_line_role='lane_center'.")
        return None, None

    for field in side_lane_width_fields:
        if field in element:
            raise ValueError(
                field + " cannot be combined with reference_line_role='lane_center'. "
                "Use reference_lane_width_m or reference_lane_width_start_m/end_m instead."
            )

    has_width_m = "reference_lane_width_m" in element
    has_start_or_end = (
        ("reference_lane_width_start_m" in element) or
        ("reference_lane_width_end_m" in element)
    )
    if has_width_m and has_start_or_end:
        raise ValueError(
            "reference_lane_width_m cannot be combined with "
            "reference_lane_width_start_m or reference_lane_width_end_m."
        )

    if has_width_m:
        width_start = float(element["reference_lane_width_m"])
        width_end = width_start
    else:
        if "reference_lane_width_start_m" in element:
            width_start = float(element["reference_lane_width_start_m"])
        elif (
            previous_metadata is not None and
            previous_metadata.get("reference_line_role") == "lane_center"
        ):
            width_start = float(previous_metadata["reference_lane_width_end_m"])
        elif defaults.get("reference_lane_width_m", None) is not None:
            width_start = float(defaults["reference_lane_width_m"])
        else:
            raise ValueError(
                "reference_line_role='lane_center' requires reference_lane_width_m "
                "or reference_lane_width_start_m on the first centered-lane element."
            )

        if "reference_lane_width_end_m" in element:
            width_end = float(element["reference_lane_width_end_m"])
        else:
            width_end = width_start

    if (width_start <= 0.0) or (width_end <= 0.0):
        raise ValueError("reference lane widths must be positive.")
    return width_start, width_end


def resolve_lane_width_start(element, previous_metadata, side):
    field = side + "_lane_widths_start"
    if field in element:
        return schema_utils.as_float_list(element[field], field)
    if previous_metadata is not None:
        return list(previous_metadata[side + "_lane_widths_end"])
    return []


def resolve_lane_width_end(element, side, start_widths):
    field = side + "_lane_widths_end"
    if field in element:
        end_widths = schema_utils.as_float_list(element[field], field)
    else:
        end_widths = list(start_widths)
    if len(end_widths) != len(start_widths):
        raise ValueError(field + " must have the same length as " + side + "_lane_widths_start.")
    return end_widths


def resolve_lane_string_list(
    element,
    previous_metadata,
    side,
    property_name,
    lane_count,
    default_value,
    valid_options,
):
    field = side + "_" + property_name
    if field in element:
        values = list(element[field])
        if len(values) != lane_count:
            raise ValueError(field + " must have one entry per " + side + " lane.")
    else:
        previous_values = previous_metadata.get(field, []) if previous_metadata else []
        values = [
            previous_values[i] if i < len(previous_values) else default_value
            for i in range(lane_count)
        ]

    for value in values:
        schema_utils.validate_string_option(value, field, valid_options)
    return values


def resolve_lane_bool_list(element, previous_metadata, side, property_name, lane_count, default_value):
    field = side + "_" + property_name
    if field in element:
        values = schema_utils.as_bool_list(element[field], field)
        if len(values) != lane_count:
            raise ValueError(field + " must have one entry per " + side + " lane.")
    else:
        previous_values = previous_metadata.get(field, []) if previous_metadata else []
        values = [
            previous_values[i] if i < len(previous_values) else default_value
            for i in range(lane_count)
        ]
    return values


def resolve_edge_bands(element, previous_metadata, side, defaults):
    field = side + "_edge_bands"
    previous_bands = previous_metadata.get(field, []) if previous_metadata else []
    if field not in element:
        return previous_bands

    normalized_bands = []
    for band_idx, band in enumerate(element[field]):
        previous_band = previous_bands[band_idx] if band_idx < len(previous_bands) else {}
        width_start = float(band.get("width_start", previous_band.get("width_end", 0.0)))
        width_end = float(band.get("width_end", width_start))
        if (width_start < 0.0) or (width_end < 0.0):
            raise ValueError(field + " widths must be non-negative.")
        surface = band.get(
            "surface",
            previous_band.get("surface", defaults["edge_band_surface"]),
        )
        schema_utils.validate_string_option(surface, field + ".surface", constants.VALID_SURFACES)
        normalized_bands.append({
            "name": band.get("name", previous_band.get("name", "edge_band_" + str(band_idx + 1))),
            "width_start": width_start,
            "width_end": width_end,
            "surface": surface,
            "available": bool(band.get("available", previous_band.get("available", defaults["edge_band_available"]))),
            "drivable": bool(band.get("drivable", previous_band.get("drivable", defaults["edge_band_drivable"]))),
        })
    return normalized_bands


def default_lane_marking(defaults, style=None):
    marking = copy.deepcopy(defaults["lane_marking"])
    if style is not None:
        marking["style"] = style
    return normalize_lane_marking(defaults, marking, "lane_marking")


def normalize_lane_marking(defaults, marking, field_name):
    normalized = schema_utils.deep_merge_dicts(defaults.get("lane_marking", {}), marking or {})
    schema_utils.validate_string_option(
        normalized.get("style"),
        field_name + ".style",
        constants.VALID_LANE_MARKING_STYLES,
    )
    if float(normalized.get("width_m", 0.0)) < 0.0:
        raise ValueError(field_name + ".width_m must be non-negative.")
    if float(normalized.get("gap_m", 0.0)) < 0.0:
        raise ValueError(field_name + ".gap_m must be non-negative.")
    normalized["width_m"] = float(normalized.get("width_m", 0.0))
    normalized["gap_m"] = float(normalized.get("gap_m", 0.0))
    normalized["color"] = schema_utils.normalize_road_marking_color(
        normalized.get("color"),
        field_name + ".color",
    )
    return normalized


def default_lane_markings_for_counts(defaults, num_left_lanes, num_right_lanes):
    return {
        "reference_line": default_lane_marking(defaults, style="dotted"),
        "left_lane_lines": [
            default_lane_marking(defaults, style="dashed" if i < (num_left_lanes - 1) else "solid")
            for i in range(num_left_lanes)
        ],
        "right_lane_lines": [
            default_lane_marking(defaults, style="dashed" if i < (num_right_lanes - 1) else "solid")
            for i in range(num_right_lanes)
        ],
        "lane_center_lines": {
            schema_utils.lane_key(lane_idx): default_lane_marking(defaults, style="none")
            for lane_idx in list(range(1, num_left_lanes + 1)) + list(range(-1, -num_right_lanes - 1, -1))
        },
    }


def inherit_lane_markings_for_counts(defaults, previous_markings, num_left_lanes, num_right_lanes):
    inherited = default_lane_markings_for_counts(defaults, num_left_lanes, num_right_lanes)
    if previous_markings is None:
        return inherited

    inherited["reference_line"] = copy.deepcopy(previous_markings.get("reference_line", inherited["reference_line"]))
    for side in ("left", "right"):
        field = side + "_lane_lines"
        lane_count = num_left_lanes if side == "left" else num_right_lanes
        previous_lines = previous_markings.get(field, [])
        inherited[field] = [
            copy.deepcopy(previous_lines[i]) if i < len(previous_lines) else inherited[field][i]
            for i in range(lane_count)
        ]

    previous_center_lines = previous_markings.get("lane_center_lines", {})
    for lane_key in list(inherited["lane_center_lines"].keys()):
        if lane_key in previous_center_lines:
            inherited["lane_center_lines"][lane_key] = copy.deepcopy(previous_center_lines[lane_key])
    return inherited


def resolve_lane_markings(element, previous_metadata, metadata, defaults, schema_warnings):
    previous_markings = previous_metadata.get("lane_markings") if previous_metadata else None
    num_left_lanes = len(metadata["left_lane_widths_start"])
    num_right_lanes = len(metadata["right_lane_widths_start"])
    if "lane_markings" not in element and previous_markings is not None:
        previous_left_count = len(previous_markings.get("left_lane_lines", []))
        previous_right_count = len(previous_markings.get("right_lane_lines", []))
        if previous_left_count == num_left_lanes and previous_right_count == num_right_lanes:
            return previous_markings

    lane_markings = inherit_lane_markings_for_counts(
        defaults,
        previous_markings,
        num_left_lanes,
        num_right_lanes,
    )
    if "lane_markings" not in element:
        return lane_markings

    provided = element["lane_markings"]
    if "reference_line" in provided:
        lane_markings["reference_line"] = normalize_lane_marking(
            defaults,
            schema_utils.deep_merge_dicts(lane_markings["reference_line"], provided["reference_line"]),
            "lane_markings.reference_line",
        )
    for side in ("left", "right"):
        field = side + "_lane_lines"
        if field in provided:
            if len(provided[field]) != len(lane_markings[field]):
                raise ValueError("lane_markings." + field + " must have one marking per " + side + " lane line.")
            lane_markings[field] = [
                normalize_lane_marking(
                    defaults,
                    schema_utils.deep_merge_dicts(lane_markings[field][i], provided[field][i]),
                    "lane_markings." + field + "[" + str(i) + "]",
                )
                for i in range(len(provided[field]))
            ]

    if "lane_center_lines" in provided:
        for lane_key, marking in provided["lane_center_lines"].items():
            lane_key_str = schema_utils.lane_key(lane_key)
            if lane_key_str not in lane_markings["lane_center_lines"]:
                schema_warnings.append(
                    "Skipping lane center marking for lane " + lane_key_str +
                    " because that lane does not exist on this element."
                )
                continue
            lane_markings["lane_center_lines"][lane_key_str] = normalize_lane_marking(
                defaults,
                schema_utils.deep_merge_dicts(lane_markings["lane_center_lines"][lane_key_str], marking),
                "lane_markings.lane_center_lines[" + lane_key_str + "]",
            )
    return lane_markings


def normalize_cone_spacing(defaults, spacing, field_name):
    normalized = schema_utils.deep_merge_dicts(defaults.get("cone_spacing", {}), spacing or {})
    distribution = normalized.get("spacing_distribution", normalized.get("distribution", "gaussian"))
    schema_utils.validate_string_option(
        distribution,
        field_name + ".distribution",
        constants.VALID_CONE_SPACING_DISTRIBUTIONS,
    )
    normalized["spacing_distribution"] = distribution
    normalized.pop("distribution", None)

    min_spacing = float(normalized.get("min_spacing_m", 0.1))
    max_spacing = normalized.get("max_spacing_m", None)
    max_spacing = None if max_spacing is None else float(max_spacing)
    if min_spacing <= 0.0:
        raise ValueError(field_name + ".min_spacing_m must be positive.")
    if (max_spacing is not None) and (max_spacing < min_spacing):
        raise ValueError(field_name + ".max_spacing_m must be greater than or equal to min_spacing_m.")

    if distribution == "gaussian":
        mean_spacing = float(normalized.get("mean_spacing_m", min_spacing))
        stddev_spacing = float(normalized.get("stddev_spacing_m", 0.0))
        if mean_spacing <= 0.0:
            raise ValueError(field_name + ".mean_spacing_m must be positive.")
        if stddev_spacing < 0.0:
            raise ValueError(field_name + ".stddev_spacing_m must be non-negative.")
        normalized["mean_spacing_m"] = mean_spacing
        normalized["stddev_spacing_m"] = stddev_spacing
    else:
        if max_spacing is None:
            raise ValueError(field_name + ".max_spacing_m is required for uniform cone spacing.")

    normalized["min_spacing_m"] = min_spacing
    normalized["max_spacing_m"] = max_spacing
    return normalized


def resolve_cones(element, previous_metadata, metadata, defaults, schema_warnings):
    if "cones" in element:
        cone_specs = element["cones"]
    elif previous_metadata is not None:
        cone_specs = previous_metadata.get("cones", [])
        if _inherited_cone_targets_still_exist(cone_specs, metadata):
            return cone_specs
    else:
        cone_specs = []

    normalized_cones = []
    for cone_idx, cone_spec in enumerate(cone_specs):
        try:
            cone = normalize_cone_spec(defaults, cone_spec, "cones[" + str(cone_idx) + "]")
            cone = normalize_reference_lane_edge_cone(cone, metadata, "cones[" + str(cone_idx) + "]")
        except ValueError as exc:
            schema_warnings.append(str(exc))
            continue

        if not cone_target_exists(cone, metadata):
            schema_warnings.append(
                "Skipping cone spec " + str(cone_idx) +
                " because its placement target does not exist on this element."
            )
            continue
        normalized_cones.append(cone)
    return normalized_cones


def normalize_reference_lane_edge_cone(cone, metadata, field_name):
    if cone["placement"] != "reference_lane_edge":
        return cone

    if metadata.get("reference_line_role") != "lane_center":
        raise ValueError(
            field_name + ".placement='reference_lane_edge' requires "
            "reference_line_role='lane_center'."
        )

    side = cone.get("side", None)
    if side not in ("left", "right"):
        raise ValueError(field_name + ".side must be 'left' or 'right' for reference_lane_edge.")

    normalized = copy.deepcopy(cone)
    normalized["source_placement"] = "reference_lane_edge"
    normalized["placement"] = "lane_line"
    normalized["side"] = side
    normalized["index"] = 1
    return normalized


def _inherited_cone_targets_still_exist(cone_specs, metadata):
    for cone in cone_specs:
        if not cone_target_exists(cone, metadata):
            return False
    return True


def normalize_cone_spec(defaults, cone_spec, field_name):
    cone = copy.deepcopy(cone_spec)
    cone["placement"] = cone.get("placement", "road_edge")
    schema_utils.validate_string_option(
        cone["placement"],
        field_name + ".placement",
        constants.VALID_CONE_PLACEMENTS,
    )
    cone["offset_m"] = float(cone.get("offset_m", 0.0))
    cone["start_progress"] = float(cone.get("start_progress", 0.0))
    cone["end_progress"] = None if cone.get("end_progress", None) is None else float(cone["end_progress"])
    if cone["start_progress"] < 0.0:
        raise ValueError(field_name + ".start_progress must be non-negative.")
    if (cone["end_progress"] is not None) and (cone["end_progress"] < cone["start_progress"]):
        raise ValueError(field_name + ".end_progress must be greater than or equal to start_progress.")

    spacing_override = {
        key: cone[key]
        for key in (
            "spacing_distribution",
            "distribution",
            "mean_spacing_m",
            "stddev_spacing_m",
            "min_spacing_m",
            "max_spacing_m",
        )
        if key in cone
    }
    spacing = normalize_cone_spacing(defaults, spacing_override, field_name)
    cone.update(spacing)
    cone["color"] = str(cone.get("color", "orange")).lower()
    cone["radius_m"] = float(cone.get("radius_m", 0.08))
    if cone["radius_m"] < 0.0:
        raise ValueError(field_name + ".radius_m must be non-negative.")
    cone["enabled"] = bool(cone.get("enabled", True))
    return cone


def cone_target_exists(cone, metadata):
    placement = cone["placement"]
    if placement == "reference_line":
        return True
    if placement == "custom_offset":
        return "offset_m" in cone

    if placement == "lane_center":
        lane = int(cone.get("lane", 0))
        if lane > 0:
            return lane <= len(metadata["left_lane_widths_start"])
        if lane < 0:
            return abs(lane) <= len(metadata["right_lane_widths_start"])
        return False

    side = cone.get("side", None)
    if side not in ("left", "right"):
        return False
    lane_count = len(metadata[side + "_lane_widths_start"])
    edge_band_count = len(metadata[side + "_edge_bands"])

    if placement == "road_edge":
        return (lane_count + edge_band_count) > 0
    if placement == "lane_line":
        index = cone.get("index", None)
        if index is None:
            return False
        try:
            index = int(index)
        except (TypeError, ValueError):
            return False
        return 1 <= index <= lane_count
    return False


def lane_metadata_for_sub_element(
    lane_metadata,
    start_fraction,
    end_fraction,
    original_element_length,
    sub_element_start_progress,
    sub_element_length,
):
    if lane_metadata is None:
        return None

    metadata = copy.deepcopy(lane_metadata)
    interpolation = metadata["lane_width_interpolation"]
    start_fraction = road_utils.clamp_unit_interval(start_fraction)
    end_fraction = road_utils.clamp_unit_interval(end_fraction)

    for side in ("left", "right"):
        widths_start_key = side + "_lane_widths_start"
        widths_end_key = side + "_lane_widths_end"
        original_widths_start = lane_metadata[widths_start_key]
        original_widths_end = lane_metadata[widths_end_key]
        metadata[widths_start_key] = road_utils.interpolate_list(
            original_widths_start,
            original_widths_end,
            start_fraction,
            interpolation,
        )
        metadata[widths_end_key] = road_utils.interpolate_list(
            original_widths_start,
            original_widths_end,
            end_fraction,
            interpolation,
        )
        if metadata["lanes"]["reference_line_role"] == "lane_boundary":
            for lane_index, lane in enumerate(metadata["lanes"][side]):
                lane["width_m"] = {
                    "start": metadata[widths_start_key][lane_index],
                    "end": metadata[widths_end_key][lane_index],
                }

        edge_bands_key = side + "_edge_bands"
        metadata[edge_bands_key] = []
        for band in lane_metadata.get(edge_bands_key, []):
            new_band = copy.deepcopy(band)
            new_band["width_start"] = road_utils.interpolate_scalar(
                band.get("width_start", 0.0),
                band.get("width_end", band.get("width_start", 0.0)),
                start_fraction,
                interpolation,
            )
            new_band["width_end"] = road_utils.interpolate_scalar(
                band.get("width_start", 0.0),
                band.get("width_end", band.get("width_start", 0.0)),
                end_fraction,
                interpolation,
            )
            metadata[edge_bands_key].append(new_band)
        metadata["edge_bands"][side] = []
        for band, private_band in zip(lane_metadata["edge_bands"][side], metadata[edge_bands_key]):
            public_band = copy.deepcopy(band)
            public_band["width_m"] = {"start": private_band["width_start"], "end": private_band["width_end"]}
            metadata["edge_bands"][side].append(public_band)

    if metadata.get("reference_line_role") == "lane_center":
        metadata["reference_lane_width_start_m"] = road_utils.interpolate_scalar(
            lane_metadata["reference_lane_width_start_m"],
            lane_metadata["reference_lane_width_end_m"],
            start_fraction,
            interpolation,
        )
        metadata["reference_lane_width_end_m"] = road_utils.interpolate_scalar(
            lane_metadata["reference_lane_width_start_m"],
            lane_metadata["reference_lane_width_end_m"],
            end_fraction,
            interpolation,
        )
        metadata["lanes"]["reference_lane"]["width_m"] = {
            "start": metadata["reference_lane_width_start_m"],
            "end": metadata["reference_lane_width_end_m"],
        }

    # Cone intervals remain local to the authored public element. Private
    # geometry segments must never own or restart those series.
    metadata["cones"] = []
    metadata["lane_widths_are_constant"] = lane_widths_are_constant_in_metadata(metadata)
    return metadata


def default_reference_line_metadata(speed_limit_kph, defaults):
    metadata = {
        "speed_limit_kph": float(speed_limit_kph),
        "lanes": {"reference_line_role": "lane_boundary", "left": [], "right": []},
        "reference_line_role": "lane_boundary",
        "reference_lane_width_start_m": None,
        "reference_lane_width_end_m": None,
        "left_lane_widths_start": [],
        "left_lane_widths_end": [],
        "right_lane_widths_start": [],
        "right_lane_widths_end": [],
        "cross_section_width_interpolation": defaults["cross_section_width_interpolation"],
        "lane_width_interpolation": defaults["cross_section_width_interpolation"],
        "lane_widths_are_constant": True,
        "left_lane_directions": [],
        "right_lane_directions": [],
        "left_lane_surfaces": [],
        "right_lane_surfaces": [],
        "left_lane_available": [],
        "right_lane_available": [],
        "left_lane_drivable": [],
        "right_lane_drivable": [],
        "left_edge_bands": [],
        "right_edge_bands": [],
        "edge_bands": {"left": [], "right": []},
        "cones": [],
    }
    metadata["public_lane_markings"] = _positional_markings(metadata, defaults)
    metadata["lane_markings"] = _private_lane_markings(metadata["public_lane_markings"], 0, 0)
    return metadata


def lane_width_lists_are_constant(widths_start, widths_end):
    if len(widths_start) != len(widths_end):
        return False
    return all(
        abs(float(width_start) - float(width_end)) <= 1e-9
        for width_start, width_end in zip(widths_start, widths_end)
    )


def lane_widths_are_constant_in_metadata(metadata):
    if "lane_widths_are_constant" in metadata:
        return bool(metadata["lane_widths_are_constant"])
    return (
        lane_width_lists_are_constant(metadata["left_lane_widths_start"], metadata["left_lane_widths_end"]) and
        lane_width_lists_are_constant(metadata["right_lane_widths_start"], metadata["right_lane_widths_end"])
    )
