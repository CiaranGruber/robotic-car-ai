"""Speed helpers used by Road."""

import numbers

import numpy as np


_RADII_REF_M = np.array([
    10, 12, 20, 30, 35,
    45, 65, 80, 100, 120,
    140, 190, 235, 280, 330,
    385, 490,
], dtype=np.float32)

_SPEEDS_REF_MPS = np.array([
    15, 20, 30, 35, 40,
    50, 55, 60, 65, 70,
    75, 80, 85, 90, 95,
    100, 110,
], dtype=np.float32) / np.float32(3.6)


def normalize_public_speed_limits_mps(speed_limits_mps, expected_count):
    values = np.asarray(speed_limits_mps, dtype=object).reshape(-1)
    if values.shape[0] != int(expected_count):
        raise ValueError(
            "Length of speed_limits_mps must match number of public road elements."
        )
    normalized = np.empty(values.shape, dtype=np.float32)
    for index, value in enumerate(values):
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Real):
            raise TypeError("speed_limits_mps values must be finite real numbers.")
        numeric_value = float(value)
        if not np.isfinite(numeric_value):
            raise ValueError("speed_limits_mps values must be finite.")
        if numeric_value <= 0.0:
            raise ValueError("speed_limits_mps values must be positive.")
        with np.errstate(over="ignore", under="ignore"):
            stored_value = np.float32(numeric_value)
        if not np.isfinite(stored_value) or stored_value <= np.float32(0.0):
            raise ValueError(
                "speed_limits_mps values must remain finite and positive "
                "when stored as float32."
            )
        normalized[index] = stored_value
    return normalized


def normalize_public_element_index(element_index, public_element_count):
    if isinstance(element_index, (bool, np.bool_)) or not isinstance(
        element_index, (int, np.integer)
    ):
        raise TypeError("element_index must be an integer.")
    element_index = int(element_index)
    if element_index < 0 or element_index >= int(public_element_count):
        raise IndexError("element_index is out of range for public road elements.")
    return element_index


def public_values_from_private_segments(
    private_values,
    source_element_to_private_segment_indices,
):
    private_values = np.asarray(private_values).reshape(-1)
    public_values = np.empty(
        (len(source_element_to_private_segment_indices),),
        dtype=private_values.dtype,
    )
    for source_index, private_indices in enumerate(
        source_element_to_private_segment_indices
    ):
        if len(private_indices) == 0:
            raise ValueError("Each public road element must own a private segment.")
        public_values[source_index] = private_values[int(private_indices[0])]
    return public_values


def private_values_from_public_elements(
    public_values,
    source_element_to_private_segment_indices,
    private_segment_count,
):
    public_values = np.asarray(public_values).reshape(-1)
    if public_values.shape[0] != len(source_element_to_private_segment_indices):
        raise ValueError("Public values must contain one value per source element.")
    private_values = np.empty((int(private_segment_count),), dtype=public_values.dtype)
    for source_index, private_indices in enumerate(
        source_element_to_private_segment_indices
    ):
        private_values[np.asarray(private_indices, dtype=np.int32)] = public_values[
            source_index
        ]
    return private_values


def compute_recommended_speed_mps(curvature_per_m, speed_limit_mps):
    """
    Compute a recommended speed from curvature and a speed limit, in SI units.

    Method:
    1) Map curvature kappa to radius r = 1/|kappa|.
    2) Lookup a posted road-sign speed (km/h) from a stepwise radius-to-speed table,
       where each interval maps to the nearest lower posted sign speed.
    3) Convert to m/s and cap by the provided max_speed.

    Reference: https://austroads.gov.au/publications/road-design/agrd03

    Notes:
    - If either input is NaN or speed_limit_mps <= 0, returns NaN.
    - For |curvature_per_m| ~ 0, returns speed_limit_mps.
    """
    try:
        if curvature_per_m is None or speed_limit_mps is None:
            return np.float32(np.nan)

        kappa = float(curvature_per_m)
        speed_limit_mps = float(speed_limit_mps)
        if not np.isfinite(kappa) or not np.isfinite(speed_limit_mps) or speed_limit_mps <= 0:
            return np.float32(np.nan)

        if abs(kappa) < 1e-12:
            return np.float32(speed_limit_mps)

        radius_m = 1.0 / abs(kappa)

        if radius_m <= _RADII_REF_M[0]:
            speed_mps = _SPEEDS_REF_MPS[0]
        elif radius_m >= _RADII_REF_M[-1]:
            speed_mps = _SPEEDS_REF_MPS[-1]
        else:
            idx = np.searchsorted(_RADII_REF_M, radius_m, side="right") - 1
            speed_mps = _SPEEDS_REF_MPS[idx]

        return np.float32(min(speed_limit_mps, speed_mps))

    except Exception:
        return np.float32(np.nan)


def compute_recommended_speeds_mps(curvatures_per_m, speed_limits_mps):
    curvatures_per_m = np.asarray(curvatures_per_m, dtype=np.float32).reshape(-1)
    speed_limits_mps = np.asarray(speed_limits_mps, dtype=np.float32).reshape(-1)
    if curvatures_per_m.shape != speed_limits_mps.shape:
        raise ValueError("curvatures_per_m and speed_limits_mps must have the same shape.")

    recommended = np.full(curvatures_per_m.shape, np.nan, dtype=np.float32)
    valid_mask = (
        np.isfinite(curvatures_per_m)
        & np.isfinite(speed_limits_mps)
        & (speed_limits_mps > 0.0)
    )
    if not np.any(valid_mask):
        return recommended

    straight_mask = valid_mask & (np.abs(curvatures_per_m) < np.float32(1e-12))
    recommended[straight_mask] = speed_limits_mps[straight_mask]

    curved_mask = valid_mask & ~straight_mask
    if np.any(curved_mask):
        radii = np.float32(1.0) / np.abs(curvatures_per_m[curved_mask])
        indices = np.searchsorted(_RADII_REF_M, radii, side="right") - 1
        indices = np.clip(indices, 0, _SPEEDS_REF_MPS.shape[0] - 1)
        curve_speeds = _SPEEDS_REF_MPS[indices]
        recommended[curved_mask] = np.minimum(
            speed_limits_mps[curved_mask],
            curve_speeds,
        ).astype(np.float32)

    return recommended


def speed_values_are_different(value_1, value_2):
    return not np.isclose(value_1, value_2, atol=1e-8, rtol=0.0, equal_nan=True)


def speed_change_points(speed_values, element_start_progresses):
    speed_values = np.asarray(speed_values, dtype=np.float32).reshape(-1)
    element_start_progresses = np.asarray(element_start_progresses, dtype=np.float32).reshape(-1)
    if speed_values.shape != element_start_progresses.shape:
        raise ValueError("speed_values and element_start_progresses must have the same shape.")
    if speed_values.shape[0] == 0:
        return (
            np.empty((0,), dtype=np.float32),
            np.empty((0,), dtype=np.float32),
        )

    change_mask = np.empty(speed_values.shape, dtype=np.bool_)
    change_mask[0] = True
    change_mask[1:] = ~np.isclose(
        speed_values[1:],
        speed_values[:-1],
        atol=1e-8,
        rtol=0.0,
        equal_nan=True,
    )
    return (
        speed_values[change_mask].astype(np.float32, copy=True),
        element_start_progresses[change_mask].astype(np.float32, copy=True),
    )


def next_speed_change(
    speed_values,
    change_progresses_m,
    reference_line_progress_m,
):
    speed_values = np.asarray(speed_values).reshape(-1)
    change_progresses_m = np.asarray(change_progresses_m).reshape(-1)
    if speed_values.shape != change_progresses_m.shape:
        raise ValueError(
            "speed_values and change_progresses_m must have the same shape."
        )

    change_index = int(
        np.searchsorted(
            change_progresses_m,
            reference_line_progress_m,
            side="right",
        )
    )
    if change_index >= speed_values.shape[0]:
        return None
    return {
        "value_mps": float(speed_values[change_index]),
        "reference_line_distance_m": float(
            change_progresses_m[change_index] - reference_line_progress_m
        ),
    }
