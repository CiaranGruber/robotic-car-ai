"""Reference-line geometry helpers for Road."""

import math
import numbers
import warnings
from collections.abc import Mapping

import numpy as np


def normalize_reference_line_progress_search(value, *, total_length_m):
    """Validate and clamp the shared strict progress-search interval."""
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError("reference_line_progress_search must be None or a mapping.")
    expected_fields = {"lower_bound_m", "upper_bound_m"}
    supplied_fields = set(value)
    if supplied_fields != expected_fields:
        missing = expected_fields - supplied_fields
        unknown = supplied_fields - expected_fields
        if missing:
            raise ValueError(
                "reference_line_progress_search." + sorted(missing)[0] +
                " is required."
            )
        raise ValueError(
            "reference_line_progress_search." + sorted(str(field) for field in unknown)[0] +
            " is not supported."
        )

    normalized = {}
    for field_name in ("lower_bound_m", "upper_bound_m"):
        field_value = value[field_name]
        if isinstance(field_value, (bool, np.bool_)) or not isinstance(
            field_value, numbers.Real
        ):
            raise TypeError(
                "reference_line_progress_search." + field_name +
                " must be a finite real number."
            )
        field_value = float(field_value)
        if not math.isfinite(field_value):
            raise ValueError(
                "reference_line_progress_search." + field_name +
                " must be finite."
            )
        normalized[field_name] = field_value
    if normalized["lower_bound_m"] > normalized["upper_bound_m"]:
        raise ValueError(
            "reference_line_progress_search lower_bound_m must be less than or equal "
            "to upper_bound_m."
        )

    total_length_m = float(total_length_m)
    return {
        "lower_bound_m": min(max(normalized["lower_bound_m"], 0.0), total_length_m),
        "upper_bound_m": min(max(normalized["upper_bound_m"], 0.0), total_length_m),
    }


def find_closest_point_to_with_end_tangent_continuation(
    px,
    py,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    l_total_at_end,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
    end_points,
    end_angles,
    *,
    reference_line_progress_search=None,
):
    """Find the finite closest point plus the final straight continuation."""
    if reference_line_progress_search is None:
        includes_road_end = True
    else:
        lower_bound_m = float(reference_line_progress_search["lower_bound_m"])
        upper_bound_m = float(reference_line_progress_search["upper_bound_m"])
        includes_road_end = False

    if reference_line_progress_search is None:
        finite_result = find_closest_point_to(
            px,
            py,
            c,
            l,
            phi,
            is_straight,
            start_points,
            start_angles,
            l_total_at_start,
            l_total_at_end,
            start_tangent_vectors,
            start_left_normal_vectors,
            curvature_signs,
            inverse_abs_curvatures,
            arc_centers,
        )
    else:
        finite_result = best_closest_point_in_progress_interval(
            px,
            py,
            lower_bound_m,
            upper_bound_m,
            c,
            l,
            phi,
            is_straight,
            start_points,
            start_angles,
            l_total_at_start,
            l_total_at_end,
            start_tangent_vectors,
            start_left_normal_vectors,
            curvature_signs,
            inverse_abs_curvatures,
            arc_centers,
        )
    if not includes_road_end:
        return (*finite_result, False)

    end_x = float(end_points[-1, 0])
    end_y = float(end_points[-1, 1])
    end_angle = float(end_angles[-1])
    tangent_x = math.cos(end_angle)
    tangent_y = math.sin(end_angle)
    query_dx = float(px) - end_x
    query_dy = float(py) - end_y
    distance_along_continuation = query_dx * tangent_x + query_dy * tangent_y
    if distance_along_continuation <= 0.0:
        return (*finite_result, False)

    continuation_x = end_x + distance_along_continuation * tangent_x
    continuation_y = end_y + distance_along_continuation * tangent_y
    continuation_dx = float(px) - continuation_x
    continuation_dy = float(py) - continuation_y
    continuation_distance = math.hypot(continuation_dx, continuation_dy)
    if continuation_distance > float(finite_result[2]) + 1e-6:
        return (*finite_result, False)

    signed_lateral = tangent_x * continuation_dy - tangent_y * continuation_dx
    side = 1.0 if signed_lateral >= 0.0 else -1.0
    return (
        continuation_x,
        continuation_y,
        continuation_distance,
        side,
        float(l_total_at_end[-1]),
        end_angle,
        len(l_total_at_end) - 1,
        True,
    )


def coordinates_at_lateral_offsets(progress_values, offset_values, convert_progression_to_coordinates):
    progress_values = np.array(progress_values, dtype=np.float32).reshape(-1)
    offset_values = np.array(offset_values, dtype=np.float32).reshape(-1)
    if offset_values.shape[0] == 1:
        offset_values = np.full(shape=progress_values.shape, fill_value=offset_values[0], dtype=np.float32)
    if offset_values.shape[0] != progress_values.shape[0]:
        raise ValueError("offset_values must be scalar or match progress_values length.")

    coords, angles = convert_progression_to_coordinates(progress_values)
    left_normals = np.transpose(
        np.vstack((-np.sin(angles), np.cos(angles)), dtype=np.float32)
    )
    return coords + offset_values[:, None] * left_normals


def closest_point_on_element(
    px,
    py,
    element_idx,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
):
    px = float(px)
    py = float(py)
    element_idx = int(element_idx)
    element_start_progress = float(l_total_at_start[element_idx])

    if is_straight[element_idx]:
        start_x = float(start_points[element_idx, 0])
        start_y = float(start_points[element_idx, 1])
        road_angle = float(start_angles[element_idx])
        tangent_x = float(start_tangent_vectors[element_idx, 0])
        tangent_y = float(start_tangent_vectors[element_idx, 1])
        left_normal_x = float(start_left_normal_vectors[element_idx, 0])
        left_normal_y = float(start_left_normal_vectors[element_idx, 1])
        dx_from_start = px - start_x
        dy_from_start = py - start_y
        progress_from_start = dx_from_start * tangent_x + dy_from_start * tangent_y
        progress_from_start = min(max(progress_from_start, 0.0), float(l[element_idx]))
        px_closest = start_x + progress_from_start * tangent_x
        py_closest = start_y + progress_from_start * tangent_y
        dx_from_closest = px - px_closest
        dy_from_closest = py - py_closest
        closest_distance = math.sqrt(dx_from_closest * dx_from_closest + dy_from_closest * dy_from_closest)
        lateral_position = dx_from_start * left_normal_x + dy_from_start * left_normal_y
        side_of_the_road_line = 1.0 if lateral_position >= 0.0 else -1.0
        progress_at_closest_p = element_start_progress + progress_from_start
        return (
            px_closest,
            py_closest,
            closest_distance,
            side_of_the_road_line,
            progress_at_closest_p,
            road_angle,
            element_idx,
        )

    curvature_sign = float(curvature_signs[element_idx])
    radius = float(inverse_abs_curvatures[element_idx])
    arc_center_x = float(arc_centers[element_idx, 0])
    arc_center_y = float(arc_centers[element_idx, 1])
    dx_to_query = px - arc_center_x
    dy_to_query = py - arc_center_y
    distance_to_center = math.sqrt(dx_to_query * dx_to_query + dy_to_query * dy_to_query)
    start_radial_angle = float(start_angles[element_idx] - curvature_sign * 0.5 * math.pi)

    if distance_to_center <= 1e-12:
        unclamped_progress_angle = 0.0
    else:
        query_radial_angle = math.atan2(dy_to_query, dx_to_query)
        unclamped_progress_angle = curvature_sign * (query_radial_angle - start_radial_angle)
        unclamped_progress_angle = (unclamped_progress_angle + math.pi) % (2.0 * math.pi) - math.pi

    progress_angle = min(max(unclamped_progress_angle, 0.0), float(phi[element_idx]))
    closest_radial_angle = start_radial_angle + curvature_sign * progress_angle
    px_closest = arc_center_x + radius * math.cos(closest_radial_angle)
    py_closest = arc_center_y + radius * math.sin(closest_radial_angle)
    dx_from_closest = px - px_closest
    dy_from_closest = py - py_closest
    closest_distance = math.sqrt(dx_from_closest * dx_from_closest + dy_from_closest * dy_from_closest)
    dist_to_arc = distance_to_center - radius
    if curvature_sign > 0.0:
        side_of_the_road_line = 1.0 if dist_to_arc < 0.0 else -1.0
    else:
        side_of_the_road_line = 1.0 if dist_to_arc > 0.0 else -1.0
    progress_at_closest_p = element_start_progress + progress_angle * radius
    road_angle_at_closest_p = float(start_angles[element_idx] + curvature_sign * progress_angle)
    return (
        px_closest,
        py_closest,
        closest_distance,
        side_of_the_road_line,
        progress_at_closest_p,
        road_angle_at_closest_p,
        element_idx,
    )


def _point_on_element_at_progress(
    px,
    py,
    element_idx,
    reference_progress,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
):
    """Evaluate one exact in-element progress as a closest-point candidate."""
    px = float(px)
    py = float(py)
    element_idx = int(element_idx)
    element_start_progress = float(l_total_at_start[element_idx])
    local_progress = float(reference_progress) - element_start_progress

    if is_straight[element_idx]:
        tangent_x = float(start_tangent_vectors[element_idx, 0])
        tangent_y = float(start_tangent_vectors[element_idx, 1])
        point_x = float(start_points[element_idx, 0]) + local_progress * tangent_x
        point_y = float(start_points[element_idx, 1]) + local_progress * tangent_y
        dx_from_start = px - float(start_points[element_idx, 0])
        dy_from_start = py - float(start_points[element_idx, 1])
        lateral_position = (
            dx_from_start * float(start_left_normal_vectors[element_idx, 0]) +
            dy_from_start * float(start_left_normal_vectors[element_idx, 1])
        )
        road_angle = float(start_angles[element_idx])
        distance = abs(lateral_position)
    else:
        curvature_sign = float(curvature_signs[element_idx])
        radius = float(inverse_abs_curvatures[element_idx])
        progress_angle = local_progress / radius
        start_radial_angle = float(
            start_angles[element_idx] - curvature_sign * 0.5 * math.pi
        )
        radial_angle = start_radial_angle + curvature_sign * progress_angle
        point_x = float(arc_centers[element_idx, 0]) + radius * math.cos(radial_angle)
        point_y = float(arc_centers[element_idx, 1]) + radius * math.sin(radial_angle)
        road_angle = float(
            start_angles[element_idx] + curvature_sign * progress_angle
        )
        lateral_position = (
            (px - point_x) * -math.sin(road_angle) +
            (py - point_y) * math.cos(road_angle)
        )
        distance = abs(lateral_position)

    side = 1.0 if lateral_position >= 0.0 else -1.0
    return (
        point_x,
        point_y,
        distance,
        side,
        float(reference_progress),
        road_angle,
        element_idx,
    )


def best_closest_point_in_progress_interval(
    px,
    py,
    lower_bound_m,
    upper_bound_m,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    l_total_at_end,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
):
    """Project onto the exact closed intersection with a progress interval."""
    last_element_idx = len(l_total_at_end) - 1
    first_idx = min(
        int(np.searchsorted(l_total_at_end, lower_bound_m, side="left")),
        last_element_idx,
    )
    last_idx = min(
        int(np.searchsorted(l_total_at_end, upper_bound_m, side="right")),
        last_element_idx,
    )
    best_result = None
    best_selection_distance = None
    closest_distance_tolerance = 1e-6
    for element_idx in range(first_idx, last_idx + 1):
        element_start = float(l_total_at_start[element_idx])
        element_end = float(l_total_at_end[element_idx])
        intersection_start = max(float(lower_bound_m), element_start)
        intersection_end = min(float(upper_bound_m), element_end)
        if intersection_start > intersection_end:
            continue

        candidate = closest_point_on_element(
            px,
            py,
            element_idx,
            c,
            l,
            phi,
            is_straight,
            start_points,
            start_angles,
            l_total_at_start,
            start_tangent_vectors,
            start_left_normal_vectors,
            curvature_signs,
            inverse_abs_curvatures,
            arc_centers,
        )
        restricted_progress = min(
            max(float(candidate[4]), intersection_start),
            intersection_end,
        )
        candidate = _point_on_element_at_progress(
            px,
            py,
            element_idx,
            restricted_progress,
            c,
            l,
            phi,
            is_straight,
            start_points,
            start_angles,
            l_total_at_start,
            start_tangent_vectors,
            start_left_normal_vectors,
            curvature_signs,
            inverse_abs_curvatures,
            arc_centers,
        )
        candidate_selection_distance = math.hypot(
            float(px) - float(candidate[0]),
            float(py) - float(candidate[1]),
        )
        if (
            best_result is None or
            candidate_selection_distance <
            best_selection_distance - closest_distance_tolerance
        ):
            best_result = candidate
            best_selection_distance = candidate_selection_distance

    if best_result is None:
        raise RuntimeError("Progress-search interval did not intersect the Road.")
    return best_result


def best_closest_point_from_element_index_range(
    px,
    py,
    first_idx,
    last_idx,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
):
    best_result = None
    closest_distance_tolerance = 1e-6
    for element_idx in range(int(first_idx), int(last_idx) + 1):
        candidate = closest_point_on_element(
            px,
            py,
            element_idx,
            c,
            l,
            phi,
            is_straight,
            start_points,
            start_angles,
            l_total_at_start,
            start_tangent_vectors,
            start_left_normal_vectors,
            curvature_signs,
            inverse_abs_curvatures,
            arc_centers,
        )
        if (best_result is None) or (candidate[2] < (best_result[2] - closest_distance_tolerance)):
            best_result = candidate
    return best_result


def element_index_range_for_progress_window(l, l_total_at_end, progress_hint, search_radius_m, element_index_hint=None):
    if l_total_at_end.shape[0] == 0:
        raise ValueError("Road has no elements.")

    radius = 0.0 if search_radius_m is None else max(0.0, float(search_radius_m))
    window_epsilon = 1e-6
    total_length = float(l_total_at_end[-1])
    search_start = min(max(float(progress_hint) - radius - window_epsilon, 0.0), total_length)
    search_end = min(max(float(progress_hint) + radius + window_epsilon, 0.0), total_length)
    if search_end < search_start:
        search_start, search_end = search_end, search_start

    last_available_idx = l_total_at_end.shape[0] - 1
    if element_index_hint is not None:
        hinted_idx = min(max(int(element_index_hint), 0), last_available_idx)

        while hinted_idx < last_available_idx and l_total_at_end[hinted_idx] < search_start:
            hinted_idx += 1
        while hinted_idx > 0 and (l_total_at_end[hinted_idx] - l[hinted_idx]) > search_end:
            hinted_idx -= 1

        first_idx = hinted_idx
        while first_idx > 0 and l_total_at_end[first_idx - 1] >= search_start:
            first_idx -= 1

        last_idx = hinted_idx
        while last_idx < last_available_idx and l_total_at_end[last_idx] <= search_end:
            last_idx += 1

        return first_idx, last_idx

    first_idx = int(np.searchsorted(l_total_at_end, search_start, side="left"))
    last_idx = int(np.searchsorted(l_total_at_end, search_end, side="right"))
    first_idx = min(max(first_idx, 0), last_available_idx)
    last_idx = min(max(last_idx, 0), last_available_idx)
    return first_idx, last_idx


def find_closest_point_to(
    px,
    py,
    c,
    l,
    phi,
    is_straight,
    start_points,
    start_angles,
    l_total_at_start,
    l_total_at_end,
    start_tangent_vectors,
    start_left_normal_vectors,
    curvature_signs,
    inverse_abs_curvatures,
    arc_centers,
    reference_line_progress_hint=None,
    reference_line_element_index_hint=None,
    reference_line_progress_search_radius_m=None,
    allow_global_closest_point_fallback=True,
    private_segment_to_source_element_index=None,
):
    if c.shape[0] == 0:
        raise ValueError("Road has no elements.")

    if reference_line_progress_hint is not None:
        first_idx, last_idx = element_index_range_for_progress_window(
            l,
            l_total_at_end,
            reference_line_progress_hint,
            reference_line_progress_search_radius_m,
            element_index_hint=reference_line_element_index_hint,
        )
        if first_idx == last_idx:
            local_result = closest_point_on_element(
                px,
                py,
                first_idx,
                c,
                l,
                phi,
                is_straight,
                start_points,
                start_angles,
                l_total_at_start,
                start_tangent_vectors,
                start_left_normal_vectors,
                curvature_signs,
                inverse_abs_curvatures,
                arc_centers,
            )
        else:
            local_result = best_closest_point_from_element_index_range(
                px,
                py,
                first_idx,
                last_idx,
                c,
                l,
                phi,
                is_straight,
                start_points,
                start_angles,
                l_total_at_start,
                start_tangent_vectors,
                start_left_normal_vectors,
                curvature_signs,
                inverse_abs_curvatures,
                arc_centers,
            )
        if (local_result is not None) or not allow_global_closest_point_fallback:
            return _map_closest_result_to_source_element(
                local_result,
                private_segment_to_source_element_index,
            )

    result = best_closest_point_from_element_index_range(
        px,
        py,
        0,
        c.shape[0] - 1,
        c,
        l,
        phi,
        is_straight,
        start_points,
        start_angles,
        l_total_at_start,
        start_tangent_vectors,
        start_left_normal_vectors,
        curvature_signs,
        inverse_abs_curvatures,
        arc_centers,
    )
    return _map_closest_result_to_source_element(
        result,
        private_segment_to_source_element_index,
    )


def _map_closest_result_to_source_element(
    result,
    private_segment_to_source_element_index,
):
    if result is None or private_segment_to_source_element_index is None:
        return result
    mapped = list(result)
    mapped[-1] = int(
        private_segment_to_source_element_index[int(mapped[-1])]
    )
    return tuple(mapped)


def reference_line_samples_at_progresses(
    progression_queries,
    c,
    l,
    phi,
    is_straight,
    start_points,
    end_points,
    start_angles,
    end_angles,
    l_total_at_end,
    v_max,
    v_rec,
    include_coordinates=True,
    include_angles=True,
    include_curvatures=True,
    include_speeds=False,
    include_element_indices=True,
    element_indices=None,
    element_indices_are_trusted=False,
    progression_queries_are_in_bounds=False,
    output_dtype=np.float32,
    private_segment_to_source_element_index=None,
):
    progression_queries = np.asarray(
        progression_queries,
        dtype=output_dtype,
    ).reshape(-1)
    num_queries = progression_queries.shape[0]
    need_angles = bool(include_angles or include_coordinates)

    p_coords = np.zeros((num_queries, 2), dtype=output_dtype) if include_coordinates else None
    p_angles = np.zeros((num_queries,), dtype=output_dtype) if need_angles else None
    p_curvatures = np.zeros((num_queries,), dtype=output_dtype) if include_curvatures else None
    p_speed_limits = np.zeros((num_queries,), dtype=output_dtype) if include_speeds else None
    p_recommended_speeds = np.zeros((num_queries,), dtype=output_dtype) if include_speeds else None
    p_element_idxs = np.zeros((num_queries,), dtype=np.int32)

    if l_total_at_end.shape[0] == 0:
        raise ValueError("Road has no elements.")

    if num_queries == 0:
        samples = {
            "progress_queries": progression_queries,
        }
        if include_element_indices:
            samples["element_indices"] = p_element_idxs
        if include_coordinates:
            samples["coordinates"] = p_coords
        if include_angles:
            samples["angles"] = p_angles
        if include_curvatures:
            samples["curvatures"] = p_curvatures
        if include_speeds:
            samples["speed_limits"] = p_speed_limits
            samples["recommended_speeds"] = p_recommended_speeds
        return samples

    last_element_idx = len(l_total_at_end) - 1
    if progression_queries_are_in_bounds:
        road_idxs_raw = None
        before_start_mask = None
        after_end_mask = None
        on_road_mask = None
        on_road_indices = None
        if element_indices is None:
            p_element_idxs = np.searchsorted(
                l_total_at_end,
                progression_queries,
                side="left",
                sorter=None,
            ).astype(np.int32)
        elif element_indices_are_trusted:
            p_element_idxs = np.asarray(element_indices).reshape(-1)
            if p_element_idxs.shape != progression_queries.shape:
                raise ValueError(
                    "element_indices must have the same shape as progression_queries."
                )
        else:
            p_element_idxs = np.asarray(element_indices, dtype=np.int32).reshape(-1)
            if p_element_idxs.shape != progression_queries.shape:
                raise ValueError(
                    "element_indices must have the same shape as progression_queries."
                )
            p_element_idxs = np.clip(
                p_element_idxs,
                0,
                last_element_idx,
            ).astype(np.int32, copy=True)
        on_road_element_idxs = p_element_idxs
    else:
        if element_indices is None:
            road_idxs_raw = np.searchsorted(l_total_at_end, progression_queries, side="left", sorter=None)
            before_start_mask = progression_queries < 0.0
            after_end_mask = road_idxs_raw == len(l_total_at_end)
        else:
            road_idxs_raw = None
            p_element_idxs = np.asarray(element_indices, dtype=np.int32).reshape(-1)
            if p_element_idxs.shape != progression_queries.shape:
                raise ValueError(
                    "element_indices must have the same shape as progression_queries."
                )
            p_element_idxs = np.clip(
                p_element_idxs,
                0,
                last_element_idx,
            ).astype(np.int32, copy=True)
            before_start_mask = progression_queries < 0.0
            after_end_mask = progression_queries > l_total_at_end[-1]
        on_road_mask = ~(before_start_mask | after_end_mask)

        if np.any(before_start_mask):
            warnings.warn(
                "A progress query is less than 0.0 in road reference-line sampling. "
                "Setting the road details to the road's start point for this query.",
                UserWarning,
                stacklevel=2,
            )
            p_element_idxs[before_start_mask] = 0
            if include_coordinates:
                p_coords[before_start_mask] = np.asarray(
                    start_points[0],
                    dtype=output_dtype,
                )
            if need_angles:
                p_angles[before_start_mask] = start_angles[0]
            if include_curvatures:
                p_curvatures[before_start_mask] = c[0]

        if np.any(after_end_mask):
            this_angle = np.asarray(end_angles[-1], dtype=output_dtype)[()]
            progress_beyond_end = progression_queries[after_end_mask] - l_total_at_end[-1]
            p_element_idxs[after_end_mask] = last_element_idx
            if include_coordinates:
                p_coords[after_end_mask, 0] = end_points[-1, 0] + progress_beyond_end * np.cos(this_angle)
                p_coords[after_end_mask, 1] = end_points[-1, 1] + progress_beyond_end * np.sin(this_angle)
            if need_angles:
                p_angles[after_end_mask] = this_angle
            if include_curvatures:
                p_curvatures[after_end_mask] = 0.0

        on_road_indices = np.where(on_road_mask)[0]
        if road_idxs_raw is None:
            on_road_element_idxs = p_element_idxs[on_road_mask]
        else:
            on_road_element_idxs = road_idxs_raw[on_road_mask].astype(np.int32)
            p_element_idxs[on_road_mask] = on_road_element_idxs

    if progression_queries_are_in_bounds or on_road_indices.size > 0:
        on_road_progression_queries = (
            progression_queries
            if progression_queries_are_in_bounds
            else progression_queries[on_road_mask]
        )
        element_start_progresses = (
            np.asarray(l_total_at_end[on_road_element_idxs], dtype=output_dtype)
            - np.asarray(l[on_road_element_idxs], dtype=output_dtype)
        )
        element_progresses = on_road_progression_queries - element_start_progresses
        if include_curvatures:
            if progression_queries_are_in_bounds:
                p_curvatures[:] = c[on_road_element_idxs]
            else:
                p_curvatures[on_road_mask] = c[on_road_element_idxs]

        if include_coordinates or need_angles:
            straight_local_mask = is_straight[on_road_element_idxs]
            if np.any(straight_local_mask):
                straight_indices = (
                    np.where(straight_local_mask)[0]
                    if progression_queries_are_in_bounds
                    else on_road_indices[straight_local_mask]
                )
                straight_element_idxs = on_road_element_idxs[straight_local_mask]
                straight_progresses = element_progresses[straight_local_mask]
                straight_angles = np.asarray(
                    start_angles[straight_element_idxs],
                    dtype=output_dtype,
                )
                if include_coordinates:
                    straight_start_points = np.asarray(
                        start_points[straight_element_idxs],
                        dtype=output_dtype,
                    )
                    p_coords[straight_indices, 0] = (
                        straight_start_points[:, 0] +
                        straight_progresses * np.cos(straight_angles)
                    )
                    p_coords[straight_indices, 1] = (
                        straight_start_points[:, 1] +
                        straight_progresses * np.sin(straight_angles)
                    )
                if need_angles:
                    p_angles[straight_indices] = straight_angles

            curved_local_mask = ~straight_local_mask
            if np.any(curved_local_mask):
                curved_indices = (
                    np.where(curved_local_mask)[0]
                    if progression_queries_are_in_bounds
                    else on_road_indices[curved_local_mask]
                )
                curved_element_idxs = on_road_element_idxs[curved_local_mask]
                curved_progresses = element_progresses[curved_local_mask]
                curvatures = np.asarray(
                    c[curved_element_idxs],
                    dtype=output_dtype,
                )
                signs = np.sign(curvatures)
                curved_lengths = np.asarray(
                    l[curved_element_idxs],
                    dtype=output_dtype,
                )
                curved_angles = np.asarray(
                    phi[curved_element_idxs],
                    dtype=output_dtype,
                )
                curved_start_angles = np.asarray(
                    start_angles[curved_element_idxs],
                    dtype=output_dtype,
                )
                progress_phi = (curved_progresses / curved_lengths) * curved_angles
                chord_angles = curved_start_angles + signs * 0.5 * progress_phi
                if include_coordinates:
                    chord_lengths = 2.0 * (1.0 / np.abs(curvatures)) * np.sin(0.5 * progress_phi)
                    curved_start_points = np.asarray(
                        start_points[curved_element_idxs],
                        dtype=output_dtype,
                    )
                    p_coords[curved_indices, 0] = (
                        curved_start_points[:, 0] +
                        chord_lengths * np.cos(chord_angles)
                    )
                    p_coords[curved_indices, 1] = (
                        curved_start_points[:, 1] +
                        chord_lengths * np.sin(chord_angles)
                    )
                if need_angles:
                    p_angles[curved_indices] = chord_angles + signs * 0.5 * progress_phi

    if include_speeds:
        if v_max.shape[0] > 0:
            p_speed_limits = v_max[p_element_idxs].astype(output_dtype)
        else:
            p_speed_limits.fill(np.nan)
        if v_rec.shape[0] > 0:
            p_recommended_speeds = v_rec[p_element_idxs].astype(output_dtype)
        else:
            p_recommended_speeds.fill(np.nan)

    samples = {
        "progress_queries": progression_queries,
    }
    if include_element_indices:
        if private_segment_to_source_element_index is None:
            samples["element_indices"] = p_element_idxs
        else:
            samples["element_indices"] = np.asarray(
                private_segment_to_source_element_index,
                dtype=np.int32,
            )[p_element_idxs]
    if include_coordinates:
        samples["coordinates"] = p_coords
    if include_angles:
        samples["angles"] = p_angles
    if include_curvatures:
        samples["curvatures"] = p_curvatures
    if include_speeds:
        samples["speed_limits"] = p_speed_limits
        samples["recommended_speeds"] = p_recommended_speeds
    return samples


def reference_line_sample_at_progress_scalar(
    reference_progress,
    c,
    l,
    phi,
    is_straight,
    start_points,
    end_points,
    start_angles,
    end_angles,
    l_total_at_end,
    element_idx=None,
):
    if l_total_at_end.shape[0] == 0:
        raise ValueError("Road has no elements.")

    reference_progress = float(reference_progress)
    last_element_idx = len(l_total_at_end) - 1
    total_length = float(l_total_at_end[-1])

    if reference_progress < 0.0:
        element_idx = 0
        return {
            "px": float(start_points[0, 0]),
            "py": float(start_points[0, 1]),
            "angle": float(start_angles[0]),
            "curvature": float(c[0]),
            "element_idx": element_idx,
        }

    if reference_progress > total_length:
        element_idx = last_element_idx
        angle = float(end_angles[-1])
        progress_beyond_end = reference_progress - total_length
        return {
            "px": float(end_points[-1, 0]) + progress_beyond_end * math.cos(angle),
            "py": float(end_points[-1, 1]) + progress_beyond_end * math.sin(angle),
            "angle": angle,
            "curvature": 0.0,
            "element_idx": element_idx,
        }

    if element_idx is None:
        element_idx = int(np.searchsorted(
            l_total_at_end,
            reference_progress,
            side="left",
            sorter=None,
        ))
    else:
        element_idx = int(element_idx)
        if element_idx < 0:
            element_idx = 0
        elif element_idx > last_element_idx:
            element_idx = last_element_idx

    element_start_progress = float(l_total_at_end[element_idx]) - float(l[element_idx])
    element_progress = reference_progress - element_start_progress
    start_angle = float(start_angles[element_idx])

    if bool(is_straight[element_idx]):
        return {
            "px": float(start_points[element_idx, 0]) + element_progress * math.cos(start_angle),
            "py": float(start_points[element_idx, 1]) + element_progress * math.sin(start_angle),
            "angle": start_angle,
            "curvature": float(c[element_idx]),
            "element_idx": element_idx,
        }

    curvature = float(c[element_idx])
    sign = 1.0 if curvature >= 0.0 else -1.0
    progress_phi = (element_progress / float(l[element_idx])) * float(phi[element_idx])
    chord_angle = start_angle + sign * 0.5 * progress_phi
    chord_length = 2.0 * (1.0 / abs(curvature)) * math.sin(0.5 * progress_phi)
    return {
        "px": float(start_points[element_idx, 0]) + chord_length * math.cos(chord_angle),
        "py": float(start_points[element_idx, 1]) + chord_length * math.sin(chord_angle),
        "angle": chord_angle + sign * 0.5 * progress_phi,
        "curvature": curvature,
        "element_idx": element_idx,
    }


def element_indices_for_reference_progresses(reference_progresses, l_total_at_end):
    reference_progresses = np.asarray(reference_progresses, dtype=np.float32).reshape(-1)
    if reference_progresses.size == 0:
        return np.array([], dtype=np.int32)

    last_element_idx = len(l_total_at_end) - 1
    element_idxs = np.searchsorted(
        l_total_at_end,
        reference_progresses,
        side="left",
        sorter=None,
    ).astype(np.int32)
    element_idxs[reference_progresses < 0.0] = 0
    element_idxs[element_idxs > last_element_idx] = last_element_idx
    return element_idxs
