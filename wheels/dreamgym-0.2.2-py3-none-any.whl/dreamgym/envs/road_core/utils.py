"""Pure numerical helpers used by Road."""

import math

import numpy as np


def clamp_unit_interval(value):
    return min(max(float(value), 0.0), 1.0)


def interpolation_alpha(progress_fraction, interpolation):
    progress_fraction = clamp_unit_interval(progress_fraction)
    if interpolation == "constant":
        return 0.0
    if interpolation == "linear":
        return progress_fraction
    if interpolation == "smoothstep":
        return progress_fraction * progress_fraction * (3.0 - 2.0 * progress_fraction)
    raise ValueError("Unknown lane width interpolation: " + str(interpolation))


def interpolation_alpha_array(progress_fractions, interpolation):
    progress_fractions = np.clip(np.array(progress_fractions, dtype=np.float32), 0.0, 1.0)
    if interpolation == "constant":
        return np.zeros_like(progress_fractions, dtype=np.float32)
    if interpolation == "linear":
        return progress_fractions
    if interpolation == "smoothstep":
        return progress_fractions * progress_fractions * (3.0 - 2.0 * progress_fractions)
    raise ValueError("Unknown lane width interpolation: " + str(interpolation))


def interpolate_scalar(start_value, end_value, progress_fraction, interpolation):
    alpha = interpolation_alpha(progress_fraction, interpolation)
    return float(start_value) + (float(end_value) - float(start_value)) * alpha


def interpolate_list(start_values, end_values, progress_fraction, interpolation):
    return [
        interpolate_scalar(start_values[i], end_values[i], progress_fraction, interpolation)
        for i in range(len(start_values))
    ]


def wrap_to_pi(angle):
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def wrap_to_pi_array(angles):
    return (np.asarray(angles, dtype=np.float32) + np.float32(np.pi)) % np.float32(2.0 * np.pi) - np.float32(np.pi)


def transform_points_2d(p, px_translate, py_translate, theta_rotate, p_translate_is_in_starting_frame=True):
    """
    Transform 2D points from one frame to another. The order of translate and
    rotate depends on which frame the translation vector is given in.
    """
    rotation_matrix = np.array([
        [np.cos(theta_rotate), np.sin(theta_rotate)],
        [-np.sin(theta_rotate), np.cos(theta_rotate)],
    ])
    if p_translate_is_in_starting_frame:
        p_translated = np.subtract(p, np.array([[px_translate, py_translate]]))
        p_transformed = np.matmul(rotation_matrix, np.transpose(p_translated))
    else:
        p_rotated = np.matmul(rotation_matrix, np.transpose(p))
        p_transformed = np.subtract(p_rotated, np.array([[px_translate], [py_translate]]))

    return np.transpose(p_transformed)


def coordinates_at_lateral_offsets_from_reference_points(reference_points, reference_angles, offset_values):
    """
    Offset already-sampled reference-line points laterally without re-sampling
    road progress.
    """
    reference_points = np.asarray(reference_points, dtype=np.float32).reshape((-1, 2))
    reference_angles = np.asarray(reference_angles, dtype=np.float32).reshape(-1)
    offset_values = np.asarray(offset_values, dtype=np.float32).reshape(-1)
    if offset_values.shape[0] == 1:
        offset_values = np.full(shape=reference_angles.shape, fill_value=offset_values[0], dtype=np.float32)
    if reference_angles.shape[0] != reference_points.shape[0]:
        raise ValueError("reference_angles must have one entry per reference point.")
    if offset_values.shape[0] != reference_points.shape[0]:
        raise ValueError("offset_values must be scalar or match reference_points length.")

    left_normals = np.transpose(
        np.vstack((-np.sin(reference_angles), np.cos(reference_angles)), dtype=np.float32)
    )
    return reference_points + offset_values[:, None] * left_normals
