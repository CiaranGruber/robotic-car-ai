"""Observation orchestration helpers for Road."""

import math

import numpy as np

from dreamgym.envs.road_core import constants
from dreamgym.envs.road_core import speeds as speed_helpers
from dreamgym.envs.road_core import utils as road_utils


_EMPTY_FLOAT32_1D = np.array([], dtype=np.float32)
_EMPTY_FLOAT32_1D.setflags(write=False)
_EMPTY_FLOAT32_2D = np.empty((0, 2), dtype=np.float32)
_EMPTY_FLOAT32_2D.setflags(write=False)


def road_info_at_given_pose_and_progress_queries(
    px,
    py,
    theta,
    target_line_lookahead_distances_m,
    c,
    v_max,
    v_rec,
    next_v_max,
    l_total_at_next_v_max,
    next_v_rec,
    l_total_at_next_v_rec,
    find_closest_point_to,
    target_line_geometry,
    target_line_config=None,
    reference_line_progress_search=None,
    include_next_speed_limit_change=True,
    include_next_recommended_speed_change=True,
    lookahead_result_fields=None,
    current_result_fields=None,
):
    try:
        lookahead_distances = np.asarray(target_line_lookahead_distances_m)
        if lookahead_distances.ndim != 1:
            raise ValueError("target_line_lookahead_distances_m must be one-dimensional.")
    except (TypeError, ValueError) as exc:
        raise ValueError(
            "target_line_lookahead_distances_m must be a one-dimensional numeric sequence."
        ) from exc
    if lookahead_distances.dtype.kind not in "iuf":
        raise ValueError(
            "target_line_lookahead_distances_m must contain only real numeric values."
        )
    if not np.all(np.isfinite(lookahead_distances)):
        raise ValueError("target_line_lookahead_distances_m must contain only finite values.")
    if np.any(lookahead_distances < 0.0):
        raise ValueError("target_line_lookahead_distances_m must be nonnegative.")
    if np.any(lookahead_distances[1:] < lookahead_distances[:-1]):
        raise ValueError("target_line_lookahead_distances_m must be nondecreasing.")
    with np.errstate(over="ignore", invalid="ignore"):
        lookahead_distances = np.asarray(
            lookahead_distances,
            dtype=np.float32,
        ).copy()
    if not np.all(np.isfinite(lookahead_distances)):
        raise ValueError(
            "target_line_lookahead_distances_m values must be representable as float32."
        )
    if current_result_fields is None:
        current_result_fields = constants.CURRENT_RESULT_FIELDS
    else:
        current_result_fields = set(current_result_fields)
        invalid_fields = current_result_fields - constants.CURRENT_RESULT_FIELDS
        if invalid_fields:
            raise ValueError(
                "Unknown current_result_fields: " +
                ", ".join(sorted(str(field) for field in invalid_fields))
            )

    if lookahead_result_fields is None:
        lookahead_result_fields = constants.LOOKAHEAD_RESULT_FIELDS
    else:
        lookahead_result_fields = set(lookahead_result_fields)
        invalid_fields = lookahead_result_fields - constants.LOOKAHEAD_RESULT_FIELDS
        if invalid_fields:
            raise ValueError(
                "Unknown lookahead_result_fields: " +
                ", ".join(sorted(str(field) for field in invalid_fields))
            )

    should_return_lookahead_offsets = "target_line_lookahead.offsets_from_reference_line_m" in lookahead_result_fields
    should_return_lookahead_reference_progresses = "target_line_lookahead.mapped_reference_line_progresses_m" in lookahead_result_fields
    should_return_lookahead_world_points = "target_line_lookahead.positions_in_world_frame_m" in lookahead_result_fields
    should_return_lookahead_body_points = "target_line_lookahead.positions_in_body_frame_m" in lookahead_result_fields
    should_return_lookahead_angles = "target_line_lookahead.headings_in_world_frame_rad" in lookahead_result_fields
    should_return_lookahead_relative_angles = "target_line_lookahead.headings_in_body_frame_rad" in lookahead_result_fields
    should_return_lookahead_curvatures = "target_line_lookahead.curvatures_per_m" in lookahead_result_fields
    should_compute_lookahead = lookahead_distances.size > 0 and len(lookahead_result_fields) > 0

    if (
        not current_result_fields and
        not lookahead_result_fields and
        not include_next_speed_limit_change and
        not include_next_recommended_speed_change
    ):
        return {}

    should_return_speed_limit = (
        "speed_profile.at_closest_reference_line_progress.speed_limit_mps"
        in current_result_fields
    )
    should_return_recommended_speed = (
        "speed_profile.at_closest_reference_line_progress.recommended_speed_mps"
        in current_result_fields
    )
    should_return_reference_curvature = (
        "reference_line.closest_point.curvature_per_m" in current_result_fields
    )
    should_return_reference_lateral_error = (
        "reference_line.tracking_error.lateral_error_from_reference_line_m"
        in current_result_fields
    )
    should_return_reference_body_point = (
        "reference_line.closest_point.position_in_body_frame_m" in current_result_fields
    )
    should_return_target_world_point = (
        "target_line.at_closest_reference_line_progress.position_in_world_frame_m"
        in current_result_fields
    )
    should_return_target_body_point = (
        "target_line.at_closest_reference_line_progress.position_in_body_frame_m"
        in current_result_fields
    )
    should_return_reference_relative_angle = (
        "reference_line.tracking_error.heading_error_rad" in current_result_fields
    )
    should_return_target_relative_angle = (
        "target_line.tracking_error.heading_error_from_target_line_rad"
        in current_result_fields
    )
    should_compute_body_frame_transform = (
        should_return_reference_body_point or
        should_return_target_body_point or
        should_return_lookahead_body_points
    )
    should_compute_current_target_geometry = (
        "target_line.at_closest_reference_line_progress.target_line_offset_from_reference_line_m" in current_result_fields or
        "target_line.tracking_error.lateral_error_from_target_line_m" in current_result_fields or
        should_return_target_world_point or
        should_return_target_body_point or
        "target_line.at_closest_reference_line_progress.heading_in_world_frame_rad" in current_result_fields or
        should_return_target_relative_angle or
        "target_line.at_closest_reference_line_progress.target_line_curvature_per_m" in current_result_fields
    )

    px_closest, py_closest, closest_distance, side_of_the_road_line, progress_at_closest_p, road_angle_at_closest_p, closest_element_idx, is_end_tangent_continuation = find_closest_point_to(
        px=px,
        py=py,
        reference_line_progress_search=reference_line_progress_search,
    )

    if should_compute_current_target_geometry or should_return_reference_curvature:
        curvature_at_closest_p = (
            0.0 if is_end_tangent_continuation else c[closest_element_idx]
        )
    else:
        curvature_at_closest_p = 0.0

    if should_return_speed_limit:
        speed_limit_at_closest_p = v_max[closest_element_idx] if v_max.shape[0] > 0 else np.float32(np.nan)
    else:
        speed_limit_at_closest_p = 0.0
    if should_return_recommended_speed:
        recommended_speed_at_closest_p = v_rec[closest_element_idx] if v_rec.shape[0] > 0 else np.float32(np.nan)
    else:
        recommended_speed_at_closest_p = 0.0

    if include_next_speed_limit_change:
        next_speed_limit_change = speed_helpers.next_speed_change(
            next_v_max,
            l_total_at_next_v_max,
            progress_at_closest_p,
        )
    if include_next_recommended_speed_change:
        next_recommended_speed_change = speed_helpers.next_speed_change(
            next_v_rec,
            l_total_at_next_v_rec,
            progress_at_closest_p,
        )

    if should_compute_current_target_geometry or should_return_reference_lateral_error:
        reference_line_lateral_error = closest_distance * side_of_the_road_line
    else:
        reference_line_lateral_error = 0.0

    if should_compute_body_frame_transform:
        cos_theta = math.cos(float(theta))
        sin_theta = math.sin(float(theta))
    else:
        cos_theta = 0.0
        sin_theta = 0.0

    if (
        (should_compute_current_target_geometry or should_compute_lookahead) and
        callable(target_line_geometry)
    ):
        target_line_geometry = target_line_geometry()

    if should_compute_current_target_geometry:
        target_line_geometry.validate_target_line_config_over_reference_progress_range(
            progress_at_closest_p,
            progress_at_closest_p,
            target_line_config,
        )
        current_target_line_geometry = target_line_geometry.target_line_geometry_at_reference_point_for_config(
            progress_at_closest_p,
            px_closest,
            py_closest,
            road_angle_at_closest_p,
            curvature_at_closest_p,
            closest_element_idx,
            target_line_config,
        )
        target_line_offset_at_closest_p = current_target_line_geometry["offset"]
        target_line_px_closest = current_target_line_geometry["px"]
        target_line_py_closest = current_target_line_geometry["py"]
        target_line_angle_at_closest_p = (
            float(road_angle_at_closest_p)
            if is_end_tangent_continuation
            else current_target_line_geometry["angle"]
        )
        target_line_curvature_at_closest_p = (
            0.0
            if is_end_tangent_continuation
            else current_target_line_geometry["curvature"]
        )
        target_line_lateral_error = reference_line_lateral_error - target_line_offset_at_closest_p
    else:
        target_line_offset_at_closest_p = 0.0
        target_line_px_closest = 0.0
        target_line_py_closest = 0.0
        target_line_angle_at_closest_p = 0.0
        target_line_curvature_at_closest_p = 0.0
        target_line_lateral_error = 0.0

    if not should_compute_lookahead:
        prog_queries_from_start = _EMPTY_FLOAT32_1D
        p_coords = _EMPTY_FLOAT32_2D
        p_coords_in_body_frame = _EMPTY_FLOAT32_2D
        p_angles = _EMPTY_FLOAT32_1D
        p_curvatures = _EMPTY_FLOAT32_1D
        target_line_offsets = _EMPTY_FLOAT32_1D
    else:
        single_body_point_fast_path = None
        constant_body_points_fast_path = None
        should_try_single_body_point_fast_path = (
            lookahead_distances.size == 1 and
            should_return_lookahead_body_points and
            not should_return_lookahead_offsets and
            not should_return_lookahead_reference_progresses and
            not should_return_lookahead_world_points and
            not should_return_lookahead_angles and
            not should_return_lookahead_relative_angles
        )
        if should_try_single_body_point_fast_path:
            single_body_point_fast_path = target_line_geometry.single_target_line_body_point_lookahead_for_config_if_available(
                progress_at_closest_p,
                float(lookahead_distances[0]),
                float(px),
                float(py),
                cos_theta,
                sin_theta,
                target_line_config,
                include_curvature=should_return_lookahead_curvatures,
            )
        should_try_constant_body_points_fast_path = (
            single_body_point_fast_path is None and
            should_return_lookahead_body_points and
            not should_return_lookahead_offsets and
            not should_return_lookahead_reference_progresses and
            not should_return_lookahead_world_points and
            not should_return_lookahead_angles and
            not should_return_lookahead_relative_angles
        )
        if should_try_constant_body_points_fast_path:
            constant_body_points_fast_path = target_line_geometry.constant_target_line_body_points_lookahead_for_config_if_available(
                progress_at_closest_p,
                lookahead_distances,
                float(px),
                float(py),
                cos_theta,
                sin_theta,
                target_line_config,
                include_curvatures=should_return_lookahead_curvatures,
            )

        if single_body_point_fast_path is not None:
            prog_queries_from_start = _EMPTY_FLOAT32_1D
            p_coords = _EMPTY_FLOAT32_2D
            p_coords_in_body_frame = single_body_point_fast_path["body_points"]
            p_angles = _EMPTY_FLOAT32_1D
            p_curvatures = (
                single_body_point_fast_path["curvatures"]
                if should_return_lookahead_curvatures
                else _EMPTY_FLOAT32_1D
            )
            target_line_offsets = _EMPTY_FLOAT32_1D
        elif constant_body_points_fast_path is not None:
            prog_queries_from_start = _EMPTY_FLOAT32_1D
            p_coords = _EMPTY_FLOAT32_2D
            p_coords_in_body_frame = constant_body_points_fast_path["body_points"]
            p_angles = _EMPTY_FLOAT32_1D
            p_curvatures = (
                constant_body_points_fast_path["curvatures"]
                if should_return_lookahead_curvatures
                else _EMPTY_FLOAT32_1D
            )
            target_line_offsets = _EMPTY_FLOAT32_1D
        else:
            prog_queries_from_start, prog_query_metadata = target_line_geometry.reference_progresses_for_target_line_config_distances(
                progress_at_closest_p,
                lookahead_distances,
                target_line_config,
                return_metadata=True,
            )
            if np.any(prog_queries_from_start < 0.0):
                prog_queries_from_start = np.maximum(
                    prog_queries_from_start,
                    np.float32(0.0),
                ).astype(np.float32, copy=False)
            target_line_geometry.validate_target_line_config_over_reference_progress_range(
                max(0.0, progress_at_closest_p),
                float(np.max(prog_queries_from_start)),
                target_line_config,
            )

            should_compute_points = (
                should_return_lookahead_world_points or
                should_return_lookahead_body_points
            )
            should_compute_body_points_directly = (
                should_return_lookahead_body_points and
                not should_return_lookahead_world_points
            )
            should_compute_angles = (
                should_compute_points or
                should_return_lookahead_angles or
                should_return_lookahead_relative_angles
            )
            should_compute_curvatures = (
                should_return_lookahead_curvatures or
                should_return_lookahead_angles or
                should_return_lookahead_relative_angles
            )
            reference_samples = target_line_geometry.reference_line_samples_at_progresses(
                prog_queries_from_start,
                include_coordinates=should_compute_points,
                include_angles=should_compute_angles,
                include_curvatures=should_compute_curvatures,
                include_speeds=False,
                include_element_indices=False,
                element_indices=prog_query_metadata["element_indices"],
                element_indices_are_trusted=prog_query_metadata["element_indices_are_trusted"],
                progression_queries_are_in_bounds=prog_query_metadata["progression_queries_are_in_bounds"],
            )
            target_line_samples = target_line_geometry.target_line_geometry_from_reference_samples_for_config(
                prog_queries_from_start,
                reference_samples,
                target_line_config,
                include_offsets=should_return_lookahead_offsets,
                include_points=should_return_lookahead_world_points,
                include_body_points=should_compute_body_points_directly,
                body_frame_pose=(float(px), float(py), cos_theta, sin_theta),
                include_angles=(should_return_lookahead_angles or should_return_lookahead_relative_angles),
                include_curvatures=should_return_lookahead_curvatures,
                include_speed_scale=False,
            )
            p_coords = (
                target_line_samples["points"]
                if should_return_lookahead_world_points
                else _EMPTY_FLOAT32_2D
            )
            p_coords_in_body_frame = (
                target_line_samples["body_points"]
                if should_compute_body_points_directly
                else _EMPTY_FLOAT32_2D
            )
            p_angles = (
                target_line_samples["angles"]
                if (should_return_lookahead_angles or should_return_lookahead_relative_angles)
                else _EMPTY_FLOAT32_1D
            )
            p_curvatures = (
                target_line_samples["curvatures"]
                if should_return_lookahead_curvatures
                else _EMPTY_FLOAT32_1D
            )
            target_line_offsets = (
                target_line_samples["offsets"]
                if should_return_lookahead_offsets
                else _EMPTY_FLOAT32_1D
            )

    if should_return_reference_body_point:
        reference_dx = float(px_closest) - float(px)
        reference_dy = float(py_closest) - float(py)
        reference_line_px_closest_in_body_frame = cos_theta * reference_dx + sin_theta * reference_dy
        reference_line_py_closest_in_body_frame = -sin_theta * reference_dx + cos_theta * reference_dy
    else:
        reference_line_px_closest_in_body_frame = 0.0
        reference_line_py_closest_in_body_frame = 0.0

    if should_return_target_body_point:
        target_dx = target_line_px_closest - float(px)
        target_dy = target_line_py_closest - float(py)
        target_line_px_closest_in_body_frame = cos_theta * target_dx + sin_theta * target_dy
        target_line_py_closest_in_body_frame = -sin_theta * target_dx + cos_theta * target_dy
    else:
        target_line_px_closest_in_body_frame = 0.0
        target_line_py_closest_in_body_frame = 0.0

    if not should_return_lookahead_body_points:
        p_coords_in_body_frame = _EMPTY_FLOAT32_2D
    elif p_coords_in_body_frame.shape[0] == 0:
        if p_coords.shape[0] == 0:
            p_coords_in_body_frame = _EMPTY_FLOAT32_2D
        else:
            lookahead_dx = p_coords[:, 0] - float(px)
            lookahead_dy = p_coords[:, 1] - float(py)
            p_coords_in_body_frame = np.empty_like(p_coords, dtype=np.float32)
            p_coords_in_body_frame[:, 0] = cos_theta * lookahead_dx + sin_theta * lookahead_dy
            p_coords_in_body_frame[:, 1] = -sin_theta * lookahead_dx + cos_theta * lookahead_dy

    if should_return_lookahead_relative_angles and p_angles.shape[0] > 0:
        p_angles_relative_to_body_frame = road_utils.wrap_to_pi_array(p_angles - theta)
    else:
        p_angles_relative_to_body_frame = _EMPTY_FLOAT32_1D
    if should_return_target_relative_angle:
        target_line_angle_relative_to_body_frame_at_closest_p = road_utils.wrap_to_pi(
            theta - target_line_angle_at_closest_p
        )
    else:
        target_line_angle_relative_to_body_frame_at_closest_p = 0.0
    if should_return_reference_relative_angle:
        road_angle_relative_to_body_frame_at_closest_p = road_utils.wrap_to_pi(
            theta - road_angle_at_closest_p
        )
    else:
        road_angle_relative_to_body_frame_at_closest_p = 0.0

    info_dict = {}
    reference_closest_point = None
    if "reference_line.closest_point.road_element_index" in current_result_fields:
        reference_closest_point = {"road_element_index": int(closest_element_idx)}
    if "reference_line.closest_point.progress_m" in current_result_fields:
        if reference_closest_point is None:
            reference_closest_point = {}
        reference_closest_point["progress_m"] = float(progress_at_closest_p)
    if "reference_line.closest_point.position_in_world_frame_m" in current_result_fields:
        if reference_closest_point is None:
            reference_closest_point = {}
        reference_closest_point["position_in_world_frame_m"] = np.array(
            (px_closest, py_closest), dtype=np.float32
        )
    if "reference_line.closest_point.position_in_body_frame_m" in current_result_fields:
        if reference_closest_point is None:
            reference_closest_point = {}
        reference_closest_point["position_in_body_frame_m"] = np.array(
            (
                reference_line_px_closest_in_body_frame,
                reference_line_py_closest_in_body_frame,
            ),
            dtype=np.float32,
        )
    if "reference_line.closest_point.heading_in_world_frame_rad" in current_result_fields:
        if reference_closest_point is None:
            reference_closest_point = {}
        reference_closest_point["heading_in_world_frame_rad"] = float(
            road_angle_at_closest_p
        )
    if "reference_line.closest_point.curvature_per_m" in current_result_fields:
        if reference_closest_point is None:
            reference_closest_point = {}
        reference_closest_point["curvature_per_m"] = float(curvature_at_closest_p)

    reference_tracking_error = None
    if (
        "reference_line.tracking_error.lateral_error_from_reference_line_m"
        in current_result_fields
    ):
        reference_tracking_error = {
            "lateral_error_from_reference_line_m": float(reference_line_lateral_error)
        }
    if "reference_line.tracking_error.heading_error_rad" in current_result_fields:
        if reference_tracking_error is None:
            reference_tracking_error = {}
        reference_tracking_error["heading_error_rad"] = float(
            road_angle_relative_to_body_frame_at_closest_p
        )
    if reference_closest_point is not None or reference_tracking_error is not None:
        reference_line_result = {}
        if reference_closest_point is not None:
            reference_line_result["closest_point"] = reference_closest_point
        if reference_tracking_error is not None:
            reference_line_result["tracking_error"] = reference_tracking_error
        info_dict["reference_line"] = reference_line_result

    target_at_closest_progress = None
    if (
        "target_line.at_closest_reference_line_progress.target_line_offset_from_reference_line_m"
        in current_result_fields
    ):
        target_at_closest_progress = {
            "target_line_offset_from_reference_line_m": float(
                target_line_offset_at_closest_p
            )
        }
    if (
        "target_line.at_closest_reference_line_progress.position_in_world_frame_m"
        in current_result_fields
    ):
        if target_at_closest_progress is None:
            target_at_closest_progress = {}
        target_at_closest_progress["position_in_world_frame_m"] = np.array(
            (target_line_px_closest, target_line_py_closest), dtype=np.float32
        )
    if (
        "target_line.at_closest_reference_line_progress.position_in_body_frame_m"
        in current_result_fields
    ):
        if target_at_closest_progress is None:
            target_at_closest_progress = {}
        target_at_closest_progress["position_in_body_frame_m"] = np.array(
            (
                target_line_px_closest_in_body_frame,
                target_line_py_closest_in_body_frame,
            ),
            dtype=np.float32,
        )
    if (
        "target_line.at_closest_reference_line_progress.heading_in_world_frame_rad"
        in current_result_fields
    ):
        if target_at_closest_progress is None:
            target_at_closest_progress = {}
        target_at_closest_progress["heading_in_world_frame_rad"] = float(
            target_line_angle_at_closest_p
        )
    if (
        "target_line.at_closest_reference_line_progress.target_line_curvature_per_m"
        in current_result_fields
    ):
        if target_at_closest_progress is None:
            target_at_closest_progress = {}
        target_at_closest_progress["target_line_curvature_per_m"] = float(
            target_line_curvature_at_closest_p
        )

    target_tracking_error = None
    if (
        "target_line.tracking_error.lateral_error_from_target_line_m"
        in current_result_fields
    ):
        target_tracking_error = {
            "lateral_error_from_target_line_m": float(target_line_lateral_error)
        }
    if (
        "target_line.tracking_error.heading_error_from_target_line_rad"
        in current_result_fields
    ):
        if target_tracking_error is None:
            target_tracking_error = {}
        target_tracking_error["heading_error_from_target_line_rad"] = float(
            target_line_angle_relative_to_body_frame_at_closest_p
        )
    if target_at_closest_progress is not None or target_tracking_error is not None:
        target_line_result = {}
        if target_at_closest_progress is not None:
            target_line_result["at_closest_reference_line_progress"] = (
                target_at_closest_progress
            )
        if target_tracking_error is not None:
            target_line_result["tracking_error"] = target_tracking_error
        info_dict["target_line"] = target_line_result

    speed_at_closest_progress = None
    if should_return_speed_limit:
        speed_at_closest_progress = {"speed_limit_mps": float(speed_limit_at_closest_p)}
    if should_return_recommended_speed:
        if speed_at_closest_progress is None:
            speed_at_closest_progress = {}
        speed_at_closest_progress["recommended_speed_mps"] = float(
            recommended_speed_at_closest_p
        )
    if speed_at_closest_progress is not None:
        info_dict["speed_profile"] = {
            "at_closest_reference_line_progress": speed_at_closest_progress
        }

    target_line_lookahead = None
    if should_return_lookahead_offsets:
        target_line_lookahead = {
            "offsets_from_reference_line_m": target_line_offsets,
        }
    if should_return_lookahead_reference_progresses:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["mapped_reference_line_progresses_m"] = (
            prog_queries_from_start
        )
    if should_return_lookahead_world_points:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["positions_in_world_frame_m"] = p_coords
    if should_return_lookahead_body_points:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["positions_in_body_frame_m"] = p_coords_in_body_frame
    if should_return_lookahead_angles:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["headings_in_world_frame_rad"] = p_angles
    if should_return_lookahead_relative_angles:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["headings_in_body_frame_rad"] = (
            p_angles_relative_to_body_frame
        )
    if should_return_lookahead_curvatures:
        if target_line_lookahead is None:
            target_line_lookahead = {}
        target_line_lookahead["curvatures_per_m"] = p_curvatures
    if target_line_lookahead is not None:
        info_dict["target_line_lookahead"] = target_line_lookahead

    if include_next_speed_limit_change:
        info_dict["next_speed_limit_change"] = next_speed_limit_change
    if include_next_recommended_speed_change:
        info_dict["next_recommended_speed_change"] = (
            next_recommended_speed_change
        )

    return info_dict
