"""Facade for target-line offset, arc-length, and sampled-geometry helpers."""

from dreamgym.envs.road_core import reference_geometry
from dreamgym.envs.road_core import target_arc_length
from dreamgym.envs.road_core import target_offsets
from dreamgym.envs.road_core import target_samples


class TargetLineGeometry:
    """Helper over current Road arrays and target-line caches."""

    __slots__ = (
        "c",
        "l",
        "phi",
        "is_straight",
        "start_points",
        "end_points",
        "start_angles",
        "end_angles",
        "l_total_at_end",
        "v_max",
        "v_rec",
        "lane_metadata",
        "all_lane_widths_are_constant",
        "min_active_lane_width_m",
        "arc_length_lookup_cache",
        "constant_offsets_cache",
        "constant_offsets_continuity_cache",
        "constant_distance_lookup_cache",
        "reference_line_samples_at_progresses_callback",
    )

    def __init__(
        self,
        c,
        l,
        phi,
        is_straight,
        start_points,
        end_points,
        start_angles,
        end_angles,
        l_total_at_end,
        v_max,
        v_rec,
        lane_metadata,
        all_lane_widths_are_constant,
        min_active_lane_width_m,
        arc_length_lookup_cache,
        constant_offsets_cache,
        constant_offsets_continuity_cache,
        constant_distance_lookup_cache,
        reference_line_samples_at_progresses_callback=None,
    ):
        self.c = c
        self.l = l
        self.phi = phi
        self.is_straight = is_straight
        self.start_points = start_points
        self.end_points = end_points
        self.start_angles = start_angles
        self.end_angles = end_angles
        self.l_total_at_end = l_total_at_end
        self.v_max = v_max
        self.v_rec = v_rec
        self.lane_metadata = lane_metadata
        self.all_lane_widths_are_constant = all_lane_widths_are_constant
        self.min_active_lane_width_m = min_active_lane_width_m
        self.arc_length_lookup_cache = arc_length_lookup_cache
        self.constant_offsets_cache = constant_offsets_cache
        self.constant_offsets_continuity_cache = constant_offsets_continuity_cache
        self.constant_distance_lookup_cache = constant_distance_lookup_cache
        self.reference_line_samples_at_progresses_callback = reference_line_samples_at_progresses_callback

    def _reference_line_samples_at_progresses(
        self,
        progression_queries,
        include_coordinates=True,
        include_angles=True,
        include_curvatures=True,
        include_speeds=False,
        include_element_indices=True,
        element_indices=None,
        element_indices_are_trusted=False,
        progression_queries_are_in_bounds=False,
    ):
        if self.reference_line_samples_at_progresses_callback is not None:
            return self.reference_line_samples_at_progresses_callback(
                progression_queries,
                include_coordinates=include_coordinates,
                include_angles=include_angles,
                include_curvatures=include_curvatures,
                include_speeds=include_speeds,
                include_element_indices=include_element_indices,
                element_indices=element_indices,
                element_indices_are_trusted=element_indices_are_trusted,
                progression_queries_are_in_bounds=progression_queries_are_in_bounds,
            )
        return reference_geometry.reference_line_samples_at_progresses(
            progression_queries,
            self.c,
            self.l,
            self.phi,
            self.is_straight,
            self.start_points,
            self.end_points,
            self.start_angles,
            self.end_angles,
            self.l_total_at_end,
            self.v_max,
            self.v_rec,
            include_coordinates=include_coordinates,
            include_angles=include_angles,
            include_curvatures=include_curvatures,
            include_speeds=include_speeds,
            include_element_indices=include_element_indices,
            element_indices=element_indices,
            element_indices_are_trusted=element_indices_are_trusted,
            progression_queries_are_in_bounds=progression_queries_are_in_bounds,
        )

    def reference_line_samples_at_progresses(
        self,
        progression_queries,
        include_coordinates=True,
        include_angles=True,
        include_curvatures=True,
        include_speeds=False,
        include_element_indices=True,
        element_indices=None,
        element_indices_are_trusted=False,
        progression_queries_are_in_bounds=False,
    ):
        return self._reference_line_samples_at_progresses(
            progression_queries,
            include_coordinates=include_coordinates,
            include_angles=include_angles,
            include_curvatures=include_curvatures,
            include_speeds=include_speeds,
            include_element_indices=include_element_indices,
            element_indices=element_indices,
            element_indices_are_trusted=element_indices_are_trusted,
            progression_queries_are_in_bounds=progression_queries_are_in_bounds,
        )

    def target_line_offsets_at_progresses(
        self,
        progress_values,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.target_line_offsets_at_progresses(
            self,
            progress_values,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def validate_target_line_config_over_reference_progress_range(
        self,
        start_reference_progress,
        end_reference_progress,
        target_line_config,
    ):
        return target_offsets.validate_target_line_config_over_reference_progress_range(
            self,
            start_reference_progress,
            end_reference_progress,
            target_line_config,
        )

    @staticmethod
    def constant_target_offsets_cache_key(
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.constant_target_offsets_cache_key(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def compute_constant_target_offsets_by_element_if_available(
        self,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.compute_constant_target_offsets_by_element_if_available(
            self,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def constant_target_offsets_by_element_if_available(
        self,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.constant_target_offsets_by_element_if_available(
            self,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    @staticmethod
    def constant_target_offsets_are_continuous(offsets_by_element):
        return target_offsets.constant_target_offsets_are_continuous(offsets_by_element)

    def constant_target_offsets_are_continuous_if_available(
        self,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.constant_target_offsets_are_continuous_if_available(
            self,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def constant_target_offsets_at_progresses_if_available(
        self,
        progress_values,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.constant_target_offsets_at_progresses_if_available(
            self,
            progress_values,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def target_line_offset_derivatives_at_progresses(
        self,
        progress_values,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_offsets.target_line_offset_derivatives_at_progresses(
            self,
            progress_values,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def constant_target_distance_lookup_for_offsets(self, offsets_by_element, cache_key=None):
        return target_arc_length.constant_target_distance_lookup_for_offsets(
            self,
            offsets_by_element,
            cache_key=cache_key,
        )

    @staticmethod
    def target_distance_at_reference_progress_for_constant_offset(reference_progress, lookup):
        return target_arc_length.target_distance_at_reference_progress_for_constant_offset(
            reference_progress,
            lookup,
        )

    def reference_progress_for_single_constant_target_distance(
        self,
        start_reference_progress,
        target_line_distance_query,
        offsets_by_element,
        cache_key=None,
    ):
        return target_arc_length.reference_progress_for_single_constant_target_distance(
            self,
            start_reference_progress,
            target_line_distance_query,
            offsets_by_element,
            cache_key=cache_key,
        )

    def reference_line_sample_at_progress_scalar(self, reference_progress, element_idx=None):
        return target_samples.reference_line_sample_at_progress_scalar(
            self,
            reference_progress,
            element_idx=element_idx,
        )

    def single_target_line_body_point_lookahead_for_config_if_available(
        self,
        start_reference_progress,
        target_line_distance_query,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        target_line_config,
        include_curvature=False,
    ):
        return target_samples.single_target_line_body_point_lookahead_for_config_if_available(
            self,
            start_reference_progress,
            target_line_distance_query,
            body_px,
            body_py,
            body_cos_theta,
            body_sin_theta,
            target_line_config,
            include_curvature=include_curvature,
        )

    def single_target_line_body_point_lookahead_if_available(
        self,
        start_reference_progress,
        target_line_distance_query,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
        include_curvature=False,
    ):
        return target_samples.single_target_line_body_point_lookahead_if_available(
            self,
            start_reference_progress,
            target_line_distance_query,
            body_px,
            body_py,
            body_cos_theta,
            body_sin_theta,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
            include_curvature=include_curvature,
        )

    def constant_target_line_body_points_lookahead_if_available(
        self,
        start_reference_progress,
        target_line_distance_queries,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
        include_curvatures=False,
    ):
        return target_samples.constant_target_line_body_points_lookahead_if_available(
            self,
            start_reference_progress,
            target_line_distance_queries,
            body_px,
            body_py,
            body_cos_theta,
            body_sin_theta,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
            include_curvatures=include_curvatures,
        )

    def constant_target_line_body_points_lookahead_for_config_if_available(
        self,
        start_reference_progress,
        target_line_distance_queries,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        target_line_config,
        include_curvatures=False,
    ):
        return target_samples.constant_target_line_body_points_lookahead_for_config_if_available(
            self,
            start_reference_progress,
            target_line_distance_queries,
            body_px,
            body_py,
            body_cos_theta,
            body_sin_theta,
            target_line_config,
            include_curvatures=include_curvatures,
        )

    def element_indices_for_reference_progresses(self, reference_progresses):
        return target_samples.element_indices_for_reference_progresses(self, reference_progresses)

    def reference_progresses_for_constant_target_offset_distances(
        self,
        start_reference_progress,
        target_line_distance_queries,
        offsets_by_element,
        cache_key=None,
        return_element_indices=False,
        return_metadata=False,
    ):
        return target_arc_length.reference_progresses_for_constant_target_offset_distances(
            self,
            start_reference_progress,
            target_line_distance_queries,
            offsets_by_element,
            cache_key=cache_key,
            return_element_indices=return_element_indices,
            return_metadata=return_metadata,
        )

    @staticmethod
    def target_line_arc_length_lookup_cache_key(
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_arc_length.target_line_arc_length_lookup_cache_key(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def target_line_arc_length_reference_grid(self, mapping_step_m):
        return target_arc_length.target_line_arc_length_reference_grid(self, mapping_step_m)

    def build_target_line_arc_length_lookup(
        self,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
        mapping_step_m=0.5,
    ):
        return target_arc_length.build_target_line_arc_length_lookup(
            self,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
            mapping_step_m=mapping_step_m,
        )

    def target_line_arc_length_lookup_if_available(
        self,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_arc_length.target_line_arc_length_lookup_if_available(
            self,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    @staticmethod
    def target_distance_at_reference_progress_from_lookup(reference_progress, lookup):
        return target_arc_length.target_distance_at_reference_progress_from_lookup(
            reference_progress,
            lookup,
        )

    def reference_progresses_from_target_line_arc_length_lookup(
        self,
        start_reference_progress,
        target_line_distance_queries,
        lookup,
    ):
        return target_arc_length.reference_progresses_from_target_line_arc_length_lookup(
            self,
            start_reference_progress,
            target_line_distance_queries,
            lookup,
        )

    def target_line_geometry_from_reference_samples(
        self,
        reference_progresses,
        reference_samples,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
        include_offsets=True,
        include_points=True,
        include_body_points=False,
        body_frame_pose=None,
        include_angles=True,
        include_curvatures=True,
        include_speed_scale=True,
    ):
        return target_samples.target_line_geometry_from_reference_samples(
            self,
            reference_progresses,
            reference_samples,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
            include_offsets=include_offsets,
            include_points=include_points,
            include_body_points=include_body_points,
            body_frame_pose=body_frame_pose,
            include_angles=include_angles,
            include_curvatures=include_curvatures,
            include_speed_scale=include_speed_scale,
        )

    def target_line_geometry_from_reference_samples_for_config(
        self,
        reference_progresses,
        reference_samples,
        target_line_config,
        **kwargs,
    ):
        return target_samples.target_line_geometry_from_reference_samples_for_config(
            self,
            reference_progresses,
            reference_samples,
            target_line_config,
            **kwargs,
        )

    def target_line_geometry_at_reference_point(
        self,
        reference_progress,
        reference_px,
        reference_py,
        reference_angle,
        reference_curvature,
        reference_element_idx,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
    ):
        return target_samples.target_line_geometry_at_reference_point(
            self,
            reference_progress,
            reference_px,
            reference_py,
            reference_angle,
            reference_curvature,
            reference_element_idx,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )

    def target_line_geometry_at_reference_point_for_config(
        self,
        reference_progress,
        reference_px,
        reference_py,
        reference_angle,
        reference_curvature,
        reference_element_idx,
        target_line_config,
    ):
        result = target_samples.target_line_geometry_at_reference_point_for_config(
            self,
            reference_progress,
            reference_px,
            reference_py,
            reference_angle,
            reference_curvature,
            reference_element_idx,
            target_line_config,
        )
        parallel_curve_denominator = (
            1.0 - float(reference_curvature) * float(result["offset"])
        )
        if parallel_curve_denominator <= 0.0:
            raise ValueError(
                "Target-line parallel-curve denominator must be greater than zero."
            )
        result["curvature"] = (
            float(reference_curvature) / parallel_curve_denominator
        )
        return result

    def reference_progresses_for_target_line_distances(
        self,
        start_reference_progress,
        target_line_distance_queries,
        target_line_offset_m=0.0,
        target_lane_index=None,
        target_lane_units=None,
        target_lane_require_active=True,
        target_lane_units_allow_outside=False,
        return_element_indices=False,
        return_metadata=False,
    ):
        return target_arc_length.reference_progresses_for_target_line_distances(
            self,
            start_reference_progress,
            target_line_distance_queries,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
            return_element_indices=return_element_indices,
            return_metadata=return_metadata,
        )

    def reference_progresses_for_target_line_config_distances(
        self,
        start_reference_progress,
        target_line_distance_queries,
        target_line_config,
        return_element_indices=False,
        return_metadata=False,
    ):
        return target_arc_length.reference_progresses_for_target_line_config_distances(
            self,
            start_reference_progress,
            target_line_distance_queries,
            target_line_config,
            return_element_indices=return_element_indices,
            return_metadata=return_metadata,
        )
