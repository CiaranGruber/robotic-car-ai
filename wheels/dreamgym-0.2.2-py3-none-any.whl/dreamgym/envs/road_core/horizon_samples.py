"""Aligned target-line horizon sampling for :class:`dreamgym.envs.Road`."""

from numbers import Real

import numpy as np

from dreamgym.envs.road_core import (
    lane_geometry,
    reference_geometry,
    target_arc_length,
    target_samples,
)
from dreamgym.envs.road_preview import (
    RoadTargetLineHorizonSample,
)
from dreamgym.envs.road_core._target_config import (
    _target_line_config_values,
)
from dreamgym.envs.config_validation import (
    detached_mapping,
    reject_unknown_keys,
    strict_bool,
    strict_int,
)


_UNAVAILABLE_LANE_RIGHT_SENTINEL_METRES = 1.0
_UNAVAILABLE_LANE_LEFT_SENTINEL_METRES = -1.0
_LANE_BOUNDS_CONFIG_KEYS = {
    "target_line_lane": {"mode", "require_active_lane"},
    "lane_index": {"mode", "lane_index", "require_active_lane"},
    "reference_lane": {"mode", "require_active_lane"},
}
_TARGET_LINE_CURVATURE_MODEL_BY_MODE = {
    "reference_line": "exact_reference_line",
    "fixed_offset": "exact_parallel_curve",
    "lane_center": "local_parallel_curve_approximation",
    "lane_coordinate": "local_parallel_curve_approximation",
}


def _finite_scalar(name, value):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real scalar")
    converted = float(value)
    if not np.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    return converted


def _target_line_distance_vector(value):
    object_array = np.asarray(value, dtype=object)
    if any(isinstance(item, (bool, np.bool_)) for item in object_array.flat):
        raise TypeError("target_line_distances_m must not contain Booleans")
    array = np.asarray(value)
    if array.ndim != 1:
        raise ValueError("target_line_distances_m must be one-dimensional")
    if array.size == 0:
        raise ValueError("target_line_distances_m must be nonempty")
    if array.dtype.kind not in "iuf":
        raise TypeError("target_line_distances_m must have a real numeric dtype")
    distances = np.array(array, dtype=np.float64, copy=True)
    if not np.isfinite(distances).all():
        raise ValueError("target_line_distances_m must contain only finite values")
    if np.any(distances < 0.0):
        raise ValueError("target_line_distances_m must be nonnegative")
    if np.any(np.diff(distances) < 0.0):
        raise ValueError("target_line_distances_m must be nondecreasing")
    return distances


def _normalize_lane_bounds_config(config, target_line_config):
    if config is None:
        return None
    supplied = detached_mapping(config, "lane_bounds_config")
    mode = supplied.get("mode")
    if not isinstance(mode, str) or mode not in _LANE_BOUNDS_CONFIG_KEYS:
        raise ValueError(
            "lane_bounds_config.mode must be one of "
            + str(tuple(_LANE_BOUNDS_CONFIG_KEYS))
            + "."
        )
    reject_unknown_keys(
        supplied,
        _LANE_BOUNDS_CONFIG_KEYS[mode],
        "lane_bounds_config",
    )
    require_active_lane = strict_bool(
        supplied.get("require_active_lane", True),
        "lane_bounds_config.require_active_lane",
    )
    if mode == "target_line_lane":
        if target_line_config["mode"] != "lane_center":
            raise ValueError(
                "lane_bounds_config mode 'target_line_lane' requires "
                "target_line_config mode 'lane_center'."
            )
        return {
            "mode": mode,
            "lane_index": int(target_line_config["lane_index"]),
            "require_active_lane": require_active_lane,
        }
    if mode == "lane_index":
        if "lane_index" not in supplied:
            raise ValueError("lane_bounds_config.lane_index is required.")
        lane_index = strict_int(
            supplied["lane_index"],
            "lane_bounds_config.lane_index",
        )
        if lane_index == 0:
            raise ValueError("lane_bounds_config.lane_index must be nonzero.")
        return {
            "mode": mode,
            "lane_index": lane_index,
            "require_active_lane": require_active_lane,
        }
    return {
        "mode": mode,
        "lane_index": None,
        "require_active_lane": require_active_lane,
    }


def _continuous_target_offsets_by_element_if_available(
    geom,
    target_line_offset_metres,
    target_lane_index,
    target_lane_units,
    target_lane_units_allow_outside,
):
    if target_lane_index is None and target_lane_units is None:
        return np.broadcast_to(
            np.float64(target_line_offset_metres),
            geom.l_total_at_end.shape,
        )
    if target_lane_index == 0 or target_lane_units == 0.0:
        return np.broadcast_to(
            np.float64(0.0),
            geom.l_total_at_end.shape,
        )

    constant_offsets = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_metres,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=False,
        target_lane_units_allow_outside=bool(
            target_lane_units_allow_outside
        ),
    )
    if constant_offsets is None:
        return None
    offsets_are_continuous = (
        geom.constant_target_offsets_are_continuous_if_available(
            target_line_offset_m=target_line_offset_metres,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=False,
            target_lane_units_allow_outside=bool(
                target_lane_units_allow_outside
            ),
        )
    )
    if not offsets_are_continuous:
        return None
    return np.asarray(constant_offsets, dtype=np.float64).reshape(-1)


def map_target_line_displacement_to_reference_line_progress(
    road,
    origin_reference_line_progress_m,
    target_line_displacement_m,
    *,
    target_line_config,
):
    origin_reference_line_progress_m = _finite_scalar(
        "origin_reference_line_progress_m",
        origin_reference_line_progress_m,
    )
    target_line_displacement_m = _finite_scalar(
        "target_line_displacement_m",
        target_line_displacement_m,
    )
    (
        target_line_offset_metres,
        target_lane_index,
        target_lane_units,
        _,
        target_lane_units_allow_outside,
    ) = _target_line_config_values(target_line_config)

    geom = road._Road__target_geometry()
    total_reference_length = float(geom.l_total_at_end[-1])
    if not 0.0 <= origin_reference_line_progress_m <= total_reference_length:
        raise ValueError("origin_reference_line_progress_m lies outside the Road domain")
    if target_line_displacement_m == 0.0:
        geom.validate_target_line_config_over_reference_progress_range(
            origin_reference_line_progress_m,
            origin_reference_line_progress_m,
            target_line_config,
        )
        return origin_reference_line_progress_m

    target_is_reference_line = (
        (
            target_lane_index is None
            and target_lane_units is None
            and target_line_offset_metres == 0.0
        )
        or target_lane_index == 0
        or target_lane_units == 0.0
    )
    if target_is_reference_line:
        mapped = origin_reference_line_progress_m + target_line_displacement_m
        geom.validate_target_line_config_over_reference_progress_range(
            origin_reference_line_progress_m,
            mapped,
            target_line_config,
        )
        return mapped

    exact_target_offsets_by_element = (
        _continuous_target_offsets_by_element_if_available(
            geom,
            target_line_offset_metres,
            target_lane_index,
            target_lane_units,
            target_lane_units_allow_outside,
        )
    )
    if exact_target_offsets_by_element is not None:
        mapped = float(
            target_arc_length.reference_progresses_for_continuous_offset_displacements(
                geom,
                origin_reference_line_progress_m,
                np.array([target_line_displacement_m], dtype=np.float64),
                exact_target_offsets_by_element,
            )[0]
        )
        geom.validate_target_line_config_over_reference_progress_range(
            origin_reference_line_progress_m,
            mapped,
            target_line_config,
        )
        return mapped

    mapped = geom.reference_progresses_for_target_line_config_distances(
        origin_reference_line_progress_m,
        np.array([target_line_displacement_m], dtype=np.float64),
        target_line_config,
    )
    mapped = float(np.asarray(mapped, dtype=np.float64).reshape(-1)[0])
    geom.validate_target_line_config_over_reference_progress_range(
        origin_reference_line_progress_m,
        mapped,
        target_line_config,
    )
    return mapped


def _lane_is_eligible(lane):
    return bool(
        lane["is_available"]
        and lane["is_drivable"]
        and lane["travel_direction"] == "increasing_reference_progress"
    )


def _reference_centred_lane_is_eligible(
    lane_sample,
    minimum_active_width_metres,
    require_active_lane,
):
    metadata = lane_sample["metadata"]
    bounds = lane_geometry.reference_lane_bounds_from_lane_sample(lane_sample)
    if require_active_lane and bounds["width_m"] < minimum_active_width_metres:
        raise ValueError("Reference lane is narrower than active_lane_minimum_width_m")
    for side in ("left", "right"):
        if metadata[side + "_lane_directions"][0] != "forward":
            return False
        if not bool(metadata[side + "_lane_available"][0]):
            return False
        if not bool(metadata[side + "_lane_drivable"][0]):
            return False
    return True


def _lane_bounds_if_selected(
    geom,
    clamped_reference_progresses,
    element_indices,
    target_offsets,
    lane_bounds_config,
):
    lane_bounds_mode = lane_bounds_config["mode"]
    selected_lane_index = lane_bounds_config["lane_index"]
    require_active_lane = lane_bounds_config["require_active_lane"]
    use_reference_centred_lane = lane_bounds_mode == "reference_lane"

    lane_samples = lane_geometry.lane_samples_at_progresses(
        clamped_reference_progresses,
        geom.lane_metadata,
        geom.l,
        geom.l_total_at_end,
        output_dtype=np.float64,
        element_indices=element_indices,
        element_indices_are_trusted=True,
    )
    sample_count = len(lane_samples)
    right_bounds = np.empty((sample_count,), dtype=np.float64)
    left_bounds = np.empty((sample_count,), dtype=np.float64)
    availability = np.empty((sample_count,), dtype=np.bool_)
    for row_index, lane_sample in enumerate(lane_samples):
        if use_reference_centred_lane:
            row_is_available = _reference_centred_lane_is_eligible(
                lane_sample,
                geom.min_active_lane_width_m,
                require_active_lane,
            )
            if row_is_available:
                bounds = lane_geometry.reference_lane_bounds_from_lane_sample(lane_sample)
                physical_lower_offset = bounds["right_bound_m"]
                physical_upper_offset = bounds["left_bound_m"]
        else:
            lanes = lane_geometry.lane_dicts_at_progress(
                lane_sample["metadata"],
                lane_sample["widths"],
                geom.min_active_lane_width_m,
            )
            selected_lane = next(
                (
                    lane
                    for lane in lanes
                    if lane["lane_index"] == selected_lane_index
                ),
                None,
            )
            if selected_lane is None:
                raise ValueError(
                    f"Lane {selected_lane_index:+d} does not exist at a requested row"
                )
            if require_active_lane and not selected_lane["is_active"]:
                raise ValueError(
                    f"Lane {selected_lane_index:+d} is narrower than "
                    "active_lane_minimum_width_m at a requested row"
                )
            row_is_available = _lane_is_eligible(selected_lane)
            if row_is_available:
                physical_lower_offset = selected_lane["lower_offset_m"]
                physical_upper_offset = selected_lane["upper_offset_m"]

        if row_is_available:
            target_offset = float(target_offsets[row_index])
            right_bounds[row_index] = physical_lower_offset - target_offset
            left_bounds[row_index] = physical_upper_offset - target_offset
            availability[row_index] = True
        else:
            right_bounds[row_index] = _UNAVAILABLE_LANE_RIGHT_SENTINEL_METRES
            left_bounds[row_index] = _UNAVAILABLE_LANE_LEFT_SENTINEL_METRES
            availability[row_index] = False
    return right_bounds, left_bounds, availability


def sample_target_line_horizon(
    road,
    origin_reference_line_progress_m,
    target_line_distances_m,
    *,
    target_line_config,
    lane_bounds_config,
):
    origin_reference_line_progress_m = _finite_scalar(
        "origin_reference_line_progress_m",
        origin_reference_line_progress_m,
    )
    target_line_distances_m = _target_line_distance_vector(
        target_line_distances_m
    )
    (
        target_line_offset_metres,
        target_lane_index,
        target_lane_units,
        _,
        target_lane_units_allow_outside,
    ) = _target_line_config_values(target_line_config)
    lane_bounds_config = _normalize_lane_bounds_config(
        lane_bounds_config,
        target_line_config,
    )
    target_line_mode = target_line_config["mode"]
    target_line_curvature_model = _TARGET_LINE_CURVATURE_MODEL_BY_MODE[
        target_line_mode
    ]
    geom = road._Road__target_geometry()
    total_reference_length = float(road.total_length_m)
    if not 0.0 <= origin_reference_line_progress_m <= total_reference_length:
        raise ValueError("origin_reference_line_progress_m lies outside the Road domain")
    exact_target_offsets_by_element = (
        _continuous_target_offsets_by_element_if_available(
            geom,
            target_line_offset_metres,
            target_lane_index,
            target_lane_units,
            target_lane_units_allow_outside,
        )
    )

    if exact_target_offsets_by_element is not None:
        mapped_reference_progresses = (
            target_arc_length.reference_progresses_for_continuous_offset_displacements(
                geom,
                origin_reference_line_progress_m,
                target_line_distances_m,
                exact_target_offsets_by_element,
            )
        )
    else:
        mapped_reference_progresses = geom.reference_progresses_for_target_line_config_distances(
            origin_reference_line_progress_m,
            target_line_distances_m,
            target_line_config,
        )
    mapped_reference_progresses = np.array(
        mapped_reference_progresses,
        dtype=np.float64,
        copy=True,
    ).reshape(-1)
    mapped_reference_progresses[target_line_distances_m == 0.0] = (
        origin_reference_line_progress_m
    )
    if not np.isfinite(mapped_reference_progresses).all():
        raise ValueError("target-line distance mapping produced nonfinite progress")

    geom.validate_target_line_config_over_reference_progress_range(
        origin_reference_line_progress_m,
        float(np.max(mapped_reference_progresses)),
        target_line_config,
    )
    spatial_domain_membership = (
        (mapped_reference_progresses >= 0.0)
        & (mapped_reference_progresses <= total_reference_length)
    )
    spatial_validity = np.logical_and.accumulate(spatial_domain_membership)
    clamped_reference_progresses = np.clip(
        mapped_reference_progresses,
        0.0,
        total_reference_length,
    )

    element_indices = np.searchsorted(
        geom.l_total_at_end,
        clamped_reference_progresses,
        side="left",
    ).astype(np.int32)
    element_indices = np.minimum(element_indices, geom.l_total_at_end.shape[0] - 1)
    if exact_target_offsets_by_element is not None:
        for element_index in np.unique(element_indices):
            target_arc_length.continuous_offset_target_line_scale(
                geom,
                float(exact_target_offsets_by_element[int(element_index)]),
                int(element_index),
            )
    reference_samples = reference_geometry.reference_line_samples_at_progresses(
        clamped_reference_progresses,
        geom.c,
        geom.l,
        geom.phi,
        geom.is_straight,
        geom.start_points,
        geom.end_points,
        geom.start_angles,
        geom.end_angles,
        geom.l_total_at_end,
        geom.v_max,
        geom.v_rec,
        include_coordinates=True,
        include_angles=True,
        include_curvatures=True,
        include_speeds=True,
        include_element_indices=True,
        element_indices=element_indices,
        element_indices_are_trusted=True,
        progression_queries_are_in_bounds=True,
        output_dtype=np.float64,
    )
    target_geometry = target_samples.target_line_geometry_from_reference_samples_for_config(
        geom,
        clamped_reference_progresses,
        reference_samples,
        target_line_config,
        include_offsets=True,
        include_points=True,
        include_body_points=False,
        include_angles=True,
        include_curvatures=True,
        include_speed_scale=False,
        output_dtype=np.float64,
    )

    if lane_bounds_config is not None:
        (
            right_lane_bounds,
            left_lane_bounds,
            lane_bounds_are_available,
        ) = _lane_bounds_if_selected(
            geom,
            clamped_reference_progresses,
            element_indices,
            target_geometry["offsets"],
            lane_bounds_config,
        )
        lane_bounds_mode = lane_bounds_config["mode"]
        lane_bounds_source_lane_index = lane_bounds_config["lane_index"]
    else:
        right_lane_bounds = None
        left_lane_bounds = None
        lane_bounds_are_available = None
        lane_bounds_mode = None
        lane_bounds_source_lane_index = None

    return RoadTargetLineHorizonSample(
        target_line_distances_m=target_line_distances_m,
        mapped_reference_line_progresses_m=mapped_reference_progresses,
        positions_in_world_frame_m=target_geometry["points"],
        headings_in_world_frame_rad=target_geometry["angles"],
        curvatures_per_m=target_geometry["curvatures"],
        recommended_speeds_mps=reference_samples["recommended_speeds"],
        speed_limits_mps=reference_samples["speed_limits"],
        offsets_from_reference_line_m=target_geometry["offsets"],
        right_lane_bound_offsets_from_target_line_m=right_lane_bounds,
        left_lane_bound_offsets_from_target_line_m=left_lane_bounds,
        is_spatially_valid=spatial_validity,
        lane_bounds_are_available=lane_bounds_are_available,
        target_line_mode=target_line_mode,
        target_line_curvature_model=target_line_curvature_model,
        lane_bounds_mode=lane_bounds_mode,
        lane_bounds_source_lane_index=lane_bounds_source_lane_index,
    )
