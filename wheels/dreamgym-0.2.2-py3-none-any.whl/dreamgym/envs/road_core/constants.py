"""Constants shared by the Road implementation."""

VALID_LANE_WIDTH_INTERPOLATIONS = ("constant", "linear", "smoothstep")
VALID_REFERENCE_LINE_ROLES = ("lane_boundary", "lane_center")
VALID_LANE_DIRECTIONS = ("forward", "reverse")
VALID_LANE_TRAVEL_DIRECTIONS = (
    "increasing_reference_progress",
    "decreasing_reference_progress",
)
VALID_SURFACES = ("tarmac", "concrete", "dirt", "grass")
VALID_LANE_MARKING_PATTERNS = (
    "none",
    "solid",
    "dashed",
    "dotted",
    "double_solid",
    "double_dashed",
    "right_solid_left_dashed",
    "right_dashed_left_solid",
)
VALID_LANE_MARKING_STYLES = VALID_LANE_MARKING_PATTERNS
VALID_INTER_CONE_SPACING_DISTRIBUTIONS = ("clipped_normal", "uniform")
VALID_CONE_PLACEMENTS = (
    "road_edge",
    "lane_line",
    "lane_center",
    "reference_line",
)
VALID_ROAD_VALIDATION_MODES = ("disabled", "raise", "warn")
VALID_SPEED_TRANSITION_SOURCES = ("speed_limit", "recommended_speed")

LOOKAHEAD_RESULT_FIELDS = frozenset((
    "target_line_lookahead.offsets_from_reference_line_m",
    "target_line_lookahead.mapped_reference_line_progresses_m",
    "target_line_lookahead.positions_in_world_frame_m",
    "target_line_lookahead.positions_in_body_frame_m",
    "target_line_lookahead.headings_in_world_frame_rad",
    "target_line_lookahead.headings_in_body_frame_rad",
    "target_line_lookahead.curvatures_per_m",
))

CURRENT_RESULT_FIELDS = frozenset((
    "reference_line.closest_point.road_element_index",
    "reference_line.closest_point.progress_m",
    "reference_line.closest_point.position_in_world_frame_m",
    "reference_line.closest_point.position_in_body_frame_m",
    "reference_line.closest_point.heading_in_world_frame_rad",
    "reference_line.closest_point.curvature_per_m",
    "reference_line.tracking_error.lateral_error_from_reference_line_m",
    "reference_line.tracking_error.heading_error_rad",
    "target_line.at_closest_reference_line_progress.target_line_offset_from_reference_line_m",
    "target_line.at_closest_reference_line_progress.position_in_world_frame_m",
    "target_line.at_closest_reference_line_progress.position_in_body_frame_m",
    "target_line.at_closest_reference_line_progress.heading_in_world_frame_rad",
    "target_line.at_closest_reference_line_progress.target_line_curvature_per_m",
    "target_line.tracking_error.lateral_error_from_target_line_m",
    "target_line.tracking_error.heading_error_from_target_line_rad",
    "speed_profile.at_closest_reference_line_progress.speed_limit_mps",
    "speed_profile.at_closest_reference_line_progress.recommended_speed_mps",
))

CONE_COLOR_NAMES = (
    "yellow",
    "blue",
    "orange",
    "red",
    "green",
    "white",
    "black",
    "unknown",
)
CONE_COLOR_TO_ID = {
    color_name: color_id
    for color_id, color_name in enumerate(CONE_COLOR_NAMES)
}
CONE_COLOR_ID_TO_NAME = {
    color_id: color_name
    for color_name, color_id in CONE_COLOR_TO_ID.items()
}
CONE_COLOR_UNKNOWN_ID = CONE_COLOR_TO_ID["unknown"]
CONE_COLOR_PADDING_ID = len(CONE_COLOR_NAMES)
