"""Random road-spec generation for examples, RL training, and evaluation."""

from __future__ import annotations

from collections.abc import Mapping
from numbers import Integral
from typing import Any, Dict, Optional

import numpy as np

from dreamgym.envs.config_validation import (
    detached_mapping,
    finite_float,
    reject_unknown_keys,
    strict_bool,
)


_GENERATION_CONFIG_KEYS = frozenset({
    "element_count_range",
    "straight_element_probability",
    "straight",
    "circular_arc",
    "speed_limit_range_kph",
    "first_element",
    "initial_cross_section",
    "active_lane_minimum_width_m",
})
_RANGE_KEYS = frozenset({"lower", "upper"})
_STRAIGHT_KEYS = frozenset({"length_range_m"})
_CIRCULAR_ARC_KEYS = frozenset({"radius_range_m", "sweep_angle_range_deg"})
_FIRST_ELEMENT_KEYS = frozenset({"require_straight", "straight_length_range_m"})
_INITIAL_CROSS_SECTION_KEYS = frozenset({
    "reference_line_role",
    "left_lane_width_range_m",
    "reference_lane_width_range_m",
})


def default_random_road_generation_config() -> Dict[str, Any]:
    return {
        "element_count_range": {"lower": 4, "upper": 8},
        "straight_element_probability": 0.45,
        "straight": {
            "length_range_m": {"lower": 35.0, "upper": 140.0},
        },
        "circular_arc": {
            "radius_range_m": {"lower": 80.0, "upper": 450.0},
            "sweep_angle_range_deg": {"lower": 8.0, "upper": 45.0},
        },
        "speed_limit_range_kph": {"lower": 50.0, "upper": 90.0},
        "first_element": {
            "require_straight": True,
            "straight_length_range_m": {"lower": 20.0, "upper": 60.0},
        },
        "initial_cross_section": {
            "reference_line_role": "lane_boundary",
            "left_lane_width_range_m": {"lower": 3.0, "upper": 3.8},
        },
        "active_lane_minimum_width_m": 0.05,
    }


def _strict_nested_mapping(value: Any, allowed_keys, path: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    result = dict(value)
    reject_unknown_keys(result, allowed_keys, path)
    return result


def _normalize_range(
    value: Any,
    path: str,
    *,
    integral: bool = False,
    positive: bool = False,
) -> Dict[str, Any]:
    range_mapping = _strict_nested_mapping(value, _RANGE_KEYS, path)
    missing = _RANGE_KEYS - set(range_mapping)
    if missing:
        raise ValueError(path + "." + sorted(missing)[0] + " is required.")

    if integral:
        normalized = {}
        for endpoint in ("lower", "upper"):
            endpoint_value = range_mapping[endpoint]
            endpoint_path = path + "." + endpoint
            if isinstance(endpoint_value, bool) or not isinstance(endpoint_value, Integral):
                raise TypeError(endpoint_path + " must be an integer.")
            normalized[endpoint] = int(endpoint_value)
    else:
        normalized = {
            endpoint: finite_float(range_mapping[endpoint], path + "." + endpoint)
            for endpoint in ("lower", "upper")
        }

    lower = normalized["lower"]
    upper = normalized["upper"]
    if positive and lower <= 0:
        raise ValueError(path + " values must be positive.")
    if upper < lower:
        raise ValueError(path + ".upper must be >= " + path + ".lower.")
    return normalized


def _normalize_nested_group(
    supplied: Mapping[str, Any],
    defaults: Mapping[str, Any],
    allowed_keys,
    path: str,
) -> Dict[str, Any]:
    group = _strict_nested_mapping(supplied, allowed_keys, path)
    merged = dict(defaults)
    merged.update(group)
    return merged


def normalize_random_road_generation_config(
    generation_config: Optional[Mapping[str, Any]],
) -> Dict[str, Any]:
    defaults = default_random_road_generation_config()
    supplied = detached_mapping(generation_config, "random_road_generation_config")
    reject_unknown_keys(
        supplied,
        _GENERATION_CONFIG_KEYS,
        "random_road_generation_config",
    )

    normalized = default_random_road_generation_config()
    if "element_count_range" in supplied:
        normalized["element_count_range"] = supplied["element_count_range"]
    normalized["element_count_range"] = _normalize_range(
        normalized["element_count_range"],
        "random_road_generation_config.element_count_range",
        integral=True,
        positive=True,
    )

    probability = finite_float(
        supplied.get(
            "straight_element_probability",
            defaults["straight_element_probability"],
        ),
        "random_road_generation_config.straight_element_probability",
    )
    if not 0.0 <= probability <= 1.0:
        raise ValueError(
            "random_road_generation_config.straight_element_probability "
            "must be in [0, 1]."
        )
    normalized["straight_element_probability"] = probability

    straight = _normalize_nested_group(
        supplied.get("straight", {}),
        defaults["straight"],
        _STRAIGHT_KEYS,
        "random_road_generation_config.straight",
    )
    straight["length_range_m"] = _normalize_range(
        straight["length_range_m"],
        "random_road_generation_config.straight.length_range_m",
        positive=True,
    )
    normalized["straight"] = straight

    circular_arc = _normalize_nested_group(
        supplied.get("circular_arc", {}),
        defaults["circular_arc"],
        _CIRCULAR_ARC_KEYS,
        "random_road_generation_config.circular_arc",
    )
    for key in ("radius_range_m", "sweep_angle_range_deg"):
        circular_arc[key] = _normalize_range(
            circular_arc[key],
            "random_road_generation_config.circular_arc." + key,
            positive=True,
        )
    normalized["circular_arc"] = circular_arc

    speed_limit_range = supplied.get(
        "speed_limit_range_kph",
        defaults["speed_limit_range_kph"],
    )
    normalized["speed_limit_range_kph"] = _normalize_range(
        speed_limit_range,
        "random_road_generation_config.speed_limit_range_kph",
        positive=True,
    )

    first_element = _normalize_nested_group(
        supplied.get("first_element", {}),
        defaults["first_element"],
        _FIRST_ELEMENT_KEYS,
        "random_road_generation_config.first_element",
    )
    first_element["require_straight"] = strict_bool(
        first_element["require_straight"],
        "random_road_generation_config.first_element.require_straight",
    )
    first_element["straight_length_range_m"] = _normalize_range(
        first_element["straight_length_range_m"],
        "random_road_generation_config.first_element.straight_length_range_m",
        positive=True,
    )
    normalized["first_element"] = first_element

    initial_supplied = _strict_nested_mapping(
        supplied.get("initial_cross_section", {}),
        _INITIAL_CROSS_SECTION_KEYS,
        "random_road_generation_config.initial_cross_section",
    )
    role = initial_supplied.get(
        "reference_line_role",
        defaults["initial_cross_section"]["reference_line_role"],
    )
    if role not in ("lane_boundary", "lane_center"):
        raise ValueError(
            "random_road_generation_config.initial_cross_section."
            "reference_line_role must be lane_boundary or lane_center."
        )
    if role == "lane_boundary":
        if "reference_lane_width_range_m" in initial_supplied:
            raise ValueError(
                "random_road_generation_config.initial_cross_section."
                "reference_lane_width_range_m requires reference_line_role='lane_center'."
            )
        width_range = initial_supplied.get(
            "left_lane_width_range_m",
            defaults["initial_cross_section"]["left_lane_width_range_m"],
        )
        width_key = "left_lane_width_range_m"
    else:
        if "left_lane_width_range_m" in initial_supplied:
            raise ValueError(
                "random_road_generation_config.initial_cross_section."
                "left_lane_width_range_m requires reference_line_role='lane_boundary'."
            )
        width_range = initial_supplied.get(
            "reference_lane_width_range_m",
            defaults["initial_cross_section"]["left_lane_width_range_m"],
        )
        width_key = "reference_lane_width_range_m"
    normalized["initial_cross_section"] = {
        "reference_line_role": role,
        width_key: _normalize_range(
            width_range,
            "random_road_generation_config.initial_cross_section." + width_key,
            positive=True,
        ),
    }

    minimum_width = finite_float(
        supplied.get(
            "active_lane_minimum_width_m",
            defaults["active_lane_minimum_width_m"],
        ),
        "random_road_generation_config.active_lane_minimum_width_m",
    )
    if minimum_width < 0.0:
        raise ValueError(
            "random_road_generation_config.active_lane_minimum_width_m "
            "must be non-negative."
        )
    normalized["active_lane_minimum_width_m"] = minimum_width
    return normalized


def _validate_seed(seed: Optional[int]) -> Optional[int]:
    if seed is None:
        return None
    if isinstance(seed, bool) or not isinstance(seed, Integral):
        raise TypeError("seed must be None or a nonnegative integer.")
    seed = int(seed)
    if seed < 0:
        raise ValueError("seed must be nonnegative.")
    return seed


def _uniform(rng: np.random.Generator, range_config: Mapping[str, Any]) -> float:
    lower = range_config["lower"]
    upper = range_config["upper"]
    if upper == lower:
        return float(lower)
    return float(rng.uniform(lower, upper))


def _random_straight_geometry(
    rng: np.random.Generator,
    generation_config: Mapping[str, Any],
    *,
    first: bool,
) -> Dict[str, Any]:
    if first:
        length_range = generation_config["first_element"]["straight_length_range_m"]
    else:
        length_range = generation_config["straight"]["length_range_m"]
    return {
        "type": "straight",
        "length_m": _uniform(rng, length_range),
    }


def _random_circular_arc_geometry(
    rng: np.random.Generator,
    generation_config: Mapping[str, Any],
) -> Dict[str, Any]:
    circular_arc = generation_config["circular_arc"]
    radius_m = _uniform(rng, circular_arc["radius_range_m"])
    sign = -1.0 if rng.random() < 0.5 else 1.0
    return {
        "type": "circular_arc",
        "curvature_per_m": sign / radius_m,
        "sweep_angle_deg": _uniform(rng, circular_arc["sweep_angle_range_deg"]),
    }


def _initial_lanes(
    rng: np.random.Generator,
    generation_config: Mapping[str, Any],
) -> Dict[str, Any]:
    initial_cross_section = generation_config["initial_cross_section"]
    role = initial_cross_section["reference_line_role"]
    if role == "lane_center":
        width_m = _uniform(
            rng,
            initial_cross_section["reference_lane_width_range_m"],
        )
        return {
            "reference_line_role": "lane_center",
            "reference_lane": {"width_m": {"start": width_m}},
        }
    width_m = _uniform(rng, initial_cross_section["left_lane_width_range_m"])
    return {
        "reference_line_role": "lane_boundary",
        "left": [{"width_m": {"start": width_m}}],
        "right": [],
    }


def generate_random_road_spec(
    generation_config: Optional[Mapping[str, Any]] = None,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Generate a deterministic Road-compatible specification."""

    config = normalize_random_road_generation_config(generation_config)
    rng = np.random.default_rng(_validate_seed(seed))
    count_range = config["element_count_range"]
    element_count = int(
        rng.integers(count_range["lower"], count_range["upper"] + 1)
    )

    elements = []
    for element_index in range(element_count):
        first = element_index == 0
        if first and config["first_element"]["require_straight"]:
            geometry = _random_straight_geometry(rng, config, first=True)
        elif rng.random() < config["straight_element_probability"]:
            geometry = _random_straight_geometry(rng, config, first=first)
        else:
            geometry = _random_circular_arc_geometry(rng, config)

        element = {
            "geometry": geometry,
            "speed_limit_kph": _uniform(rng, config["speed_limit_range_kph"]),
        }
        if first:
            element["lanes"] = _initial_lanes(rng, config)
        elements.append(element)

    return {
        "active_lane_minimum_width_m": config["active_lane_minimum_width_m"],
        "elements": elements,
    }
