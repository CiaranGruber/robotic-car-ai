"""Cone generation and cone-detection helpers for Road."""

import numpy as np

from dreamgym.envs.road_core import constants as road_constants
from dreamgym.envs.road_core import lane_geometry
from dreamgym.envs.road_core import utils as road_utils


MIN_CONE_SPACING_M = 1e-6


def sample_cone_spacing(cone, rng):
    spacing_config = cone["inter_cone_spacing"]
    if spacing_config["distribution"] == "uniform":
        spacing = rng.uniform(spacing_config["lower_bound_m"], spacing_config["upper_bound_m"])
    else:
        spacing = rng.normal(spacing_config["mean_m"], spacing_config["standard_deviation_m"])
        spacing = max(spacing, spacing_config["lower_bound_m"])
        if spacing_config["upper_bound_m"] is not None:
            spacing = min(spacing, spacing_config["upper_bound_m"])
    return max(float(spacing), 1e-6)


def sample_cone_local_progresses(cone, local_start, local_end, rng):
    local_progresses = []
    local_progress = float(local_start)
    local_end = float(local_end)
    while local_progress <= local_end + 1e-9:
        local_progresses.append(local_progress)
        local_progress += sample_cone_spacing(cone, rng)
    return np.asarray(local_progresses, dtype=np.float32)


def cone_color_to_id(color):
    return road_constants.CONE_COLOR_TO_ID.get(
        str(color).lower(),
        road_constants.CONE_COLOR_UNKNOWN_ID,
    )


def cone_point_arrays_from_cone_points(cone_points):
    if len(cone_points) == 0:
        return (
            np.empty((0, 2), dtype=np.float32),
            np.empty((0,), dtype=np.int32),
        )

    p_cones = np.empty((len(cone_points), 2), dtype=np.float32)
    cone_color = np.empty((len(cone_points),), dtype=np.int32)
    for idx, cone in enumerate(cone_points):
        p_cones[idx, 0] = float(cone["px"])
        p_cones[idx, 1] = float(cone["py"])
        cone_color[idx] = cone_color_to_id(cone.get("color", "unknown"))

    return p_cones, cone_color


def _element_fractions_from_local_progresses(local_progresses, element_length):
    local_progresses = np.asarray(local_progresses, dtype=np.float32).reshape(-1)
    element_length = float(element_length)
    if element_length <= 0.0:
        return np.zeros(shape=local_progresses.shape, dtype=np.float32)
    return np.clip(local_progresses / element_length, 0.0, 1.0).astype(np.float32)


def _lane_width_matrix(metadata, side, element_fractions):
    if side + "_lane_widths_start" not in metadata:
        lanes = metadata["lanes"].get(side, [])
        interpolation = metadata["cross_section_width_interpolation"]
        alpha = road_utils.interpolation_alpha_array(element_fractions, interpolation).reshape(-1, 1)
        starts = np.asarray([lane["width_m"]["start"] for lane in lanes], dtype=np.float32).reshape(1, -1)
        ends = np.asarray([lane["width_m"]["end"] for lane in lanes], dtype=np.float32).reshape(1, -1)
        return starts + (ends - starts) * alpha
    return lane_geometry.lane_width_matrix_for_metadata_at_fractions(
        metadata,
        side,
        element_fractions,
    )


def _edge_band_width_matrix(metadata, side, element_fractions):
    public = side + "_edge_bands" not in metadata
    edge_bands = metadata["edge_bands"][side] if public else metadata[side + "_edge_bands"]
    if len(edge_bands) == 0:
        return np.zeros((element_fractions.shape[0], 0), dtype=np.float32)

    interpolation = metadata.get("lane_width_interpolation", metadata.get("cross_section_width_interpolation"))
    alpha = road_utils.interpolation_alpha_array(element_fractions, interpolation).reshape(-1, 1)
    starts = np.asarray(
        [float(band["width_m"]["start"] if public else band.get("width_start", 0.0)) for band in edge_bands],
        dtype=np.float32,
    ).reshape(1, -1)
    ends = np.asarray(
        [float(band["width_m"]["end"] if public else band.get("width_end", band.get("width_start", 0.0))) for band in edge_bands],
        dtype=np.float32,
    ).reshape(1, -1)
    return starts + (ends - starts) * alpha


def cone_offsets_at_progresses_for_element(road, cone, local_progresses, metadata, element_length):
    placement_record = cone["placement"]
    placement = placement_record["mode"]
    offset = float(placement_record["lateral_offset_from_anchor_m"])
    local_progresses = np.asarray(local_progresses, dtype=np.float32).reshape(-1)
    if local_progresses.size == 0:
        return np.empty((0,), dtype=np.float32)

    if placement == "reference_line":
        return np.full(shape=local_progresses.shape, fill_value=offset, dtype=np.float32)
    if placement == "custom_offset":
        return np.full(shape=local_progresses.shape, fill_value=offset, dtype=np.float32)

    element_fractions = _element_fractions_from_local_progresses(local_progresses, element_length)

    if placement == "lane_center":
        lane_index = int(placement_record["lane_index"])
        if lane_index == 0:
            return np.full(shape=local_progresses.shape, fill_value=offset, dtype=np.float32)

        side = "left" if lane_index > 0 else "right"
        sign = 1.0 if lane_index > 0 else -1.0
        lane_position = abs(lane_index)
        widths_matrix = _lane_width_matrix(metadata, side, element_fractions)
        if lane_position > widths_matrix.shape[1]:
            raise ValueError("Lane " + str(lane_index) + " does not exist at this progress.")
        inner_offsets = np.sum(widths_matrix[:, :lane_position - 1], axis=1)
        lane_widths = widths_matrix[:, lane_position - 1]
        return (sign * (inner_offsets + 0.5 * lane_widths) + offset).astype(np.float32)

    if placement == "lane_line":
        signed_line_index = int(placement_record["lane_line_index"])
        if signed_line_index == 0:
            return np.full(shape=local_progresses.shape, fill_value=offset, dtype=np.float32)

        lane_side = "left" if signed_line_index > 0 else "right"
        sign = 1.0 if signed_line_index > 0 else -1.0
        line_position = abs(signed_line_index)
        widths_matrix = _lane_width_matrix(metadata, lane_side, element_fractions)
        if line_position > widths_matrix.shape[1]:
            raise ValueError("Lane line " + str(signed_line_index) + " does not exist at this progress.")
        return (sign * np.sum(widths_matrix[:, :line_position], axis=1) + offset).astype(np.float32)

    if placement == "road_edge":
        side = placement_record["side"]
        sign = 1.0 if side == "left" else -1.0
        widths_matrix = _lane_width_matrix(metadata, side, element_fractions)
        lane_outer_offsets = np.sum(widths_matrix, axis=1)
        edge_band_widths = _edge_band_width_matrix(metadata, side, element_fractions)
        edge_outer_offsets = lane_outer_offsets + np.sum(edge_band_widths, axis=1)
        return (sign * edge_outer_offsets + offset).astype(np.float32)

    raise ValueError("Unsupported cone placement: " + str(placement))


def cone_offset_at_progress(road, cone, progress):
    placement_record = cone["placement"]
    placement = placement_record["mode"]
    offset = float(placement_record["lateral_offset_from_anchor_m"])
    if placement == "reference_line":
        return offset
    if placement == "lane_center":
        return road.get_lane_center_offset_at_progress(
            progress,
            int(placement_record["lane_index"]),
            require_active=False,
        ) + offset
    if placement == "lane_line":
        signed_line_index = int(placement_record["lane_line_index"])
        try:
            anchor = road.get_lane_line_offset_at_progress(progress, signed_line_index)
        except ValueError:
            if abs(signed_line_index) != 1:
                raise
            bounds = road.get_reference_lane_bounds_at_progress(progress)
            anchor = bounds["left_bound_m"] if signed_line_index > 0 else bounds["right_bound_m"]
        return anchor + offset
    if placement == "road_edge":
        side = placement_record["side"]
        cross_section = road.get_cross_section_at_progress(progress)
        if len(cross_section["edge_bands"][side]) > 0:
            return cross_section["edge_bands"][side][-1]["outer_offset_m"] + offset
        if not cross_section["lanes"]:
            try:
                bounds = road.get_reference_lane_bounds_at_progress(progress)
            except ValueError:
                return offset
            anchor = bounds["left_bound_m"] if side == "left" else bounds["right_bound_m"]
            return anchor + offset
        if side == "left":
            return sum(cross_section["lane_widths"]["left"]) + offset
        return -sum(cross_section["lane_widths"]["right"]) + offset
    raise ValueError("Unsupported cone placement: " + str(placement))


def get_cone_points_and_arrays_from_spec(
    road,
    lane_metadata,
    element_lengths,
    element_ends,
    rng=None,
    source_element_to_private_segment_indices=None,
):
    """
    Return cone points and cached arrays generated from the lane-aware road
    specification.
    """
    if rng is None:
        rng = np.random.default_rng(0)

    cone_points = []
    p_cones, cone_color = get_cone_arrays_from_spec(
        road,
        lane_metadata,
        element_lengths,
        element_ends,
        rng=rng,
        cone_points=cone_points,
        source_element_to_private_segment_indices=(
            source_element_to_private_segment_indices
        ),
    )
    return cone_points, p_cones, cone_color


def get_cone_arrays_from_spec(
    road,
    lane_metadata,
    element_lengths,
    element_ends,
    rng=None,
    cone_points=None,
    source_element_to_private_segment_indices=None,
):
    """
    Return cached cone coordinate/color arrays generated from the road spec.

    When cone_points is supplied, it is filled with the dictionary records used
    by rendering/debug helpers. The environment hot path leaves it as None and
    avoids that reset-time Python-object construction.
    """
    if rng is None:
        rng = np.random.default_rng(0)

    cone_point_arrays = []
    cone_color_arrays = []
    for element_idx, metadata in enumerate(lane_metadata):
        if source_element_to_private_segment_indices is None:
            private_indices = np.asarray([element_idx], dtype=np.int32)
        else:
            private_indices = np.asarray(
                source_element_to_private_segment_indices[element_idx],
                dtype=np.int32,
            )
        first_private_index = int(private_indices[0])
        last_private_index = int(private_indices[-1])
        element_start = float(
            element_ends[first_private_index] - element_lengths[first_private_index]
        )
        element_length = float(element_ends[last_private_index] - element_start)

        for cone in metadata["cones"]:
            interval = cone["element_progress_interval"]
            local_start = float(interval["lower_bound_m"])
            local_end = element_length if interval["upper_bound_m"] is None else float(interval["upper_bound_m"])

            local_progresses = sample_cone_local_progresses(cone, local_start, local_end, rng)
            if local_progresses.size == 0:
                continue
            progress_values = (element_start + local_progresses).astype(np.float32)
            lateral_offsets = cone_offsets_at_progresses_for_element(
                road,
                cone,
                local_progresses,
                metadata,
                element_length,
            )
            coords = road.convert_progression_and_lateral_offsets_to_coordinates(
                progress_values,
                lateral_offsets,
            )
            cone_color_id = cone_color_to_id(cone.get("color", "orange"))
            cone_point_arrays.append(np.asarray(coords, dtype=np.float32).reshape(-1, 2))
            cone_color_arrays.append(
                np.full(shape=(coords.shape[0],), fill_value=cone_color_id, dtype=np.int32)
            )

            if cone_points is not None:
                for local_progress, progress, lateral_offset, coord in zip(local_progresses, progress_values, lateral_offsets, coords):
                    cone_points.append({
                        "px": float(coord[0]),
                        "py": float(coord[1]),
                        "progress_m": float(progress),
                        "local_progress_m": float(local_progress),
                        "offset_m": float(lateral_offset),
                        "color": cone.get("color", "orange"),
                        "radius_m": float(cone.get("radius_m", 0.08)),
                        "placement": dict(cone["placement"]),
                    })

    if len(cone_point_arrays) == 0:
        return np.empty((0, 2), dtype=np.float32), np.empty((0,), dtype=np.int32)

    return (
        np.concatenate(cone_point_arrays, axis=0).astype(np.float32, copy=False),
        np.concatenate(cone_color_arrays, axis=0).astype(np.int32, copy=False),
    )


def get_cone_points_from_spec(
    road,
    lane_metadata,
    element_lengths,
    element_ends,
    rng=None,
    source_element_to_private_segment_indices=None,
):
    cone_points, _, _ = get_cone_points_and_arrays_from_spec(
        road,
        lane_metadata,
        element_lengths,
        element_ends,
        rng=rng,
        source_element_to_private_segment_indices=(
            source_element_to_private_segment_indices
        ),
    )
    return cone_points


def get_cone_count_upper_bound_from_spec(
    lane_metadata,
    element_lengths,
    source_element_to_private_segment_indices=None,
):
    max_count = 0
    for element_idx, metadata in enumerate(lane_metadata):
        if source_element_to_private_segment_indices is None:
            private_indices = np.asarray([element_idx], dtype=np.int32)
        else:
            private_indices = np.asarray(
                source_element_to_private_segment_indices[element_idx],
                dtype=np.int32,
            )
        element_length = float(np.sum(element_lengths[private_indices]))
        for cone in metadata["cones"]:
            interval = cone["element_progress_interval"]
            local_start = float(interval["lower_bound_m"])
            local_end = element_length if interval["upper_bound_m"] is None else float(interval["upper_bound_m"])
            min_spacing = max(float(cone["inter_cone_spacing"]["lower_bound_m"]), MIN_CONE_SPACING_M)
            max_count += int(np.floor((local_end - local_start) / min_spacing + 1e-9)) + 1
    return int(max_count)


def cone_info_from_point_arrays_at_given_pose_and_fov(
    p_cones,
    cone_color,
    px,
    py,
    theta,
    fov_horizontal_degrees=80.0,
    body_x_upper_bound=4.0,
    max_results=None,
    radius_m=None,
):
    p_cones = np.asarray(p_cones, dtype=np.float32)
    if p_cones.size == 0:
        p_cones = np.empty((0, 2), dtype=np.float32)
    else:
        p_cones = p_cones.reshape((-1, 2))

    cone_color = np.asarray(cone_color, dtype=np.int32).reshape(-1)
    if cone_color.shape[0] != p_cones.shape[0]:
        raise ValueError("cone_color must have one entry per cone point.")
    if radius_m is not None:
        radius_m = np.asarray(radius_m, dtype=np.float64).reshape(-1)
        if radius_m.shape[0] != p_cones.shape[0]:
            raise ValueError("radius_m must have one entry per cone point.")

    if p_cones.shape[0] == 0:
        result = {
            "num_cones": 0,
            "px": np.empty((0,), dtype=np.float32),
            "py": np.empty((0,), dtype=np.float32),
            "px_in_body_frame": np.empty((0,), dtype=np.float32),
            "py_in_body_frame": np.empty((0,), dtype=np.float32),
            "color": np.empty((0,), dtype=np.int32),
        }
        if radius_m is not None:
            result["radius_m"] = np.empty((0,), dtype=np.float64)
        return result

    if max_results is not None:
        max_results = int(max_results)
        if max_results <= 0:
            raise ValueError("max_results must be a positive integer or None.")

    cos_theta = np.float32(np.cos(theta))
    sin_theta = np.float32(np.sin(theta))
    dx = p_cones[:, 0] - np.float32(px)
    dy = p_cones[:, 1] - np.float32(py)
    p_cones_body_x = cos_theta * dx + sin_theta * dy
    p_cones_body_y = -sin_theta * dx + cos_theta * dy

    half_fov = 0.5 * fov_horizontal_degrees * (np.pi / 180.0)
    if half_fov >= 0.5 * np.pi - 1e-7:
        cones_check = np.logical_and(
            np.greater_equal(p_cones_body_x, 0.0),
            np.less_equal(p_cones_body_x, body_x_upper_bound),
        )
    else:
        half_width_at_cone = np.float32(np.tan(half_fov)) * p_cones_body_x
        cones_check = np.logical_and.reduce((
            np.greater_equal(p_cones_body_x, 0.0),
            np.less_equal(p_cones_body_x, body_x_upper_bound),
            np.less_equal(np.abs(p_cones_body_y), half_width_at_cone),
        ))

    p_cones = p_cones[cones_check]
    cone_color = cone_color[cones_check]
    if radius_m is not None:
        radius_m = radius_m[cones_check]
    p_cones_body_x = p_cones_body_x[cones_check]
    p_cones_body_y = p_cones_body_y[cones_check]

    distance_squared = p_cones_body_x * p_cones_body_x + p_cones_body_y * p_cones_body_y
    if max_results is not None and distance_squared.shape[0] > max_results:
        nearest = np.argpartition(distance_squared, max_results - 1)[:max_results]
        order = nearest[np.argsort(distance_squared[nearest], kind="stable")]
    else:
        order = np.argsort(distance_squared, kind="stable")

    p_cones = p_cones[order]
    p_cones_body_x = p_cones_body_x[order]
    p_cones_body_y = p_cones_body_y[order]
    cone_color = cone_color[order]
    if radius_m is not None:
        radius_m = radius_m[order]

    result = {
        "num_cones": p_cones.shape[0],
        "px": p_cones[:, 0],
        "py": p_cones[:, 1],
        "px_in_body_frame": p_cones_body_x,
        "py_in_body_frame": p_cones_body_y,
        "color": cone_color,
    }
    if radius_m is not None:
        result["radius_m"] = radius_m
    return result


def cone_info_for_cone_points_at_given_pose_and_fov(
    cone_points,
    px,
    py,
    theta,
    fov_horizontal_degrees=80.0,
    body_x_upper_bound=4.0,
    max_results=None,
):
    p_cones, cone_color = cone_point_arrays_from_cone_points(cone_points)
    radius_m = np.asarray([point["radius_m"] for point in cone_points], dtype=np.float64)

    return cone_info_from_point_arrays_at_given_pose_and_fov(
        p_cones,
        cone_color,
        px=px,
        py=py,
        theta=theta,
        fov_horizontal_degrees=fov_horizontal_degrees,
        body_x_upper_bound=body_x_upper_bound,
        max_results=max_results,
        radius_m=radius_m,
    )


def road_owned_cone_info_at_given_pose_and_fov(
    road,
    lane_metadata,
    element_lengths,
    element_ends,
    px,
    py,
    theta,
    fov_horizontal_degrees=80.0,
    body_x_upper_bound=4.0,
    rng=None,
    max_results=None,
    source_element_to_private_segment_indices=None,
):
    cone_points, p_cones, cone_color = get_cone_points_and_arrays_from_spec(
        road,
        lane_metadata,
        element_lengths,
        element_ends,
        rng=rng,
        source_element_to_private_segment_indices=(
            source_element_to_private_segment_indices
        ),
    )
    return cone_info_from_point_arrays_at_given_pose_and_fov(
        p_cones,
        cone_color,
        px=px,
        py=py,
        theta=theta,
        fov_horizontal_degrees=fov_horizontal_degrees,
        body_x_upper_bound=body_x_upper_bound,
        max_results=max_results,
        radius_m=np.asarray([point["radius_m"] for point in cone_points], dtype=np.float64),
    )
