"""Lane and road cross-section geometry helpers."""

import copy

import numpy as np

from dreamgym.envs.road_core import schema_utils
from dreamgym.envs.road_core import utils as road_utils


def progress_context_at(progress, element_lengths, element_end_progresses):
    return progress_contexts_at([progress], element_lengths, element_end_progresses)[0]


def progress_context_arrays_at(
    progress_values,
    element_lengths,
    element_end_progresses,
    *,
    output_dtype=np.float32,
    element_indices=None,
    element_indices_are_trusted=False,
):
    if element_end_progresses.shape[0] == 0:
        raise ValueError("Road has no elements.")

    progress_values = np.asarray(progress_values, dtype=output_dtype).reshape(-1)
    total_length = float(element_end_progresses[-1])
    clamped_progresses = np.clip(progress_values, 0.0, total_length)
    if element_indices is None:
        if element_indices_are_trusted:
            raise ValueError(
                "element_indices_are_trusted=True requires element_indices."
            )
        element_idxs = np.searchsorted(
            element_end_progresses,
            clamped_progresses,
            side="left",
            sorter=None,
        )
        element_idxs = np.minimum(
            element_idxs,
            element_end_progresses.shape[0] - 1,
        ).astype(np.int32)
    else:
        if not element_indices_are_trusted:
            raise ValueError(
                "Supplied element_indices require element_indices_are_trusted=True."
            )
        supplied_element_idxs = np.asarray(element_indices)
        if supplied_element_idxs.dtype.kind not in "iu":
            raise TypeError("element_indices must have an integer dtype.")
        supplied_element_idxs = supplied_element_idxs.reshape(-1)
        if supplied_element_idxs.shape != progress_values.shape:
            raise ValueError(
                "element_indices must have the same shape as progress_values."
            )
        if np.any(
            (supplied_element_idxs < 0)
            | (supplied_element_idxs >= element_end_progresses.shape[0])
        ):
            raise ValueError("element_indices lie outside the Road element range.")
        element_idxs = supplied_element_idxs.astype(np.int32, copy=False)

    element_start_progresses = (
        np.asarray(element_end_progresses[element_idxs], dtype=output_dtype)
        - np.asarray(element_lengths[element_idxs], dtype=output_dtype)
    )
    element_lengths_at_progresses = np.asarray(
        element_lengths[element_idxs],
        dtype=output_dtype,
    )
    element_progresses = np.clip(clamped_progresses - element_start_progresses, 0.0, element_lengths_at_progresses)
    element_fractions = np.zeros_like(element_progresses, dtype=output_dtype)
    positive_lengths = element_lengths_at_progresses > 0.0
    element_fractions[positive_lengths] = element_progresses[positive_lengths] / element_lengths_at_progresses[positive_lengths]
    element_fractions = np.clip(element_fractions, 0.0, 1.0)

    return {
        "progress_values": progress_values,
        "clamped_progresses": clamped_progresses,
        "element_indices": element_idxs,
        "element_start_progresses": element_start_progresses.astype(output_dtype),
        "element_progresses": element_progresses.astype(output_dtype),
        "element_lengths": element_lengths_at_progresses.astype(output_dtype),
        "element_fractions": element_fractions.astype(output_dtype),
    }


def progress_contexts_at(
    progress_values,
    element_lengths,
    element_end_progresses,
    *,
    output_dtype=np.float32,
    element_indices=None,
    element_indices_are_trusted=False,
):
    context_arrays = progress_context_arrays_at(
        progress_values,
        element_lengths,
        element_end_progresses,
        output_dtype=output_dtype,
        element_indices=element_indices,
        element_indices_are_trusted=element_indices_are_trusted,
    )

    contexts = []
    for i_progress in range(context_arrays["progress_values"].shape[0]):
        contexts.append({
            "progress_m": float(context_arrays["progress_values"][i_progress]),
            "clamped_progress_m": float(context_arrays["clamped_progresses"][i_progress]),
            "element_index": int(context_arrays["element_indices"][i_progress]),
            "element_start_progress_m": float(context_arrays["element_start_progresses"][i_progress]),
            "element_progress_m": float(context_arrays["element_progresses"][i_progress]),
            "element_length_m": float(context_arrays["element_lengths"][i_progress]),
            "element_fraction": float(context_arrays["element_fractions"][i_progress]),
        })
    return contexts


def lane_metadata_and_context_at(progress, lane_metadata, element_lengths, element_end_progresses):
    context = progress_context_at(progress, element_lengths, element_end_progresses)
    element_idx = context["element_index"]
    if element_idx >= len(lane_metadata):
        raise ValueError("Lane metadata is missing for road element " + str(element_idx) + ".")
    return lane_metadata[element_idx], context


def lane_samples_at_progresses(
    progress_values,
    lane_metadata,
    element_lengths,
    element_end_progresses,
    *,
    output_dtype=np.float32,
    element_indices=None,
    element_indices_are_trusted=False,
):
    contexts = progress_contexts_at(
        progress_values,
        element_lengths,
        element_end_progresses,
        output_dtype=output_dtype,
        element_indices=element_indices,
        element_indices_are_trusted=element_indices_are_trusted,
    )
    samples = []
    for context in contexts:
        element_idx = context["element_index"]
        if element_idx >= len(lane_metadata):
            raise ValueError("Lane metadata is missing for road element " + str(element_idx) + ".")
        metadata = lane_metadata[element_idx]
        widths = lane_widths_for_metadata_at_fraction(metadata, context["element_fraction"])
        samples.append({
            "metadata": metadata,
            "context": context,
            "widths": widths,
        })
    return samples


def lane_widths_for_metadata_at_fraction(metadata, progress_fraction):
    interpolation = metadata["lane_width_interpolation"]
    return {
        "left": road_utils.interpolate_list(
            metadata["left_lane_widths_start"],
            metadata["left_lane_widths_end"],
            progress_fraction,
            interpolation,
        ),
        "right": road_utils.interpolate_list(
            metadata["right_lane_widths_start"],
            metadata["right_lane_widths_end"],
            progress_fraction,
            interpolation,
        ),
    }


def lane_width_matrix_for_metadata_at_fractions(metadata, side, progress_fractions):
    start_widths = np.array(metadata[side + "_lane_widths_start"], dtype=np.float32).reshape(1, -1)
    end_widths = np.array(metadata[side + "_lane_widths_end"], dtype=np.float32).reshape(1, -1)
    progress_fractions = np.array(progress_fractions, dtype=np.float32).reshape(-1)
    if start_widths.shape[1] == 0:
        return np.zeros((progress_fractions.shape[0], 0), dtype=np.float32)
    interpolation = metadata["lane_width_interpolation"]
    alpha = road_utils.interpolation_alpha_array(progress_fractions, interpolation).reshape(-1, 1)
    return start_widths + (end_widths - start_widths) * alpha


def lane_center_offset_from_widths(widths, lane_index, min_active_lane_width_m, require_active=True):
    lane_index = int(lane_index)
    if lane_index == 0:
        return 0.0

    require_lane_index(lane_index, widths, min_active_lane_width_m, require_active)

    if lane_index > 0:
        lane_position = lane_index
        return (
            sum(widths["left"][:lane_position - 1]) +
            0.5 * widths["left"][lane_position - 1]
        )

    lane_position = abs(lane_index)
    return -(
        sum(widths["right"][:lane_position - 1]) +
        0.5 * widths["right"][lane_position - 1]
    )


def lane_line_offset_from_widths(widths, lane_line_index):
    lane_line_index = int(lane_line_index)
    if lane_line_index == 0:
        return 0.0

    if lane_line_index > 0:
        if lane_line_index > len(widths["left"]):
            raise ValueError("Lane line +" + str(lane_line_index) + " does not exist at this progress.")
        return sum(widths["left"][:lane_line_index])

    lane_line_position = abs(lane_line_index)
    if lane_line_position > len(widths["right"]):
        raise ValueError("Lane line " + str(lane_line_index) + " does not exist at this progress.")
    return -sum(widths["right"][:lane_line_position])


def lane_line_offsets_from_widths(widths):
    left_offsets = []
    offset = 0.0
    for width in widths["left"]:
        offset += float(width)
        left_offsets.append(offset)

    right_offsets = []
    offset = 0.0
    for width in widths["right"]:
        offset -= float(width)
        right_offsets.append(offset)

    indexed = {"0": 0.0}
    for idx, offset in enumerate(left_offsets, start=1):
        indexed[schema_utils.lane_line_key(idx)] = offset
    for idx, offset in enumerate(right_offsets, start=1):
        indexed[schema_utils.lane_line_key(-idx)] = offset

    return {
        "reference_line": 0.0,
        "left_lane_lines": left_offsets,
        "right_lane_lines": right_offsets,
        "indexed": indexed,
    }


def lane_units_to_meter_offset_from_widths(widths, lane_units, allow_outside=False):
    lane_units = float(lane_units)
    if lane_units == 0.0:
        return 0.0

    side_widths = widths["left"] if lane_units > 0.0 else widths["right"]
    sign = 1.0 if lane_units > 0.0 else -1.0
    lane_position = abs(lane_units)

    if len(side_widths) == 0:
        raise ValueError("Cannot convert lane units because this side has no lanes at this progress.")
    if (lane_position > len(side_widths)) and not allow_outside:
        raise ValueError("Lane-unit target lies outside the specified lanes at this progress.")

    full_lanes = int(np.floor(lane_position))
    fractional_lane = lane_position - full_lanes

    if full_lanes >= len(side_widths):
        if np.isclose(fractional_lane, 0.0):
            return sign * sum(side_widths)
        extra_lane_units = lane_position - len(side_widths)
        return sign * (sum(side_widths) + extra_lane_units * side_widths[-1])

    return sign * (sum(side_widths[:full_lanes]) + fractional_lane * side_widths[full_lanes])


def lane_center_offsets_at_progresses_vectorized(
    progress_values,
    lane_index,
    lane_metadata,
    element_lengths,
    element_end_progresses,
    min_active_lane_width_m,
    require_active=True,
):
    progress_values = np.array(progress_values, dtype=np.float32).reshape(-1)
    lane_index = int(lane_index)
    if lane_index == 0:
        return np.zeros(shape=progress_values.shape, dtype=np.float32)
    if progress_values.size == 0:
        return np.array([], dtype=np.float32)

    context_arrays = progress_context_arrays_at(progress_values, element_lengths, element_end_progresses)
    offsets = np.empty(shape=progress_values.shape, dtype=np.float32)
    side = "left" if lane_index > 0 else "right"
    sign = 1.0 if lane_index > 0 else -1.0
    lane_position = abs(lane_index)

    for element_idx in np.unique(context_arrays["element_indices"]):
        element_mask = context_arrays["element_indices"] == element_idx
        metadata = lane_metadata[int(element_idx)]
        lane_count = len(metadata[side + "_lane_widths_start"])
        if lane_position > lane_count:
            raise ValueError("Lane " + schema_utils.lane_key(lane_index) + " does not exist at this progress.")

        widths_matrix = lane_width_matrix_for_metadata_at_fractions(
            metadata,
            side,
            context_arrays["element_fractions"][element_mask],
        )
        lane_widths = widths_matrix[:, lane_position - 1]
        if require_active and np.any(lane_widths < min_active_lane_width_m):
            raise ValueError(
                "Lane " + schema_utils.lane_key(lane_index) +
                " is narrower than min_active_lane_width_m at this progress."
            )
        inner_offsets = np.sum(widths_matrix[:, :lane_position - 1], axis=1)
        offsets[element_mask] = sign * (inner_offsets + 0.5 * lane_widths)

    return offsets


def lane_units_to_meter_offsets_at_progresses_vectorized(
    progress_values,
    lane_units,
    lane_metadata,
    element_lengths,
    element_end_progresses,
    allow_outside=False,
):
    progress_values = np.array(progress_values, dtype=np.float32).reshape(-1)
    lane_units = float(lane_units)
    if lane_units == 0.0:
        return np.zeros(shape=progress_values.shape, dtype=np.float32)
    if progress_values.size == 0:
        return np.array([], dtype=np.float32)

    context_arrays = progress_context_arrays_at(progress_values, element_lengths, element_end_progresses)
    offsets = np.empty(shape=progress_values.shape, dtype=np.float32)
    side = "left" if lane_units > 0.0 else "right"
    sign = 1.0 if lane_units > 0.0 else -1.0
    lane_position = abs(lane_units)
    full_lanes = int(np.floor(lane_position))
    fractional_lane = lane_position - full_lanes

    for element_idx in np.unique(context_arrays["element_indices"]):
        element_mask = context_arrays["element_indices"] == element_idx
        metadata = lane_metadata[int(element_idx)]
        side_widths_start = metadata[side + "_lane_widths_start"]
        lane_count = len(side_widths_start)
        if lane_count == 0:
            raise ValueError("Cannot convert lane units because this side has no lanes at this progress.")
        if (lane_position > lane_count) and not allow_outside:
            raise ValueError("Lane-unit target lies outside the specified lanes at this progress.")

        widths_matrix = lane_width_matrix_for_metadata_at_fractions(
            metadata,
            side,
            context_arrays["element_fractions"][element_mask],
        )
        if full_lanes >= lane_count:
            if np.isclose(fractional_lane, 0.0):
                unsigned_offsets = np.sum(widths_matrix, axis=1)
            else:
                extra_lane_units = lane_position - lane_count
                unsigned_offsets = np.sum(widths_matrix, axis=1) + extra_lane_units * widths_matrix[:, -1]
        else:
            unsigned_offsets = (
                np.sum(widths_matrix[:, :full_lanes], axis=1) +
                fractional_lane * widths_matrix[:, full_lanes]
            )
        offsets[element_mask] = sign * unsigned_offsets

    return offsets


def edge_band_width_at_fraction(band, progress_fraction, interpolation):
    return road_utils.interpolate_scalar(
        band.get("width_start", 0.0),
        band.get("width_end", band.get("width_start", 0.0)),
        progress_fraction,
        interpolation,
    )


def require_lane_index(lane_idx, widths, min_active_lane_width_m, require_active):
    lane_idx = int(lane_idx)
    if lane_idx == 0:
        return 0.0

    side_widths = widths["left"] if lane_idx > 0 else widths["right"]
    lane_position = abs(lane_idx)
    if lane_position > len(side_widths):
        raise ValueError("Lane " + schema_utils.lane_key(lane_idx) + " does not exist at this progress.")

    lane_width = float(side_widths[lane_position - 1])
    if require_active and (lane_width < min_active_lane_width_m):
        raise ValueError(
            "Lane " + schema_utils.lane_key(lane_idx) +
            " is narrower than min_active_lane_width_m at this progress."
        )
    return lane_width


def lane_dicts_at_progress(metadata, widths, min_active_lane_width_m):
    lanes = []
    public_lanes = metadata["lanes"]
    if public_lanes["reference_line_role"] == "lane_center":
        return lanes
    else:
        left_records = public_lanes["left"]
        right_records = public_lanes["right"]

    inner_offset = 0.0
    for lane_idx, width in enumerate(widths["left"], start=1):
        outer_offset = inner_offset + float(width)
        lanes.append({
            "lane_index": lane_idx,
            "side": "left",
            "width_m": float(width),
            "center_offset_m": 0.5 * (inner_offset + outer_offset),
            "inner_line_offset_m": inner_offset,
            "outer_line_offset_m": outer_offset,
            "lower_offset_m": min(inner_offset, outer_offset),
            "upper_offset_m": max(inner_offset, outer_offset),
            "is_active": float(width) >= min_active_lane_width_m,
            "travel_direction": left_records[lane_idx - 1]["travel_direction"],
            "surface": metadata["left_lane_surfaces"][lane_idx - 1],
            "is_available": bool(metadata["left_lane_available"][lane_idx - 1]),
            "is_drivable": bool(metadata["left_lane_drivable"][lane_idx - 1]),
        })
        inner_offset = outer_offset

    inner_offset = 0.0
    for lane_position, width in enumerate(widths["right"], start=1):
        outer_offset = inner_offset - float(width)
        lanes.append({
            "lane_index": -lane_position,
            "side": "right",
            "width_m": float(width),
            "center_offset_m": 0.5 * (inner_offset + outer_offset),
            "inner_line_offset_m": inner_offset,
            "outer_line_offset_m": outer_offset,
            "lower_offset_m": min(inner_offset, outer_offset),
            "upper_offset_m": max(inner_offset, outer_offset),
            "is_active": float(width) >= min_active_lane_width_m,
            "travel_direction": right_records[lane_position - 1]["travel_direction"],
            "surface": metadata["right_lane_surfaces"][lane_position - 1],
            "is_available": bool(metadata["right_lane_available"][lane_position - 1]),
            "is_drivable": bool(metadata["right_lane_drivable"][lane_position - 1]),
        })
        inner_offset = outer_offset

    return lanes


def lane_line_dicts_at_progress(metadata, widths):
    lane_lines = [{
        "lane_line_index": 0,
        "side": "reference",
        "offset_m": 0.0,
        "marking": copy.deepcopy(metadata["public_lane_markings"]["lane_lines"]["0"]),
    }]
    if metadata["lanes"]["reference_line_role"] == "lane_center":
        return lane_lines

    offset = 0.0
    for line_idx, width in enumerate(widths["left"], start=1):
        offset += float(width)
        lane_lines.append({
            "lane_line_index": line_idx,
            "side": "left",
            "offset_m": offset,
            "marking": copy.deepcopy(metadata["public_lane_markings"]["lane_lines"].get("+" + str(line_idx))),
        })

    offset = 0.0
    for line_position, width in enumerate(widths["right"], start=1):
        offset -= float(width)
        lane_lines.append({
            "lane_line_index": -line_position,
            "side": "right",
            "offset_m": offset,
            "marking": copy.deepcopy(metadata["public_lane_markings"]["lane_lines"].get("-" + str(line_position))),
        })

    return lane_lines


def edge_band_dicts_at_progress(metadata, widths, progress_fraction):
    interpolation = metadata["lane_width_interpolation"]
    edge_bands = {"left": [], "right": []}

    inner_offset = sum(float(width) for width in widths["left"])
    for band_idx, band in enumerate(metadata["left_edge_bands"]):
        width = edge_band_width_at_fraction(band, progress_fraction, interpolation)
        outer_offset = inner_offset + width
        edge_bands["left"].append({
            "band_index": band_idx,
            "side": "left",
            "name": band["name"],
            "width_m": width,
            "center_offset_m": 0.5 * (inner_offset + outer_offset),
            "inner_offset_m": inner_offset,
            "outer_offset_m": outer_offset,
            "lower_offset_m": min(inner_offset, outer_offset),
            "upper_offset_m": max(inner_offset, outer_offset),
            "surface": band["surface"],
            "is_available": bool(band["available"]),
            "is_drivable": bool(band["drivable"]),
        })
        inner_offset = outer_offset

    inner_offset = -sum(float(width) for width in widths["right"])
    for band_idx, band in enumerate(metadata["right_edge_bands"]):
        width = edge_band_width_at_fraction(band, progress_fraction, interpolation)
        outer_offset = inner_offset - width
        edge_bands["right"].append({
            "band_index": band_idx,
            "side": "right",
            "name": band["name"],
            "width_m": width,
            "center_offset_m": 0.5 * (inner_offset + outer_offset),
            "inner_offset_m": inner_offset,
            "outer_offset_m": outer_offset,
            "lower_offset_m": min(inner_offset, outer_offset),
            "upper_offset_m": max(inner_offset, outer_offset),
            "surface": band["surface"],
            "is_available": bool(band["available"]),
            "is_drivable": bool(band["drivable"]),
        })
        inner_offset = outer_offset

    return edge_bands


def cross_section_from_lane_sample(sample, min_active_lane_width_m):
    metadata = sample["metadata"]
    context = sample["context"]
    widths = sample["widths"]
    lane_lines = lane_line_dicts_at_progress(metadata, widths)
    edge_bands = edge_band_dicts_at_progress(metadata, widths, context["element_fraction"])
    public_widths = (
        {"left": [], "right": []}
        if metadata["lanes"]["reference_line_role"] == "lane_center"
        else copy.deepcopy(widths)
    )
    public_line_offsets = (
        {
            "reference_line": 0.0,
            "left_lane_lines": [],
            "right_lane_lines": [],
            "indexed": {"0": 0.0},
        }
        if metadata["lanes"]["reference_line_role"] == "lane_center"
        else lane_line_offsets_from_widths(widths)
    )
    return {
        "progress_m": context["progress_m"],
        "clamped_progress_m": context["clamped_progress_m"],
        "element_index": context["element_index"],
        "element_fraction": context["element_fraction"],
        "cross_section_width_interpolation": metadata["cross_section_width_interpolation"],
        "lane_widths": public_widths,
        "lanes": lane_dicts_at_progress(metadata, widths, min_active_lane_width_m),
        "lane_lines": lane_lines,
        "lane_line_offsets": public_line_offsets,
        "edge_bands": edge_bands,
    }


def require_reference_lane_center_metadata(metadata):
    if metadata.get("reference_line_role") != "lane_center":
        raise ValueError(
            "Reference-lane bounds are only available when "
            "reference_line_role='lane_center'."
        )
    if (
        len(metadata["left_lane_widths_start"]) < 1 or
        len(metadata["right_lane_widths_start"]) < 1
    ):
        raise ValueError("Centered reference-lane metadata is missing its side widths.")


def reference_lane_bounds_from_lane_sample(sample):
    metadata = sample["metadata"]
    context = sample["context"]
    widths = sample["widths"]
    require_reference_lane_center_metadata(metadata)
    left_bound_m = lane_line_offset_from_widths(widths, 1)
    right_bound_m = lane_line_offset_from_widths(widths, -1)
    return {
        "progress_m": context["progress_m"],
        "clamped_progress_m": context["clamped_progress_m"],
        "element_index": context["element_index"],
        "right_bound_m": float(right_bound_m),
        "left_bound_m": float(left_bound_m),
        "width_m": float(left_bound_m - right_bound_m),
        "center_offset_m": 0.0,
    }


def reference_lane_bounds_at_progresses(
    progress_values,
    lane_metadata,
    element_lengths,
    element_end_progresses,
):
    progress_values = np.asarray(progress_values, dtype=np.float32).reshape(-1)
    if progress_values.size == 0:
        return {
            "progress_m": np.empty((0,), dtype=np.float32),
            "clamped_progress_m": np.empty((0,), dtype=np.float32),
            "element_index": np.empty((0,), dtype=np.int32),
            "right_bound_m": np.empty((0,), dtype=np.float32),
            "left_bound_m": np.empty((0,), dtype=np.float32),
            "width_m": np.empty((0,), dtype=np.float32),
            "center_offset_m": np.empty((0,), dtype=np.float32),
        }

    context_arrays = progress_context_arrays_at(
        progress_values,
        element_lengths,
        element_end_progresses,
    )
    left_bounds = np.empty(shape=progress_values.shape, dtype=np.float32)
    right_bounds = np.empty(shape=progress_values.shape, dtype=np.float32)

    for element_idx in np.unique(context_arrays["element_indices"]):
        element_mask = context_arrays["element_indices"] == element_idx
        metadata = lane_metadata[int(element_idx)]
        require_reference_lane_center_metadata(metadata)

        left_widths = lane_width_matrix_for_metadata_at_fractions(
            metadata,
            "left",
            context_arrays["element_fractions"][element_mask],
        )
        right_widths = lane_width_matrix_for_metadata_at_fractions(
            metadata,
            "right",
            context_arrays["element_fractions"][element_mask],
        )
        left_bounds[element_mask] = left_widths[:, 0]
        right_bounds[element_mask] = -right_widths[:, 0]

    return {
        "progress_m": context_arrays["progress_values"].astype(np.float32, copy=False),
        "clamped_progress_m": context_arrays["clamped_progresses"].astype(np.float32, copy=False),
        "element_index": context_arrays["element_indices"].astype(np.int32, copy=False),
        "right_bound_m": right_bounds,
        "left_bound_m": left_bounds,
        "width_m": (left_bounds - right_bounds).astype(np.float32, copy=False),
        "center_offset_m": np.zeros(shape=progress_values.shape, dtype=np.float32),
    }


def lookup_lateral_region_in_cross_section(cross_section, lateral_offset_m, tolerance=1e-9):
    offset = float(lateral_offset_m)
    tolerance = abs(float(tolerance))

    for lane_line in cross_section["lane_lines"]:
        if abs(offset - lane_line["offset_m"]) <= tolerance:
            result = copy.deepcopy(lane_line)
            result["type"] = "lane_line"
            return result

    for lane in cross_section["lanes"]:
        if (offset > lane["lower_offset_m"] + tolerance) and (offset < lane["upper_offset_m"] - tolerance):
            result = copy.deepcopy(lane)
            result["type"] = "lane"
            return result

    for side in ("left", "right"):
        for band in cross_section["edge_bands"][side]:
            if (offset > band["lower_offset_m"] + tolerance) and (offset < band["upper_offset_m"] - tolerance):
                result = copy.deepcopy(band)
                result["type"] = "edge_band"
                return result

    return {
        "type": "outside",
        "offset_m": offset,
        "progress_m": cross_section["progress_m"],
        "clamped_progress_m": cross_section["clamped_progress_m"],
    }
