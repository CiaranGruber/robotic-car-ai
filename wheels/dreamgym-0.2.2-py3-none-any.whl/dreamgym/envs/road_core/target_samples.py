"""Target-line sampled geometry helpers."""

import math

import numpy as np

from dreamgym.envs.road_core import reference_geometry
from dreamgym.envs.road_core._target_config import _target_line_config_values


def _strict_parallel_curve_denominator(reference_curvatures, target_line_offsets):
    denominator = 1.0 - reference_curvatures * target_line_offsets
    if np.ndim(denominator) == 0:
        if denominator <= 0.0:
            raise ValueError("The parallel-curve denominator must be greater than zero.")
    elif np.any(denominator <= 0.0):
        raise ValueError("Every parallel-curve denominator must be greater than zero.")
    return denominator


def _config_geometry_kwargs(target_line_config):
    (
        target_line_offset_m,
        target_lane_index,
        target_lane_units,
        target_lane_require_active,
        target_lane_units_allow_outside,
    ) = _target_line_config_values(target_line_config)
    return {
        "target_line_offset_m": target_line_offset_m,
        "target_lane_index": target_lane_index,
        "target_lane_units": target_lane_units,
        "target_lane_require_active": target_lane_require_active,
        "target_lane_units_allow_outside": target_lane_units_allow_outside,
    }


def single_target_line_body_point_lookahead_for_config_if_available(
    geom,
    start_reference_progress,
    target_line_distance_query,
    body_px,
    body_py,
    body_cos_theta,
    body_sin_theta,
    target_line_config,
    *,
    include_curvature=False,
):
    return single_target_line_body_point_lookahead_if_available(
        geom,
        start_reference_progress,
        target_line_distance_query,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        include_curvature=include_curvature,
        **_config_geometry_kwargs(target_line_config),
    )


def constant_target_line_body_points_lookahead_for_config_if_available(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    body_px,
    body_py,
    body_cos_theta,
    body_sin_theta,
    target_line_config,
    *,
    include_curvatures=False,
):
    return constant_target_line_body_points_lookahead_if_available(
        geom,
        start_reference_progress,
        target_line_distance_queries,
        body_px,
        body_py,
        body_cos_theta,
        body_sin_theta,
        include_curvatures=include_curvatures,
        **_config_geometry_kwargs(target_line_config),
    )


def reference_line_sample_at_progress_scalar(geom, reference_progress, element_idx=None):
    return reference_geometry.reference_line_sample_at_progress_scalar(
        reference_progress,
        geom.c,
        geom.l,
        geom.phi,
        geom.is_straight,
        geom.start_points,
        geom.end_points,
        geom.start_angles,
        geom.end_angles,
        geom.l_total_at_end,
        element_idx=element_idx,
    )


def single_target_line_body_point_lookahead_if_available(
    geom,
    start_reference_progress,
    target_line_distance_query,
    body_px,
    body_py,
    body_cos_theta,
    body_sin_theta,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
    include_curvature=False,
):
    target_line_offset = 0.0
    reference_element_idx = None
    if target_lane_index is None and target_lane_units is None and float(target_line_offset_m) == 0.0:
        reference_progress = float(start_reference_progress) + float(target_line_distance_query)
    else:
        constant_offsets_by_element = geom.constant_target_offsets_by_element_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
        if (
            constant_offsets_by_element is None or
            not geom.constant_target_offsets_are_continuous_if_available(
                target_line_offset_m=target_line_offset_m,
                target_lane_index=target_lane_index,
                target_lane_units=target_lane_units,
                target_lane_require_active=target_lane_require_active,
                target_lane_units_allow_outside=target_lane_units_allow_outside,
            )
        ):
            return None

        constant_offset_cache_key = geom.constant_target_offsets_cache_key(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
        progress_and_element = geom.reference_progress_for_single_constant_target_distance(
            start_reference_progress,
            target_line_distance_query,
            constant_offsets_by_element,
            cache_key=constant_offset_cache_key,
        )
        if progress_and_element is None:
            return None
        reference_progress, reference_element_idx = progress_and_element
        target_line_offset = float(constant_offsets_by_element[0])

    reference_sample = geom.reference_line_sample_at_progress_scalar(
        reference_progress,
        element_idx=reference_element_idx,
    )
    reference_angle = reference_sample["angle"]
    target_px = reference_sample["px"] - target_line_offset * math.sin(reference_angle)
    target_py = reference_sample["py"] + target_line_offset * math.cos(reference_angle)

    target_dx = target_px - float(body_px)
    target_dy = target_py - float(body_py)
    body_point = np.array(
        [[
            body_cos_theta * target_dx + body_sin_theta * target_dy,
            -body_sin_theta * target_dx + body_cos_theta * target_dy,
        ]],
        dtype=np.float32,
    )

    result = {
        "body_points": body_point,
    }
    if include_curvature:
        reference_curvature = reference_sample["curvature"]
        denominator = _strict_parallel_curve_denominator(
            reference_curvature,
            target_line_offset,
        )
        target_line_curvature = reference_curvature / denominator
        result["curvatures"] = np.array([target_line_curvature], dtype=np.float32)
    return result


def constant_target_line_body_points_lookahead_if_available(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    body_px,
    body_py,
    body_cos_theta,
    body_sin_theta,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
    include_curvatures=False,
):
    target_line_distance_queries = np.asarray(target_line_distance_queries, dtype=np.float64).reshape(-1)
    if target_line_distance_queries.size == 0:
        result = {"body_points": np.empty((0, 2), dtype=np.float32)}
        if include_curvatures:
            result["curvatures"] = np.array([], dtype=np.float32)
        return result

    constant_offsets_by_element = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if (
        constant_offsets_by_element is None or
        not geom.constant_target_offsets_are_continuous_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    ):
        return None

    constant_offset_cache_key = geom.constant_target_offsets_cache_key(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    lookup = geom.constant_target_distance_lookup_for_offsets(
        constant_offsets_by_element,
        cache_key=constant_offset_cache_key,
    )
    if lookup is None:
        return None

    reference_boundaries = lookup["reference_boundaries"]
    target_distance_boundaries = lookup["target_distance_boundaries"]
    element_target_line_scales = lookup["element_target_line_scales"]
    start_target_distance = geom.target_distance_at_reference_progress_for_constant_offset(
        start_reference_progress,
        lookup,
    )
    query_target_distances = start_target_distance + target_line_distance_queries
    total_target_distance = float(target_distance_boundaries[-1])
    if np.any(query_target_distances > total_target_distance):
        return None
    query_target_distances = np.maximum(query_target_distances, 0.0)

    element_idxs = np.searchsorted(
        target_distance_boundaries[1:],
        query_target_distances,
        side="left",
    ).astype(np.int32)
    local_target_distances = query_target_distances - target_distance_boundaries[element_idxs]
    target_line_offset = float(constant_offsets_by_element[0])
    reference_curvatures = geom.c[element_idxs].astype(np.float64, copy=False)
    target_line_scales = _strict_parallel_curve_denominator(
        reference_curvatures,
        target_line_offset,
    )
    target_line_curvatures = reference_curvatures / target_line_scales

    start_angles = geom.start_angles[element_idxs].astype(np.float64, copy=False)
    sin_start_angles = np.sin(start_angles)
    cos_start_angles = np.cos(start_angles)
    target_start_x = geom.start_points[element_idxs, 0].astype(np.float64, copy=False) - target_line_offset * sin_start_angles
    target_start_y = geom.start_points[element_idxs, 1].astype(np.float64, copy=False) + target_line_offset * cos_start_angles

    target_x = np.empty(shape=query_target_distances.shape, dtype=np.float64)
    target_y = np.empty(shape=query_target_distances.shape, dtype=np.float64)
    straight_mask = geom.is_straight[element_idxs]
    if np.any(straight_mask):
        target_x[straight_mask] = (
            target_start_x[straight_mask] +
            local_target_distances[straight_mask] * cos_start_angles[straight_mask]
        )
        target_y[straight_mask] = (
            target_start_y[straight_mask] +
            local_target_distances[straight_mask] * sin_start_angles[straight_mask]
        )

    curved_mask = ~straight_mask
    if np.any(curved_mask):
        curved_curvatures = target_line_curvatures[curved_mask]
        curvature_signs = np.sign(curved_curvatures)
        progress_phi = local_target_distances[curved_mask] * np.abs(curved_curvatures)
        chord_angles = start_angles[curved_mask] + curvature_signs * 0.5 * progress_phi
        chord_lengths = 2.0 * (1.0 / np.abs(curved_curvatures)) * np.sin(0.5 * progress_phi)
        target_x[curved_mask] = target_start_x[curved_mask] + chord_lengths * np.cos(chord_angles)
        target_y[curved_mask] = target_start_y[curved_mask] + chord_lengths * np.sin(chord_angles)

    target_dx = target_x - float(body_px)
    target_dy = target_y - float(body_py)
    body_points = np.empty((target_line_distance_queries.size, 2), dtype=np.float32)
    body_points[:, 0] = body_cos_theta * target_dx + body_sin_theta * target_dy
    body_points[:, 1] = -body_sin_theta * target_dx + body_cos_theta * target_dy

    result = {
        "body_points": body_points,
    }
    if include_curvatures:
        result["curvatures"] = target_line_curvatures.astype(np.float32)
    return result


def element_indices_for_reference_progresses(geom, reference_progresses):
    return reference_geometry.element_indices_for_reference_progresses(
        reference_progresses,
        geom.l_total_at_end,
    )


def target_line_geometry_from_reference_samples(
    geom,
    reference_progresses,
    reference_samples,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
    include_offsets=True,
    include_points=True,
    include_body_points=False,
    body_frame_pose=None,
    include_angles=True,
    include_curvatures=True,
    include_speed_scale=True,
    output_dtype=np.float32,
):
    reference_progresses = np.asarray(
        reference_progresses,
        dtype=output_dtype,
    ).reshape(-1)
    if reference_progresses.size == 0:
        result = {}
        if include_offsets:
            result["offsets"] = np.array([], dtype=output_dtype)
        if include_points:
            result["points"] = np.empty((0, 2), dtype=output_dtype)
        if include_body_points:
            result["body_points"] = np.empty((0, 2), dtype=output_dtype)
        if include_angles:
            result["angles"] = np.array([], dtype=output_dtype)
        if include_curvatures:
            result["curvatures"] = np.array([], dtype=output_dtype)
        if include_speed_scale:
            result["speed_scale"] = np.array([], dtype=output_dtype)
        return result

    reference_points = (
        np.asarray(reference_samples["coordinates"], dtype=output_dtype).reshape((-1, 2))
        if (include_points or include_body_points) else None
    )
    reference_angles = (
        np.asarray(reference_samples["angles"], dtype=output_dtype).reshape(-1)
        if (include_points or include_body_points or include_angles) else None
    )
    reference_curvatures = (
        np.asarray(reference_samples["curvatures"], dtype=output_dtype).reshape(-1)
        if (include_curvatures or include_angles or include_speed_scale) else None
    )
    if include_body_points and body_frame_pose is None:
        raise ValueError("body_frame_pose must be provided when include_body_points=True.")
    if body_frame_pose is not None:
        body_px, body_py, body_cos_theta, body_sin_theta = body_frame_pose

    if target_lane_index is None and target_lane_units is None and float(target_line_offset_m) == 0.0:
        result = {}
        if include_offsets:
            result["offsets"] = np.zeros(shape=reference_progresses.shape, dtype=output_dtype)
        if include_points:
            result["points"] = reference_points
        if include_body_points:
            target_dx = reference_points[:, 0] - float(body_px)
            target_dy = reference_points[:, 1] - float(body_py)
            body_points = np.empty_like(reference_points, dtype=output_dtype)
            body_points[:, 0] = body_cos_theta * target_dx + body_sin_theta * target_dy
            body_points[:, 1] = -body_sin_theta * target_dx + body_cos_theta * target_dy
            result["body_points"] = body_points
        if include_angles:
            result["angles"] = reference_angles
        if include_curvatures:
            result["curvatures"] = reference_curvatures
        if include_speed_scale:
            result["speed_scale"] = np.ones(shape=reference_progresses.shape, dtype=output_dtype)
        return result

    constant_offsets_by_element = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if (
        constant_offsets_by_element is not None and
        geom.constant_target_offsets_are_continuous_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    ):
        target_line_offset = float(constant_offsets_by_element[0])
        result = {}
        if include_offsets:
            result["offsets"] = np.full(
                shape=reference_progresses.shape,
                fill_value=target_line_offset,
                dtype=output_dtype,
            )
        if include_points or include_body_points:
            sin_reference_angles = np.sin(reference_angles)
            cos_reference_angles = np.cos(reference_angles)
        if include_points:
            target_line_points = np.empty_like(reference_points, dtype=output_dtype)
            target_line_points[:, 0] = reference_points[:, 0] - target_line_offset * sin_reference_angles
            target_line_points[:, 1] = reference_points[:, 1] + target_line_offset * cos_reference_angles
            result["points"] = target_line_points
        if include_body_points:
            target_dx = (
                reference_points[:, 0] -
                target_line_offset * sin_reference_angles -
                float(body_px)
            )
            target_dy = (
                reference_points[:, 1] +
                target_line_offset * cos_reference_angles -
                float(body_py)
            )
            body_points = np.empty_like(reference_points, dtype=output_dtype)
            body_points[:, 0] = body_cos_theta * target_dx + body_sin_theta * target_dy
            body_points[:, 1] = -body_sin_theta * target_dx + body_cos_theta * target_dy
            result["body_points"] = body_points
        if include_angles:
            result["angles"] = reference_angles
        if include_curvatures or include_speed_scale:
            tangent_scale = _strict_parallel_curve_denominator(
                reference_curvatures,
                target_line_offset,
            )
            if include_curvatures:
                target_line_curvatures = reference_curvatures / tangent_scale
                result["curvatures"] = target_line_curvatures.astype(output_dtype)
            if include_speed_scale:
                result["speed_scale"] = np.maximum(
                    np.abs(tangent_scale),
                    1e-6,
                ).astype(output_dtype)
        return result

    needs_offsets = include_offsets or include_points or include_body_points or include_angles or include_curvatures or include_speed_scale
    target_line_offsets = None
    if needs_offsets:
        target_line_offsets = np.asarray(
            geom.target_line_offsets_at_progresses(
                reference_progresses,
                target_line_offset_m=target_line_offset_m,
                target_lane_index=target_lane_index,
                target_lane_units=target_lane_units,
                target_lane_require_active=target_lane_require_active,
                target_lane_units_allow_outside=target_lane_units_allow_outside,
            ),
            dtype=output_dtype,
        )

    target_line_offset_derivatives = None
    if include_angles or include_speed_scale:
        target_line_offset_derivatives = np.asarray(
            geom.target_line_offset_derivatives_at_progresses(
                reference_progresses,
                target_line_offset_m=target_line_offset_m,
                target_lane_index=target_lane_index,
                target_lane_units=target_lane_units,
                target_lane_require_active=target_lane_require_active,
                target_lane_units_allow_outside=target_lane_units_allow_outside,
            ),
            dtype=output_dtype,
        )

    tangent_scale = (
        1.0 - reference_curvatures * target_line_offsets
        if (include_angles or include_curvatures or include_speed_scale)
        else None
    )

    result = {}
    if include_offsets:
        result["offsets"] = target_line_offsets.astype(output_dtype)
    if include_points or include_body_points:
        sin_reference_angles = np.sin(reference_angles)
        cos_reference_angles = np.cos(reference_angles)
    if include_points:
        target_line_points = np.empty_like(reference_points, dtype=output_dtype)
        target_line_points[:, 0] = reference_points[:, 0] - target_line_offsets * sin_reference_angles
        target_line_points[:, 1] = reference_points[:, 1] + target_line_offsets * cos_reference_angles
        result["points"] = target_line_points
    if include_body_points:
        target_dx = (
            reference_points[:, 0] -
            target_line_offsets * sin_reference_angles -
            float(body_px)
        )
        target_dy = (
            reference_points[:, 1] +
            target_line_offsets * cos_reference_angles -
            float(body_py)
        )
        body_points = np.empty_like(reference_points, dtype=output_dtype)
        body_points[:, 0] = body_cos_theta * target_dx + body_sin_theta * target_dy
        body_points[:, 1] = -body_sin_theta * target_dx + body_cos_theta * target_dy
        result["body_points"] = body_points
    if include_angles:
        target_line_angles = reference_angles + np.arctan2(
            target_line_offset_derivatives,
            tangent_scale,
        )
        result["angles"] = target_line_angles.astype(output_dtype)
    if include_curvatures:
        curvature_denominator = _strict_parallel_curve_denominator(
            reference_curvatures,
            target_line_offsets,
        )
        target_line_curvatures = reference_curvatures / curvature_denominator
        result["curvatures"] = target_line_curvatures.astype(output_dtype)
    if include_speed_scale:
        target_line_speed_scale = np.sqrt(
            tangent_scale * tangent_scale +
            target_line_offset_derivatives * target_line_offset_derivatives
        )
        result["speed_scale"] = np.maximum(
            target_line_speed_scale,
            1e-6,
        ).astype(output_dtype)
    return result


def target_line_geometry_at_reference_point(
    geom,
    reference_progress,
    reference_px,
    reference_py,
    reference_angle,
    reference_curvature,
    reference_element_idx,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is None and target_lane_units is None:
        target_line_offset = float(target_line_offset_m)
        reference_angle = float(reference_angle)
        reference_curvature = float(reference_curvature)
        if target_line_offset == 0.0:
            return {
                "offset": 0.0,
                "px": float(reference_px),
                "py": float(reference_py),
                "angle": reference_angle,
                "curvature": reference_curvature,
                "speed_scale": 1.0,
            }

        tangent_scale = _strict_parallel_curve_denominator(
            reference_curvature,
            target_line_offset,
        )
        target_line_curvature = reference_curvature / tangent_scale
        target_line_speed_scale = max(abs(tangent_scale), 1e-6)

        return {
            "offset": target_line_offset,
            "px": float(reference_px) - target_line_offset * math.sin(reference_angle),
            "py": float(reference_py) + target_line_offset * math.cos(reference_angle),
            "angle": reference_angle,
            "curvature": target_line_curvature,
            "speed_scale": target_line_speed_scale,
        }

    constant_offsets_by_element = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )

    if (
        constant_offsets_by_element is None or
        not geom.constant_target_offsets_are_continuous_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    ):
        reference_samples = {
            "coordinates": np.array([[reference_px, reference_py]], dtype=np.float32),
            "angles": np.array([reference_angle], dtype=np.float32),
            "curvatures": np.array([reference_curvature], dtype=np.float32),
        }
        target_line_geometry = geom.target_line_geometry_from_reference_samples(
            np.array([reference_progress], dtype=np.float32),
            reference_samples,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
        return {
            "offset": float(target_line_geometry["offsets"][0]),
            "px": float(target_line_geometry["points"][0, 0]),
            "py": float(target_line_geometry["points"][0, 1]),
            "angle": float(target_line_geometry["angles"][0]),
            "curvature": float(target_line_geometry["curvatures"][0]),
            "speed_scale": float(target_line_geometry["speed_scale"][0]),
        }

    reference_element_idx = int(reference_element_idx)
    target_line_offset = float(constant_offsets_by_element[reference_element_idx])
    reference_angle = float(reference_angle)
    reference_curvature = float(reference_curvature)
    tangent_scale = _strict_parallel_curve_denominator(
        reference_curvature,
        target_line_offset,
    )
    target_line_curvature = reference_curvature / tangent_scale
    target_line_speed_scale = max(abs(tangent_scale), 1e-6)

    return {
        "offset": target_line_offset,
        "px": float(reference_px) - target_line_offset * math.sin(reference_angle),
        "py": float(reference_py) + target_line_offset * math.cos(reference_angle),
        "angle": reference_angle,
        "curvature": target_line_curvature,
        "speed_scale": target_line_speed_scale,
    }


def target_line_geometry_from_reference_samples_for_config(
    geom,
    reference_line_progresses_m,
    reference_samples,
    target_line_config,
    **kwargs,
):
    """Sample unchanged target geometry from one normalized target record."""
    return target_line_geometry_from_reference_samples(
        geom,
        reference_line_progresses_m,
        reference_samples,
        **_config_geometry_kwargs(target_line_config),
        **kwargs,
    )


def target_line_geometry_at_reference_point_for_config(
    geom,
    reference_progress,
    reference_px,
    reference_py,
    reference_angle,
    reference_curvature,
    reference_element_idx,
    target_line_config,
):
    """Resolve unchanged current geometry from one normalized target record."""
    return target_line_geometry_at_reference_point(
        geom,
        reference_progress,
        reference_px,
        reference_py,
        reference_angle,
        reference_curvature,
        reference_element_idx,
        **_config_geometry_kwargs(target_line_config),
    )
