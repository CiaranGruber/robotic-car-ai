"""Target-line arc-length mapping and lookup-cache helpers."""

import numpy as np

from dreamgym.envs.road_core import lane_geometry
from dreamgym.envs.road_core import utils as road_utils
from dreamgym.envs.road_core._target_config import _target_line_config_values


_PARALLEL_CURVE_DENOMINATOR_MINIMUM = 1.0e-6


def continuous_offset_target_line_scale(geom, target_line_offset_metres, element_index):
    """Return the forward target/reference arc-length scale for one element."""
    element_target_line_scale = (
        1.0 - float(geom.c[element_index]) * float(target_line_offset_metres)
    )
    if element_target_line_scale <= _PARALLEL_CURVE_DENOMINATOR_MINIMUM:
        raise ValueError(
            "fixed-offset parallel-curve denominator must be greater than "
            "1.0e-6 for a forward target mapping"
        )
    return element_target_line_scale


def _advance_reference_progress_by_target_line_displacement(
    geom,
    start_reference_progress,
    target_line_displacement,
    target_line_offsets_by_element,
):
    current_reference_progress = float(start_reference_progress)
    remaining_target_distance = abs(float(target_line_displacement))
    if remaining_target_distance == 0.0:
        return current_reference_progress

    direction = 1.0 if target_line_displacement > 0.0 else -1.0
    element_end_progresses = geom.l_total_at_end
    total_reference_length = float(element_end_progresses[-1])

    while remaining_target_distance > 0.0:
        if direction > 0.0:
            # Beyond finite Road geometry, raw progress extrapolates one-for-one
            # so callers can diagnose and clamp endpoint saturation themselves.
            if current_reference_progress < 0.0:
                target_distance_to_road_start = -current_reference_progress
                if remaining_target_distance <= target_distance_to_road_start:
                    return current_reference_progress + remaining_target_distance
                current_reference_progress = 0.0
                remaining_target_distance -= target_distance_to_road_start
                continue
            if current_reference_progress >= total_reference_length:
                return current_reference_progress + remaining_target_distance

            element_index = int(
                np.searchsorted(
                    element_end_progresses,
                    current_reference_progress,
                    # Forward travel from a boundary enters the next element.
                    side="right",
                )
            )
            element_boundary = float(element_end_progresses[element_index])
            element_target_line_scale = continuous_offset_target_line_scale(
                geom,
                target_line_offsets_by_element[element_index],
                element_index,
            )
            target_distance_to_boundary = (
                element_boundary - current_reference_progress
            ) * element_target_line_scale
            if remaining_target_distance <= target_distance_to_boundary:
                if remaining_target_distance == target_distance_to_boundary:
                    return element_boundary
                return (
                    current_reference_progress
                    + remaining_target_distance / element_target_line_scale
                )
            current_reference_progress = element_boundary
            remaining_target_distance -= target_distance_to_boundary
            continue

        if current_reference_progress > total_reference_length:
            target_distance_to_road_end = (
                current_reference_progress - total_reference_length
            )
            if remaining_target_distance <= target_distance_to_road_end:
                return current_reference_progress - remaining_target_distance
            current_reference_progress = total_reference_length
            remaining_target_distance -= target_distance_to_road_end
            continue
        if current_reference_progress <= 0.0:
            return current_reference_progress - remaining_target_distance

        element_index = int(
            np.searchsorted(
                element_end_progresses,
                current_reference_progress,
                # Backward travel from a boundary enters the preceding element.
                side="left",
            )
        )
        element_start_progress = (
            0.0
            if element_index == 0
            else float(element_end_progresses[element_index - 1])
        )
        element_target_line_scale = continuous_offset_target_line_scale(
            geom,
            target_line_offsets_by_element[element_index],
            element_index,
        )
        target_distance_to_boundary = (
            current_reference_progress - element_start_progress
        ) * element_target_line_scale
        if remaining_target_distance <= target_distance_to_boundary:
            if remaining_target_distance == target_distance_to_boundary:
                return element_start_progress
            return (
                current_reference_progress
                - remaining_target_distance / element_target_line_scale
            )
        current_reference_progress = element_start_progress
        remaining_target_distance -= target_distance_to_boundary

    return current_reference_progress


def reference_progresses_for_continuous_offset_displacements(
    geom,
    origin_reference_line_progress_m,
    target_line_displacements_m,
    target_line_offsets_by_element,
):
    """Map sorted target-line displacements through continuous fixed offsets."""
    displacements = np.asarray(
        target_line_displacements_m,
        dtype=np.float64,
    ).reshape(-1)
    offsets = np.asarray(
        target_line_offsets_by_element,
        dtype=np.float64,
    ).reshape(-1)
    if offsets.shape != geom.l_total_at_end.shape:
        raise ValueError("target-line offsets must provide one value per Road element")

    reference_progresses = np.empty_like(displacements, dtype=np.float64)
    current_reference_progress = float(origin_reference_line_progress_m)
    previous_target_line_displacement = 0.0
    for row_index, target_line_displacement in enumerate(displacements):
        incremental_displacement = (
            float(target_line_displacement) - previous_target_line_displacement
        )
        current_reference_progress = (
            _advance_reference_progress_by_target_line_displacement(
                geom,
                current_reference_progress,
                incremental_displacement,
                offsets,
            )
        )
        reference_progresses[row_index] = current_reference_progress
        previous_target_line_displacement = float(target_line_displacement)
    return reference_progresses


def constant_target_distance_lookup_for_offsets(geom, offsets_by_element, cache_key=None):
    if cache_key is not None and cache_key in geom.constant_distance_lookup_cache:
        return geom.constant_distance_lookup_cache[cache_key]

    offsets_by_element = np.asarray(offsets_by_element, dtype=np.float64).reshape(-1)
    if offsets_by_element.shape[0] != geom.l.shape[0]:
        lookup = None
    else:
        element_target_line_scales = 1.0 - geom.c.astype(np.float64) * offsets_by_element
        if np.any(element_target_line_scales <= 1e-6):
            lookup = None
        else:
            reference_boundaries = np.empty((geom.l.shape[0] + 1,), dtype=np.float64)
            reference_boundaries[0] = 0.0
            reference_boundaries[1:] = geom.l_total_at_end.astype(np.float64)

            target_distance_boundaries = np.empty((geom.l.shape[0] + 1,), dtype=np.float64)
            target_distance_boundaries[0] = 0.0
            target_distance_boundaries[1:] = np.cumsum(
                geom.l.astype(np.float64) * element_target_line_scales,
                dtype=np.float64,
            )
            lookup = {
                "reference_boundaries": reference_boundaries,
                "target_distance_boundaries": target_distance_boundaries,
                "element_target_line_scales": element_target_line_scales,
            }

    if cache_key is not None:
        geom.constant_distance_lookup_cache[cache_key] = lookup
    return lookup


def target_distance_at_reference_progress_for_constant_offset(reference_progress, lookup):
    reference_progress = float(reference_progress)
    reference_boundaries = lookup["reference_boundaries"]
    target_distance_boundaries = lookup["target_distance_boundaries"]
    element_target_line_scales = lookup["element_target_line_scales"]

    total_reference_length = float(reference_boundaries[-1])
    total_target_distance = float(target_distance_boundaries[-1])

    if reference_progress < 0.0:
        return reference_progress
    if reference_progress >= total_reference_length:
        return total_target_distance + (reference_progress - total_reference_length)

    element_idx = int(np.searchsorted(reference_boundaries[1:], reference_progress, side="right"))
    return (
        float(target_distance_boundaries[element_idx]) +
        (reference_progress - float(reference_boundaries[element_idx])) *
        float(element_target_line_scales[element_idx])
    )


def reference_progress_for_single_constant_target_distance(
    geom,
    start_reference_progress,
    target_line_distance_query,
    offsets_by_element,
    cache_key=None,
):
    lookup = geom.constant_target_distance_lookup_for_offsets(offsets_by_element, cache_key=cache_key)
    if lookup is None:
        return None

    reference_boundaries = lookup["reference_boundaries"]
    target_distance_boundaries = lookup["target_distance_boundaries"]
    element_target_line_scales = lookup["element_target_line_scales"]

    start_target_distance = geom.target_distance_at_reference_progress_for_constant_offset(
        start_reference_progress,
        lookup,
    )
    query_target_distance = start_target_distance + float(target_line_distance_query)

    total_reference_length = float(reference_boundaries[-1])
    total_target_distance = float(target_distance_boundaries[-1])
    last_element_idx = len(geom.l_total_at_end) - 1

    if query_target_distance < 0.0:
        return query_target_distance, 0
    if query_target_distance > total_target_distance:
        return (
            total_reference_length + (query_target_distance - total_target_distance),
            last_element_idx,
        )

    element_idx = int(np.searchsorted(
        target_distance_boundaries[1:],
        query_target_distance,
        side="left",
    ))
    reference_progress = (
        float(reference_boundaries[element_idx]) +
        (
            query_target_distance -
            float(target_distance_boundaries[element_idx])
        ) /
        float(element_target_line_scales[element_idx])
    )
    return reference_progress, element_idx


def reference_progresses_for_constant_target_offset_distances(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    offsets_by_element,
    cache_key=None,
    return_element_indices=False,
    return_metadata=False,
):
    target_line_distance_queries = np.asarray(target_line_distance_queries, dtype=np.float64).reshape(-1)
    want_element_indices = bool(return_element_indices or return_metadata)
    if target_line_distance_queries.size == 0:
        reference_progresses = np.array([], dtype=np.float32)
        if return_metadata:
            return reference_progresses, {
                "element_indices": np.array([], dtype=np.int32),
                "element_indices_are_trusted": True,
                "progression_queries_are_in_bounds": True,
            }
        if return_element_indices:
            return reference_progresses, np.array([], dtype=np.int32)
        return reference_progresses

    lookup = geom.constant_target_distance_lookup_for_offsets(offsets_by_element, cache_key=cache_key)
    if lookup is None:
        if return_metadata:
            return None, {
                "element_indices": None,
                "element_indices_are_trusted": False,
                "progression_queries_are_in_bounds": False,
            }
        if return_element_indices:
            return None, None
        return None

    reference_boundaries = lookup["reference_boundaries"]
    target_distance_boundaries = lookup["target_distance_boundaries"]
    element_target_line_scales = lookup["element_target_line_scales"]

    start_target_distance = geom.target_distance_at_reference_progress_for_constant_offset(
        start_reference_progress,
        lookup,
    )
    query_target_distances = start_target_distance + target_line_distance_queries

    total_reference_length = float(reference_boundaries[-1])
    total_target_distance = float(target_distance_boundaries[-1])
    reference_progresses = np.empty(shape=query_target_distances.shape, dtype=np.float64)

    boundary_tolerance = 1e-7
    before_start_mask = query_target_distances < -boundary_tolerance
    after_end_mask = query_target_distances > (total_target_distance + boundary_tolerance)
    inside_mask = ~(before_start_mask | after_end_mask)
    progression_queries_are_in_bounds = not (
        bool(np.any(before_start_mask)) or
        bool(np.any(after_end_mask))
    )
    if want_element_indices:
        target_element_idxs = np.empty(shape=query_target_distances.shape, dtype=np.int32)
        target_element_idxs[before_start_mask] = 0
        target_element_idxs[after_end_mask] = len(geom.l_total_at_end) - 1

    reference_progresses[before_start_mask] = query_target_distances[before_start_mask]
    reference_progresses[after_end_mask] = (
        total_reference_length +
        (query_target_distances[after_end_mask] - total_target_distance)
    )

    if np.any(inside_mask):
        inside_target_distances = np.clip(
            query_target_distances[inside_mask],
            0.0,
            total_target_distance,
        )
        element_idxs = np.searchsorted(
            target_distance_boundaries[1:],
            inside_target_distances,
            side="left",
        ).astype(np.int32)
        reference_progresses[inside_mask] = (
            reference_boundaries[element_idxs] +
            (
                inside_target_distances -
                target_distance_boundaries[element_idxs]
            ) /
            element_target_line_scales[element_idxs]
        )
        if want_element_indices:
            target_element_idxs[inside_mask] = element_idxs

    reference_progresses = reference_progresses.astype(np.float32)
    if return_metadata:
        return reference_progresses, {
            "element_indices": target_element_idxs,
            "element_indices_are_trusted": True,
            "progression_queries_are_in_bounds": progression_queries_are_in_bounds,
        }
    if return_element_indices:
        return reference_progresses, target_element_idxs
    return reference_progresses


def target_line_arc_length_lookup_cache_key(
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    return (
        float(target_line_offset_m),
        None if target_lane_index is None else int(target_lane_index),
        None if target_lane_units is None else float(target_lane_units),
        bool(target_lane_require_active),
        bool(target_lane_units_allow_outside),
    )


def target_line_arc_length_reference_grid(geom, mapping_step_m):
    if geom.l_total_at_end.shape[0] == 0:
        raise ValueError("Road has no elements.")

    reference_grid_parts = []
    element_start_progress = 0.0
    for element_idx in range(geom.l.shape[0]):
        element_end_progress = float(geom.l_total_at_end[element_idx])
        element_length = element_end_progress - element_start_progress
        num_samples = max(2, int(np.ceil(element_length / mapping_step_m)) + 1)
        element_grid = np.linspace(
            element_start_progress,
            element_end_progress,
            num=num_samples,
            endpoint=True,
            dtype=np.float32,
        )
        if len(reference_grid_parts) > 0:
            element_grid = element_grid[1:]
        reference_grid_parts.append(element_grid)
        element_start_progress = element_end_progress

    return np.concatenate(reference_grid_parts, axis=0).astype(np.float32)


def build_target_line_arc_length_lookup(
    geom,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
    mapping_step_m=0.5,
):
    reference_progresses = geom.target_line_arc_length_reference_grid(mapping_step_m)
    try:
        reference_samples = geom._reference_line_samples_at_progresses(
            reference_progresses,
            include_coordinates=True,
            include_angles=True,
            include_curvatures=False,
            include_speeds=False,
            include_element_indices=False,
        )
        target_line_offsets = geom.target_line_offsets_at_progresses(
            reference_progresses,
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    except ValueError:
        return None

    target_line_points = road_utils.coordinates_at_lateral_offsets_from_reference_points(
        reference_samples["coordinates"],
        reference_samples["angles"],
        target_line_offsets,
    )
    segment_lengths = np.linalg.norm(np.diff(target_line_points, axis=0), axis=1)
    target_distances = np.concatenate(
        (
            np.array([0.0], dtype=np.float32),
            np.cumsum(segment_lengths, dtype=np.float32),
        ),
        axis=0,
    )
    if (
        not np.all(np.isfinite(reference_progresses)) or
        not np.all(np.isfinite(target_distances)) or
        target_distances[-1] <= 0.0
    ):
        return None

    keep_indices = np.concatenate(
        (
            np.array([True], dtype=np.bool_),
            np.diff(target_distances) > 1e-9,
        ),
        axis=0,
    )
    reference_progresses = reference_progresses[keep_indices]
    target_distances = target_distances[keep_indices]
    if target_distances.size < 2:
        return None

    return {
        "reference_progresses": reference_progresses.astype(np.float32),
        "target_distances": target_distances.astype(np.float32),
    }


def target_line_arc_length_lookup_if_available(
    geom,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    cache_key = geom.target_line_arc_length_lookup_cache_key(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if cache_key not in geom.arc_length_lookup_cache:
        geom.arc_length_lookup_cache[cache_key] = geom.build_target_line_arc_length_lookup(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    return geom.arc_length_lookup_cache[cache_key]


def target_distance_at_reference_progress_from_lookup(reference_progress, lookup):
    reference_progresses = lookup["reference_progresses"]
    target_distances = lookup["target_distances"]
    reference_progress = float(reference_progress)
    reference_start = float(reference_progresses[0])
    reference_end = float(reference_progresses[-1])

    if reference_progress < reference_start:
        return float(target_distances[0]) + (reference_progress - reference_start)
    if reference_progress > reference_end:
        return float(target_distances[-1]) + (reference_progress - reference_end)
    return float(np.interp(reference_progress, reference_progresses, target_distances))


def reference_progresses_from_target_line_arc_length_lookup(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    lookup,
):
    target_line_distance_queries = np.asarray(target_line_distance_queries, dtype=np.float32).reshape(-1)
    reference_progresses_table = lookup["reference_progresses"]
    target_distances_table = lookup["target_distances"]

    start_target_distance = geom.target_distance_at_reference_progress_from_lookup(
        start_reference_progress,
        lookup,
    )
    query_target_distances = start_target_distance + target_line_distance_queries
    reference_progresses = np.empty(shape=query_target_distances.shape, dtype=np.float32)

    before_start_mask = query_target_distances < target_distances_table[0]
    after_end_mask = query_target_distances > target_distances_table[-1]
    inside_mask = ~(before_start_mask | after_end_mask)

    reference_progresses[before_start_mask] = (
        reference_progresses_table[0] +
        (query_target_distances[before_start_mask] - target_distances_table[0])
    )
    reference_progresses[after_end_mask] = (
        reference_progresses_table[-1] +
        (query_target_distances[after_end_mask] - target_distances_table[-1])
    )
    reference_progresses[inside_mask] = np.interp(
        query_target_distances[inside_mask],
        target_distances_table,
        reference_progresses_table,
    ).astype(np.float32)

    return reference_progresses


def reference_progresses_for_target_line_distances(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
    return_element_indices=False,
    return_metadata=False,
):
    target_line_distance_queries = np.asarray(target_line_distance_queries, dtype=np.float32).reshape(-1)
    reference_progresses = np.full(
        shape=target_line_distance_queries.shape,
        fill_value=float(start_reference_progress),
        dtype=np.float32,
    )
    if target_line_distance_queries.size == 0:
        if return_metadata:
            return reference_progresses, {
                "element_indices": np.array([], dtype=np.int32),
                "element_indices_are_trusted": True,
                "progression_queries_are_in_bounds": True,
            }
        if return_element_indices:
            return reference_progresses, np.array([], dtype=np.int32)
        return reference_progresses
    if target_lane_index is None and target_lane_units is None and float(target_line_offset_m) == 0.0:
        reference_progresses = (float(start_reference_progress) + target_line_distance_queries).astype(np.float32)
        if return_metadata:
            return reference_progresses, {
                "element_indices": geom.element_indices_for_reference_progresses(reference_progresses),
                "element_indices_are_trusted": True,
                "progression_queries_are_in_bounds": bool(np.all(
                    (reference_progresses >= 0.0) &
                    (reference_progresses <= geom.l_total_at_end[-1])
                )),
            }
        if return_element_indices:
            return reference_progresses, geom.element_indices_for_reference_progresses(reference_progresses)
        return reference_progresses

    constant_offset_cache_key = geom.constant_target_offsets_cache_key(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if target_lane_index is None and target_lane_units is None:
        constant_offsets_by_element = np.full(
            geom.l_total_at_end.shape,
            float(target_line_offset_m),
            dtype=np.float32,
        )
        constant_offsets_are_continuous = True
    else:
        # Do not probe every Road element merely to select a mapping fast path.
        # A previously established whole-Road constant result is safe to reuse,
        # but an uncached lane selector must be evaluated only where it travels.
        constant_offsets_by_element = geom.constant_offsets_cache.get(
            constant_offset_cache_key
        )
        if constant_offsets_by_element is None:
            constant_offsets_are_continuous = None
        else:
            constant_offsets_are_continuous = bool(
                constant_offsets_by_element.size <= 1
                or np.allclose(
                    constant_offsets_by_element[1:],
                    constant_offsets_by_element[0],
                    rtol=0.0,
                    atol=1.0e-9,
                )
            )
    if constant_offsets_by_element is not None and constant_offsets_are_continuous:
        fast_reference_progresses = geom.reference_progresses_for_constant_target_offset_distances(
            start_reference_progress,
            target_line_distance_queries,
            constant_offsets_by_element,
            cache_key=constant_offset_cache_key,
            return_element_indices=return_element_indices,
            return_metadata=return_metadata,
        )
        if return_metadata:
            fast_reference_progresses, fast_metadata = fast_reference_progresses
            if fast_reference_progresses is not None:
                return fast_reference_progresses, fast_metadata
        if return_element_indices:
            fast_reference_progresses, fast_element_indices = fast_reference_progresses
            if fast_reference_progresses is not None:
                return fast_reference_progresses, fast_element_indices
        elif fast_reference_progresses is not None:
            return fast_reference_progresses

    mapping_step_m = 0.5
    total_reference_length = float(geom.l_total_at_end[-1])

    def local_target_line_offsets(reference_grid):
        if target_lane_index is not None:
            return lane_geometry.lane_center_offsets_at_progresses_vectorized(
                reference_grid,
                int(target_lane_index),
                geom.lane_metadata,
                geom.l,
                geom.l_total_at_end,
                geom.min_active_lane_width_m,
                require_active=bool(target_lane_require_active),
            )
        if target_lane_units is not None:
            return lane_geometry.lane_units_to_meter_offsets_at_progresses_vectorized(
                reference_grid,
                float(target_lane_units),
                geom.lane_metadata,
                geom.l,
                geom.l_total_at_end,
                allow_outside=bool(target_lane_units_allow_outside),
            )
        return np.full(
            reference_grid.shape,
            float(target_line_offset_m),
            dtype=np.float32,
        )

    for direction in (-1.0, 1.0):
        mask = target_line_distance_queries * direction > 0.0
        if not np.any(mask):
            continue

        requested_distances = target_line_distance_queries[mask] * direction
        max_requested_distance = float(np.max(requested_distances))
        current_reference_progress = float(start_reference_progress)
        reference_grid_parts = [
            np.array([current_reference_progress], dtype=np.float64)
        ]
        cumulative_distance_parts = [np.array([0.0], dtype=np.float64)]
        cumulative_distance = 0.0
        distance_comparison_tolerance = (
            8.0
            * np.finfo(np.float32).eps
            * max(1.0, max_requested_distance)
        )

        while (
            cumulative_distance + distance_comparison_tolerance
            < max_requested_distance
        ):
            if direction > 0.0 and current_reference_progress < 0.0:
                element_boundary = min(
                    0.0,
                    current_reference_progress
                    + max_requested_distance
                    - cumulative_distance,
                )
                raw_span = element_boundary - current_reference_progress
            elif direction < 0.0 and current_reference_progress > total_reference_length:
                element_boundary = max(
                    total_reference_length,
                    current_reference_progress
                    - (max_requested_distance - cumulative_distance),
                )
                raw_span = current_reference_progress - element_boundary
            elif (
                direction > 0.0 and current_reference_progress >= total_reference_length
            ) or (direction < 0.0 and current_reference_progress <= 0.0):
                raw_span = max_requested_distance - cumulative_distance
                element_boundary = current_reference_progress + direction * raw_span
            else:
                raw_span = None

            if raw_span is not None:
                cumulative_distance += raw_span
                current_reference_progress = element_boundary
                reference_grid_parts.append(
                    np.array([current_reference_progress], dtype=np.float64)
                )
                cumulative_distance_parts.append(
                    np.array([cumulative_distance], dtype=np.float64)
                )
                continue

            if direction > 0.0:
                element_index = int(
                    np.searchsorted(
                        geom.l_total_at_end,
                        current_reference_progress,
                        side="right",
                    )
                )
                element_boundary = float(geom.l_total_at_end[element_index])
            else:
                element_index = int(
                    np.searchsorted(
                        geom.l_total_at_end,
                        current_reference_progress,
                        side="left",
                    )
                )
                element_boundary = (
                    0.0
                    if element_index == 0
                    else float(geom.l_total_at_end[element_index - 1])
                )

            reference_span = abs(element_boundary - current_reference_progress)
            num_samples = max(2, int(np.ceil(reference_span / mapping_step_m)) + 1)
            reference_grid = np.linspace(
                current_reference_progress,
                element_boundary,
                num=num_samples,
                endpoint=True,
                dtype=np.float32,
            )
            reference_samples = geom._reference_line_samples_at_progresses(
                reference_grid,
                include_coordinates=True,
                include_angles=True,
                include_curvatures=False,
                include_speeds=False,
                include_element_indices=False,
            )
            offset_reference_grid = reference_grid
            if direction < 0.0:
                # The shared boundary belongs to the preceding element, but
                # this segment approaches it through the current element.
                # Use the inward-side lane geometry to measure only this
                # segment; post-map range validation owns boundary validity.
                offset_reference_grid = reference_grid.copy()
                offset_reference_grid[-1] = np.nextafter(
                    offset_reference_grid[-1],
                    np.float32(np.inf),
                )
            target_line_offsets = local_target_line_offsets(
                offset_reference_grid
            )
            if np.allclose(
                target_line_offsets,
                target_line_offsets[0],
                rtol=0.0,
                atol=1.0e-7,
            ):
                target_line_scale = continuous_offset_target_line_scale(
                    geom,
                    target_line_offsets[0],
                    element_index,
                )
                segment_lengths = (
                    np.abs(np.diff(reference_grid.astype(np.float64)))
                    * target_line_scale
                )
            else:
                target_line_points = road_utils.coordinates_at_lateral_offsets_from_reference_points(
                    reference_samples["coordinates"],
                    reference_samples["angles"],
                    target_line_offsets,
                )
                segment_lengths = np.linalg.norm(
                    np.diff(target_line_points, axis=0), axis=1
                ).astype(np.float64)

            local_cumulative_distances = (
                cumulative_distance + np.cumsum(segment_lengths, dtype=np.float64)
            )
            reference_grid_parts.append(reference_grid[1:].astype(np.float64))
            cumulative_distance_parts.append(local_cumulative_distances)
            cumulative_distance = float(local_cumulative_distances[-1])
            current_reference_progress = element_boundary

        reference_grid = np.concatenate(reference_grid_parts)
        cumulative_distances = np.concatenate(cumulative_distance_parts)
        if cumulative_distances[-1] <= 0.0:
            reference_progresses[mask] = float(start_reference_progress)
        else:
            reference_progresses[mask] = np.interp(
                requested_distances,
                cumulative_distances,
                reference_grid,
            ).astype(np.float32)

    if return_metadata:
        return reference_progresses, {
            "element_indices": None,
            "element_indices_are_trusted": False,
            "progression_queries_are_in_bounds": False,
        }
    if return_element_indices:
        return reference_progresses, None
    return reference_progresses


def reference_progresses_for_target_line_config_distances(
    geom,
    start_reference_progress,
    target_line_distance_queries,
    target_line_config,
    *,
    return_element_indices=False,
    return_metadata=False,
):
    """Map distances using one already-normalized target-line record."""
    (
        target_line_offset_m,
        target_lane_index,
        target_lane_units,
        _,
        target_lane_units_allow_outside,
    ) = _target_line_config_values(target_line_config)
    return reference_progresses_for_target_line_distances(
        geom,
        start_reference_progress,
        target_line_distance_queries,
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=False,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
        return_element_indices=return_element_indices,
        return_metadata=return_metadata,
    )
