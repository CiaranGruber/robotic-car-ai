"""Target-line offset selection and constant-offset cache helpers."""

import numpy as np

from dreamgym.envs.road_core import lane_geometry
from dreamgym.envs.road_core._target_config import _target_line_config_values


def validate_target_line_config_over_reference_progress_range(
    geom,
    start_reference_progress,
    end_reference_progress,
    target_line_config,
):
    """Validate lane existence/activity only on the traversed Road portion."""
    if target_line_config["mode"] not in {"lane_center", "lane_coordinate"}:
        return

    total_length = float(geom.l_total_at_end[-1])
    lower = max(0.0, min(float(start_reference_progress), float(end_reference_progress)))
    upper = min(total_length, max(float(start_reference_progress), float(end_reference_progress)))
    progress_values = [lower, upper]
    for boundary_value in geom.l_total_at_end[:-1]:
        boundary = float(boundary_value)
        if lower <= boundary <= upper:
            progress_values.append(boundary)
        if lower <= boundary < upper:
            progress_values.append(float(np.nextafter(boundary, np.inf)))
    progress_values = np.unique(np.asarray(progress_values, dtype=np.float64))
    (
        _,
        target_lane_index,
        target_lane_units,
        target_lane_require_active,
        target_lane_units_allow_outside,
    ) = _target_line_config_values(target_line_config)
    element_indices = np.searchsorted(
        geom.l_total_at_end.astype(np.float64),
        progress_values,
        side="left",
    ).astype(np.int32)
    element_indices = np.minimum(element_indices, geom.l_total_at_end.shape[0] - 1)
    contexts = lane_geometry.progress_contexts_at(
        progress_values,
        geom.l,
        geom.l_total_at_end,
        output_dtype=np.float64,
        element_indices=element_indices,
        element_indices_are_trusted=True,
    )
    for context in contexts:
        metadata = geom.lane_metadata[context["element_index"]]
        widths = lane_geometry.lane_widths_for_metadata_at_fraction(
            metadata,
            context["element_fraction"],
        )
        if target_lane_index is not None:
            lane_geometry.lane_center_offset_from_widths(
                widths,
                target_lane_index,
                geom.min_active_lane_width_m,
                target_lane_require_active,
            )
        else:
            lane_geometry.lane_units_to_meter_offset_from_widths(
                widths,
                target_lane_units,
                allow_outside=target_lane_units_allow_outside,
            )


def target_line_offsets_at_progresses(
    geom,
    progress_values,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is not None and target_lane_units is not None:
        raise ValueError("Specify only one of target_lane_index or target_lane_units.")

    progress_values = np.array(progress_values, dtype=np.float32).reshape(-1)
    if progress_values.size == 0:
        return np.array([], dtype=np.float32)

    constant_offsets = geom.constant_target_offsets_at_progresses_if_available(
        progress_values,
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if constant_offsets is not None:
        return constant_offsets

    if target_lane_index is not None:
        return lane_geometry.lane_center_offsets_at_progresses_vectorized(
            progress_values,
            int(target_lane_index),
            geom.lane_metadata,
            geom.l,
            geom.l_total_at_end,
            geom.min_active_lane_width_m,
            require_active=bool(target_lane_require_active),
        )

    if target_lane_units is not None:
        return lane_geometry.lane_units_to_meter_offsets_at_progresses_vectorized(
            progress_values,
            float(target_lane_units),
            geom.lane_metadata,
            geom.l,
            geom.l_total_at_end,
            allow_outside=bool(target_lane_units_allow_outside),
        )

    return np.full(
        shape=progress_values.shape,
        fill_value=float(target_line_offset_m),
        dtype=np.float32,
    )


def constant_target_offsets_cache_key(
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    return (
        float(target_line_offset_m),
        None if target_lane_index is None else int(target_lane_index),
        None if target_lane_units is None else float(target_lane_units),
        bool(target_lane_require_active),
        bool(target_lane_units_allow_outside),
    )


def compute_constant_target_offsets_by_element_if_available(
    geom,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is None and target_lane_units is None:
        return np.full(
            shape=geom.l_total_at_end.shape,
            fill_value=float(target_line_offset_m),
            dtype=np.float32,
        )

    if not geom.all_lane_widths_are_constant:
        return None

    offsets = []
    for metadata in geom.lane_metadata:
        widths = {
            "left": metadata["left_lane_widths_start"],
            "right": metadata["right_lane_widths_start"],
        }

        try:
            if target_lane_index is not None:
                offset = lane_geometry.lane_center_offset_from_widths(
                    widths,
                    int(target_lane_index),
                    geom.min_active_lane_width_m,
                    bool(target_lane_require_active),
                )
            else:
                offset = lane_geometry.lane_units_to_meter_offset_from_widths(
                    widths,
                    float(target_lane_units),
                    allow_outside=bool(target_lane_units_allow_outside),
                )
        except ValueError:
            return None
        offsets.append(offset)

    return np.array(offsets, dtype=np.float32)


def constant_target_offsets_by_element_if_available(
    geom,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is not None and target_lane_units is not None:
        raise ValueError("Specify only one of target_lane_index or target_lane_units.")

    cache_key = geom.constant_target_offsets_cache_key(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if cache_key not in geom.constant_offsets_cache:
        geom.constant_offsets_cache[cache_key] = geom.compute_constant_target_offsets_by_element_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    return geom.constant_offsets_cache[cache_key]


def constant_target_offsets_are_continuous(offsets_by_element):
    offsets_by_element = np.asarray(offsets_by_element, dtype=np.float32).reshape(-1)
    if offsets_by_element.size <= 1:
        return True
    first_offset = float(offsets_by_element[0])
    for offset in offsets_by_element[1:]:
        if abs(float(offset) - first_offset) > 1e-9:
            return False
    return True


def constant_target_offsets_are_continuous_if_available(
    geom,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is not None and target_lane_units is not None:
        raise ValueError("Specify only one of target_lane_index or target_lane_units.")
    if target_lane_index is None and target_lane_units is None:
        return True

    cache_key = geom.constant_target_offsets_cache_key(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if cache_key not in geom.constant_offsets_continuity_cache:
        offsets_by_element = geom.constant_target_offsets_by_element_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
        if offsets_by_element is None:
            geom.constant_offsets_continuity_cache[cache_key] = None
        else:
            geom.constant_offsets_continuity_cache[cache_key] = geom.constant_target_offsets_are_continuous(offsets_by_element)
    return geom.constant_offsets_continuity_cache[cache_key]


def constant_target_offsets_at_progresses_if_available(
    geom,
    progress_values,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    progress_values = np.asarray(progress_values, dtype=np.float32).reshape(-1)
    if progress_values.size == 0:
        return np.array([], dtype=np.float32)

    offsets_by_element = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if offsets_by_element is None:
        return None
    if geom.l_total_at_end.shape[0] == 0:
        raise ValueError("Road has no elements.")

    total_length = float(geom.l_total_at_end[-1])
    clamped_progresses = np.clip(progress_values, 0.0, total_length)
    element_idxs = np.searchsorted(geom.l_total_at_end, clamped_progresses, side="left", sorter=None)
    element_idxs = np.minimum(element_idxs, geom.l_total_at_end.shape[0] - 1)
    return offsets_by_element[element_idxs].astype(np.float32)


def target_line_offset_derivatives_at_progresses(
    geom,
    progress_values,
    target_line_offset_m=0.0,
    target_lane_index=None,
    target_lane_units=None,
    target_lane_require_active=True,
    target_lane_units_allow_outside=False,
):
    if target_lane_index is not None and target_lane_units is not None:
        raise ValueError("Specify only one of target_lane_index or target_lane_units.")

    progress_values = np.asarray(progress_values, dtype=np.float32).reshape(-1)
    if progress_values.size == 0:
        return np.array([], dtype=np.float32)
    if target_lane_index is None and target_lane_units is None:
        return np.zeros(shape=progress_values.shape, dtype=np.float32)

    constant_offsets_by_element = geom.constant_target_offsets_by_element_if_available(
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    if (
        constant_offsets_by_element is not None and
        geom.constant_target_offsets_are_continuous_if_available(
            target_line_offset_m=target_line_offset_m,
            target_lane_index=target_lane_index,
            target_lane_units=target_lane_units,
            target_lane_require_active=target_lane_require_active,
            target_lane_units_allow_outside=target_lane_units_allow_outside,
        )
    ):
        return np.zeros(shape=progress_values.shape, dtype=np.float32)

    finite_difference_step = np.float32(0.05)
    road_end_progress = geom.l_total_at_end[-1]
    lower_progress = progress_values - finite_difference_step
    upper_progress = progress_values + finite_difference_step
    np.clip(
        lower_progress,
        np.float32(0.0),
        road_end_progress,
        out=lower_progress,
    )
    np.clip(
        upper_progress,
        np.float32(0.0),
        road_end_progress,
        out=upper_progress,
    )
    lower_offsets = geom.target_line_offsets_at_progresses(
        lower_progress,
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    upper_offsets = geom.target_line_offsets_at_progresses(
        upper_progress,
        target_line_offset_m=target_line_offset_m,
        target_lane_index=target_lane_index,
        target_lane_units=target_lane_units,
        target_lane_require_active=target_lane_require_active,
        target_lane_units_allow_outside=target_lane_units_allow_outside,
    )
    np.subtract(upper_progress, lower_progress, out=lower_progress)
    np.subtract(upper_offsets, lower_offsets, out=upper_offsets)
    np.divide(
        upper_offsets,
        lower_progress,
        out=upper_offsets,
        where=lower_progress > np.float32(0.0),
    )
    np.copyto(
        upper_offsets,
        np.float32(0.0),
        where=lower_progress <= np.float32(0.0),
    )
    return upper_offsets
