"""Immutable public result types for Road target-line preview sampling."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from numbers import Integral

import numpy as np


_TARGET_LINE_MODES = {
    "reference_line",
    "fixed_offset",
    "lane_center",
    "lane_coordinate",
}
_TARGET_LINE_CURVATURE_MODELS = {
    "exact_reference_line",
    "exact_parallel_curve",
    "local_parallel_curve_approximation",
}
_LANE_BOUNDS_MODES = {
    "target_line_lane",
    "lane_index",
    "reference_lane",
}
_TARGET_LINE_CURVATURE_MODEL_BY_MODE = {
    "reference_line": "exact_reference_line",
    "fixed_offset": "exact_parallel_curve",
    "lane_center": "local_parallel_curve_approximation",
    "lane_coordinate": "local_parallel_curve_approximation",
}


def validate_road_preview_distances(value: object) -> tuple[float, ...]:
    """Return a detached, strictly increasing road-preview distance grid."""
    path = "observation_config.road_preview.target_line_distances_m"
    if (
        isinstance(value, (str, bytes, bytearray)) or
        not isinstance(value, (Sequence, np.ndarray))
    ):
        raise ValueError(
            path + " must be a one-dimensional ordered "
            "real numeric sequence."
        )
    try:
        distance_array = np.asarray(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(
            path + " must be a one-dimensional ordered "
            "real numeric sequence."
        ) from exc

    if distance_array.ndim != 1 or distance_array.dtype.kind not in "iuf":
        raise ValueError(
            path + " must be a one-dimensional ordered "
            "real numeric sequence."
        )
    if any(isinstance(distance, (bool, np.bool_)) for distance in value):
        raise ValueError(
            path + " must not contain boolean values."
        )

    distances = tuple(float(distance) for distance in distance_array)

    if len(distances) < 2:
        raise ValueError(
            path + " must contain at least two points."
        )
    if not np.isfinite(distances).all():
        raise ValueError(
            path + " must contain only finite values."
        )
    if distances[0] != 0.0:
        raise ValueError(
            path + " must start at exactly 0.0."
        )
    if any(distance < 0.0 for distance in distances):
        raise ValueError(
            path + " must contain only nonnegative values."
        )
    if any(current <= previous for previous, current in zip(distances, distances[1:])):
        raise ValueError(
            path + " must be strictly increasing."
        )
    return distances


def _read_only_finite_float_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {value.shape}")
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, dtype=np.float64, copy=True)
    if not np.isfinite(copied).all():
        raise ValueError(f"{name} must contain only finite values")
    copied.setflags(write=False)
    return copied


def _read_only_bool_array(
    name: str,
    value: object,
    shape: tuple[int, ...],
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {value.shape}")
    if value.dtype != np.dtype(np.bool_):
        raise TypeError(f"{name} must have a boolean dtype")
    copied = np.array(value, dtype=np.bool_, copy=True)
    copied.setflags(write=False)
    return copied


def _validated_provenance(name: str, value: object, allowed: set[str]) -> str:
    if not isinstance(value, str) or value not in allowed:
        raise ValueError(f"{name} must be one of {sorted(allowed)}")
    return value


@dataclass(frozen=True, slots=True)
class RoadTargetLineHorizonSample:
    """A detached, immutable result for one aligned Road horizon sample.

    Every array has the same ``M`` rows (positions have shape ``(M, 2)``).
    Distances, positions, and lateral offsets are in metres; headings are in
    radians; curvatures are per metre; and speeds are metres per second.  The
    constructor defensively copies all arrays and exposes read-only ``float64``
    data and boolean masks.

    ``mapped_reference_line_progresses_m`` retains the raw target-to-reference
    mapping.  On a finite Road, rows beyond an endpoint repeat finite endpoint
    geometry, speed, and any selected lane bounds, while
    ``is_spatially_valid`` marks those rows false.
    ``lane_bounds_are_available`` is independent of spatial validity.  The
    four scalar metadata fields record the requested target-line and lane-bound
    modes, including zero-valued non-reference target modes.

    Raises
    ------
    TypeError
        If an array, mask, metadata token, or lane index has the wrong type.
    ValueError
        If shapes, finiteness, distance ordering, lane-array grouping, bounds,
        or metadata cross-field combinations are invalid.
    """

    target_line_distances_m: np.ndarray
    mapped_reference_line_progresses_m: np.ndarray
    positions_in_world_frame_m: np.ndarray
    headings_in_world_frame_rad: np.ndarray
    curvatures_per_m: np.ndarray
    recommended_speeds_mps: np.ndarray
    speed_limits_mps: np.ndarray
    offsets_from_reference_line_m: np.ndarray
    right_lane_bound_offsets_from_target_line_m: np.ndarray | None
    left_lane_bound_offsets_from_target_line_m: np.ndarray | None
    is_spatially_valid: np.ndarray
    lane_bounds_are_available: np.ndarray | None
    target_line_mode: str
    target_line_curvature_model: str
    lane_bounds_mode: str | None
    lane_bounds_source_lane_index: int | None

    def __post_init__(self) -> None:
        distances = self.target_line_distances_m
        if not isinstance(distances, np.ndarray):
            raise TypeError("target_line_distances_m must be a NumPy array")
        if distances.ndim != 1:
            raise ValueError("target_line_distances_m must be one-dimensional")
        sample_count = distances.shape[0]
        if sample_count == 0:
            raise ValueError("target_line_distances_m must be nonempty")

        one_dimensional_float_fields = (
            "target_line_distances_m",
            "mapped_reference_line_progresses_m",
            "headings_in_world_frame_rad",
            "curvatures_per_m",
            "recommended_speeds_mps",
            "speed_limits_mps",
            "offsets_from_reference_line_m",
        )
        for field_name in one_dimensional_float_fields:
            object.__setattr__(
                self,
                field_name,
                _read_only_finite_float_array(
                    field_name,
                    getattr(self, field_name),
                    (sample_count,),
                ),
            )
        object.__setattr__(
            self,
            "positions_in_world_frame_m",
            _read_only_finite_float_array(
                "positions_in_world_frame_m",
                self.positions_in_world_frame_m,
                (sample_count, 2),
            ),
        )
        object.__setattr__(
            self,
            "is_spatially_valid",
            _read_only_bool_array(
                "is_spatially_valid",
                self.is_spatially_valid,
                (sample_count,),
            ),
        )
        if np.any(self.target_line_distances_m < 0.0):
            raise ValueError("target_line_distances_m must be nonnegative")
        if np.any(np.diff(self.target_line_distances_m) < 0.0):
            raise ValueError("target_line_distances_m must be nondecreasing")

        lane_field_values = (
            self.right_lane_bound_offsets_from_target_line_m,
            self.left_lane_bound_offsets_from_target_line_m,
            self.lane_bounds_are_available,
        )
        lane_fields_present = tuple(value is not None for value in lane_field_values)
        if any(lane_fields_present) and not all(lane_fields_present):
            raise ValueError(
                "right/left lane-bound arrays and lane_bounds_are_available "
                "must either all be present or all be absent"
            )
        if all(lane_fields_present):
            for field_name in (
                "right_lane_bound_offsets_from_target_line_m",
                "left_lane_bound_offsets_from_target_line_m",
            ):
                object.__setattr__(
                    self,
                    field_name,
                    _read_only_finite_float_array(
                        field_name,
                        getattr(self, field_name),
                        (sample_count,),
                    ),
                )
            object.__setattr__(
                self,
                "lane_bounds_are_available",
                _read_only_bool_array(
                    "lane_bounds_are_available",
                    self.lane_bounds_are_available,
                    (sample_count,),
                ),
            )
            available = self.lane_bounds_are_available
            right = self.right_lane_bound_offsets_from_target_line_m
            left = self.left_lane_bound_offsets_from_target_line_m
            assert available is not None and right is not None and left is not None
            if np.any(right[available] > left[available]):
                raise ValueError("available right lane bounds must not exceed left bounds")
            unavailable = ~available
            if (
                np.any(right[unavailable] != 1.0)
                or np.any(left[unavailable] != -1.0)
            ):
                raise ValueError(
                    "unavailable lane bounds must use exact right=+1.0, left=-1.0"
                )

        target_line_mode = _validated_provenance(
            "target_line_mode",
            self.target_line_mode,
            _TARGET_LINE_MODES,
        )
        target_line_curvature_model = _validated_provenance(
            "target_line_curvature_model",
            self.target_line_curvature_model,
            _TARGET_LINE_CURVATURE_MODELS,
        )
        if (
            target_line_curvature_model
            != _TARGET_LINE_CURVATURE_MODEL_BY_MODE[target_line_mode]
        ):
            raise ValueError(
                "target_line_curvature_model does not match target_line_mode"
            )
        object.__setattr__(self, "target_line_mode", target_line_mode)
        object.__setattr__(
            self,
            "target_line_curvature_model",
            target_line_curvature_model,
        )

        source_lane_index = self.lane_bounds_source_lane_index
        if source_lane_index is not None:
            if isinstance(source_lane_index, bool) or not isinstance(
                source_lane_index,
                Integral,
            ):
                raise TypeError(
                    "lane_bounds_source_lane_index must be an integer or None"
                )
            source_lane_index = int(source_lane_index)
            if source_lane_index == 0:
                raise ValueError(
                    "lane_bounds_source_lane_index 0 is not a physical lane"
                )
            object.__setattr__(
                self,
                "lane_bounds_source_lane_index",
                source_lane_index,
            )

        lane_bounds_mode = self.lane_bounds_mode
        if lane_bounds_mode is None:
            if any(lane_fields_present) or source_lane_index is not None:
                raise ValueError(
                    "lane_bounds_mode=None requires absent lane arrays and source index"
                )
            return
        lane_bounds_mode = _validated_provenance(
            "lane_bounds_mode",
            lane_bounds_mode,
            _LANE_BOUNDS_MODES,
        )
        object.__setattr__(self, "lane_bounds_mode", lane_bounds_mode)
        if not all(lane_fields_present):
            raise ValueError("a lane_bounds_mode requires all three lane arrays")
        if lane_bounds_mode == "reference_lane":
            if source_lane_index is not None:
                raise ValueError(
                    "reference_lane bounds require no source lane index"
                )
        else:
            if source_lane_index is None:
                raise ValueError(
                    f"{lane_bounds_mode} requires a source lane index"
                )
            if (
                lane_bounds_mode == "target_line_lane"
                and target_line_mode != "lane_center"
            ):
                raise ValueError(
                    "target_line_lane bounds require target_line_mode='lane_center'"
                )
