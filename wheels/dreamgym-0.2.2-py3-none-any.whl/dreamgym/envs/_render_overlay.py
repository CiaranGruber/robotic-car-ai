"""Dependency-light private primitives for autonomous-driving render overlays."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral

import numpy as np


_OVERLAY_POLYLINE_SEMANTICS = frozenset(
    {
        "formulation_target",
        "predicted_path",
        "executed_predicted_segment",
        "sensor_preview",
        "lane_right",
        "lane_left",
        "predicted_heading",
    }
)
_OVERLAY_MARKER_SEMANTICS = frozenset(
    {
        "prediction_node",
        "first_predicted_state",
        "sensor_preview_sample",
    }
)
_MAX_OVERLAY_STATUS_LINES = 4
_MAX_OVERLAY_STATUS_LINE_CHARACTERS = 120


def _read_only_float64_copy(value, *, shape, name: str) -> np.ndarray:
    try:
        array = np.array(value, dtype=np.float64, copy=True)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite numeric array.") from exc
    if not shape(array):
        raise ValueError(f"{name} has an invalid shape {array.shape}.")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must contain only finite values.")
    array.setflags(write=False)
    return array


def _validated_nonnegative_integer(value, *, name: str) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
        raise ValueError(f"{name} must be a nonnegative integer.")
    result = int(value)
    if result < 0:
        raise ValueError(f"{name} must be a nonnegative integer.")
    return result


def _validated_semantic(value, *, vocabulary, name: str) -> str:
    if not isinstance(value, str) or value not in vocabulary:
        raise ValueError(f"{name} must be one of {sorted(vocabulary)}.")
    return value


@dataclass(frozen=True, slots=True)
class _RenderOverlayPolyline:
    positions_metres: np.ndarray
    semantic: str

    def __post_init__(self) -> None:
        positions = _read_only_float64_copy(
            self.positions_metres,
            shape=lambda array: array.ndim == 2
            and array.shape[0] >= 2
            and array.shape[1] == 2,
            name="positions_metres",
        )
        semantic = _validated_semantic(
            self.semantic,
            vocabulary=_OVERLAY_POLYLINE_SEMANTICS,
            name="polyline semantic",
        )
        object.__setattr__(self, "positions_metres", positions)
        object.__setattr__(self, "semantic", semantic)


@dataclass(frozen=True, slots=True)
class _RenderOverlayMarker:
    position_metres: np.ndarray
    semantic: str
    heading_radians: float | None = None

    def __post_init__(self) -> None:
        position = _read_only_float64_copy(
            self.position_metres,
            shape=lambda array: array.shape == (2,),
            name="position_metres",
        )
        semantic = _validated_semantic(
            self.semantic,
            vocabulary=_OVERLAY_MARKER_SEMANTICS,
            name="marker semantic",
        )
        heading = self.heading_radians
        if heading is not None:
            try:
                heading = float(heading)
            except (TypeError, ValueError) as exc:
                raise ValueError("heading_radians must be finite or None.") from exc
            if not np.isfinite(heading):
                raise ValueError("heading_radians must be finite or None.")
        object.__setattr__(self, "position_metres", position)
        object.__setattr__(self, "semantic", semantic)
        object.__setattr__(self, "heading_radians", heading)


@dataclass(frozen=True, slots=True)
class _AutonomousDrivingRenderOverlaySnapshot:
    episode_generation: int
    transition_index: int
    polylines: tuple[_RenderOverlayPolyline, ...]
    markers: tuple[_RenderOverlayMarker, ...]
    status_lines: tuple[str, ...]

    def __post_init__(self) -> None:
        generation = _validated_nonnegative_integer(
            self.episode_generation,
            name="episode_generation",
        )
        transition = _validated_nonnegative_integer(
            self.transition_index,
            name="transition_index",
        )
        polylines = tuple(self.polylines)
        markers = tuple(self.markers)
        status_lines = tuple(self.status_lines)
        if not all(isinstance(item, _RenderOverlayPolyline) for item in polylines):
            raise TypeError("polylines must contain only _RenderOverlayPolyline values.")
        if not all(isinstance(item, _RenderOverlayMarker) for item in markers):
            raise TypeError("markers must contain only _RenderOverlayMarker values.")
        if len(status_lines) > _MAX_OVERLAY_STATUS_LINES:
            raise ValueError(
                f"status_lines may contain at most {_MAX_OVERLAY_STATUS_LINES} lines."
            )
        for line in status_lines:
            if (
                not isinstance(line, str)
                or not line.strip()
                or "\n" in line
                or "\r" in line
                or len(line) > _MAX_OVERLAY_STATUS_LINE_CHARACTERS
            ):
                raise ValueError(
                    "Each status line must be a nonempty single-line string with at "
                    f"most {_MAX_OVERLAY_STATUS_LINE_CHARACTERS} characters."
                )
        object.__setattr__(self, "episode_generation", generation)
        object.__setattr__(self, "transition_index", transition)
        object.__setattr__(self, "polylines", polylines)
        object.__setattr__(self, "markers", markers)
        object.__setattr__(self, "status_lines", status_lines)
