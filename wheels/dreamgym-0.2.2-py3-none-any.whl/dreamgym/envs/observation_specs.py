"""Immutable observation-registry metadata for the public runtime fields."""

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Iterable, Optional, Tuple

import numpy as np


OBSERVATION_FORMATS = ("dict", "flat")

ROAD_PREVIEW_LANE_RUNTIME_FIELDS = (
    "road_preview_right_lane_bound_offsets_from_target_line_m",
    "road_preview_left_lane_bound_offsets_from_target_line_m",
    "road_preview_lane_bounds_are_available",
)

CONE_DETECTION_RUNTIME_FIELDS = (
    "cone_detections_forward_positions_in_body_frame_m",
    "cone_detections_left_positions_in_body_frame_m",
    "cone_detections_color_ids",
    "cone_detections_count",
)

_OPERATIONAL_GROUND_TRUTH_DEFAULTS = MappingProxyType({
    "ground_truth_world_position_x_m": 0.0,
    "ground_truth_world_position_y_m": 0.0,
    "ground_truth_heading_in_world_frame_rad": 0.0,
    "ground_truth_body_longitudinal_velocity_mps": 0.0,
    "ground_truth_body_lateral_velocity_mps": 0.0,
    "ground_truth_yaw_rate_rad_per_s": 0.0,
    "ground_truth_front_wheel_steering_angle_rad": 0.0,
    "reference_line_progress_m": 0.0,
    "reference_line_road_element_index": 0,
    "lateral_error_from_target_line_m": 0.0,
    "heading_error_from_target_line_rad": 0.0,
    "target_line_curvature_per_m": 0.0,
    "speed_limit_mps": 0.0,
    "recommended_speed_mps": 0.0,
})

_FULL_ONLY_GROUND_TRUTH_SCALAR_DEFAULTS = MappingProxyType({
    "target_line_offset_from_reference_line_m": 0.0,
    "lateral_error_from_reference_line_m": 0.0,
})


def _new_ground_truth_retained_state(mode, previous=None):
    """Build a fresh retained schema, preserving values shared with ``previous``."""

    retained = dict(_OPERATIONAL_GROUND_TRUTH_DEFAULTS)
    if mode == "full":
        retained.update(_FULL_ONLY_GROUND_TRUTH_SCALAR_DEFAULTS)
        retained.update({
            "reference_line_closest_point_position_in_body_frame_m": np.zeros(
                (2,), dtype=np.float32
            ),
            "target_line_position_at_closest_reference_line_progress_in_body_frame_m": np.zeros(
                (2,), dtype=np.float32
            ),
            "reference_line_closest_point_position_in_world_frame_m": np.zeros(
                (2,), dtype=np.float32
            ),
            "target_line_position_at_closest_reference_line_progress_in_world_frame_m": np.zeros(
                (2,), dtype=np.float32
            ),
            "target_line_lookahead_positions_in_body_frame_m": np.empty(
                (0, 2), dtype=np.float32
            ),
            "target_line_lookahead_curvatures_per_m": np.empty(
                (0,), dtype=np.float32
            ),
        })
    if previous is not None:
        for key in retained:
            if key in previous:
                retained[key] = previous[key]
    return retained


def _lookahead_coords_shape(env):
    return (2, env._lookahead_sample_count)


def _lookahead_curvatures_shape(env):
    return (env._lookahead_sample_count,)


def _road_preview_shape(env):
    return (env._road_preview_point_count,)


def _cone_array_shape(env):
    return (env._maximum_cone_detection_count,)


def _cone_count_shape(env):
    return (1,)


def _cone_color_nvec(env):
    return (
        [env.road.CONE_COLOR_PADDING_ID + 1]
        * env._maximum_cone_detection_count
    )


def _cone_color_start(env):
    return [0] * env._maximum_cone_detection_count


def _cone_count_nvec(env):
    return [env._maximum_cone_detection_count + 1]


def _cone_count_start(env):
    return [0]


def _ground_truth_delta_rate_limits_bracket_zero(env):
    lower, upper = env.car._physical_front_wheel_angle_rate_bounds_rad_per_s
    return float(lower) <= 0.0 <= float(upper)


def _ground_truth_delta_bounds(env):
    """Return raw steering limits for all valid reset and dynamic values."""

    if not _ground_truth_delta_rate_limits_bracket_zero(env):
        return -np.inf, np.inf
    limit = float(env.car._requested_front_wheel_angle_magnitude_limit_rad)
    offset = float(env.car._physical_front_wheel_angle_offset_from_request_rad)
    initial_bounds = env._initial_state_config["bounds"][
        "front_wheel_steering_angle_rad"
    ]
    return (
        min(-limit, -limit + offset, initial_bounds["lower"]),
        max(limit, limit + offset, initial_bounds["upper"]),
    )


def _ground_truth_delta_low(env):
    return _ground_truth_delta_bounds(env)[0]


def _ground_truth_delta_high(env):
    return _ground_truth_delta_bounds(env)[1]


@dataclass(frozen=True)
class ObservationSpec:
    """One public runtime field and its writer metadata."""

    name: str
    record_path: Tuple[str, ...]
    low: Any
    high: Any
    shape: Any
    dtype: Any = np.float32
    space_kind: str = "box"
    writer_group: Optional[str] = None
    writer_key: Optional[str] = None
    road_result_field: Optional[str] = None
    error_names: Tuple[str, ...] = ()
    supports_scaling: bool = True
    nvec: Optional[Any] = None
    start: Optional[Any] = None


@dataclass(frozen=True)
class CompiledObservationRecord:
    """Detached step-time routing/scaling/error data for one registry position."""

    spec: ObservationSpec
    destination: str
    scaling_factor: Optional[float]
    error_values: Tuple[float, ...]

    def error(self, name: str) -> float:
        try:
            index = self.spec.error_names.index(name)
        except ValueError as error:
            raise KeyError(name) from error
        return self.error_values[index]


def _spec(
    name,
    low,
    high,
    shape,
    *,
    record_path=None,
    **kwargs,
):
    if record_path is None:
        record_path = (name,)
    return ObservationSpec(
        name=name,
        record_path=tuple(record_path),
        low=low,
        high=high,
        shape=shape,
        **kwargs,
    )


# The order is the normative 38-row relative order plus the three specified
# insertions.
OBSERVATION_SPECS = (
    _spec("ground_truth_world_position_x_m", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="px"),
    _spec("ground_truth_world_position_y_m", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="py"),
    _spec("ground_truth_heading_in_world_frame_rad", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="theta"),
    _spec("ground_truth_body_longitudinal_velocity_mps", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="vx"),
    _spec("ground_truth_body_lateral_velocity_mps", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="vy"),
    _spec("ground_truth_yaw_rate_rad_per_s", -np.inf, np.inf, (1,), writer_group="ground_truth_state", writer_key="omega"),
    _spec("ground_truth_front_wheel_steering_angle_rad", _ground_truth_delta_low, _ground_truth_delta_high, (1,), writer_group="ground_truth_state", writer_key="delta"),
    _spec("reference_line_progress_m", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="reference_progress"),
    _spec("body_longitudinal_velocity_mps", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="vx_sensor", error_names=("bias_mps", "noise_standard_deviation_mps")),
    _spec("front_wheel_steering_angle_rad", -0.5 * np.pi, 0.5 * np.pi, (1,), writer_group="scalar", writer_key="steering_sensor", error_names=("bias_rad", "noise_standard_deviation_rad", "resolution_rad")),
    _spec("lateral_error_from_target_line_m", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="lateral_error_target", error_names=("bias_m", "noise_standard_deviation_m")),
    _spec("heading_error_from_target_line_rad", -np.pi, np.pi, (1,), writer_group="scalar", writer_key="heading_target", error_names=("bias_rad", "noise_standard_deviation_rad")),
    _spec("target_line_offset_from_reference_line_m", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="target_offset", error_names=("bias_m", "noise_standard_deviation_m")),
    _spec("lateral_error_from_reference_line_m", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="lateral_error_reference", error_names=("bias_m", "noise_standard_deviation_m")),
    _spec("yaw_rate_rad_per_s", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="heading_gyro", error_names=("bias_rad_per_s", "noise_standard_deviation_rad_per_s")),
    _spec("body_longitudinal_acceleration_mps2", -np.inf, np.inf, (1,), writer_group="accel", writer_key="x"),
    _spec("body_lateral_acceleration_mps2", -np.inf, np.inf, (1,), writer_group="accel", writer_key="y"),
    _spec("target_line_position_at_closest_reference_line_progress_in_body_frame_m", -np.inf, np.inf, (2,), writer_group="vector", writer_key="target_line_closest_point", error_names=("bias_m", "noise_standard_deviation_m")),
    _spec("reference_line_closest_point_position_in_body_frame_m", -np.inf, np.inf, (2,), writer_group="vector", writer_key="reference_line_closest_point", error_names=("bias_m", "noise_standard_deviation_m")),
    _spec("target_line_lookahead_positions_in_body_frame_m", -np.inf, np.inf, _lookahead_coords_shape, record_path=("target_line_lookahead", "positions_in_body_frame_m"), writer_group="vector", writer_key="lookahead_target_line_coords", road_result_field="target_line_lookahead.positions_in_body_frame_m"),
    _spec("target_line_curvature_per_m", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="target_curvature", error_names=("bias_per_m", "noise_standard_deviation_per_m")),
    _spec("target_line_lookahead_curvatures_per_m", -np.inf, np.inf, _lookahead_curvatures_shape, record_path=("target_line_lookahead", "curvatures_per_m"), writer_group="vector", writer_key="lookahead_target_line_curvatures", road_result_field="target_line_lookahead.curvatures_per_m"),
    _spec("road_preview_target_line_curvatures_per_m", -np.inf, np.inf, _road_preview_shape, record_path=("road_preview", "target_line_curvatures_per_m"), writer_group="road_preview", writer_key="curvatures_per_m"),
    _spec("road_preview_recommended_speeds_mps", -np.inf, np.inf, _road_preview_shape, record_path=("road_preview", "recommended_speeds_mps"), writer_group="road_preview", writer_key="recommended_speeds_mps"),
    _spec("road_preview_speed_limits_mps", -np.inf, np.inf, _road_preview_shape, record_path=("road_preview", "speed_limits_mps"), writer_group="road_preview", writer_key="speed_limits_mps"),
    _spec("road_preview_right_lane_bound_offsets_from_target_line_m", -np.inf, np.inf, _road_preview_shape, record_path=("road_preview", "right_lane_bound_offsets_from_target_line_m"), writer_group="road_preview", writer_key="right_lane_bound_offsets_from_target_line_m"),
    _spec("road_preview_left_lane_bound_offsets_from_target_line_m", -np.inf, np.inf, _road_preview_shape, record_path=("road_preview", "left_lane_bound_offsets_from_target_line_m"), writer_group="road_preview", writer_key="left_lane_bound_offsets_from_target_line_m"),
    _spec("road_preview_is_spatially_valid", 0.0, 1.0, _road_preview_shape, record_path=("road_preview", "is_spatially_valid"), writer_group="road_preview", writer_key="is_spatially_valid", supports_scaling=False),
    _spec("road_preview_lane_bounds_are_available", 0.0, 1.0, _road_preview_shape, record_path=("road_preview", "lane_bounds_are_available"), writer_group="road_preview", writer_key="lane_bounds_are_available", supports_scaling=False),
    _spec("speed_limit_mps", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="speed_limit"),
    _spec("recommended_speed_mps", -np.inf, np.inf, (1,), writer_group="scalar", writer_key="recommended_speed"),
    _spec("next_speed_limit_change_value_mps", -np.inf, np.inf, (1,), record_path=("next_speed_limit_change", "value_mps"), writer_group="next_speed_change", writer_key="next_speed_limit"),
    _spec("next_speed_limit_change_reference_line_distance_m", -np.inf, np.inf, (1,), record_path=("next_speed_limit_change", "reference_line_distance_m"), writer_group="next_speed_change", writer_key="distance_to_next_speed_limit"),
    _spec("next_speed_limit_change_exists", 0.0, 1.0, (1,), record_path=("next_speed_limit_change", "exists"), writer_group="next_speed_change", writer_key="next_speed_limit_change_exists", supports_scaling=False),
    _spec("next_recommended_speed_change_value_mps", -np.inf, np.inf, (1,), record_path=("next_recommended_speed_change", "value_mps"), writer_group="next_speed_change", writer_key="next_recommended_speed"),
    _spec("next_recommended_speed_change_reference_line_distance_m", -np.inf, np.inf, (1,), record_path=("next_recommended_speed_change", "reference_line_distance_m"), writer_group="next_speed_change", writer_key="distance_to_next_recommended_speed"),
    _spec("next_recommended_speed_change_exists", 0.0, 1.0, (1,), record_path=("next_recommended_speed_change", "exists"), writer_group="next_speed_change", writer_key="next_recommended_speed_change_exists", supports_scaling=False),
    _spec("cone_detections_forward_positions_in_body_frame_m", -np.inf, np.inf, _cone_array_shape, record_path=("cone_detections", "positions_in_body_frame_m")),
    _spec("cone_detections_left_positions_in_body_frame_m", -np.inf, np.inf, _cone_array_shape, record_path=("cone_detections", "positions_in_body_frame_m")),
    _spec("cone_detections_color_ids", None, None, _cone_array_shape, record_path=("cone_detections", "color_ids"), dtype=np.int32, space_kind="multi_discrete", supports_scaling=False, nvec=_cone_color_nvec, start=_cone_color_start),
    _spec("cone_detections_count", None, None, _cone_count_shape, record_path=("cone_detections", "count"), dtype=np.int32, space_kind="multi_discrete", supports_scaling=False, nvec=_cone_count_nvec, start=_cone_count_start),
)


OBSERVATION_SPEC_BY_NAME = MappingProxyType(
    {spec.name: spec for spec in OBSERVATION_SPECS}
)


def resolve_spec_value(value, env):
    return value(env) if callable(value) else value


def resolve_spec_shape(spec, env):
    return tuple(resolve_spec_value(spec.shape, env))


def iter_observation_specs_by_writer_group(writer_group):
    for spec in OBSERVATION_SPECS:
        if spec.writer_group == writer_group:
            yield spec


def compile_observation_records(normalized_config):
    """Compile normalized nested public configuration into frozen writer data."""

    compiled = []
    for spec in OBSERVATION_SPECS:
        record = normalized_config
        for component in spec.record_path:
            record = record[component]
        compiled.append(
            CompiledObservationRecord(
                spec=spec,
                destination=record["destination"],
                scaling_factor=(
                    record["scaling_factor"] if spec.supports_scaling else None
                ),
                error_values=tuple(record[name] for name in spec.error_names),
            )
        )
    return tuple(compiled)


def observation_names() -> Iterable[str]:
    return tuple(spec.name for spec in OBSERVATION_SPECS)
