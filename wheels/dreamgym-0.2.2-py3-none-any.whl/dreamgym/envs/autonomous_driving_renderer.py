"""Pygame-backed rendering for AutonomousDrivingEnv."""

from __future__ import annotations

import math
import warnings
from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType

from gymnasium.error import DependencyNotInstalled
import numpy as np

from dreamgym.envs.config_validation import strict_positive_int
from dreamgym.visualization.autonomous_driving._road_presentation import (
    _ROAD_LITERAL_COLORS,
    _cadence_for_pattern,
    _calibrate_marking,
    _cone_color,
    _iter_lane_markings,
    _marking_components,
    _marking_signature,
    _resolve_marking_color,
    _resolve_marking_colors,
    _resolve_road_presentation_style,
    _segment_world_polyline,
    _surface_color,
)
from dreamgym.visualization.autonomous_driving.theme import (
    AutonomousDrivingVisualizationTheme,
)


_BASE_LINE_WIDTH_PX = 3
_BASE_MARKER_RADIUS_PX = 3
_BASE_FONT_SIZE_PX = 16
_OVERLAY_STATUS_MARGIN_PX = 8
_OVERLAY_STATUS_PADDING_PX = 5
_OVERLAY_SCREEN_CLIP_MARGIN_PX = 32768


@dataclass(frozen=True, slots=True)
class _NativeRoadMarkingComponent:
    extra_offset_m: float
    pattern: str
    cadence_m: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class _NativeRoadMarkingStyle:
    color: tuple[int, int, int, int]
    line_width_px: int
    outline_width_px: int
    components: tuple[_NativeRoadMarkingComponent, ...]


def _metadata_markings(road_metadata):
    for metadata in road_metadata:
        yield from _iter_lane_markings(metadata["lane_markings"])


def _contiguous_presentation_runs(records, signature):
    """Yield drawable slices without crossing gaps or presentation boundaries."""
    run_start = None
    run_signature = None
    run_record = None
    for index, record in enumerate(records):
        if record is None:
            if run_start is not None and index - run_start >= 2:
                yield run_start, index, run_record
            run_start = None
            run_signature = None
            run_record = None
            continue

        record_signature = signature(record)
        if run_start is None:
            run_start = index
            run_signature = record_signature
            run_record = record
            continue
        if record_signature == run_signature:
            continue

        if index - run_start >= 2:
            yield run_start, index, run_record
        run_start = index
        run_signature = record_signature
        run_record = record

    if run_start is not None and len(records) - run_start >= 2:
        yield run_start, len(records), run_record


def _import_pygame():
    try:
        import pygame
    except ImportError as exc:
        raise DependencyNotInstalled(
            "pygame is required for dreamgym render_mode='human' and "
            "render_mode='rgb_array'. Install it with: "
            "python -m pip install -e \".[render]\""
        ) from exc
    return pygame


class PygameAutonomousDrivingRenderer:
    def __init__(
        self,
        env,
        render_mode: str,
        render_config: Mapping[str, object],
        visualization_theme: AutonomousDrivingVisualizationTheme,
    ):
        if not isinstance(visualization_theme, AutonomousDrivingVisualizationTheme):
            raise TypeError(
                "visualization_theme must be an AutonomousDrivingVisualizationTheme"
            )
        self.env = env
        self.render_mode = render_mode
        self.visualization_theme = visualization_theme
        self.config = render_config
        self._road_style = _resolve_road_presentation_style(visualization_theme)
        road_metadata = getattr(
            self.env.road, "get_road_element_lane_metadata", lambda: ()
        )()
        self._resolved_marking_colors = dict(
            _resolve_marking_colors(road_metadata, self._road_style)
        )
        self.pygame = _import_pygame()
        self.render_fps = strict_positive_int(
            env.metadata.get("render_fps", 20),
            "render_fps",
        )
        self._build_native_styles(road_metadata)
        self.width_px, self.height_px = self.config["frame_size_px"]
        self.screen = None
        self.clock = None
        self._overlay_font = None
        self._initialized_overlay_font = False
        self._owns_display_subsystem = False
        self._window_closed_by_user = False
        self.surface = self.pygame.Surface((self.width_px, self.height_px))

        if self.render_mode == "human":
            try:
                self._owns_display_subsystem = not self.pygame.display.get_init()
                if self._owns_display_subsystem:
                    self.pygame.display.init()
                self.screen = self.pygame.display.set_mode(
                    (self.width_px, self.height_px)
                )
                self.clock = self.pygame.time.Clock()
            except BaseException:
                try:
                    self.close()
                except BaseException:
                    pass
                raise

    def _native_color(self, color, opacity=1.0):
        resolved = self.pygame.Color(color)
        return (
            resolved.r,
            resolved.g,
            resolved.b,
            int(round(255.0 * float(opacity))),
        )

    @staticmethod
    def _line_width(scale, *, base=_BASE_LINE_WIDTH_PX):
        return max(1, int(round(float(base) * float(scale))))

    @staticmethod
    def _marker_radius(scale, *, base=_BASE_MARKER_RADIUS_PX):
        return max(1, int(round(float(base) * float(scale))))

    def _build_native_styles(self, road_metadata):
        theme = self.visualization_theme
        road_style = self._road_style
        self._canvas_color = self._native_color(
            theme.canvas.world_background_color
        )[:3]
        self._surface_colors = {
            token: self._native_color(
                _surface_color(token, road_style), road_style.surface_opacity
            )
            for token, _ in road_style.surface_colors
        }
        self._fallback_surface_color = self._native_color(
            road_style.fallback_surface_color, road_style.surface_opacity
        )
        self._cone_colors = {
            token: self._native_color(_cone_color(token, road_style))
            for token, _ in road_style.cone_colors
        }
        self._marking_colors = {
            None: self._native_color(
                road_style.default_marking_color, road_style.marking_opacity
            ),
            **{
                literal: self._native_color(
                    _resolve_marking_color({"color": literal}, road_style),
                    road_style.marking_opacity,
                )
                for literal in _ROAD_LITERAL_COLORS
            },
        }
        self._marking_colors.update(
            {
                key: self._native_color(color, road_style.marking_opacity)
                for key, color in self._resolved_marking_colors.items()
            }
        )
        self._marking_outline_color = self._native_color(
            road_style.marking_outline_color, road_style.marking_opacity
        )
        self._cone_outline_color = self._native_color(
            road_style.cone_outline_color
        )
        self._vehicle_fill = self._native_color(
            theme.vehicle.fill_color, theme.vehicle.fill_opacity
        )
        self._vehicle_outline = self._native_color(theme.vehicle.outline_color)
        self._cone_radius_px = self._marker_radius(
            road_style.cone_marker_scale, base=4
        )
        self._cone_outline_width_px = (
            self._line_width(road_style.cone_outline_scale, base=2)
            if road_style.cone_outline_scale
            else 0
        )
        self._vehicle_outline_width_px = (
            self._line_width(theme.vehicle.outline_scale, base=2)
            if theme.vehicle.outline_scale
            else 0
        )
        self._pattern_cadences = {
            pattern: _cadence_for_pattern(pattern, road_style)
            for pattern in ("solid", "dashed", "dotted", "dash_dot")
        }
        native_marking_styles = {}
        for marking in _metadata_markings(road_metadata):
            signature = _marking_signature(marking)
            if signature in native_marking_styles:
                continue
            width_m, _, line_scale, outline_scale = _calibrate_marking(
                marking, road_style
            )
            line_width_px = max(1, int(round(width_m * 10.0 * line_scale)))
            outline_width_px = (
                max(1, int(round(line_width_px * outline_scale)))
                if outline_scale
                else 0
            )
            native_marking_styles[signature] = _NativeRoadMarkingStyle(
                color=self._marking_colors[signature[1]],
                line_width_px=line_width_px,
                outline_width_px=outline_width_px,
                components=tuple(
                    _NativeRoadMarkingComponent(
                        extra_offset_m=float(extra_offset_m),
                        pattern=pattern,
                        cadence_m=tuple(self._pattern_cadences[pattern]),
                    )
                    for extra_offset_m, pattern in _marking_components(0.0, marking)
                ),
            )
        self._road_marking_styles = MappingProxyType(native_marking_styles)

        line_themes = {
            "formulation_target": theme.mpc.formulation_target,
            "sensor_preview": theme.mpc.sensor_preview,
            "lane_right": theme.mpc.lane_envelope,
            "lane_left": theme.mpc.lane_envelope,
            "predicted_path": theme.mpc.predicted_path,
            "predicted_heading": theme.mpc.predicted_headings,
            "executed_predicted_segment": theme.mpc.executed_segment,
        }
        self._overlay_polyline_styles = {
            semantic: {
                "color": self._native_color(style.color, style.opacity),
                "width_px": self._line_width(style.line_scale),
                "cadence_m": self._pattern_cadences[style.pattern],
            }
            for semantic, style in line_themes.items()
        }
        marker_themes = {
            "sensor_preview_sample": theme.mpc.sensor_preview,
            "prediction_node": theme.mpc.prediction_nodes,
            "first_predicted_state": theme.mpc.first_predicted_state,
        }
        self._overlay_marker_styles = {
            semantic: {
                "color": self._native_color(style.color, style.opacity),
                "radius_px": self._marker_radius(style.marker_scale),
                "shape": style.shape,
                "outline_color": self._native_color(style.outline_color)
                if getattr(style, "outline_color", None) is not None
                else None,
                "outline_width_px": self._line_width(style.outline_scale)
                if getattr(style, "outline_scale", None)
                else 0,
            }
            for semantic, style in marker_themes.items()
        }
        annotations = theme.annotations
        panel_style = annotations.panel_style
        self._status_style = {
            "text": self._native_color(annotations.text_color),
            "face": self._native_color(
                panel_style.background_color,
                panel_style.background_opacity,
            ),
            "border": self._native_color(panel_style.border_color),
            "border_width_px": self._line_width(
                panel_style.border_line_scale
            ),
            "font_size_px": max(
                1, int(round(_BASE_FONT_SIZE_PX * annotations.font_scale))
            ),
            "font_family": panel_style.font_family,
        }

    @property
    def window_closed_by_user(self) -> bool:
        return self._window_closed_by_user

    def render_frame(self) -> np.ndarray | None:
        if self.render_mode == "human":
            if self.window_closed_by_user:
                return None
            if self._pump_events():
                return None

        self._draw_scene()
        frame = self._surface_to_rgb_array()

        if self.render_mode == "human":
            if self.screen is not None:
                self.screen.blit(self.surface, (0, 0))
                self.pygame.display.flip()
            if self.clock is not None:
                self.clock.tick(self.render_fps)

        return frame

    def close(self) -> None:
        self._overlay_font = None
        self.screen = None
        self.clock = None
        primary_error = None
        if self._initialized_overlay_font:
            self._initialized_overlay_font = False
            try:
                self.pygame.font.quit()
            except BaseException as error:
                primary_error = error
        if self._owns_display_subsystem:
            self._owns_display_subsystem = False
            try:
                self.pygame.display.quit()
            except BaseException as error:
                if primary_error is None:
                    primary_error = error
        if primary_error is not None:
            raise primary_error

    def _close_from_user(self) -> None:
        self._window_closed_by_user = True
        try:
            self.close()
        finally:
            warnings.warn(
                "The pygame window was closed by the user; "
                "human rendering is disabled for this environment.",
                UserWarning,
                stacklevel=3,
            )

    def _pump_events(self) -> bool:
        for event in self.pygame.event.get():
            if event.type == self.pygame.QUIT:
                self._close_from_user()
                return True
        return False

    def _draw_scene(self) -> None:
        self.surface.fill(self._canvas_color)
        self._scene_progress = self._progress_samples()
        self._scene_cross_sections = self.env.road.get_cross_sections_at_progresses(
            self._scene_progress
        )
        handlers = {
            "edge_bands": self._draw_edge_bands,
            "lane_surfaces": self._draw_lane_surfaces,
            "road_markings": self._draw_road_markings,
            "cones": self._draw_cones,
            "lane_envelope": lambda: self._draw_overlay_layer("lane_envelope"),
            "sensor_preview": lambda: self._draw_overlay_layer("sensor_preview"),
            "predicted_path": lambda: self._draw_overlay_layer("predicted_path"),
            "predicted_headings": lambda: self._draw_overlay_layer("predicted_headings"),
            "executed_segment": lambda: self._draw_overlay_layer("executed_segment"),
            "formulation_target": lambda: self._draw_overlay_layer("formulation_target"),
            "prediction_nodes": lambda: self._draw_overlay_layer("prediction_nodes"),
            "sensor_markers": lambda: self._draw_overlay_layer("sensor_markers"),
            "first_predicted_state": lambda: self._draw_overlay_layer("first_predicted_state"),
            "vehicle": self._draw_car,
            "annotations": self._draw_annotations,
            "hud": self._draw_hud,
        }
        try:
            for layer in self.visualization_theme.layer_order:
                handler = handlers.get(layer)
                if handler is None:
                    continue
                layer_surface = self.pygame.Surface(
                    (self.width_px, self.height_px), flags=self.pygame.SRCALPHA
                )
                self._layer_surface = layer_surface
                handler()
                self.surface.blit(layer_surface, (0, 0))
        finally:
            self._layer_surface = None
            self._scene_progress = None
            self._scene_cross_sections = None

    def _target_surface(self):
        return getattr(self, "_layer_surface", None) or self.surface

    def _draw_overlay(self) -> None:
        for layer in self.visualization_theme.layer_order:
            self._draw_overlay_layer(layer)
        self._draw_hud()

    def _active_overlay_snapshot(self):
        snapshot = getattr(self.env, "_render_overlay_snapshot", None)
        if snapshot is None:
            return None
        active_generation = getattr(
            self.env,
            "_render_overlay_episode_generation",
            None,
        )
        if snapshot.episode_generation != active_generation:
            self.env._render_overlay_snapshot = None
            return None
        return snapshot

    def _draw_overlay_layer(self, layer) -> None:
        snapshot = self._active_overlay_snapshot()
        if snapshot is None:
            return
        polyline_semantics = {
            "lane_envelope": ("lane_right", "lane_left"),
            "sensor_preview": ("sensor_preview",),
            "predicted_path": ("predicted_path",),
            "predicted_headings": ("predicted_heading",),
            "executed_segment": ("executed_predicted_segment",),
            "formulation_target": ("formulation_target",),
        }
        marker_semantics = {
            "prediction_nodes": ("prediction_node",),
            "sensor_markers": ("sensor_preview_sample",),
            "first_predicted_state": ("first_predicted_state",),
        }
        surface = self._target_surface()
        for semantic in polyline_semantics.get(layer, ()):
            for polyline in snapshot.polylines:
                if polyline.semantic == semantic:
                    self._draw_overlay_polyline(surface, polyline)
        for semantic in marker_semantics.get(layer, ()):
            for marker in snapshot.markers:
                if marker.semantic == semantic:
                    self._draw_overlay_marker(surface, marker)

    def _draw_annotations(self) -> None:
        # The current live snapshot has no independent annotation primitive.
        return None

    def _draw_hud(self) -> None:
        snapshot = self._active_overlay_snapshot()
        if snapshot is not None:
            self._draw_overlay_status(self._target_surface(), snapshot.status_lines)

    def _overlay_world_to_screen(self, x: float, y: float) -> tuple[int, int]:
        center_x, center_y = self._camera_center()
        metres_per_px = max(
            self.config["view"]["minimum_width_m"] / self.width_px,
            self.config["view"]["minimum_height_m"] / self.height_px,
        )
        margin = _OVERLAY_SCREEN_CLIP_MARGIN_PX
        x = float(
            np.clip(
                x,
                center_x + (-margin - self.width_px / 2.0) * metres_per_px,
                center_x + (self.width_px / 2.0 + margin) * metres_per_px,
            )
        )
        y = float(
            np.clip(
                y,
                center_y - (self.height_px / 2.0 + margin) * metres_per_px,
                center_y - (-margin - self.height_px / 2.0) * metres_per_px,
            )
        )
        return (
            int(round(self.width_px / 2.0 + (x - center_x) / metres_per_px)),
            int(round(self.height_px / 2.0 - (y - center_y) / metres_per_px)),
        )

    def _draw_overlay_polyline(self, surface, polyline) -> None:
        style = self._overlay_polyline_styles[polyline.semantic]
        positions = np.asarray(polyline.positions_metres, dtype=np.float64)
        segments, _ = _segment_world_polyline(positions, style["cadence_m"])
        for segment in segments:
            if len(segment) < 2:
                continue
            points = [
                self._overlay_world_to_screen(float(x), float(y))
                for x, y in segment
            ]
            self.pygame.draw.lines(
                surface,
                style["color"],
                False,
                points,
                style["width_px"],
            )

    def _draw_overlay_marker(self, surface, marker) -> None:
        position = np.asarray(marker.position_metres, dtype=np.float64)
        if position.shape != (2,) or not np.all(np.isfinite(position)):
            return
        style = self._overlay_marker_styles[marker.semantic]
        center = self._overlay_world_to_screen(float(position[0]), float(position[1]))
        self._draw_marker_shape(surface, center, style)

    def _draw_marker_shape(self, surface, center, style) -> None:
        radius = style["radius_px"]
        color = style["color"]
        outline = style["outline_color"]
        outline_width = style["outline_width_px"]
        shape = style["shape"]
        if shape == "circle":
            if outline is not None and outline_width:
                self.pygame.draw.circle(surface, outline, center, radius + outline_width)
            self.pygame.draw.circle(surface, color, center, radius)
        elif shape == "square":
            rect = self.pygame.Rect(center[0] - radius, center[1] - radius, 2 * radius + 1, 2 * radius + 1)
            if outline is not None and outline_width:
                self.pygame.draw.rect(surface, outline, rect, width=outline_width)
            self.pygame.draw.rect(surface, color, rect.inflate(-2 * outline_width, -2 * outline_width) if outline_width else rect)
        elif shape == "diamond":
            points = ((center[0], center[1] - radius), (center[0] + radius, center[1]), (center[0], center[1] + radius), (center[0] - radius, center[1]))
            self.pygame.draw.polygon(surface, color, points)
            if outline is not None and outline_width:
                self.pygame.draw.polygon(surface, outline, points, width=outline_width)
        else:
            self.pygame.draw.line(surface, color, (center[0] - radius, center[1] - radius), (center[0] + radius, center[1] + radius), max(1, outline_width))
            self.pygame.draw.line(surface, color, (center[0] - radius, center[1] + radius), (center[0] + radius, center[1] - radius), max(1, outline_width))

    def _draw_overlay_status(self, surface, status_lines) -> None:
        if len(status_lines) == 0:
            return
        if not self.pygame.font.get_init():
            self._initialized_overlay_font = True
            self.pygame.font.init()
        font = getattr(self, "_overlay_font", None)
        if font is None:
            font_path = self.pygame.font.match_font(self._status_style["font_family"])
            font = self.pygame.font.Font(font_path, self._status_style["font_size_px"])
            self._overlay_font = font
        rendered_lines = [
            font.render(line, True, self._status_style["text"]) for line in status_lines
        ]
        line_height = max(line.get_height() for line in rendered_lines)
        content_width = max(line.get_width() for line in rendered_lines)
        padding = _OVERLAY_STATUS_PADDING_PX
        margin = _OVERLAY_STATUS_MARGIN_PX
        background = self.pygame.Rect(
            margin,
            margin,
            content_width + 2 * padding,
            line_height * len(rendered_lines) + 2 * padding,
        )
        self.pygame.draw.rect(surface, self._status_style["face"], background)
        self.pygame.draw.rect(
            surface,
            self._status_style["border"],
            background,
            width=self._status_style["border_width_px"],
        )
        for index, rendered in enumerate(rendered_lines):
            surface.blit(
                rendered,
                (margin + padding, margin + padding + index * line_height),
            )

    def _surface_to_rgb_array(self) -> np.ndarray:
        pixels = self.pygame.surfarray.array3d(self.surface)
        return np.transpose(pixels, axes=(1, 0, 2)).astype(np.uint8, copy=False)

    def _camera_center(self) -> tuple[float, float]:
        view = self.config["view"]
        if view["mode"] == "fixed":
            return 0.5 * view["minimum_width_m"], 0.0
        px, py, _, _, _, _, _ = self.env.car._state_values()
        return float(px), float(py)

    def _world_to_screen(self, x: float, y: float) -> tuple[int, int]:
        center_x, center_y = self._camera_center()
        view = self.config["view"]
        meters_per_px = max(
            view["minimum_width_m"] / self.width_px,
            view["minimum_height_m"] / self.height_px,
        )
        screen_x = int(round(self.width_px / 2.0 + (x - center_x) / meters_per_px))
        screen_y = int(round(self.height_px / 2.0 - (y - center_y) / meters_per_px))
        return screen_x, screen_y

    def _draw_polyline(self, coords, color, width: int = 2) -> None:
        points = [self._world_to_screen(float(x), float(y)) for x, y in coords]
        if len(points) >= 2:
            self.pygame.draw.lines(self._target_surface(), color, False, points, width)

    def _draw_polygon(self, coords, color) -> None:
        points = [self._world_to_screen(float(x), float(y)) for x, y in coords]
        if len(points) >= 3:
            self.pygame.draw.polygon(self._target_surface(), color, points)

    def _progress_samples(self) -> np.ndarray:
        road_length = float(self.env.road.total_length_m)
        step = float(self.config["maximum_road_geometry_sample_spacing_m"])
        sample_count = max(2, int(math.ceil(road_length / step)) + 1)
        samples = np.linspace(0.0, road_length, sample_count, dtype=np.float64)
        get_element_ends = getattr(self.env.road, "get_l_total_at_end", None)
        if callable(get_element_ends):
            element_ends = np.asarray(get_element_ends(), dtype=np.float64).reshape(-1)
            element_ends = element_ends[
                np.isfinite(element_ends)
                & (element_ends >= 0.0)
                & (element_ends <= road_length)
            ]
            if element_ends.size:
                boundary_successors = np.nextafter(
                    element_ends.astype(np.float32),
                    np.float32(np.inf),
                ).astype(np.float64)
                boundary_successors = boundary_successors[
                    boundary_successors <= road_length
                ]
                samples = np.concatenate(
                    (samples, element_ends, boundary_successors)
                )
        return np.unique(samples).astype(np.float32, copy=False)

    def _draw_road(self) -> None:
        self._scene_progress = self._progress_samples()
        self._scene_cross_sections = self.env.road.get_cross_sections_at_progresses(
            self._scene_progress
        )
        self._draw_edge_bands()
        self._draw_lane_surfaces()
        self._draw_road_markings()
        self._draw_cones()

    def _road_scene(self):
        progress = getattr(self, "_scene_progress", None)
        cross_sections = getattr(self, "_scene_cross_sections", None)
        if progress is None or cross_sections is None:
            progress = self._progress_samples()
            cross_sections = self.env.road.get_cross_sections_at_progresses(progress)
        return progress, cross_sections

    def _draw_edge_bands(self) -> None:
        if not self.config["road_content"]["include_edge_bands"]:
            return
        progress, cross_sections = self._road_scene()
        for side in ("left", "right"):
            num_edge_bands = max(
                (len(section["edge_bands"][side]) for section in cross_sections),
                default=0,
            )
            for band_idx in range(num_edge_bands):
                bands = [
                    section["edge_bands"][side][band_idx]
                    if band_idx < len(section["edge_bands"][side])
                    else None
                    for section in cross_sections
                ]
                for run_start, run_end, band in _contiguous_presentation_runs(
                    bands, lambda candidate: str(candidate["surface"])
                ):
                    run = bands[run_start:run_end]
                    color = self._surface_colors.get(
                        str(band["surface"]), self._fallback_surface_color
                    )
                    self._draw_offset_band(
                        progress[run_start:run_end],
                        [candidate["lower_offset_m"] for candidate in run],
                        [candidate["upper_offset_m"] for candidate in run],
                        color,
                    )

    def _draw_lane_surfaces(self) -> None:
        if not self.config["road_content"]["include_lane_surfaces"]:
            return
        progress, cross_sections = self._road_scene()
        lane_indices = sorted({lane["lane_index"] for section in cross_sections for lane in section["lanes"]})
        for lane_index in lane_indices:
            lanes = [
                next(
                    (
                        candidate
                        for candidate in section["lanes"]
                        if candidate["lane_index"] == lane_index
                    ),
                    None,
                )
                for section in cross_sections
            ]
            for run_start, run_end, lane in _contiguous_presentation_runs(
                lanes, lambda candidate: str(candidate["surface"])
            ):
                run = lanes[run_start:run_end]
                color = self._surface_colors.get(
                    str(lane["surface"]), self._fallback_surface_color
                )
                self._draw_offset_band(
                    progress[run_start:run_end],
                    [candidate["lower_offset_m"] for candidate in run],
                    [candidate["upper_offset_m"] for candidate in run],
                    color,
                )

    def _draw_road_markings(self) -> None:
        road_content = self.config["road_content"]
        if not (
            road_content["include_reference_line"]
            or road_content["include_markings"]
        ):
            return
        progress, cross_sections = self._road_scene()
        line_indices = []
        for section in cross_sections:
            for line in section["lane_lines"]:
                if line["lane_line_index"] not in line_indices:
                    line_indices.append(line["lane_line_index"])
        for line_idx in line_indices:
            if line_idx == 0 and not road_content["include_reference_line"]:
                continue
            if line_idx != 0 and not road_content["include_markings"]:
                continue
            lane_lines = [
                next(
                    (
                        candidate
                        for candidate in section["lane_lines"]
                        if candidate["lane_line_index"] == line_idx
                    ),
                    None,
                )
                for section in cross_sections
            ]
            for run_start, run_end, lane_line in _contiguous_presentation_runs(
                lane_lines,
                lambda candidate: _marking_signature(candidate["marking"]),
            ):
                run = lane_lines[run_start:run_end]
                marking_style = self._road_marking_styles[
                    _marking_signature(lane_line["marking"])
                ]
                self._draw_lane_marking(
                    progress[run_start:run_end],
                    [candidate["offset_m"] for candidate in run],
                    marking_style,
                )

    def _draw_cones(self) -> None:
        if not self.config["road_content"]["include_cones"]:
            return
        surface = self._target_surface()
        for cone in self.env.road.get_cone_points_from_spec():
            center = self._world_to_screen(cone["px"], cone["py"])
            color = self._cone_colors[cone["color"]]
            if self._cone_outline_width_px:
                self.pygame.draw.circle(
                    surface,
                    self._cone_outline_color,
                    center,
                    self._cone_radius_px + self._cone_outline_width_px,
                )
            self.pygame.draw.circle(surface, color, center, self._cone_radius_px)

    def _draw_lane_marking(self, progress, center_offsets, marking_style) -> None:
        progress = np.asarray(progress, dtype=np.float32)
        center_offsets = np.asarray(center_offsets, dtype=np.float32)
        for component in marking_style.components:
            offsets = center_offsets + component.extra_offset_m
            finite_mask = np.isfinite(progress) & np.isfinite(offsets)
            if not np.any(finite_mask):
                continue

            run_start = None
            for idx, is_finite in enumerate(finite_mask):
                if is_finite and run_start is None:
                    run_start = idx
                    continue
                if is_finite:
                    continue
                if run_start is not None and (idx - run_start) >= 2:
                    coords = self.env.road.convert_progression_and_lateral_offsets_to_coordinates(
                        progress[run_start:idx],
                        offsets[run_start:idx],
                    )
                    if marking_style.outline_width_px:
                        self._draw_styled_polyline(
                            coords,
                            color=self._marking_outline_color,
                            width=(
                                marking_style.line_width_px
                                + 2 * marking_style.outline_width_px
                            ),
                            linestyle=component,
                        )
                    self._draw_styled_polyline(
                        coords,
                        color=marking_style.color,
                        width=marking_style.line_width_px,
                        linestyle=component,
                    )
                run_start = None

            if run_start is not None and (len(finite_mask) - run_start) >= 2:
                coords = self.env.road.convert_progression_and_lateral_offsets_to_coordinates(
                    progress[run_start:],
                    offsets[run_start:],
                )
                if marking_style.outline_width_px:
                    self._draw_styled_polyline(
                        coords,
                        color=self._marking_outline_color,
                        width=(
                            marking_style.line_width_px
                            + 2 * marking_style.outline_width_px
                        ),
                        linestyle=component,
                    )
                self._draw_styled_polyline(
                    coords,
                    color=marking_style.color,
                    width=marking_style.line_width_px,
                    linestyle=component,
                )

    def _draw_offset_band(self, progress, lower_offsets, upper_offsets, color) -> None:
        progress = np.asarray(progress, dtype=np.float32)
        lower_offsets = np.asarray(lower_offsets, dtype=np.float32)
        upper_offsets = np.asarray(upper_offsets, dtype=np.float32)
        finite_mask = (
            np.isfinite(progress)
            & np.isfinite(lower_offsets)
            & np.isfinite(upper_offsets)
        )
        if not np.any(finite_mask):
            return

        def draw_run(run_start: int, run_end: int) -> None:
            run_lower_offsets = lower_offsets[run_start:run_end]
            run_upper_offsets = upper_offsets[run_start:run_end]
            if np.all(np.abs(run_upper_offsets - run_lower_offsets) <= 1e-9):
                return

            lower = self.env.road.convert_progression_and_lateral_offsets_to_coordinates(
                progress[run_start:run_end],
                run_lower_offsets,
            )
            upper = self.env.road.convert_progression_and_lateral_offsets_to_coordinates(
                progress[run_start:run_end],
                run_upper_offsets,
            )
            coords = np.vstack((lower, upper[::-1]))
            self._draw_polygon(coords, color)

        run_start = None
        for idx, is_finite in enumerate(finite_mask):
            if is_finite and run_start is None:
                run_start = idx
                continue
            if is_finite:
                continue
            if run_start is not None and (idx - run_start) >= 2:
                draw_run(run_start, idx)
            run_start = None

        if run_start is not None and (len(finite_mask) - run_start) >= 2:
            draw_run(run_start, len(finite_mask))

    def _draw_styled_polyline(self, coords, color, width: int, linestyle: str) -> None:
        cadence_m = (
            linestyle.cadence_m
            if isinstance(linestyle, _NativeRoadMarkingComponent)
            else self._pattern_cadences[linestyle]
        )
        segments, _ = _segment_world_polyline(coords, cadence_m)
        for dash_coords in segments:
            self._draw_polyline(dash_coords, color, width=width)

    def _draw_car(self) -> None:
        car = self.env.car
        px, py, theta, _, _, _, _ = car._state_values()
        px = float(px)
        py = float(py)
        theta = float(theta)
        front_axle_distance_m = car._front_axle_distance_from_center_of_mass_m
        rear_axle_distance_m = car._rear_axle_distance_from_center_of_mass_m
        length = float(front_axle_distance_m + rear_axle_distance_m)
        width = max(0.8, 0.45 * length)
        local_corners = np.array(
            [
                [-rear_axle_distance_m, -0.5 * width],
                [front_axle_distance_m, -0.5 * width],
                [front_axle_distance_m, 0.5 * width],
                [-rear_axle_distance_m, 0.5 * width],
            ],
            dtype=np.float32,
        )
        c = math.cos(theta)
        s = math.sin(theta)
        rotation = np.array([[c, -s], [s, c]], dtype=np.float32)
        world_corners = local_corners @ rotation.T + np.array([px, py], dtype=np.float32)
        self._draw_polygon(world_corners, self._vehicle_fill)
        if self._vehicle_outline_width_px:
            self._draw_polyline(
                np.vstack((world_corners, world_corners[0])),
                self._vehicle_outline,
                width=self._vehicle_outline_width_px,
            )
