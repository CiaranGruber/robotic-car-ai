#!/usr/bin/env python

import copy
import math
import numpy as np

from dreamgym.envs.config_validation import (
    detached_mapping,
    finite_float,
    reject_unknown_keys,
    strict_bool,
    strict_positive_int,
)


_TOP_LEVEL_GROUPS = {
    "axle_geometry",
    "mass_properties",
    "longitudinal_force_model",
    "steering",
    "tire_force_model",
    "kinematic_dynamic_transition",
    "body_geometry",
}
_TIRE_FORCE_DEFAULTS = {
    "dry": {
        "peak_factor_d": 1.0,
        "shape_factor_c": 1.9,
        "stiffness_factor_b": 10.0,
        "curvature_factor_e": 0.97,
    },
    "wet": {
        "peak_factor_d": 0.82,
        "shape_factor_c": 2.3,
        "stiffness_factor_b": 12.0,
        "curvature_factor_e": 1.0,
    },
    "snow": {
        "peak_factor_d": 0.3,
        "shape_factor_c": 2.0,
        "stiffness_factor_b": 5.0,
        "curvature_factor_e": 1.0,
    },
    "ice": {
        "peak_factor_d": 0.1,
        "shape_factor_c": 2.0,
        "stiffness_factor_b": 4.0,
        "curvature_factor_e": 1.0,
    },
}
_TIRE_FORCE_CONDITIONS = ("dry", "wet", "snow", "ice", "custom")
_TIRE_FORCE_FACTOR_NAMES = (
    "peak_factor_d",
    "shape_factor_c",
    "stiffness_factor_b",
    "curvature_factor_e",
)
_EOM_ADVANCED_MOTOR_PARAMETER_NAMES = (
    "motor_model_flags",
    "motor_command_points",
    "motor_force_points",
    "motor_drive_force_max",
    "motor_max_power",
    "motor_min_power_limit_speed",
    "rolling_resistance_force",
    "rolling_resistance_deadband_speed",
)


def _required_group(config, group):
    path = "bicycle_model_config." + group
    if group not in config:
        raise ValueError(path + " is required.")
    return detached_mapping(config[group], path)


def _required_number(mapping, key, path):
    if key not in mapping:
        raise ValueError(path + "." + key + " is required.")
    return finite_float(mapping[key], path + "." + key)


def _strict_mapping(value, path):
    if value is None:
        raise TypeError(path + " must be a mapping.")
    return detached_mapping(value, path)


def _normalize_tire_force_model(raw):
    path = "bicycle_model_config.tire_force_model"
    supplied = _strict_mapping(raw, path)
    reject_unknown_keys(supplied, {"road_conditions"}, path)
    conditions_path = path + ".road_conditions"
    conditions = _strict_mapping(supplied.get("road_conditions", {}), conditions_path)
    reject_unknown_keys(conditions, _TIRE_FORCE_DEFAULTS, conditions_path)
    resolved = {}
    factor_names = set(next(iter(_TIRE_FORCE_DEFAULTS.values())))
    for condition, defaults in _TIRE_FORCE_DEFAULTS.items():
        condition_path = conditions_path + "." + condition
        overrides = _strict_mapping(conditions.get(condition, {}), condition_path)
        reject_unknown_keys(overrides, factor_names, condition_path)
        factors = {**defaults, **overrides}
        for key in factor_names:
            factors[key] = finite_float(factors[key], condition_path + "." + key)
        if factors["peak_factor_d"] < 0.0:
            raise ValueError(condition_path + ".peak_factor_d must be non-negative.")
        if factors["shape_factor_c"] <= 0.0:
            raise ValueError(condition_path + ".shape_factor_c must be greater than zero.")
        if factors["stiffness_factor_b"] < 0.0:
            raise ValueError(condition_path + ".stiffness_factor_b must be non-negative.")
        resolved[condition] = factors
    return {"road_conditions": resolved}


def _normalize_lookup_table(value, path):
    if isinstance(value, (str, bytes, bytearray)):
        raise TypeError(path + " must be a sequence of two-value rows.")
    try:
        rows = list(value)
    except TypeError as exc:
        raise TypeError(path + " must be a sequence of two-value rows.") from exc
    normalized = []
    for row_index, row in enumerate(rows):
        if isinstance(row, (str, bytes, bytearray)):
            raise TypeError(path + " must be a sequence of two-value rows.")
        try:
            values = list(row)
        except TypeError as exc:
            raise TypeError(path + " must be a sequence of two-value rows.") from exc
        if len(values) != 2:
            raise ValueError(path + " must contain two-value rows.")
        normalized.append(
            [
                finite_float(values[0], path + "[" + str(row_index) + "][0]"),
                finite_float(values[1], path + "[" + str(row_index) + "][1]"),
            ]
        )
    if len(normalized) < 2:
        raise ValueError(path + " must contain at least two points.")
    sorted_commands = sorted(row[0] for row in normalized)
    previous = None
    for command in sorted_commands:
        if command < -1.0 or command > 1.0:
            raise ValueError(path + " command points must be in [-1, 1].")
        if previous is not None and command <= previous:
            raise ValueError(path + " command points must be strictly unique.")
        previous = command
    return normalized


def _normalize_motor_command_map(raw, command_gain, path):
    supplied = detached_mapping(raw, path)
    source = supplied.get("source")
    if source not in {"generated", "lookup_table"}:
        raise ValueError(path + ".source must be 'generated' or 'lookup_table'.")
    if source == "lookup_table":
        reject_unknown_keys(supplied, {"source", "lookup_table"}, path)
        if "lookup_table" not in supplied:
            raise ValueError(path + ".lookup_table is required.")
        return {
            "source": "lookup_table",
            "lookup_table": _normalize_lookup_table(
                supplied["lookup_table"], path + ".lookup_table"
            ),
        }

    generated_keys = {
        "source",
        "normalized_command_deadband",
        "drive_force_at_full_command_n",
        "braking_force_magnitude_at_full_command_n",
        "drive_response_exponent",
        "braking_response_exponent",
        "per_command_side_point_count",
    }
    reject_unknown_keys(supplied, generated_keys, path)
    resolved = {
        "source": "generated",
        "normalized_command_deadband": supplied.get(
            "normalized_command_deadband", 0.0
        ),
        "drive_force_at_full_command_n": supplied.get(
            "drive_force_at_full_command_n", command_gain
        ),
        "braking_force_magnitude_at_full_command_n": supplied.get(
            "braking_force_magnitude_at_full_command_n", command_gain
        ),
        "drive_response_exponent": supplied.get("drive_response_exponent", 1.0),
        "braking_response_exponent": supplied.get(
            "braking_response_exponent", 1.0
        ),
        "per_command_side_point_count": supplied.get(
            "per_command_side_point_count", 5
        ),
    }
    for key in (
        "normalized_command_deadband",
        "drive_force_at_full_command_n",
        "braking_force_magnitude_at_full_command_n",
        "drive_response_exponent",
        "braking_response_exponent",
    ):
        resolved[key] = finite_float(resolved[key], path + "." + key)
    if not 0.0 <= resolved["normalized_command_deadband"] < 1.0:
        raise ValueError(path + ".normalized_command_deadband must be in [0, 1).")
    for key in (
        "drive_force_at_full_command_n",
        "braking_force_magnitude_at_full_command_n",
    ):
        if resolved[key] < 0.0:
            raise ValueError(path + "." + key + " must be non-negative.")
    for key in ("drive_response_exponent", "braking_response_exponent"):
        if resolved[key] <= 0.0:
            raise ValueError(path + "." + key + " must be greater than zero.")
    point_count = strict_positive_int(
        resolved["per_command_side_point_count"],
        path + ".per_command_side_point_count",
    )
    if point_count < 2:
        raise ValueError(path + ".per_command_side_point_count must be at least 2.")
    resolved["per_command_side_point_count"] = point_count
    return resolved


def _normalize_constant_force_limit(raw, path):
    supplied = detached_mapping(raw, path)
    source = supplied.get("source")
    if source == "direct_force":
        reject_unknown_keys(supplied, {"source", "force_n"}, path)
        force = _required_number(supplied, "force_n", path)
        if force < 0.0:
            raise ValueError(path + ".force_n must be non-negative.")
        return {"source": source, "force_n": force}
    if source == "motor_torque":
        allowed = {
            "source",
            "maximum_torque_per_motor_nm",
            "driven_wheel_radius_m",
            "motor_to_wheel_torque_ratio",
            "motor_count",
            "drivetrain_efficiency",
        }
        reject_unknown_keys(supplied, allowed, path)
        torque = _required_number(supplied, "maximum_torque_per_motor_nm", path)
        radius = _required_number(supplied, "driven_wheel_radius_m", path)
        ratio = finite_float(
            supplied.get("motor_to_wheel_torque_ratio", 1.0),
            path + ".motor_to_wheel_torque_ratio",
        )
        count = strict_positive_int(
            supplied.get("motor_count", 1), path + ".motor_count"
        )
        efficiency = finite_float(
            supplied.get("drivetrain_efficiency", 1.0),
            path + ".drivetrain_efficiency",
        )
        if torque < 0.0:
            raise ValueError(path + ".maximum_torque_per_motor_nm must be non-negative.")
        if radius <= 0.0:
            raise ValueError(path + ".driven_wheel_radius_m must be greater than zero.")
        if ratio <= 0.0:
            raise ValueError(
                path + ".motor_to_wheel_torque_ratio must be greater than zero."
            )
        if not 0.0 < efficiency <= 1.0:
            raise ValueError(path + ".drivetrain_efficiency must be in (0, 1].")
        return {
            "source": source,
            "maximum_torque_per_motor_nm": torque,
            "driven_wheel_radius_m": radius,
            "motor_to_wheel_torque_ratio": ratio,
            "motor_count": count,
            "drivetrain_efficiency": efficiency,
        }
    raise ValueError(path + ".source must be 'direct_force' or 'motor_torque'.")


def _normalize_drive_force_envelope(raw, path):
    supplied = _strict_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {
            "constant_force_limit",
            "maximum_power_w",
            "power_limit_longitudinal_speed_floor_mps",
        },
        path,
    )
    resolved = {}
    if "constant_force_limit" in supplied:
        resolved["constant_force_limit"] = _normalize_constant_force_limit(
            supplied["constant_force_limit"], path + ".constant_force_limit"
        )
    if "maximum_power_w" in supplied:
        maximum_power = finite_float(
            supplied["maximum_power_w"], path + ".maximum_power_w"
        )
        if maximum_power <= 0.0:
            raise ValueError(path + ".maximum_power_w must be greater than zero.")
        resolved["maximum_power_w"] = maximum_power
    speed_floor = finite_float(
        supplied.get("power_limit_longitudinal_speed_floor_mps", 0.5),
        path + ".power_limit_longitudinal_speed_floor_mps",
    )
    if speed_floor <= 0.0:
        raise ValueError(
            path
            + ".power_limit_longitudinal_speed_floor_mps must be greater than zero."
        )
    resolved["power_limit_longitudinal_speed_floor_mps"] = speed_floor
    return resolved


def _normalize_rolling_resistance(raw, path):
    supplied = _strict_mapping(raw, path)
    reject_unknown_keys(
        supplied,
        {
            "coefficient",
            "gravitational_acceleration_mps2",
            "body_longitudinal_speed_deadband_mps",
        },
        path,
    )
    resolved = {
        "coefficient": finite_float(
            supplied.get("coefficient", 0.0), path + ".coefficient"
        ),
        "gravitational_acceleration_mps2": finite_float(
            supplied.get("gravitational_acceleration_mps2", 9.81),
            path + ".gravitational_acceleration_mps2",
        ),
        "body_longitudinal_speed_deadband_mps": finite_float(
            supplied.get("body_longitudinal_speed_deadband_mps", 0.05),
            path + ".body_longitudinal_speed_deadband_mps",
        ),
    }
    if resolved["coefficient"] < 0.0:
        raise ValueError(path + ".coefficient must be non-negative.")
    if resolved["gravitational_acceleration_mps2"] <= 0.0:
        raise ValueError(
            path + ".gravitational_acceleration_mps2 must be greater than zero."
        )
    if resolved["body_longitudinal_speed_deadband_mps"] < 0.0:
        raise ValueError(
            path + ".body_longitudinal_speed_deadband_mps must be non-negative."
        )
    return resolved


def normalize_bicycle_model_config(config):
    path = "bicycle_model_config"
    supplied = detached_mapping(config, path)
    reject_unknown_keys(supplied, _TOP_LEVEL_GROUPS, path)

    axle_path = path + ".axle_geometry"
    axle = _required_group(supplied, "axle_geometry")
    reject_unknown_keys(
        axle,
        {
            "front_axle_distance_from_center_of_mass_m",
            "rear_axle_distance_from_center_of_mass_m",
        },
        axle_path,
    )
    front_axle = _required_number(
        axle, "front_axle_distance_from_center_of_mass_m", axle_path
    )
    rear_axle = _required_number(
        axle, "rear_axle_distance_from_center_of_mass_m", axle_path
    )
    if front_axle < 0.0 or rear_axle < 0.0:
        raise ValueError(axle_path + " distances must be non-negative.")
    if front_axle + rear_axle <= 0.0:
        raise ValueError(axle_path + " wheelbase must be greater than zero.")

    mass_path = path + ".mass_properties"
    mass = _required_group(supplied, "mass_properties")
    reject_unknown_keys(mass, {"mass_kg", "yaw_moment_of_inertia_kg_m2"}, mass_path)
    mass_kg = _required_number(mass, "mass_kg", mass_path)
    yaw_inertia = _required_number(mass, "yaw_moment_of_inertia_kg_m2", mass_path)
    if mass_kg <= 0.0 or yaw_inertia <= 0.0:
        raise ValueError(mass_path + " values must be greater than zero.")

    force_path = path + ".longitudinal_force_model"
    force = _required_group(supplied, "longitudinal_force_model")
    reject_unknown_keys(
        force,
        {
            "normalized_motor_command_force_gain_n",
            "quadratic_aerodynamic_drag_coefficient_kg_per_m",
            "motor_command_map",
            "drive_force_envelope",
            "rolling_resistance",
        },
        force_path,
    )
    command_gain = _required_number(
        force, "normalized_motor_command_force_gain_n", force_path
    )
    drag = _required_number(
        force, "quadratic_aerodynamic_drag_coefficient_kg_per_m", force_path
    )
    if command_gain < 0.0 or drag < 0.0:
        raise ValueError(force_path + " required values must be non-negative.")
    normalized_force = {
        "normalized_motor_command_force_gain_n": command_gain,
        "quadratic_aerodynamic_drag_coefficient_kg_per_m": drag,
    }
    if "motor_command_map" in force:
        normalized_force["motor_command_map"] = _normalize_motor_command_map(
            force["motor_command_map"],
            command_gain,
            force_path + ".motor_command_map",
        )
    if "drive_force_envelope" in force:
        normalized_force["drive_force_envelope"] = _normalize_drive_force_envelope(
            force["drive_force_envelope"], force_path + ".drive_force_envelope"
        )
    if "rolling_resistance" in force:
        normalized_force["rolling_resistance"] = _normalize_rolling_resistance(
            force["rolling_resistance"], force_path + ".rolling_resistance"
        )

    steering_path = path + ".steering"
    steering = _required_group(supplied, "steering")
    steering_keys = {
        "physical_front_wheel_angle_offset_from_request_rad",
        "requested_front_wheel_angle_magnitude_limit_rad",
        "physical_front_wheel_angle_rate_bounds_rad_per_s",
    }
    reject_unknown_keys(steering, steering_keys, steering_path)
    offset = _required_number(
        steering, "physical_front_wheel_angle_offset_from_request_rad", steering_path
    )
    request_limit = _required_number(
        steering, "requested_front_wheel_angle_magnitude_limit_rad", steering_path
    )
    if request_limit < 0.0:
        raise ValueError(
            steering_path
            + ".requested_front_wheel_angle_magnitude_limit_rad must be non-negative."
        )
    bounds_key = "physical_front_wheel_angle_rate_bounds_rad_per_s"
    if bounds_key not in steering:
        raise ValueError(steering_path + "." + bounds_key + " is required.")
    bounds_path = steering_path + "." + bounds_key
    bounds = detached_mapping(steering[bounds_key], bounds_path)
    reject_unknown_keys(bounds, {"lower", "upper"}, bounds_path)
    lower_rate = _required_number(bounds, "lower", bounds_path)
    upper_rate = _required_number(bounds, "upper", bounds_path)
    if lower_rate > upper_rate:
        raise ValueError(bounds_path + ".upper must be greater than or equal to lower.")

    transition_path = path + ".kinematic_dynamic_transition"
    transition = _strict_mapping(
        supplied.get("kinematic_dynamic_transition", {}), transition_path
    )
    reject_unknown_keys(transition, {"body_longitudinal_speed_range_mps"}, transition_path)
    speed_path = transition_path + ".body_longitudinal_speed_range_mps"
    speed_range = _strict_mapping(
        transition.get("body_longitudinal_speed_range_mps", {}), speed_path
    )
    reject_unknown_keys(speed_range, {"lower", "upper"}, speed_path)
    speed_lower = finite_float(speed_range.get("lower", 3.0), speed_path + ".lower")
    speed_upper = finite_float(speed_range.get("upper", 5.0), speed_path + ".upper")
    if speed_lower < 0.0:
        raise ValueError(speed_path + ".lower must be non-negative.")
    if speed_upper <= speed_lower:
        raise ValueError(speed_path + ".upper must be greater than lower.")

    body_path = path + ".body_geometry"
    body = _strict_mapping(supplied.get("body_geometry", {}), body_path)
    body_keys = {
        "front_extent_from_center_of_mass_m",
        "rear_extent_from_center_of_mass_m",
        "width_m",
    }
    reject_unknown_keys(body, body_keys, body_path)
    front_extent = finite_float(
        body.get("front_extent_from_center_of_mass_m", front_axle * 1.125),
        body_path + ".front_extent_from_center_of_mass_m",
    )
    rear_extent = finite_float(
        body.get("rear_extent_from_center_of_mass_m", rear_axle * 1.125),
        body_path + ".rear_extent_from_center_of_mass_m",
    )
    width = finite_float(
        body.get("width_m", (front_axle + rear_axle) * 0.4),
        body_path + ".width_m",
    )
    if front_extent < 0.0 or rear_extent < 0.0:
        raise ValueError(body_path + " extents must be non-negative.")
    if front_extent + rear_extent <= 0.0:
        raise ValueError(body_path + " extent sum must be greater than zero.")
    if width <= 0.0:
        raise ValueError(body_path + ".width_m must be greater than zero.")

    return {
        "axle_geometry": {
            "front_axle_distance_from_center_of_mass_m": front_axle,
            "rear_axle_distance_from_center_of_mass_m": rear_axle,
        },
        "mass_properties": {
            "mass_kg": mass_kg,
            "yaw_moment_of_inertia_kg_m2": yaw_inertia,
        },
        "longitudinal_force_model": normalized_force,
        "steering": {
            "physical_front_wheel_angle_offset_from_request_rad": offset,
            "requested_front_wheel_angle_magnitude_limit_rad": request_limit,
            "physical_front_wheel_angle_rate_bounds_rad_per_s": {
                "lower": lower_rate,
                "upper": upper_rate,
            },
        },
        "tire_force_model": _normalize_tire_force_model(
            supplied.get("tire_force_model", {})
        ),
        "kinematic_dynamic_transition": {
            "body_longitudinal_speed_range_mps": {
                "lower": speed_lower,
                "upper": speed_upper,
            }
        },
        "body_geometry": {
            "front_extent_from_center_of_mass_m": front_extent,
            "rear_extent_from_center_of_mass_m": rear_extent,
            "width_m": width,
        },
    }

class BicycleModelDynamic:
    """
    Dynamic bicycle model with nested public state and action records.

    For ``car = BicycleModelDynamic(config)``, ``car.state`` is the current
    public state mapping.  Its ``world_pose`` record contains ``x_m``, ``y_m``,
    and ``heading_rad``; its ``body_motion`` record contains longitudinal and
    lateral velocity plus yaw rate; and its remaining public leaf is
    ``front_wheel_steering_angle_rad``.

    Call ``car.set_action_request(normalized_drive_command,
    requested_front_wheel_angle_rad)`` before integration.  The model exposes
    ``car.resolved_action_request`` after public request clipping and
    ``car.current_model_action`` for the drive command and physical front-wheel
    angle rate used by the current integration step.

    ``config`` is normalized by :func:`normalize_bicycle_model_config` into
    nested geometry, mass, tire-force, transition, motor-command, and drive
    force-envelope records.  The model evolves that resolved configuration
    with the selected integration method.
    """

    INTEGRATION_METHODS = ("euler", "heun", "midpoint", "rk4", "rk45")
    MOTOR_FLAG_COMMAND_MAP = 1
    MOTOR_FLAG_SPEED_ENVELOPE = 2
    MOTOR_FLAG_ROLLING_RESISTANCE = 4

    @staticmethod
    def _finite_float(value, name):
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError(name + " must be a finite number.")
        if not np.isfinite(value):
            raise ValueError(name + " must be a finite number.")
        return value

    @staticmethod
    def _nonnegative_float(value, name):
        value = BicycleModelDynamic._finite_float(value, name)
        if value < 0.0:
            raise ValueError(name + " must be non-negative.")
        return value

    @staticmethod
    def _positive_float(value, name):
        value = BicycleModelDynamic._finite_float(value, name)
        if value <= 0.0:
            raise ValueError(name + " must be greater than zero.")
        return value

    @staticmethod
    def _as_mapping(value, name):
        if not isinstance(value, dict):
            raise ValueError(name + " must be a dictionary.")
        return value

    @staticmethod
    def _validated_motor_lookup(command_points, force_points, name):
        try:
            commands = [BicycleModelDynamic._finite_float(value, name + ".command") for value in command_points]
            forces = [BicycleModelDynamic._finite_float(value, name + ".force") for value in force_points]
        except TypeError as exc:
            raise ValueError(name + " command and force points must be sequences.") from exc

        if len(commands) != len(forces):
            raise ValueError(name + " command and force point sequences must have the same length.")
        if len(commands) < 2:
            raise ValueError(name + " must contain at least two points.")

        points = sorted(zip(commands, forces), key=lambda item: item[0])
        previous_command = None
        for command, _ in points:
            if command < -1.0 or command > 1.0:
                raise ValueError(name + " command points must be in [-1, 1].")
            if previous_command is not None and command <= previous_command:
                raise ValueError(name + " command points must be strictly increasing.")
            previous_command = command

        return tuple(command for command, _ in points), tuple(force for _, force in points)

    def _generated_motor_lookup(self, command_map):
        deadband = command_map["normalized_command_deadband"]
        drive_force_max = command_map["drive_force_at_full_command_n"]
        brake_force_max = command_map[
            "braking_force_magnitude_at_full_command_n"
        ]
        drive_softness = command_map["drive_response_exponent"]
        brake_softness = command_map["braking_response_exponent"]
        num_points_per_side = command_map["per_command_side_point_count"]

        points = []
        for point_idx in range(num_points_per_side):
            frac = point_idx / float(num_points_per_side - 1)
            command = deadband + frac * (1.0 - deadband)
            drive_force = drive_force_max * (frac ** drive_softness)
            brake_force = brake_force_max * (frac ** brake_softness)
            points.append((command, drive_force))
            points.append((-command, -brake_force))

        points.append((0.0, 0.0))
        points.sort(key=lambda item: item[0])

        command_points = []
        force_points = []
        for command, force in points:
            if abs(command) < 1e-15:
                command = 0.0
            if command_points and abs(command - command_points[-1]) < 1e-12:
                continue
            command_points.append(command)
            force_points.append(force)

        return tuple(command_points), tuple(force_points)

    def _motor_command_lookup_from_parameters(self, command_map):
        if command_map["source"] == "lookup_table":
            lookup_array = np.asarray(command_map["lookup_table"], dtype=np.float64)
            return self._validated_motor_lookup(
                lookup_array[:, 0],
                lookup_array[:, 1],
                "motor_command_map.lookup_table",
            )
        return self._generated_motor_lookup(command_map)

    def _drive_force_envelope_from_config(self, envelope):
        force_limit = envelope.get("constant_force_limit")
        if force_limit is None:
            drive_force_max = self._normalized_motor_command_force_gain_n
        elif force_limit["source"] == "direct_force":
            drive_force_max = force_limit["force_n"]
        else:
            drive_force_max = (
                force_limit["maximum_torque_per_motor_nm"]
                * force_limit["motor_to_wheel_torque_ratio"]
                * force_limit["motor_count"]
                * force_limit["drivetrain_efficiency"]
                / force_limit["driven_wheel_radius_m"]
            )
        max_power = envelope.get("maximum_power_w", math.inf)
        min_power_limit_speed = envelope[
            "power_limit_longitudinal_speed_floor_mps"
        ]

        return drive_force_max, max_power, min_power_limit_speed

    def _rolling_resistance_from_config(self, rolling_resistance):
        coefficient = rolling_resistance["coefficient"]
        gravity = rolling_resistance["gravitational_acceleration_mps2"]
        deadband_speed = rolling_resistance[
            "body_longitudinal_speed_deadband_mps"
        ]

        return coefficient * self._mass_kg * gravity, deadband_speed

    def _motor_params_for_eom_from_parameters(self, longitudinal_force_model):
        flags = 0
        motor_command_points = ()
        motor_force_points = ()
        motor_drive_force_max = self._normalized_motor_command_force_gain_n
        motor_max_power = math.inf
        motor_min_power_limit_speed = 0.5
        rolling_resistance_force = 0.0
        rolling_resistance_deadband_speed = 0.0

        if "motor_command_map" in longitudinal_force_model:
            motor_command_points, motor_force_points = self._motor_command_lookup_from_parameters(
                longitudinal_force_model["motor_command_map"]
            )
            flags |= self.MOTOR_FLAG_COMMAND_MAP

        if "drive_force_envelope" in longitudinal_force_model:
            (
                motor_drive_force_max,
                motor_max_power,
                motor_min_power_limit_speed,
            ) = self._drive_force_envelope_from_config(
                longitudinal_force_model["drive_force_envelope"]
            )
            flags |= self.MOTOR_FLAG_SPEED_ENVELOPE

        if "rolling_resistance" in longitudinal_force_model:
            rolling_resistance_force, rolling_resistance_deadband_speed = self._rolling_resistance_from_config(
                longitudinal_force_model["rolling_resistance"]
            )
            if rolling_resistance_force > 0.0:
                flags |= self.MOTOR_FLAG_ROLLING_RESISTANCE

        return {
            "motor_model_flags": flags,
            "motor_command_points": motor_command_points,
            "motor_force_points": motor_force_points,
            "motor_drive_force_max": motor_drive_force_max,
            "motor_max_power": motor_max_power,
            "motor_min_power_limit_speed": motor_min_power_limit_speed,
            "rolling_resistance_force": rolling_resistance_force,
            "rolling_resistance_deadband_speed": rolling_resistance_deadband_speed,
        }

    def __init__(self, config):
        """
        Initialization function for the "BicycleModelDynamic" class.

        The default value for the Pacejka's tire formula coefficients (peak,
        shape, stiffness, curvature) are taken from the following:
        > Source: https://www.edy.es/dev/docs/pacejka-94-parameters-explained-a-comprehensive-guide/
        > Source: https://au.mathworks.com/help/sdl/ref/tireroadinteractionmagicformula.html
        The details are repeated here for convenience:
        ------------------------------------------------------------------------
            Name         Typical range   Typical values for longitudinal forces
                                         Dry tarmac   Wet tarmac   Snow   Ice
        ------------------------------------------------------------------------
        D   Peak         0.1  -  1.9       1.0          0.82        0.3    0.1
        C*  Shape        1.0  -  2.0       1.9          2.3         2.0    2.0
        B   Stiffness    4.0  - 12.0      10.0         12.0         5.0    4.0
        E   Curvature  -10.0  -  1.0       0.97         1.0         1.0    1.0
        ------------------------------------------------------------------------
        * Note for coefficient C: The Pacejka model specifies the shape as
          C=1.65 for the longitudinal force and C=1.3 for the lateral force.

        Parameters
        ----------
            config : mapping
                A dictionary for the constant parameters that describe the
                dynamic bicycle model. See the class definition above for the
                notation and defintion of each parameter.

        Returns
        -------
        Nothing
        """
        normalized = normalize_bicycle_model_config(config)
        self._normalized_config = normalized
        axle_geometry = normalized["axle_geometry"]
        mass_properties = normalized["mass_properties"]
        longitudinal_force_model = normalized["longitudinal_force_model"]
        steering = normalized["steering"]
        steering_rate_bounds = steering[
            "physical_front_wheel_angle_rate_bounds_rad_per_s"
        ]
        road_conditions = normalized["tire_force_model"]["road_conditions"]
        transition_range = normalized["kinematic_dynamic_transition"][
            "body_longitudinal_speed_range_mps"
        ]
        body_geometry = normalized["body_geometry"]

        self._front_axle_distance_from_center_of_mass_m = axle_geometry[
            "front_axle_distance_from_center_of_mass_m"
        ]
        self._rear_axle_distance_from_center_of_mass_m = axle_geometry[
            "rear_axle_distance_from_center_of_mass_m"
        ]
        self._mass_kg = mass_properties["mass_kg"]
        self._yaw_moment_of_inertia_kg_m2 = mass_properties[
            "yaw_moment_of_inertia_kg_m2"
        ]
        self._normalized_motor_command_force_gain_n = longitudinal_force_model[
            "normalized_motor_command_force_gain_n"
        ]
        self._quadratic_aerodynamic_drag_coefficient_kg_per_m = longitudinal_force_model[
            "quadratic_aerodynamic_drag_coefficient_kg_per_m"
        ]
        self._tire_force_presets = copy.deepcopy(road_conditions)

        # Syntax note:
        # value = <value_if_true> if <expression> else <value_if_false>


        # > For parametric uncertainty in the steering angle
        self._physical_front_wheel_angle_offset_from_request_rad = steering[
            "physical_front_wheel_angle_offset_from_request_rad"
        ]
        self._requested_front_wheel_angle_magnitude_limit_rad = steering[
            "requested_front_wheel_angle_magnitude_limit_rad"
        ]
        self._physical_front_wheel_angle_rate_bounds_rad_per_s = (
            steering_rate_bounds["lower"],
            steering_rate_bounds["upper"],
        )
        self._body_longitudinal_speed_transition_range_mps = (
            transition_range["lower"],
            transition_range["upper"],
        )
        self._body_front_extent_from_center_of_mass_m = body_geometry[
            "front_extent_from_center_of_mass_m"
        ]
        self._body_rear_extent_from_center_of_mass_m = body_geometry[
            "rear_extent_from_center_of_mass_m"
        ]
        self._body_width_m = body_geometry["width_m"]

        motor_params_for_eom = self._motor_params_for_eom_from_parameters(
            longitudinal_force_model
        )

        dry_tire_force_factors = self._tire_force_presets["dry"]
        Lf = self._front_axle_distance_from_center_of_mass_m
        Lr = self._rear_axle_distance_from_center_of_mass_m
        m = self._mass_kg
        wheelbase = Lf + Lr
        transition_min, transition_max = (
            self._body_longitudinal_speed_transition_range_mps
        )
        self._eom_params = (
            Lf,
            Lr,
            1.0 / m,
            1.0 / self._yaw_moment_of_inertia_kg_m2,
            Lr / wheelbase,
            1.0 / wheelbase,
            self._normalized_motor_command_force_gain_n,
            self._quadratic_aerodynamic_drag_coefficient_kg_per_m,
            dry_tire_force_factors["peak_factor_d"],
            dry_tire_force_factors["shape_factor_c"],
            dry_tire_force_factors["stiffness_factor_b"],
            dry_tire_force_factors["curvature_factor_e"],
            transition_min,
            transition_max,
            9.81 * m * Lr / wheelbase,
            9.81 * m * Lf / wheelbase,
            motor_params_for_eom["motor_model_flags"],
            motor_params_for_eom["motor_command_points"],
            motor_params_for_eom["motor_force_points"],
            motor_params_for_eom["motor_drive_force_max"],
            motor_params_for_eom["motor_max_power"],
            motor_params_for_eom["motor_min_power_limit_speed"],
            motor_params_for_eom["rolling_resistance_force"],
            motor_params_for_eom["rolling_resistance_deadband_speed"],
        )
        self.set_tire_force_condition("dry")

        # Initialize the state variables
        # > These are for readability when accessing this class
        self._px    = 0.0
        self._py    = 0.0
        self._theta = 0.0
        self._vx    = 0.0
        self._vy    = 0.0
        self._omega = 0.0
        self._delta = 0.0

        # Initialize the action variables
        self._Fcmd   = 0.0
        self._Ddelta = 0.0

        # Initialize the actions requested
        self._drive_command_request  = 0.0
        self._delta_request = (
            -self._physical_front_wheel_angle_offset_from_request_rad
        )

        self._integration_state = np.empty((7,), dtype=np.float32)
        self._integration_action = np.empty((2,), dtype=np.float32)
        self._integration_scratch = np.empty((7,), dtype=np.float32)
        self._eom_m1 = np.empty((7,), dtype=np.float32)
        self._eom_m2 = np.empty((7,), dtype=np.float32)

    @property
    def normalized_config(self):
        return copy.deepcopy(self._normalized_config)

    @property
    def tire_force_condition(self):
        return self._current_tire_force["condition"]

    @property
    def effective_tire_force_factors(self):
        return dict(self._current_tire_force["factors"])

    def set_tire_force_condition(self, condition, factors=None):
        if not isinstance(condition, str):
            raise TypeError(
                "condition must be one of " + str(_TIRE_FORCE_CONDITIONS) + "."
            )
        if condition not in _TIRE_FORCE_CONDITIONS:
            raise ValueError(
                "condition must be one of " + str(_TIRE_FORCE_CONDITIONS) + "."
            )

        if condition == "custom":
            if factors is None:
                raise TypeError("factors must be a complete mapping for custom condition.")
            resolved = detached_mapping(factors, "factors")
            reject_unknown_keys(resolved, _TIRE_FORCE_FACTOR_NAMES, "factors")
            missing = sorted(set(_TIRE_FORCE_FACTOR_NAMES) - set(resolved))
            if missing:
                raise ValueError("factors." + missing[0] + " is required.")
        else:
            if factors is not None:
                raise ValueError("factors must not be supplied for preset conditions.")
            resolved = dict(self._tire_force_presets[condition])

        for factor_name in _TIRE_FORCE_FACTOR_NAMES:
            resolved[factor_name] = finite_float(
                resolved[factor_name], "factors." + factor_name
            )
        if resolved["peak_factor_d"] < 0.0:
            raise ValueError("factors.peak_factor_d must be non-negative.")
        if resolved["shape_factor_c"] <= 0.0:
            raise ValueError("factors.shape_factor_c must be greater than zero.")
        if resolved["stiffness_factor_b"] < 0.0:
            raise ValueError("factors.stiffness_factor_b must be non-negative.")

        tire_eom_params = (
            resolved["peak_factor_d"],
            resolved["shape_factor_c"],
            resolved["stiffness_factor_b"],
            resolved["curvature_factor_e"],
        )
        current = {"condition": condition, "factors": resolved}

        self._current_tire_force = current
        self._eom_params = (
            self._eom_params[:8] + tire_eom_params + self._eom_params[12:]
        )

    @property
    def state(self):
        px, py, theta, vx, vy, omega, delta = self._state_values()
        return {
            "world_pose": {
                "x_m": float(px),
                "y_m": float(py),
                "heading_rad": float(theta),
            },
            "body_motion": {
                "longitudinal_velocity_mps": float(vx),
                "lateral_velocity_mps": float(vy),
                "yaw_rate_rad_per_s": float(omega),
            },
            "front_wheel_steering_angle_rad": float(delta),
        }

    @property
    def resolved_action_request(self):
        return {
            "normalized_drive_command": float(self._drive_command_request),
            "requested_front_wheel_angle_rad": float(self._delta_request),
        }

    @property
    def current_model_action(self):
        return {
            "normalized_drive_command": float(self._Fcmd),
            "physical_front_wheel_angle_rate_rad_per_s": float(self._Ddelta),
        }

    def _state_values(self):
        return (
            self._px,
            self._py,
            self._theta,
            self._vx,
            self._vy,
            self._omega,
            self._delta,
        )

    def reset(self, state=None):
        """
        Reset the states, actions, and requested actions.

        Parameters
        ----------
            state : mapping or None
                Strict sparse nested state mapping. Omitted leaves resolve to
                zero, as does an omitted or ``None`` mapping.

        Returns
        -------
        Nothing
        """
        state_path = "state"
        supplied = {} if state is None else detached_mapping(state, state_path)
        reject_unknown_keys(
            supplied,
            {"world_pose", "body_motion", "front_wheel_steering_angle_rad"},
            state_path,
        )
        world_pose = _strict_mapping(
            supplied.get("world_pose", {}), state_path + ".world_pose"
        )
        reject_unknown_keys(
            world_pose,
            {"x_m", "y_m", "heading_rad"},
            state_path + ".world_pose",
        )
        body_motion = _strict_mapping(
            supplied.get("body_motion", {}), state_path + ".body_motion"
        )
        reject_unknown_keys(
            body_motion,
            {
                "longitudinal_velocity_mps",
                "lateral_velocity_mps",
                "yaw_rate_rad_per_s",
            },
            state_path + ".body_motion",
        )
        values = (
            finite_float(world_pose.get("x_m", 0.0), state_path + ".world_pose.x_m"),
            finite_float(world_pose.get("y_m", 0.0), state_path + ".world_pose.y_m"),
            finite_float(
                world_pose.get("heading_rad", 0.0),
                state_path + ".world_pose.heading_rad",
            ),
            finite_float(
                body_motion.get("longitudinal_velocity_mps", 0.0),
                state_path + ".body_motion.longitudinal_velocity_mps",
            ),
            finite_float(
                body_motion.get("lateral_velocity_mps", 0.0),
                state_path + ".body_motion.lateral_velocity_mps",
            ),
            finite_float(
                body_motion.get("yaw_rate_rad_per_s", 0.0),
                state_path + ".body_motion.yaw_rate_rad_per_s",
            ),
            finite_float(
                supplied.get("front_wheel_steering_angle_rad", 0.0),
                state_path + ".front_wheel_steering_angle_rad",
            ),
        )

        (
            self._px,
            self._py,
            self._theta,
            self._vx,
            self._vy,
            self._omega,
            self._delta,
        ) = values

        # Reset the actions and requested actions to zero
        self._Fcmd   = 0.0
        self._Ddelta = 0.0
        self._drive_command_request  = 0.0
        self._delta_request = (
            -self._physical_front_wheel_angle_offset_from_request_rad
        )



    def set_action_request(
        self,
        normalized_drive_command,
        requested_front_wheel_angle_rad,
    ):
        """
        Set the action request values, clipping them to their allowable range.

        Parameters
        ----------
            normalized_drive_command : float
                The requested drive command for the force applied to the drive
                wheel, i.e., the accelerator position.
                (valid range: [-1,1])
            requested_front_wheel_angle_rad : float
                The request-space steering angle, clipped to its configured
                magnitude limit. The model adds
                ``physical_front_wheel_angle_offset_from_request_rad`` to form
                the physical end-of-step target, then converts that target
                into a constant steering rate for the step, subject to the
                physical front-wheel angle-rate limits.
                (units: radians)

        Returns
        -------
        Nothing
        """
        # Clip the actions to their respective request limits
        drive_request = finite_float(
            normalized_drive_command, "normalized_drive_command"
        )
        angle_request = finite_float(
            requested_front_wheel_angle_rad,
            "requested_front_wheel_angle_rad",
        )
        self._drive_command_request = max(-1.0, min(drive_request, 1.0))
        self._delta_request = max(
            -self._requested_front_wheel_angle_magnitude_limit_rad,
            min(
                angle_request,
                self._requested_front_wheel_angle_magnitude_limit_rad,
            ),
        )



    @staticmethod
    def eom_kinematic_bicycle(t, s, a, mp):
        """
        Compute the equations-of-motion (eom) for the dynamic bicycle model.

        ``Fcmd`` and ``Ddelta`` below are private equation-of-motion tuple
        notation, not public States, Actions, or Bounds fields.

        The eom for the bicycle, derived for the drive force being applied at
        the rear wheel, are:

        px_dot    = vx * cos(theta) - vy * sin(theta)
        py_dot    = vx * sin(theta) + vy * cos(theta)
        theta_dot = omega
        vx_dot    = (1/m)  * (F   - Fyf sin(delta) + m v_y omega )
        vy_dot    = (1/m)  * (Fyr + Fyf cos(delta) - m v_x omega )
        omega_dot = (1/Iz) * (-Fyr lr + Fyf lf cos(delta))

        In classic parameter mode, where none of the advanced motor parameters
        are provided:
        F = Fcmd * Cm - Cd * vx * abs(vx)
        In complete advanced parameter mode, all advanced motor parameters are
        provided. Any advanced motor parameter selects this mode, so a partial
        advanced group is invalid. The Fcmd * Cm term can then be replaced by a
        lookup-table command map, capped by a speed-dependent torque/power
        envelope, and reduced by rolling resistance.
        Fyf = Fzf Dp sin(Cp atan(Bp alpha_f - Ep(Bp alpha_f - atan(Bp alpha_f))))
        Fyr = Fzr Dp sin(Cp atan(Bp alpha_r - Ep(Bp alpha_r - atan(Bp alpha_r))))
        alpha_f = -atan((vy + lf omega) / vx) + delta
        alpha_r = -atan((vy - lr omega) / vx)

        See the class definition above for the meaning of this notation.

        Parameters
        ----------
            t : float
                Time for a time-varying eom. This is not used by this function
                because the kinematic bicycle model is time-invariant. However,
                "t" is required as an input parameters because it is expected by
                the scipy.integrate numercial integration functions.
            s : numpy array
                The states, with ordering convention:
                [ px  , py  , theta, vx  , vy  , omega, delta ], hence mapping as:
                [ s[0], s[1], s[2] , s[3], s[4], s[5] , s[6]  ]
                This is expected to be a one-dimensional array.
            a : numpy array
                The actions, with ordering convention:
                [ Fcmd, Ddelta ], hence mapping as:
                [ a[0], a[1]   ]
                This is expected to be a one-dimensional array.
            mp : dictionary
                A dictionary contain the constant model parameters that appear
                in the eom. For the dynamic bicycle model is the:
                - Car mass "m"
                - Car length center-of-gravity to front and rear axles "Lf", "Lr"
                - Car yaw moment of inertia "Iz"
                - Drive motor coefficient "Cm" for a full normalized command
                - Aerodynamic drag coefficient "Cd"
                - Pacejka Tyre Model coefficieints "Dp", "Cp", "Bp", "Ep"
                - The kinematic-to-dynamic model velocity transition range
                  "v_transition_min" and "v_transition_max"
                - For classic parameter mode, no further parameters are needed.
                  For complete advanced parameter mode, supply every one of:
                  "motor_model_flags", "motor_command_points",
                  "motor_force_points", "motor_drive_force_max",
                  "motor_max_power", "motor_min_power_limit_speed",
                  "rolling_resistance_force", and
                  "rolling_resistance_deadband_speed". Any advanced parameter
                  selects advanced mode, so partial advanced groups are invalid.

        Returns
        -------
        s_dot : numpy array
            The time deriviative of the state, i.e., "s dot", with the same
            ordering convention as "s", i.e.,:
            [px_dot, py_dot, theta_dot, vx_dot, vy_dot, omega_dot, delta_dot]
        """
        s_dot = np.empty((7,), dtype=np.float32)
        BicycleModelDynamic._eom_kinematic_bicycle_inplace(t, s, a, mp, s_dot)
        return s_dot



    @staticmethod
    def _eom_motor_parameter_values(mp):
        present = tuple(
            name for name in _EOM_ADVANCED_MOTOR_PARAMETER_NAMES if name in mp
        )
        if not present:
            return (0, (), (), mp["Cm"], math.inf, 0.5, 0.0, 0.0)

        missing = tuple(
            name for name in _EOM_ADVANCED_MOTOR_PARAMETER_NAMES if name not in mp
        )
        if missing:
            raise ValueError(
                "Advanced EOM motor parameters must be supplied as a complete "
                "group; missing: " + ", ".join(missing)
            )
        return tuple(mp[name] for name in _EOM_ADVANCED_MOTOR_PARAMETER_NAMES)



    @staticmethod
    def _eom_param_values(mp):
        """Pack EOM constants once per integration call for the fixed-step hot path."""
        Lf = mp["Lf"]
        Lr = mp["Lr"]
        m = mp["m"]
        L = Lf + Lr
        return (
            Lf,
            Lr,
            1.0 / m,
            1.0 / mp["Iz"],
            Lr / L,
            1.0 / L,
            mp["Cm"],
            mp["Cd"],
            mp["Dp"],
            mp["Cp"],
            mp["Bp"],
            mp["Ep"],
            mp["v_transition_min"],
            mp["v_transition_max"],
            9.81 * m * Lr / L,
            9.81 * m * Lf / L,
            *BicycleModelDynamic._eom_motor_parameter_values(mp),
        )



    @staticmethod
    def _eom_kinematic_bicycle_inplace(t, s, a, mp, s_dot):
        """
        In-place version of eom_kinematic_bicycle.

        This keeps the public EOM API intact while avoiding repeated small
        allocations in the fixed-step integrators.
        """
        BicycleModelDynamic._eom_kinematic_bicycle_values_inplace(
            t,
            s,
            a,
            BicycleModelDynamic._eom_param_values(mp),
            s_dot,
        )



    @staticmethod
    def _eom_kinematic_bicycle_values(t, s, a, eom_params):
        s_dot = np.empty((7,), dtype=np.float32)
        BicycleModelDynamic._eom_kinematic_bicycle_values_inplace(t, s, a, eom_params, s_dot)
        return s_dot



    @staticmethod
    def _eom_kinematic_bicycle_values_inplace(t, s, a, eom_params, s_dot):
        s_dot_tuple = BicycleModelDynamic._eom_kinematic_bicycle_tuple(
            s,
            float(a[0]),
            float(a[1]),
            eom_params,
        )
        (
            s_dot[0],
            s_dot[1],
            s_dot[2],
            s_dot[3],
            s_dot[4],
            s_dot[5],
            s_dot[6],
        ) = s_dot_tuple



    @staticmethod
    def _motor_force_from_lookup(command, command_points, force_points):
        if command <= command_points[0]:
            return force_points[0]
        for point_idx in range(1, len(command_points)):
            command_high = command_points[point_idx]
            if command <= command_high:
                command_low = command_points[point_idx - 1]
                force_low = force_points[point_idx - 1]
                return force_low + (
                    (force_points[point_idx] - force_low) *
                    (command - command_low) /
                    (command_high - command_low)
                )
        return force_points[-1]



    @staticmethod
    def _eom_kinematic_bicycle_tuple(s, Fcmd, Ddelta, eom_params):
        (
            Lf,
            Lr,
            inv_m,
            inv_Iz,
            Lr_over_L,
            inv_L,
            Cm,
            Cd,
            Dp,
            Cp,
            Bp,
            Ep,
            vt_min,
            vt_max,
            Fzf,
            Fzr,
            motor_model_flags,
            motor_command_points,
            motor_force_points,
            motor_drive_force_max,
            motor_max_power,
            motor_min_power_limit_speed,
            rolling_resistance_force,
            rolling_resistance_deadband_speed,
        ) = eom_params

        theta = float(s[2])
        vx = float(s[3])
        vy = float(s[4])
        omega = float(s[5])
        delta = float(s[6])

        abs_vx = abs(vx)
        vx_sign = 1.0 if vx > 0.0 else (-1.0 if vx < 0.0 else 0.0)
        if motor_model_flags == 0:
            F = Fcmd * Cm - Cd * vx * vx * vx_sign
        else:
            drive_force = Fcmd * Cm
            if motor_model_flags & BicycleModelDynamic.MOTOR_FLAG_COMMAND_MAP:
                drive_force = BicycleModelDynamic._motor_force_from_lookup(
                    Fcmd,
                    motor_command_points,
                    motor_force_points,
                )
            if (
                motor_model_flags & BicycleModelDynamic.MOTOR_FLAG_SPEED_ENVELOPE and
                drive_force > 0.0
            ):
                speed_for_power = (
                    abs_vx
                    if abs_vx > motor_min_power_limit_speed
                    else motor_min_power_limit_speed
                )
                drive_force_limit = motor_drive_force_max
                power_force_limit = motor_max_power / speed_for_power
                if power_force_limit < drive_force_limit:
                    drive_force_limit = power_force_limit
                if drive_force > drive_force_limit:
                    drive_force = drive_force_limit

            F = drive_force - Cd * vx * vx * vx_sign
            if (
                motor_model_flags & BicycleModelDynamic.MOTOR_FLAG_ROLLING_RESISTANCE and
                abs_vx > rolling_resistance_deadband_speed
            ):
                F -= rolling_resistance_force * vx_sign
        cos_theta = math.cos(theta)
        sin_theta = math.sin(theta)
        px_dot = vx * cos_theta - vy * sin_theta
        py_dot = vx * sin_theta + vy * cos_theta

        if (abs_vx <= vt_min):
            F_on_m = F * inv_m
            tan_delta = math.tan(delta)
            delta_dot_sec2_delta_vx_plus_tan_delta_v_dot = (
                Ddelta * (1.0 + tan_delta * tan_delta) * vx +
                tan_delta * F_on_m
            )
            return (
                px_dot,
                py_dot,
                omega,
                F_on_m,
                delta_dot_sec2_delta_vx_plus_tan_delta_v_dot * Lr_over_L,
                delta_dot_sec2_delta_vx_plus_tan_delta_v_dot * inv_L,
                Ddelta,
            )

        alpha_f = -math.atan((vy + Lf * omega) / vx) + delta
        alpha_r = -math.atan((vy - Lr * omega) / vx)

        Bp_alpha_f = Bp * alpha_f
        Bp_alpha_r = Bp * alpha_r
        Fyf = Fzf * Dp * math.sin(Cp * math.atan(Bp_alpha_f - Ep * (Bp_alpha_f - math.atan(Bp_alpha_f))))
        Fyr = Fzr * Dp * math.sin(Cp * math.atan(Bp_alpha_r - Ep * (Bp_alpha_r - math.atan(Bp_alpha_r))))

        sin_delta = math.sin(delta)
        cos_delta = math.cos(delta)
        dynamic_vx_dot = inv_m * (F - Fyf * sin_delta) + vy * omega
        dynamic_vy_dot = inv_m * (Fyr + Fyf * cos_delta) - vx * omega
        dynamic_omega_dot = inv_Iz * (-Fyr * Lr + Fyf * Lf * cos_delta)

        if (abs_vx >= vt_max):
            return (
                px_dot,
                py_dot,
                omega,
                dynamic_vx_dot,
                dynamic_vy_dot,
                dynamic_omega_dot,
                Ddelta,
            )

        F_on_m = F * inv_m
        tan_delta = math.tan(delta)
        delta_dot_sec2_delta_vx_plus_tan_delta_v_dot = (
            Ddelta * (1.0 + tan_delta * tan_delta) * vx +
            tan_delta * F_on_m
        )
        kinematic_vy_dot = delta_dot_sec2_delta_vx_plus_tan_delta_v_dot * Lr_over_L
        kinematic_omega_dot = delta_dot_sec2_delta_vx_plus_tan_delta_v_dot * inv_L
        blend_factor = max(0.0, min((abs_vx - vt_min) / (vt_max - vt_min), 1.0))
        kinematic_factor = 1.0 - blend_factor

        return (
            px_dot,
            py_dot,
            omega,
            blend_factor * dynamic_vx_dot + kinematic_factor * F_on_m,
            blend_factor * dynamic_vy_dot + kinematic_factor * kinematic_vy_dot,
            blend_factor * dynamic_omega_dot + kinematic_factor * kinematic_omega_dot,
            Ddelta,
        )



    @staticmethod
    def _rk4_step_tuple(s, Fcmd, Ddelta, eom_params, step_Ts):
        eom_tuple = BicycleModelDynamic._eom_kinematic_bicycle_tuple
        half_step_Ts = 0.5 * step_Ts
        one_sixth_step_Ts = step_Ts / 6.0

        m1 = eom_tuple(s, Fcmd, Ddelta, eom_params)
        s2 = (
            s[0] + half_step_Ts * m1[0],
            s[1] + half_step_Ts * m1[1],
            s[2] + half_step_Ts * m1[2],
            s[3] + half_step_Ts * m1[3],
            s[4] + half_step_Ts * m1[4],
            s[5] + half_step_Ts * m1[5],
            s[6] + half_step_Ts * m1[6],
        )

        m2 = eom_tuple(s2, Fcmd, Ddelta, eom_params)
        s3 = (
            s[0] + half_step_Ts * m2[0],
            s[1] + half_step_Ts * m2[1],
            s[2] + half_step_Ts * m2[2],
            s[3] + half_step_Ts * m2[3],
            s[4] + half_step_Ts * m2[4],
            s[5] + half_step_Ts * m2[5],
            s[6] + half_step_Ts * m2[6],
        )

        m3 = eom_tuple(s3, Fcmd, Ddelta, eom_params)
        s4 = (
            s[0] + step_Ts * m3[0],
            s[1] + step_Ts * m3[1],
            s[2] + step_Ts * m3[2],
            s[3] + step_Ts * m3[3],
            s[4] + step_Ts * m3[4],
            s[5] + step_Ts * m3[5],
            s[6] + step_Ts * m3[6],
        )

        m4 = eom_tuple(s4, Fcmd, Ddelta, eom_params)
        return (
            s[0] + one_sixth_step_Ts * (m1[0] + 2.0 * m2[0] + 2.0 * m3[0] + m4[0]),
            s[1] + one_sixth_step_Ts * (m1[1] + 2.0 * m2[1] + 2.0 * m3[1] + m4[1]),
            s[2] + one_sixth_step_Ts * (m1[2] + 2.0 * m2[2] + 2.0 * m3[2] + m4[2]),
            s[3] + one_sixth_step_Ts * (m1[3] + 2.0 * m2[3] + 2.0 * m3[3] + m4[3]),
            s[4] + one_sixth_step_Ts * (m1[4] + 2.0 * m2[4] + 2.0 * m3[4] + m4[4]),
            s[5] + one_sixth_step_Ts * (m1[5] + 2.0 * m2[5] + 2.0 * m3[5] + m4[5]),
            s[6] + one_sixth_step_Ts * (m1[6] + 2.0 * m2[6] + 2.0 * m3[6] + m4[6]),
        )



    def integrate(
        self,
        duration_s,
        method,
        *,
        substep_count=1,
        update_stored_state=False,
    ):
        """
        Approximate the state after ``duration_s`` seconds.

        Parameters
        ----------
        duration_s : float
            Total duration advanced by this integration call, in seconds.
        method : str
            Numerical integration technique to use.
        substep_count : int, keyword-only
            Number of substeps over the total duration.
        update_stored_state : bool, keyword-only
            Whether to replace the model's stored state with the result.

        Returns
        -------
        px, py, theta, vx, vy, omega, delta : float, float, float, float, float, float, float
            State approximation in the established seven-value order.
        """

        duration_s = finite_float(duration_s, "duration_s")
        if duration_s <= 0.0:
            raise ValueError("duration_s must be greater than zero.")
        if not isinstance(method, str):
            raise TypeError("method must be a string.")
        if method not in self.INTEGRATION_METHODS:
            raise ValueError(
                "method must be one of " +
                str(self.INTEGRATION_METHODS) +
                ", got " + str(method)
            )
        substep_count = strict_positive_int(substep_count, "substep_count")
        update_stored_state = strict_bool(
            update_stored_state,
            "update_stored_state",
        )
        substep_duration_s = duration_s / float(substep_count)

        # Convert requested actions into dynamic model actions.
        # > For steering angle: choose the constant steering rate that reaches
        #   the requested steering angle at the end of this integration step,
        #   unless the configured steering-rate limits bind.
        delta_target = (
            self._delta_request
            + self._physical_front_wheel_angle_offset_from_request_rad
        )
        Ddelta_target = (delta_target - self._delta) / duration_s
        steering_rate_lower, steering_rate_upper = (
            self._physical_front_wheel_angle_rate_bounds_rad_per_s
        )
        self._Ddelta = max(
            steering_rate_lower,
            min(Ddelta_target, steering_rate_upper),
        )

        # > For velocity:
        #v_target = self._v_request
        #Dv_target = (v_target - self.v) / (Ts*num_steps)
        #self._Dv = max( self.Dv_lower_limit , min( Dv_target , self.Dv_upper_limit ))

        # > For drive force command
        self._Fcmd = self._drive_command_request

        eom_params = self._eom_params

        if method == "rk4":
            s = (
                float(self._px),
                float(self._py),
                float(self._theta),
                float(self._vx),
                float(self._vy),
                float(self._omega),
                float(self._delta),
            )
            Fcmd = float(self._Fcmd)
            Ddelta = float(self._Ddelta)
            rk4_step = BicycleModelDynamic._rk4_step_tuple

        elif method == "rk45":
            s = np.array(self._state_values(), dtype=np.float32)
            a = np.array([self._Fcmd, self._Ddelta], dtype=np.float32)
        else:
            s = self._integration_state
            s[0] = self._px
            s[1] = self._py
            s[2] = self._theta
            s[3] = self._vx
            s[4] = self._vy
            s[5] = self._omega
            s[6] = self._delta

            a = self._integration_action
            a[0] = self._Fcmd
            a[1] = self._Ddelta

            scratch = self._integration_scratch
            m1 = self._eom_m1
            m2 = self._eom_m2
            eom_inplace = BicycleModelDynamic._eom_kinematic_bicycle_values_inplace

        # Iterate over the requested number of time steps
        if (method == "euler"):
            for _ in range(substep_count):
                eom_inplace(0, s, a, eom_params, m1)
                np.multiply(m1, substep_duration_s, out=scratch)
                np.add(s, scratch, out=s)

        elif (method == "midpoint"):
            for _ in range(substep_count):
                # Compute Euler's method for half a time step
                eom_inplace(0, s, a, eom_params, m1)
                np.multiply(m1, 0.5 * substep_duration_s, out=scratch)
                np.add(s, scratch, out=scratch)
                # Compute full step based on gradient at the half step state (i.e., at the midpoint)
                eom_inplace(0, scratch, a, eom_params, m2)
                np.multiply(m2, substep_duration_s, out=scratch)
                np.add(s, scratch, out=s)

        elif method == "heun":
            for _ in range(substep_count):
                # Compute Euler's method for a full time step
                eom_inplace(0, s, a, eom_params, m1)
                np.multiply(m1, substep_duration_s, out=scratch)
                np.add(s, scratch, out=scratch)
                # Compute update based on half gradient at the start and the end
                eom_inplace(0, scratch, a, eom_params, m2)
                np.add(m1, m2, out=m2)
                np.multiply(m2, 0.5 * substep_duration_s, out=m2)
                np.add(s, m2, out=s)

        elif (method == "rk4"):
            for _ in range(substep_count):
                s = rk4_step(s, Fcmd, Ddelta, eom_params, substep_duration_s)

        elif (method == "rk45"):
            # Python function links:
            # > scipy.integrate.RK45: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.RK45.html#scipy.integrate.RK45
            # > scipy.integrate.solve_ivp: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html#scipy.integrate.solve_ivp
            try:
                from scipy import integrate
            except ModuleNotFoundError as exc:
                raise ModuleNotFoundError(
                    "The rk45 integration method requires scipy. Install it with "
                    "`python -m pip install scipy` or `python -m pip install -e .[rk45]`."
                ) from exc

            for _ in range(substep_count):
                # Call the RK45 method
                sol = integrate.solve_ivp(
                    BicycleModelDynamic._eom_kinematic_bicycle_values,
                    [0, substep_duration_s],
                    s,
                    method="RK45",
                    t_eval=None,
                    args=[a, eom_params],
                    vectorized=False,
                )

                # Copy across the solution
                s = np.copy(sol.y[:,-1])

        # Numerical integration is now complete

        # Update the class variable (if requested)
        if update_stored_state:
            self._px    = s[0]
            self._py    = s[1]
            self._theta = s[2]
            self._vx    = s[3]
            self._vy    = s[4]
            self._omega = s[5]
            self._delta = s[6]

        # Return the state components
        return s[0], s[1], s[2] , s[3] , s[4] , s[5] , s[6]



    def compute_body_frame_acceleration(self):
        """
        Compute instantaneous body-frame accelerations (ax, ay) in m/s^2 from the
        current state and actions, using the blended equations of motion.

        Returns
        -------
        ax, ay : float, float
            Longitudinal and lateral accelerations in the body frame (m/s^2).
        """
        s = self._integration_state
        s[0] = self._px
        s[1] = self._py
        s[2] = self._theta
        s[3] = self._vx
        s[4] = self._vy
        s[5] = self._omega
        s[6] = self._delta

        a = self._integration_action
        a[0] = self._Fcmd
        a[1] = self._Ddelta

        s_dot = self._eom_m1
        BicycleModelDynamic._eom_kinematic_bicycle_values_inplace(
            0,
            s,
            a,
            self._eom_params,
            s_dot,
        )
        ax = float(s_dot[3])
        ay = float(s_dot[4])
        return ax, ay

    def plot_car_on_matplotlib_axis(
        self,
        axis_handle,
        px,
        py,
        theta,
        delta,
        scale=1.0,
        plot_handles=None,
        visualization_theme=None,
    ):
        """Plot the bicycle-model vehicle or update existing artist geometry."""
        if plot_handles is not None and visualization_theme is not None:
            raise ValueError(
                "visualization_theme cannot be supplied when updating existing plot_handles."
            )
        theme = None
        if plot_handles is None:
            from dreamgym.visualization.autonomous_driving.theme import (
                resolve_autonomous_driving_visualization_theme,
            )

            theme = resolve_autonomous_driving_visualization_theme(visualization_theme)
        from dreamgym.visualization.autonomous_driving._vehicle_matplotlib import plot_car

        return plot_car(
            axis_handle,
            (px, py, theta, 0.0, 0.0, 0.0, delta),
            self._front_axle_distance_from_center_of_mass_m,
            self._rear_axle_distance_from_center_of_mass_m,
            self._body_front_extent_from_center_of_mass_m,
            self._body_rear_extent_from_center_of_mass_m,
            self._body_width_m,
            scale=scale,
            plot_handles=plot_handles,
            theme=theme,
        )
