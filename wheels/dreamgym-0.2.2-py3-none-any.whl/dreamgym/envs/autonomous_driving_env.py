#!/usr/bin/env python

import copy
from collections import deque
from collections.abc import Mapping
import math
from types import MappingProxyType

import numpy as np

from dreamgym.envs._render_overlay import (
    _AutonomousDrivingRenderOverlaySnapshot,
    _validated_nonnegative_integer,
)
from dreamgym.envs.bicycle_model_dynamic import (
    BicycleModelDynamic,
)
from dreamgym.envs.road import Road
from dreamgym.envs.road_core._target_config import _normalize_target_line_config
from dreamgym.envs.observation_specs import (
    CONE_DETECTION_RUNTIME_FIELDS,
    OBSERVATION_FORMATS,
    OBSERVATION_SPEC_BY_NAME,
    OBSERVATION_SPECS,
    ROAD_PREVIEW_LANE_RUNTIME_FIELDS,
    compile_observation_records,
    iter_observation_specs_by_writer_group,
    _new_ground_truth_retained_state,
    resolve_spec_shape,
    resolve_spec_value,
)
from dreamgym.envs._render_config import normalize_render_config
from dreamgym.envs.config_validation import (
    detached_mapping,
    finite_float,
    normalize_initial_state_config,
    normalize_initial_state_reset_overlay,
    normalize_observation_config,
    optional_callable,
    reject_unknown_keys,
    required_detached_mapping,
    strict_bool,
    strict_int,
    strict_positive_int,
)

import gymnasium as gym
from gymnasium import spaces


_UNRESOLVED_VISUALIZATION_THEME = object()
_NO_PENDING_REFERENCE_LINE_PROGRESS_SEARCH = object()


def _detached_read_only_render_value(value):
    if isinstance(value, Mapping):
        return MappingProxyType(
            {
                key: _detached_read_only_render_value(item)
                for key, item in value.items()
            }
        )
    if isinstance(value, (list, tuple)):
        return tuple(_detached_read_only_render_value(item) for item in value)
    return copy.deepcopy(value)


INTEGRATION_DEFAULTS = {
    "method": "rk4",
    "environment_step_duration_s": 0.05,
    "substep_count": 1,
}
TERMINATION_DEFAULTS = {
    "planar_speed_bounds_mps": {
        "lower": 0.0,
        "upper": 200.0 / 3.6,
    },
    "absolute_lateral_error_from_target_line_upper_bound_m": 20.0,
}
LANE_KEEPING_BUILT_IN_POLICY_DEFAULTS = {
    "mode": "built_in",
    "lateral_error_feedback_gain_rad_per_m": 0.40,
    "heading_error_feedback_gain": 1.20,
    "curvature_feedforward_gain": 0.80,
}
CRUISE_CONTROL_BUILT_IN_POLICY_DEFAULTS = {
    "mode": "built_in",
    "target_speed": {
        "source": "road_recommended_speed_then_speed_limit",
    },
    "pid": {
        "proportional_gain_per_mps": 0.20,
        "integral_gain_per_m": 0.05,
        "derivative_gain_per_mps2": 0.0,
        "integrated_speed_error_limit_m": 50.0,
    },
}
INTERNAL_POLICY_DEFAULTS = {
    "lane_keeping": {
        "enabled": False,
        "policy": LANE_KEEPING_BUILT_IN_POLICY_DEFAULTS,
    },
    "cruise_control": {
        "enabled": False,
        "policy": CRUISE_CONTROL_BUILT_IN_POLICY_DEFAULTS,
    },
    "action_interface": "auto",
}
_ACTION_INTERFACES = ("auto", "full", "drive_only", "steer_only", "none")


def resolve_positive_road_speed_target_mps(recommended_speed, speed_limit):
    """Choose positive recommended speed, then positive speed limit, in m/s."""

    recommended_speed = float(recommended_speed)
    speed_limit = float(speed_limit)
    if math.isfinite(recommended_speed) and recommended_speed > 0.0:
        return recommended_speed
    if math.isfinite(speed_limit) and speed_limit > 0.0:
        return speed_limit
    raise ValueError(
        "Road recommended speed and speed limit are both invalid; "
        "a positive finite target is required."
    )


def normalize_integration_config(raw):
    supplied = required_detached_mapping(raw, "integration_config")
    reject_unknown_keys(supplied, INTEGRATION_DEFAULTS, "integration_config")
    resolved = {**INTEGRATION_DEFAULTS, **supplied}
    method = resolved["method"]
    if not isinstance(method, str):
        raise TypeError("integration_config.method must be a string.")
    if method not in BicycleModelDynamic.INTEGRATION_METHODS:
        raise ValueError(
            "integration_config.method must be one of "
            + str(BicycleModelDynamic.INTEGRATION_METHODS)
            + ", got "
            + str(method)
        )
    resolved["environment_step_duration_s"] = finite_float(
        resolved["environment_step_duration_s"],
        "integration_config.environment_step_duration_s",
    )
    if resolved["environment_step_duration_s"] <= 0.0:
        raise ValueError(
            "integration_config.environment_step_duration_s must be greater than zero."
        )
    resolved["substep_count"] = strict_positive_int(
        resolved["substep_count"],
        "integration_config.substep_count",
    )
    return resolved


def normalize_termination_config(raw):
    supplied = required_detached_mapping(raw, "termination_config")
    reject_unknown_keys(supplied, TERMINATION_DEFAULTS, "termination_config")
    supplied_speed_bounds = required_detached_mapping(
        supplied.get("planar_speed_bounds_mps", {}),
        "termination_config.planar_speed_bounds_mps",
    )
    reject_unknown_keys(
        supplied_speed_bounds,
        TERMINATION_DEFAULTS["planar_speed_bounds_mps"],
        "termination_config.planar_speed_bounds_mps",
    )
    speed_bounds = {
        **TERMINATION_DEFAULTS["planar_speed_bounds_mps"],
        **supplied_speed_bounds,
    }
    speed_bounds = {
        key: finite_float(
            value,
            "termination_config.planar_speed_bounds_mps." + key,
        )
        for key, value in speed_bounds.items()
    }
    lateral_bound = finite_float(
        supplied.get(
            "absolute_lateral_error_from_target_line_upper_bound_m",
            TERMINATION_DEFAULTS[
                "absolute_lateral_error_from_target_line_upper_bound_m"
            ],
        ),
        "termination_config."
        "absolute_lateral_error_from_target_line_upper_bound_m",
    )
    if speed_bounds["lower"] < 0.0:
        raise ValueError(
            "termination_config.planar_speed_bounds_mps.lower must be non-negative."
        )
    if speed_bounds["upper"] <= speed_bounds["lower"]:
        raise ValueError(
            "termination_config.planar_speed_bounds_mps.upper must be greater than "
            "termination_config.planar_speed_bounds_mps.lower."
        )
    if lateral_bound <= 0.0:
        raise ValueError(
            "termination_config."
            "absolute_lateral_error_from_target_line_upper_bound_m "
            "must be greater than zero."
        )
    return {
        "planar_speed_bounds_mps": speed_bounds,
        "absolute_lateral_error_from_target_line_upper_bound_m": lateral_bound,
    }


def _internal_policy_mapping(value, path):
    if not isinstance(value, Mapping):
        raise TypeError(path + " must be a mapping.")
    return value


def _internal_policy_mode(policy, path):
    mode = policy.get("mode", "built_in")
    if not isinstance(mode, str):
        raise TypeError(path + ".mode must be a string.")
    if mode not in ("built_in", "custom"):
        raise ValueError(path + ".mode must be 'built_in' or 'custom'.")
    return mode


def _normalize_custom_internal_policy(policy, path):
    reject_unknown_keys(policy, ("mode", "callable"), path)
    if "callable" not in policy:
        raise ValueError(path + ".callable is required when mode is 'custom'.")
    controller = policy["callable"]
    if not callable(controller):
        raise TypeError(path + ".callable must be callable.")
    return {"mode": "custom", "callable": controller}


def _normalize_lane_keeping_policy(raw):
    path = "internal_policy_config.lane_keeping.policy"
    policy = _internal_policy_mapping(raw, path)
    mode = _internal_policy_mode(policy, path)
    if mode == "custom":
        return _normalize_custom_internal_policy(policy, path)

    reject_unknown_keys(policy, LANE_KEEPING_BUILT_IN_POLICY_DEFAULTS, path)
    normalized = {"mode": "built_in"}
    for key in (
        "lateral_error_feedback_gain_rad_per_m",
        "heading_error_feedback_gain",
        "curvature_feedforward_gain",
    ):
        normalized[key] = finite_float(
            policy.get(key, LANE_KEEPING_BUILT_IN_POLICY_DEFAULTS[key]),
            path + "." + key,
        )
    return normalized


def _normalize_cruise_target_speed(raw):
    path = "internal_policy_config.cruise_control.policy.target_speed"
    target_speed = _internal_policy_mapping(raw, path)
    reject_unknown_keys(target_speed, ("source", "value_mps"), path)
    source = target_speed.get(
        "source",
        "road_recommended_speed_then_speed_limit",
    )
    if not isinstance(source, str):
        raise TypeError(path + ".source must be a string.")
    if source == "road_recommended_speed_then_speed_limit":
        if "value_mps" in target_speed:
            raise ValueError(
                path + ".value_mps must be omitted for the road-derived source."
            )
        return {"source": source}
    if source == "fixed":
        if "value_mps" not in target_speed:
            raise ValueError(path + ".value_mps is required for the fixed source.")
        value_mps = finite_float(target_speed["value_mps"], path + ".value_mps")
        if value_mps <= 0.0:
            raise ValueError(path + ".value_mps must be positive.")
        return {"source": source, "value_mps": value_mps}
    raise ValueError(
        path + ".source must be 'road_recommended_speed_then_speed_limit' "
        "or 'fixed'."
    )


def _normalize_cruise_pid(raw):
    path = "internal_policy_config.cruise_control.policy.pid"
    pid = _internal_policy_mapping(raw, path)
    defaults = CRUISE_CONTROL_BUILT_IN_POLICY_DEFAULTS["pid"]
    reject_unknown_keys(pid, defaults, path)
    normalized = {
        key: finite_float(pid.get(key, default), path + "." + key)
        for key, default in defaults.items()
    }
    if normalized["integrated_speed_error_limit_m"] < 0.0:
        raise ValueError(
            path + ".integrated_speed_error_limit_m must be non-negative."
        )
    return normalized


def _normalize_cruise_control_policy(raw):
    path = "internal_policy_config.cruise_control.policy"
    policy = _internal_policy_mapping(raw, path)
    mode = _internal_policy_mode(policy, path)
    if mode == "custom":
        return _normalize_custom_internal_policy(policy, path)

    reject_unknown_keys(policy, ("mode", "target_speed", "pid"), path)
    return {
        "mode": "built_in",
        "target_speed": _normalize_cruise_target_speed(
            policy.get("target_speed", {})
        ),
        "pid": _normalize_cruise_pid(policy.get("pid", {})),
    }


def normalize_internal_policy_config(raw):
    """Normalize the strict nested internal-policy configuration."""

    if raw is None:
        supplied = {}
    else:
        supplied = _internal_policy_mapping(raw, "internal_policy_config")
    reject_unknown_keys(
        supplied,
        ("lane_keeping", "cruise_control", "action_interface"),
        "internal_policy_config",
    )

    lane_path = "internal_policy_config.lane_keeping"
    lane_keeping = _internal_policy_mapping(supplied.get("lane_keeping", {}), lane_path)
    reject_unknown_keys(lane_keeping, ("enabled", "policy"), lane_path)

    cruise_path = "internal_policy_config.cruise_control"
    cruise_control = _internal_policy_mapping(
        supplied.get("cruise_control", {}),
        cruise_path,
    )
    reject_unknown_keys(cruise_control, ("enabled", "policy"), cruise_path)

    action_interface = supplied.get("action_interface", "auto")
    if not isinstance(action_interface, str):
        raise TypeError("internal_policy_config.action_interface must be a string.")
    if action_interface not in _ACTION_INTERFACES:
        raise ValueError("internal_policy_config.action_interface is not supported.")

    return {
        "lane_keeping": {
            "enabled": strict_bool(
                lane_keeping.get("enabled", False),
                lane_path + ".enabled",
            ),
            "policy": _normalize_lane_keeping_policy(
                lane_keeping.get("policy", {})
            ),
        },
        "cruise_control": {
            "enabled": strict_bool(
                cruise_control.get("enabled", False),
                cruise_path + ".enabled",
            ),
            "policy": _normalize_cruise_control_policy(
                cruise_control.get("policy", {})
            ),
        },
        "action_interface": action_interface,
    }


class AutonomousDrivingEnv(gym.Env):
    """
    Gymnasium environment for one dynamic bicycle model travelling on one Road.

    Runtime records
    ---------------
    car : BicycleModelDynamic
        The environment-owned vehicle model.
    road : Road
        The complete runtime Road built from ``road_spec``.  Road geometry,
        target-line tracking, and speed information are queried from this
        record during reset and step.

    Construction accepts strict nested mappings.  ``integration_config.method``
    selects the numerical integrator, while
    ``integration_config.environment_step_duration_s`` gives the environment
    step duration and ``integration_config.substep_count`` gives the number of
    integration substeps.  ``initial_state_config`` contains nested reset
    bounds; ``termination_config`` contains episode limits; and
    ``target_line_config`` selects the Road-derived target line.

    ``observation_config`` routes final scalar and vector records to the
    observation, info, or neither.  Its ``target_line_lookahead`` record uses
    ``target_line_lookahead.maximum_distance_m`` and ``sample_count`` to define
    target-line lookahead distances in metres from the current closest
    reference-line progress.  The configured acquisition record controls the
    lookahead source and its optional error or latency model.

    ``internal_policy_config`` optionally supplies nested lane-keeping and
    cruise-control records.  ``action_interface`` resolves to the public
    Gymnasium action space.  ``ground_truth_mode`` selects operational or full
    unscaled state support, and ``observation_format`` selects ``dict`` or
    ``flat`` output.  ``render_mode`` remains ``None``, ``human``, or
    ``rgb_array``; rendering details live in ``render_config``.
    """

    metadata = {
        "render_modes": ["human", "rgb_array"],
        "render_fps": 20,
        "integration_methods": list(BicycleModelDynamic.INTEGRATION_METHODS),
    }

    OBSERVATION_FORMATS = OBSERVATION_FORMATS
    GROUND_TRUTH_MODES = ("operational", "full")
    (
        _SCALAR_REFERENCE_PROGRESS,
        _SCALAR_VX_SENSOR,
        _SCALAR_STEERING_SENSOR,
        _SCALAR_LATERAL_ERROR_TARGET,
        _SCALAR_HEADING_TARGET,
        _SCALAR_TARGET_OFFSET,
        _SCALAR_LATERAL_ERROR_REFERENCE,
        _SCALAR_HEADING_GYRO,
        _SCALAR_TARGET_CURVATURE,
        _SCALAR_SPEED_LIMIT,
        _SCALAR_RECOMMENDED_SPEED,
    ) = range(11)
    def __init__(
        self,
        render_mode,
        bicycle_model_config,
        road_spec,
        integration_config,
        termination_config,
        initial_state_config,
        observation_config,
        target_line_config,
        render_config=None,
        visualization_theme=None,
        internal_policy_config=None,
        ground_truth_mode="operational",
        observation_format="dict",
    ):
        """
        Initialization function for the "AutonomousDrivingGym" class.

        Parameters
        ----------
            render_mode : string
                Specifies how the visualization of the environment should be
                render as part of the "step" function.

            bicycle_model_config : dictionary
                Parameters necessary for initializing a BicycleModelDynamic
                object

            road_spec : dictionary
                Specifies the road. Must contain an "elements" list and can
                contain road-wide "defaults".

            integration_config : dictionary
                Specifies the integration details used in the "step" function.
                This dictionary should contain the following keys:
                - method : string
                    The numerical integration method that is used when simulating the
                    evolution of the car.
                - environment_step_duration_s : float
                    The numerical integration time step that the environment evolves
                    by each time the "step" function is called.
                - substep_count : int
                    The number of integration substeps per environment step.

            termination_config : dictionary
                Specifies the bounds for when to raise the termination flag.
                The base environment applies no reward shaping and returns zero
                reward.
                This dictionary should contain the following keys:
                - planar_speed_bounds_mps : dictionary
                    Inclusive lower and upper planar-speed bounds.
                - absolute_lateral_error_from_target_line_upper_bound_m : float
                    Termination is flagged when the car deviates from the target line
                    by more than this upper bound value.

            initial_state_config : dictionary
                Strict sparse bounds for the seven absolute world-pose and
                body-motion state leaves. A supplied constructor leaf requires
                finite ordered ``lower`` and ``upper`` fields; omitted leaves
                default to fixed zero. ``reference_line_progress_search`` is
                either ``None`` or a complete finite ordered
                ``lower_bound_m``/``upper_bound_m`` interval used only to
                restrict the initial closest-point lookup.

            observation_config : dictionary
                Strict nested registry for the final observation concepts.
                Each routable leaf has ``destination`` set to
                ``"observation"``, ``"info"``, or ``"neither"``; omitted
                destinations default to ``"neither"``. Numeric leaves also
                accept a finite signed ``scaling_factor`` (default ``1.0``),
                while sensor error fields default to zero. Compound records
                configure target-line lookahead, fixed-grid road preview,
                next speed changes, and cone detections. ``fixed_noise_seed``
                is either ``None`` or a non-negative integer.

            target_line_config : dictionary
                Required strict mapping selecting the line tracked by target-line
                observations and termination checks. An empty mapping selects
                ``reference_line``. The supported modes are ``reference_line``,
                ``fixed_offset``, ``lane_center``, and ``lane_coordinate``;
                non-reference modes require their mode-specific fields. Direct
                construction must supply this mapping; Gym registration supplies
                an empty mapping by default.

            render_config : dictionary or None [OPTIONAL]
                Sparse rendering configuration. ``None`` selects the canonical
                render defaults. This setting is independent of ``render_mode``;
                rendering resources are still created only when required. Both
                direct construction and Gym registration default to ``None``.

            visualization_theme : AutonomousDrivingVisualizationTheme, dictionary, or None [OPTIONAL]
                Resolved visualization theme or a strict sparse theme mapping.
                ``None`` selects the canonical default theme. The resolved theme
                controls environment rendering and associated road/car
                presentation without changing simulation behavior. Both direct
                construction and Gym registration default to ``None``.

            internal_policy_config : dict [OPTIONAL]
                Strict nested ``lane_keeping`` and ``cruise_control`` records.
                Each has an ``enabled`` boolean and a discriminated ``policy``.
                A ``built_in`` lane policy accepts finite signed lateral-error,
                heading-error, and curvature-feedforward gains. A ``built_in``
                cruise policy accepts a ``target_speed`` record and finite PID
                gains; its target source is either
                ``road_recommended_speed_then_speed_limit`` or ``fixed`` with a
                positive finite ``value_mps``. A ``custom`` policy contains
                exactly ``mode`` and a required ``callable`` taking
                ``(env, observation)``. Custom callbacks receive independent
                copies of the latest observation returned by reset/step.
                - action_interface : str [OPTIONAL]
                    Requests one of {"full", "drive_only", "steer_only",
                    "none", "auto"}; the requested mode defaults to "auto".
                    The four resolved interfaces are "full" with normalized
                    [drive, steer] and shape (2,), "drive_only" with [drive]
                    and shape (1,), "steer_only" with [steer] and shape (1,),
                    and "none" with a fixed no-op Box of shape (1,).
                    "auto" resolves from controller toggles: lane keeping only
                    -> "drive_only"; cruise control only -> "steer_only"; both
                    -> "none"; neither -> "full". Missing axes start at zero.
                    Explicit "none" zeros both axes unless enabled internal
                    policies control them.

            ground_truth_mode : "operational" or "full" [OPTIONAL]
                Controls which unscaled, noise-free values are retained in
                `get_current_ground_truth()`. "operational" keeps
                training/control/reward support fields. "full" additionally
                keeps debug and export fields such as closest-point vectors
                and lookahead arrays.

            observation_format : "dict" or "flat" [OPTIONAL]
                "dict" returns the standard Gymnasium `Dict` observation.
                "flat" returns a single float32 `Box` vector containing the
                enabled observation fields in deterministic insertion order.
                `info` remains a dictionary in both modes. Use
                `flat_observation_slices` to map names to vector slices.

        Returns
        -------
        Nothing
        """

        integration_config = normalize_integration_config(integration_config)
        termination_config = normalize_termination_config(termination_config)
        initial_state_config = normalize_initial_state_config(initial_state_config)
        observation_config = normalize_observation_config(observation_config)
        self._target_line_config = _normalize_target_line_config(target_line_config)
        internal_policy_config = normalize_internal_policy_config(internal_policy_config)
        render_config = normalize_render_config(render_config)
        if render_mode is not None and render_mode not in self.metadata["render_modes"]:
            raise ValueError(
                "render_mode must be one of "
                + str(self.metadata["render_modes"])
                + " or None, got "
                + str(render_mode)
            )
        self._visualization_theme = _UNRESOLVED_VISUALIZATION_THEME
        if visualization_theme is not None:
            from dreamgym.visualization.autonomous_driving.theme import (
                resolve_autonomous_driving_visualization_theme,
            )

            self._visualization_theme = (
                resolve_autonomous_driving_visualization_theme(visualization_theme)
            )
        elif render_mode is not None:
            self._resolve_visualization_theme()

        self._ground_truth_mode = self._validate_ground_truth_mode(ground_truth_mode)
        self._observation_format = self._validate_observation_format(observation_format)

        # ACTION SPACE (configurable via internal_policy_config['action_interface'])
        # Determine action interface early (may depend on enable flags)
        _ipc = internal_policy_config
        _enable_lk = _ipc["lane_keeping"]["enabled"]
        _enable_cc = _ipc["cruise_control"]["enabled"]
        _requested_ai = _ipc["action_interface"]
        self._requested_action_interface = _requested_ai
        if _requested_ai == "auto":
            if _enable_lk and not _enable_cc:
                self._effective_action_interface = "drive_only"
            elif _enable_cc and not _enable_lk:
                self._effective_action_interface = "steer_only"
            elif _enable_lk and _enable_cc:
                self._effective_action_interface = "none"
            else:
                self._effective_action_interface = "full"
        else:
            self._effective_action_interface = _requested_ai

        # > Actions are the:
        #   - Normalized drive command to the motor. Range [-1,1]
        #   - Normalized steering command. Range [-1,1], mapped to steering angle below.
        if self._effective_action_interface == "full":
            action_space_low  = np.array([-1.0, -1.0], dtype=np.float32)
            action_space_high = np.array([ 1.0,  1.0], dtype=np.float32)
            self.action_space_labels = ["Drive command","Steering command"]
        elif self._effective_action_interface == "drive_only":
            action_space_low  = np.array([-1.0], dtype=np.float32)
            action_space_high = np.array([ 1.0], dtype=np.float32)
            self.action_space_labels = ["Drive command"]
        elif self._effective_action_interface == "steer_only":
            action_space_low  = np.array([-1.0], dtype=np.float32)
            action_space_high = np.array([ 1.0], dtype=np.float32)
            self.action_space_labels = ["Steering command"]
        elif self._effective_action_interface == "none":
            # Constant no-op input; value is ignored. Avoid RescaleAction with this mode.
            action_space_low  = np.array([0.0], dtype=np.float32)
            action_space_high = np.array([0.0], dtype=np.float32)
            self.action_space_labels = []
        else:
            raise ValueError(
                "Unknown action_interface "
                f"'{self._effective_action_interface}'"
            )

        self.action_space = spaces.Box(low=action_space_low, high=action_space_high, dtype=np.float32)

        # THE CAR:
        # Create an instance of the bicycle model
        self.car = BicycleModelDynamic(config=bicycle_model_config)

        # THE ROAD:
        # Instantiate a RoadEnv object
        if road_spec is None or not isinstance(road_spec, Mapping):
            raise TypeError("road_spec must be a mapping.")
        self.__requested_road_spec = copy.deepcopy(road_spec)
        road = Road(
            road_spec=self.__requested_road_spec,
            minimum_curvature_magnitude_per_m=(1.0 / 10000.0),
        )
        self._install_road(road)

        # INTEGRATION SPECIFICATIONS:
        # Set the numerical integration parameters
        self.integration_method = integration_config["method"]
        self.environment_step_duration_s = integration_config[
            "environment_step_duration_s"
        ]
        self.integration_substep_count = integration_config["substep_count"]

        # Termination SPECIFICATIONS:
        # Set the termination parameters
        self.termination_planar_speed_lower_bound_mps = termination_config[
            "planar_speed_bounds_mps"
        ]["lower"]
        self.termination_planar_speed_upper_bound_mps = termination_config[
            "planar_speed_bounds_mps"
        ]["upper"]
        self.termination_absolute_lateral_error_from_target_line_upper_bound_m = (
            termination_config[
                "absolute_lateral_error_from_target_line_upper_bound_m"
            ]
        )



        # INITIAL CONDITION SPECIFICATIONS:
        # Constructor normalization is compiled once; reset overlays detach and
        # resolve over this complete effective record.
        self._initial_state_config = initial_state_config
        self._pending_reference_line_progress_search = (
            _NO_PENDING_REFERENCE_LINE_PROGRESS_SEARCH
        )



        # OBSERVATION PARAMETERS
        # Compile the final nested public configuration once.  Step-time
        # writers consume only frozen records and private scalar acquisition
        # values, never the caller's or normalized nested mappings.
        self._compile_observation_configuration(observation_config)
        self._configure_road_preview_metadata(observation_config)

        self._observation_noise_rng = None

        self._configure_observation_flags_spaces_and_blanks()

        self._should_compute_target_line_lookahead_positions_in_body_frame_m = (
            self._is_observation_record_routed(
                "target_line_lookahead_positions_in_body_frame_m"
            )
        )
        self._should_compute_target_line_lookahead_curvatures_per_m = (
            self._is_observation_record_routed(
                "target_line_lookahead_curvatures_per_m"
            )
        )
        self._lookahead_outputs_are_routed = (
            self._should_compute_target_line_lookahead_positions_in_body_frame_m
            or
            self._should_compute_target_line_lookahead_curvatures_per_m
        )
        self._should_compute_target_line_lookahead = (
            self._lookahead_outputs_are_routed or
            self.ground_truth_mode == "full"
        )
        self.should_compute_target_line_closest_point_coords_in_body_frame = (
            self._is_observation_record_routed(
                "target_line_position_at_closest_reference_line_progress_in_body_frame_m"
            )
        )
        self.should_compute_reference_line_closest_point_coords_in_body_frame = (
            self._is_observation_record_routed(
                "reference_line_closest_point_position_in_body_frame_m"
            )
        )
        self._configure_road_output_fields()
        self.should_compute_next_speed_limit_change = any(
            self._is_observation_record_routed(name)
            for name in (
                "next_speed_limit_change_value_mps",
                "next_speed_limit_change_reference_line_distance_m",
                "next_speed_limit_change_exists",
            )
        )
        self.should_compute_next_recommended_speed_change = any(
            self._is_observation_record_routed(name)
            for name in (
                "next_recommended_speed_change_value_mps",
                "next_recommended_speed_change_reference_line_distance_m",
                "next_recommended_speed_change_exists",
            )
        )
        self.should_compute_next_speed_changes = (
            self.should_compute_next_speed_limit_change or
            self.should_compute_next_recommended_speed_change
        )


        # LOOK-AHEAD QUERIES
        # Based on the observation parameters, construct target-line distance
        # queries for the look-ahead details about the line to follow.
        self._target_line_lookahead_distances_m = (
            self._new_lookahead_progress_queries(
                self._should_compute_target_line_lookahead
            )
        )
        self._configure_lookahead_localization_latency()
        self._configure_observation_writers()
        self._configure_road_preview_latency()

        # PROGRESS TRACKING
        # Initialize the "previous progress" variable to zero
        # > It is set to the correct value in the reset function
        self._previous_reference_line_progress_m = 0.0
        self._previous_reference_line_road_element_index = None
        self.should_use_reference_line_progress_hint = False
        self.reference_line_progress_search_radius_m = None
        self._simulation_time_s = 0.0
        self._reset_lookahead_localization_noise_state()
        self._reset_road_preview_localization_noise_state()

        # GROUND TRUTH RECORDING
        # This stores unscaled, noise-free values needed by training helpers.
        # Debug/export-only fields are opt-in via ground_truth_mode="full".
        self._current_ground_truth = self._new_current_ground_truth_dict()

        # PROGRESS QUERIES:
        # Set the progress queries used for filling
        # the "info_dict" with look-ahead observations.
        #self.progress_queries = np.array([0.0,1.0,2.0,3.0,4.0,5.0], dtype=np.float32)

        # RENDERING:
        self.render_mode = render_mode
        self._render_config = render_config
        self._renderer = None
        if render_mode is not None:
            self._render_overlay_episode_generation = None
            self._render_overlay_snapshot = None

        # INTERNAL POLICIES (OPTIONAL):
        # Toggleable simple controllers for lane keeping and cruise control.
        # Users can also provide custom callables via internal_policy_config.
        ipc = internal_policy_config
        lane_policy = ipc["lane_keeping"]["policy"]
        cruise_policy = ipc["cruise_control"]["policy"]
        self._lane_keeping_enabled = ipc["lane_keeping"]["enabled"]
        self._cruise_control_enabled = ipc["cruise_control"]["enabled"]
        if lane_policy["mode"] == "built_in":
            self._lane_keeping_built_in_policy = copy.deepcopy(lane_policy)
            self._lane_keeping_policy_callable = None
        else:
            self._lane_keeping_built_in_policy = copy.deepcopy(
                LANE_KEEPING_BUILT_IN_POLICY_DEFAULTS
            )
            self._lane_keeping_policy_callable = lane_policy["callable"]
        if cruise_policy["mode"] == "built_in":
            self._cruise_control_built_in_policy = copy.deepcopy(cruise_policy)
            self._cruise_control_policy_callable = None
        else:
            self._cruise_control_built_in_policy = copy.deepcopy(
                CRUISE_CONTROL_BUILT_IN_POLICY_DEFAULTS
            )
            self._cruise_control_policy_callable = cruise_policy["callable"]
        self._cruise_integral = 0.0
        self._cruise_prev_error = 0.0
        self._latest_observation = None
        self._latest_info = None

    @property
    def requested_action_interface(self):
        """Return the constructor-requested action interface."""

        return self._requested_action_interface

    @property
    def effective_action_interface(self):
        """Return the construction-time resolved action interface."""

        return self._effective_action_interface

    @property
    def lane_keeping_enabled(self):
        """Whether the internal lane-keeping policy is enabled."""

        return self._lane_keeping_enabled

    @lane_keeping_enabled.setter
    def lane_keeping_enabled(self, value):
        validated = strict_bool(value, "lane_keeping_enabled")
        self._lane_keeping_enabled = validated

    @property
    def cruise_control_enabled(self):
        """Whether the internal cruise-control policy is enabled."""

        return self._cruise_control_enabled

    @cruise_control_enabled.setter
    def cruise_control_enabled(self, value):
        validated = strict_bool(value, "cruise_control_enabled")
        self._cruise_control_enabled = validated

    @property
    def lane_keeping_policy_callable(self):
        """Return the custom lane policy, or ``None`` for the built-in policy."""

        return self._lane_keeping_policy_callable

    @lane_keeping_policy_callable.setter
    def lane_keeping_policy_callable(self, value):
        validated = optional_callable(value, "lane_keeping_policy_callable")
        self._lane_keeping_policy_callable = validated

    @property
    def cruise_control_policy_callable(self):
        """Return the custom cruise policy, or ``None`` for the built-in policy."""

        return self._cruise_control_policy_callable

    @cruise_control_policy_callable.setter
    def cruise_control_policy_callable(self, value):
        validated = optional_callable(value, "cruise_control_policy_callable")
        self._cruise_control_policy_callable = validated

    def _road_output_fields_for_ground_truth_mode(self, ground_truth_mode):
        lookahead_records = tuple(
            record for record in self._compiled_observation_records
            if record.spec.road_result_field is not None
        )
        road_lookahead_result_fields = {
            record.spec.road_result_field
            for record in lookahead_records
            if record.destination != "neither"
        }
        if ground_truth_mode == "full":
            road_lookahead_result_fields.update(
                record.spec.road_result_field for record in lookahead_records
            )

        road_current_result_fields = {
            "speed_profile.at_closest_reference_line_progress.speed_limit_mps",
            "speed_profile.at_closest_reference_line_progress.recommended_speed_mps",
            "reference_line.closest_point.road_element_index",
            "target_line.tracking_error.lateral_error_from_target_line_m",
            "target_line.tracking_error.heading_error_from_target_line_rad",
            "target_line.at_closest_reference_line_progress.target_line_curvature_per_m",
            "reference_line.closest_point.progress_m",
        }
        if (
            self._is_observation_record_routed(
                "target_line_offset_from_reference_line_m"
            ) or
            ground_truth_mode == "full"
        ):
            road_current_result_fields.add(
                "target_line.at_closest_reference_line_progress."
                "target_line_offset_from_reference_line_m"
            )
        if (
            self._is_observation_record_routed(
                "lateral_error_from_reference_line_m"
            ) or
            ground_truth_mode == "full"
        ):
            road_current_result_fields.add(
                "reference_line.tracking_error.lateral_error_from_reference_line_m"
            )
        if self.should_compute_target_line_closest_point_coords_in_body_frame or ground_truth_mode == "full":
            road_current_result_fields.add(
                "target_line.at_closest_reference_line_progress.position_in_body_frame_m"
            )
        if self.should_compute_reference_line_closest_point_coords_in_body_frame or ground_truth_mode == "full":
            road_current_result_fields.add(
                "reference_line.closest_point.position_in_body_frame_m"
            )
        if ground_truth_mode == "full":
            road_current_result_fields.update({
                "target_line.at_closest_reference_line_progress.position_in_world_frame_m",
                "reference_line.closest_point.position_in_world_frame_m",
            })
        return road_lookahead_result_fields, road_current_result_fields

    def _configure_road_output_fields(self):
        (
            self._road_lookahead_result_fields,
            self._road_current_result_fields,
        ) = self._road_output_fields_for_ground_truth_mode(self.ground_truth_mode)

    def _new_lookahead_progress_queries(self, should_compute):
        if not should_compute:
            return np.empty((0,), dtype=np.float32)
        increment = (
            self._lookahead_maximum_distance_m / self._lookahead_sample_count
        )
        return np.linspace(
            increment,
            self._lookahead_maximum_distance_m,
            num=self._lookahead_sample_count,
            endpoint=True,
            dtype=np.float32,
        )

    def _install_road(self, road):
        """Install one complete runtime Road without changing request provenance."""
        if not isinstance(road, Road):
            raise TypeError("road must be a Road instance.")
        road_total_length_m = road.total_length_m
        road_progress_completion_threshold_m = max(
            road_total_length_m - 0.1,
            0.9999 * road_total_length_m,
        )
        (
            self.__road,
            self._road_total_length_m,
            self._road_progress_completion_threshold_m,
        ) = (
            road,
            road_total_length_m,
            road_progress_completion_threshold_m,
        )

    def _configure_road_preview_metadata(self, observation_config):
        preview = observation_config["road_preview"]
        normalized_distances = preview["target_line_distances_m"]
        self._road_preview_point_count = (
            0 if normalized_distances is None else len(normalized_distances)
        )
        self._road_preview_target_line_distances_m = normalized_distances
        lane_bounds = preview["lane_bounds"]
        if lane_bounds is not None and lane_bounds["mode"] == "target_line_lane":
            if self._target_line_config["mode"] != "lane_center":
                raise ValueError(
                    "observation_config.road_preview.lane_bounds mode "
                    "'target_line_lane' requires target_line_config mode 'lane_center'."
                )
        self._road_preview_lane_bounds_config = (
            None if lane_bounds is None else dict(lane_bounds)
        )
        self._should_sample_road_preview_lane_bounds = any(
            self._is_observation_record_routed(name)
            for name in ROAD_PREVIEW_LANE_RUNTIME_FIELDS
        )

        target_line_mode = self._target_line_config["mode"]
        lane_bounds_mode = None if lane_bounds is None else lane_bounds["mode"]
        source_lane_index = None
        if lane_bounds_mode == "target_line_lane":
            source_lane_index = int(self._target_line_config["lane_index"])
        elif lane_bounds_mode == "lane_index":
            source_lane_index = int(lane_bounds["lane_index"])
        self._resolved_road_preview_metadata = MappingProxyType(
            {
                "target_line_mode": target_line_mode,
                "target_line_curvature_model": {
                    "reference_line": "exact_reference_line",
                    "fixed_offset": "exact_parallel_curve",
                    "lane_center": "local_parallel_curve_approximation",
                    "lane_coordinate": "local_parallel_curve_approximation",
                }[target_line_mode],
                "lane_bounds_mode": lane_bounds_mode,
                "lane_bounds_source_lane_index": source_lane_index,
            }
        )

    def _compile_observation_configuration(self, observation_config):
        records = compile_observation_records(observation_config)
        self._compiled_observation_records = records
        self._compiled_observation_by_name = MappingProxyType(
            {record.spec.name: record for record in records}
        )
        self._fixed_noise_seed = observation_config["fixed_noise_seed"]

        lookahead = observation_config["target_line_lookahead"]
        self._lookahead_maximum_distance_m = lookahead["maximum_distance_m"]
        self._lookahead_sample_count = lookahead["sample_count"]
        acquisition = lookahead["acquisition"]
        self._lookahead_acquisition_mode = acquisition["mode"]
        self._lookahead_position_error_forward = (0.0, 0.0)
        self._lookahead_position_error_left = (0.0, 0.0)
        self._lookahead_curvature_error = (0.0, 0.0)
        self._lookahead_query_distance_error = (0.0, 0.0, 0.0)
        self._lookahead_latency_s = 0.0
        if acquisition["mode"] == "additive_output_error":
            position_error = acquisition["position_error_in_body_frame"]
            self._lookahead_position_error_forward = (
                position_error["forward"]["bias_m"],
                position_error["forward"]["noise_standard_deviation_m"],
            )
            self._lookahead_position_error_left = (
                position_error["left"]["bias_m"],
                position_error["left"]["noise_standard_deviation_m"],
            )
            curvature_error = acquisition["curvature_error"]
            self._lookahead_curvature_error = (
                curvature_error["bias_per_m"],
                curvature_error["noise_standard_deviation_per_m"],
            )
        elif acquisition["mode"] == "localized_map":
            query_error = acquisition["query_distance_error"]
            self._lookahead_query_distance_error = (
                query_error["bias_m"],
                query_error["noise_standard_deviation_m"],
                query_error["random_walk_standard_deviation_m_per_sqrt_s"],
            )
            self._lookahead_latency_s = acquisition["latency_s"]

        preview_acquisition = observation_config["road_preview"]["acquisition"]
        preview_query_error = preview_acquisition[
            "query_origin_error_along_target_line"
        ]
        self._road_preview_query_origin_error = (
            preview_query_error["bias_m"],
            preview_query_error["noise_standard_deviation_m"],
            preview_query_error["random_walk_standard_deviation_m_per_sqrt_s"],
        )
        self._road_preview_latency_s = preview_acquisition["latency_s"]
        preview_output_errors = preview_acquisition["output_errors"]
        self._road_preview_output_errors = MappingProxyType({
            "curvatures_per_m": tuple(
                preview_output_errors["target_line_curvatures_per_m"].values()
            ),
            "recommended_speeds_mps": tuple(
                preview_output_errors["recommended_speeds_mps"].values()
            ),
            "speed_limits_mps": tuple(
                preview_output_errors["speed_limits_mps"].values()
            ),
            "right_lane_bound_offsets_from_target_line_m": tuple(
                preview_output_errors[
                    "right_lane_bound_offsets_from_target_line_m"
                ].values()
            ),
            "left_lane_bound_offsets_from_target_line_m": tuple(
                preview_output_errors[
                    "left_lane_bound_offsets_from_target_line_m"
                ].values()
            ),
        })

        cones = observation_config["cone_detections"]
        self._cone_maximum_detection_count = cones["maximum_detection_count"]
        cone_acquisition = cones["acquisition"]
        self._cone_horizontal_field_of_view_deg = cone_acquisition[
            "horizontal_field_of_view_deg"
        ]
        self._cone_forward_position_upper_bound_m = cone_acquisition[
            "forward_position_upper_bound_m"
        ]
        cone_errors = cone_acquisition["position_error_in_body_frame"]
        self._cone_position_noise_standard_deviation_m = (
            cone_errors["forward"]["noise_standard_deviation_m"],
            cone_errors["left"]["noise_standard_deviation_m"],
        )

    def _noise_sample(self, bias, stddev, shape=None):
        bias = float(bias)
        stddev = float(stddev)
        rng = self._observation_noise_rng if self._observation_noise_rng is not None else self.np_random
        if shape is None:
            if stddev == 0.0:
                return bias
            return rng.normal(bias, stddev)

        if stddev == 0.0:
            if bias == 0.0:
                return None
            return np.full(shape, bias, dtype=np.float32)

        return np.asarray(rng.normal(bias, stddev, shape), dtype=np.float32)

    def _reset_observation_noise_rng(self):
        if self._fixed_noise_seed is None:
            self._observation_noise_rng = self.np_random
        else:
            self._observation_noise_rng = np.random.default_rng(self._fixed_noise_seed)

    @staticmethod
    def _wrap_to_pi(angle):
        return float(np.arctan2(np.sin(angle), np.cos(angle)))

    def _reset_lookahead_localization_noise_state(self):
        self._look_ahead_localized_map_progress_random_walk_error_m = 0.0
        if getattr(self, "should_use_lookahead_localized_map_latency", False):
            self._look_ahead_localization_history.clear()

    def _configure_lookahead_localization_latency(self):
        latency_s = float(self._lookahead_latency_s)
        self.should_use_lookahead_localized_map_latency = (
            self._lookahead_outputs_are_routed and
            self._lookahead_acquisition_mode == "localized_map" and
            latency_s > 0.0
        )
        if self.should_use_lookahead_localized_map_latency:
            ts = max(float(self.environment_step_duration_s), 1e-9)
            maxlen = max(2, int(np.ceil(latency_s / ts)) + 3)
            self._look_ahead_localization_history = deque(maxlen=maxlen)
        else:
            self._look_ahead_localization_history = None

    def _advance_lookahead_localization_noise_state(self, dt):
        if (
            not self._lookahead_outputs_are_routed or
            self._lookahead_acquisition_mode != "localized_map"
        ):
            return
        random_walk_stddev = float(
            self._lookahead_query_distance_error[2]
        )
        if random_walk_stddev == 0.0:
            return
        step_stddev = random_walk_stddev * np.sqrt(max(0.0, float(dt)))
        rng = self._observation_noise_rng if self._observation_noise_rng is not None else self.np_random
        self._look_ahead_localized_map_progress_random_walk_error_m += float(
            rng.normal(0.0, step_stddev)
        )

    def _configure_road_preview_latency(self):
        latency_s = float(self._road_preview_latency_s)
        self.should_use_road_preview_latency = (
            self.should_compute_road_preview and latency_s > 0.0
        )
        if self.should_use_road_preview_latency:
            ts = max(float(self.environment_step_duration_s), 1e-9)
            maxlen = max(2, int(np.ceil(latency_s / ts)) + 3)
            self._road_preview_localization_history = deque(maxlen=maxlen)
        else:
            self._road_preview_localization_history = None

    def _reset_road_preview_localization_noise_state(self):
        self._road_preview_localized_map_progress_random_walk_error_m = 0.0
        if self._road_preview_localization_history is not None:
            self._road_preview_localization_history.clear()
        self._road_preview_debug_snapshot = None

    def _advance_road_preview_localization_noise_state(self, dt):
        if not self.should_compute_road_preview:
            return
        random_walk_stddev = float(
            self._road_preview_query_origin_error[2]
        )
        if random_walk_stddev == 0.0:
            return
        step_stddev = random_walk_stddev * np.sqrt(max(0.0, float(dt)))
        rng = (
            self._observation_noise_rng
            if self._observation_noise_rng is not None
            else self.np_random
        )
        self._road_preview_localized_map_progress_random_walk_error_m += float(
            rng.normal(0.0, step_stddev)
        )

    def _append_road_preview_localization_sample(
        self,
        origin_reference_progress_metres,
    ):
        if not self.should_use_road_preview_latency:
            return
        sample = {
            "time_s": float(self._simulation_time_s),
            "reference_line_progress_at_closest_point": float(
                origin_reference_progress_metres
            ),
            "target_line_config": dict(self._target_line_config),
            "lane_bounds_config": (
                None
                if self._road_preview_lane_bounds_config is None
                else dict(self._road_preview_lane_bounds_config)
            ),
        }
        history = self._road_preview_localization_history
        if history and abs(history[-1]["time_s"] - sample["time_s"]) <= 1e-12:
            history[-1] = sample
        else:
            history.append(sample)

    def _road_preview_localization_sample_at_time(self, query_time_s):
        history = self._road_preview_localization_history
        if history is None or len(history) == 0:
            return None

        query_time_s = float(query_time_s)
        if query_time_s <= history[0]["time_s"]:
            return dict(history[0])
        if query_time_s >= history[-1]["time_s"]:
            return dict(history[-1])

        for upper_index in range(1, len(history)):
            upper_sample = history[upper_index]
            if upper_sample["time_s"] < query_time_s:
                continue
            lower_sample = history[upper_index - 1]
            time_span = upper_sample["time_s"] - lower_sample["time_s"]
            alpha = (
                0.0
                if time_span <= 0.0
                else (query_time_s - lower_sample["time_s"]) / time_span
            )
            sample = {
                "time_s": query_time_s,
                "reference_line_progress_at_closest_point": float(
                    lower_sample["reference_line_progress_at_closest_point"] +
                    alpha * (
                        upper_sample["reference_line_progress_at_closest_point"] -
                        lower_sample["reference_line_progress_at_closest_point"]
                    )
                ),
            }
            selector_source = lower_sample if alpha < 0.5 else upper_sample
            sample["target_line_config"] = dict(
                selector_source["target_line_config"]
            )
            lane_bounds_config = selector_source["lane_bounds_config"]
            sample["lane_bounds_config"] = (
                None
                if lane_bounds_config is None
                else dict(lane_bounds_config)
            )
            return sample

        return dict(history[-1])

    def _validate_road_preview_base_origin(self, origin, source_name):
        try:
            origin = float(origin)
        except (TypeError, ValueError, OverflowError) as exc:
            raise RuntimeError(
                "Road preview " + source_name + " origin must be a finite number."
            ) from exc
        total_length = self.road.total_length_m
        if not np.isfinite(origin):
            raise RuntimeError(
                "Road preview " + source_name + " origin must be finite."
            )
        if origin < 0.0 or origin > total_length:
            raise RuntimeError(
                "Road preview " + source_name + " origin lies outside the Road domain."
            )
        return origin, total_length

    def _lookahead_progress_error_for_source(self):
        return (
            self._lookahead_correlated_progress_error_for_source() +
            self._lookahead_white_progress_error_for_source()
        )

    def _lookahead_correlated_progress_error_for_source(self):
        if (
            not self._lookahead_outputs_are_routed or
            self._lookahead_acquisition_mode != "localized_map"
        ):
            return 0.0

        return (
            float(self._lookahead_query_distance_error[0]) +
            float(self._look_ahead_localized_map_progress_random_walk_error_m)
        )

    def _lookahead_white_progress_error_for_source(self):
        if (
            not self._lookahead_outputs_are_routed or
            self._lookahead_acquisition_mode != "localized_map"
        ):
            return 0.0
        return float(self._noise_sample(0.0, self._lookahead_query_distance_error[1]))

    def _lookahead_progress_queries_for_source(self, progress_error_m=None):
        if (
            not self._should_compute_target_line_lookahead or
            self._lookahead_acquisition_mode != "localized_map"
        ):
            return self._target_line_lookahead_distances_m

        if progress_error_m is None:
            progress_error_m = self._lookahead_progress_error_for_source()
        progress_error_m = float(progress_error_m)
        if progress_error_m == 0.0:
            return self._target_line_lookahead_distances_m
        return (
            self._target_line_lookahead_distances_m
            + np.float32(progress_error_m)
        )

    def _current_lookahead_localization_sample(self, road_info_dict):
        correlated_error_m = float(self._lookahead_correlated_progress_error_for_source())
        white_error_m = float(self._lookahead_white_progress_error_for_source())
        px, py, theta, _, _, _, _ = self.car._state_values()
        sample = {
            "time_s": float(self._simulation_time_s),
            "px": float(px),
            "py": float(py),
            "theta": float(theta),
            "reference_line_progress_at_closest_point": float(
                road_info_dict["reference_line_progress_at_closest_point"]
            ),
            "closest_element_idx": int(road_info_dict["closest_element_idx"]),
            "target_line_config": dict(self._target_line_config),
            "look_ahead_correlated_progress_error_m": correlated_error_m,
            "look_ahead_white_progress_error_m": white_error_m,
            "look_ahead_progress_error_m": correlated_error_m + white_error_m,
        }
        return sample

    def _append_lookahead_localization_sample_if_needed(self, road_info_dict):
        if not self.should_use_lookahead_localized_map_latency:
            return
        sample = self._current_lookahead_localization_sample(road_info_dict)
        history = self._look_ahead_localization_history
        if len(history) > 0 and abs(history[-1]["time_s"] - sample["time_s"]) <= 1e-12:
            history[-1] = sample
        else:
            history.append(sample)

    @staticmethod
    def _interpolate_angle(theta0, theta1, alpha):
        angle_delta = np.arctan2(np.sin(theta1 - theta0), np.cos(theta1 - theta0))
        return float(theta0 + alpha * angle_delta)

    def _lookahead_localization_sample_at_time(self, query_time_s):
        history = self._look_ahead_localization_history
        if history is None or len(history) == 0:
            return None

        query_time_s = float(query_time_s)
        if query_time_s <= history[0]["time_s"]:
            return history[0]
        if query_time_s >= history[-1]["time_s"]:
            return history[-1]

        for upper_index in range(1, len(history)):
            upper_sample = history[upper_index]
            if upper_sample["time_s"] < query_time_s:
                continue
            lower_sample = history[upper_index - 1]
            time_span = upper_sample["time_s"] - lower_sample["time_s"]
            alpha = 0.0 if time_span <= 0.0 else (query_time_s - lower_sample["time_s"]) / time_span
            sample = {}
            for key in (
                "time_s",
                "px",
                "py",
                "reference_line_progress_at_closest_point",
                "look_ahead_correlated_progress_error_m",
            ):
                sample[key] = float(lower_sample[key] + alpha * (upper_sample[key] - lower_sample[key]))
            sample["theta"] = self._interpolate_angle(
                lower_sample["theta"],
                upper_sample["theta"],
                alpha,
            )
            sample["closest_element_idx"] = None
            selector_source = lower_sample if alpha < 0.5 else upper_sample
            sample["target_line_config"] = dict(
                selector_source["target_line_config"]
            )
            sample["look_ahead_white_progress_error_m"] = float(
                selector_source["look_ahead_white_progress_error_m"]
            )
            sample["look_ahead_progress_error_m"] = (
                sample["look_ahead_correlated_progress_error_m"] +
                sample["look_ahead_white_progress_error_m"]
            )
            return sample

        return history[-1]

    def _merge_delayed_localized_map_lookahead_if_needed(self, road_info_dict):
        if not self.should_use_lookahead_localized_map_latency:
            return road_info_dict

        delayed_sample = self._lookahead_localization_sample_at_time(
            self._simulation_time_s - float(self._lookahead_latency_s)
        )
        if delayed_sample is None:
            return road_info_dict

        progress_queries = self._lookahead_progress_queries_for_source(
            delayed_sample["look_ahead_progress_error_m"]
        )
        if np.any(progress_queries < 0.0):
            delayed_road_info = self._sample_prestart_localized_lookahead(
                px=delayed_sample["px"],
                py=delayed_sample["py"],
                theta=delayed_sample["theta"],
                origin_reference_line_progress_m=delayed_sample[
                    "reference_line_progress_at_closest_point"
                ],
                signed_target_line_distances_m=progress_queries,
                lookahead_result_fields=self._road_lookahead_result_fields,
                target_line_config=delayed_sample["target_line_config"],
            )
        else:
            delayed_road_info = self._get_road_info_for_pose(
                px=delayed_sample["px"],
                py=delayed_sample["py"],
                theta=delayed_sample["theta"],
                target_line_lookahead_distances_m=progress_queries,
                target_line_config=delayed_sample["target_line_config"],
                reference_line_progress_search={
                    "lower_bound_m": delayed_sample[
                        "reference_line_progress_at_closest_point"
                    ],
                    "upper_bound_m": delayed_sample[
                        "reference_line_progress_at_closest_point"
                    ],
                },
                include_next_speed_limit_change=False,
                include_next_recommended_speed_change=False,
                lookahead_result_fields=self._road_lookahead_result_fields,
                current_result_fields=set(),
            )

        for field in ("target_line_points_in_body_frame", "target_line_curvatures"):
            if field in delayed_road_info:
                road_info_dict[field] = delayed_road_info[field]
        return road_info_dict

    @classmethod
    def _validate_ground_truth_mode(cls, ground_truth_mode):
        if not isinstance(ground_truth_mode, str):
            raise TypeError("ground_truth_mode must be a string.")
        mode = ground_truth_mode.lower()
        if mode not in cls.GROUND_TRUTH_MODES:
            raise ValueError(
                "ground_truth_mode must be one of " +
                str(cls.GROUND_TRUTH_MODES) +
                ", got " + str(ground_truth_mode)
            )
        return mode

    def _new_current_ground_truth_dict(self, mode=None, previous=None):
        if mode is None:
            mode = self.ground_truth_mode
        return _new_ground_truth_retained_state(mode, previous=previous)

    @property
    def ground_truth_mode(self):
        return self._ground_truth_mode

    @ground_truth_mode.setter
    def ground_truth_mode(self, ground_truth_mode):
        mode = self._validate_ground_truth_mode(ground_truth_mode)
        previous = self._current_ground_truth
        retained_state = self._new_current_ground_truth_dict(
            mode,
            previous=previous,
        )
        road_lookahead_result_fields, road_current_result_fields = (
            self._road_output_fields_for_ground_truth_mode(mode)
        )
        should_compute_target_line_lookahead = (
            self._lookahead_outputs_are_routed or
            mode == "full"
        )
        target_line_lookahead_distances_m = self._new_lookahead_progress_queries(
            should_compute_target_line_lookahead
        )

        self._ground_truth_mode = mode
        self._current_ground_truth = retained_state
        self._road_lookahead_result_fields = road_lookahead_result_fields
        self._road_current_result_fields = road_current_result_fields
        self._should_compute_target_line_lookahead = (
            should_compute_target_line_lookahead
        )
        self._target_line_lookahead_distances_m = target_line_lookahead_distances_m

    @classmethod
    def _validate_observation_format(cls, observation_format):
        if not isinstance(observation_format, str):
            raise TypeError("observation_format must be a string.")
        mode = observation_format.lower()
        if mode not in cls.OBSERVATION_FORMATS:
            raise ValueError(
                "observation_format must be one of " +
                str(cls.OBSERVATION_FORMATS) +
                ", got " + str(observation_format)
            )
        return mode

    @property
    def observation_format(self):
        return self._observation_format

    @staticmethod
    def _space_low_high_flat(space):
        if isinstance(space, spaces.Box):
            return (
                np.asarray(space.low, dtype=np.float32).reshape(-1),
                np.asarray(space.high, dtype=np.float32).reshape(-1),
            )
        if isinstance(space, spaces.MultiDiscrete):
            start = np.asarray(space.start, dtype=np.float32).reshape(-1)
            nvec = np.asarray(space.nvec, dtype=np.float32).reshape(-1)
            return start, start + nvec - np.float32(1.0)
        raise TypeError("Unsupported observation subspace for flat observations: " + str(type(space)))

    def _is_observation_record_routed(self, name):
        return self._compiled_observation_by_name[name].destination != "neither"

    def _include_flags_for_observation_spec(self, spec):
        destination = self._compiled_observation_by_name[spec.name].destination
        return (
            destination == "observation",
            destination == "info",
        )

    def _validated_scaling_for_observation_spec(self, spec):
        return self._compiled_observation_by_name[spec.name].scaling_factor

    def _space_for_observation_spec(self, spec):
        if spec.space_kind == "box":
            low = float(resolve_spec_value(spec.low, self))
            high = float(resolve_spec_value(spec.high, self))
            scale = self._validated_scaling_for_observation_spec(spec)
            if scale is not None:
                if scale == 0.0:
                    low = 0.0
                    high = 0.0
                else:
                    scaled_endpoints = (low * scale, high * scale)
                    low = min(scaled_endpoints)
                    high = max(scaled_endpoints)
            return spaces.Box(
                low=np.float32(low),
                high=np.float32(high),
                shape=resolve_spec_shape(spec, self),
                dtype=spec.dtype,
            )
        if spec.space_kind == "multi_discrete":
            return spaces.MultiDiscrete(
                nvec=resolve_spec_value(spec.nvec, self),
                dtype=spec.dtype,
                start=resolve_spec_value(spec.start, self),
            )
        raise ValueError("Unsupported observation space kind: " + str(spec.space_kind))

    def _blank_for_observation_spec(self, spec):
        return np.zeros(resolve_spec_shape(spec, self), dtype=spec.dtype)

    def _configure_observation_flags_spaces_and_blanks(self):
        self._road_spec_cone_xy = np.empty((0, 2), dtype=np.float32)
        self._road_spec_cone_color = np.empty((0,), dtype=np.int32)
        self._ground_truth_front_wheel_steering_observation_space = None

        cone_records = tuple(
            self._compiled_observation_by_name[name]
            for name in CONE_DETECTION_RUNTIME_FIELDS
        )
        self._should_write_cone_positions = (
            cone_records[0].destination != "neither"
        )
        self._should_write_cone_color_ids = (
            cone_records[2].destination != "neither"
        )
        self._should_write_cone_count = (
            cone_records[3].destination != "neither"
        )
        self.should_compute_cone_detections = any(
            record.destination != "neither" for record in cone_records
        )
        if self._cone_maximum_detection_count is None:
            if self.should_compute_cone_detections:
                self._maximum_cone_detection_count = max(
                    1,
                    self.road.get_cone_count_upper_bound_from_spec(),
                )
            else:
                self._maximum_cone_detection_count = 0
        else:
            self._maximum_cone_detection_count = self._cone_maximum_detection_count

        obs_space_dict = {}
        self.obs_dict_blank = {}
        self.info_dict_blank = {}

        for spec in OBSERVATION_SPECS:
            should_include_obs, should_include_info = self._include_flags_for_observation_spec(spec)
            if not (should_include_obs or should_include_info):
                continue

            self._validated_scaling_for_observation_spec(spec)
            blank = self._blank_for_observation_spec(spec)
            runtime_name = spec.name
            if should_include_obs:
                observation_subspace = self._space_for_observation_spec(spec)
                obs_space_dict[runtime_name] = observation_subspace
                if runtime_name == "ground_truth_front_wheel_steering_angle_rad":
                    self._ground_truth_front_wheel_steering_observation_space = (
                        observation_subspace
                    )
                self.obs_dict_blank[runtime_name] = blank
            if should_include_info:
                self.info_dict_blank[runtime_name] = blank.copy()

        self.should_use_empty_observation = (len(obs_space_dict) == 0)
        if self.should_use_empty_observation:
            empty_shape = (1,)
            obs_space_dict["_empty_observation"] = spaces.Box(
                low=np.array([0.0], dtype=np.float32),
                high=np.array([0.0], dtype=np.float32),
                shape=empty_shape,
                dtype=np.float32,
            )
            self.obs_dict_blank["_empty_observation"] = np.zeros(
                empty_shape,
                dtype=np.float32,
            )

        self._configure_observation_space(obs_space_dict)

    def _configure_observation_space(self, obs_space_dict):
        self.flat_observation_slices = {}
        self.flat_observation_names = tuple(obs_space_dict.keys())
        self._flat_observation_view_specs = []

        flat_lows = []
        flat_highs = []
        flat_unscale_factors = []
        start = 0
        for obs_name, obs_space in obs_space_dict.items():
            blank = self.obs_dict_blank[obs_name]
            size = int(np.asarray(blank).size)
            stop = start + size
            obs_slice = slice(start, stop)
            self.flat_observation_slices[obs_name] = obs_slice
            self._flat_observation_view_specs.append((obs_name, obs_slice, blank.shape))
            low, high = self._space_low_high_flat(obs_space)
            flat_lows.append(low)
            flat_highs.append(high)
            scaling = self._scaling_for_observation_key(obs_name)
            if scaling is None:
                unscale_factor = np.float32(1.0)
            elif float(scaling) == 0.0:
                unscale_factor = np.float32(0.0)
            else:
                unscale_factor = np.float32(1.0 / float(scaling))
            flat_unscale_factors.append(np.full((size,), unscale_factor, dtype=np.float32))
            start = stop

        self.flat_observation_size = start
        self._active_flat_observation = None
        if flat_unscale_factors:
            self._flat_observation_unscale_factors = np.concatenate(flat_unscale_factors).astype(np.float32, copy=False)
        else:
            self._flat_observation_unscale_factors = np.zeros((0,), dtype=np.float32)

        if self.observation_format == "dict":
            self.observation_space = spaces.Dict(obs_space_dict)
            return

        if flat_lows:
            flat_low = np.concatenate(flat_lows).astype(np.float32, copy=False)
            flat_high = np.concatenate(flat_highs).astype(np.float32, copy=False)
        else:
            flat_low = np.zeros((0,), dtype=np.float32)
            flat_high = np.zeros((0,), dtype=np.float32)
        self.observation_space = spaces.Box(
            low=flat_low,
            high=flat_high,
            shape=(self.flat_observation_size,),
            dtype=np.float32,
        )

    def _observation_targets_for(self, spec):
        runtime_name = spec.name
        destination = self._compiled_observation_by_name[spec.name].destination
        obs_targets = (runtime_name,) if destination == "observation" else ()
        info_targets = (runtime_name,) if destination == "info" else ()
        return obs_targets, info_targets

    def _configure_observation_writers(self):
        state_value_indices = {
            "px": 0,
            "py": 1,
            "theta": 2,
            "vx": 3,
            "vy": 4,
            "omega": 5,
            "delta": 6,
        }
        self._ground_truth_state_writer_specs = []
        for spec in iter_observation_specs_by_writer_group("ground_truth_state"):
            obs_targets, info_targets = self._observation_targets_for(spec)
            if obs_targets or info_targets:
                self._ground_truth_state_writer_specs.append(
                    (
                        state_value_indices[spec.writer_key],
                        self._compiled_observation_by_name[spec.name].scaling_factor,
                        obs_targets,
                        info_targets,
                    )
                )

        scalar_writer_codes = {
            "reference_progress": self._SCALAR_REFERENCE_PROGRESS,
            "vx_sensor": self._SCALAR_VX_SENSOR,
            "steering_sensor": self._SCALAR_STEERING_SENSOR,
            "lateral_error_target": self._SCALAR_LATERAL_ERROR_TARGET,
            "heading_target": self._SCALAR_HEADING_TARGET,
            "target_offset": self._SCALAR_TARGET_OFFSET,
            "lateral_error_reference": self._SCALAR_LATERAL_ERROR_REFERENCE,
            "heading_gyro": self._SCALAR_HEADING_GYRO,
            "target_curvature": self._SCALAR_TARGET_CURVATURE,
            "speed_limit": self._SCALAR_SPEED_LIMIT,
            "recommended_speed": self._SCALAR_RECOMMENDED_SPEED,
        }
        self._scalar_observation_writer_specs = []
        for spec in iter_observation_specs_by_writer_group("scalar"):
            obs_targets, info_targets = self._observation_targets_for(spec)
            if obs_targets or info_targets:
                self._scalar_observation_writer_specs.append(
                    (
                        scalar_writer_codes[spec.writer_key],
                        self._compiled_observation_by_name[spec.name],
                        obs_targets,
                        info_targets,
                    )
                )

        accel_specs = {
            spec.writer_key: spec
            for spec in iter_observation_specs_by_writer_group("accel")
        }
        self._accel_x_record = self._compiled_observation_by_name[accel_specs["x"].name]
        self._accel_y_record = self._compiled_observation_by_name[accel_specs["y"].name]
        self._accel_x_targets = self._observation_targets_for(accel_specs["x"])
        self._accel_y_targets = self._observation_targets_for(accel_specs["y"])
        self._should_write_accel_observations = any(self._accel_x_targets) or any(self._accel_y_targets)

        self._next_speed_change_writer_specs = []
        for spec in iter_observation_specs_by_writer_group("next_speed_change"):
            obs_targets, info_targets = self._observation_targets_for(spec)
            if obs_targets or info_targets:
                self._next_speed_change_writer_specs.append(
                    (
                        spec.writer_key,
                        self._compiled_observation_by_name[spec.name].scaling_factor,
                        obs_targets,
                        info_targets,
                    )
                )

        vector_compute_fns = {
            "target_line_closest_point": type(self)._compute_target_line_closest_point_coords_in_body_frame_observation,
            "reference_line_closest_point": type(self)._compute_reference_line_closest_point_coords_in_body_frame_observation,
            "lookahead_target_line_coords": type(self)._compute_look_ahead_target_line_coords_in_body_frame_observation,
            "lookahead_target_line_curvatures": type(self)._compute_look_ahead_target_line_curvatures_observation,
        }
        self._vector_observation_writer_specs = []
        for spec in iter_observation_specs_by_writer_group("vector"):
            obs_targets, info_targets = self._observation_targets_for(spec)
            if obs_targets or info_targets:
                self._vector_observation_writer_specs.append(
                    (
                        vector_compute_fns[spec.writer_key],
                        self._compiled_observation_by_name[spec.name],
                        obs_targets,
                        info_targets,
                    )
                )

        self._road_preview_observation_writer_specs = []
        for spec in iter_observation_specs_by_writer_group("road_preview"):
            obs_targets, info_targets = self._observation_targets_for(spec)
            if obs_targets or info_targets:
                self._road_preview_observation_writer_specs.append(
                    (
                        spec.writer_key,
                        self._compiled_observation_by_name[spec.name].scaling_factor,
                        obs_targets,
                        info_targets,
                    )
                )
        self.should_compute_road_preview = bool(
            self._road_preview_observation_writer_specs
        )

    @staticmethod
    def _write_observation_targets(obs_dict, info_dict, obs_targets, info_targets, value):
        for obs_name in obs_targets:
            obs_dict[obs_name][...] = value
        for obs_name in info_targets:
            info_dict[obs_name][...] = value

    @staticmethod
    def _scale_observation_value(value, scaling, arithmetic_multiplier=None):
        if float(scaling) == 0.0:
            value_array = np.asarray(value)
            if value_array.ndim == 0:
                return np.float32(0.0)
            return np.zeros(value_array.shape, dtype=np.float32)
        if arithmetic_multiplier is None:
            arithmetic_multiplier = scaling
        return value * arithmetic_multiplier

    def _write_flat_and_info_targets(self, flat_observation, info_dict, obs_targets, info_targets, value):
        for obs_name in obs_targets:
            flat_observation[self.flat_observation_slices[obs_name]] = np.asarray(
                value,
                dtype=np.float32,
            ).reshape(-1)
        for obs_name in info_targets:
            info_dict[obs_name][...] = value

    def _compute_target_line_closest_point_coords_in_body_frame_observation(
        self, road_info_dict, record
    ):
        target_px_noise = self._noise_sample(
            record.error("bias_m"),
            record.error("noise_standard_deviation_m"),
        )
        target_py_noise = self._noise_sample(
            record.error("bias_m"),
            record.error("noise_standard_deviation_m"),
        )
        value = np.array(
            [
                road_info_dict["target_line_px_closest_in_body_frame"] + target_px_noise,
                road_info_dict["target_line_py_closest_in_body_frame"] + target_py_noise,
            ],
        )
        return np.asarray(
            self._scale_observation_value(
                value,
                record.scaling_factor,
            ),
            dtype=np.float32,
        )

    def _compute_reference_line_closest_point_coords_in_body_frame_observation(
        self, road_info_dict, record
    ):
        reference_px_noise = self._noise_sample(
            record.error("bias_m"),
            record.error("noise_standard_deviation_m"),
        )
        reference_py_noise = self._noise_sample(
            record.error("bias_m"),
            record.error("noise_standard_deviation_m"),
        )
        value = np.array(
            [
                road_info_dict["reference_line_px_closest_in_body_frame"] + reference_px_noise,
                road_info_dict["reference_line_py_closest_in_body_frame"] + reference_py_noise,
            ],
        )
        return np.asarray(
            self._scale_observation_value(
                value,
                record.scaling_factor,
            ),
            dtype=np.float32,
        )

    def _compute_look_ahead_target_line_coords_in_body_frame_observation(
        self, road_info_dict, record
    ):
        look_ahead_coords = np.asarray(
            road_info_dict["target_line_points_in_body_frame"],
            dtype=np.float32,
        ).T.copy()
        if self._lookahead_acquisition_mode == "additive_output_error":
            coords_x_noise = self._noise_sample(
                *self._lookahead_position_error_forward,
                (self._lookahead_sample_count,),
            )
            if coords_x_noise is not None:
                look_ahead_coords[0, :] += coords_x_noise
            coords_y_noise = self._noise_sample(
                *self._lookahead_position_error_left,
                (self._lookahead_sample_count,),
            )
            if coords_y_noise is not None:
                look_ahead_coords[1, :] += coords_y_noise
        scaling = record.scaling_factor
        return self._scale_observation_value(
            look_ahead_coords,
            scaling,
            np.float32(scaling),
        )

    def _compute_look_ahead_target_line_curvatures_observation(
        self, road_info_dict, record
    ):
        look_ahead_curvatures = np.asarray(
            road_info_dict["target_line_curvatures"],
            dtype=np.float32,
        ).copy()
        if self._lookahead_acquisition_mode == "additive_output_error":
            curvatures_noise = self._noise_sample(
                *self._lookahead_curvature_error,
                (self._lookahead_sample_count,),
            )
            if curvatures_noise is not None:
                look_ahead_curvatures += curvatures_noise
        scaling = record.scaling_factor
        return self._scale_observation_value(
            look_ahead_curvatures,
            scaling,
            np.float32(scaling),
        )

    def _prepare_cone_detections_for_episode(self, rng=None):
        if not self.should_compute_cone_detections:
            self._road_spec_cone_xy = np.empty((0, 2), dtype=np.float32)
            self._road_spec_cone_color = np.empty((0,), dtype=np.int32)
            return

        self._road_spec_cone_xy, self._road_spec_cone_color = self.road.get_cone_arrays_from_spec(rng=rng)

    def _get_cone_info_at_current_pose(self):
        px, py, theta, _, _, _, _ = self.car._state_values()
        return self.road.cone_info_for_cone_point_arrays_at_given_pose_and_fov(
            self._road_spec_cone_xy,
            self._road_spec_cone_color,
            px=px,
            py=py,
            theta=theta,
            fov_horizontal_degrees=self._cone_horizontal_field_of_view_deg,
            body_x_upper_bound=self._cone_forward_position_upper_bound_m,
            max_results=self._maximum_cone_detection_count,
        )

    def _cone_detection_values(self, cone_info):
        num_cones = min(
            int(cone_info["num_cones"]),
            self._maximum_cone_detection_count,
        )
        values = {}

        if self._should_write_cone_positions:
            forward_positions = np.zeros(
                (self._maximum_cone_detection_count,), dtype=np.float32
            )
            left_positions = np.zeros(
                (self._maximum_cone_detection_count,), dtype=np.float32
            )
            if num_cones:
                forward_positions[:num_cones] = np.asarray(
                    cone_info["px_in_body_frame"], dtype=np.float32
                )[:num_cones]
                left_positions[:num_cones] = np.asarray(
                    cone_info["py_in_body_frame"], dtype=np.float32
                )[:num_cones]

                forward_stddev, left_stddev = (
                    self._cone_position_noise_standard_deviation_m
                )
                forward_noise = self._noise_sample(
                    0.0, forward_stddev, (num_cones,)
                )
                if forward_noise is not None:
                    forward_positions[:num_cones] += forward_noise
                left_noise = self._noise_sample(
                    0.0, left_stddev, (num_cones,)
                )
                if left_noise is not None:
                    left_positions[:num_cones] += left_noise

                scaling = self._compiled_observation_by_name[
                    "cone_detections_forward_positions_in_body_frame_m"
                ].scaling_factor
                arithmetic_multiplier = np.float32(scaling)
                forward_positions[:num_cones] = self._scale_observation_value(
                    forward_positions[:num_cones],
                    scaling,
                    arithmetic_multiplier,
                )
                left_positions[:num_cones] = self._scale_observation_value(
                    left_positions[:num_cones],
                    scaling,
                    arithmetic_multiplier,
                )

            values[
                "cone_detections_forward_positions_in_body_frame_m"
            ] = forward_positions
            values[
                "cone_detections_left_positions_in_body_frame_m"
            ] = left_positions

        if self._should_write_cone_color_ids:
            color_ids = np.full(
                (self._maximum_cone_detection_count,),
                Road.CONE_COLOR_PADDING_ID,
                dtype=np.int32,
            )
            if num_cones:
                color_ids[:num_cones] = np.asarray(
                    cone_info["color"], dtype=np.int32
                )[:num_cones]
            values["cone_detections_color_ids"] = color_ids

        if self._should_write_cone_count:
            values["cone_detections_count"] = np.array(
                [num_cones], dtype=np.int32
            )

        return values

    def _write_cone_detections_to_dicts(self, cone_info, obs_dict, info_dict):
        for runtime_name, value in self._cone_detection_values(cone_info).items():
            if runtime_name in obs_dict:
                obs_dict[runtime_name][...] = value
            if runtime_name in info_dict:
                info_dict[runtime_name][...] = value

    def _write_cone_detections_to_flat_or_info(self, cone_info, flat_observation, info_dict):
        for runtime_name, value in self._cone_detection_values(cone_info).items():
            if runtime_name in self.flat_observation_slices:
                flat_observation[self.flat_observation_slices[runtime_name]] = np.asarray(
                    value, dtype=np.float32
                ).reshape(-1)
            if runtime_name in info_dict:
                info_dict[runtime_name][...] = value

    def _new_observation_and_info_dicts(self):
        # Fresh arrays ensure returned observations cannot mutate the reusable templates.
        # Enabled fields are overwritten by the observation writers below, so empty
        # allocation avoids copying zero-filled templates on every environment step.
        if self.observation_format == "flat":
            flat_observation = np.empty((self.flat_observation_size,), dtype=np.float32)
            obs_dict = {
                key: flat_observation[obs_slice].reshape(obs_shape)
                for key, obs_slice, obs_shape in self._flat_observation_view_specs
            }
            self._active_flat_observation = flat_observation
        else:
            obs_dict = {key: np.empty_like(value) for key, value in self.obs_dict_blank.items()}
            self._active_flat_observation = None

        info_dict = {key: np.empty_like(value) for key, value in self.info_dict_blank.items()}
        if self.should_use_empty_observation:
            obs_dict["_empty_observation"][0] = np.float32(0.0)
        return obs_dict, info_dict

    def _new_info_dict(self):
        return {key: np.empty_like(value) for key, value in self.info_dict_blank.items()}

    def _format_observation_for_return(self, obs_dict):
        if self.observation_format == "flat":
            return self._active_flat_observation
        return obs_dict

    @staticmethod
    def _copy_observation(observation):
        if observation is None:
            return None
        if isinstance(observation, np.ndarray):
            return np.copy(observation)
        if not isinstance(observation, dict):
            return observation
        return {
            key: np.copy(value) if isinstance(value, np.ndarray) else value
            for key, value in observation.items()
        }

    def _get_cone_info_for_observation_if_needed(self):
        if self.should_compute_cone_detections:
            return self._get_cone_info_at_current_pose()
        return None

    def _update_current_ground_truth_from_road_info(
        self,
        road_info_dict,
        nominal_ground_truth_lookahead=None,
    ):
        road_truth = {
            "lateral_error_from_target_line": road_info_dict["lateral_error_from_target_line"],
            "heading_error_from_target_line_rad": road_info_dict[
                "heading_error_from_target_line_rad"
            ],
            "target_line_curvature_at_closest_point": road_info_dict["target_line_curvature_at_closest_p"],
        }
        if "lateral_error_from_reference_line" in road_info_dict:
            road_truth["lateral_error_from_reference_line"] = road_info_dict["lateral_error_from_reference_line"]
        if "target_line_offset_from_reference_line" in road_info_dict:
            road_truth["target_line_offset_from_reference_line"] = road_info_dict["target_line_offset_from_reference_line"]

        ground_truth = self._current_ground_truth
        px, py, theta, vx, vy, omega, delta = self.car._state_values()
        ground_truth["ground_truth_world_position_x_m"] = px
        ground_truth["ground_truth_world_position_y_m"] = py
        ground_truth["ground_truth_heading_in_world_frame_rad"] = theta
        ground_truth["ground_truth_body_longitudinal_velocity_mps"] = vx
        ground_truth["ground_truth_body_lateral_velocity_mps"] = vy
        ground_truth["ground_truth_yaw_rate_rad_per_s"] = omega
        ground_truth["ground_truth_front_wheel_steering_angle_rad"] = delta

        ground_truth["reference_line_progress_m"] = road_info_dict[
            "reference_line_progress_at_closest_point"
        ]
        ground_truth["reference_line_road_element_index"] = int(
            road_info_dict["closest_element_idx"]
        )

        ground_truth["lateral_error_from_target_line_m"] = road_truth[
            "lateral_error_from_target_line"
        ]
        ground_truth["heading_error_from_target_line_rad"] = road_truth[
            "heading_error_from_target_line_rad"
        ]
        ground_truth["target_line_curvature_per_m"] = road_truth[
            "target_line_curvature_at_closest_point"
        ]
        ground_truth["speed_limit_mps"] = road_info_dict["speed_limit_at_closest_p"]
        ground_truth["recommended_speed_mps"] = road_info_dict[
            "recommended_speed_at_closest_p"
        ]

        if self.ground_truth_mode == "full":
            lookahead_road_info = (
                road_info_dict
                if nominal_ground_truth_lookahead is None
                else nominal_ground_truth_lookahead
            )
            ground_truth["target_line_offset_from_reference_line_m"] = road_truth[
                "target_line_offset_from_reference_line"
            ]
            ground_truth["lateral_error_from_reference_line_m"] = road_truth[
                "lateral_error_from_reference_line"
            ]
            ground_truth[
                "target_line_position_at_closest_reference_line_progress_in_world_frame_m"
            ] = np.array(
                [
                    road_info_dict["target_line_px_closest"],
                    road_info_dict["target_line_py_closest"],
                ],
                dtype=np.float32,
            )
            ground_truth[
                "reference_line_closest_point_position_in_world_frame_m"
            ] = np.array(
                [
                    road_info_dict["reference_line_px_closest"],
                    road_info_dict["reference_line_py_closest"],
                ],
                dtype=np.float32,
            )
            ground_truth[
                "target_line_position_at_closest_reference_line_progress_in_body_frame_m"
            ] = np.array(
                [
                    road_info_dict["target_line_px_closest_in_body_frame"],
                    road_info_dict["target_line_py_closest_in_body_frame"],
                ],
                dtype=np.float32,
            )
            ground_truth[
                "reference_line_closest_point_position_in_body_frame_m"
            ] = np.array(
                [
                    road_info_dict["reference_line_px_closest_in_body_frame"],
                    road_info_dict["reference_line_py_closest_in_body_frame"],
                ],
                dtype=np.float32,
            )
            ground_truth[
                "target_line_lookahead_positions_in_body_frame_m"
            ] = np.array(
                lookahead_road_info.get(
                    "target_line_points_in_body_frame",
                    np.empty((0, 2), dtype=np.float32),
                ),
                dtype=np.float32,
                copy=True,
            )
            ground_truth["target_line_lookahead_curvatures_per_m"] = np.array(
                lookahead_road_info.get(
                    "target_line_curvatures",
                    np.empty((0,), dtype=np.float32),
                ),
                dtype=np.float32,
                copy=True,
            )

        return road_truth

    def _write_ground_truth_state_observations(self, obs_dict, info_dict):
        state_values = self.car._state_values()
        for state_index, scaling, obs_targets, info_targets in self._ground_truth_state_writer_specs:
            value = self._scale_observation_value(
                state_values[state_index],
                scaling,
            )
            self._write_observation_targets(obs_dict, info_dict, obs_targets, info_targets, value)

    def _write_ground_truth_state_observations_flat(self, flat_observation, info_dict):
        state_values = self.car._state_values()
        for state_index, scaling, obs_targets, info_targets in self._ground_truth_state_writer_specs:
            value = self._scale_observation_value(
                state_values[state_index],
                scaling,
            )
            for obs_name in obs_targets:
                flat_observation[self.flat_observation_slices[obs_name]][0] = value
            for obs_name in info_targets:
                info_dict[obs_name][0] = value

    def _scalar_observation_value(
        self,
        scalar_code,
        record,
        road_info_dict,
        road_truth,
        state_values,
    ):
        scalar_reference_progress = self._SCALAR_REFERENCE_PROGRESS
        scalar_vx_sensor = self._SCALAR_VX_SENSOR
        scalar_steering_sensor = self._SCALAR_STEERING_SENSOR
        scalar_lateral_error_target = self._SCALAR_LATERAL_ERROR_TARGET
        scalar_heading_target = self._SCALAR_HEADING_TARGET
        scalar_target_offset = self._SCALAR_TARGET_OFFSET
        scalar_lateral_error_reference = self._SCALAR_LATERAL_ERROR_REFERENCE
        scalar_heading_gyro = self._SCALAR_HEADING_GYRO
        scalar_target_curvature = self._SCALAR_TARGET_CURVATURE
        scalar_speed_limit = self._SCALAR_SPEED_LIMIT

        if scalar_code == scalar_reference_progress:
            return self._scale_observation_value(
                road_info_dict["reference_line_progress_at_closest_point"],
                record.scaling_factor,
            )
        if scalar_code == scalar_vx_sensor:
            vx_noise = self._noise_sample(
                record.error("bias_mps"),
                record.error("noise_standard_deviation_mps"),
            )
            return self._scale_observation_value(
                state_values[3] + vx_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_steering_sensor:
            delta_meas_noisy = state_values[6] + self._noise_sample(
                0.0, record.error("noise_standard_deviation_rad")
            )
            delta_resolution = record.error("resolution_rad")
            if delta_resolution > 7.6e-4:
                delta_meas_noisy = np.round(delta_meas_noisy / delta_resolution) * delta_resolution
            return self._scale_observation_value(
                np.clip(
                    delta_meas_noisy + record.error("bias_rad"),
                    -0.5 * np.pi,
                    0.5 * np.pi,
                ),
                record.scaling_factor,
            )
        if scalar_code == scalar_lateral_error_target:
            lateral_error_noise = self._noise_sample(
                record.error("bias_m"),
                record.error("noise_standard_deviation_m"),
            )
            return self._scale_observation_value(
                road_truth["lateral_error_from_target_line"] +
                lateral_error_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_heading_target:
            heading_noise = self._noise_sample(
                record.error("bias_rad"),
                record.error("noise_standard_deviation_rad"),
            )
            return self._scale_observation_value(
                self._wrap_to_pi(
                    road_truth["heading_error_from_target_line_rad"] +
                    heading_noise
                ),
                record.scaling_factor,
            )
        if scalar_code == scalar_target_offset:
            target_line_offset_noise = self._noise_sample(
                record.error("bias_m"),
                record.error("noise_standard_deviation_m"),
            )
            return self._scale_observation_value(
                road_truth["target_line_offset_from_reference_line"] +
                target_line_offset_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_lateral_error_reference:
            lateral_error_noise = self._noise_sample(
                record.error("bias_m"),
                record.error("noise_standard_deviation_m"),
            )
            return self._scale_observation_value(
                road_truth["lateral_error_from_reference_line"] +
                lateral_error_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_heading_gyro:
            heading_gyro_noise = self._noise_sample(
                record.error("bias_rad_per_s"),
                record.error("noise_standard_deviation_rad_per_s"),
            )
            return self._scale_observation_value(
                state_values[5] + heading_gyro_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_target_curvature:
            target_line_curvature_noise = self._noise_sample(
                record.error("bias_per_m"),
                record.error("noise_standard_deviation_per_m"),
            )
            return self._scale_observation_value(
                road_truth["target_line_curvature_at_closest_point"] +
                target_line_curvature_noise,
                record.scaling_factor,
            )
        if scalar_code == scalar_speed_limit:
            return self._scale_observation_value(
                road_info_dict["speed_limit_at_closest_p"],
                record.scaling_factor,
            )
        return self._scale_observation_value(
            road_info_dict["recommended_speed_at_closest_p"],
            record.scaling_factor,
        )

    def _write_scalar_observations(self, obs_dict, info_dict, road_info_dict, road_truth):
        state_values = self.car._state_values()
        for scalar_code, record, obs_targets, info_targets in self._scalar_observation_writer_specs:
            value = self._scalar_observation_value(
                scalar_code,
                record,
                road_info_dict,
                road_truth,
                state_values,
            )

            for obs_name in obs_targets:
                obs_dict[obs_name][0] = value
            for obs_name in info_targets:
                info_dict[obs_name][0] = value

        if self._should_write_accel_observations:
            ax, ay = self.car.compute_body_frame_acceleration()
            ax -= state_values[5] * state_values[4]
            ay += state_values[5] * state_values[3]
            accel_x_meas = self._scale_observation_value(
                ax,
                self._accel_x_record.scaling_factor,
            )
            accel_y_meas = self._scale_observation_value(
                ay,
                self._accel_y_record.scaling_factor,
            )
            for obs_name in self._accel_x_targets[0]:
                obs_dict[obs_name][0] = accel_x_meas
            for obs_name in self._accel_x_targets[1]:
                info_dict[obs_name][0] = accel_x_meas
            for obs_name in self._accel_y_targets[0]:
                obs_dict[obs_name][0] = accel_y_meas
            for obs_name in self._accel_y_targets[1]:
                info_dict[obs_name][0] = accel_y_meas

        for road_info_key, scaling, obs_targets, info_targets in self._next_speed_change_writer_specs:
            value = road_info_dict[road_info_key]
            if scaling is not None:
                value = self._scale_observation_value(value, scaling)
            for obs_name in obs_targets:
                obs_dict[obs_name][0] = value
            for obs_name in info_targets:
                info_dict[obs_name][0] = value

    def _write_scalar_observations_flat(self, flat_observation, info_dict, road_info_dict, road_truth):
        state_values = self.car._state_values()
        for scalar_code, record, obs_targets, info_targets in self._scalar_observation_writer_specs:
            value = self._scalar_observation_value(
                scalar_code,
                record,
                road_info_dict,
                road_truth,
                state_values,
            )

            for obs_name in obs_targets:
                flat_observation[self.flat_observation_slices[obs_name]][0] = value
            for obs_name in info_targets:
                info_dict[obs_name][0] = value

        if self._should_write_accel_observations:
            ax, ay = self.car.compute_body_frame_acceleration()
            ax -= state_values[5] * state_values[4]
            ay += state_values[5] * state_values[3]
            accel_x_meas = self._scale_observation_value(
                ax,
                self._accel_x_record.scaling_factor,
            )
            accel_y_meas = self._scale_observation_value(
                ay,
                self._accel_y_record.scaling_factor,
            )
            for obs_name in self._accel_x_targets[0]:
                flat_observation[self.flat_observation_slices[obs_name]][0] = accel_x_meas
            for obs_name in self._accel_x_targets[1]:
                info_dict[obs_name][0] = accel_x_meas
            for obs_name in self._accel_y_targets[0]:
                flat_observation[self.flat_observation_slices[obs_name]][0] = accel_y_meas
            for obs_name in self._accel_y_targets[1]:
                info_dict[obs_name][0] = accel_y_meas

        for road_info_key, scaling, obs_targets, info_targets in self._next_speed_change_writer_specs:
            value = road_info_dict[road_info_key]
            if scaling is not None:
                value = self._scale_observation_value(value, scaling)
            for obs_name in obs_targets:
                flat_observation[self.flat_observation_slices[obs_name]][0] = value
            for obs_name in info_targets:
                info_dict[obs_name][0] = value

    def _write_vector_observations(self, obs_dict, info_dict, road_info_dict):
        for compute_fn, record, obs_targets, info_targets in self._vector_observation_writer_specs:
            value = compute_fn(self, road_info_dict, record)
            self._write_observation_targets(obs_dict, info_dict, obs_targets, info_targets, value)

    def _write_vector_observations_flat(self, flat_observation, info_dict, road_info_dict):
        for compute_fn, record, obs_targets, info_targets in self._vector_observation_writer_specs:
            value = compute_fn(self, road_info_dict, record)
            self._write_flat_and_info_targets(flat_observation, info_dict, obs_targets, info_targets, value)

    def _sample_road_preview_for_observation(self, road_info_dict):
        """Return one detached physical-SI sample and private debug metadata."""
        self._road_preview_debug_snapshot = None
        actual_origin, total_length = self._validate_road_preview_base_origin(
            road_info_dict["reference_line_progress_at_closest_point"],
            "actual",
        )
        self._append_road_preview_localization_sample(actual_origin)
        if self.should_use_road_preview_latency:
            origin_snapshot = self._road_preview_localization_sample_at_time(
                self._simulation_time_s - self._road_preview_latency_s
            )
            if origin_snapshot is None:
                raise RuntimeError("Road preview delayed origin is unavailable.")
            base_origin, _ = self._validate_road_preview_base_origin(
                origin_snapshot["reference_line_progress_at_closest_point"],
                "delayed",
            )
            target_line_config = origin_snapshot["target_line_config"]
            lane_bounds_config = origin_snapshot["lane_bounds_config"]
        else:
            base_origin = actual_origin
            target_line_config = self._target_line_config
            lane_bounds_config = self._road_preview_lane_bounds_config

        target_line_progress_error = float(
            self._noise_sample(
                (
                    self._road_preview_query_origin_error[0] +
                    self._road_preview_localized_map_progress_random_walk_error_m
                ),
                self._road_preview_query_origin_error[1],
            )
        )
        if target_line_progress_error == 0.0:
            requested_origin = base_origin
        else:
            requested_origin = (
                self.road.map_target_line_displacement_to_reference_line_progress(
                    base_origin,
                    target_line_progress_error,
                    target_line_config=target_line_config,
                )
            )
        if not np.isfinite(requested_origin):
            raise RuntimeError("Road preview requested origin must be finite.")
        effective_origin = min(max(requested_origin, 0.0), total_length)
        sample = self.road.sample_target_line_horizon(
            effective_origin,
            self._road_preview_target_line_distances_m,
            target_line_config=target_line_config,
            lane_bounds_config=(
                lane_bounds_config
                if self._should_sample_road_preview_lane_bounds
                else None
            ),
        )
        self._road_preview_debug_snapshot = MappingProxyType(
            {
                "requested_origin_reference_progress_metres": requested_origin,
                "effective_origin_reference_progress_metres": effective_origin,
                "origin_was_saturated": requested_origin != effective_origin,
            }
        )
        return sample

    def _road_preview_writer_value(
        self,
        sample,
        writer_key,
        scaling,
    ):
        lane_availability = None
        sample_lane_availability = getattr(
            sample,
            "lane_bounds_are_available",
            None,
        )
        if sample_lane_availability is not None:
            lane_availability = np.logical_and(
                sample.is_spatially_valid,
                sample_lane_availability,
            )
        if writer_key == "lane_bounds_are_available":
            value = lane_availability
        else:
            value = getattr(sample, writer_key)
        if value is None:
            raise RuntimeError(
                "Road preview sample did not provide required field " + writer_key
            )
        value = np.asarray(value, dtype=np.float32)
        is_lane_bound = writer_key in (
            "right_lane_bound_offsets_from_target_line_m",
            "left_lane_bound_offsets_from_target_line_m",
        )
        if is_lane_bound:
            if lane_availability is None:
                raise RuntimeError("Road preview lane availability is unavailable")
            value = np.array(value, copy=True)
            unavailable = ~lane_availability
            value[unavailable] = (
                1.0
                if writer_key == "right_lane_bound_offsets_from_target_line_m"
                else -1.0
            )

        output_error = self._road_preview_output_errors.get(writer_key)
        if output_error is not None:
            noise_shape = value.shape
            if is_lane_bound:
                noise_shape = (int(np.count_nonzero(lane_availability)),)
            noise = (
                None
                if is_lane_bound and noise_shape[0] == 0
                else self._noise_sample(
                    output_error[0],
                    output_error[1],
                    noise_shape,
                )
            )
            if noise is not None:
                if is_lane_bound:
                    value[lane_availability] += noise
                else:
                    value = value + noise
        if scaling is not None:
            value = self._scale_observation_value(
                value,
                scaling,
                np.float32(scaling),
            )
        return value

    def _write_road_preview_observations(
        self,
        obs_dict,
        info_dict,
        road_info_dict,
    ):
        if not self.should_compute_road_preview:
            return
        sample = self._sample_road_preview_for_observation(road_info_dict)
        for (
            writer_key,
            scaling,
            obs_targets,
            info_targets,
        ) in self._road_preview_observation_writer_specs:
            value = self._road_preview_writer_value(
                sample,
                writer_key,
                scaling,
            )
            self._write_observation_targets(
                obs_dict,
                info_dict,
                obs_targets,
                info_targets,
                value,
            )

    def _write_road_preview_observations_flat(
        self,
        flat_observation,
        info_dict,
        road_info_dict,
    ):
        if not self.should_compute_road_preview:
            return
        sample = self._sample_road_preview_for_observation(road_info_dict)
        for (
            writer_key,
            scaling,
            obs_targets,
            info_targets,
        ) in self._road_preview_observation_writer_specs:
            value = self._road_preview_writer_value(
                sample,
                writer_key,
                scaling,
            )
            self._write_flat_and_info_targets(
                flat_observation,
                info_dict,
                obs_targets,
                info_targets,
                value,
            )



    def _get_nominal_ground_truth_lookahead_if_needed(self, road_info_dict):
        if not (
            self.ground_truth_mode == "full" and
            self._lookahead_outputs_are_routed and
            self._lookahead_acquisition_mode == "localized_map"
        ):
            return None

        px, py, theta, _, _, _, _ = self.car._state_values()
        progress_m = float(
            road_info_dict["reference_line_progress_at_closest_point"]
        )
        return self._get_road_info_for_pose(
            px=px,
            py=py,
            theta=theta,
            target_line_lookahead_distances_m=(
                self._target_line_lookahead_distances_m
            ),
            target_line_config=self._target_line_config,
            reference_line_progress_search={
                "lower_bound_m": progress_m,
                "upper_bound_m": progress_m,
            },
            include_next_speed_limit_change=False,
            include_next_recommended_speed_change=False,
            lookahead_result_fields={
                "target_line_lookahead.positions_in_body_frame_m",
                "target_line_lookahead.curvatures_per_m",
            },
            current_result_fields=set(),
        )

    def _get_road_info_and_cone_info_for_observation(self):
        if self.should_use_lookahead_localized_map_latency:
            road_info_dict = self._get_road_info(np.array([], dtype=np.float32))
            self._append_lookahead_localization_sample_if_needed(road_info_dict)
            road_info_dict = self._merge_delayed_localized_map_lookahead_if_needed(road_info_dict)
        else:
            lookahead_progress_queries = self._lookahead_progress_queries_for_source()
            road_info_dict = self._get_road_info(lookahead_progress_queries)
        nominal_ground_truth_lookahead = (
            self._get_nominal_ground_truth_lookahead_if_needed(road_info_dict)
        )
        cone_info = self._get_cone_info_for_observation_if_needed()
        return road_info_dict, cone_info, nominal_ground_truth_lookahead

    def _get_flat_observation_and_info_and_update_ground_truth(self):
        flat_observation = np.empty((self.flat_observation_size,), dtype=np.float32)
        info_dict = self._new_info_dict()
        if self.should_use_empty_observation:
            flat_observation[0] = np.float32(0.0)

        (
            road_info_dict,
            cone_info,
            nominal_ground_truth_lookahead,
        ) = self._get_road_info_and_cone_info_for_observation()

        road_truth = self._update_current_ground_truth_from_road_info(
            road_info_dict,
            nominal_ground_truth_lookahead,
        )
        self._write_ground_truth_state_observations_flat(flat_observation, info_dict)
        self._write_scalar_observations_flat(flat_observation, info_dict, road_info_dict, road_truth)
        self._write_vector_observations_flat(flat_observation, info_dict, road_info_dict)
        self._write_road_preview_observations_flat(
            flat_observation,
            info_dict,
            road_info_dict,
        )

        if cone_info is not None:
            self._write_cone_detections_to_flat_or_info(cone_info, flat_observation, info_dict)

        return flat_observation, info_dict

    def _get_observation_and_info_and_update_ground_truth(self):
        """
        Build the current observation and info outputs.

        Parameters
        ----------
        Nothing

        Returns
        -------
        observation
            Observation in the configured observation_format.
        info_dict : dictionary
            Enabled info fields and auxiliary step details.
        """
        if self.observation_format == "flat":
            return self._get_flat_observation_and_info_and_update_ground_truth()

        obs_dict, info_dict = self._new_observation_and_info_dicts()

        (
            road_info_dict,
            cone_info,
            nominal_ground_truth_lookahead,
        ) = self._get_road_info_and_cone_info_for_observation()

        road_truth = self._update_current_ground_truth_from_road_info(
            road_info_dict,
            nominal_ground_truth_lookahead,
        )
        self._write_ground_truth_state_observations(obs_dict, info_dict)
        self._write_scalar_observations(obs_dict, info_dict, road_info_dict, road_truth)
        self._write_vector_observations(obs_dict, info_dict, road_info_dict)
        self._write_road_preview_observations(obs_dict, info_dict, road_info_dict)

        if cone_info is not None:
            self._write_cone_detections_to_dicts(cone_info, obs_dict, info_dict)

        return self._format_observation_for_return(obs_dict), info_dict

    def _get_road_info(self, progress_queries):
        """
        Get selected Road fields for the current car pose.

        Parameters
        ----------
            progress_queries : numpy arrray, 1-dimensional
                Target-line distance queries, relative to the current closest
                reference-line progress, at which lookahead information should
                be generated.
                Units: meters

        Returns
        -------
            road_info_dict : dictionary
                Selected current, lookahead, and speed-change fields returned
                by Road according to this environment's field selectors.
                Common fields include:
                - "speed_limit_at_closest_p" : float
                    Speed limit at the closest point.
                - "recommended_speed_at_closest_p" : float
                    Recommended speed at the closest point.
                - "closest_element_idx" : int
                    The index of the road element that is closest to the car.
                - "target_line_offset_from_reference_line" : float
                    Signed target-line offset from the reference line.
                - "lateral_error_from_target_line" : float
                    Signed lateral error from the target line.
                - "target_line_px_closest", "target_line_py_closest" : float
                    World-frame coordinate of the current target-line point.
                - "target_line_px_closest_in_body_frame", "target_line_py_closest_in_body_frame" : float
                    Body-frame coordinate of the current target-line point.
                - "heading_error_from_target_line_rad" : float
                    Car heading minus target-line tangent angle, wrapped to
                    ``[-pi, pi)``.
                - "target_line_curvature_at_closest_p" : float
                    Target-line curvature at the current point.
                - "target_line_reference_progress_queries_from_start" : numpy array
                    Reference-line progress values corresponding to target-line
                    distance lookahead queries.
                - "target_line_points_in_body_frame" : numpy array
                    Target-line lookahead coordinates in body frame.
                - "target_line_angles_relative_to_body_frame" : numpy array
                    Target-line tangent angles minus car heading at lookahead queries.
                - "target_line_curvatures" : numpy array
                    Target-line curvatures at lookahead queries.
                - "reference_line_progress_at_closest_point" : float
                    Reference-line progress at the closest reference-line point.
                - "lateral_error_from_reference_line" : float
                    Signed lateral error from the reference line.
                - "reference_line_px_closest", "reference_line_py_closest" : float
                    World-frame coordinate of the closest reference-line point.

                - "next_speed_limit" : float
                    The speed limit next time it changes
                - "distance_to_next_speed_limit
                    The road progress distance from the current point upto when the next speed limit starts
                - "next_recommended_speed" : float
                    The recommended next time it changes
                - "distance_to_next_recommended_speed
                    The road progress distance from the current point upto when the next recommended speed starts

                Units: all lengths in meters, all angles in radians, all speeds in meters/second.
        """
        px, py, theta, _, _, _, _ = self.car._state_values()
        pending_search = self._pending_reference_line_progress_search
        if pending_search is not _NO_PENDING_REFERENCE_LINE_PROGRESS_SEARCH:
            reference_line_progress_search = pending_search
        elif self.should_use_reference_line_progress_hint:
            radius_m = float(self.reference_line_progress_search_radius_m)
            progress_hint_m = float(self._previous_reference_line_progress_m)
            reference_line_progress_search = {
                "lower_bound_m": progress_hint_m - radius_m,
                "upper_bound_m": progress_hint_m + radius_m,
            }
        else:
            reference_line_progress_search = None
        road_info = self._get_road_info_for_pose(
            px=px,
            py=py,
            theta=theta,
            target_line_lookahead_distances_m=(
                np.empty((0,), dtype=np.float32)
                if np.any(progress_queries < 0.0)
                else progress_queries
            ),
            target_line_config=self._target_line_config,
            reference_line_progress_search=reference_line_progress_search,
            include_next_speed_limit_change=(
                self.should_compute_next_speed_limit_change
            ),
            include_next_recommended_speed_change=(
                self.should_compute_next_recommended_speed_change
            ),
            lookahead_result_fields=self._road_lookahead_result_fields,
            current_result_fields=self._road_current_result_fields,
        )
        if np.any(progress_queries < 0.0):
            road_info.update(
                self._sample_prestart_localized_lookahead(
                    px=px,
                    py=py,
                    theta=theta,
                    origin_reference_line_progress_m=road_info[
                        "reference_line_progress_at_closest_point"
                    ],
                    signed_target_line_distances_m=progress_queries,
                    lookahead_result_fields=self._road_lookahead_result_fields,
                    target_line_config=self._target_line_config,
                )
            )
        return road_info

    def _sample_prestart_localized_lookahead(
        self,
        *,
        px,
        py,
        theta,
        origin_reference_line_progress_m,
        signed_target_line_distances_m,
        lookahead_result_fields,
        target_line_config,
    ):
        """Sample signed localized queries with Road's lightweight semantics."""

        target_geometry = self.road._Road__target_geometry()
        reference_progresses, metadata = (
            target_geometry.reference_progresses_for_target_line_config_distances(
                float(origin_reference_line_progress_m),
                np.asarray(signed_target_line_distances_m, dtype=np.float32),
                target_line_config,
                return_metadata=True,
            )
        )
        reference_progresses = np.maximum(
            reference_progresses,
            np.float32(0.0),
        ).astype(np.float32, copy=False)
        validation_progresses = np.clip(
            np.append(
                reference_progresses,
                np.float32(origin_reference_line_progress_m),
            ),
            np.float32(0.0),
            np.float32(self.road.total_length_m),
        )
        target_geometry.validate_target_line_config_over_reference_progress_range(
            float(np.min(validation_progresses)),
            float(np.max(validation_progresses)),
            target_line_config,
        )

        positions_field = "target_line_lookahead.positions_in_body_frame_m"
        curvatures_field = "target_line_lookahead.curvatures_per_m"
        should_sample_positions = positions_field in lookahead_result_fields
        should_sample_curvatures = curvatures_field in lookahead_result_fields
        reference_samples = target_geometry.reference_line_samples_at_progresses(
            reference_progresses,
            include_coordinates=should_sample_positions,
            include_angles=should_sample_positions,
            include_curvatures=should_sample_curvatures,
            include_speeds=False,
            include_element_indices=False,
            element_indices=metadata["element_indices"],
            element_indices_are_trusted=metadata["element_indices_are_trusted"],
            progression_queries_are_in_bounds=metadata[
                "progression_queries_are_in_bounds"
            ],
        )
        body_frame_pose = None
        if should_sample_positions:
            body_frame_pose = (
                float(px),
                float(py),
                float(np.cos(theta)),
                float(np.sin(theta)),
            )
        target_samples = (
            target_geometry.target_line_geometry_from_reference_samples_for_config(
                reference_progresses,
                reference_samples,
                target_line_config,
                include_offsets=False,
                include_points=False,
                include_body_points=should_sample_positions,
                body_frame_pose=body_frame_pose,
                include_angles=False,
                include_curvatures=should_sample_curvatures,
                include_speed_scale=False,
            )
        )
        road_info = {}
        if should_sample_positions:
            road_info["target_line_points_in_body_frame"] = target_samples[
                "body_points"
            ]
        if should_sample_curvatures:
            road_info["target_line_curvatures"] = target_samples["curvatures"]
        return road_info

    def _get_road_info_for_pose(
        self,
        px,
        py,
        theta,
        target_line_lookahead_distances_m,
        target_line_config,
        reference_line_progress_search,
        include_next_speed_limit_change,
        include_next_recommended_speed_change,
        lookahead_result_fields,
        current_result_fields,
    ):
        result = self.road.road_info_at_given_pose_and_progress_queries(
            px=px,
            py=py,
            theta=theta,
            target_line_lookahead_distances_m=target_line_lookahead_distances_m,
            target_line_config=target_line_config,
            reference_line_progress_search=reference_line_progress_search,
            include_next_speed_limit_change=include_next_speed_limit_change,
            include_next_recommended_speed_change=(
                include_next_recommended_speed_change
            ),
            lookahead_result_fields=lookahead_result_fields,
            current_result_fields=current_result_fields,
        )
        return self._observation_road_info_from_nested_result(result)

    def _observation_road_info_from_nested_result(self, result):
        """Project selected nested Road fields into the current observation writers."""
        road_info = {}
        reference_line = result.get("reference_line", {})
        closest_point = reference_line.get("closest_point", {})
        reference_error = reference_line.get("tracking_error", {})
        target_line = result.get("target_line", {})
        target_at_progress = target_line.get(
            "at_closest_reference_line_progress", {}
        )
        target_error = target_line.get("tracking_error", {})
        speed_at_progress = result.get("speed_profile", {}).get(
            "at_closest_reference_line_progress", {}
        )
        lookahead = result.get("target_line_lookahead", {})

        scalar_mappings = (
            (closest_point, "road_element_index", "closest_element_idx"),
            (
                closest_point,
                "progress_m",
                "reference_line_progress_at_closest_point",
            ),
            (
                reference_error,
                "lateral_error_from_reference_line_m",
                "lateral_error_from_reference_line",
            ),
            (
                target_at_progress,
                "target_line_offset_from_reference_line_m",
                "target_line_offset_from_reference_line",
            ),
            (
                target_at_progress,
                "target_line_curvature_per_m",
                "target_line_curvature_at_closest_p",
            ),
            (
                target_error,
                "lateral_error_from_target_line_m",
                "lateral_error_from_target_line",
            ),
            (
                target_error,
                "heading_error_from_target_line_rad",
                "heading_error_from_target_line_rad",
            ),
            (speed_at_progress, "speed_limit_mps", "speed_limit_at_closest_p"),
            (
                speed_at_progress,
                "recommended_speed_mps",
                "recommended_speed_at_closest_p",
            ),
            (
                lookahead,
                "positions_in_body_frame_m",
                "target_line_points_in_body_frame",
            ),
            (
                lookahead,
                "curvatures_per_m",
                "target_line_curvatures",
            ),
        )
        for source, source_key, destination_key in scalar_mappings:
            if source_key in source:
                road_info[destination_key] = source[source_key]

        point_mappings = (
            (
                closest_point,
                "position_in_world_frame_m",
                "reference_line_px_closest",
                "reference_line_py_closest",
            ),
            (
                closest_point,
                "position_in_body_frame_m",
                "reference_line_px_closest_in_body_frame",
                "reference_line_py_closest_in_body_frame",
            ),
            (
                target_at_progress,
                "position_in_world_frame_m",
                "target_line_px_closest",
                "target_line_py_closest",
            ),
            (
                target_at_progress,
                "position_in_body_frame_m",
                "target_line_px_closest_in_body_frame",
                "target_line_py_closest_in_body_frame",
            ),
        )
        for source, source_key, x_key, y_key in point_mappings:
            if source_key in source:
                point = source[source_key]
                road_info[x_key] = point[0]
                road_info[y_key] = point[1]

        next_change_mappings = (
            (
                "next_speed_limit_change",
                "speed_limit_at_closest_p",
                "next_speed_limit",
                "distance_to_next_speed_limit",
                "next_speed_limit_change_exists",
            ),
            (
                "next_recommended_speed_change",
                "recommended_speed_at_closest_p",
                "next_recommended_speed",
                "distance_to_next_recommended_speed",
                "next_recommended_speed_change_exists",
            ),
        )
        for (
            result_key,
            current_key,
            value_key,
            distance_key,
            exists_key,
        ) in next_change_mappings:
            if result_key not in result:
                continue
            change = result[result_key]
            if change is None:
                road_info[value_key] = road_info[current_key]
                road_info[distance_key] = self._road_total_length_m + 1.0
                road_info[exists_key] = 0.0
            else:
                road_info[value_key] = change["value_mps"]
                road_info[distance_key] = change["reference_line_distance_m"]
                road_info[exists_key] = 1.0

        return road_info

    def _scaling_for_observation_key(self, key):
        spec = OBSERVATION_SPEC_BY_NAME.get(key)
        if spec is None:
            return None
        return self._compiled_observation_by_name[spec.name].scaling_factor

    def undo_scaling(self, values):
        if isinstance(values, np.ndarray):
            flat_values = np.asarray(values, dtype=np.float32).reshape(-1)
            if flat_values.shape != self._flat_observation_unscale_factors.shape:
                raise ValueError(
                    "Flat observation has size " + str(flat_values.shape[0]) +
                    ", expected " + str(self.flat_observation_size) + "."
            )
            for key in self.flat_observation_names:
                scaling = self._scaling_for_observation_key(key)
                if scaling is not None and float(scaling) == 0.0:
                    raise ValueError(
                        "Cannot undo scaling for '" + key + "': " +
                        "its configured scaling_factor is zero."
                    )
            return flat_values * self._flat_observation_unscale_factors

        unscaled_dict = values.copy()
        for key, value in values.items():
            scaling = self._scaling_for_observation_key(key)
            if scaling is not None:
                if float(scaling) == 0.0:
                    raise ValueError(
                        "Cannot undo scaling for '" + key + "': " +
                        "its configured scaling_factor is zero."
                    )
                else:
                    unscaled_dict[key] = value / scaling
            else:
                unscaled_dict[key] = value
        return unscaled_dict

    def _validate_reset_steering_observation_bounds(self, steering_bounds):
        observation_space = (
            self._ground_truth_front_wheel_steering_observation_space
        )
        if observation_space is None:
            return
        scaling = self._compiled_observation_by_name[
            "ground_truth_front_wheel_steering_angle_rad"
        ].scaling_factor
        for endpoint in ("lower", "upper"):
            transformed = np.empty((1,), dtype=np.float32)
            transformed[0] = self._scale_observation_value(
                steering_bounds[endpoint], scaling
            )
            if not observation_space.contains(transformed):
                raise ValueError(
                    "options.initial_state_config.bounds."
                    "front_wheel_steering_angle_rad."
                    + endpoint
                    + " is outside the constructor-compiled observation space."
                )



    def reset(self, seed=None, options=None):
        """
        Resets the position of the car and generates an observation

        Parameters
        ----------
            seed : int
                For seeding the numpy random number generator
            options : dictionary
                Strict mapping whose only supported key is
                ``initial_state_config``. Its value is a sparse reset overlay:
                omitted state leaves inherit constructor-effective bounds and
                either endpoint of a supplied leaf may override independently.
                An omitted search interval inherits, explicit ``None`` disables
                it for this reset, and a supplied search mapping requires both
                bounds.

        Returns
        -------
            (observation, info) : tuple
                `observation` uses the configured observation_format; `info`
                contains enabled info fields and auxiliary reset details.
        """

        if options is None:
            supplied_options = {}
        else:
            supplied_options = required_detached_mapping(options, "options")
        reject_unknown_keys(supplied_options, {"initial_state_config"}, "options")
        if "initial_state_config" in supplied_options:
            effective_initial_state_config = normalize_initial_state_reset_overlay(
                supplied_options["initial_state_config"],
                self._initial_state_config,
            )
        else:
            effective_initial_state_config = copy.deepcopy(
                self._initial_state_config
            )

        # Validate and detach before seeding or sampling.
        self._validate_reset_steering_observation_bounds(
            effective_initial_state_config["bounds"][
                "front_wheel_steering_angle_rad"
            ]
        )
        super().reset(seed=seed)
        self._reset_observation_noise_rng()
        self._prepare_cone_detections_for_episode(rng=self.np_random)

        bounds = effective_initial_state_config["bounds"]
        world_pose_bounds = bounds["world_pose"]
        body_motion_bounds = bounds["body_motion"]
        steering_bounds = bounds["front_wheel_steering_angle_rad"]

        def sample(bound_record):
            return self.np_random.uniform(
                low=bound_record["lower"],
                high=bound_record["upper"],
            )

        self.car.reset(
            state={
                "world_pose": {
                    "x_m": sample(world_pose_bounds["x_m"]),
                    "y_m": sample(world_pose_bounds["y_m"]),
                    "heading_rad": sample(world_pose_bounds["heading_rad"]),
                },
                "body_motion": {
                    "longitudinal_velocity_mps": sample(
                        body_motion_bounds["longitudinal_velocity_mps"]
                    ),
                    "lateral_velocity_mps": sample(
                        body_motion_bounds["lateral_velocity_mps"]
                    ),
                    "yaw_rate_rad_per_s": sample(
                        body_motion_bounds["yaw_rate_rad_per_s"]
                    ),
                },
                "front_wheel_steering_angle_rad": sample(steering_bounds),
            }
        )
        self._simulation_time_s = 0.0
        self._reset_lookahead_localization_noise_state()
        self._reset_road_preview_localization_noise_state()
        self._previous_reference_line_road_element_index = None
        self.should_use_reference_line_progress_hint = False
        self.reference_line_progress_search_radius_m = None
        self._pending_reference_line_progress_search = (
            effective_initial_state_config["reference_line_progress_search"]
        )

        # The search interval belongs to this reset attempt even if observation
        # construction raises.
        try:
            observation, info_dict = (
                self._get_observation_and_info_and_update_ground_truth()
            )
            self._latest_observation = self._copy_observation(observation)
            self._latest_info = info_dict
        finally:
            self._pending_reference_line_progress_search = (
                _NO_PENDING_REFERENCE_LINE_PROGRESS_SEARCH
            )

        # Set the previous progress variable
        self._previous_reference_line_progress_m = self._current_ground_truth[
            "reference_line_progress_m"
        ]
        self._previous_reference_line_road_element_index = self._current_ground_truth[
            "reference_line_road_element_index"
        ]
        self.should_use_reference_line_progress_hint = True
        self.reference_line_progress_search_radius_m = 0.0

        # Reset internal policy state
        self._cruise_integral = 0.0
        self._cruise_prev_error = 0.0

        # Render, if necessary
        if self.render_mode == "human":
            self._render_frame()

        # Return the observation and info dictionary
        return observation, info_dict



    def step(self, action):
        """
        Steps forward the car by one time increment,
        and generates an observation.

        Parameters
        ----------
            action : array-like
                Must match `self.action_space` for the resolved runtime mode:
                normalized [drive, steering] for "full" (shape (2,)), [drive]
                for "drive_only" (shape (1,)), [steering] for "steer_only"
                (shape (1,)), or the fixed no-op for "none" (shape (1,)).
                Missing axes start at zero and enabled internal policies may
                control them. A normalized steering command maps to the
                bicycle model's end-of-step steering-angle request.

        Returns
        -------
            (observation, reward, terminated, truncated, info) : tuple
                `observation` uses the configured observation_format. The base
                `reward` is `0.0`. `terminated` reports natural environment
                endings, while the base environment's independent `truncated`
                flag is always `False`; an outer `TimeLimit` may set it to
                `True`. `info` contains enabled fields, termination reasons,
                with no base-environment reward metadata.
        """

        # Optionally override parts of the incoming action using internal policies
        # Expand the provided action according to the configured interface
        _a = np.array(action, dtype=np.float32).ravel()
        _mode = self._effective_action_interface
        if _mode == "full":
            drive_cmd = float(_a[0])
            steering_cmd = float(_a[1])
        elif _mode == "drive_only":
            drive_cmd = float(_a[0])
            steering_cmd = 0.0
        elif _mode == "steer_only":
            drive_cmd = 0.0
            steering_cmd = float(_a[0])
        elif _mode == "none":
            drive_cmd = 0.0
            steering_cmd = 0.0
        else:
            raise RuntimeError(f"Unsupported action_interface '{_mode}'")

        steering_cmd = max(-1.0, min(steering_cmd, 1.0))
        delta_req = steering_cmd * float(
            self.car._requested_front_wheel_angle_magnitude_limit_rad
        )

        should_call_custom_controller = (
            (
                self._lane_keeping_enabled
                and self._lane_keeping_policy_callable is not None
            )
            or (
                self._cruise_control_enabled
                and self._cruise_control_policy_callable is not None
            )
        )
        # Custom controllers consume the cached observation from the previous
        # reset/step, i.e. the same obs_k format and snapshot the agent used.
        cached_observation = self._latest_observation
        if (
            cached_observation is None and
            should_call_custom_controller
        ):
            # `step` before `reset` is invalid Gymnasium usage, but keep custom
            # callbacks from seeing an uninitialized observation in that case.
            cached_observation = {}

        # Lane keeping controller (steering)
        if self._lane_keeping_enabled:
            if self._lane_keeping_policy_callable is not None:
                # Custom lane keep consumes the cached agent observation.
                lane_observation = self._copy_observation(cached_observation)
                delta_req = float(
                    self._lane_keeping_policy_callable(self, lane_observation)
                )
            else:
                delta_req = float(self._default_lane_keep_delta())

        # Cruise control controller (longitudinal drive command)
        if self._cruise_control_enabled:
            if self._cruise_control_policy_callable is not None:
                # Custom cruise consumes the cached agent observation.
                cruise_observation = self._copy_observation(cached_observation)
                drive_cmd = float(
                    self._cruise_control_policy_callable(self, cruise_observation)
                )
            else:
                drive_cmd = float(self._default_cruise_drive_command())

        # Set the action request for bicycle model
        self.car.set_action_request(
            normalized_drive_command=drive_cmd,
            requested_front_wheel_angle_rad=delta_req,
        )

        px_before_integration, py_before_integration, _, _, _, _, _ = (
            self.car._state_values()
        )

        # Perform one integration step
        self.car.integrate(
            duration_s=self.environment_step_duration_s,
            method=self.integration_method,
            substep_count=self.integration_substep_count,
            update_stored_state=True,
        )

        px_after_integration, py_after_integration, _, vx, vy, _, _ = (
            self.car._state_values()
        )
        self.reference_line_progress_search_radius_m = (
            2.0 * (
                abs(px_after_integration - px_before_integration) +
                abs(py_after_integration - py_before_integration)
            ) + 1e-6
        )
        self._simulation_time_s += float(self.environment_step_duration_s)
        self._advance_lookahead_localization_noise_state(
            self.environment_step_duration_s
        )
        self._advance_road_preview_localization_noise_state(
            self.environment_step_duration_s
        )

        # Get the observation
        observation, info_dict = self._get_observation_and_info_and_update_ground_truth()
        self._latest_observation = self._copy_observation(observation)
        self._latest_info = info_dict

        # Extract the value of "progress at closest point"
        progress_at_closest_point = self._current_ground_truth[
            "reference_line_progress_m"
        ]

        # Extract the lateral error from the selected target line
        lateral_error_from_target_line = self._current_ground_truth[
            "lateral_error_from_target_line_m"
        ]

        # Compute the speed of the car
        car_speed = math.hypot(float(vx), float(vy))

        # Compute the "terminated" flag and reasons
        termination_reasons = {
            "road_progress_completion_threshold_reached": (
                progress_at_closest_point >= self._road_progress_completion_threshold_m
            ),
            "planar_speed_below_lower_bound": (
                car_speed < self.termination_planar_speed_lower_bound_mps
            ),
            "planar_speed_above_upper_bound": (
                car_speed > self.termination_planar_speed_upper_bound_mps
            ),
            "absolute_lateral_error_from_target_line_above_upper_bound": (
                abs(lateral_error_from_target_line) >
                self.termination_absolute_lateral_error_from_target_line_upper_bound_m
            ),
        }
        terminated = any(termination_reasons.values())
        info_dict["termination_reasons"] = termination_reasons

        # Compute the "truncated" flag
        truncated = False

        # Set the reward to zero; reward shaping to be done in a wrapper
        reward = 0.0
        self._previous_reference_line_progress_m = progress_at_closest_point
        self._previous_reference_line_road_element_index = self._current_ground_truth[
            "reference_line_road_element_index"
        ]
        self.should_use_reference_line_progress_hint = True
        self.reference_line_progress_search_radius_m = 0.0

        # Render, if necessary
        if self.render_mode == "human":
            self._render_frame()

        # Return the observation and info dictionary
        return observation, reward, terminated, truncated, info_dict        


    # ---------------------------
    # INTERNAL POLICY CONTROLLERS
    # ---------------------------
    def _default_lane_keep_delta(self):
        """
        Simple lane-keeping controller that combines lateral error, heading error,
        and a curvature feedforward term.

        Returns
        -------
        float
            End-of-step steering angle request (radians), clipped to the model limits.
        """
        # Errors relative to the selected target line.
        y_err = float(self._current_ground_truth["lateral_error_from_target_line_m"])
        psi_err = float(
            self._current_ground_truth["heading_error_from_target_line_rad"]
        )
        curvature = float(self._current_ground_truth["target_line_curvature_per_m"])

        policy = self._lane_keeping_built_in_policy
        k_y = float(policy["lateral_error_feedback_gain_rad_per_m"])
        k_psi = float(policy["heading_error_feedback_gain"])
        k_ff = float(policy["curvature_feedforward_gain"])

        # Feedforward based on bicycle model kinematics
        L = float(
            self.car._front_axle_distance_from_center_of_mass_m
            + self.car._rear_axle_distance_from_center_of_mass_m
        )
        delta_ff = np.arctan(L * curvature)

        delta_req = -k_y * y_err - k_psi * psi_err + k_ff * delta_ff
        # Clip to steering request bounds
        delta_req = np.clip(
            delta_req,
            -self.car._requested_front_wheel_angle_magnitude_limit_rad,
            self.car._requested_front_wheel_angle_magnitude_limit_rad,
        )
        return delta_req

    def _default_cruise_drive_command(self):
        """
        Apply PI(D) cruise control using the configured exclusive target source.

        The road-derived target uses the positive road recommendation and then
        the positive road speed limit; the fixed target uses its validated
        positive ``value_mps`` value.

        Returns
        -------
        float
            Normalized drive command in [-1, 1].
        """
        policy = self._cruise_control_built_in_policy
        target_speed = policy["target_speed"]
        if target_speed["source"] == "road_recommended_speed_then_speed_limit":
            v_target = resolve_positive_road_speed_target_mps(
                self._current_ground_truth["recommended_speed_mps"],
                self._current_ground_truth["speed_limit_mps"],
            )
        else:
            v_target = float(target_speed["value_mps"])
        _, _, _, vx, _, _, _ = self.car._state_values()
        v_meas = float(vx)
        e = v_target - v_meas
        environment_step_duration_s = float(self.environment_step_duration_s)

        # PI(D) update with basic anti-windup on integral
        pid = policy["pid"]
        self._cruise_integral += e * environment_step_duration_s
        integral_limit = pid["integrated_speed_error_limit_m"]
        self._cruise_integral = max(
            -integral_limit,
            min(self._cruise_integral, integral_limit),
        )
        de = (
            (e - self._cruise_prev_error) / environment_step_duration_s
            if environment_step_duration_s > 0
            else 0.0
        )
        self._cruise_prev_error = e

        cmd = (
            pid["proportional_gain_per_mps"] * e
            + pid["integral_gain_per_m"] * self._cruise_integral
            + pid["derivative_gain_per_mps2"] * de
        )
        # Clip to valid drive command range
        cmd = max(-1.0, min(cmd, 1.0))
        return cmd

    def _begin_render_overlay_episode(self, episode_generation):
        generation = _validated_nonnegative_integer(
            episode_generation,
            name="episode_generation",
        )
        if self.render_mode is None:
            raise RuntimeError(
                "A render overlay episode requires an active environment render mode."
            )
        self._render_overlay_snapshot = None
        self._render_overlay_episode_generation = generation

    def _publish_render_overlay_snapshot(self, snapshot):
        if not isinstance(snapshot, _AutonomousDrivingRenderOverlaySnapshot):
            raise TypeError(
                "snapshot must be an _AutonomousDrivingRenderOverlaySnapshot."
            )
        active_generation = getattr(
            self,
            "_render_overlay_episode_generation",
            None,
        )
        if active_generation is None:
            raise RuntimeError("No render overlay episode is active.")
        if snapshot.episode_generation != active_generation:
            raise RuntimeError(
                "Render overlay snapshot generation does not match the active "
                "episode generation."
            )
        self._render_overlay_snapshot = snapshot

    def _clear_render_overlay_snapshot(self, episode_generation):
        generation = _validated_nonnegative_integer(
            episode_generation,
            name="episode_generation",
        )
        active_generation = getattr(
            self,
            "_render_overlay_episode_generation",
            None,
        )
        if active_generation is None:
            return
        if generation != active_generation:
            raise RuntimeError(
                "Cannot clear a render overlay from a different episode generation."
            )
        self._render_overlay_snapshot = None

    def _finish_render_overlay_episode(self, episode_generation):
        generation = _validated_nonnegative_integer(
            episode_generation,
            name="episode_generation",
        )
        active_generation = getattr(
            self,
            "_render_overlay_episode_generation",
            None,
        )
        if active_generation is None:
            return
        if generation != active_generation:
            raise RuntimeError(
                "Cannot finish a render overlay from a different episode generation."
            )
        self._render_overlay_snapshot = None
        self._render_overlay_episode_generation = None

    def _get_renderer(self):
        if self._renderer is None:
            from dreamgym.envs.autonomous_driving_renderer import (
                PygameAutonomousDrivingRenderer,
            )

            self._renderer = PygameAutonomousDrivingRenderer(
                self,
                render_mode=self.render_mode,
                render_config=self._render_config,
                visualization_theme=self._resolve_visualization_theme(),
            )
        return self._renderer

    def _resolve_visualization_theme(self):
        if self._visualization_theme is _UNRESOLVED_VISUALIZATION_THEME:
            from dreamgym.visualization.autonomous_driving.theme import (
                resolve_autonomous_driving_visualization_theme,
            )

            self._visualization_theme = (
                resolve_autonomous_driving_visualization_theme()
            )
        return self._visualization_theme

    @property
    def visualization_theme(self):
        return self._resolve_visualization_theme()

    @property
    def resolved_render_config(self):
        """Complete detached read-only operational render configuration."""

        return _detached_read_only_render_value(self._render_config)

    @property
    def requested_road_spec(self):
        return copy.deepcopy(self.__requested_road_spec)

    @property
    def resolved_road_preview_metadata(self):
        """Detached read-only target and lane provenance for road preview."""

        return self._resolved_road_preview_metadata

    @property
    def road(self):
        return self.__road

    def _render_frame(self):
        if self.render_mode is None:
            return None
        return self._get_renderer().render_frame()

    def render(self):
        if self.render_mode == "rgb_array":
            return self._render_frame()
        if self.render_mode == "human":
            self._render_frame()
            return None
        return None



    def close(self):
        if hasattr(self, "_render_overlay_snapshot"):
            self._render_overlay_snapshot = None
            self._render_overlay_episode_generation = None
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None



    # -------------------------
    # GETTER AND SETTER METHODS
    # -------------------------

    def get_current_ground_truth(self):
        return {
            key: np.copy(value) if isinstance(value, np.ndarray) else value
            for key, value in self._current_ground_truth.items()
        }

    @property
    def integration_method(self):
        return self._integration_method

    @integration_method.setter
    def integration_method(self, integration_method):
        normalized = normalize_integration_config(
            {"method": integration_method}
        )
        self._integration_method = normalized["method"]

    @property
    def environment_step_duration_s(self):
        return self._environment_step_duration_s

    @environment_step_duration_s.setter
    def environment_step_duration_s(self, environment_step_duration_s):
        normalized = normalize_integration_config(
            {"environment_step_duration_s": environment_step_duration_s}
        )
        self._environment_step_duration_s = normalized[
            "environment_step_duration_s"
        ]
        if hasattr(self, "_should_compute_target_line_lookahead"):
            self._configure_lookahead_localization_latency()
            self._reset_lookahead_localization_noise_state()
        if hasattr(self, "should_compute_road_preview"):
            self._configure_road_preview_latency()
            self._reset_road_preview_localization_noise_state()

    @property
    def integration_substep_count(self):
        return self._integration_substep_count

    @integration_substep_count.setter
    def integration_substep_count(self, integration_substep_count):
        normalized = normalize_integration_config(
            {"substep_count": integration_substep_count}
        )
        self._integration_substep_count = normalized["substep_count"]

    @property
    def tire_force_condition(self):
        return self.car.tire_force_condition

    @property
    def effective_tire_force_factors(self):
        return self.car.effective_tire_force_factors

    def set_tire_force_condition(self, condition, factors=None):
        self.car.set_tire_force_condition(condition, factors=factors)

    # def set_progress_queries_for_generating_observations(self, progress_queries):
    #     """
    #     Parameters
    #     ----------
    #         "progress_queries" : numpy array, 1-dimensional
    #         Specifies the values of progress-along-the-road,
    #         relative to the current position of the car, at
    #         which the observations should be generated. These
    #         observations are returned in the "info_dict".
    #         (Units: meters)

    #     Returns
    #     -------
    #     Nothing
    #     """
    #     # Get the progress query values
    #     self.progress_queries = progress_queries
