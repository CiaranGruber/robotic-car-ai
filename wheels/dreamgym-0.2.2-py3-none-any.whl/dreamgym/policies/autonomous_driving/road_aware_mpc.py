"""Road-aware model-predictive policies for autonomous driving."""

from __future__ import annotations

from dataclasses import replace
from time import perf_counter

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_adapter import (
    _require_observation_layout,
)
from dreamgym.policies.autonomous_driving._mpc_failures import (
    _MPCPolicyInputError,
)
from dreamgym.policies.autonomous_driving._mpc_policy_base import (
    _AutonomousDrivingMPCPolicyBase,
    _MPCModelSchedule,
    _MPCReferenceSchedule,
)
from dreamgym.policies.autonomous_driving._mpc_road_aware_formulations import (
    build_direct_steering_feedforward,
    build_road_aware_direct_steering_model_schedule,
    build_road_aware_steering_rate_model_schedule,
    build_steering_rate_feedforward,
)
from dreamgym.policies.autonomous_driving._mpc_road_horizon import (
    finalize_road_horizon_context,
    materialize_road_horizon,
    required_road_preview_fields,
)
from dreamgym.policies.autonomous_driving.mpc import (
    AutonomousDrivingDirectSteeringMPCPolicy,
    AutonomousDrivingSteeringRateMPCPolicy,
)
from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
)
from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCPolicyFailure,
    MPCPolicyFailureStage,
    MPCRoadHorizonContext,
)
from dreamgym.policies.mpc import LinearQuadraticMPCProblem


def _raise_classified_formulation_failure(
    *,
    reason: str,
    field_name: str,
    message: str,
) -> None:
    raise _MPCPolicyInputError(
        MPCPolicyFailure(
            stage=MPCPolicyFailureStage.FORMULATION,
            reason=reason,
            field_name=field_name,
            message=message,
        )
    )


def _require_finite_target_geometry_schedule(
    field_name: str,
    values: np.ndarray,
) -> None:
    if not np.isfinite(values).all():
        _raise_classified_formulation_failure(
            reason="target_geometry_invalid",
            field_name=field_name,
            message=f"{field_name} is nonfinite for the finite road preview",
        )


def _require_finite_model_schedule_input(
    linearization_speeds: np.ndarray,
) -> None:
    with np.errstate(over="ignore", invalid="ignore"):
        squared_speeds = np.square(linearization_speeds)
    if not np.isfinite(squared_speeds).all():
        _raise_classified_formulation_failure(
            reason="formulation_input_invalid",
            field_name="linearization_speeds_mps",
            message=(
                "linearization_speeds_mps cannot be squared finitely for "
                "the kinematic MPC formulation"
            ),
        )


def _validated_road_aware_model_schedule(
    schedule: _MPCModelSchedule,
    *,
    curvature_enabled: bool,
) -> _MPCModelSchedule:
    for field_name in ("state_matrices", "control_matrices"):
        matrices = getattr(schedule, field_name)
        if not all(np.isfinite(matrix).all() for matrix in matrices):
            _raise_classified_formulation_failure(
                reason="formulation_input_invalid",
                field_name=field_name,
                message=f"{field_name} contains a nonfinite derived value",
            )
    offsets = schedule.affine_offsets
    if offsets is not None and not all(
        np.isfinite(offset).all() for offset in offsets
    ):
        _raise_classified_formulation_failure(
            reason=(
                "target_geometry_invalid"
                if curvature_enabled
                else "formulation_input_invalid"
            ),
            field_name="affine_offsets",
            message="affine_offsets contains a nonfinite derived value",
        )
    return schedule


class AutonomousDrivingRoadAwareDirectSteeringMPCPolicy(
    AutonomousDrivingDirectSteeringMPCPolicy
):
    """Three-state direct-steering MPC using agent-visible road preview."""

    _mpc_formulation_key = "road_aware_direct_steering"

    def __init__(
        self,
        config: AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    ) -> None:
        if type(config) is not AutonomousDrivingRoadAwareDirectSteeringMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingRoadAwareDirectSteeringMPCConfig"
            )
        self._initialize(config)

    @classmethod
    def from_env(
        cls,
        env,
        config: AutonomousDrivingRoadAwareDirectSteeringMPCConfig | None = None,
    ) -> "AutonomousDrivingRoadAwareDirectSteeringMPCPolicy":
        if config is None:
            config = AutonomousDrivingRoadAwareDirectSteeringMPCConfig()
        if type(config) is not AutonomousDrivingRoadAwareDirectSteeringMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingRoadAwareDirectSteeringMPCConfig or None"
            )
        return cls._from_env(env, config)

    @staticmethod
    def _required_observation_fields(
        config: AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    ) -> tuple[str, ...]:
        baseline = _AutonomousDrivingMPCPolicyBase._required_observation_fields(
            config
        )
        return baseline + required_road_preview_fields(config)

    @staticmethod
    def _require_fully_resolved_config(
        config: AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    ) -> None:
        _AutonomousDrivingMPCPolicyBase._require_fully_resolved_config(config)
        environment = config.environment
        assert environment is not None
        required = (
            AutonomousDrivingRoadAwareDirectSteeringMPCPolicy
            ._required_observation_fields(config)
        )
        missing = [
            name for name in required if name not in environment.observation_names
        ]
        if missing:
            raise ValueError(
                ", ".join(missing)
                + " must be agent-visible observation fields routed through obs"
            )
        _require_observation_layout(environment, required)
        if config.use_curvature_preview and (
            environment.target_lane_index is not None
            or environment.target_lane_units is not None
        ):
            raise ValueError(
                "curvature-aware MPC supports only the reference line or a "
                "fixed target_line_offset_metres; target_lane_index and "
                "target_lane_units are unsupported"
            )

    def _build_reference_schedule(
        self,
        *,
        decoded,
        progress_schedule: np.ndarray,
        observation,
    ) -> _MPCReferenceSchedule:
        baseline = super()._build_reference_schedule(
            decoded=decoded,
            progress_schedule=progress_schedule,
            observation=observation,
        )
        preview_fields = required_road_preview_fields(self.config)
        if not preview_fields:
            return baseline

        road_start = perf_counter()
        try:
            road_preview = self._adapter.decode_road_preview(
                observation,
                required_fields=preview_fields,
            )
            materialization = materialize_road_horizon(
                self.config,
                road_preview=road_preview,
                progress_schedule_metres=progress_schedule,
                baseline_reference_speeds_mps=(
                    baseline.reference_speeds_mps
                ),
                baseline_soft_speed_upper_bounds_mps=(
                    baseline.soft_speed_upper_bounds_mps
                ),
                baseline_reference_transition_index=(
                    baseline.reference_transition_index
                ),
            )
            if self.config.use_curvature_preview:
                curvature = (
                    materialization
                    .interpolated_target_line_curvatures_per_metre
                )
                assert curvature is not None
                constraints = self.config.constraints
                lower = constraints.steering_angle_control_lower_radians
                upper = constraints.steering_angle_control_upper_radians
                assert lower is not None and upper is not None
                with np.errstate(over="ignore", invalid="ignore"):
                    direct_feedforward, direct_exceeds = (
                        build_direct_steering_feedforward(
                            self.config.model,
                            curvature,
                            direct_steering_angle_lower_radians=lower,
                            direct_steering_angle_upper_radians=upper,
                        )
                    )
                _require_finite_target_geometry_schedule(
                    "direct_steering_angle_feedforward_radians",
                    direct_feedforward,
                )
            else:
                direct_feedforward = None
                direct_exceeds = None
            road_context = finalize_road_horizon_context(
                materialization,
                direct_steering_angle_feedforward_radians=(
                    direct_feedforward
                ),
                direct_steering_angle_feedforward_exceeds_bound=(
                    direct_exceeds
                ),
                steering_angle_state_feedforward_radians=None,
                steering_angle_state_feedforward_exceeds_bound=None,
                steering_rate_control_feedforward_radians_per_second=None,
                steering_rate_control_feedforward_exceeds_bound=None,
            )
        except _MPCPolicyInputError as error:
            raise _MPCPolicyInputError(
                error.failure,
                road_horizon_time_seconds=perf_counter() - road_start,
            ) from error

        return _MPCReferenceSchedule(
            reference_speeds_mps=(
                materialization.effective_speed_references_mps
            ),
            soft_speed_upper_bounds_mps=(
                materialization.installed_soft_speed_upper_bounds_mps
            ),
            reference_transition_index=(
                materialization.reference_transition_index
            ),
            road_horizon_context=road_context,
            road_horizon_time_seconds=perf_counter() - road_start,
        )

    def _build_model_schedule(
        self,
        *,
        linearization_speeds: np.ndarray,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> _MPCModelSchedule:
        if road_horizon_context is None:
            return super()._build_model_schedule(
                linearization_speeds=linearization_speeds,
                road_horizon_context=road_horizon_context,
            )
        _require_finite_model_schedule_input(linearization_speeds)
        if not self.config.use_curvature_preview:
            return _validated_road_aware_model_schedule(
                super()._build_model_schedule(
                    linearization_speeds=linearization_speeds,
                    road_horizon_context=road_horizon_context,
                ),
                curvature_enabled=False,
            )
        curvatures = (
            road_horizon_context
            .interpolated_target_line_curvatures_per_metre
        )
        assert curvatures is not None
        with np.errstate(over="ignore", invalid="ignore"):
            state_matrices, control_matrices, affine_offsets = (
                build_road_aware_direct_steering_model_schedule(
                    self.config.model,
                    linearization_speeds,
                    curvatures,
                )
            )
        return _validated_road_aware_model_schedule(
            _MPCModelSchedule(
                state_matrices=state_matrices,
                control_matrices=control_matrices,
                affine_offsets=affine_offsets,
            ),
            curvature_enabled=True,
        )

    def _build_problem(
        self,
        *,
        initial_state: np.ndarray,
        state_matrices: tuple[np.ndarray, ...],
        control_matrices: tuple[np.ndarray, ...],
        affine_offsets: tuple[np.ndarray, ...] | None,
        reference_speeds: np.ndarray,
        soft_speed_upper_bounds: np.ndarray | None,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> LinearQuadraticMPCProblem:
        baseline = super()._build_problem(
            initial_state=initial_state,
            state_matrices=state_matrices,
            control_matrices=control_matrices,
            affine_offsets=affine_offsets,
            reference_speeds=reference_speeds,
            soft_speed_upper_bounds=soft_speed_upper_bounds,
            road_horizon_context=road_horizon_context,
        )
        if road_horizon_context is None:
            return baseline

        replacements = {}
        direct_feedforward = (
            road_horizon_context
            .direct_steering_angle_feedforward_radians
        )
        if direct_feedforward is not None:
            replacements["control_references"] = tuple(
                np.array([0.0, steering_reference], dtype=np.float64)
                for steering_reference in direct_feedforward
            )

        lane_lower = (
            road_horizon_context
            .installed_soft_lateral_error_lower_bounds_metres
        )
        lane_upper = (
            road_horizon_context
            .installed_soft_lateral_error_upper_bounds_metres
        )
        if lane_lower is not None:
            assert lane_upper is not None
            constraints = self.config.constraints
            speed_lower = (
                -np.inf
                if constraints.soft_speed_state_lower_mps is None
                else constraints.soft_speed_state_lower_mps
            )
            heading_lower = (
                -np.inf
                if constraints.soft_heading_error_state_lower_radians is None
                else constraints.soft_heading_error_state_lower_radians
            )
            heading_upper = (
                np.inf
                if constraints.soft_heading_error_state_upper_radians is None
                else constraints.soft_heading_error_state_upper_radians
            )
            replacements["soft_state_lower_bounds"] = tuple(
                np.array(
                    [speed_lower, lane_lower[stage], heading_lower],
                    dtype=np.float64,
                )
                for stage in range(self.config.horizon_steps)
            )
            replacements["soft_state_upper_bounds"] = tuple(
                np.array(
                    [
                        np.inf
                        if soft_speed_upper_bounds is None
                        else soft_speed_upper_bounds[stage],
                        lane_upper[stage],
                        heading_upper,
                    ],
                    dtype=np.float64,
                )
                for stage in range(self.config.horizon_steps)
            )

        if not replacements:
            return baseline
        return replace(baseline, **replacements)


class AutonomousDrivingRoadAwareSteeringRateMPCPolicy(
    AutonomousDrivingSteeringRateMPCPolicy
):
    """Four-state steering-rate MPC using agent-visible road preview."""

    _mpc_formulation_key = "road_aware_steering_rate"

    def __init__(
        self,
        config: AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    ) -> None:
        if type(config) is not AutonomousDrivingRoadAwareSteeringRateMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingRoadAwareSteeringRateMPCConfig"
            )
        self._initialize(config)

    @classmethod
    def from_env(
        cls,
        env,
        config: AutonomousDrivingRoadAwareSteeringRateMPCConfig | None = None,
    ) -> "AutonomousDrivingRoadAwareSteeringRateMPCPolicy":
        if config is None:
            config = AutonomousDrivingRoadAwareSteeringRateMPCConfig()
        if type(config) is not AutonomousDrivingRoadAwareSteeringRateMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingRoadAwareSteeringRateMPCConfig or None"
            )
        return cls._from_env(env, config)

    @staticmethod
    def _required_observation_fields(
        config: AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    ) -> tuple[str, ...]:
        baseline = _AutonomousDrivingMPCPolicyBase._required_observation_fields(
            config
        )
        return baseline + required_road_preview_fields(config)

    @staticmethod
    def _require_fully_resolved_config(
        config: AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    ) -> None:
        _AutonomousDrivingMPCPolicyBase._require_fully_resolved_config(config)
        environment = config.environment
        assert environment is not None
        required = (
            AutonomousDrivingRoadAwareSteeringRateMPCPolicy
            ._required_observation_fields(config)
        )
        missing = [
            name for name in required if name not in environment.observation_names
        ]
        if missing:
            raise ValueError(
                ", ".join(missing)
                + " must be agent-visible observation fields routed through obs"
            )
        _require_observation_layout(environment, required)
        if config.use_curvature_preview and (
            environment.target_lane_index is not None
            or environment.target_lane_units is not None
        ):
            raise ValueError(
                "curvature-aware MPC supports only the reference line or a "
                "fixed target_line_offset_metres; target_lane_index and "
                "target_lane_units are unsupported"
            )

    def _build_reference_schedule(
        self,
        *,
        decoded,
        progress_schedule: np.ndarray,
        observation,
    ) -> _MPCReferenceSchedule:
        baseline = super()._build_reference_schedule(
            decoded=decoded,
            progress_schedule=progress_schedule,
            observation=observation,
        )
        preview_fields = required_road_preview_fields(self.config)
        if not preview_fields:
            return baseline

        road_start = perf_counter()
        try:
            road_preview = self._adapter.decode_road_preview(
                observation,
                required_fields=preview_fields,
            )
            materialization = materialize_road_horizon(
                self.config,
                road_preview=road_preview,
                progress_schedule_metres=progress_schedule,
                baseline_reference_speeds_mps=(
                    baseline.reference_speeds_mps
                ),
                baseline_soft_speed_upper_bounds_mps=(
                    baseline.soft_speed_upper_bounds_mps
                ),
                baseline_reference_transition_index=(
                    baseline.reference_transition_index
                ),
            )
            if self.config.use_curvature_preview:
                curvature = (
                    materialization
                    .interpolated_target_line_curvatures_per_metre
                )
                assert curvature is not None
                constraints = self.config.constraints
                angle_lower = constraints.steering_angle_state_lower_radians
                angle_upper = constraints.steering_angle_state_upper_radians
                rate_lower = (
                    constraints
                    .steering_rate_control_lower_radians_per_second
                )
                rate_upper = (
                    constraints
                    .steering_rate_control_upper_radians_per_second
                )
                assert angle_lower is not None and angle_upper is not None
                assert rate_lower is not None and rate_upper is not None
                with np.errstate(over="ignore", invalid="ignore"):
                    (
                        steering_angle_feedforward,
                        steering_angle_exceeds,
                        steering_rate_feedforward,
                        steering_rate_exceeds,
                    ) = build_steering_rate_feedforward(
                        self.config.model,
                        curvature,
                        steering_angle_state_lower_radians=angle_lower,
                        steering_angle_state_upper_radians=angle_upper,
                        steering_rate_control_lower_radians_per_second=rate_lower,
                        steering_rate_control_upper_radians_per_second=rate_upper,
                    )
                _require_finite_target_geometry_schedule(
                    "steering_angle_state_feedforward_radians",
                    steering_angle_feedforward,
                )
                _require_finite_target_geometry_schedule(
                    "steering_rate_control_feedforward_radians_per_second",
                    steering_rate_feedforward,
                )
            else:
                steering_angle_feedforward = None
                steering_angle_exceeds = None
                steering_rate_feedforward = None
                steering_rate_exceeds = None
            road_context = finalize_road_horizon_context(
                materialization,
                direct_steering_angle_feedforward_radians=None,
                direct_steering_angle_feedforward_exceeds_bound=None,
                steering_angle_state_feedforward_radians=(
                    steering_angle_feedforward
                ),
                steering_angle_state_feedforward_exceeds_bound=(
                    steering_angle_exceeds
                ),
                steering_rate_control_feedforward_radians_per_second=(
                    steering_rate_feedforward
                ),
                steering_rate_control_feedforward_exceeds_bound=(
                    steering_rate_exceeds
                ),
            )
        except _MPCPolicyInputError as error:
            raise _MPCPolicyInputError(
                error.failure,
                road_horizon_time_seconds=perf_counter() - road_start,
            ) from error

        return _MPCReferenceSchedule(
            reference_speeds_mps=(
                materialization.effective_speed_references_mps
            ),
            soft_speed_upper_bounds_mps=(
                materialization.installed_soft_speed_upper_bounds_mps
            ),
            reference_transition_index=(
                materialization.reference_transition_index
            ),
            road_horizon_context=road_context,
            road_horizon_time_seconds=perf_counter() - road_start,
        )

    def _build_model_schedule(
        self,
        *,
        linearization_speeds: np.ndarray,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> _MPCModelSchedule:
        if road_horizon_context is None:
            return super()._build_model_schedule(
                linearization_speeds=linearization_speeds,
                road_horizon_context=road_horizon_context,
            )
        _require_finite_model_schedule_input(linearization_speeds)
        if not self.config.use_curvature_preview:
            return _validated_road_aware_model_schedule(
                super()._build_model_schedule(
                    linearization_speeds=linearization_speeds,
                    road_horizon_context=road_horizon_context,
                ),
                curvature_enabled=False,
            )
        curvatures = (
            road_horizon_context
            .interpolated_target_line_curvatures_per_metre
        )
        assert curvatures is not None
        with np.errstate(over="ignore", invalid="ignore"):
            state_matrices, control_matrices, affine_offsets = (
                build_road_aware_steering_rate_model_schedule(
                    self.config.model,
                    linearization_speeds,
                    curvatures,
                )
            )
        return _validated_road_aware_model_schedule(
            _MPCModelSchedule(
                state_matrices=state_matrices,
                control_matrices=control_matrices,
                affine_offsets=affine_offsets,
            ),
            curvature_enabled=True,
        )

    def _build_problem(
        self,
        *,
        initial_state: np.ndarray,
        state_matrices: tuple[np.ndarray, ...],
        control_matrices: tuple[np.ndarray, ...],
        affine_offsets: tuple[np.ndarray, ...] | None,
        reference_speeds: np.ndarray,
        soft_speed_upper_bounds: np.ndarray | None,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> LinearQuadraticMPCProblem:
        baseline = super()._build_problem(
            initial_state=initial_state,
            state_matrices=state_matrices,
            control_matrices=control_matrices,
            affine_offsets=affine_offsets,
            reference_speeds=reference_speeds,
            soft_speed_upper_bounds=soft_speed_upper_bounds,
            road_horizon_context=road_horizon_context,
        )
        if road_horizon_context is None:
            return baseline

        replacements = {}
        steering_angle_feedforward = (
            road_horizon_context
            .steering_angle_state_feedforward_radians
        )
        if steering_angle_feedforward is not None:
            replacements["state_references"] = tuple(
                np.array(
                    [
                        reference_speeds[stage],
                        0.0,
                        0.0,
                        steering_angle_feedforward[stage],
                    ],
                    dtype=np.float64,
                )
                for stage in range(self.config.horizon_steps)
            )
            replacements["terminal_state_reference"] = np.array(
                [
                    reference_speeds[self.config.horizon_steps],
                    0.0,
                    0.0,
                    steering_angle_feedforward[self.config.horizon_steps],
                ],
                dtype=np.float64,
            )
        steering_rate_feedforward = (
            road_horizon_context
            .steering_rate_control_feedforward_radians_per_second
        )
        if steering_rate_feedforward is not None:
            replacements["control_references"] = tuple(
                np.array([0.0, rate_reference], dtype=np.float64)
                for rate_reference in steering_rate_feedforward
            )

        lane_lower = (
            road_horizon_context
            .installed_soft_lateral_error_lower_bounds_metres
        )
        lane_upper = (
            road_horizon_context
            .installed_soft_lateral_error_upper_bounds_metres
        )
        if lane_lower is not None:
            assert lane_upper is not None
            constraints = self.config.constraints
            speed_lower = (
                -np.inf
                if constraints.soft_speed_state_lower_mps is None
                else constraints.soft_speed_state_lower_mps
            )
            heading_lower = (
                -np.inf
                if constraints.soft_heading_error_state_lower_radians is None
                else constraints.soft_heading_error_state_lower_radians
            )
            heading_upper = (
                np.inf
                if constraints.soft_heading_error_state_upper_radians is None
                else constraints.soft_heading_error_state_upper_radians
            )
            replacements["soft_state_lower_bounds"] = tuple(
                np.array(
                    [
                        speed_lower,
                        lane_lower[stage],
                        heading_lower,
                        -np.inf,
                    ],
                    dtype=np.float64,
                )
                for stage in range(self.config.horizon_steps)
            )
            replacements["soft_state_upper_bounds"] = tuple(
                np.array(
                    [
                        np.inf
                        if soft_speed_upper_bounds is None
                        else soft_speed_upper_bounds[stage],
                        lane_upper[stage],
                        heading_upper,
                        np.inf,
                    ],
                    dtype=np.float64,
                )
                for stage in range(self.config.horizon_steps)
            )

        if not replacements:
            return baseline
        return replace(baseline, **replacements)


__all__ = [
    "AutonomousDrivingRoadAwareDirectSteeringMPCPolicy",
    "AutonomousDrivingRoadAwareSteeringRateMPCPolicy",
]
