"""Private control-role classification shared by autonomous-driving MPC."""

from enum import Enum

from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    AutonomousDrivingSteeringRateMPCConfig,
)


class _MPCControlKind(str, Enum):
    DIRECT_STEERING = "direct_steering"
    STEERING_RATE = "steering_rate"


def _control_kind_for_config(config: object) -> _MPCControlKind:
    config_type = type(config)
    if config_type in (
        AutonomousDrivingDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    ):
        return _MPCControlKind.DIRECT_STEERING
    if config_type in (
        AutonomousDrivingSteeringRateMPCConfig,
        AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    ):
        return _MPCControlKind.STEERING_RATE
    raise TypeError(
        "config must be exactly one of the four supported autonomous-driving "
        "MPC config types"
    )
