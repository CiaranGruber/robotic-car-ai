"""Configuration contracts for autonomous-driving MPC policies."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field, fields, replace
from enum import Enum
import math
from numbers import Integral, Real

from dreamgym.policies.mpc import MPCSolverConfig


def _finite_float(
    name: str,
    value: object,
    *,
    positive: bool = False,
    nonnegative: bool = False,
) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    if positive and converted <= 0.0:
        raise ValueError(f"{name} must be greater than zero")
    if nonnegative and converted < 0.0:
        raise ValueError(f"{name} must be nonnegative")
    return converted


def _positive_integer(name: str, value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    converted = int(value)
    if converted <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return converted


def _float_pair(name: str, value: object) -> tuple[float, float]:
    if not isinstance(value, (tuple, list)):
        raise TypeError(f"{name} must be a tuple/list")
    if len(value) != 2:
        raise ValueError(f"{name} must contain exactly two values")
    return (
        _finite_float(f"{name}[0]", value[0]),
        _finite_float(f"{name}[1]", value[1]),
    )


def _validate_ordered_pair(
    lower_name: str,
    lower: float | None,
    upper_name: str,
    upper: float | None,
) -> None:
    if lower is not None and upper is not None and lower > upper:
        raise ValueError(f"{lower_name} must not exceed {upper_name}")


class MPCSpeedLinearizationStrategy(str, Enum):
    MEASURED_SPEED = "measured_speed"
    RECOMMENDED_SPEED = "recommended_speed"
    SPEED_LIMIT = "speed_limit"
    PREVIEW_RECOMMENDED_SPEED = "preview_recommended_speed"
    SHIFTED_PREDICTED_SPEED = "shifted_predicted_speed"
    FIXED_SPEED = "fixed_speed"


class MPCRoadPreviewExtensionMode(str, Enum):
    ERROR = "error"
    HOLD_LAST = "hold_last"


class MPCFallbackMode(str, Enum):
    HOLD_PREVIOUS_ACTION = "hold_previous_action"
    ZERO_ACTION = "zero_action"
    ZERO_DRIVE_HOLD_STEERING = "zero_drive_hold_steering"
    CONSTANT_ACTION = "constant_action"
    RAISE = "raise"
    FALLBACK_POLICY = "fallback_policy"


_MPC_ROAD_PREVIEW_NUMERIC_FIELDS = {
    "road_preview_target_line_curvatures",
    "road_preview_recommended_speeds",
    "road_preview_speed_limits",
    "road_preview_right_lane_bound_offsets_from_target_line",
    "road_preview_left_lane_bound_offsets_from_target_line",
}
_MPC_ROAD_PREVIEW_VALIDITY_FIELD = "road_preview_validity"


@dataclass(frozen=True, slots=True)
class MPCEnvironmentConfig:
    control_timestep_seconds: float
    action_lower_bounds: tuple[float, float]
    action_upper_bounds: tuple[float, float]
    steering_request_limit_radians: float
    steering_offset_radians: float
    observation_format: str
    observation_names: tuple[str, ...]
    observation_shapes: tuple[tuple[str, tuple[int, ...]], ...]
    observation_scales: tuple[tuple[str, float], ...]
    flat_observation_size: int | None = None
    flat_observation_slices: tuple[tuple[str, int, int], ...] = ()
    road_preview_distances_metres: tuple[float, ...] | None = None
    target_line_offset_metres: float = 0.0
    target_lane_index: int | None = None
    target_lane_units: float | None = None
    target_lane_units_allow_outside: bool = False
    road_preview_lane_index: int | None = None
    road_preview_lane_selection_provenance: str | None = None
    road_preview_target_curvature_provenance: str | None = None
    vehicle_body_width_metres: float | None = None

    @classmethod
    def from_env(cls, env) -> "MPCEnvironmentConfig":
        """Snapshot the MPC-relevant interface exposed by ``env``.

        The implementation is imported lazily so this dependency-light
        configuration module does not need to import Gymnasium merely to define
        the public dataclasses.
        """

        from dreamgym.policies.autonomous_driving._mpc_adapter import (
            _snapshot_environment_config,
        )

        return _snapshot_environment_config(env)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "control_timestep_seconds",
            _finite_float(
                "control_timestep_seconds",
                self.control_timestep_seconds,
                positive=True,
            ),
        )
        lower_bounds = _float_pair("action_lower_bounds", self.action_lower_bounds)
        upper_bounds = _float_pair("action_upper_bounds", self.action_upper_bounds)
        for index, (lower, upper) in enumerate(zip(lower_bounds, upper_bounds)):
            if lower > upper:
                raise ValueError(
                    f"action_lower_bounds[{index}] must not exceed "
                    f"action_upper_bounds[{index}]"
                )
        object.__setattr__(self, "action_lower_bounds", lower_bounds)
        object.__setattr__(self, "action_upper_bounds", upper_bounds)
        object.__setattr__(
            self,
            "steering_request_limit_radians",
            _finite_float(
                "steering_request_limit_radians",
                self.steering_request_limit_radians,
                positive=True,
            ),
        )
        object.__setattr__(
            self,
            "steering_offset_radians",
            _finite_float("steering_offset_radians", self.steering_offset_radians),
        )

        if not isinstance(self.observation_format, str):
            raise TypeError("observation_format must be a string")
        if self.observation_format not in {"dict", "flat"}:
            raise ValueError("observation_format must be 'dict' or 'flat'")
        if not isinstance(self.observation_names, (tuple, list)):
            raise TypeError("observation_names must be a tuple/list")
        observation_names = tuple(self.observation_names)
        if not observation_names:
            raise ValueError("observation_names must not be empty")
        if not all(isinstance(name, str) and name for name in observation_names):
            raise TypeError("observation_names must contain nonempty strings")
        if len(set(observation_names)) != len(observation_names):
            raise ValueError("observation_names must be unique")
        object.__setattr__(self, "observation_names", observation_names)

        if not isinstance(self.observation_shapes, (tuple, list)):
            raise TypeError("observation_shapes must be a tuple/list")
        shapes: list[tuple[str, tuple[int, ...]]] = []
        shape_names: set[str] = set()
        for index, item in enumerate(self.observation_shapes):
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                raise ValueError(
                    f"observation_shapes[{index}] must be a (name, shape) pair"
                )
            name, raw_shape = item
            if not isinstance(name, str) or not name:
                raise TypeError(
                    f"observation_shapes[{index}] name must be a nonempty string"
                )
            if name in shape_names:
                raise ValueError("observation shape names must be unique")
            if name not in observation_names:
                raise ValueError(
                    f"observation shape {name!r} is not in observation_names"
                )
            if not isinstance(raw_shape, (tuple, list)):
                raise TypeError(
                    f"observation_shapes[{index}] shape must be a tuple/list"
                )
            shape: list[int] = []
            for dimension in raw_shape:
                if isinstance(dimension, bool) or not isinstance(
                    dimension, Integral
                ):
                    raise TypeError(
                        "observation shape dimensions must be integers"
                    )
                converted = int(dimension)
                if converted <= 0:
                    raise ValueError(
                        "observation shape dimensions must be greater than zero"
                    )
                shape.append(converted)
            shape_names.add(name)
            shapes.append((name, tuple(shape)))
        if shape_names != set(observation_names):
            raise ValueError(
                "observation_shapes must provide exactly one shape for every "
                "observation"
            )
        object.__setattr__(self, "observation_shapes", tuple(shapes))

        if not isinstance(self.observation_scales, (tuple, list)):
            raise TypeError("observation_scales must be a tuple/list")
        scales: list[tuple[str, float]] = []
        scale_names: set[str] = set()
        for index, item in enumerate(self.observation_scales):
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                raise ValueError(
                    f"observation_scales[{index}] must be a (name, scale) pair"
                )
            name, scale = item
            if not isinstance(name, str) or not name:
                raise TypeError(
                    f"observation_scales[{index}] name must be a nonempty string"
                )
            if name in scale_names:
                raise ValueError("observation scale names must be unique")
            if name not in observation_names:
                raise ValueError(
                    f"observation scale {name!r} is not in observation_names"
                )
            scale_names.add(name)
            scales.append(
                (
                    name,
                    _finite_float(
                        f"observation_scales[{index}][1]",
                        scale,
                        positive=True,
                    ),
                )
            )
        if scale_names != set(observation_names):
            raise ValueError(
                "observation_scales must provide exactly one scale for every observation"
            )
        object.__setattr__(self, "observation_scales", tuple(scales))

        flat_size = self.flat_observation_size
        if flat_size is not None:
            flat_size = _positive_integer("flat_observation_size", flat_size)
            object.__setattr__(self, "flat_observation_size", flat_size)
        if self.observation_format == "flat" and flat_size is None:
            raise ValueError("flat observations require flat_observation_size")

        if not isinstance(self.flat_observation_slices, (tuple, list)):
            raise TypeError("flat_observation_slices must be a tuple/list")
        slices: list[tuple[str, int, int]] = []
        slice_names: set[str] = set()
        for index, item in enumerate(self.flat_observation_slices):
            if not isinstance(item, (tuple, list)) or len(item) != 3:
                raise ValueError(
                    f"flat_observation_slices[{index}] must be a (name, start, stop) tuple"
                )
            name, start, stop = item
            if not isinstance(name, str) or not name:
                raise TypeError("flat observation slice names must be nonempty strings")
            if name in slice_names:
                raise ValueError("flat observation slice names must be unique")
            if name not in observation_names:
                raise ValueError(
                    f"flat observation slice {name!r} is not in observation_names"
                )
            if (
                isinstance(start, bool)
                or not isinstance(start, Integral)
                or isinstance(stop, bool)
                or not isinstance(stop, Integral)
            ):
                raise TypeError("flat observation slice bounds must be integers")
            start = int(start)
            stop = int(stop)
            if start < 0 or stop <= start:
                raise ValueError("flat observation slices require 0 <= start < stop")
            if flat_size is not None and stop > flat_size:
                raise ValueError("flat observation slice exceeds flat_observation_size")
            slice_names.add(name)
            slices.append((name, start, stop))
        if slices and flat_size is None:
            raise ValueError(
                "flat_observation_slices require flat_observation_size"
            )
        if self.observation_format == "flat":
            if slice_names != set(observation_names):
                raise ValueError(
                    "flat_observation_slices must provide exactly one slice "
                    "for every observation"
                )
            shapes_by_name = dict(shapes)
            for name, start, stop in slices:
                if math.prod(shapes_by_name[name]) != stop - start:
                    raise ValueError(
                        f"flat observation shape for {name!r} must match its "
                        "slice width"
                    )
            expected_start = 0
            for _, start, stop in sorted(slices, key=lambda item: item[1]):
                if start < expected_start:
                    raise ValueError("flat observation slices must not overlap")
                if start > expected_start:
                    raise ValueError(
                        "flat observation slices must completely cover "
                        "flat_observation_size"
                    )
                expected_start = stop
            if expected_start != flat_size:
                raise ValueError(
                    "flat observation slices must completely cover "
                    "flat_observation_size"
                )
        object.__setattr__(self, "flat_observation_slices", tuple(slices))

        distances = self.road_preview_distances_metres
        if distances is not None:
            from dreamgym.envs.road_preview import validate_road_preview_distances

            distances = validate_road_preview_distances(distances)
            object.__setattr__(self, "road_preview_distances_metres", distances)

        object.__setattr__(
            self,
            "target_line_offset_metres",
            _finite_float(
                "target_line_offset_metres",
                self.target_line_offset_metres,
            ),
        )
        target_lane_index = self.target_lane_index
        if target_lane_index is not None:
            if isinstance(target_lane_index, bool) or not isinstance(
                target_lane_index,
                Integral,
            ):
                raise TypeError("target_lane_index must be an integer or None")
            target_lane_index = int(target_lane_index)
            object.__setattr__(self, "target_lane_index", target_lane_index)
        target_lane_units = self.target_lane_units
        if target_lane_units is not None:
            target_lane_units = _finite_float(
                "target_lane_units",
                target_lane_units,
            )
            object.__setattr__(self, "target_lane_units", target_lane_units)
        if target_lane_index is not None and target_lane_units is not None:
            raise ValueError(
                "target_lane_index and target_lane_units are mutually exclusive"
            )
        if not isinstance(self.target_lane_units_allow_outside, bool):
            raise TypeError("target_lane_units_allow_outside must be a bool")

        preview_lane_index = self.road_preview_lane_index
        if preview_lane_index is not None:
            if isinstance(preview_lane_index, bool) or not isinstance(
                preview_lane_index,
                Integral,
            ):
                raise TypeError(
                    "road_preview_lane_index must be a nonzero integer or None"
                )
            preview_lane_index = int(preview_lane_index)
            if preview_lane_index == 0:
                raise ValueError("road_preview_lane_index must be nonzero")
            object.__setattr__(
                self,
                "road_preview_lane_index",
                preview_lane_index,
            )

        lane_provenance = self.road_preview_lane_selection_provenance
        curvature_provenance = self.road_preview_target_curvature_provenance
        allowed_curvature = {
            None,
            "exact_reference_line",
            "exact_parallel_curve",
            "tapered_target_approximation",
        }
        if curvature_provenance not in allowed_curvature:
            raise ValueError(
                "road_preview_target_curvature_provenance has an invalid token"
            )
        if target_lane_index is not None or target_lane_units is not None:
            expected_curvatures = {"tapered_target_approximation"}
        elif self.target_line_offset_metres != 0.0:
            expected_curvatures = {"exact_parallel_curve"}
        else:
            # Exact zero is ambiguous in the legacy MPC-native selector fields;
            # translated curvature provenance retains the final requested mode.
            expected_curvatures = {
                "exact_reference_line",
                "exact_parallel_curve",
            }
        if (
            curvature_provenance is not None
            and curvature_provenance not in expected_curvatures
        ):
            raise ValueError(
                "road_preview_target_curvature_provenance does not match "
                "the translated target selector"
            )
        if distances is not None and curvature_provenance is None:
            raise ValueError(
                "road_preview_target_curvature_provenance is required for "
                "road_preview_distances_metres"
            )

        allowed_lane_provenance = {
            None,
            "reference_line_lane_center",
            "target_lane_index",
            "explicit_lane_index",
        }
        if lane_provenance not in allowed_lane_provenance:
            raise ValueError(
                "road_preview_lane_selection_provenance has an invalid token"
            )
        if lane_provenance is None:
            if preview_lane_index is not None:
                raise ValueError(
                    "road_preview_lane_index requires lane-selection provenance"
                )
        elif lane_provenance == "reference_line_lane_center":
            if preview_lane_index is not None:
                raise ValueError(
                    "reference_line_lane_center requires road_preview_lane_index=None"
                )
        elif preview_lane_index is None:
            raise ValueError(
                f"{lane_provenance} requires road_preview_lane_index"
            )
        elif (
            lane_provenance == "target_lane_index"
            and preview_lane_index != target_lane_index
        ):
            raise ValueError(
                "target_lane_index preview bounds require the translated target lane"
            )

        body_width = self.vehicle_body_width_metres
        if body_width is not None:
            object.__setattr__(
                self,
                "vehicle_body_width_metres",
                _finite_float(
                    "vehicle_body_width_metres",
                    body_width,
                    positive=True,
                ),
            )

        configured_preview_fields: set[str] = set()
        if distances is not None or any(
            name.startswith("road_preview_") for name in observation_names
        ):
            preview_field_names = set(_MPC_ROAD_PREVIEW_NUMERIC_FIELDS) | {
                _MPC_ROAD_PREVIEW_VALIDITY_FIELD
            }
            configured_preview_fields = set(observation_names) & preview_field_names
        if configured_preview_fields and distances is None:
            raise ValueError(
                "road-preview observation fields require "
                "road_preview_distances_metres"
            )
        if configured_preview_fields:
            assert distances is not None
            expected_shape = (len(distances),)
            shapes_by_name = dict(shapes)
            for field_name in configured_preview_fields:
                if shapes_by_name[field_name] != expected_shape:
                    raise ValueError(
                        f"observation shape for {field_name!r} must be "
                        f"{expected_shape}"
                    )
            if (
                configured_preview_fields != {_MPC_ROAD_PREVIEW_VALIDITY_FIELD}
                and _MPC_ROAD_PREVIEW_VALIDITY_FIELD not in configured_preview_fields
            ):
                raise ValueError(
                    "numeric road-preview observation fields require "
                    "road_preview_validity"
                )
            if (
                _MPC_ROAD_PREVIEW_VALIDITY_FIELD in configured_preview_fields
                and dict(scales)[_MPC_ROAD_PREVIEW_VALIDITY_FIELD] != 1.0
            ):
                raise ValueError("road_preview_validity must be unscaled")
            lane_fields = {
                "road_preview_right_lane_bound_offsets_from_target_line",
                "road_preview_left_lane_bound_offsets_from_target_line",
            }
            if configured_preview_fields & lane_fields and lane_provenance is None:
                raise ValueError(
                    "lane-bound road-preview observations require lane provenance"
                )


def _validate_objective_weights(
    config: object,
    *,
    quadratic_fields: tuple[str, ...],
    linear_fields: tuple[str, ...],
) -> None:
    for field_name in quadratic_fields:
        object.__setattr__(
            config,
            field_name,
            _finite_float(
                field_name,
                getattr(config, field_name),
                nonnegative=True,
            ),
        )
    for field_name in linear_fields:
        object.__setattr__(
            config,
            field_name,
            _finite_float(field_name, getattr(config, field_name)),
        )


def _validate_optional_finite_fields(
    config: object,
    field_names: tuple[str, ...],
) -> None:
    for field_name in field_names:
        value = getattr(config, field_name)
        if value is not None:
            object.__setattr__(
                config,
                field_name,
                _finite_float(field_name, value),
            )


def _validate_all_or_none_pair(
    config: object,
    lower_name: str,
    upper_name: str,
) -> None:
    lower = getattr(config, lower_name)
    upper = getattr(config, upper_name)
    if (lower is None) != (upper is None):
        raise ValueError(f"{lower_name} and {upper_name} must be provided together")
    _validate_ordered_pair(lower_name, lower, upper_name, upper)


def _validate_shared_constraint_values(config: object) -> None:
    for field_name in (
        "normalized_drive_command_control_lower",
        "normalized_drive_command_control_upper",
    ):
        value = _finite_float(field_name, getattr(config, field_name))
        if value < -1.0 or value > 1.0:
            raise ValueError(f"{field_name} must be inside normalized [-1, 1] bounds")
        object.__setattr__(config, field_name, value)

    _validate_optional_finite_fields(
        config,
        (
            "soft_speed_state_lower_mps",
            "soft_lateral_error_state_lower_metres",
            "soft_lateral_error_state_upper_metres",
            "soft_heading_error_state_lower_radians",
            "soft_heading_error_state_upper_radians",
        ),
    )
    recommended_speed_margin = getattr(
        config,
        "recommended_speed_soft_upper_margin_mps",
    )
    if recommended_speed_margin is not None:
        object.__setattr__(
            config,
            "recommended_speed_soft_upper_margin_mps",
            _finite_float(
                "recommended_speed_soft_upper_margin_mps",
                recommended_speed_margin,
                nonnegative=True,
            ),
        )
    for field_name in (
        "soft_state_linear_penalty",
        "soft_state_quadratic_penalty",
    ):
        object.__setattr__(
            config,
            field_name,
            _finite_float(
                field_name,
                getattr(config, field_name),
                nonnegative=True,
            ),
        )

    any_soft_bound_active = any(
        getattr(config, field_name) is not None
        for field_name in (
            "recommended_speed_soft_upper_margin_mps",
            "soft_speed_state_lower_mps",
            "soft_lateral_error_state_lower_metres",
            "soft_lateral_error_state_upper_metres",
            "soft_heading_error_state_lower_radians",
            "soft_heading_error_state_upper_radians",
        )
    )
    if any_soft_bound_active and not (
        getattr(config, "soft_state_linear_penalty") > 0.0
        or getattr(config, "soft_state_quadratic_penalty") > 0.0
    ):
        raise ValueError(
            "at least one soft-state penalty must be positive when a soft bound "
            "is active"
        )

    _validate_ordered_pair(
        "normalized_drive_command_control_lower",
        getattr(config, "normalized_drive_command_control_lower"),
        "normalized_drive_command_control_upper",
        getattr(config, "normalized_drive_command_control_upper"),
    )
    for lower_name, upper_name in (
        (
            "soft_lateral_error_state_lower_metres",
            "soft_lateral_error_state_upper_metres",
        ),
        (
            "soft_heading_error_state_lower_radians",
            "soft_heading_error_state_upper_radians",
        ),
    ):
        _validate_ordered_pair(
            lower_name,
            getattr(config, lower_name),
            upper_name,
            getattr(config, upper_name),
        )


@dataclass(frozen=True, slots=True)
class KinematicBicycleMPCModelConfig:
    control_timestep_seconds: float
    mass_kg: float
    motor_force_gain_newtons: float
    front_axle_distance_metres: float
    rear_axle_distance_metres: float

    @classmethod
    def from_env(cls, env) -> "KinematicBicycleMPCModelConfig":
        from ._mpc_adapter import _snapshot_kinematic_bicycle_mpc_model

        return _snapshot_kinematic_bicycle_mpc_model(env)

    def __post_init__(self) -> None:
        for field_name in (
            "control_timestep_seconds",
            "mass_kg",
            "motor_force_gain_newtons",
            "front_axle_distance_metres",
            "rear_axle_distance_metres",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_float(field_name, getattr(self, field_name), positive=True),
            )


@dataclass(frozen=True, slots=True)
class MPCFallbackConfig:
    mode: MPCFallbackMode = MPCFallbackMode.HOLD_PREVIOUS_ACTION
    constant_environment_action: tuple[float, float] | None = None
    policy_factory: Callable[[], object] | None = None

    def __post_init__(self) -> None:
        mode = self.mode
        if isinstance(mode, str) and not isinstance(mode, MPCFallbackMode):
            try:
                mode = MPCFallbackMode(mode)
            except ValueError as error:
                raise ValueError("invalid fallback mode") from error
            object.__setattr__(self, "mode", mode)
        elif not isinstance(mode, MPCFallbackMode):
            raise TypeError("mode must be an MPCFallbackMode")

        action = self.constant_environment_action
        if action is not None:
            action = _float_pair("constant_environment_action", action)
            if any(value < -1.0 or value > 1.0 for value in action):
                raise ValueError(
                    "constant_environment_action must be inside normalized "
                    "[-1, 1] bounds"
                )
            object.__setattr__(self, "constant_environment_action", action)

        if mode is MPCFallbackMode.CONSTANT_ACTION:
            if action is None:
                raise ValueError(
                    "constant_environment_action is required for constant-action "
                    "fallback"
                )
            if self.policy_factory is not None:
                raise ValueError(
                    "policy_factory is forbidden for constant-action fallback"
                )
            return

        if mode is MPCFallbackMode.FALLBACK_POLICY:
            if action is not None:
                raise ValueError(
                    "constant_environment_action is forbidden for fallback-policy "
                    "mode"
                )
            if not callable(self.policy_factory):
                raise TypeError(
                    "policy_factory must be callable for fallback-policy mode"
                )
            return

        if action is not None or self.policy_factory is not None:
            raise ValueError(
                "constant_environment_action and policy_factory are forbidden for "
                f"{mode.value} fallback"
            )


@dataclass(frozen=True, slots=True)
class DirectSteeringMPCObjectiveConfig:
    speed_state_quadratic_weight: float = 1.0
    lateral_error_state_quadratic_weight: float = 1.0
    heading_error_state_quadratic_weight: float = 1.0
    normalized_drive_command_control_quadratic_weight: float = 1.0
    steering_angle_control_quadratic_weight: float = 1.0
    speed_state_linear_weight: float = 0.0
    lateral_error_state_linear_weight: float = 0.0
    heading_error_state_linear_weight: float = 0.0
    normalized_drive_command_control_linear_weight: float = 0.0
    steering_angle_control_linear_weight: float = 0.0

    def __post_init__(self) -> None:
        _validate_objective_weights(
            self,
            quadratic_fields=(
                "speed_state_quadratic_weight",
                "lateral_error_state_quadratic_weight",
                "heading_error_state_quadratic_weight",
                "normalized_drive_command_control_quadratic_weight",
                "steering_angle_control_quadratic_weight",
            ),
            linear_fields=(
                "speed_state_linear_weight",
                "lateral_error_state_linear_weight",
                "heading_error_state_linear_weight",
                "normalized_drive_command_control_linear_weight",
                "steering_angle_control_linear_weight",
            ),
        )


@dataclass(frozen=True, slots=True)
class SteeringRateMPCObjectiveConfig:
    speed_state_quadratic_weight: float = 1.0
    lateral_error_state_quadratic_weight: float = 1.0
    heading_error_state_quadratic_weight: float = 1.0
    steering_angle_state_quadratic_weight: float = 1.0
    normalized_drive_command_control_quadratic_weight: float = 1.0
    steering_rate_control_quadratic_weight: float = 1.0
    speed_state_linear_weight: float = 0.0
    lateral_error_state_linear_weight: float = 0.0
    heading_error_state_linear_weight: float = 0.0
    steering_angle_state_linear_weight: float = 0.0
    normalized_drive_command_control_linear_weight: float = 0.0
    steering_rate_control_linear_weight: float = 0.0

    def __post_init__(self) -> None:
        _validate_objective_weights(
            self,
            quadratic_fields=(
                "speed_state_quadratic_weight",
                "lateral_error_state_quadratic_weight",
                "heading_error_state_quadratic_weight",
                "steering_angle_state_quadratic_weight",
                "normalized_drive_command_control_quadratic_weight",
                "steering_rate_control_quadratic_weight",
            ),
            linear_fields=(
                "speed_state_linear_weight",
                "lateral_error_state_linear_weight",
                "heading_error_state_linear_weight",
                "steering_angle_state_linear_weight",
                "normalized_drive_command_control_linear_weight",
                "steering_rate_control_linear_weight",
            ),
        )


@dataclass(frozen=True, slots=True)
class DirectSteeringMPCConstraintConfig:
    normalized_drive_command_control_lower: float = -0.75
    normalized_drive_command_control_upper: float = 0.75
    steering_angle_control_lower_radians: float | None = None
    steering_angle_control_upper_radians: float | None = None
    soft_speed_state_lower_mps: float | None = None
    recommended_speed_soft_upper_margin_mps: float | None = 0.0
    soft_lateral_error_state_lower_metres: float | None = None
    soft_lateral_error_state_upper_metres: float | None = None
    soft_heading_error_state_lower_radians: float | None = None
    soft_heading_error_state_upper_radians: float | None = None
    soft_state_linear_penalty: float = 5.0
    soft_state_quadratic_penalty: float = 5.0

    def __post_init__(self) -> None:
        _validate_direct_steering_constraint_values(self)


@dataclass(frozen=True, slots=True)
class SteeringRateMPCConstraintConfig:
    normalized_drive_command_control_lower: float = -0.75
    normalized_drive_command_control_upper: float = 0.75
    normalized_drive_command_control_change_lower_per_step: float = -0.10
    normalized_drive_command_control_change_upper_per_step: float = 0.10
    steering_rate_control_lower_radians_per_second: float | None = None
    steering_rate_control_upper_radians_per_second: float | None = None
    steering_angle_state_lower_radians: float | None = None
    steering_angle_state_upper_radians: float | None = None
    soft_speed_state_lower_mps: float | None = None
    recommended_speed_soft_upper_margin_mps: float | None = 0.0
    soft_lateral_error_state_lower_metres: float | None = None
    soft_lateral_error_state_upper_metres: float | None = None
    soft_heading_error_state_lower_radians: float | None = None
    soft_heading_error_state_upper_radians: float | None = None
    soft_state_linear_penalty: float = 5.0
    soft_state_quadratic_penalty: float = 5.0

    def __post_init__(self) -> None:
        _validate_steering_rate_constraint_values(self)


def _validate_direct_steering_constraint_values(config: object) -> None:
    _validate_shared_constraint_values(config)
    _validate_optional_finite_fields(
        config,
        (
            "steering_angle_control_lower_radians",
            "steering_angle_control_upper_radians",
        ),
    )
    _validate_all_or_none_pair(
        config,
        "steering_angle_control_lower_radians",
        "steering_angle_control_upper_radians",
    )


def _validate_steering_rate_constraint_values(config: object) -> None:
    _validate_shared_constraint_values(config)
    for field_name in (
        "normalized_drive_command_control_change_lower_per_step",
        "normalized_drive_command_control_change_upper_per_step",
    ):
        object.__setattr__(
            config,
            field_name,
            _finite_float(field_name, getattr(config, field_name)),
        )
    _validate_optional_finite_fields(
        config,
        (
            "steering_rate_control_lower_radians_per_second",
            "steering_rate_control_upper_radians_per_second",
            "steering_angle_state_lower_radians",
            "steering_angle_state_upper_radians",
        ),
    )
    _validate_ordered_pair(
        "normalized_drive_command_control_change_lower_per_step",
        getattr(config, "normalized_drive_command_control_change_lower_per_step"),
        "normalized_drive_command_control_change_upper_per_step",
        getattr(config, "normalized_drive_command_control_change_upper_per_step"),
    )
    for lower_name, upper_name in (
        (
            "steering_rate_control_lower_radians_per_second",
            "steering_rate_control_upper_radians_per_second",
        ),
        (
            "steering_angle_state_lower_radians",
            "steering_angle_state_upper_radians",
        ),
    ):
        _validate_all_or_none_pair(config, lower_name, upper_name)


def _validate_road_aware_constraint_values(config: object) -> None:
    width = getattr(config, "vehicle_body_width_metres")
    if width is not None:
        object.__setattr__(
            config,
            "vehicle_body_width_metres",
            _finite_float(
                "vehicle_body_width_metres",
                width,
                positive=True,
            ),
        )
    object.__setattr__(
        config,
        "lane_safety_margin_metres",
        _finite_float(
            "lane_safety_margin_metres",
            getattr(config, "lane_safety_margin_metres"),
            nonnegative=True,
        ),
    )
    for field_name in (
        "maximum_lateral_acceleration_mps2",
        "speed_limit_soft_upper_margin_mps",
    ):
        value = getattr(config, field_name)
        if value is None:
            continue
        object.__setattr__(
            config,
            field_name,
            _finite_float(
                field_name,
                value,
                positive=field_name == "maximum_lateral_acceleration_mps2",
                nonnegative=field_name == "speed_limit_soft_upper_margin_mps",
            ),
        )


@dataclass(frozen=True, slots=True)
class RoadAwareDirectSteeringMPCConstraintConfig:
    normalized_drive_command_control_lower: float = -0.75
    normalized_drive_command_control_upper: float = 0.75
    steering_angle_control_lower_radians: float | None = None
    steering_angle_control_upper_radians: float | None = None
    soft_speed_state_lower_mps: float | None = None
    recommended_speed_soft_upper_margin_mps: float | None = 0.0
    soft_lateral_error_state_lower_metres: float | None = None
    soft_lateral_error_state_upper_metres: float | None = None
    soft_heading_error_state_lower_radians: float | None = None
    soft_heading_error_state_upper_radians: float | None = None
    soft_state_linear_penalty: float = 5.0
    soft_state_quadratic_penalty: float = 5.0
    vehicle_body_width_metres: float | None = None
    lane_safety_margin_metres: float = 0.0
    maximum_lateral_acceleration_mps2: float | None = 3.0
    speed_limit_soft_upper_margin_mps: float | None = 0.0

    def __post_init__(self) -> None:
        _validate_direct_steering_constraint_values(self)
        _validate_road_aware_constraint_values(self)


@dataclass(frozen=True, slots=True)
class RoadAwareSteeringRateMPCConstraintConfig:
    normalized_drive_command_control_lower: float = -0.75
    normalized_drive_command_control_upper: float = 0.75
    normalized_drive_command_control_change_lower_per_step: float = -0.10
    normalized_drive_command_control_change_upper_per_step: float = 0.10
    steering_rate_control_lower_radians_per_second: float | None = None
    steering_rate_control_upper_radians_per_second: float | None = None
    steering_angle_state_lower_radians: float | None = None
    steering_angle_state_upper_radians: float | None = None
    soft_speed_state_lower_mps: float | None = None
    recommended_speed_soft_upper_margin_mps: float | None = 0.0
    soft_lateral_error_state_lower_metres: float | None = None
    soft_lateral_error_state_upper_metres: float | None = None
    soft_heading_error_state_lower_radians: float | None = None
    soft_heading_error_state_upper_radians: float | None = None
    soft_state_linear_penalty: float = 5.0
    soft_state_quadratic_penalty: float = 5.0
    vehicle_body_width_metres: float | None = None
    lane_safety_margin_metres: float = 0.0
    maximum_lateral_acceleration_mps2: float | None = 3.0
    speed_limit_soft_upper_margin_mps: float | None = 0.0

    def __post_init__(self) -> None:
        _validate_steering_rate_constraint_values(self)
        _validate_road_aware_constraint_values(self)


def _road_aware_direct_teaching_constraints(
    baseline: DirectSteeringMPCConstraintConfig,
) -> RoadAwareDirectSteeringMPCConstraintConfig:
    baseline_values = {
        item.name: getattr(baseline, item.name) for item in fields(baseline)
    }
    return RoadAwareDirectSteeringMPCConstraintConfig(
        **baseline_values,
        vehicle_body_width_metres=None,
        lane_safety_margin_metres=0.0,
        maximum_lateral_acceleration_mps2=3.0,
        speed_limit_soft_upper_margin_mps=0.0,
    )


def _road_aware_rate_teaching_constraints(
    baseline: SteeringRateMPCConstraintConfig,
) -> RoadAwareSteeringRateMPCConstraintConfig:
    baseline_values = {
        item.name: getattr(baseline, item.name) for item in fields(baseline)
    }
    return RoadAwareSteeringRateMPCConstraintConfig(
        **baseline_values,
        vehicle_body_width_metres=None,
        lane_safety_margin_metres=0.0,
        maximum_lateral_acceleration_mps2=3.0,
        speed_limit_soft_upper_margin_mps=0.0,
    )


def _validate_policy_specific_config(
    config: object,
    *,
    objective_type: type,
    constraint_type: type,
) -> None:
    object.__setattr__(
        config,
        "horizon_steps",
        _positive_integer("horizon_steps", getattr(config, "horizon_steps")),
    )
    environment = getattr(config, "environment")
    if environment is not None and not isinstance(environment, MPCEnvironmentConfig):
        raise TypeError("environment must be an MPCEnvironmentConfig or None")
    model = getattr(config, "model")
    if model is not None and not isinstance(model, KinematicBicycleMPCModelConfig):
        raise TypeError("model must be a KinematicBicycleMPCModelConfig or None")
    if not isinstance(getattr(config, "objective"), objective_type):
        raise TypeError(f"objective must be a {objective_type.__name__}")
    if not isinstance(getattr(config, "constraints"), constraint_type):
        raise TypeError(f"constraints must be a {constraint_type.__name__}")
    if not isinstance(getattr(config, "solver"), MPCSolverConfig):
        raise TypeError("solver must be an MPCSolverConfig")
    if not isinstance(getattr(config, "fallback"), MPCFallbackConfig):
        raise TypeError("fallback must be an MPCFallbackConfig")

    strategy = getattr(config, "linearization_strategy")
    if isinstance(strategy, str) and not isinstance(
        strategy, MPCSpeedLinearizationStrategy
    ):
        try:
            strategy = MPCSpeedLinearizationStrategy(strategy)
        except ValueError as error:
            raise ValueError("invalid linearization_strategy") from error
        object.__setattr__(config, "linearization_strategy", strategy)
    elif not isinstance(strategy, MPCSpeedLinearizationStrategy):
        raise TypeError(
            "linearization_strategy must be an MPCSpeedLinearizationStrategy"
        )

    fixed_speed = getattr(config, "fixed_linearization_speed_mps")
    if fixed_speed is not None:
        fixed_speed = _finite_float(
            "fixed_linearization_speed_mps",
            fixed_speed,
            positive=True,
        )
        object.__setattr__(config, "fixed_linearization_speed_mps", fixed_speed)
    if strategy is MPCSpeedLinearizationStrategy.FIXED_SPEED:
        if fixed_speed is None:
            raise ValueError(
                "fixed_linearization_speed_mps is required for fixed-speed "
                "linearization"
            )
    elif fixed_speed is not None:
        raise ValueError(
            "fixed_linearization_speed_mps is forbidden unless "
            "linearization_strategy is FIXED_SPEED"
        )

    if environment is not None and model is not None:
        if not math.isclose(
            environment.control_timestep_seconds,
            model.control_timestep_seconds,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise ValueError("environment and model control timesteps must match")


def _validate_road_aware_policy_config(
    config: object,
    *,
    objective_type: type,
    constraint_type: type,
) -> None:
    _validate_policy_specific_config(
        config,
        objective_type=objective_type,
        constraint_type=constraint_type,
    )
    for field_name in (
        "use_speed_preview",
        "use_curvature_preview",
        "use_lane_bound_constraints",
    ):
        if not isinstance(getattr(config, field_name), bool):
            raise TypeError(f"{field_name} must be a bool")

    extension_mode = getattr(config, "road_preview_extension_mode")
    if isinstance(extension_mode, str) and not isinstance(
        extension_mode,
        MPCRoadPreviewExtensionMode,
    ):
        try:
            extension_mode = MPCRoadPreviewExtensionMode(extension_mode)
        except ValueError as error:
            raise ValueError("invalid road_preview_extension_mode") from error
        object.__setattr__(config, "road_preview_extension_mode", extension_mode)
    elif not isinstance(extension_mode, MPCRoadPreviewExtensionMode):
        raise TypeError(
            "road_preview_extension_mode must be an "
            "MPCRoadPreviewExtensionMode"
        )

    constraints = getattr(config, "constraints")
    road_soft_bound_is_active = (
        (
            getattr(config, "use_speed_preview")
            and constraints.speed_limit_soft_upper_margin_mps is not None
        )
        or (
            getattr(config, "use_curvature_preview")
            and constraints.maximum_lateral_acceleration_mps2 is not None
        )
        or getattr(config, "use_lane_bound_constraints")
    )
    if road_soft_bound_is_active and not (
        constraints.soft_state_linear_penalty > 0.0
        or constraints.soft_state_quadratic_penalty > 0.0
    ):
        raise ValueError(
            "at least one soft-state penalty must be positive when an enabled "
            "road feature installs a soft bound"
        )


@dataclass(frozen=True, slots=True)
class AutonomousDrivingDirectSteeringMPCConfig:
    horizon_steps: int = 20
    environment: MPCEnvironmentConfig | None = None
    model: KinematicBicycleMPCModelConfig | None = None
    objective: DirectSteeringMPCObjectiveConfig = field(
        default_factory=DirectSteeringMPCObjectiveConfig
    )
    constraints: DirectSteeringMPCConstraintConfig = field(
        default_factory=DirectSteeringMPCConstraintConfig
    )
    solver: MPCSolverConfig = field(default_factory=MPCSolverConfig)
    linearization_strategy: MPCSpeedLinearizationStrategy = (
        MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
    )
    fixed_linearization_speed_mps: float | None = None
    fallback: MPCFallbackConfig = field(default_factory=MPCFallbackConfig)

    def __post_init__(self) -> None:
        _validate_policy_specific_config(
            self,
            objective_type=DirectSteeringMPCObjectiveConfig,
            constraint_type=DirectSteeringMPCConstraintConfig,
        )

    @classmethod
    def teaching_baseline(
        cls,
        **overrides,
    ) -> "AutonomousDrivingDirectSteeringMPCConfig":
        baseline = cls(
            horizon_steps=20,
            environment=None,
            model=None,
            objective=DirectSteeringMPCObjectiveConfig(
                speed_state_quadratic_weight=1.0,
                lateral_error_state_quadratic_weight=1.0,
                heading_error_state_quadratic_weight=1.0,
                normalized_drive_command_control_quadratic_weight=1.0,
                steering_angle_control_quadratic_weight=1.0,
                speed_state_linear_weight=0.0,
                lateral_error_state_linear_weight=0.0,
                heading_error_state_linear_weight=0.0,
                normalized_drive_command_control_linear_weight=0.0,
                steering_angle_control_linear_weight=0.0,
            ),
            constraints=DirectSteeringMPCConstraintConfig(
                normalized_drive_command_control_lower=-0.75,
                normalized_drive_command_control_upper=0.75,
                steering_angle_control_lower_radians=None,
                steering_angle_control_upper_radians=None,
                soft_speed_state_lower_mps=None,
                recommended_speed_soft_upper_margin_mps=0.0,
                soft_lateral_error_state_lower_metres=None,
                soft_lateral_error_state_upper_metres=None,
                soft_heading_error_state_lower_radians=None,
                soft_heading_error_state_upper_radians=None,
                soft_state_linear_penalty=5.0,
                soft_state_quadratic_penalty=5.0,
            ),
            solver=MPCSolverConfig(
                dtype="float64",
                verbose=False,
                absolute_tolerance=1.0e-3,
                relative_tolerance=1.0e-3,
                max_iterations=4000,
                polishing=False,
                adaptive_rho=True,
                check_termination_interval=25,
                time_limit_seconds=None,
                accept_solved_inaccurate=True,
                additional_osqp_settings={},
            ),
            linearization_strategy=(
                MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
            ),
            fixed_linearization_speed_mps=None,
            fallback=MPCFallbackConfig(
                mode=MPCFallbackMode.HOLD_PREVIOUS_ACTION,
                constant_environment_action=None,
                policy_factory=None,
            ),
        )
        return replace(baseline, **overrides)


@dataclass(frozen=True, slots=True)
class AutonomousDrivingSteeringRateMPCConfig:
    horizon_steps: int = 20
    environment: MPCEnvironmentConfig | None = None
    model: KinematicBicycleMPCModelConfig | None = None
    objective: SteeringRateMPCObjectiveConfig = field(
        default_factory=SteeringRateMPCObjectiveConfig
    )
    constraints: SteeringRateMPCConstraintConfig = field(
        default_factory=SteeringRateMPCConstraintConfig
    )
    solver: MPCSolverConfig = field(default_factory=MPCSolverConfig)
    linearization_strategy: MPCSpeedLinearizationStrategy = (
        MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
    )
    fixed_linearization_speed_mps: float | None = None
    fallback: MPCFallbackConfig = field(default_factory=MPCFallbackConfig)

    def __post_init__(self) -> None:
        _validate_policy_specific_config(
            self,
            objective_type=SteeringRateMPCObjectiveConfig,
            constraint_type=SteeringRateMPCConstraintConfig,
        )

    @classmethod
    def teaching_baseline(
        cls,
        **overrides,
    ) -> "AutonomousDrivingSteeringRateMPCConfig":
        baseline = cls(
            horizon_steps=20,
            environment=None,
            model=None,
            objective=SteeringRateMPCObjectiveConfig(
                speed_state_quadratic_weight=1.0,
                lateral_error_state_quadratic_weight=1.0,
                heading_error_state_quadratic_weight=1.0,
                steering_angle_state_quadratic_weight=1.0,
                normalized_drive_command_control_quadratic_weight=1.0,
                steering_rate_control_quadratic_weight=1.0,
                speed_state_linear_weight=0.0,
                lateral_error_state_linear_weight=0.0,
                heading_error_state_linear_weight=0.0,
                steering_angle_state_linear_weight=0.0,
                normalized_drive_command_control_linear_weight=0.0,
                steering_rate_control_linear_weight=0.0,
            ),
            constraints=SteeringRateMPCConstraintConfig(
                normalized_drive_command_control_lower=-0.75,
                normalized_drive_command_control_upper=0.75,
                normalized_drive_command_control_change_lower_per_step=-0.10,
                normalized_drive_command_control_change_upper_per_step=0.10,
                steering_rate_control_lower_radians_per_second=None,
                steering_rate_control_upper_radians_per_second=None,
                steering_angle_state_lower_radians=None,
                steering_angle_state_upper_radians=None,
                soft_speed_state_lower_mps=None,
                recommended_speed_soft_upper_margin_mps=0.0,
                soft_lateral_error_state_lower_metres=None,
                soft_lateral_error_state_upper_metres=None,
                soft_heading_error_state_lower_radians=None,
                soft_heading_error_state_upper_radians=None,
                soft_state_linear_penalty=5.0,
                soft_state_quadratic_penalty=5.0,
            ),
            solver=MPCSolverConfig(
                dtype="float64",
                verbose=False,
                absolute_tolerance=1.0e-3,
                relative_tolerance=1.0e-3,
                max_iterations=4000,
                polishing=False,
                adaptive_rho=True,
                check_termination_interval=25,
                time_limit_seconds=None,
                accept_solved_inaccurate=True,
                additional_osqp_settings={},
            ),
            linearization_strategy=(
                MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
            ),
            fixed_linearization_speed_mps=None,
            fallback=MPCFallbackConfig(
                mode=MPCFallbackMode.HOLD_PREVIOUS_ACTION,
                constant_environment_action=None,
                policy_factory=None,
            ),
        )
        return replace(baseline, **overrides)


@dataclass(frozen=True, slots=True)
class AutonomousDrivingRoadAwareDirectSteeringMPCConfig:
    horizon_steps: int = 20
    environment: MPCEnvironmentConfig | None = None
    model: KinematicBicycleMPCModelConfig | None = None
    objective: DirectSteeringMPCObjectiveConfig = field(
        default_factory=DirectSteeringMPCObjectiveConfig
    )
    constraints: RoadAwareDirectSteeringMPCConstraintConfig = field(
        default_factory=RoadAwareDirectSteeringMPCConstraintConfig
    )
    solver: MPCSolverConfig = field(default_factory=MPCSolverConfig)
    linearization_strategy: MPCSpeedLinearizationStrategy = (
        MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
    )
    fixed_linearization_speed_mps: float | None = None
    fallback: MPCFallbackConfig = field(default_factory=MPCFallbackConfig)
    use_speed_preview: bool = True
    use_curvature_preview: bool = True
    use_lane_bound_constraints: bool = True
    road_preview_extension_mode: MPCRoadPreviewExtensionMode = (
        MPCRoadPreviewExtensionMode.ERROR
    )

    def __post_init__(self) -> None:
        _validate_road_aware_policy_config(
            self,
            objective_type=DirectSteeringMPCObjectiveConfig,
            constraint_type=RoadAwareDirectSteeringMPCConstraintConfig,
        )

    @classmethod
    def fully_road_aware_teaching_preset(
        cls,
        **overrides,
    ) -> "AutonomousDrivingRoadAwareDirectSteeringMPCConfig":
        baseline = AutonomousDrivingDirectSteeringMPCConfig.teaching_baseline()
        baseline_constraints = baseline.constraints
        preset = cls(
            horizon_steps=baseline.horizon_steps,
            environment=baseline.environment,
            model=baseline.model,
            objective=baseline.objective,
            constraints=_road_aware_direct_teaching_constraints(
                baseline_constraints
            ),
            solver=baseline.solver,
            linearization_strategy=baseline.linearization_strategy,
            fixed_linearization_speed_mps=baseline.fixed_linearization_speed_mps,
            fallback=baseline.fallback,
            use_speed_preview=True,
            use_curvature_preview=True,
            use_lane_bound_constraints=True,
            road_preview_extension_mode=MPCRoadPreviewExtensionMode.ERROR,
        )
        return replace(preset, **overrides)


@dataclass(frozen=True, slots=True)
class AutonomousDrivingRoadAwareSteeringRateMPCConfig:
    horizon_steps: int = 20
    environment: MPCEnvironmentConfig | None = None
    model: KinematicBicycleMPCModelConfig | None = None
    objective: SteeringRateMPCObjectiveConfig = field(
        default_factory=SteeringRateMPCObjectiveConfig
    )
    constraints: RoadAwareSteeringRateMPCConstraintConfig = field(
        default_factory=RoadAwareSteeringRateMPCConstraintConfig
    )
    solver: MPCSolverConfig = field(default_factory=MPCSolverConfig)
    linearization_strategy: MPCSpeedLinearizationStrategy = (
        MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED
    )
    fixed_linearization_speed_mps: float | None = None
    fallback: MPCFallbackConfig = field(default_factory=MPCFallbackConfig)
    use_speed_preview: bool = True
    use_curvature_preview: bool = True
    use_lane_bound_constraints: bool = True
    road_preview_extension_mode: MPCRoadPreviewExtensionMode = (
        MPCRoadPreviewExtensionMode.ERROR
    )

    def __post_init__(self) -> None:
        _validate_road_aware_policy_config(
            self,
            objective_type=SteeringRateMPCObjectiveConfig,
            constraint_type=RoadAwareSteeringRateMPCConstraintConfig,
        )

    @classmethod
    def fully_road_aware_teaching_preset(
        cls,
        **overrides,
    ) -> "AutonomousDrivingRoadAwareSteeringRateMPCConfig":
        baseline = AutonomousDrivingSteeringRateMPCConfig.teaching_baseline()
        baseline_constraints = baseline.constraints
        preset = cls(
            horizon_steps=baseline.horizon_steps,
            environment=baseline.environment,
            model=baseline.model,
            objective=baseline.objective,
            constraints=_road_aware_rate_teaching_constraints(
                baseline_constraints
            ),
            solver=baseline.solver,
            linearization_strategy=baseline.linearization_strategy,
            fixed_linearization_speed_mps=baseline.fixed_linearization_speed_mps,
            fallback=baseline.fallback,
            use_speed_preview=True,
            use_curvature_preview=True,
            use_lane_bound_constraints=True,
            road_preview_extension_mode=MPCRoadPreviewExtensionMode.ERROR,
        )
        return replace(preset, **overrides)
