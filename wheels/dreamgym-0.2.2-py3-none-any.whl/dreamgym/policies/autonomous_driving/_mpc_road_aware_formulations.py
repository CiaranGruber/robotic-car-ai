"""Pure road-aware formulation schedules for autonomous-driving MPC."""

from __future__ import annotations

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_formulations import (
    build_direct_steering_model,
    build_steering_rate_model,
)
from dreamgym.policies.autonomous_driving.mpc_config import (
    KinematicBicycleMPCModelConfig,
)


def _state_row_schedule(
    name: str,
    values,
    *,
    horizon_steps: int | None = None,
) -> np.ndarray:
    schedule = np.asarray(values, dtype=np.float64)
    expected_length = (
        None if horizon_steps is None else horizon_steps + 1
    )
    if schedule.ndim != 1 or schedule.shape[0] < 2:
        raise ValueError(f"{name} must have shape (N + 1,) with N >= 1")
    if expected_length is not None and schedule.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got "
            f"{schedule.shape}"
        )
    if not np.isfinite(schedule).all():
        raise ValueError(f"{name} must contain only finite values")
    return schedule


def build_road_aware_direct_steering_model_schedule(
    model: KinematicBicycleMPCModelConfig,
    linearization_speeds_mps,
    target_line_curvatures_per_metre,
) -> tuple[
    tuple[np.ndarray, ...],
    tuple[np.ndarray, ...],
    tuple[np.ndarray, ...],
]:
    """Build unchanged direct-steering matrices and curvature offsets."""

    speeds = np.asarray(linearization_speeds_mps, dtype=np.float64)
    if speeds.ndim != 1 or speeds.shape[0] < 1:
        raise ValueError(
            "linearization_speeds_mps must have shape (N,) with N >= 1"
        )
    if not np.isfinite(speeds).all():
        raise ValueError(
            "linearization_speeds_mps must contain only finite values"
        )
    curvatures = _state_row_schedule(
        "target_line_curvatures_per_metre",
        target_line_curvatures_per_metre,
        horizon_steps=speeds.shape[0],
    )
    models = tuple(
        build_direct_steering_model(model, speed) for speed in speeds
    )
    timestep = model.control_timestep_seconds
    affine_offsets = tuple(
        np.array(
            [
                0.0,
                -0.5 * timestep**2 * speed**2 * curvature,
                -timestep * speed * curvature,
            ],
            dtype=np.float64,
        )
        for speed, curvature in zip(
            speeds,
            curvatures[:-1],
            strict=True,
        )
    )
    return (
        tuple(state_matrix for state_matrix, _ in models),
        tuple(control_matrix for _, control_matrix in models),
        affine_offsets,
    )


def build_direct_steering_feedforward(
    model: KinematicBicycleMPCModelConfig,
    target_line_curvatures_per_metre,
    *,
    direct_steering_angle_lower_radians: float,
    direct_steering_angle_upper_radians: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Build unclipped small-angle steering references and bound diagnostics."""

    curvatures = _state_row_schedule(
        "target_line_curvatures_per_metre",
        target_line_curvatures_per_metre,
    )
    lower = float(direct_steering_angle_lower_radians)
    upper = float(direct_steering_angle_upper_radians)
    if not np.isfinite((lower, upper)).all():
        raise ValueError("steering-angle bounds must be finite")
    if lower > upper:
        raise ValueError(
            "direct_steering_angle_lower_radians must not exceed "
            "direct_steering_angle_upper_radians"
        )
    wheelbase = (
        model.front_axle_distance_metres
        + model.rear_axle_distance_metres
    )
    references = wheelbase * curvatures[:-1]
    exceeds_bound = np.logical_or(references < lower, references > upper)
    return references, exceeds_bound


def build_road_aware_steering_rate_model_schedule(
    model: KinematicBicycleMPCModelConfig,
    linearization_speeds_mps,
    target_line_curvatures_per_metre,
) -> tuple[
    tuple[np.ndarray, ...],
    tuple[np.ndarray, ...],
    tuple[np.ndarray, ...],
]:
    """Build unchanged steering-rate matrices and varying-curvature offsets."""

    speeds = np.asarray(linearization_speeds_mps, dtype=np.float64)
    if speeds.ndim != 1 or speeds.shape[0] < 1:
        raise ValueError(
            "linearization_speeds_mps must have shape (N,) with N >= 1"
        )
    if not np.isfinite(speeds).all():
        raise ValueError(
            "linearization_speeds_mps must contain only finite values"
        )
    curvatures = _state_row_schedule(
        "target_line_curvatures_per_metre",
        target_line_curvatures_per_metre,
        horizon_steps=speeds.shape[0],
    )
    models = tuple(
        build_steering_rate_model(model, speed) for speed in speeds
    )
    timestep = model.control_timestep_seconds
    affine_offsets = tuple(
        np.array(
            [
                0.0,
                -(timestep**2 * speed**2 / 6.0)
                * (2.0 * curvatures[stage] + curvatures[stage + 1]),
                -(timestep * speed / 2.0)
                * (curvatures[stage] + curvatures[stage + 1]),
                0.0,
            ],
            dtype=np.float64,
        )
        for stage, speed in enumerate(speeds)
    )
    return (
        tuple(state_matrix for state_matrix, _ in models),
        tuple(control_matrix for _, control_matrix in models),
        affine_offsets,
    )


def build_steering_rate_feedforward(
    model: KinematicBicycleMPCModelConfig,
    target_line_curvatures_per_metre,
    *,
    steering_angle_state_lower_radians: float,
    steering_angle_state_upper_radians: float,
    steering_rate_control_lower_radians_per_second: float,
    steering_rate_control_upper_radians_per_second: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Build unclipped steering-angle-state and steering-rate references."""

    curvatures = _state_row_schedule(
        "target_line_curvatures_per_metre",
        target_line_curvatures_per_metre,
    )
    angle_lower = float(steering_angle_state_lower_radians)
    angle_upper = float(steering_angle_state_upper_radians)
    rate_lower = float(steering_rate_control_lower_radians_per_second)
    rate_upper = float(steering_rate_control_upper_radians_per_second)
    if not np.isfinite(
        (angle_lower, angle_upper, rate_lower, rate_upper)
    ).all():
        raise ValueError("steering-angle-state and steering-rate bounds must be finite")
    if angle_lower > angle_upper:
        raise ValueError(
            "steering_angle_state_lower_radians must not exceed "
            "steering_angle_state_upper_radians"
        )
    if rate_lower > rate_upper:
        raise ValueError(
            "steering_rate_control_lower_radians_per_second must not exceed "
            "steering_rate_control_upper_radians_per_second"
        )
    wheelbase = (
        model.front_axle_distance_metres
        + model.rear_axle_distance_metres
    )
    steering_angle_references = wheelbase * curvatures
    steering_rate_references = (
        np.diff(steering_angle_references)
        / model.control_timestep_seconds
    )
    steering_angle_exceeds_bound = np.logical_or(
        steering_angle_references < angle_lower,
        steering_angle_references > angle_upper,
    )
    steering_rate_exceeds_bound = np.logical_or(
        steering_rate_references < rate_lower,
        steering_rate_references > rate_upper,
    )
    return (
        steering_angle_references,
        steering_angle_exceeds_bound,
        steering_rate_references,
        steering_rate_exceeds_bound,
    )
