"""Deterministic road-preview materialization for road-aware MPC policies."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_adapter import (
    MPCRoadPreviewObservation,
)
from dreamgym.policies.autonomous_driving._mpc_failures import (
    _MPCPolicyInputError,
)
from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    MPCRoadPreviewExtensionMode,
)
from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCPolicyFailure,
    MPCPolicyFailureStage,
    MPCRoadHorizonContext,
)


_RoadAwareMPCConfig = (
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig
    | AutonomousDrivingRoadAwareSteeringRateMPCConfig
)


@dataclass(frozen=True, slots=True)
class _RoadHorizonMaterialization:
    """Validated fixed-grid and interpolated road-preview schedules."""

    source_distances_metres: np.ndarray
    source_validity: np.ndarray
    source_target_line_curvatures_per_metre: np.ndarray | None
    source_recommended_speeds_mps: np.ndarray | None
    source_speed_limits_mps: np.ndarray | None
    source_right_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    source_left_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    target_selector_provenance: str
    target_curvature_provenance: str
    lane_selection_provenance: str | None
    lane_index: int | None
    progress_schedule_metres: np.ndarray
    road_preview_query_distances_metres: np.ndarray
    interpolated_target_line_curvatures_per_metre: np.ndarray | None
    interpolated_recommended_speeds_mps: np.ndarray | None
    interpolated_speed_limits_mps: np.ndarray | None
    interpolated_right_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    interpolated_left_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    effective_speed_references_mps: np.ndarray
    recommended_speed_soft_ceiling_mps: np.ndarray | None
    speed_limit_soft_ceiling_mps: np.ndarray | None
    curvature_soft_ceiling_mps: np.ndarray | None
    installed_soft_speed_upper_bounds_mps: np.ndarray | None
    installed_soft_lateral_error_lower_bounds_metres: np.ndarray | None
    installed_soft_lateral_error_upper_bounds_metres: np.ndarray | None
    reference_transition_index: int | None
    extension_mode: MPCRoadPreviewExtensionMode
    extension_mask: np.ndarray
    final_valid_preview_distance_metres: float
    first_extended_distance_metres: float | None
    maximum_requested_distance_metres: float
    use_speed_preview: bool
    use_curvature_preview: bool
    use_lane_bound_constraints: bool


def _read_only_float_vector(value: np.ndarray) -> np.ndarray:
    copied = np.array(value, dtype=np.float64, copy=True)
    copied.setflags(write=False)
    return copied


def _checked_schedule_array(
    name: str,
    value: np.ndarray,
    expected_length: int,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    return _read_only_float_vector(value)


def _raise_policy_input_error(
    *,
    stage: MPCPolicyFailureStage,
    reason: str,
    field_name: str,
    message: str,
) -> None:
    raise _MPCPolicyInputError(
        MPCPolicyFailure(
            stage=stage,
            reason=reason,
            field_name=field_name,
            message=message,
        )
    )


def _lane_bounds_have_unavailable_valid_rows(
    right_lane_bound_offsets: np.ndarray,
    left_lane_bound_offsets: np.ndarray,
    valid_rows: np.ndarray,
) -> bool:
    """Return whether the Road's authoritative bounds contain a reversed row."""

    return bool(
        np.any(
            right_lane_bound_offsets[valid_rows]
            > left_lane_bound_offsets[valid_rows]
        )
    )


def _interpolate_valid_prefix(
    source_distances_metres: np.ndarray,
    source_channel: np.ndarray,
    source_validity: np.ndarray,
    query_distances_metres: np.ndarray,
    extension_mode: MPCRoadPreviewExtensionMode,
    semantic_field_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Interpolate one channel on its finite prefix and diagnose extension."""

    valid_count = int(np.count_nonzero(source_validity))
    valid_distances = source_distances_metres[:valid_count]
    valid_values = source_channel[:valid_count]
    if not np.isfinite(valid_values).all():
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_PREVIEW,
            reason="nonfinite_value",
            field_name=semantic_field_name,
            message=f"{semantic_field_name} contains a nonfinite valid row",
        )
    final_valid_distance = float(valid_distances[-1])
    extension_mask = query_distances_metres > final_valid_distance
    if (
        np.any(extension_mask)
        and extension_mode is MPCRoadPreviewExtensionMode.ERROR
    ):
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_HORIZON,
            reason="coverage_exhausted",
            field_name="road_preview_query_distances_metres",
            message="the required horizon exceeds valid road-preview coverage",
        )

    interpolated = np.empty(query_distances_metres.shape, dtype=np.float64)
    covered = ~extension_mask
    interpolated[covered] = np.interp(
        query_distances_metres[covered],
        valid_distances,
        valid_values,
    )
    if np.any(extension_mask):
        interpolated[extension_mask] = valid_values[-1]
    interpolated.setflags(write=False)
    extension_mask.setflags(write=False)
    return interpolated, extension_mask


def required_road_preview_fields(config) -> tuple[str, ...]:
    """Return the routed road-preview fields required by enabled features."""

    required: list[str] = []
    if config.use_speed_preview:
        required.extend(
            (
                "road_preview_recommended_speeds_mps",
                "road_preview_speed_limits_mps",
            )
        )
    if config.use_curvature_preview:
        required.append("road_preview_target_line_curvatures_per_m")
    if config.use_lane_bound_constraints:
        required.extend(
            (
                "road_preview_right_lane_bound_offsets_from_target_line_m",
                "road_preview_left_lane_bound_offsets_from_target_line_m",
            )
        )
    if required:
        required.append("road_preview_is_spatially_valid")
    return tuple(required)


def materialize_road_horizon(
    config: _RoadAwareMPCConfig,
    *,
    road_preview: MPCRoadPreviewObservation,
    progress_schedule_metres: np.ndarray,
    baseline_reference_speeds_mps: np.ndarray,
    baseline_soft_speed_upper_bounds_mps: np.ndarray | None,
    baseline_reference_transition_index: int | None,
) -> _RoadHorizonMaterialization:
    """Validate and interpolate one decoded fixed-grid road preview."""

    if not any(
        (
            config.use_speed_preview,
            config.use_curvature_preview,
            config.use_lane_bound_constraints,
        )
    ):
        raise ValueError(
            "road-horizon materialization requires at least one enabled road feature"
        )
    if not isinstance(road_preview, MPCRoadPreviewObservation):
        raise TypeError("road_preview must be an MPCRoadPreviewObservation")
    environment = config.environment
    if environment is None:
        raise ValueError(
            "road-horizon materialization requires an environment snapshot"
        )
    configured_distances = environment.road_preview_distances_metres
    if configured_distances is None:
        raise ValueError("road-horizon materialization requires a source distance grid")
    source_distances = np.asarray(configured_distances, dtype=np.float64)
    if source_distances.shape != road_preview.validity.shape:
        raise ValueError(
            "road-preview source distances and decoded values must have equal shapes"
        )
    target_curvature_provenance = (
        environment.road_preview_target_curvature_provenance
    )
    if target_curvature_provenance is None:
        raise ValueError(
            "road-horizon materialization requires target-curvature provenance"
        )
    if environment.target_lane_index is not None:
        target_selector_provenance = "target_lane_index"
    elif environment.target_lane_units is not None:
        target_selector_provenance = "target_lane_units"
    elif target_curvature_provenance == "exact_parallel_curve":
        target_selector_provenance = "fixed_offset"
    else:
        target_selector_provenance = "reference_line"
    if config.use_lane_bound_constraints:
        lane_selection_provenance = (
            environment.road_preview_lane_selection_provenance
        )
        lane_index = environment.road_preview_lane_index
        if lane_selection_provenance is None:
            raise ValueError(
                "lane-bound materialization requires lane-selection provenance"
            )
    else:
        lane_selection_provenance = None
        lane_index = None
    if (
        source_distances.ndim != 1
        or source_distances.size == 0
        or not np.isfinite(source_distances).all()
        or source_distances[0] != 0.0
        or np.any(np.diff(source_distances) <= 0.0)
    ):
        raise ValueError(
            "road-preview source distances must be finite and strictly increasing "
            "from zero"
        )

    if not isinstance(progress_schedule_metres, np.ndarray):
        raise TypeError("progress_schedule_metres must be a NumPy array")
    if progress_schedule_metres.ndim != 1:
        raise ValueError("progress_schedule_metres must be one-dimensional")
    if progress_schedule_metres.dtype.kind not in "iuf":
        raise TypeError("progress_schedule_metres must have a real numeric dtype")
    if progress_schedule_metres.size < 2:
        raise ValueError("progress_schedule_metres must contain at least two rows")
    progress_schedule = np.array(
        progress_schedule_metres,
        dtype=np.float64,
        copy=True,
    )
    road_query = np.array(
        progress_schedule_metres,
        dtype=np.float64,
        copy=True,
    )
    if np.any(road_query < 0.0):
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_HORIZON,
            reason="negative_query",
            field_name="road_preview_query_distances_metres",
            message="road-preview query distances must not be negative",
        )
    if not np.isfinite(road_query).all():
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_HORIZON,
            reason="nonfinite_value",
            field_name="road_preview_query_distances_metres",
            message="road-preview query distances must be finite",
        )
    if road_query[0] != 0.0 or np.any(np.diff(road_query) < 0.0):
        raise ValueError(
            "progress_schedule_metres must begin at zero and be nondecreasing"
        )
    progress_schedule.setflags(write=False)
    road_query.setflags(write=False)

    validity_values = np.asarray(road_preview.validity)
    is_binary = np.logical_or(validity_values == 0.0, validity_values == 1.0)
    valid_count = int(np.count_nonzero(validity_values == 1.0))
    expected_validity = np.arange(validity_values.size) < valid_count
    if (
        not np.isfinite(validity_values).all()
        or not np.all(is_binary)
        or valid_count == 0
        or not np.array_equal(validity_values == 1.0, expected_validity)
    ):
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_PREVIEW,
            reason="invalid_validity_mask",
            field_name="road_preview_is_spatially_valid",
            message="road-preview validity must contain a nonempty binary prefix",
        )

    source_validity = np.array(expected_validity, dtype=bool, copy=True)
    source_validity.setflags(write=False)
    enabled_channels = (
        (
            config.use_curvature_preview,
            "target_line_curvatures_per_metre",
            "source_target_line_curvatures_per_metre",
        ),
        (
            config.use_speed_preview,
            "recommended_speeds_mps",
            "source_recommended_speeds_mps",
        ),
        (
            config.use_speed_preview,
            "speed_limits_mps",
            "source_speed_limits_mps",
        ),
        (
            config.use_lane_bound_constraints,
            "right_lane_bound_offsets_from_target_line_metres",
            "source_right_lane_bound_offsets_from_target_line_metres",
        ),
        (
            config.use_lane_bound_constraints,
            "left_lane_bound_offsets_from_target_line_metres",
            "source_left_lane_bound_offsets_from_target_line_metres",
        ),
    )
    sources: dict[str, np.ndarray | None] = {}
    for enabled, preview_field, source_field in enabled_channels:
        if not enabled:
            sources[source_field] = None
            continue
        values = getattr(road_preview, preview_field)
        if values is None:
            raise ValueError(
                f"{preview_field} is required when its road feature is enabled"
            )
        if (
            np.isinf(values).any()
            or not np.isfinite(values[source_validity]).all()
        ):
            reason = (
                "lane_unavailable"
                if source_field
                in {
                    "source_right_lane_bound_offsets_from_target_line_metres",
                    "source_left_lane_bound_offsets_from_target_line_metres",
                }
                else "nonfinite_value"
            )
            _raise_policy_input_error(
                stage=MPCPolicyFailureStage.ROAD_PREVIEW,
                reason=reason,
                field_name=source_field,
                message=(
                    f"{source_field} contains an unsupported infinity or a "
                    "nonfinite valid row"
                ),
            )
        sources[source_field] = _read_only_float_vector(values)

    for source_field in (
        "source_recommended_speeds_mps",
        "source_speed_limits_mps",
    ):
        values = sources[source_field]
        if values is not None and np.any(values[source_validity] < 0.0):
            _raise_policy_input_error(
                stage=MPCPolicyFailureStage.ROAD_PREVIEW,
                reason="formulation_input_invalid",
                field_name=source_field,
                message=f"{source_field} contains a negative valid row",
            )

    if config.use_lane_bound_constraints:
        source_right = sources[
            "source_right_lane_bound_offsets_from_target_line_metres"
        ]
        source_left = sources[
            "source_left_lane_bound_offsets_from_target_line_metres"
        ]
        assert source_right is not None and source_left is not None
        if _lane_bounds_have_unavailable_valid_rows(
            source_right,
            source_left,
            source_validity,
        ):
            _raise_policy_input_error(
                stage=MPCPolicyFailureStage.ROAD_PREVIEW,
                reason="lane_unavailable",
                field_name=(
                    "source_right_lane_bound_offsets_from_target_line_metres"
                ),
                message="source right lane bounds exceed source left lane bounds",
            )

    extension_mode = config.road_preview_extension_mode
    if not isinstance(extension_mode, MPCRoadPreviewExtensionMode):
        raise TypeError(
            "road_preview_extension_mode must be an MPCRoadPreviewExtensionMode"
        )
    interpolated: dict[str, np.ndarray | None] = {}
    interpolation_fields = (
        (
            "source_target_line_curvatures_per_metre",
            "interpolated_target_line_curvatures_per_metre",
        ),
        (
            "source_recommended_speeds_mps",
            "interpolated_recommended_speeds_mps",
        ),
        (
            "source_speed_limits_mps",
            "interpolated_speed_limits_mps",
        ),
        (
            "source_right_lane_bound_offsets_from_target_line_metres",
            "interpolated_right_lane_bound_offsets_from_target_line_metres",
        ),
        (
            "source_left_lane_bound_offsets_from_target_line_metres",
            "interpolated_left_lane_bound_offsets_from_target_line_metres",
        ),
    )
    common_extension_mask: np.ndarray | None = None
    for source_field, interpolated_field in interpolation_fields:
        source_channel = sources[source_field]
        if source_channel is None:
            interpolated[interpolated_field] = None
            continue
        values, channel_extension_mask = _interpolate_valid_prefix(
            source_distances,
            source_channel,
            source_validity,
            road_query,
            extension_mode,
            source_field,
        )
        if common_extension_mask is None:
            common_extension_mask = channel_extension_mask
        elif not np.array_equal(
            common_extension_mask,
            channel_extension_mask,
        ):
            raise RuntimeError(
                "road-preview channels produced inconsistent extension masks"
            )
        interpolated[interpolated_field] = values
    if common_extension_mask is None:
        raise ValueError(
            "road-horizon materialization requires at least one enabled road feature"
        )

    final_valid_distance = float(source_distances[valid_count - 1])
    if np.any(common_extension_mask):
        first_extended_distance = float(road_query[common_extension_mask][0])
    else:
        first_extended_distance = None

    horizon_steps = road_query.shape[0] - 1
    if config.use_speed_preview:
        interpolated_recommended = interpolated[
            "interpolated_recommended_speeds_mps"
        ]
        interpolated_speed_limits = interpolated[
            "interpolated_speed_limits_mps"
        ]
        assert (
            interpolated_recommended is not None
            and interpolated_speed_limits is not None
        )
        effective_speed_references = _read_only_float_vector(
            np.minimum(interpolated_recommended, interpolated_speed_limits)
        )
        recommended_margin = (
            config.constraints.recommended_speed_soft_upper_margin_mps
        )
        recommended_ceiling = (
            None
            if recommended_margin is None
            else _read_only_float_vector(
                interpolated_recommended[1:] + recommended_margin
            )
        )
        speed_limit_margin = (
            config.constraints.speed_limit_soft_upper_margin_mps
        )
        speed_limit_ceiling = (
            None
            if speed_limit_margin is None
            else _read_only_float_vector(
                interpolated_speed_limits[1:] + speed_limit_margin
            )
        )
        baseline_ceiling = None
        reference_transition_index = None
    else:
        effective_speed_references = _checked_schedule_array(
            "baseline_reference_speeds_mps",
            baseline_reference_speeds_mps,
            horizon_steps + 1,
        )
        recommended_ceiling = None
        speed_limit_ceiling = None
        baseline_ceiling = (
            None
            if baseline_soft_speed_upper_bounds_mps is None
            else _checked_schedule_array(
                "baseline_soft_speed_upper_bounds_mps",
                baseline_soft_speed_upper_bounds_mps,
                horizon_steps,
            )
        )
        reference_transition_index = baseline_reference_transition_index

    if (
        not np.isfinite(effective_speed_references).all()
        or np.any(effective_speed_references < 0.0)
    ):
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_HORIZON,
            reason="formulation_input_invalid",
            field_name="effective_speed_references_mps",
            message="the final speed-reference schedule must be finite and nonnegative",
        )

    curvature_ceiling = None
    maximum_lateral_acceleration = (
        config.constraints.maximum_lateral_acceleration_mps2
    )
    if config.use_curvature_preview and maximum_lateral_acceleration is not None:
        interpolated_curvature = interpolated[
            "interpolated_target_line_curvatures_per_metre"
        ]
        assert interpolated_curvature is not None
        constrained_curvature = np.abs(interpolated_curvature[1:])
        curvature_ceiling_values = np.full(
            horizon_steps,
            np.inf,
            dtype=np.float64,
        )
        active_curvature = constrained_curvature > 1.0e-12
        curvature_ceiling_values[active_curvature] = np.sqrt(
            maximum_lateral_acceleration
            / constrained_curvature[active_curvature]
        )
        curvature_ceiling_values.setflags(write=False)
        curvature_ceiling = curvature_ceiling_values

    contributors = [
        value
        for value in (
            baseline_ceiling,
            recommended_ceiling,
            speed_limit_ceiling,
            curvature_ceiling,
        )
        if value is not None
    ]
    installed_speed_ceiling = None
    if contributors:
        installed_values = np.full(horizon_steps, np.inf, dtype=np.float64)
        for contributor in contributors:
            installed_values = np.minimum(installed_values, contributor)
        installed_values.setflags(write=False)
        installed_speed_ceiling = installed_values
    if installed_speed_ceiling is not None and (
        np.isnan(installed_speed_ceiling).any()
        or np.any(installed_speed_ceiling < 0.0)
    ):
        _raise_policy_input_error(
            stage=MPCPolicyFailureStage.ROAD_HORIZON,
            reason="formulation_input_invalid",
            field_name="installed_soft_speed_upper_bounds_mps",
            message=(
                "the final speed-ceiling schedule must not contain NaN or "
                "negative values"
            ),
        )

    installed_lane_lower = None
    installed_lane_upper = None
    if config.use_lane_bound_constraints:
        vehicle_width = config.constraints.vehicle_body_width_metres
        if vehicle_width is None:
            raise ValueError(
                "lane-bound materialization requires a resolved vehicle body width"
            )
        lane_margin = config.constraints.lane_safety_margin_metres
        if (
            not np.isfinite(vehicle_width)
            or vehicle_width <= 0.0
            or not np.isfinite(lane_margin)
            or lane_margin < 0.0
        ):
            raise ValueError(
                "lane-bound materialization requires valid width and margin beliefs"
            )
        interpolated_right = interpolated[
            "interpolated_right_lane_bound_offsets_from_target_line_metres"
        ]
        interpolated_left = interpolated[
            "interpolated_left_lane_bound_offsets_from_target_line_metres"
        ]
        assert interpolated_right is not None and interpolated_left is not None
        footprint_clearance = 0.5 * vehicle_width + lane_margin
        contracted_lower = interpolated_right[1:] + footprint_clearance
        contracted_upper = interpolated_left[1:] - footprint_clearance
        if (
            not np.isfinite(contracted_lower).all()
            or not np.isfinite(contracted_upper).all()
            or np.any(contracted_lower > contracted_upper)
        ):
            _raise_policy_input_error(
                stage=MPCPolicyFailureStage.ROAD_HORIZON,
                reason="lane_unavailable",
                field_name=(
                    "installed_soft_lateral_error_lower_bounds_metres"
                ),
                message="the contracted lane envelope is unavailable",
            )

        static_lower = (
            config.constraints.soft_lateral_error_state_lower_metres
        )
        static_upper = (
            config.constraints.soft_lateral_error_state_upper_metres
        )
        installed_lower_values = np.array(
            contracted_lower,
            dtype=np.float64,
            copy=True,
        )
        installed_upper_values = np.array(
            contracted_upper,
            dtype=np.float64,
            copy=True,
        )
        if static_lower is not None:
            installed_lower_values = np.maximum(
                installed_lower_values,
                static_lower,
            )
        if static_upper is not None:
            installed_upper_values = np.minimum(
                installed_upper_values,
                static_upper,
            )
        if np.any(installed_lower_values > installed_upper_values):
            _raise_policy_input_error(
                stage=MPCPolicyFailureStage.ROAD_HORIZON,
                reason="lane_envelope_empty",
                field_name="installed_soft_lateral_error_bounds_metres",
                message=(
                    "the contracted lane and static lateral bounds do not "
                    "intersect"
                ),
            )
        installed_lower_values.setflags(write=False)
        installed_upper_values.setflags(write=False)
        installed_lane_lower = installed_lower_values
        installed_lane_upper = installed_upper_values

    return _RoadHorizonMaterialization(
        source_distances_metres=_read_only_float_vector(source_distances),
        source_validity=source_validity,
        target_selector_provenance=target_selector_provenance,
        target_curvature_provenance=target_curvature_provenance,
        lane_selection_provenance=lane_selection_provenance,
        lane_index=lane_index,
        progress_schedule_metres=progress_schedule,
        road_preview_query_distances_metres=road_query,
        extension_mode=extension_mode,
        extension_mask=common_extension_mask,
        final_valid_preview_distance_metres=final_valid_distance,
        first_extended_distance_metres=first_extended_distance,
        maximum_requested_distance_metres=float(road_query[-1]),
        effective_speed_references_mps=effective_speed_references,
        recommended_speed_soft_ceiling_mps=recommended_ceiling,
        speed_limit_soft_ceiling_mps=speed_limit_ceiling,
        curvature_soft_ceiling_mps=curvature_ceiling,
        installed_soft_speed_upper_bounds_mps=installed_speed_ceiling,
        installed_soft_lateral_error_lower_bounds_metres=installed_lane_lower,
        installed_soft_lateral_error_upper_bounds_metres=installed_lane_upper,
        reference_transition_index=reference_transition_index,
        use_speed_preview=config.use_speed_preview,
        use_curvature_preview=config.use_curvature_preview,
        use_lane_bound_constraints=config.use_lane_bound_constraints,
        **sources,
        **interpolated,
    )


def finalize_road_horizon_context(
    materialization: _RoadHorizonMaterialization,
    *,
    direct_steering_angle_feedforward_radians: np.ndarray | None,
    direct_steering_angle_feedforward_exceeds_bound: np.ndarray | None,
    steering_angle_state_feedforward_radians: np.ndarray | None,
    steering_angle_state_feedforward_exceeds_bound: np.ndarray | None,
    steering_rate_control_feedforward_radians_per_second: np.ndarray | None,
    steering_rate_control_feedforward_exceeds_bound: np.ndarray | None,
) -> MPCRoadHorizonContext:
    """Finalize a complete context with one formulation's feedforward family."""

    if not isinstance(materialization, _RoadHorizonMaterialization):
        raise TypeError(
            "materialization must be a _RoadHorizonMaterialization"
        )
    return MPCRoadHorizonContext(
        source_distances_metres=materialization.source_distances_metres,
        source_validity=materialization.source_validity,
        source_target_line_curvatures_per_metre=(
            materialization.source_target_line_curvatures_per_metre
        ),
        source_recommended_speeds_mps=(
            materialization.source_recommended_speeds_mps
        ),
        source_speed_limits_mps=materialization.source_speed_limits_mps,
        source_right_lane_bound_offsets_from_target_line_metres=(
            materialization.source_right_lane_bound_offsets_from_target_line_metres
        ),
        source_left_lane_bound_offsets_from_target_line_metres=(
            materialization.source_left_lane_bound_offsets_from_target_line_metres
        ),
        target_selector_provenance=(
            materialization.target_selector_provenance
        ),
        target_curvature_provenance=(
            materialization.target_curvature_provenance
        ),
        lane_selection_provenance=(
            materialization.lane_selection_provenance
        ),
        lane_index=materialization.lane_index,
        progress_schedule_metres=materialization.progress_schedule_metres,
        road_preview_query_distances_metres=(
            materialization.road_preview_query_distances_metres
        ),
        interpolated_target_line_curvatures_per_metre=(
            materialization.interpolated_target_line_curvatures_per_metre
        ),
        interpolated_recommended_speeds_mps=(
            materialization.interpolated_recommended_speeds_mps
        ),
        interpolated_speed_limits_mps=(
            materialization.interpolated_speed_limits_mps
        ),
        interpolated_right_lane_bound_offsets_from_target_line_metres=(
            materialization.interpolated_right_lane_bound_offsets_from_target_line_metres
        ),
        interpolated_left_lane_bound_offsets_from_target_line_metres=(
            materialization.interpolated_left_lane_bound_offsets_from_target_line_metres
        ),
        effective_speed_references_mps=(
            materialization.effective_speed_references_mps
        ),
        recommended_speed_soft_ceiling_mps=(
            materialization.recommended_speed_soft_ceiling_mps
        ),
        speed_limit_soft_ceiling_mps=(
            materialization.speed_limit_soft_ceiling_mps
        ),
        curvature_soft_ceiling_mps=(
            materialization.curvature_soft_ceiling_mps
        ),
        installed_soft_speed_upper_bounds_mps=(
            materialization.installed_soft_speed_upper_bounds_mps
        ),
        installed_soft_lateral_error_lower_bounds_metres=(
            materialization.installed_soft_lateral_error_lower_bounds_metres
        ),
        installed_soft_lateral_error_upper_bounds_metres=(
            materialization.installed_soft_lateral_error_upper_bounds_metres
        ),
        direct_steering_angle_feedforward_radians=(
            direct_steering_angle_feedforward_radians
        ),
        direct_steering_angle_feedforward_exceeds_bound=(
            direct_steering_angle_feedforward_exceeds_bound
        ),
        steering_angle_state_feedforward_radians=(
            steering_angle_state_feedforward_radians
        ),
        steering_angle_state_feedforward_exceeds_bound=(
            steering_angle_state_feedforward_exceeds_bound
        ),
        steering_rate_control_feedforward_radians_per_second=(
            steering_rate_control_feedforward_radians_per_second
        ),
        steering_rate_control_feedforward_exceeds_bound=(
            steering_rate_control_feedforward_exceeds_bound
        ),
        extension_mode=materialization.extension_mode,
        extension_mask=materialization.extension_mask,
        final_valid_preview_distance_metres=(
            materialization.final_valid_preview_distance_metres
        ),
        first_extended_distance_metres=(
            materialization.first_extended_distance_metres
        ),
        maximum_requested_distance_metres=(
            materialization.maximum_requested_distance_metres
        ),
        use_speed_preview=materialization.use_speed_preview,
        use_curvature_preview=materialization.use_curvature_preview,
        use_lane_bound_constraints=(
            materialization.use_lane_bound_constraints
        ),
    )
