"""Structured results returned by autonomous-driving MPC policies."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
import math
from numbers import Integral, Real
from types import MappingProxyType

import numpy as np

from dreamgym.policies.autonomous_driving.mpc_config import (
    KinematicBicycleMPCModelConfig,
    MPCEnvironmentConfig,
    MPCFallbackMode,
    MPCRoadPreviewExtensionMode,
)
from dreamgym.policies.mpc import MPCSolveResult


class MPCPolicyFailureStage(str, Enum):
    """Policy stage that rejected a validly configured runtime input."""

    ROAD_PREVIEW = "road_preview"
    ROAD_HORIZON = "road_horizon"
    FORMULATION = "formulation"


_MPC_POLICY_FAILURE_REASONS = {
    "nonfinite_value",
    "invalid_validity_mask",
    "coverage_exhausted",
    "negative_query",
    "lane_unavailable",
    "lane_envelope_empty",
    "target_geometry_invalid",
    "formulation_input_invalid",
}

_MPC_TARGET_SELECTOR_PROVENANCE = frozenset(
    {
        "reference_line",
        "fixed_offset",
        "target_lane_index",
        "target_lane_units",
    }
)
_MPC_TARGET_CURVATURE_PROVENANCE = frozenset(
    {
        "exact_reference_line",
        "exact_parallel_curve",
        "tapered_target_approximation",
    }
)
_MPC_LANE_SELECTION_PROVENANCE = frozenset(
    {
        "reference_line_lane_center",
        "target_lane_index",
        "explicit_lane_index",
    }
)


def _validated_mpc_provenance(
    name: str,
    value: object,
    allowed: frozenset[str],
) -> str:
    if not isinstance(value, str) or value not in allowed:
        raise ValueError(f"{name} must be one of {sorted(allowed)}")
    return value


@dataclass(frozen=True, slots=True)
class MPCPolicyFailure:
    """Stable classification for a runtime failure before an MPC solve."""

    stage: MPCPolicyFailureStage
    reason: str
    field_name: str
    message: str

    def __post_init__(self) -> None:
        stage = self.stage
        if isinstance(stage, str) and not isinstance(stage, MPCPolicyFailureStage):
            try:
                stage = MPCPolicyFailureStage(stage)
            except ValueError as error:
                raise ValueError("invalid policy failure stage") from error
            object.__setattr__(self, "stage", stage)
        elif not isinstance(stage, MPCPolicyFailureStage):
            raise TypeError("stage must be an MPCPolicyFailureStage or string value")

        if not isinstance(self.reason, str):
            raise TypeError("reason must be a string")
        if self.reason not in _MPC_POLICY_FAILURE_REASONS:
            raise ValueError("reason is not an approved MPC policy failure reason")
        for field_name in ("field_name", "message"):
            value = getattr(self, field_name)
            if not isinstance(value, str):
                raise TypeError(f"{field_name} must be a string")
            if not value.strip():
                raise ValueError(f"{field_name} must be nonempty")


def _read_only_vector(
    name: str,
    value: object,
    expected_length: int | None = None,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if expected_length is not None and value.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, copy=True)
    if not np.isfinite(copied).all():
        raise ValueError(f"{name} must contain only finite values")
    copied.setflags(write=False)
    return copied


def _read_only_boolean_vector(
    name: str,
    value: object,
    expected_length: int,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if value.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got {value.shape}"
        )
    if value.dtype.kind != "b":
        raise TypeError(f"{name} must have a boolean dtype")
    copied = np.array(value, dtype=bool, copy=True)
    copied.setflags(write=False)
    return copied


def _read_only_vector_allowing_infinity(
    name: str,
    value: object,
    expected_length: int,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if value.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, copy=True)
    if np.isnan(copied).any():
        raise ValueError(f"{name} must not contain NaN values")
    copied.setflags(write=False)
    return copied


def _read_only_source_vector(
    name: str,
    value: object,
    expected_length: int,
    validity: np.ndarray,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if value.shape != (expected_length,):
        raise ValueError(
            f"{name} must have shape ({expected_length},), got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, copy=True)
    if np.isinf(copied).any() or not np.isfinite(copied[validity]).all():
        raise ValueError(
            f"{name} must be finite at every valid source distance and "
            "must not contain infinities"
        )
    copied.setflags(write=False)
    return copied


def _read_only_distance_schedule(
    name: str,
    value: object,
    expected_length: int | None = None,
    *,
    strictly_increasing: bool = False,
) -> np.ndarray:
    copied = _read_only_vector(name, value, expected_length)
    if copied.size == 0:
        raise ValueError(f"{name} must not be empty")
    if copied[0] != 0.0:
        raise ValueError(f"{name} must begin at zero")
    differences = np.diff(copied)
    if np.any(differences <= 0.0 if strictly_increasing else differences < 0.0):
        qualifier = "strictly increasing" if strictly_increasing else "nondecreasing"
        raise ValueError(f"{name} must be nonnegative and {qualifier}")
    return copied


def _expected_environment_action(
    normalized_action_before_clipping: np.ndarray,
    emitted_dtype: np.dtype,
) -> np.ndarray:
    return np.asarray(
        np.clip(normalized_action_before_clipping, -1.0, 1.0),
        dtype=emitted_dtype,
    )


def _expected_action_clipping_flags(
    normalized_action_before_clipping: np.ndarray,
) -> tuple[bool, bool]:
    return tuple(
        bool(value < -1.0 or value > 1.0)
        for value in normalized_action_before_clipping
    )


def _nonnegative_finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted) or converted < 0.0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return converted


def _finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    return converted


def _finite_pair(
    name: str,
    value: object,
    *,
    optional: bool = False,
    ordered: bool = True,
) -> tuple[float, float] | None:
    if value is None and optional:
        return None
    if not isinstance(value, (tuple, list)):
        raise TypeError(f"{name} must be a tuple/list")
    if len(value) != 2:
        raise ValueError(f"{name} must contain exactly two values")
    converted: list[float] = []
    for index, item in enumerate(value):
        if isinstance(item, bool) or not isinstance(item, Real):
            raise TypeError(f"{name}[{index}] must be a real number")
        scalar = float(item)
        if not math.isfinite(scalar):
            raise ValueError(f"{name}[{index}] must be finite")
        converted.append(scalar)
    if ordered and converted[0] > converted[1]:
        raise ValueError(f"{name} lower value must not exceed its upper value")
    return converted[0], converted[1]


def _immutable_mismatch_mapping(
    name: str,
    value: object,
) -> Mapping[str, tuple[float, float]] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping or None")
    copied: dict[str, tuple[float, float]] = {}
    for key, pair in value.items():
        if not isinstance(key, str) or not key:
            raise TypeError(f"{name} keys must be nonempty strings")
        converted = _finite_pair(
            f"{name}[{key!r}]",
            pair,
            ordered=False,
        )
        assert converted is not None
        copied[key] = converted
    return MappingProxyType(copied)


@dataclass(frozen=True, slots=True)
class MPCEnvironmentBindingDiagnostics:
    """Controller beliefs and facts from the policy's current plant binding."""

    controller_model: KinematicBicycleMPCModelConfig
    plant_model: KinematicBicycleMPCModelConfig | None
    environment: MPCEnvironmentConfig
    controller_steering_angle_bounds_radians: tuple[float, float]
    plant_steering_angle_bounds_radians: tuple[float, float] | None
    controller_steering_rate_bounds_radians_per_second: tuple[float, float] | None
    plant_steering_rate_bounds_radians_per_second: tuple[float, float] | None
    model_source: str
    steering_angle_bounds_source: str
    steering_rate_bounds_source: str | None
    model_parameter_mismatches: Mapping[str, tuple[float, float]] | None
    configured_steering_bound_mismatches: Mapping[str, tuple[float, float]] | None
    controller_vehicle_body_width_metres: float | None = None
    plant_vehicle_body_width_metres: float | None = None
    vehicle_body_width_source: str | None = None
    configured_vehicle_body_width_mismatch: tuple[float, float] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.controller_model, KinematicBicycleMPCModelConfig):
            raise TypeError(
                "controller_model must be a KinematicBicycleMPCModelConfig"
            )
        if self.plant_model is not None and not isinstance(
            self.plant_model,
            KinematicBicycleMPCModelConfig,
        ):
            raise TypeError(
                "plant_model must be a KinematicBicycleMPCModelConfig or None"
            )
        if not isinstance(self.environment, MPCEnvironmentConfig):
            raise TypeError("environment must be an MPCEnvironmentConfig")

        for field_name in (
            "controller_steering_angle_bounds_radians",
            "plant_steering_angle_bounds_radians",
            "controller_steering_rate_bounds_radians_per_second",
            "plant_steering_rate_bounds_radians_per_second",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_pair(
                    field_name,
                    getattr(self, field_name),
                    optional=field_name != "controller_steering_angle_bounds_radians",
                ),
            )

        valid_sources = {"explicit", "initial_environment_default"}
        for field_name in ("model_source", "steering_angle_bounds_source"):
            if getattr(self, field_name) not in valid_sources:
                raise ValueError(
                    f"{field_name} must be 'explicit' or "
                    "'initial_environment_default'"
                )
        rate_source = self.steering_rate_bounds_source
        if rate_source is not None and rate_source not in valid_sources:
            raise ValueError(
                "steering_rate_bounds_source must be 'explicit', "
                "'initial_environment_default', or None"
            )
        controller_rate_bounds = (
            self.controller_steering_rate_bounds_radians_per_second
        )
        if (controller_rate_bounds is None) != (rate_source is None):
            raise ValueError(
                "controller steering-rate bounds and source must both be present "
                "or both be None"
            )

        for field_name in (
            "model_parameter_mismatches",
            "configured_steering_bound_mismatches",
        ):
            object.__setattr__(
                self,
                field_name,
                _immutable_mismatch_mapping(field_name, getattr(self, field_name)),
            )

        controller_width = self.controller_vehicle_body_width_metres
        plant_width = self.plant_vehicle_body_width_metres
        for field_name, value in (
            ("controller_vehicle_body_width_metres", controller_width),
            ("plant_vehicle_body_width_metres", plant_width),
        ):
            if value is None:
                continue
            converted = _finite_float(field_name, value)
            if converted <= 0.0:
                raise ValueError(f"{field_name} must be greater than zero")
            object.__setattr__(self, field_name, converted)
            if field_name == "controller_vehicle_body_width_metres":
                controller_width = converted
            else:
                plant_width = converted

        width_source = self.vehicle_body_width_source
        width_mismatch = _finite_pair(
            "configured_vehicle_body_width_mismatch",
            self.configured_vehicle_body_width_mismatch,
            optional=True,
            ordered=False,
        )
        object.__setattr__(
            self,
            "configured_vehicle_body_width_mismatch",
            width_mismatch,
        )
        if controller_width is None:
            if (
                plant_width is not None
                or width_source is not None
                or width_mismatch is not None
            ):
                raise ValueError(
                    "body-width diagnostics must all be None when the controller "
                    "does not own a width belief"
                )
        else:
            if width_source not in valid_sources:
                raise ValueError(
                    "vehicle_body_width_source must be 'explicit' or "
                    "'initial_environment_default'"
                )
            if plant_width is None:
                if width_mismatch is not None:
                    raise ValueError(
                        "a body-width mismatch requires a known plant width"
                    )
            else:
                widths_match = math.isclose(
                    controller_width,
                    plant_width,
                    rel_tol=1.0e-12,
                    abs_tol=1.0e-12,
                )
                if widths_match and width_mismatch is not None:
                    raise ValueError(
                        "matching body widths must not report a mismatch"
                    )
                if not widths_match:
                    if width_mismatch != (controller_width, plant_width):
                        raise ValueError(
                            "configured_vehicle_body_width_mismatch must contain "
                            "the controller and plant widths"
                        )

    @property
    def has_model_parameter_mismatch(self) -> bool | None:
        return (
            None
            if self.model_parameter_mismatches is None
            else bool(self.model_parameter_mismatches)
        )

    @property
    def has_configured_steering_bound_mismatch(self) -> bool | None:
        return (
            None
            if self.configured_steering_bound_mismatches is None
            else bool(self.configured_steering_bound_mismatches)
        )

    @property
    def has_configured_vehicle_body_width_mismatch(self) -> bool | None:
        if (
            self.controller_vehicle_body_width_metres is None
            or self.plant_vehicle_body_width_metres is None
        ):
            return None
        return self.configured_vehicle_body_width_mismatch is not None


@dataclass(frozen=True, slots=True)
class MPCActionRequest:
    """Physical and normalized forms of one immutable policy action request."""

    planned_model_control: np.ndarray | None
    requested_steering_angle_radians: float
    normalized_action_before_clipping: np.ndarray
    environment_action: np.ndarray
    drive_command_was_clipped: bool
    steering_command_was_clipped: bool

    def __post_init__(self) -> None:
        planned_control = self.planned_model_control
        if planned_control is not None:
            planned_control = _read_only_vector(
                "planned_model_control",
                planned_control,
                2,
            )
        normalized_before_clipping = _read_only_vector(
            "normalized_action_before_clipping",
            self.normalized_action_before_clipping,
            2,
        )
        environment_action = _read_only_vector(
            "environment_action",
            self.environment_action,
            2,
        )
        if environment_action.dtype.kind != "f":
            raise TypeError("environment_action must have a real floating dtype")
        clipping_field_names = (
            "drive_command_was_clipped",
            "steering_command_was_clipped",
        )
        for field_name in clipping_field_names:
            if not isinstance(getattr(self, field_name), bool):
                raise TypeError(f"{field_name} must be a bool")

        expected_environment_action = _expected_environment_action(
            normalized_before_clipping,
            environment_action.dtype,
        )
        if not np.array_equal(environment_action, expected_environment_action):
            raise ValueError(
                "environment_action must equal the normalized interface clip "
                "at its stored dtype"
            )
        expected_clipping_flags = _expected_action_clipping_flags(
            normalized_before_clipping
        )
        for field_name, expected_flag in zip(
            clipping_field_names,
            expected_clipping_flags,
            strict=True,
        ):
            if getattr(self, field_name) != expected_flag:
                raise ValueError(
                    f"{field_name} must match normalized interface clipping"
                )

        object.__setattr__(self, "planned_model_control", planned_control)
        object.__setattr__(
            self,
            "requested_steering_angle_radians",
            _finite_float(
                "requested_steering_angle_radians",
                self.requested_steering_angle_radians,
            ),
        )
        object.__setattr__(
            self,
            "normalized_action_before_clipping",
            normalized_before_clipping,
        )
        object.__setattr__(self, "environment_action", environment_action)


@dataclass(frozen=True, slots=True)
class MPCRoadHorizonContext:
    """Immutable road-preview belief and its installed MPC horizon schedules."""

    source_distances_metres: np.ndarray
    source_validity: np.ndarray
    source_target_line_curvatures_per_metre: np.ndarray | None
    source_recommended_speeds_mps: np.ndarray | None
    source_speed_limits_mps: np.ndarray | None
    source_right_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    source_left_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    target_selector_provenance: str
    target_curvature_provenance: str
    lane_selection_provenance: str | None
    lane_index: int | None
    progress_schedule_metres: np.ndarray
    road_preview_query_distances_metres: np.ndarray
    interpolated_target_line_curvatures_per_metre: np.ndarray | None
    interpolated_recommended_speeds_mps: np.ndarray | None
    interpolated_speed_limits_mps: np.ndarray | None
    interpolated_right_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    interpolated_left_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    effective_speed_references_mps: np.ndarray
    recommended_speed_soft_ceiling_mps: np.ndarray | None
    speed_limit_soft_ceiling_mps: np.ndarray | None
    curvature_soft_ceiling_mps: np.ndarray | None
    installed_soft_speed_upper_bounds_mps: np.ndarray | None
    installed_soft_lateral_error_lower_bounds_metres: np.ndarray | None
    installed_soft_lateral_error_upper_bounds_metres: np.ndarray | None
    direct_steering_angle_feedforward_radians: np.ndarray | None
    direct_steering_angle_feedforward_exceeds_bound: np.ndarray | None
    steering_angle_state_feedforward_radians: np.ndarray | None
    steering_angle_state_feedforward_exceeds_bound: np.ndarray | None
    steering_rate_control_feedforward_radians_per_second: np.ndarray | None
    steering_rate_control_feedforward_exceeds_bound: np.ndarray | None
    extension_mode: MPCRoadPreviewExtensionMode
    extension_mask: np.ndarray
    final_valid_preview_distance_metres: float
    first_extended_distance_metres: float | None
    maximum_requested_distance_metres: float
    use_speed_preview: bool
    use_curvature_preview: bool
    use_lane_bound_constraints: bool

    def __post_init__(self) -> None:
        for field_name in (
            "use_speed_preview",
            "use_curvature_preview",
            "use_lane_bound_constraints",
        ):
            if not isinstance(getattr(self, field_name), bool):
                raise TypeError(f"{field_name} must be a bool")
        if not any(
            (
                self.use_speed_preview,
                self.use_curvature_preview,
                self.use_lane_bound_constraints,
            )
        ):
            raise ValueError(
                "road horizon context requires at least one enabled road feature"
            )

        source_distances = _read_only_distance_schedule(
            "source_distances_metres",
            self.source_distances_metres,
            strictly_increasing=True,
        )
        source_count = source_distances.shape[0]
        source_validity = _read_only_boolean_vector(
            "source_validity",
            self.source_validity,
            source_count,
        )
        valid_count = int(np.count_nonzero(source_validity))
        expected_validity = np.arange(source_count) < valid_count
        if valid_count == 0 or not np.array_equal(source_validity, expected_validity):
            raise ValueError(
                "source_validity must contain a nonempty valid prefix"
            )
        object.__setattr__(self, "source_distances_metres", source_distances)
        object.__setattr__(self, "source_validity", source_validity)

        def store_source_channel(field_name: str, enabled: bool) -> None:
            value = getattr(self, field_name)
            if not enabled:
                if value is not None:
                    raise ValueError(f"{field_name} must be None when disabled")
                return
            if value is None:
                raise ValueError(f"{field_name} is required when enabled")
            object.__setattr__(
                self,
                field_name,
                _read_only_source_vector(
                    field_name,
                    value,
                    source_count,
                    source_validity,
                ),
            )

        store_source_channel(
            "source_target_line_curvatures_per_metre",
            self.use_curvature_preview,
        )
        for field_name in (
            "source_recommended_speeds_mps",
            "source_speed_limits_mps",
        ):
            store_source_channel(field_name, self.use_speed_preview)
            values = getattr(self, field_name)
            if values is not None and np.any(values[source_validity] < 0.0):
                raise ValueError(f"{field_name} must be nonnegative at valid rows")
        for field_name in (
            "source_right_lane_bound_offsets_from_target_line_metres",
            "source_left_lane_bound_offsets_from_target_line_metres",
        ):
            store_source_channel(field_name, self.use_lane_bound_constraints)
        if self.use_lane_bound_constraints:
            source_right = (
                self.source_right_lane_bound_offsets_from_target_line_metres
            )
            source_left = (
                self.source_left_lane_bound_offsets_from_target_line_metres
            )
            assert source_right is not None and source_left is not None
            if np.any(source_right[source_validity] > source_left[source_validity]):
                raise ValueError(
                    "source right lane bounds must not exceed source left bounds"
                )

        target_selector = _validated_mpc_provenance(
            "target_selector_provenance",
            self.target_selector_provenance,
            _MPC_TARGET_SELECTOR_PROVENANCE,
        )
        target_curvature = _validated_mpc_provenance(
            "target_curvature_provenance",
            self.target_curvature_provenance,
            _MPC_TARGET_CURVATURE_PROVENANCE,
        )
        expected_target_curvature = {
            "reference_line": "exact_reference_line",
            "fixed_offset": "exact_parallel_curve",
            "target_lane_index": "tapered_target_approximation",
            "target_lane_units": "tapered_target_approximation",
        }[target_selector]
        if target_curvature != expected_target_curvature:
            raise ValueError(
                "target_curvature_provenance does not match "
                "target_selector_provenance"
            )
        object.__setattr__(self, "target_selector_provenance", target_selector)
        object.__setattr__(self, "target_curvature_provenance", target_curvature)
        if self.use_lane_bound_constraints:
            lane_provenance = _validated_mpc_provenance(
                "lane_selection_provenance",
                self.lane_selection_provenance,
                _MPC_LANE_SELECTION_PROVENANCE,
            )
            if (
                lane_provenance == "target_lane_index"
                and target_selector != "target_lane_index"
            ):
                raise ValueError(
                    "target_lane_index lane provenance requires the matching "
                    "target selector"
                )
            lane_index = self.lane_index
            if lane_provenance == "reference_line_lane_center":
                if lane_index is not None:
                    raise ValueError(
                        "reference_line_lane_center requires lane_index=None"
                    )
            else:
                if isinstance(lane_index, bool) or not isinstance(
                    lane_index,
                    Integral,
                ):
                    raise TypeError(
                        f"{lane_provenance} requires a nonzero integer lane_index"
                    )
                lane_index = int(lane_index)
                if lane_index == 0:
                    raise ValueError("lane_index 0 is not a physical lane")
            object.__setattr__(
                self,
                "lane_selection_provenance",
                lane_provenance,
            )
            object.__setattr__(self, "lane_index", lane_index)
        elif self.lane_selection_provenance is not None or self.lane_index is not None:
            raise ValueError(
                "lane provenance and index must be None when lane constraints "
                "are disabled"
            )

        progress_schedule = _read_only_distance_schedule(
            "progress_schedule_metres",
            self.progress_schedule_metres,
        )
        if progress_schedule.shape[0] < 2:
            raise ValueError("progress_schedule_metres must contain at least two rows")
        horizon_steps = progress_schedule.shape[0] - 1
        query_distances = _read_only_distance_schedule(
            "road_preview_query_distances_metres",
            self.road_preview_query_distances_metres,
            horizon_steps + 1,
        )
        object.__setattr__(self, "progress_schedule_metres", progress_schedule)
        object.__setattr__(
            self,
            "road_preview_query_distances_metres",
            query_distances,
        )

        def store_interpolated_channel(field_name: str, enabled: bool) -> None:
            value = getattr(self, field_name)
            if not enabled:
                if value is not None:
                    raise ValueError(f"{field_name} must be None when disabled")
                return
            if value is None:
                raise ValueError(f"{field_name} is required when enabled")
            object.__setattr__(
                self,
                field_name,
                _read_only_vector(field_name, value, horizon_steps + 1),
            )

        store_interpolated_channel(
            "interpolated_target_line_curvatures_per_metre",
            self.use_curvature_preview,
        )
        for field_name in (
            "interpolated_recommended_speeds_mps",
            "interpolated_speed_limits_mps",
        ):
            store_interpolated_channel(field_name, self.use_speed_preview)
            values = getattr(self, field_name)
            if values is not None and np.any(values < 0.0):
                raise ValueError(f"{field_name} must be nonnegative")
        for field_name in (
            "interpolated_right_lane_bound_offsets_from_target_line_metres",
            "interpolated_left_lane_bound_offsets_from_target_line_metres",
        ):
            store_interpolated_channel(field_name, self.use_lane_bound_constraints)
        if self.use_lane_bound_constraints:
            interpolated_right = (
                self.interpolated_right_lane_bound_offsets_from_target_line_metres
            )
            interpolated_left = (
                self.interpolated_left_lane_bound_offsets_from_target_line_metres
            )
            assert interpolated_right is not None and interpolated_left is not None
            if np.any(interpolated_right > interpolated_left):
                raise ValueError(
                    "interpolated right lane bounds must not exceed left bounds"
                )
        effective_speed_references = _read_only_vector(
            "effective_speed_references_mps",
            self.effective_speed_references_mps,
            horizon_steps + 1,
        )
        if np.any(effective_speed_references < 0.0):
            raise ValueError("effective_speed_references_mps must be nonnegative")
        object.__setattr__(
            self,
            "effective_speed_references_mps",
            effective_speed_references,
        )

        def store_optional_horizon_vector(
            field_name: str,
            *,
            enabled: bool = True,
        ) -> None:
            value = getattr(self, field_name)
            if not enabled:
                if value is not None:
                    raise ValueError(f"{field_name} must be None when disabled")
                return
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _read_only_vector_allowing_infinity(
                        field_name,
                        value,
                        horizon_steps,
                    ),
                )

        store_optional_horizon_vector(
            "recommended_speed_soft_ceiling_mps",
            enabled=self.use_speed_preview,
        )
        store_optional_horizon_vector(
            "speed_limit_soft_ceiling_mps",
            enabled=self.use_speed_preview,
        )
        store_optional_horizon_vector(
            "curvature_soft_ceiling_mps",
            enabled=self.use_curvature_preview,
        )
        store_optional_horizon_vector("installed_soft_speed_upper_bounds_mps")
        for field_name in (
            "recommended_speed_soft_ceiling_mps",
            "speed_limit_soft_ceiling_mps",
            "curvature_soft_ceiling_mps",
            "installed_soft_speed_upper_bounds_mps",
        ):
            values = getattr(self, field_name)
            if values is not None and np.any(values < 0.0):
                raise ValueError(f"{field_name} must be nonnegative")

        lane_bound_fields = (
            "installed_soft_lateral_error_lower_bounds_metres",
            "installed_soft_lateral_error_upper_bounds_metres",
        )
        for field_name in lane_bound_fields:
            value = getattr(self, field_name)
            if self.use_lane_bound_constraints:
                if value is None:
                    raise ValueError(f"{field_name} is required when enabled")
                object.__setattr__(
                    self,
                    field_name,
                    _read_only_vector_allowing_infinity(
                        field_name,
                        value,
                        horizon_steps,
                    ),
                )
            elif value is not None:
                raise ValueError(f"{field_name} must be None when disabled")
        if self.use_lane_bound_constraints:
            lower = self.installed_soft_lateral_error_lower_bounds_metres
            upper = self.installed_soft_lateral_error_upper_bounds_metres
            assert lower is not None and upper is not None
            if np.any(lower > upper):
                raise ValueError(
                    "installed lateral-error lower bounds must not exceed upper bounds"
                )

        direct_fields = (
            "direct_steering_angle_feedforward_radians",
            "direct_steering_angle_feedforward_exceeds_bound",
        )
        rate_fields = (
            "steering_angle_state_feedforward_radians",
            "steering_angle_state_feedforward_exceeds_bound",
            "steering_rate_control_feedforward_radians_per_second",
            "steering_rate_control_feedforward_exceeds_bound",
        )
        direct_present = tuple(getattr(self, name) is not None for name in direct_fields)
        rate_present = tuple(getattr(self, name) is not None for name in rate_fields)
        if not self.use_curvature_preview:
            if any(direct_present) or any(rate_present):
                raise ValueError("feedforward fields must be None when curvature is disabled")
        else:
            complete_direct = all(direct_present)
            complete_rate = all(rate_present)
            if complete_direct == complete_rate or (
                any(direct_present) and not complete_direct
            ) or (any(rate_present) and not complete_rate):
                raise ValueError(
                    "curvature preview requires exactly one complete feedforward family"
                )
            if complete_direct:
                object.__setattr__(
                    self,
                    direct_fields[0],
                    _read_only_vector(direct_fields[0], getattr(self, direct_fields[0]), horizon_steps),
                )
                object.__setattr__(
                    self,
                    direct_fields[1],
                    _read_only_boolean_vector(
                        direct_fields[1],
                        getattr(self, direct_fields[1]),
                        horizon_steps,
                    ),
                )
            else:
                rate_lengths = (horizon_steps + 1, horizon_steps + 1, horizon_steps, horizon_steps)
                for index, (field_name, expected_length) in enumerate(
                    zip(rate_fields, rate_lengths, strict=True)
                ):
                    reader = (
                        _read_only_boolean_vector if index in (1, 3) else _read_only_vector
                    )
                    object.__setattr__(
                        self,
                        field_name,
                        reader(field_name, getattr(self, field_name), expected_length),
                    )

        extension_mode = self.extension_mode
        if isinstance(extension_mode, str) and not isinstance(
            extension_mode,
            MPCRoadPreviewExtensionMode,
        ):
            try:
                extension_mode = MPCRoadPreviewExtensionMode(extension_mode)
            except ValueError as error:
                raise ValueError("invalid road-preview extension mode") from error
            object.__setattr__(self, "extension_mode", extension_mode)
        elif not isinstance(extension_mode, MPCRoadPreviewExtensionMode):
            raise TypeError(
                "extension_mode must be an MPCRoadPreviewExtensionMode or string value"
            )
        extension_mask = _read_only_boolean_vector(
            "extension_mask",
            self.extension_mask,
            horizon_steps + 1,
        )
        final_valid_distance = _nonnegative_finite_float(
            "final_valid_preview_distance_metres",
            self.final_valid_preview_distance_metres,
        )
        expected_final_valid_distance = float(source_distances[valid_count - 1])
        if final_valid_distance != expected_final_valid_distance:
            raise ValueError(
                "final_valid_preview_distance_metres must identify the last valid source row"
            )
        expected_extension_mask = query_distances > final_valid_distance
        if not np.array_equal(extension_mask, expected_extension_mask):
            raise ValueError(
                "extension_mask must identify queries beyond the final valid source distance"
            )
        maximum_requested_distance = _nonnegative_finite_float(
            "maximum_requested_distance_metres",
            self.maximum_requested_distance_metres,
        )
        if maximum_requested_distance != float(query_distances[-1]):
            raise ValueError(
                "maximum_requested_distance_metres must equal the final query distance"
            )
        first_extended_distance = self.first_extended_distance_metres
        if np.any(extension_mask):
            expected_first_extended = float(query_distances[extension_mask][0])
            if first_extended_distance is None:
                raise ValueError(
                    "first_extended_distance_metres is required when extension occurs"
                )
            first_extended_distance = _nonnegative_finite_float(
                "first_extended_distance_metres",
                first_extended_distance,
            )
            if first_extended_distance != expected_first_extended:
                raise ValueError(
                    "first_extended_distance_metres must identify the first extended query"
                )
            if extension_mode is MPCRoadPreviewExtensionMode.ERROR:
                raise ValueError("ERROR extension mode cannot contain extended queries")
        elif first_extended_distance is not None:
            raise ValueError(
                "first_extended_distance_metres must be None when no query is extended"
            )
        object.__setattr__(self, "extension_mask", extension_mask)
        object.__setattr__(
            self,
            "final_valid_preview_distance_metres",
            final_valid_distance,
        )
        object.__setattr__(
            self,
            "first_extended_distance_metres",
            first_extended_distance,
        )
        object.__setattr__(
            self,
            "maximum_requested_distance_metres",
            maximum_requested_distance,
        )


@dataclass(frozen=True, slots=True)
class MPCPolicyResult:
    """Immutable policy outcome and the schedule used to formulate its solve.

    ``progress_schedule_metres`` is built from the shifted previous prediction,
    or from the zero-control bootstrap schedule on the first call.  It is not
    the progress output of the current solve.
    """

    solve_result: MPCSolveResult | None
    failure: MPCPolicyFailure | None
    action_request: MPCActionRequest | None
    fallback_mode: MPCFallbackMode | None
    fallback_action_used: bool
    initial_state: np.ndarray
    progress_schedule_metres: np.ndarray
    reference_speeds_mps: np.ndarray | None
    soft_speed_upper_bounds_mps: np.ndarray | None
    linearization_speeds_mps: np.ndarray | None
    reference_transition_index: int | None
    road_horizon_context: MPCRoadHorizonContext | None
    control_step_index: int
    terminated: bool
    truncated: bool
    road_horizon_time_seconds: float
    model_schedule_time_seconds: float
    postprocessing_time_seconds: float
    total_time_seconds: float

    def __post_init__(self) -> None:
        solve_result = self.solve_result
        failure = self.failure
        if solve_result is not None and not isinstance(solve_result, MPCSolveResult):
            raise TypeError("solve_result must be an MPCSolveResult or None")
        if failure is not None and not isinstance(failure, MPCPolicyFailure):
            raise TypeError("failure must be an MPCPolicyFailure or None")
        if (solve_result is None) == (failure is None):
            raise ValueError("exactly one of solve_result and failure must be present")

        progress_schedule = _read_only_vector(
            "progress_schedule_metres",
            self.progress_schedule_metres,
        )
        if progress_schedule.shape[0] < 2:
            raise ValueError(
                "progress_schedule_metres must contain at least two rows"
            )
        horizon_steps = progress_schedule.shape[0] - 1

        initial_state = _read_only_vector("initial_state", self.initial_state)
        if initial_state.shape[0] <= 0:
            raise ValueError("initial_state must not be empty")
        prediction = None if solve_result is None else solve_result.prediction
        if prediction is not None:
            if prediction.controls.shape[0] != horizon_steps:
                raise ValueError(
                    "the solver prediction horizon must match "
                    "progress_schedule_metres"
                )
            expected_state_size = prediction.states.shape[1]
            if initial_state.shape != (expected_state_size,):
                raise ValueError(
                    f"initial_state must have shape ({expected_state_size},)"
                )

        reference_speeds = self.reference_speeds_mps
        if reference_speeds is not None:
            reference_speeds = _read_only_vector(
                "reference_speeds_mps",
                reference_speeds,
                horizon_steps + 1,
            )
        linearization_speeds = self.linearization_speeds_mps
        if linearization_speeds is not None:
            linearization_speeds = _read_only_vector(
                "linearization_speeds_mps",
                linearization_speeds,
                horizon_steps,
            )
        if solve_result is not None and (
            reference_speeds is None or linearization_speeds is None
        ):
            raise ValueError(
                "every solver outcome requires complete reference and "
                "linearization schedules"
            )
        if self.soft_speed_upper_bounds_mps is None:
            soft_speed_bounds = None
        else:
            soft_speed_bounds = _read_only_vector_allowing_infinity(
                "soft_speed_upper_bounds_mps",
                self.soft_speed_upper_bounds_mps,
                horizon_steps,
            )
            if np.any(soft_speed_bounds < 0.0):
                raise ValueError(
                    "soft_speed_upper_bounds_mps must be nonnegative or +inf"
                )
        object.__setattr__(self, "initial_state", initial_state)
        object.__setattr__(self, "progress_schedule_metres", progress_schedule)
        object.__setattr__(self, "reference_speeds_mps", reference_speeds)
        object.__setattr__(
            self,
            "soft_speed_upper_bounds_mps",
            soft_speed_bounds,
        )
        object.__setattr__(
            self,
            "linearization_speeds_mps",
            linearization_speeds,
        )

        action_request = self.action_request
        if action_request is not None and not isinstance(
            action_request,
            MPCActionRequest,
        ):
            raise TypeError("action_request must be an MPCActionRequest or None")
        if not isinstance(self.fallback_action_used, bool):
            raise TypeError("fallback_action_used must be a bool")
        fallback_mode = self.fallback_mode
        if fallback_mode is not None and isinstance(fallback_mode, str) and not isinstance(
            fallback_mode, MPCFallbackMode
        ):
            try:
                fallback_mode = MPCFallbackMode(fallback_mode)
            except ValueError as error:
                raise ValueError("invalid fallback_mode") from error
            object.__setattr__(self, "fallback_mode", fallback_mode)
        elif fallback_mode is not None and not isinstance(
            fallback_mode, MPCFallbackMode
        ):
            raise TypeError("fallback_mode must be an MPCFallbackMode or None")
        if self.solve_usable:
            if fallback_mode is not None:
                raise ValueError("fallback_mode must be None for a usable solve")
            if self.fallback_action_used:
                raise ValueError(
                    "fallback_action_used must be false for a usable solve"
                )
            if action_request is None:
                raise ValueError("a usable solve requires an action_request")
            if action_request.planned_model_control is None:
                raise ValueError(
                    "a usable solve requires a planned_model_control"
                )
        else:
            if fallback_mode is None:
                raise ValueError("an unusable solve requires a fallback_mode")
            if fallback_mode is MPCFallbackMode.RAISE:
                if self.fallback_action_used:
                    raise ValueError(
                        "raise fallback must not report a fallback action"
                    )
                if action_request is not None:
                    raise ValueError("raise fallback requires action_request=None")
            else:
                if not self.fallback_action_used:
                    raise ValueError(
                        "a returned fallback requires fallback_action_used=True"
                    )
                if action_request is None:
                    raise ValueError(
                        "a returned fallback requires an action_request"
                    )
                if action_request.planned_model_control is not None:
                    raise ValueError(
                        "a fallback action must not contain a planned_model_control"
                    )

        transition_index = self.reference_transition_index
        if transition_index is not None:
            if reference_speeds is None:
                raise ValueError(
                    "reference_transition_index requires reference_speeds_mps"
                )
            if isinstance(transition_index, bool) or not isinstance(
                transition_index, Integral
            ):
                raise TypeError("reference_transition_index must be an integer or None")
            transition_index = int(transition_index)
            if not 0 <= transition_index <= horizon_steps:
                raise ValueError(
                    "reference_transition_index must lie inside the prediction horizon"
                )
            object.__setattr__(
                self,
                "reference_transition_index",
                transition_index,
            )

        road_context = self.road_horizon_context
        if road_context is not None:
            if not isinstance(road_context, MPCRoadHorizonContext):
                raise TypeError(
                    "road_horizon_context must be an MPCRoadHorizonContext or None"
                )
            if not np.array_equal(
                road_context.progress_schedule_metres,
                progress_schedule,
            ):
                raise ValueError(
                    "road_horizon_context must use the result progress schedule"
                )
            if reference_speeds is None or not np.array_equal(
                reference_speeds,
                road_context.effective_speed_references_mps,
            ):
                raise ValueError(
                    "reference_speeds_mps must match the road horizon context"
                )
            context_soft_bounds = (
                road_context.installed_soft_speed_upper_bounds_mps
            )
            if (soft_speed_bounds is None) != (context_soft_bounds is None):
                raise ValueError(
                    "soft_speed_upper_bounds_mps availability must match the "
                    "road horizon context"
                )
            if soft_speed_bounds is not None and not np.array_equal(
                soft_speed_bounds,
                context_soft_bounds,
            ):
                raise ValueError(
                    "soft_speed_upper_bounds_mps must match the road horizon context"
                )
            if (
                road_context.use_speed_preview
                and transition_index is not None
            ):
                raise ValueError(
                    "reference_transition_index must be None for speed preview"
                )

        if isinstance(self.control_step_index, bool) or not isinstance(
            self.control_step_index, Integral
        ):
            raise TypeError("control_step_index must be an integer")
        control_step_index = int(self.control_step_index)
        if control_step_index < 0:
            raise ValueError("control_step_index must be nonnegative")
        object.__setattr__(self, "control_step_index", control_step_index)
        for field_name in ("terminated", "truncated"):
            if not isinstance(getattr(self, field_name), bool):
                raise TypeError(f"{field_name} must be a bool")
        for field_name in (
            "road_horizon_time_seconds",
            "model_schedule_time_seconds",
            "postprocessing_time_seconds",
            "total_time_seconds",
        ):
            object.__setattr__(
                self,
                field_name,
                _nonnegative_finite_float(field_name, getattr(self, field_name)),
            )

    @property
    def solve_usable(self) -> bool:
        """Whether an actual solver call produced an accepted prediction."""

        return self.solve_result is not None and self.solve_result.usable

    @property
    def solve_status(self) -> str | None:
        """Return the exact solver status, or ``None`` before a solver call."""

        return None if self.solve_result is None else self.solve_result.status

    @property
    def environment_action(self) -> np.ndarray | None:
        """Return a defensive action copy, or ``None`` for raise mode."""

        if self.action_request is None:
            return None
        return self.action_request.environment_action.copy()
