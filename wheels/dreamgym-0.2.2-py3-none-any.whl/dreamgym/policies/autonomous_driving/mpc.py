"""Straight-road model-predictive policies for autonomous driving."""

from __future__ import annotations

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_adapter import MPCObservation
from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingDirectSteeringMPCConfig,
    AutonomousDrivingSteeringRateMPCConfig,
)
from dreamgym.policies.autonomous_driving._mpc_formulations import (
    build_direct_steering_model,
    build_steering_rate_model,
)
from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCRoadHorizonContext,
)
from dreamgym.policies.mpc import LinearQuadraticMPCProblem

from ._mpc_policy_base import (
    _AutonomousDrivingMPCPolicyBase,
    _MPCModelSchedule,
    _guard_planned_controller_value,
)


class AutonomousDrivingDirectSteeringMPCPolicy(_AutonomousDrivingMPCPolicyBase):
    """Three-state straight-road MPC with physical steering-angle control."""

    _mpc_formulation_key = "direct_steering"
    n_state = 3

    def __init__(self, config: AutonomousDrivingDirectSteeringMPCConfig) -> None:
        if type(config) is not AutonomousDrivingDirectSteeringMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingDirectSteeringMPCConfig"
            )
        self._initialize(config)

    @classmethod
    def from_env(
        cls,
        env,
        config: AutonomousDrivingDirectSteeringMPCConfig | None = None,
    ) -> "AutonomousDrivingDirectSteeringMPCPolicy":
        if config is None:
            config = AutonomousDrivingDirectSteeringMPCConfig()
        if type(config) is not AutonomousDrivingDirectSteeringMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingDirectSteeringMPCConfig or None"
            )
        return cls._from_env(env, config)

    def _initial_state(self, observation: MPCObservation) -> np.ndarray:
        return np.array(
            [
                observation.vx_mps,
                observation.lateral_error_metres,
                observation.heading_error_radians,
            ],
            dtype=np.float64,
        )

    def _build_model_schedule(
        self,
        *,
        linearization_speeds: np.ndarray,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> _MPCModelSchedule:
        del road_horizon_context
        models = tuple(
            build_direct_steering_model(self.config.model, speed)
            for speed in linearization_speeds
        )
        return _MPCModelSchedule(
            state_matrices=tuple(
                state_matrix for state_matrix, _ in models
            ),
            control_matrices=tuple(
                control_matrix for _, control_matrix in models
            ),
            affine_offsets=None,
        )

    def _build_problem(
        self,
        *,
        initial_state: np.ndarray,
        state_matrices: tuple[np.ndarray, ...],
        control_matrices: tuple[np.ndarray, ...],
        affine_offsets: tuple[np.ndarray, ...] | None,
        reference_speeds: np.ndarray,
        soft_speed_upper_bounds: np.ndarray | None,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> LinearQuadraticMPCProblem:
        del road_horizon_context
        objective = self.config.objective
        constraints = self.config.constraints
        horizon = self.config.horizon_steps

        state_cost = np.diag(
            [
                objective.speed_state_quadratic_weight,
                objective.lateral_error_state_quadratic_weight,
                objective.heading_error_state_quadratic_weight,
            ]
        ).astype(np.float64)
        control_cost = np.diag(
            [
                objective.normalized_drive_command_control_quadratic_weight,
                objective.steering_angle_control_quadratic_weight,
            ]
        ).astype(np.float64)
        state_linear_cost = np.array(
            [
                objective.speed_state_linear_weight,
                objective.lateral_error_state_linear_weight,
                objective.heading_error_state_linear_weight,
            ],
            dtype=np.float64,
        )
        control_linear_cost = np.array(
            [
                objective.normalized_drive_command_control_linear_weight,
                objective.steering_angle_control_linear_weight,
            ],
            dtype=np.float64,
        )
        state_references = tuple(
            np.array([reference_speeds[stage], 0.0, 0.0], dtype=np.float64)
            for stage in range(horizon)
        )
        terminal_reference = np.array(
            [reference_speeds[horizon], 0.0, 0.0], dtype=np.float64
        )

        negative_infinity = -np.inf
        positive_infinity = np.inf
        soft_lower = np.array(
            [
                negative_infinity
                if constraints.soft_speed_state_lower_mps is None
                else constraints.soft_speed_state_lower_mps,
                negative_infinity
                if constraints.soft_lateral_error_state_lower_metres is None
                else constraints.soft_lateral_error_state_lower_metres,
                negative_infinity
                if constraints.soft_heading_error_state_lower_radians is None
                else constraints.soft_heading_error_state_lower_radians,
            ],
            dtype=np.float64,
        )
        soft_upper = tuple(
            np.array(
                [
                    positive_infinity
                    if soft_speed_upper_bounds is None
                    else soft_speed_upper_bounds[stage],
                    positive_infinity
                    if constraints.soft_lateral_error_state_upper_metres is None
                    else constraints.soft_lateral_error_state_upper_metres,
                    positive_infinity
                    if constraints.soft_heading_error_state_upper_radians is None
                    else constraints.soft_heading_error_state_upper_radians,
                ],
                dtype=np.float64,
            )
            for stage in range(horizon)
        )
        linear_penalty = np.full(
            self.n_state,
            constraints.soft_state_linear_penalty,
            dtype=np.float64,
        )
        quadratic_penalty = np.full(
            self.n_state,
            constraints.soft_state_quadratic_penalty,
            dtype=np.float64,
        )
        return LinearQuadraticMPCProblem(
            horizon_steps=horizon,
            state_matrices=state_matrices,
            control_matrices=control_matrices,
            initial_state=initial_state,
            affine_offsets=affine_offsets,
            state_cost_matrices=state_cost,
            control_cost_matrices=control_cost,
            state_linear_costs=state_linear_cost,
            control_linear_costs=control_linear_cost,
            terminal_state_cost_matrix=state_cost,
            terminal_state_linear_cost=state_linear_cost,
            state_references=state_references,
            terminal_state_reference=terminal_reference,
            control_references=np.zeros(self.n_control, dtype=np.float64),
            control_lower_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_lower,
                    constraints.steering_angle_control_lower_radians,
                ],
                dtype=np.float64,
            ),
            control_upper_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_upper,
                    constraints.steering_angle_control_upper_radians,
                ],
                dtype=np.float64,
            ),
            soft_state_lower_bounds=soft_lower,
            soft_state_upper_bounds=soft_upper,
            soft_state_linear_penalties=linear_penalty,
            soft_state_quadratic_penalties=quadratic_penalty,
        )

    def _requested_steering_angle_from_first_control(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
    ) -> float:
        del observation
        return float(first_control[1])

    def _controller_validated_steering_angle(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
        requested_steering_angle_radians: float,
    ) -> float:
        del observation, requested_steering_angle_radians
        constraints = self.config.constraints
        lower = constraints.steering_angle_control_lower_radians
        upper = constraints.steering_angle_control_upper_radians
        assert lower is not None and upper is not None
        return _guard_planned_controller_value(
            float(first_control[1]),
            lower=lower,
            upper=upper,
            eps_abs=self.config.solver.absolute_tolerance,
            eps_rel=self.config.solver.relative_tolerance,
            quantity_name="steering-angle control",
        )


class AutonomousDrivingSteeringRateMPCPolicy(_AutonomousDrivingMPCPolicyBase):
    """Four-state straight-road MPC with physical steering-rate control."""

    _mpc_formulation_key = "steering_rate"
    n_state = 4

    def __init__(self, config: AutonomousDrivingSteeringRateMPCConfig) -> None:
        if type(config) is not AutonomousDrivingSteeringRateMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingSteeringRateMPCConfig"
            )
        self._initialize(config)

    @classmethod
    def from_env(
        cls,
        env,
        config: AutonomousDrivingSteeringRateMPCConfig | None = None,
    ) -> "AutonomousDrivingSteeringRateMPCPolicy":
        if config is None:
            config = AutonomousDrivingSteeringRateMPCConfig()
        if type(config) is not AutonomousDrivingSteeringRateMPCConfig:
            raise TypeError(
                "config must be exactly an "
                "AutonomousDrivingSteeringRateMPCConfig or None"
            )
        return cls._from_env(env, config)

    def _initial_state(self, observation: MPCObservation) -> np.ndarray:
        return np.array(
            [
                observation.vx_mps,
                observation.lateral_error_metres,
                observation.heading_error_radians,
                observation.steering_angle_radians,
            ],
            dtype=np.float64,
        )

    def _build_model_schedule(
        self,
        *,
        linearization_speeds: np.ndarray,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> _MPCModelSchedule:
        del road_horizon_context
        models = tuple(
            build_steering_rate_model(self.config.model, speed)
            for speed in linearization_speeds
        )
        return _MPCModelSchedule(
            state_matrices=tuple(
                state_matrix for state_matrix, _ in models
            ),
            control_matrices=tuple(
                control_matrix for _, control_matrix in models
            ),
            affine_offsets=None,
        )

    def _build_problem(
        self,
        *,
        initial_state: np.ndarray,
        state_matrices: tuple[np.ndarray, ...],
        control_matrices: tuple[np.ndarray, ...],
        affine_offsets: tuple[np.ndarray, ...] | None,
        reference_speeds: np.ndarray,
        soft_speed_upper_bounds: np.ndarray | None,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> LinearQuadraticMPCProblem:
        del road_horizon_context
        objective = self.config.objective
        constraints = self.config.constraints
        horizon = self.config.horizon_steps

        state_cost = np.diag(
            [
                objective.speed_state_quadratic_weight,
                objective.lateral_error_state_quadratic_weight,
                objective.heading_error_state_quadratic_weight,
                objective.steering_angle_state_quadratic_weight,
            ]
        ).astype(np.float64)
        control_cost = np.diag(
            [
                objective.normalized_drive_command_control_quadratic_weight,
                objective.steering_rate_control_quadratic_weight,
            ]
        ).astype(np.float64)
        state_linear_cost = np.array(
            [
                objective.speed_state_linear_weight,
                objective.lateral_error_state_linear_weight,
                objective.heading_error_state_linear_weight,
                objective.steering_angle_state_linear_weight,
            ],
            dtype=np.float64,
        )
        control_linear_cost = np.array(
            [
                objective.normalized_drive_command_control_linear_weight,
                objective.steering_rate_control_linear_weight,
            ],
            dtype=np.float64,
        )
        state_references = tuple(
            np.array(
                [reference_speeds[stage], 0.0, 0.0, 0.0],
                dtype=np.float64,
            )
            for stage in range(horizon)
        )
        terminal_reference = np.array(
            [reference_speeds[horizon], 0.0, 0.0, 0.0],
            dtype=np.float64,
        )

        soft_lower = np.array(
            [
                -np.inf
                if constraints.soft_speed_state_lower_mps is None
                else constraints.soft_speed_state_lower_mps,
                -np.inf
                if constraints.soft_lateral_error_state_lower_metres is None
                else constraints.soft_lateral_error_state_lower_metres,
                -np.inf
                if constraints.soft_heading_error_state_lower_radians is None
                else constraints.soft_heading_error_state_lower_radians,
                -np.inf,
            ],
            dtype=np.float64,
        )
        soft_upper = tuple(
            np.array(
                [
                    np.inf
                    if soft_speed_upper_bounds is None
                    else soft_speed_upper_bounds[stage],
                    np.inf
                    if constraints.soft_lateral_error_state_upper_metres is None
                    else constraints.soft_lateral_error_state_upper_metres,
                    np.inf
                    if constraints.soft_heading_error_state_upper_radians is None
                    else constraints.soft_heading_error_state_upper_radians,
                    np.inf,
                ],
                dtype=np.float64,
            )
            for stage in range(horizon)
        )
        linear_penalty = np.full(
            self.n_state,
            constraints.soft_state_linear_penalty,
            dtype=np.float64,
        )
        quadratic_penalty = np.full(
            self.n_state,
            constraints.soft_state_quadratic_penalty,
            dtype=np.float64,
        )
        if (
            self._applied_drive_command is None
            or self._applied_steering_rate is None
        ):
            previous_control = np.zeros(self.n_control, dtype=np.float64)
        else:
            previous_control = np.array(
                [
                    self._applied_drive_command,
                    self._applied_steering_rate,
                ],
                dtype=np.float64,
            )

        return LinearQuadraticMPCProblem(
            horizon_steps=horizon,
            state_matrices=state_matrices,
            control_matrices=control_matrices,
            initial_state=initial_state,
            affine_offsets=affine_offsets,
            state_cost_matrices=state_cost,
            control_cost_matrices=control_cost,
            state_linear_costs=state_linear_cost,
            control_linear_costs=control_linear_cost,
            terminal_state_cost_matrix=state_cost,
            terminal_state_linear_cost=state_linear_cost,
            state_references=state_references,
            terminal_state_reference=terminal_reference,
            control_references=np.zeros(self.n_control, dtype=np.float64),
            control_lower_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_lower,
                    constraints.steering_rate_control_lower_radians_per_second,
                ],
                dtype=np.float64,
            ),
            control_upper_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_upper,
                    constraints.steering_rate_control_upper_radians_per_second,
                ],
                dtype=np.float64,
            ),
            control_rate_lower_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_change_lower_per_step,
                    -np.inf,
                ],
                dtype=np.float64,
            ),
            control_rate_upper_bounds=np.array(
                [
                    constraints.normalized_drive_command_control_change_upper_per_step,
                    np.inf,
                ],
                dtype=np.float64,
            ),
            previous_control=previous_control,
            state_lower_bounds=np.array(
                [
                    -np.inf,
                    -np.inf,
                    -np.inf,
                    constraints.steering_angle_state_lower_radians,
                ],
                dtype=np.float64,
            ),
            state_upper_bounds=np.array(
                [
                    np.inf,
                    np.inf,
                    np.inf,
                    constraints.steering_angle_state_upper_radians,
                ],
                dtype=np.float64,
            ),
            soft_state_lower_bounds=soft_lower,
            soft_state_upper_bounds=soft_upper,
            soft_state_linear_penalties=linear_penalty,
            soft_state_quadratic_penalties=quadratic_penalty,
        )

    def _requested_steering_angle_from_first_control(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
    ) -> float:
        return float(
            observation.steering_angle_radians
            + self.config.model.control_timestep_seconds * first_control[1]
        )

    def _controller_validated_steering_angle(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
        requested_steering_angle_radians: float,
    ) -> float:
        del requested_steering_angle_radians
        constraints = self.config.constraints
        rate_lower = (
            constraints.steering_rate_control_lower_radians_per_second
        )
        rate_upper = (
            constraints.steering_rate_control_upper_radians_per_second
        )
        angle_lower = constraints.steering_angle_state_lower_radians
        angle_upper = constraints.steering_angle_state_upper_radians
        assert rate_lower is not None and rate_upper is not None
        assert angle_lower is not None and angle_upper is not None
        guarded_rate = _guard_planned_controller_value(
            float(first_control[1]),
            lower=rate_lower,
            upper=rate_upper,
            eps_abs=self.config.solver.absolute_tolerance,
            eps_rel=self.config.solver.relative_tolerance,
            quantity_name="steering-rate control",
        )
        requested_angle = float(
            observation.steering_angle_radians
            + self.config.model.control_timestep_seconds * guarded_rate
        )
        return _guard_planned_controller_value(
            requested_angle,
            lower=angle_lower,
            upper=angle_upper,
            eps_abs=self.config.solver.absolute_tolerance,
            eps_rel=self.config.solver.relative_tolerance,
            quantity_name="steering-angle state",
        )


__all__ = [
    "AutonomousDrivingDirectSteeringMPCPolicy",
    "AutonomousDrivingSteeringRateMPCPolicy",
]
