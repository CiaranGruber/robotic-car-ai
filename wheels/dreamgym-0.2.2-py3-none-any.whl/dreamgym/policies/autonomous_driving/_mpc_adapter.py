"""Environment binding for the autonomous-driving MPC policies.

This module is the boundary between Gymnasium's normalized, possibly scaled
agent interface and the physical quantities used by the MPC formulations.  It
deliberately snapshots interface facts separately from the controller's model
beliefs so model-mismatch experiments remain explicit and supported.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, fields, replace
import math
from numbers import Integral, Real

from gymnasium import spaces
import numpy as np

from dreamgym.policies.autonomous_driving._mpc_control import (
    _MPCControlKind,
    _control_kind_for_config,
)
from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    AutonomousDrivingSteeringRateMPCConfig,
    KinematicBicycleMPCModelConfig,
    MPCEnvironmentConfig,
    MPCFallbackMode,
)


ROAD_PREVIEW_NUMERIC_FIELDS = (
    "road_preview_target_line_curvatures_per_m",
    "road_preview_recommended_speeds_mps",
    "road_preview_speed_limits_mps",
    "road_preview_right_lane_bound_offsets_from_target_line_m",
    "road_preview_left_lane_bound_offsets_from_target_line_m",
)
ROAD_PREVIEW_VALIDITY_FIELD = "road_preview_is_spatially_valid"


@dataclass(frozen=True, slots=True)
class MPCObservation:
    """Agent-visible autonomous-driving observations in physical units."""

    vx_mps: float
    steering_angle_radians: float
    lateral_error_metres: float
    heading_error_radians: float
    recommended_speed_mps: float
    next_recommended_speed_mps: float
    distance_to_next_recommended_speed_metres: float
    speed_limit_mps: float | None


def _detached_read_only_real_vector(name: str, value: object) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, copy=True)
    copied.setflags(write=False)
    return copied


@dataclass(frozen=True, slots=True)
class MPCRoadPreviewObservation:
    """Detached physical-SI road-preview vectors decoded for MPC internals."""

    target_line_curvatures_per_metre: np.ndarray | None
    recommended_speeds_mps: np.ndarray | None
    speed_limits_mps: np.ndarray | None
    right_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    left_lane_bound_offsets_from_target_line_metres: np.ndarray | None
    validity: np.ndarray

    def __post_init__(self) -> None:
        validity = _detached_read_only_real_vector("validity", self.validity)
        expected_shape = validity.shape
        object.__setattr__(self, "validity", validity)
        for field_name in (
            "target_line_curvatures_per_metre",
            "recommended_speeds_mps",
            "speed_limits_mps",
            "right_lane_bound_offsets_from_target_line_metres",
            "left_lane_bound_offsets_from_target_line_metres",
        ):
            value = getattr(self, field_name)
            if value is None:
                continue
            copied = _detached_read_only_real_vector(field_name, value)
            if copied.shape != expected_shape:
                raise ValueError(
                    f"{field_name} must have shape {expected_shape}, got "
                    f"{copied.shape}"
                )
            object.__setattr__(self, field_name, copied)


_MPC_SCALAR_OBSERVATION_FIELDS = frozenset(
    {
        "body_longitudinal_velocity_mps",
        "front_wheel_steering_angle_rad",
        "lateral_error_from_target_line_m",
        "heading_error_from_target_line_rad",
        "recommended_speed_mps",
        "next_recommended_speed_change_value_mps",
        "next_recommended_speed_change_reference_line_distance_m",
        "speed_limit_mps",
    }
)
_MPC_ROAD_PREVIEW_FIELDS = frozenset(
    ROAD_PREVIEW_NUMERIC_FIELDS + (ROAD_PREVIEW_VALIDITY_FIELD,)
)
_MPC_ROAD_PREVIEW_LANE_BOUND_FIELDS = frozenset(
    {
        "road_preview_right_lane_bound_offsets_from_target_line_m",
        "road_preview_left_lane_bound_offsets_from_target_line_m",
    }
)


def _mpc_environment_interfaces_match(
    first: MPCEnvironmentConfig,
    second: MPCEnvironmentConfig,
) -> bool:
    """Compare interface facts while excluding the plant body-width fact."""

    if not isinstance(first, MPCEnvironmentConfig) or not isinstance(
        second,
        MPCEnvironmentConfig,
    ):
        raise TypeError("both values must be MPCEnvironmentConfig instances")
    return all(
        getattr(first, field.name) == getattr(second, field.name)
        for field in fields(MPCEnvironmentConfig)
        if field.name != "vehicle_body_width_metres"
    )


def _unwrapped_environment(env):
    return getattr(env, "unwrapped", env)


def _enabled_internal_controller_names(env: object) -> tuple[str, ...]:
    base_env = _unwrapped_environment(env)
    enabled = []
    if base_env.lane_keeping_enabled:
        enabled.append("lane keeping")
    if base_env.cruise_control_enabled:
        enabled.append("cruise control")
    return tuple(enabled)


def _validate_no_internal_controller_overrides(env: object) -> None:
    enabled = _enabled_internal_controller_names(env)
    if enabled:
        raise ValueError(
            "MPC requires internal lane keeping and cruise control "
            "to be disabled; enabled: " + ", ".join(enabled)
        )


def _finite_float(name: str, value: object, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    if positive and converted <= 0.0:
        raise ValueError(f"{name} must be greater than zero")
    return converted


def _observation_scale(base_env, name: str) -> float:
    compiled = getattr(base_env, "_compiled_observation_by_name", {})
    record = compiled.get(name) if isinstance(compiled, Mapping) else None
    raw_scale = 1.0 if record is None else record.scaling_factor
    if raw_scale is None:
        raw_scale = 1.0
    try:
        return _finite_float(f"observation scaling for {name}", raw_scale, positive=True)
    except (TypeError, ValueError) as error:
        raise type(error)(f"invalid observation scaling for {name}: {error}") from error


def _validate_action_space_dtype(action_space: spaces.Box) -> None:
    dtype = np.dtype(action_space.dtype)
    if not np.issubdtype(dtype, np.floating) or not np.can_cast(
        np.dtype(np.float32),
        dtype,
        casting="safe",
    ):
        raise ValueError(
            "MPC action space dtype must be a real floating dtype that "
            "safely accepts float32 actions"
        )


def _validate_full_normalized_action_interface(env, base_env) -> tuple[tuple[float, float], tuple[float, float]]:
    _validate_no_internal_controller_overrides(env)
    if base_env.effective_action_interface != "full":
        raise ValueError("MPC requires the full two-axis action interface")
    action_space = getattr(env, "action_space", None)
    if not isinstance(action_space, spaces.Box) or action_space.shape != (2,):
        raise ValueError("MPC requires a Box action space with shape (2,)")
    _validate_action_space_dtype(action_space)
    low = np.asarray(action_space.low, dtype=np.float64)
    high = np.asarray(action_space.high, dtype=np.float64)
    if not (
        np.array_equal(low, np.array([-1.0, -1.0], dtype=np.float64))
        and np.array_equal(high, np.array([1.0, 1.0], dtype=np.float64))
    ):
        raise ValueError("MPC requires normalized [-1, 1] bounds on both actions")
    return (float(low[0]), float(low[1])), (float(high[0]), float(high[1]))


def _copy_action_space(action_space: spaces.Box) -> spaces.Box:
    """Return a detached Box preserving exact membership semantics."""

    copied = spaces.Box(
        low=np.array(action_space.low, dtype=action_space.dtype, copy=True),
        high=np.array(action_space.high, dtype=action_space.dtype, copy=True),
        dtype=action_space.dtype,
    )
    copied.low.setflags(write=False)
    copied.high.setflags(write=False)
    return copied


def _snapshot_full_normalized_action_space(env, base_env) -> spaces.Box:
    _validate_full_normalized_action_interface(env, base_env)
    action_space = getattr(env, "action_space", None)
    assert isinstance(action_space, spaces.Box)
    return _copy_action_space(action_space)


def _copied_observation_shape(name: str, raw_shape: object) -> tuple[int, ...]:
    if not isinstance(raw_shape, (tuple, list)):
        raise TypeError(f"observation shape for {name} must be a tuple/list")
    shape: list[int] = []
    for dimension in raw_shape:
        if isinstance(dimension, bool) or not isinstance(dimension, Integral):
            raise TypeError(f"observation shape for {name} must contain integers")
        converted = int(dimension)
        if converted <= 0:
            raise ValueError(
                f"observation shape for {name} must contain positive dimensions"
            )
        shape.append(converted)
    return tuple(shape)


def _snapshot_observation_layout(env, base_env):
    observation_format = getattr(base_env, "observation_format", None)
    names = tuple(getattr(base_env, "flat_observation_names", ()))
    if not names or not all(isinstance(name, str) and name for name in names):
        raise ValueError("environment does not expose a valid observation layout")

    observation_space = getattr(env, "observation_space", None)
    if observation_format == "dict":
        if not isinstance(observation_space, spaces.Dict):
            raise ValueError("dict observation format requires a Dict observation space")
        if set(observation_space.spaces) != set(names):
            raise ValueError("dict observation names do not match the observation space")
        shapes = tuple(
            (
                name,
                _copied_observation_shape(
                    name,
                    getattr(observation_space.spaces[name], "shape", None),
                ),
            )
            for name in names
        )
        return "dict", names, shapes, None, ()

    if observation_format != "flat":
        raise ValueError("MPC supports only dict or flat observations")
    if not isinstance(observation_space, spaces.Box) or len(observation_space.shape) != 1:
        raise ValueError("flat observation format requires a one-dimensional Box")

    flat_size = getattr(base_env, "flat_observation_size", None)
    if isinstance(flat_size, bool) or not isinstance(flat_size, (int, np.integer)):
        raise TypeError("flat observation size must be an integer")
    flat_size = int(flat_size)
    if flat_size <= 0 or observation_space.shape != (flat_size,):
        raise ValueError("flat observation size does not match the observation space")

    raw_slices = getattr(base_env, "flat_observation_slices", None)
    if not isinstance(raw_slices, Mapping) or set(raw_slices) != set(names):
        raise ValueError("flat observation slices do not match observation names")
    raw_view_specs = getattr(base_env, "_flat_observation_view_specs", None)
    if not isinstance(raw_view_specs, (tuple, list)):
        raise ValueError("environment does not expose flat observation view specs")
    if len(raw_view_specs) != len(names):
        raise ValueError("flat observation view specs do not match observation names")

    slices: list[tuple[str, int, int]] = []
    shapes: list[tuple[str, tuple[int, ...]]] = []
    occupied = np.zeros(flat_size, dtype=bool)
    view_names: list[str] = []
    blank_observations = getattr(base_env, "obs_dict_blank", None)
    if blank_observations is not None and not isinstance(blank_observations, Mapping):
        raise ValueError("flat observation blanks must be a mapping")
    if blank_observations is not None and not set(names).issubset(
        blank_observations
    ):
        raise ValueError("flat observation blanks do not match observation names")
    for index, spec in enumerate(raw_view_specs):
        if not isinstance(spec, (tuple, list)) or len(spec) != 3:
            raise ValueError(
                f"flat observation view spec {index} must be a (name, slice, shape) tuple"
            )
        name, item, raw_shape = spec
        if not isinstance(name, str) or not name:
            raise TypeError("flat observation view names must be nonempty strings")
        view_names.append(name)
        if name not in raw_slices:
            raise ValueError("flat observation view specs do not match observation names")
        if not isinstance(item, slice) or item.step not in (None, 1):
            raise ValueError(f"flat observation slice for {name} is invalid")
        if not isinstance(item.start, int) or not isinstance(item.stop, int):
            raise ValueError(f"flat observation slice for {name} needs integer bounds")
        if item.start < 0 or item.stop <= item.start or item.stop > flat_size:
            raise ValueError(f"flat observation slice for {name} is out of bounds")
        if occupied[item.start:item.stop].any():
            raise ValueError("flat observation slices overlap")
        matching_slice = raw_slices[name]
        if not isinstance(matching_slice, slice) or (
            matching_slice.start != item.start
            or matching_slice.stop != item.stop
            or matching_slice.step not in (None, 1)
        ):
            raise ValueError(
                f"flat observation view slice for {name} does not match flat_observation_slices"
            )
        shape = _copied_observation_shape(name, raw_shape)
        if math.prod(shape) != item.stop - item.start:
            raise ValueError(
                f"flat observation shape for {name} does not match its slice width"
            )
        if blank_observations is not None and name in blank_observations:
            blank_shape = _copied_observation_shape(
                name,
                getattr(blank_observations[name], "shape", None),
            )
            if blank_shape != shape:
                raise ValueError(
                    f"flat observation shape for {name} does not match obs_dict_blank"
                )
        occupied[item.start:item.stop] = True
        slices.append((name, item.start, item.stop))
        shapes.append((name, shape))
    if tuple(view_names) != names:
        raise ValueError("flat observation view specs do not match observation names")
    if not occupied.all():
        raise ValueError("flat observation slices do not cover the flat observation size")
    return "flat", names, tuple(shapes), flat_size, tuple(slices)


def _require_observation_layout(
    environment: MPCEnvironmentConfig,
    required_fields: tuple[str, ...],
) -> None:
    shapes = dict(environment.observation_shapes)
    scales = dict(environment.observation_scales)
    slices = {
        name: (start, stop)
        for name, start, stop in environment.flat_observation_slices
    }
    unknown = set(required_fields) - (
        _MPC_SCALAR_OBSERVATION_FIELDS | _MPC_ROAD_PREVIEW_FIELDS
    )
    if unknown:
        raise ValueError(
            "unknown required MPC observation fields: "
            + ", ".join(sorted(unknown))
        )
    required_preview_fields = set(required_fields) & _MPC_ROAD_PREVIEW_FIELDS
    if required_preview_fields:
        distances = environment.road_preview_distances_metres
        if distances is None:
            raise ValueError(
                "road-preview required fields need road_preview_distances_metres"
            )
        if (
            required_preview_fields - {ROAD_PREVIEW_VALIDITY_FIELD}
            and ROAD_PREVIEW_VALIDITY_FIELD not in required_preview_fields
        ):
            raise ValueError(
                "numeric road-preview required fields need "
                "road_preview_is_spatially_valid"
            )
        if (
            ROAD_PREVIEW_VALIDITY_FIELD in required_preview_fields
            and scales[ROAD_PREVIEW_VALIDITY_FIELD] != 1.0
        ):
            raise ValueError(
                "road_preview_is_spatially_valid must be unscaled"
            )
        if (
            required_preview_fields & _MPC_ROAD_PREVIEW_LANE_BOUND_FIELDS
            and environment.road_preview_lane_selection_provenance is None
        ):
            raise ValueError(
                "lane-bound road-preview observations require lane provenance"
            )
        expected_preview_shape = (len(distances),)
    else:
        expected_preview_shape = None

    for name in required_fields:
        if name in _MPC_ROAD_PREVIEW_FIELDS:
            if shapes[name] != expected_preview_shape:
                raise ValueError(
                    f"required road-preview observation {name!r} must have "
                    f"shape {expected_preview_shape}"
                )
            expected_width = expected_preview_shape[0]
        else:
            if math.prod(shapes[name]) != 1:
                raise ValueError(
                    f"required observation {name!r} must contain exactly one element"
                )
            expected_width = 1
        if environment.observation_format == "flat":
            start, stop = slices[name]
            if stop - start != expected_width:
                raise ValueError(
                    f"required flat observation {name!r} must have width "
                    f"{expected_width}"
                )


def _snapshot_normalized_bicycle_config(base_env) -> Mapping:
    car = getattr(base_env, "car", None)
    if car is None:
        raise ValueError("environment does not expose vehicle parameters")
    try:
        config = car.normalized_config
    except AttributeError as error:
        raise ValueError(
            "environment car does not expose normalized_config"
        ) from error
    if not isinstance(config, Mapping):
        raise TypeError("environment car normalized_config must be a mapping")
    return config


def _normalized_bicycle_value(config: Mapping, *path: str):
    current = config
    for index, name in enumerate(path):
        if not isinstance(current, Mapping) or name not in current:
            dotted = ".".join(path[: index + 1])
            raise ValueError(
                "environment car normalized_config is missing " + dotted
            )
        current = current[name]
    return current


def _snapshot_environment_config(
    env,
    *,
    base_env=None,
    bicycle_config: Mapping | None = None,
) -> MPCEnvironmentConfig:
    """Return a validated, detached snapshot of MPC interface facts."""

    if base_env is None:
        base_env = _unwrapped_environment(env)
    lower, upper = _validate_full_normalized_action_interface(env, base_env)
    (
        observation_format,
        names,
        observation_shapes,
        flat_size,
        flat_slices,
    ) = _snapshot_observation_layout(env, base_env)
    scales = tuple((name, _observation_scale(base_env, name)) for name in names)
    if bicycle_config is None:
        bicycle_config = _snapshot_normalized_bicycle_config(base_env)
    steering = _normalized_bicycle_value(bicycle_config, "steering")
    body_geometry = _normalized_bicycle_value(
        bicycle_config,
        "body_geometry",
    )

    preview_fields = _snapshot_road_preview_mpc_fields(base_env)
    return MPCEnvironmentConfig(
        control_timestep_seconds=_finite_float(
            "environment control timestep",
            base_env.environment_step_duration_s,
            positive=True,
        ),
        action_lower_bounds=lower,
        action_upper_bounds=upper,
        steering_request_limit_radians=_finite_float(
            "steering request limit",
            _normalized_bicycle_value(
                steering,
                "requested_front_wheel_angle_magnitude_limit_rad",
            ),
            positive=True,
        ),
        steering_offset_radians=_finite_float(
            "steering offset",
            _normalized_bicycle_value(
                steering,
                "physical_front_wheel_angle_offset_from_request_rad",
            ),
        ),
        observation_format=observation_format,
        observation_names=names,
        observation_shapes=observation_shapes,
        observation_scales=scales,
        flat_observation_size=flat_size,
        flat_observation_slices=flat_slices,
        **preview_fields,
        vehicle_body_width_metres=_normalized_bicycle_value(
            body_geometry,
            "width_m",
        ),
    )


def _snapshot_road_preview_mpc_fields(base_env) -> dict[str, object]:
    """Translate final environment preview authority into MPC-native fields."""

    metadata = getattr(base_env, "resolved_road_preview_metadata", None)
    if not isinstance(metadata, Mapping):
        raise ValueError("environment does not expose road-preview metadata")
    metadata = dict(metadata)
    expected_keys = {
        "target_line_mode",
        "target_line_curvature_model",
        "lane_bounds_mode",
        "lane_bounds_source_lane_index",
    }
    if set(metadata) != expected_keys:
        raise ValueError("resolved_road_preview_metadata has invalid fields")

    target_config = getattr(base_env, "_target_line_config", None)
    if not isinstance(target_config, Mapping):
        raise ValueError("environment does not expose resolved target-line config")
    target_config = dict(target_config)
    target_mode = metadata["target_line_mode"]
    if target_config.get("mode", "reference_line") != target_mode:
        raise ValueError("road-preview metadata does not match target-line config")

    target_line_offset_metres = 0.0
    target_lane_index = None
    target_lane_units = None
    target_lane_units_allow_outside = False
    if target_mode == "fixed_offset":
        target_line_offset_metres = float(
            target_config["offset_from_reference_line_m"]
        )
    elif target_mode == "lane_center":
        target_lane_index = int(target_config["lane_index"])
    elif target_mode == "lane_coordinate":
        target_lane_units = float(target_config["lane_coordinate"])
        target_lane_units_allow_outside = bool(
            target_config["allow_outside_lanes"]
        )
    elif target_mode != "reference_line":
        raise ValueError("unsupported road-preview target-line mode")

    curvature_provenance = {
        "exact_reference_line": "exact_reference_line",
        "exact_parallel_curve": "exact_parallel_curve",
        "local_parallel_curve_approximation": "tapered_target_approximation",
    }.get(metadata["target_line_curvature_model"])
    if curvature_provenance is None:
        raise ValueError("unsupported road-preview target curvature model")

    lane_mode = metadata["lane_bounds_mode"]
    lane_provenance = {
        None: None,
        "target_line_lane": "target_lane_index",
        "lane_index": "explicit_lane_index",
        "reference_lane": "reference_line_lane_center",
    }.get(lane_mode, object())
    if not isinstance(lane_provenance, (str, type(None))):
        raise ValueError("unsupported road-preview lane-bounds mode")
    lane_index = metadata["lane_bounds_source_lane_index"]

    distances = getattr(base_env, "_road_preview_target_line_distances_m", None)
    if distances is not None:
        distances = tuple(float(distance) for distance in distances)
    return {
        "road_preview_distances_metres": distances,
        "target_line_offset_metres": target_line_offset_metres,
        "target_lane_index": target_lane_index,
        "target_lane_units": target_lane_units,
        "target_lane_units_allow_outside": target_lane_units_allow_outside,
        "road_preview_lane_index": lane_index,
        "road_preview_lane_selection_provenance": lane_provenance,
        "road_preview_target_curvature_provenance": curvature_provenance,
    }


def _snapshot_kinematic_bicycle_mpc_model(
    env,
    *,
    base_env=None,
    bicycle_config: Mapping | None = None,
) -> KinematicBicycleMPCModelConfig:
    """Return a detached physical-model snapshot for the sibling configs."""

    if base_env is None:
        base_env = _unwrapped_environment(env)
    if bicycle_config is None:
        bicycle_config = _snapshot_normalized_bicycle_config(base_env)
    mass_properties = _normalized_bicycle_value(
        bicycle_config,
        "mass_properties",
    )
    longitudinal_force_model = _normalized_bicycle_value(
        bicycle_config,
        "longitudinal_force_model",
    )
    axle_geometry = _normalized_bicycle_value(
        bicycle_config,
        "axle_geometry",
    )
    return KinematicBicycleMPCModelConfig(
        control_timestep_seconds=base_env.environment_step_duration_s,
        mass_kg=_normalized_bicycle_value(mass_properties, "mass_kg"),
        motor_force_gain_newtons=_normalized_bicycle_value(
            longitudinal_force_model,
            "normalized_motor_command_force_gain_n",
        ),
        front_axle_distance_metres=_normalized_bicycle_value(
            axle_geometry,
            "front_axle_distance_from_center_of_mass_m",
        ),
        rear_axle_distance_metres=_normalized_bicycle_value(
            axle_geometry,
            "rear_axle_distance_from_center_of_mass_m",
        ),
    )


@dataclass(frozen=True, slots=True)
class AutonomousDrivingMPCAdapter:
    """Validated conversion boundary for one environment interface snapshot."""

    environment_config: MPCEnvironmentConfig
    plant_model: KinematicBicycleMPCModelConfig | None
    required_fields: tuple[str, ...]
    steering_rate_control_lower_radians_per_second: float | None
    steering_rate_control_upper_radians_per_second: float | None
    action_space: spaces.Box | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.environment_config, MPCEnvironmentConfig):
            raise TypeError("environment_config must be an MPCEnvironmentConfig")
        if self.plant_model is not None and not isinstance(
            self.plant_model,
            KinematicBicycleMPCModelConfig,
        ):
            raise TypeError(
                "plant_model must be a KinematicBicycleMPCModelConfig or None"
            )
        if not isinstance(self.required_fields, tuple):
            raise TypeError("required_fields must be a tuple")
        if not all(
            isinstance(name, str) and name for name in self.required_fields
        ):
            raise TypeError("required_fields must contain nonempty strings")
        if len(set(self.required_fields)) != len(self.required_fields):
            raise ValueError("required_fields must be unique")
        missing = [
            name
            for name in self.required_fields
            if name not in self.environment_config.observation_names
        ]
        if missing:
            raise ValueError(
                ", ".join(missing)
                + " must be agent-visible observation fields routed through obs"
            )
        _require_observation_layout(
            self.environment_config,
            self.required_fields,
        )
        action_space = self.action_space
        if action_space is None:
            action_space = spaces.Box(
                low=np.asarray(
                    self.environment_config.action_lower_bounds,
                    dtype=np.float32,
                ),
                high=np.asarray(
                    self.environment_config.action_upper_bounds,
                    dtype=np.float32,
                ),
                dtype=np.float32,
            )
        if not isinstance(action_space, spaces.Box) or action_space.shape != (2,):
            raise TypeError("action_space must be a Box with shape (2,)")
        _validate_action_space_dtype(action_space)
        copied_action_space = _copy_action_space(action_space)
        copied_low = tuple(float(value) for value in copied_action_space.low)
        copied_high = tuple(float(value) for value in copied_action_space.high)
        if copied_low != self.environment_config.action_lower_bounds or (
            copied_high != self.environment_config.action_upper_bounds
        ):
            raise ValueError("action_space bounds must match environment_config")
        object.__setattr__(self, "action_space", copied_action_space)
        lower = self.steering_rate_control_lower_radians_per_second
        upper = self.steering_rate_control_upper_radians_per_second
        if (lower is None) != (upper is None):
            raise ValueError("steering-rate capability bounds must be provided together")
        if lower is not None:
            lower = _finite_float("steering-rate lower limit", lower)
            upper = _finite_float("steering-rate upper limit", upper)
            if lower > upper:
                raise ValueError(
                    "steering-rate lower limit must not exceed upper limit"
                )
            object.__setattr__(
                self,
                "steering_rate_control_lower_radians_per_second",
                lower,
            )
            object.__setattr__(
                self,
                "steering_rate_control_upper_radians_per_second",
                upper,
            )

    @classmethod
    def from_env(
        cls,
        env,
        required_fields: tuple[str, ...],
    ) -> "AutonomousDrivingMPCAdapter":
        if not isinstance(required_fields, tuple):
            raise TypeError("required_fields must be a tuple")
        if not all(isinstance(name, str) and name for name in required_fields):
            raise TypeError("required_fields must contain nonempty strings")
        if len(set(required_fields)) != len(required_fields):
            raise ValueError("required_fields must be unique")

        base_env = _unwrapped_environment(env)
        bicycle_config = _snapshot_normalized_bicycle_config(base_env)
        environment_config = _snapshot_environment_config(
            env,
            base_env=base_env,
            bicycle_config=bicycle_config,
        )
        missing = [
            name for name in required_fields if name not in environment_config.observation_names
        ]
        if missing:
            raise ValueError(
                ", ".join(missing)
                + " must be agent-visible observation fields routed through obs"
            )
        _require_observation_layout(environment_config, required_fields)

        action_space = _snapshot_full_normalized_action_space(env, base_env)
        steering = _normalized_bicycle_value(bicycle_config, "steering")
        steering_rate_bounds = _normalized_bicycle_value(
            steering,
            "physical_front_wheel_angle_rate_bounds_rad_per_s",
        )
        return cls(
            environment_config=environment_config,
            plant_model=_snapshot_kinematic_bicycle_mpc_model(
                env,
                base_env=base_env,
                bicycle_config=bicycle_config,
            ),
            required_fields=required_fields,
            steering_rate_control_lower_radians_per_second=_finite_float(
                "steering-rate lower limit",
                _normalized_bicycle_value(steering_rate_bounds, "lower"),
            ),
            steering_rate_control_upper_radians_per_second=_finite_float(
                "steering-rate upper limit",
                _normalized_bicycle_value(steering_rate_bounds, "upper"),
            ),
            action_space=action_space,
        )

    def _encoded_scalar(self, observation, name: str) -> float:
        if self.environment_config.observation_format == "dict":
            if not isinstance(observation, Mapping):
                raise TypeError("dict observation format requires a mapping")
            if name not in observation:
                raise ValueError(f"observation is missing required field {name}")
            value = np.asarray(observation[name])
            if value.size != 1:
                raise ValueError(f"observation field {name} must be scalar")
            return float(value.reshape(-1)[0])

        value = np.asarray(observation)
        expected_size = self.environment_config.flat_observation_size
        if value.shape != (expected_size,):
            raise ValueError(
                f"flat observation size must be {expected_size}, got shape {value.shape}"
            )
        slices = {
            field_name: (start, stop)
            for field_name, start, stop in self.environment_config.flat_observation_slices
        }
        start, stop = slices[name]
        encoded = value[start:stop]
        if encoded.size != 1:
            raise ValueError(f"observation field {name} must be scalar")
        return float(encoded[0])

    def _physical_scalar(
        self,
        observation,
        name: str,
        *,
        allow_positive_infinity: bool = False,
    ) -> float:
        encoded = self._encoded_scalar(observation, name)
        scale = dict(self.environment_config.observation_scales)[name]
        physical = encoded / scale
        if allow_positive_infinity and physical == math.inf:
            return physical
        if not math.isfinite(physical):
            raise ValueError(f"observation field {name} must be finite")
        return float(physical)

    def _physical_preview_vector(
        self,
        observation,
        name: str,
        *,
        scale_values: bool,
    ) -> np.ndarray:
        distances = self.environment_config.road_preview_distances_metres
        if distances is None:
            raise ValueError("road-preview decoding requires a committed distance grid")
        expected_shape = (len(distances),)
        if self.environment_config.observation_format == "dict":
            if not isinstance(observation, Mapping):
                raise TypeError("dict observation format requires a mapping")
            if name not in observation:
                raise ValueError(f"observation is missing required field {name}")
            encoded = np.asarray(observation[name])
        else:
            flat = np.asarray(observation)
            expected_size = self.environment_config.flat_observation_size
            if flat.shape != (expected_size,):
                raise ValueError(
                    f"flat observation size must be {expected_size}, got shape "
                    f"{flat.shape}"
                )
            slices = {
                field_name: (start, stop)
                for field_name, start, stop in (
                    self.environment_config.flat_observation_slices
                )
            }
            start, stop = slices[name]
            encoded = flat[start:stop]
        if encoded.shape != expected_shape:
            raise ValueError(
                f"observation field {name} must have shape {expected_shape}, "
                f"got {encoded.shape}"
            )
        if encoded.dtype.kind not in "iuf":
            raise TypeError(
                f"observation field {name} must have a real numeric dtype"
            )
        if not scale_values:
            return encoded
        scale = dict(self.environment_config.observation_scales)[name]
        return np.asarray(encoded / scale)

    def decode_road_preview(
        self,
        observation,
        *,
        required_fields: tuple[str, ...],
    ) -> MPCRoadPreviewObservation:
        """Decode selected preview fields without classifying physical values."""

        if not isinstance(required_fields, tuple):
            raise TypeError("required_fields must be a tuple")
        if not all(isinstance(name, str) and name for name in required_fields):
            raise TypeError("required_fields must contain nonempty strings")
        if len(set(required_fields)) != len(required_fields):
            raise ValueError("required_fields must be unique")
        required = frozenset(required_fields)
        unknown = required - _MPC_ROAD_PREVIEW_FIELDS
        if unknown:
            raise ValueError(
                "unknown required road-preview fields: "
                + ", ".join(sorted(unknown))
            )
        if ROAD_PREVIEW_VALIDITY_FIELD not in required:
            raise ValueError(
                "road_preview_is_spatially_valid is required for preview decoding"
            )
        unbound = required - set(self.required_fields)
        if unbound:
            raise ValueError(
                "road-preview fields were not bound by this adapter: "
                + ", ".join(sorted(unbound))
            )

        validity = self._physical_preview_vector(
            observation,
            ROAD_PREVIEW_VALIDITY_FIELD,
            scale_values=False,
        )
        values = {
            name: self._physical_preview_vector(
                observation,
                name,
                scale_values=True,
            )
            for name in required_fields
            if name != ROAD_PREVIEW_VALIDITY_FIELD
        }
        return MPCRoadPreviewObservation(
            target_line_curvatures_per_metre=values.get(
                "road_preview_target_line_curvatures_per_m"
            ),
            recommended_speeds_mps=values.get(
                "road_preview_recommended_speeds_mps"
            ),
            speed_limits_mps=values.get("road_preview_speed_limits_mps"),
            right_lane_bound_offsets_from_target_line_metres=values.get(
                "road_preview_right_lane_bound_offsets_from_target_line_m"
            ),
            left_lane_bound_offsets_from_target_line_metres=values.get(
                "road_preview_left_lane_bound_offsets_from_target_line_m"
            ),
            validity=validity,
        )

    def decode_observation(self, observation) -> MPCObservation:
        """Decode one agent observation without consulting ``info`` or ground truth."""

        speed_limit = None
        if "speed_limit_mps" in self.required_fields:
            speed_limit = self._physical_scalar(observation, "speed_limit_mps")
        return MPCObservation(
            vx_mps=self._physical_scalar(
                observation,
                "body_longitudinal_velocity_mps",
            ),
            steering_angle_radians=self._physical_scalar(
                observation,
                "front_wheel_steering_angle_rad",
            ),
            lateral_error_metres=self._physical_scalar(
                observation,
                "lateral_error_from_target_line_m",
            ),
            heading_error_radians=self._physical_scalar(
                observation,
                "heading_error_from_target_line_rad",
            ),
            recommended_speed_mps=self._physical_scalar(
                observation,
                "recommended_speed_mps",
            ),
            next_recommended_speed_mps=self._physical_scalar(
                observation,
                "next_recommended_speed_change_value_mps",
            ),
            distance_to_next_recommended_speed_metres=self._physical_scalar(
                observation,
                "next_recommended_speed_change_reference_line_distance_m",
                allow_positive_infinity=True,
            ),
            speed_limit_mps=speed_limit,
        )

    def steering_angle_to_normalized_request(
        self,
        requested_angle_radians: float,
    ) -> float:
        requested = _finite_float(
            "requested_angle_radians",
            requested_angle_radians,
        )
        return float(
            (requested - self.environment_config.steering_offset_radians)
            / self.environment_config.steering_request_limit_radians
        )

    def validate_environment(
        self,
        env,
        model: KinematicBicycleMPCModelConfig,
    ) -> None:
        """Validate interface stability while allowing deliberate model mismatch."""

        if not isinstance(model, KinematicBicycleMPCModelConfig):
            raise TypeError("model must be a KinematicBicycleMPCModelConfig")
        current = MPCEnvironmentConfig.from_env(env)
        if not _mpc_environment_interfaces_match(
            current,
            self.environment_config,
        ):
            raise ValueError("environment interface no longer matches the MPC snapshot")
        current_action_space = _snapshot_full_normalized_action_space(
            env,
            _unwrapped_environment(env),
        )
        bound_action_space = self.action_space
        assert isinstance(bound_action_space, spaces.Box)
        if current_action_space.dtype != bound_action_space.dtype or not (
            np.array_equal(current_action_space.low, bound_action_space.low)
            and np.array_equal(current_action_space.high, bound_action_space.high)
        ):
            raise ValueError(
                "environment action space no longer matches the MPC snapshot"
            )
        self._validate_model_timestep(model)

    def _validate_model_timestep(
        self,
        model: KinematicBicycleMPCModelConfig,
    ) -> None:
        if not isinstance(model, KinematicBicycleMPCModelConfig):
            raise TypeError("model must be a KinematicBicycleMPCModelConfig")
        if not math.isclose(
            self.environment_config.control_timestep_seconds,
            model.control_timestep_seconds,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise ValueError("environment and MPC model timestep must match")

    def model_parameter_mismatches(
        self,
        model: KinematicBicycleMPCModelConfig,
    ) -> dict[str, tuple[float, float]] | None:
        """Return ``controller, plant`` pairs for deliberate model mismatches."""

        if not isinstance(model, KinematicBicycleMPCModelConfig):
            raise TypeError("model must be a KinematicBicycleMPCModelConfig")
        if self.plant_model is None:
            return None
        mismatches: dict[str, tuple[float, float]] = {}
        for field_name in (
            "mass_kg",
            "motor_force_gain_newtons",
            "front_axle_distance_metres",
            "rear_axle_distance_metres",
        ):
            controller_value = getattr(model, field_name)
            plant_value = getattr(self.plant_model, field_name)
            if not math.isclose(
                controller_value,
                plant_value,
                rel_tol=1.0e-12,
                abs_tol=1.0e-12,
            ):
                mismatches[field_name] = (controller_value, plant_value)
        return mismatches


def _validate_configured_constant_fallback_action(env, config) -> None:
    _control_kind_for_config(config)
    fallback = config.fallback
    if fallback.mode is not MPCFallbackMode.CONSTANT_ACTION:
        return
    action_space = getattr(env, "action_space", None)
    if not isinstance(action_space, spaces.Box):
        raise ValueError("constant fallback requires a Box action space")
    action = np.asarray(
        fallback.constant_environment_action,
        dtype=action_space.dtype,
    )
    if not action_space.contains(action):
        raise ValueError(
            "constant fallback action must be inside the current environment "
            "action space"
        )


def resolve_policy_config_from_env(
    env,
    config: (
        AutonomousDrivingDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareSteeringRateMPCConfig
        | AutonomousDrivingSteeringRateMPCConfig
    ),
    required_fields: tuple[str, ...],
) -> tuple[
    AutonomousDrivingDirectSteeringMPCConfig
    | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
    | AutonomousDrivingRoadAwareSteeringRateMPCConfig
    | AutonomousDrivingSteeringRateMPCConfig,
    AutonomousDrivingMPCAdapter,
]:
    """Resolve environment/model/actuator defaults without erasing beliefs."""

    control_kind = _control_kind_for_config(config)
    adapter = AutonomousDrivingMPCAdapter.from_env(env, required_fields)
    _validate_configured_constant_fallback_action(env, config)

    model = adapter.plant_model if config.model is None else config.model
    adapter._validate_model_timestep(model)

    constraints = config.constraints
    offset = adapter.environment_config.steering_offset_radians
    request_limit = adapter.environment_config.steering_request_limit_radians
    replacements: dict[str, float] = {}
    if control_kind is _MPCControlKind.DIRECT_STEERING:
        if constraints.steering_angle_control_lower_radians is None:
            replacements.update(
                steering_angle_control_lower_radians=offset - request_limit,
                steering_angle_control_upper_radians=offset + request_limit,
            )
    else:
        if constraints.steering_angle_state_lower_radians is None:
            replacements.update(
                steering_angle_state_lower_radians=offset - request_limit,
                steering_angle_state_upper_radians=offset + request_limit,
            )
        if constraints.steering_rate_control_lower_radians_per_second is None:
            replacements.update(
                steering_rate_control_lower_radians_per_second=(
                    adapter.steering_rate_control_lower_radians_per_second
                ),
                steering_rate_control_upper_radians_per_second=(
                    adapter.steering_rate_control_upper_radians_per_second
                ),
            )

    if type(config) in (
        AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    ) and config.use_lane_bound_constraints:
        if constraints.vehicle_body_width_metres is None:
            plant_width = adapter.environment_config.vehicle_body_width_metres
            if plant_width is None:
                raise ValueError(
                    "lane-bound constraints require an environment vehicle body "
                    "width"
                )
            replacements["vehicle_body_width_metres"] = plant_width

    if replacements:
        constraints = replace(constraints, **replacements)

    resolved = replace(
        config,
        environment=adapter.environment_config,
        model=model,
        constraints=constraints,
    )
    return resolved, adapter
