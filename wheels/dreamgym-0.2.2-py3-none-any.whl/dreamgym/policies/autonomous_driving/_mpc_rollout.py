"""Dependency-light private seam used by MPC rollout capture."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dreamgym.policies.autonomous_driving.mpc_results import MPCPolicyResult
    from dreamgym.policies.mpc import LinearQuadraticMPCProblem


class _AutonomousDrivingMPCPolicyMarker:
    """Private marker for the two supported autonomous-driving MPC families."""


class _MPCConfiguredRaiseError(RuntimeError):
    def __init__(
        self,
        *,
        policy_result: MPCPolicyResult,
        problem: LinearQuadraticMPCProblem | None,
    ) -> None:
        status = policy_result.solve_status
        detail = (
            f"solver status {status!r}"
            if status is not None
            else f"policy failure {policy_result.failure.reason!r}"
        )
        super().__init__(f"MPC action unavailable: {detail}")
        self.policy_result = policy_result
        self.problem = problem
