"""Pure straight-road formulations and schedules for autonomous-driving MPC."""

from __future__ import annotations

import math
from numbers import Integral, Real

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_adapter import MPCObservation
from dreamgym.policies.autonomous_driving.mpc_config import (
    KinematicBicycleMPCModelConfig,
    MPCSpeedLinearizationStrategy,
)


def _finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    return converted


def _horizon_steps(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError("horizon_steps must be an integer")
    converted = int(value)
    if converted <= 0:
        raise ValueError("horizon_steps must be greater than zero")
    return converted


def _model_terms(
    model: KinematicBicycleMPCModelConfig,
    linearization_speed_mps: object,
):
    if not isinstance(model, KinematicBicycleMPCModelConfig):
        raise TypeError("model must be a KinematicBicycleMPCModelConfig")
    speed = _finite_float("linearization_speed_mps", linearization_speed_mps)
    timestep = model.control_timestep_seconds
    wheelbase = (
        model.front_axle_distance_metres + model.rear_axle_distance_metres
    )
    drive_gain = model.motor_force_gain_newtons / model.mass_kg
    return timestep, wheelbase, drive_gain, speed


def build_direct_steering_model(
    model: KinematicBicycleMPCModelConfig,
    linearization_speed_mps: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Build the three-state, direct-steering frozen-speed model.

    States are ``[vx, lateral_error, heading_error]`` and controls are
    ``[normalized_drive_command, physical_steering_angle]``.  Positive lateral
    error and positive steering are both leftward.  The scheduled speed is used
    exactly as supplied, including at zero or in reverse; there is deliberately
    no hidden numerical speed floor.
    """

    timestep, wheelbase, drive_gain, speed = _model_terms(
        model, linearization_speed_mps
    )
    state_matrix = np.array(
        [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, timestep * speed],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )
    control_matrix = np.array(
        [
            [timestep * drive_gain, 0.0],
            [0.0, 0.5 * timestep**2 * speed**2 / wheelbase],
            [0.0, timestep * speed / wheelbase],
        ],
        dtype=np.float64,
    )
    return state_matrix, control_matrix


def build_steering_rate_model(
    model: KinematicBicycleMPCModelConfig,
    linearization_speed_mps: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Build the four-state, steering-rate frozen-speed model.

    States are ``[vx, lateral_error, heading_error, steering_angle]`` and
    controls are ``[normalized_drive_command, steering_rate]``.  The exact
    polynomial-in-time terms retain the previous teaching formulation while
    using the repository's positive-left error convention.
    """

    timestep, wheelbase, drive_gain, speed = _model_terms(
        model, linearization_speed_mps
    )
    state_matrix = np.array(
        [
            [1.0, 0.0, 0.0, 0.0],
            [
                0.0,
                1.0,
                timestep * speed,
                0.5 * timestep**2 * speed**2 / wheelbase,
            ],
            [0.0, 0.0, 1.0, timestep * speed / wheelbase],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )
    control_matrix = np.array(
        [
            [timestep * drive_gain, 0.0],
            [0.0, (1.0 / 6.0) * timestep**3 * speed**2 / wheelbase],
            [0.0, 0.5 * timestep**2 * speed / wheelbase],
            [0.0, timestep],
        ],
        dtype=np.float64,
    )
    return state_matrix, control_matrix


def predict_relative_progress(
    model: KinematicBicycleMPCModelConfig,
    previous_states,
    previous_controls,
) -> np.ndarray:
    """Shift the prior prediction and integrate progress from the current pose.

    A prior horizon with ``N`` controls has ``N+1`` states.  Because that
    horizon was generated one control step ago, new interval ``k`` uses prior
    state/control ``k+1`` for all available shifted intervals.  The last
    interval uses the prior terminal speed and repeats the last control.
    """

    if not isinstance(model, KinematicBicycleMPCModelConfig):
        raise TypeError("model must be a KinematicBicycleMPCModelConfig")
    states = np.asarray(previous_states, dtype=np.float64)
    controls = np.asarray(previous_controls, dtype=np.float64)
    if states.ndim != 2 or states.shape[1] < 1:
        raise ValueError("previous_states must be a two-dimensional state trajectory")
    if controls.ndim != 2 or controls.shape[1] < 1 or controls.shape[0] < 1:
        raise ValueError("previous_controls must be a nonempty two-dimensional trajectory")
    horizon_steps = controls.shape[0]
    if states.shape[0] != horizon_steps + 1:
        raise ValueError("previous_states must have one more stage than previous_controls")
    if not np.isfinite(states).all() or not np.isfinite(controls).all():
        raise ValueError("previous states and controls must be finite")

    timestep = model.control_timestep_seconds
    acceleration_progress_gain = (
        0.5
        * timestep**2
        * model.motor_force_gain_newtons
        / model.mass_kg
    )
    interval_progress = np.empty(horizon_steps, dtype=np.float64)
    if horizon_steps > 1:
        interval_progress[:-1] = (
            timestep * states[1:horizon_steps, 0]
            + acceleration_progress_gain * controls[1:horizon_steps, 0]
        )
    interval_progress[-1] = (
        timestep * states[horizon_steps, 0]
        + acceleration_progress_gain * controls[horizon_steps - 1, 0]
    )
    progress = np.empty(horizon_steps + 1, dtype=np.float64)
    progress[0] = 0.0
    progress[1:] = np.cumsum(interval_progress, dtype=np.float64)
    return progress


def predict_current_relative_progress(
    model: KinematicBicycleMPCModelConfig,
    predicted_states,
    predicted_controls,
) -> np.ndarray:
    """Integrate the current prediction with state/control stages k=0...N-1."""

    if not isinstance(model, KinematicBicycleMPCModelConfig):
        raise TypeError("model must be a KinematicBicycleMPCModelConfig")
    states = np.asarray(predicted_states, dtype=np.float64)
    controls = np.asarray(predicted_controls, dtype=np.float64)
    if states.ndim != 2 or states.shape[1] < 1:
        raise ValueError(
            "predicted_states must be a two-dimensional state trajectory"
        )
    if controls.ndim != 2 or controls.shape[1] < 1 or controls.shape[0] < 1:
        raise ValueError(
            "predicted_controls must be a nonempty two-dimensional trajectory"
        )
    if states.shape[0] != controls.shape[0] + 1:
        raise ValueError(
            "predicted_states must have one more stage than predicted_controls"
        )
    if not np.isfinite(states).all() or not np.isfinite(controls).all():
        raise ValueError("predicted states and controls must be finite")
    timestep = model.control_timestep_seconds
    interval_progress = (
        timestep * states[:-1, 0]
        + 0.5
        * timestep**2
        * model.motor_force_gain_newtons
        / model.mass_kg
        * controls[:, 0]
    )
    progress = np.empty(controls.shape[0] + 1, dtype=np.float64)
    progress[0] = 0.0
    progress[1:] = np.cumsum(interval_progress, dtype=np.float64)
    return progress


def build_recommended_speed_schedules(
    predicted_progress: np.ndarray,
    current_speed: float,
    next_speed: float,
    distance: float,
    recommended_speed_soft_upper_margin_mps: float | None,
) -> tuple[np.ndarray, np.ndarray | None, int | None]:
    """Build independent state-reference and soft-upper-bound schedules.

    References align with states ``x0..xN``.  When enabled, soft state bounds
    align with constrained states ``x1..xN`` and add the configured physical
    speed margin to ``references[1:]``.  Equality at the transition distance
    selects the next recommendation.
    """

    progress = np.asarray(predicted_progress, dtype=np.float64)
    if progress.ndim != 1 or progress.shape[0] < 2:
        raise ValueError("predicted_progress must have shape (N+1,) with N >= 1")
    if not np.isfinite(progress).all():
        raise ValueError("predicted_progress must be finite")
    current = _finite_float("current_speed", current_speed)
    following = _finite_float("next_speed", next_speed)
    if isinstance(distance, bool) or not isinstance(distance, Real):
        raise TypeError("distance must be a real number")
    transition_distance = float(distance)
    if math.isnan(transition_distance) or transition_distance == -math.inf:
        raise ValueError("distance must be finite or positive infinity")

    crossing = np.flatnonzero(progress >= transition_distance)
    transition_index = int(crossing[0]) if crossing.size else None
    reference_speeds = np.full(progress.shape, current, dtype=np.float64)
    if transition_index is not None:
        reference_speeds[transition_index:] = following
    if recommended_speed_soft_upper_margin_mps is None:
        soft_upper_bounds = None
    else:
        margin = _finite_float(
            "recommended_speed_soft_upper_margin_mps",
            recommended_speed_soft_upper_margin_mps,
        )
        if margin < 0.0:
            raise ValueError(
                "recommended_speed_soft_upper_margin_mps must be nonnegative"
            )
        soft_upper_bounds = reference_speeds[1:] + margin
    return reference_speeds, soft_upper_bounds, transition_index


def _validated_observation_value(name: str, value: object) -> float:
    return _finite_float(name, value)


def build_linearization_speed_schedule(
    strategy: MPCSpeedLinearizationStrategy,
    horizon_steps: int,
    observation: MPCObservation,
    reference_speeds,
    previous_states,
    fixed_speed_mps: float | None,
) -> np.ndarray:
    """Build one interval-start speed schedule without changing references."""

    horizon = _horizon_steps(horizon_steps)
    if not isinstance(observation, MPCObservation):
        raise TypeError("observation must be an MPCObservation")
    if isinstance(strategy, str) and not isinstance(
        strategy, MPCSpeedLinearizationStrategy
    ):
        try:
            strategy = MPCSpeedLinearizationStrategy(strategy)
        except ValueError as error:
            raise ValueError("invalid speed linearization strategy") from error
    if not isinstance(strategy, MPCSpeedLinearizationStrategy):
        raise TypeError("strategy must be an MPCSpeedLinearizationStrategy")

    references = np.asarray(reference_speeds, dtype=np.float64)
    if references.shape != (horizon + 1,):
        raise ValueError("reference_speeds must have shape (horizon_steps + 1,)")
    if not np.isfinite(references).all():
        raise ValueError("reference_speeds must be finite")

    measured_speed = _validated_observation_value(
        "observation.vx_mps", observation.vx_mps
    )
    if strategy is MPCSpeedLinearizationStrategy.MEASURED_SPEED:
        return np.full(horizon, measured_speed, dtype=np.float64)
    if strategy is MPCSpeedLinearizationStrategy.RECOMMENDED_SPEED:
        recommended = _validated_observation_value(
            "observation.recommended_speed_mps", observation.recommended_speed_mps
        )
        return np.full(horizon, recommended, dtype=np.float64)
    if strategy is MPCSpeedLinearizationStrategy.SPEED_LIMIT:
        if observation.speed_limit_mps is None:
            raise ValueError("speed_limit observation is required for SPEED_LIMIT")
        speed_limit = _validated_observation_value(
            "observation.speed_limit_mps", observation.speed_limit_mps
        )
        return np.full(horizon, speed_limit, dtype=np.float64)
    if strategy is MPCSpeedLinearizationStrategy.PREVIEW_RECOMMENDED_SPEED:
        return references[:-1].copy()
    if strategy is MPCSpeedLinearizationStrategy.SHIFTED_PREDICTED_SPEED:
        try:
            prior = (
                None
                if previous_states is None
                else np.asarray(previous_states, dtype=np.float64)
            )
        except (TypeError, ValueError):
            prior = None
        prior_is_usable = (
            prior is not None
            and prior.ndim == 2
            and prior.shape[0] == horizon + 1
            and prior.shape[1] >= 1
            and np.isfinite(prior[:, 0]).all()
        )
        if not prior_is_usable:
            return np.full(horizon, measured_speed, dtype=np.float64)
        schedule = np.empty(horizon, dtype=np.float64)
        schedule[0] = measured_speed
        if horizon > 1:
            schedule[1:] = np.asarray(prior[2:, 0], dtype=np.float64)
        return schedule
    if fixed_speed_mps is None:
        raise ValueError("fixed_speed_mps is required for FIXED_SPEED")
    fixed_speed = _finite_float("fixed_speed_mps", fixed_speed_mps)
    return np.full(horizon, fixed_speed, dtype=np.float64)
