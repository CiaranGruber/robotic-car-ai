"""Private typed transport for classified MPC policy input failures."""

from __future__ import annotations

from dreamgym.policies.autonomous_driving.mpc_results import MPCPolicyFailure


class _MPCPolicyInputError(RuntimeError):
    """Carry a classified per-step policy failure through private helpers."""

    def __init__(
        self,
        failure: MPCPolicyFailure,
        *,
        road_horizon_time_seconds: float = 0.0,
    ) -> None:
        super().__init__(failure.message)
        self.failure = failure
        self.road_horizon_time_seconds = road_horizon_time_seconds
