"""Private shared lifecycle for autonomous-driving MPC policies."""

from __future__ import annotations

from dataclasses import dataclass, replace
import inspect
import math
from numbers import Integral, Real
from time import perf_counter
from typing import overload
import weakref

import numpy as np

from dreamgym.policies.autonomous_driving._mpc_adapter import (
    AutonomousDrivingMPCAdapter,
    MPCObservation,
    _enabled_internal_controller_names,
    _mpc_environment_interfaces_match,
    _require_observation_layout,
    _unwrapped_environment,
    _validate_configured_constant_fallback_action,
    resolve_policy_config_from_env,
)
from dreamgym.policies.autonomous_driving._mpc_control import (
    _MPCControlKind,
    _control_kind_for_config,
)
from dreamgym.policies.autonomous_driving._mpc_failures import (
    _MPCPolicyInputError,
)
from dreamgym.policies.autonomous_driving._mpc_rollout import (
    _AutonomousDrivingMPCPolicyMarker,
    _MPCConfiguredRaiseError,
)
from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    AutonomousDrivingSteeringRateMPCConfig,
    MPCFallbackMode,
    MPCSpeedLinearizationStrategy,
)
from dreamgym.policies.autonomous_driving._mpc_formulations import (
    build_linearization_speed_schedule,
    build_recommended_speed_schedules,
    predict_relative_progress,
)
from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCActionRequest,
    MPCEnvironmentBindingDiagnostics,
    MPCPolicyFailure,
    MPCPolicyResult,
    MPCRoadHorizonContext,
    _expected_action_clipping_flags,
    _expected_environment_action,
)
from dreamgym.policies.mpc import (
    LinearQuadraticMPCProblem,
    LinearQuadraticMPCSolver,
    MPCSolveResult,
)


_BASE_REQUIRED_OBSERVATION_FIELDS = (
    "body_longitudinal_velocity_mps",
    "front_wheel_steering_angle_rad",
    "lateral_error_from_target_line_m",
    "heading_error_from_target_line_rad",
    "recommended_speed_mps",
    "next_recommended_speed_change_value_mps",
    "next_recommended_speed_change_reference_line_distance_m",
)

_BIND_SEED_NOT_PROVIDED = object()


def _validated_optional_seed(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError("seed must be an integer or None")
    converted = int(value)
    if converted < 0:
        raise ValueError("seed must be nonnegative")
    return converted


def _finite_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    return converted


def _guard_planned_controller_value(
    value: float,
    *,
    lower: float,
    upper: float,
    eps_abs: float,
    eps_rel: float,
    quantity_name: str,
) -> float:
    if lower <= value <= upper:
        return value
    bound = lower if value < lower else upper
    tolerance = eps_abs + eps_rel * max(1.0, abs(value), abs(bound))
    if abs(value - bound) > tolerance:
        raise RuntimeError(
            "usable MPC prediction violates configured "
            f"{quantity_name} bounds"
        )
    return bound


def _cold_fallback_seed(
    rollout_seed: int | None,
    activation_index: int,
) -> int | None:
    if rollout_seed is None:
        return None
    state = np.random.SeedSequence(
        [rollout_seed, activation_index]
    ).generate_state(1, dtype=np.uint32)
    return int(state[0])


@dataclass(frozen=True, slots=True)
class _MPCControllerBeliefProvenance:
    model_source: str
    steering_angle_bounds_source: str
    steering_rate_bounds_source: str | None
    vehicle_body_width_source: str | None


@dataclass(frozen=True, slots=True)
class _MPCReferenceSchedule:
    reference_speeds_mps: np.ndarray
    soft_speed_upper_bounds_mps: np.ndarray | None
    reference_transition_index: int | None
    road_horizon_context: MPCRoadHorizonContext | None
    road_horizon_time_seconds: float


@dataclass(frozen=True, slots=True)
class _MPCModelSchedule:
    state_matrices: tuple[np.ndarray, ...]
    control_matrices: tuple[np.ndarray, ...]
    affine_offsets: tuple[np.ndarray, ...] | None


def _controller_belief_provenance(
    config: (
        AutonomousDrivingDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareSteeringRateMPCConfig
        | AutonomousDrivingSteeringRateMPCConfig
    ),
    *,
    explicit: bool,
) -> _MPCControllerBeliefProvenance:
    control_kind = _control_kind_for_config(config)
    is_road_aware = type(config) in (
        AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    )
    if explicit:
        model_source = "explicit"
        angle_source = "explicit"
        rate_source = (
            None
            if control_kind is _MPCControlKind.DIRECT_STEERING
            else "explicit"
        )
    else:
        model_source = (
            "initial_environment_default" if config.model is None else "explicit"
        )
        if control_kind is _MPCControlKind.DIRECT_STEERING:
            angle_source = (
                "initial_environment_default"
                if config.constraints.steering_angle_control_lower_radians is None
                else "explicit"
            )
            rate_source = None
        else:
            angle_source = (
                "initial_environment_default"
                if config.constraints.steering_angle_state_lower_radians is None
                else "explicit"
            )
            rate_source = (
                "initial_environment_default"
                if config.constraints.steering_rate_control_lower_radians_per_second
                is None
                else "explicit"
            )
    width = (
        config.constraints.vehicle_body_width_metres
        if is_road_aware
        else None
    )
    if width is not None:
        width_source = "explicit"
    elif (
        not explicit
        and is_road_aware
        and config.use_lane_bound_constraints
    ):
        width_source = "initial_environment_default"
    else:
        width_source = None
    return _MPCControllerBeliefProvenance(
        model_source=model_source,
        steering_angle_bounds_source=angle_source,
        steering_rate_bounds_source=rate_source,
        vehicle_body_width_source=width_source,
    )


def _configured_steering_bound_mismatches(
    controller_angle_bounds: tuple[float, float],
    plant_angle_bounds: tuple[float, float],
    controller_rate_bounds: tuple[float, float] | None,
    plant_rate_bounds: tuple[float, float],
) -> dict[str, tuple[float, float]]:
    angle_role = "control" if controller_rate_bounds is None else "state"
    comparisons = [
        (
            f"steering_angle_{angle_role}_lower_radians",
            controller_angle_bounds[0],
            plant_angle_bounds[0],
        ),
        (
            f"steering_angle_{angle_role}_upper_radians",
            controller_angle_bounds[1],
            plant_angle_bounds[1],
        ),
    ]
    if controller_rate_bounds is not None:
        comparisons.extend(
            (
                (
                    "steering_rate_control_lower_radians_per_second",
                    controller_rate_bounds[0],
                    plant_rate_bounds[0],
                ),
                (
                    "steering_rate_control_upper_radians_per_second",
                    controller_rate_bounds[1],
                    plant_rate_bounds[1],
                ),
            )
        )
    return {
        name: (controller_value, plant_value)
        for name, controller_value, plant_value in comparisons
        if not math.isclose(
            controller_value,
            plant_value,
            rel_tol=1.0e-12,
            abs_tol=1.0e-12,
        )
    }


def _build_binding_diagnostics(
    config: (
        AutonomousDrivingDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
        | AutonomousDrivingRoadAwareSteeringRateMPCConfig
        | AutonomousDrivingSteeringRateMPCConfig
    ),
    adapter: AutonomousDrivingMPCAdapter | None,
    provenance: _MPCControllerBeliefProvenance,
) -> MPCEnvironmentBindingDiagnostics:
    control_kind = _control_kind_for_config(config)
    model = config.model
    environment = config.environment
    assert model is not None
    assert environment is not None
    constraints = config.constraints
    if control_kind is _MPCControlKind.DIRECT_STEERING:
        controller_angle_bounds = (
            constraints.steering_angle_control_lower_radians,
            constraints.steering_angle_control_upper_radians,
        )
        controller_rate_bounds = None
    else:
        controller_angle_bounds = (
            constraints.steering_angle_state_lower_radians,
            constraints.steering_angle_state_upper_radians,
        )
        controller_rate_bounds = (
            constraints.steering_rate_control_lower_radians_per_second,
            constraints.steering_rate_control_upper_radians_per_second,
        )
    assert all(value is not None for value in controller_angle_bounds)
    if controller_rate_bounds is not None:
        assert all(value is not None for value in controller_rate_bounds)

    if adapter is None:
        plant_model = None
        plant_angle_bounds = None
        plant_rate_bounds = None
        model_parameter_mismatches = None
        configured_steering_bound_mismatches = None
    else:
        plant_model = adapter.plant_model
        assert plant_model is not None
        plant_environment = adapter.environment_config
        request_limit = plant_environment.steering_request_limit_radians
        request_offset = plant_environment.steering_offset_radians
        plant_angle_bounds = (
            request_offset - request_limit,
            request_offset + request_limit,
        )
        rate_lower = adapter.steering_rate_control_lower_radians_per_second
        rate_upper = adapter.steering_rate_control_upper_radians_per_second
        assert rate_lower is not None and rate_upper is not None
        plant_rate_bounds = (rate_lower, rate_upper)
        model_parameter_mismatches = adapter.model_parameter_mismatches(model)
        assert model_parameter_mismatches is not None
        configured_steering_bound_mismatches = (
            _configured_steering_bound_mismatches(
                controller_angle_bounds,
                plant_angle_bounds,
                controller_rate_bounds,
                plant_rate_bounds,
            )
        )

    is_road_aware = type(config) in (
        AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
        AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    )
    controller_width = (
        constraints.vehicle_body_width_metres if is_road_aware else None
    )
    if controller_width is None:
        plant_width = None
        width_source = None
        configured_width_mismatch = None
    else:
        plant_width = (
            None
            if adapter is None
            else adapter.environment_config.vehicle_body_width_metres
        )
        width_source = provenance.vehicle_body_width_source
        configured_width_mismatch = (
            None
            if plant_width is None
            or math.isclose(
                controller_width,
                plant_width,
                rel_tol=1.0e-12,
                abs_tol=1.0e-12,
            )
            else (controller_width, plant_width)
        )

    return MPCEnvironmentBindingDiagnostics(
        controller_model=model,
        plant_model=plant_model,
        environment=environment,
        controller_steering_angle_bounds_radians=controller_angle_bounds,
        plant_steering_angle_bounds_radians=plant_angle_bounds,
        controller_steering_rate_bounds_radians_per_second=controller_rate_bounds,
        plant_steering_rate_bounds_radians_per_second=plant_rate_bounds,
        model_source=provenance.model_source,
        steering_angle_bounds_source=provenance.steering_angle_bounds_source,
        steering_rate_bounds_source=provenance.steering_rate_bounds_source,
        model_parameter_mismatches=model_parameter_mismatches,
        configured_steering_bound_mismatches=(
            configured_steering_bound_mismatches
        ),
        controller_vehicle_body_width_metres=controller_width,
        plant_vehicle_body_width_metres=plant_width,
        vehicle_body_width_source=width_source,
        configured_vehicle_body_width_mismatch=configured_width_mismatch,
    )


class _AutonomousDrivingMPCPolicyBase(_AutonomousDrivingMPCPolicyMarker):
    """Shared environment binding, scheduling, results, and fallback lifecycle."""

    n_state: int
    n_control = 2

    def _initialize(
        self,
        config: (
            AutonomousDrivingDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareSteeringRateMPCConfig
            | AutonomousDrivingSteeringRateMPCConfig
        ),
    ) -> None:
        self._require_fully_resolved_config(config)
        self.config = config
        self._adapter = self._adapter_from_resolved_config(config)
        self._controller_belief_provenance = _controller_belief_provenance(
            config,
            explicit=True,
        )
        self._binding_diagnostics = _build_binding_diagnostics(
            config,
            None,
            self._controller_belief_provenance,
        )
        self._bound_environment_ref = None
        if config.fallback.mode is MPCFallbackMode.FALLBACK_POLICY:
            factory = config.fallback.policy_factory
            assert callable(factory)
            self._fallback_policy = factory()
            self._validate_cold_fallback_policy(self._fallback_policy)
        else:
            self._fallback_policy = None
        self.solver = LinearQuadraticMPCSolver(
            self.n_state,
            self.n_control,
            config.solver,
        )
        self.reset()

    @classmethod
    def _from_env(
        cls,
        env,
        config: (
            AutonomousDrivingDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareSteeringRateMPCConfig
            | AutonomousDrivingSteeringRateMPCConfig
        ),
    ):
        """Construct from a validated snapshot of an environment interface."""

        provenance = _controller_belief_provenance(config, explicit=False)
        required_fields = cls._required_observation_fields(config)
        resolved, adapter = resolve_policy_config_from_env(
            env,
            config,
            required_fields,
        )
        bound_environment_ref = weakref.ref(_unwrapped_environment(env))
        policy = cls(resolved)
        policy._controller_belief_provenance = provenance
        policy._adapter = adapter
        policy._binding_diagnostics = _build_binding_diagnostics(
            resolved,
            adapter,
            provenance,
        )
        policy._bind_cold_fallback_environment(env)
        policy._bound_environment_ref = bound_environment_ref
        return policy

    def _validate_cold_fallback_policy(self, policy) -> None:
        if policy is None or policy is self:
            raise TypeError(
                "owned fallback policy factory must return a distinct "
                "fallback policy"
            )

        required_hooks = (
            ("compute_action", (None, {}, False, False), {}),
            ("reset", (), {"seed": None}),
        )
        for name, args, kwargs in required_hooks:
            hook = getattr(policy, name, None)
            if not callable(hook):
                raise TypeError(
                    f"owned fallback policy must provide callable {name}"
                )
            try:
                inspect.signature(hook).bind(*args, **kwargs)
            except (TypeError, ValueError) as error:
                raise TypeError(
                    f"owned fallback policy {name} has an incompatible signature"
                ) from error

        missing = object()
        optional_hooks = (
            ("bind_environment", (None,), {}),
            (
                "record_applied_action",
                (),
                {
                    "drive_command": None,
                    "steering_rate": None,
                    "steering_angle": None,
                },
            ),
        )
        for name, args, kwargs in optional_hooks:
            hook = getattr(policy, name, missing)
            if hook is missing:
                continue
            if not callable(hook):
                raise TypeError(
                    f"owned fallback policy {name} must be callable when present"
                )
            try:
                inspect.signature(hook).bind(*args, **kwargs)
            except (TypeError, ValueError) as error:
                raise TypeError(
                    f"owned fallback policy {name} has an incompatible signature"
                ) from error

    def _bind_cold_fallback_environment(self, env) -> None:
        fallback_policy = self._fallback_policy
        if fallback_policy is None:
            return
        bind_environment = getattr(fallback_policy, "bind_environment", None)
        if bind_environment is not None:
            bind_environment(env)

    @staticmethod
    def _required_observation_fields(
        config: (
            AutonomousDrivingDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareSteeringRateMPCConfig
            | AutonomousDrivingSteeringRateMPCConfig
        ),
    ) -> tuple[str, ...]:
        required = _BASE_REQUIRED_OBSERVATION_FIELDS
        if config.linearization_strategy is MPCSpeedLinearizationStrategy.SPEED_LIMIT:
            required += ("speed_limit_mps",)
        return required

    @staticmethod
    def _require_fully_resolved_config(
        config: (
            AutonomousDrivingDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareSteeringRateMPCConfig
            | AutonomousDrivingSteeringRateMPCConfig
        ),
    ) -> None:
        control_kind = _control_kind_for_config(config)
        if config.environment is None or config.model is None:
            raise ValueError(
                "explicit policy construction requires a fully resolved "
                "environment and model config"
            )
        constraints = config.constraints
        if control_kind is _MPCControlKind.DIRECT_STEERING:
            actuator_values = (
                constraints.steering_angle_control_lower_radians,
                constraints.steering_angle_control_upper_radians,
            )
        else:
            actuator_values = (
                constraints.steering_angle_state_lower_radians,
                constraints.steering_angle_state_upper_radians,
                constraints.steering_rate_control_lower_radians_per_second,
                constraints.steering_rate_control_upper_radians_per_second,
            )
        if any(value is None for value in actuator_values):
            raise ValueError(
                "explicit policy construction requires fully resolved actuator bounds"
            )
        if (
            type(config)
            in (
                AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
                AutonomousDrivingRoadAwareSteeringRateMPCConfig,
            )
            and config.use_lane_bound_constraints
            and constraints.vehicle_body_width_metres is None
        ):
            raise ValueError(
                "explicit policy construction with lane-bound constraints "
                "requires a resolved vehicle_body_width_metres"
            )
        environment = config.environment
        if environment.action_lower_bounds != (-1.0, -1.0) or (
            environment.action_upper_bounds != (1.0, 1.0)
        ):
            raise ValueError("MPC requires the full normalized two-axis action bounds")
        required = _AutonomousDrivingMPCPolicyBase._required_observation_fields(
            config
        )
        missing = [
            name for name in required if name not in environment.observation_names
        ]
        if missing:
            raise ValueError(
                ", ".join(missing)
                + " must be agent-visible observation fields routed through obs"
            )
        _require_observation_layout(environment, required)

    @classmethod
    def _adapter_from_resolved_config(
        cls,
        config: (
            AutonomousDrivingDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareDirectSteeringMPCConfig
            | AutonomousDrivingRoadAwareSteeringRateMPCConfig
            | AutonomousDrivingSteeringRateMPCConfig
        ),
    ) -> AutonomousDrivingMPCAdapter:
        return AutonomousDrivingMPCAdapter(
            environment_config=config.environment,
            plant_model=None,
            required_fields=cls._required_observation_fields(config),
            steering_rate_control_lower_radians_per_second=None,
            steering_rate_control_upper_radians_per_second=None,
        )

    @property
    def rollout_seed(self) -> int | None:
        return self._rollout_seed

    @overload
    def bind_environment(self, env) -> None:
        return None

    @overload
    def bind_environment(self, env, *, seed: int | None) -> None:
        return None

    def bind_environment(
        self,
        env,
        *,
        seed=_BIND_SEED_NOT_PROVIDED,
    ) -> None:
        """Refresh environment interface facts while preserving model beliefs."""

        candidate_seed = (
            self._rollout_seed
            if seed is _BIND_SEED_NOT_PROVIDED
            else _validated_optional_seed(seed)
        )
        candidate_adapter = AutonomousDrivingMPCAdapter.from_env(
            env,
            self._required_observation_fields(self.config),
        )
        candidate_adapter._validate_model_timestep(self.config.model)
        _validate_configured_constant_fallback_action(env, self.config)
        candidate_config = replace(
            self.config,
            environment=candidate_adapter.environment_config,
        )
        self._require_fully_resolved_config(candidate_config)
        candidate_diagnostics = _build_binding_diagnostics(
            candidate_config,
            candidate_adapter,
            self._controller_belief_provenance,
        )
        candidate_environment_ref = weakref.ref(_unwrapped_environment(env))
        candidate_fallback_policy = None
        if candidate_config.fallback.mode is MPCFallbackMode.FALLBACK_POLICY:
            factory = candidate_config.fallback.policy_factory
            assert callable(factory)
            candidate_fallback_policy = factory()
            self._validate_cold_fallback_policy(candidate_fallback_policy)
            if candidate_fallback_policy is self._fallback_policy:
                raise TypeError(
                    "owned fallback policy factory must return a distinct "
                    "fallback policy for rebinding"
                )
            bind_environment = getattr(
                candidate_fallback_policy,
                "bind_environment",
                None,
            )
            if bind_environment is not None:
                bind_environment(env)

        self.config = candidate_config
        self._adapter = candidate_adapter
        self._binding_diagnostics = candidate_diagnostics
        self._bound_environment_ref = candidate_environment_ref
        self._fallback_policy = candidate_fallback_policy
        self.reset(seed=candidate_seed)

    def _validate_rollout_continuation(self, env) -> None:
        environment_ref = self._bound_environment_ref
        bound_environment = (
            None if environment_ref is None else environment_ref()
        )
        current_environment = _unwrapped_environment(env)
        if bound_environment is None or current_environment is not bound_environment:
            raise RuntimeError(
                "MPC rollout continuation requires the same unwrapped "
                "environment object"
            )

        try:
            fresh_adapter = AutonomousDrivingMPCAdapter.from_env(
                env,
                self._required_observation_fields(self.config),
            )
            fresh_adapter._validate_model_timestep(self.config.model)
            fresh_config = replace(
                self.config,
                environment=fresh_adapter.environment_config,
            )
            self._require_fully_resolved_config(fresh_config)
            fresh_diagnostics = _build_binding_diagnostics(
                fresh_config,
                fresh_adapter,
                self._controller_belief_provenance,
            )
        except (TypeError, ValueError) as error:
            raise RuntimeError(
                "MPC rollout environment binding facts changed: "
                + str(error)
            ) from error
        if not _mpc_environment_interfaces_match(
            fresh_adapter.environment_config,
            self._adapter.environment_config,
        ):
            raise RuntimeError(
                "MPC rollout environment interface changed after binding"
            )
        if fresh_adapter.plant_model != self._adapter.plant_model:
            raise RuntimeError(
                "MPC rollout plant model changed after binding"
            )
        if (
            fresh_adapter.steering_rate_control_lower_radians_per_second
            != self._adapter.steering_rate_control_lower_radians_per_second
            or fresh_adapter.steering_rate_control_upper_radians_per_second
            != self._adapter.steering_rate_control_upper_radians_per_second
        ):
            raise RuntimeError(
                "MPC rollout steering-rate bounds changed after binding"
            )
        fresh_action_space = fresh_adapter.action_space
        committed_action_space = self._adapter.action_space
        assert fresh_action_space is not None
        assert committed_action_space is not None
        if (
            fresh_action_space.dtype != committed_action_space.dtype
            or not np.array_equal(
                fresh_action_space.low,
                committed_action_space.low,
            )
            or not np.array_equal(
                fresh_action_space.high,
                committed_action_space.high,
            )
        ):
            raise RuntimeError(
                "MPC rollout action space changed after binding"
            )
        diagnostics_without_refreshed_environment = replace(
            fresh_diagnostics,
            environment=self._binding_diagnostics.environment,
        )
        if diagnostics_without_refreshed_environment != self._binding_diagnostics:
            raise RuntimeError(
                "MPC rollout binding diagnostics changed after binding"
            )
        self._validate_bound_environment_action_ownership()

    def _validate_bound_environment_action_ownership(self) -> None:
        environment_ref = self._bound_environment_ref
        if environment_ref is None:
            return
        environment = environment_ref()
        if environment is None:
            raise RuntimeError(
                "MPC bound environment is unavailable; action ownership "
                "can no longer be verified"
            )
        enabled = _enabled_internal_controller_names(environment)
        if enabled:
            raise RuntimeError(
                "MPC requires internal lane keeping and cruise control "
                "to remain disabled; enabled: " + ", ".join(enabled)
            )

    def reset(self, seed=None) -> None:
        """Clear all cross-call prediction, action, and failure state."""

        validated_seed = _validated_optional_seed(seed)
        self._rollout_seed = validated_seed
        self._fallback_activation_index = 0
        self._fallback_episode_active = False
        self._last_emitted_action_from_nested_fallback = False
        self.last_result: MPCPolicyResult | None = None
        self.last_problem: LinearQuadraticMPCProblem | None = None
        self._previous_predicted_states: np.ndarray | None = None
        self._previous_predicted_controls: np.ndarray | None = None
        self._last_emitted_action: np.ndarray | None = None
        self._applied_drive_command: float | None = None
        self._applied_steering_rate: float | None = None
        self._applied_steering_angle: float | None = None
        self._control_step_index = 0

    def record_applied_action(
        self,
        *,
        drive_command,
        steering_rate,
        steering_angle,
    ) -> None:
        """Record the actual model-space control applied by the environment."""

        validated_drive = _finite_float("drive_command", drive_command)
        validated_rate = _finite_float("steering_rate", steering_rate)
        validated_angle = _finite_float("steering_angle", steering_angle)
        self._applied_drive_command = validated_drive
        self._applied_steering_rate = validated_rate
        self._applied_steering_angle = validated_angle
        if self._last_emitted_action_from_nested_fallback:
            fallback_policy = self._fallback_policy
            assert fallback_policy is not None
            record_applied_action = getattr(
                fallback_policy,
                "record_applied_action",
                None,
            )
            if record_applied_action is not None:
                record_applied_action(
                    drive_command=validated_drive,
                    steering_rate=validated_rate,
                    steering_angle=validated_angle,
                )

    @property
    def previous_predicted_states(self) -> np.ndarray | None:
        if self._previous_predicted_states is None:
            return None
        return self._previous_predicted_states.copy()

    @property
    def previous_predicted_controls(self) -> np.ndarray | None:
        if self._previous_predicted_controls is None:
            return None
        return self._previous_predicted_controls.copy()

    @property
    def last_emitted_action(self) -> np.ndarray | None:
        if self._last_emitted_action is None:
            return None
        return self._last_emitted_action.copy()

    @property
    def binding_diagnostics(self) -> MPCEnvironmentBindingDiagnostics:
        return self._binding_diagnostics

    @property
    def applied_action(self) -> np.ndarray | None:
        values = (
            self._applied_drive_command,
            self._applied_steering_rate,
            self._applied_steering_angle,
        )
        if any(value is None for value in values):
            return None
        return np.array(values, dtype=np.float64)

    @property
    def control_step_index(self) -> int:
        return self._control_step_index

    def compute_action(
        self,
        observation,
        info_dict,
        terminated,
        truncated,
    ) -> np.ndarray:
        """Compute and return only the full Gymnasium action."""

        result = self.compute_action_result(
            observation,
            info_dict,
            terminated,
            truncated,
        )
        action = result.environment_action
        assert action is not None
        return action

    def compute_action_result(
        self,
        observation,
        info_dict,
        terminated,
        truncated,
    ) -> MPCPolicyResult:
        """Solve one MPC problem and return its complete structured outcome."""

        self._validate_bound_environment_action_ownership()
        del info_dict  # Control inputs deliberately come only from observation.
        if not isinstance(terminated, (bool, np.bool_)):
            raise TypeError("terminated must be a bool")
        if not isinstance(truncated, (bool, np.bool_)):
            raise TypeError("truncated must be a bool")
        terminated = bool(terminated)
        truncated = bool(truncated)

        total_start = perf_counter()
        decoded = self._adapter.decode_observation(observation)
        initial_state = self._initial_state(decoded)
        horizon = self.config.horizon_steps

        if (
            self._previous_predicted_states is None
            or self._previous_predicted_controls is None
        ):
            progress_states = np.tile(initial_state, (horizon + 1, 1))
            progress_controls = np.zeros(
                (horizon, self.n_control), dtype=np.float64
            )
        else:
            progress_states = self._previous_predicted_states
            progress_controls = self._previous_predicted_controls
        progress_schedule = predict_relative_progress(
            self.config.model,
            progress_states,
            progress_controls,
        )
        try:
            reference_schedule = self._build_reference_schedule(
                decoded=decoded,
                progress_schedule=progress_schedule,
                observation=observation,
            )
        except _MPCPolicyInputError as error:
            return self._complete_pre_solver_failure(
                decoded=decoded,
                initial_state=initial_state,
                progress_schedule=progress_schedule,
                failure=error.failure,
                observation=observation,
                terminated=terminated,
                truncated=truncated,
                road_horizon_time_seconds=(
                    error.road_horizon_time_seconds
                ),
                total_start=total_start,
            )

        linearization_speeds = None
        try:
            model_schedule_start = perf_counter()
            linearization_speeds = build_linearization_speed_schedule(
                self.config.linearization_strategy,
                horizon,
                decoded,
                reference_schedule.reference_speeds_mps,
                self._previous_predicted_states,
                self.config.fixed_linearization_speed_mps,
            )
            model_schedule = self._build_model_schedule(
                linearization_speeds=linearization_speeds,
                road_horizon_context=(
                    reference_schedule.road_horizon_context
                ),
            )
            model_schedule_time = perf_counter() - model_schedule_start

            problem = self._build_problem(
                initial_state=initial_state,
                state_matrices=model_schedule.state_matrices,
                control_matrices=model_schedule.control_matrices,
                affine_offsets=model_schedule.affine_offsets,
                reference_speeds=reference_schedule.reference_speeds_mps,
                soft_speed_upper_bounds=(
                    reference_schedule.soft_speed_upper_bounds_mps
                ),
                road_horizon_context=(
                    reference_schedule.road_horizon_context
                ),
            )
        except _MPCPolicyInputError as error:
            return self._complete_pre_solver_failure(
                decoded=decoded,
                initial_state=initial_state,
                progress_schedule=progress_schedule,
                failure=error.failure,
                observation=observation,
                terminated=terminated,
                truncated=truncated,
                road_horizon_time_seconds=(
                    reference_schedule.road_horizon_time_seconds
                ),
                reference_schedule=reference_schedule,
                linearization_speeds=linearization_speeds,
                total_start=total_start,
            )
        self.last_problem = problem
        self.solver.set_problem(problem)
        solve_result = self.solver.solve()
        postprocessing_start = perf_counter()
        if not isinstance(solve_result, MPCSolveResult):
            raise TypeError("solver.solve() must return an MPCSolveResult")
        self._validate_present_prediction_shapes(solve_result)

        fallback_mode = None if solve_result.usable else self.config.fallback.mode
        if solve_result.usable:
            prediction = solve_result.prediction
            assert prediction is not None
            first_control = prediction.controls[0]
            constraints = self.config.constraints
            guarded_drive_command = _guard_planned_controller_value(
                float(first_control[0]),
                lower=constraints.normalized_drive_command_control_lower,
                upper=constraints.normalized_drive_command_control_upper,
                eps_abs=self.config.solver.absolute_tolerance,
                eps_rel=self.config.solver.relative_tolerance,
                quantity_name="drive-command",
            )
            requested_steering_angle = (
                self._requested_steering_angle_from_first_control(
                    first_control,
                    decoded,
                )
            )
            requested_steering_angle = (
                self._controller_validated_steering_angle(
                    first_control,
                    decoded,
                    requested_steering_angle,
                )
            )
            action_request = self._build_action_request(
                planned_model_control=first_control,
                requested_steering_angle_radians=requested_steering_angle,
                normalized_action_before_clipping=np.array(
                    [
                        guarded_drive_command,
                        self._adapter.steering_angle_to_normalized_request(
                            requested_steering_angle
                        ),
                    ],
                    dtype=np.float64,
                ),
            )
            fallback_action_used = False
            self._fallback_episode_active = False
            self._previous_predicted_states = prediction.states.copy()
            self._previous_predicted_controls = prediction.controls.copy()
        else:
            self._previous_predicted_states = None
            self._previous_predicted_controls = None
            if fallback_mode is MPCFallbackMode.RAISE:
                action_request = None
                fallback_action_used = False
            else:
                fallback_action = self._fallback_action(
                    solve_result=solve_result,
                    failure=None,
                    decoded=decoded,
                    observation=observation,
                    terminated=terminated,
                    truncated=truncated,
                )
                if fallback_mode is MPCFallbackMode.FALLBACK_POLICY:
                    fallback_action = self._validate_nested_fallback_action(
                        fallback_action
                    )
                else:
                    fallback_action = self._validated_fallback_action(
                        fallback_action,
                        require_in_space=(
                            fallback_mode is MPCFallbackMode.CONSTANT_ACTION
                        ),
                    )
                requested_steering_angle = (
                    self.config.environment.steering_offset_radians
                    + self.config.environment.steering_request_limit_radians
                    * fallback_action[1]
                )
                action_request = self._build_action_request(
                    planned_model_control=None,
                    requested_steering_angle_radians=requested_steering_angle,
                    normalized_action_before_clipping=fallback_action,
                )
                fallback_action_used = True

        result = MPCPolicyResult(
            solve_result=solve_result,
            failure=None,
            action_request=action_request,
            fallback_mode=fallback_mode,
            fallback_action_used=fallback_action_used,
            initial_state=initial_state,
            progress_schedule_metres=progress_schedule,
            reference_speeds_mps=reference_schedule.reference_speeds_mps,
            soft_speed_upper_bounds_mps=(
                reference_schedule.soft_speed_upper_bounds_mps
            ),
            linearization_speeds_mps=linearization_speeds,
            reference_transition_index=(
                reference_schedule.reference_transition_index
            ),
            road_horizon_context=reference_schedule.road_horizon_context,
            control_step_index=self._control_step_index,
            terminated=terminated,
            truncated=truncated,
            road_horizon_time_seconds=(
                reference_schedule.road_horizon_time_seconds
            ),
            model_schedule_time_seconds=model_schedule_time,
            postprocessing_time_seconds=0.0,
            total_time_seconds=0.0,
        )
        self._control_step_index += 1
        should_raise = fallback_mode is MPCFallbackMode.RAISE
        if action_request is not None:
            self._last_emitted_action = action_request.environment_action.copy()
            self._last_emitted_action_from_nested_fallback = (
                fallback_mode is MPCFallbackMode.FALLBACK_POLICY
            )
        self.last_result = result
        final_time = perf_counter()
        object.__setattr__(
            result,
            "postprocessing_time_seconds",
            final_time - postprocessing_start,
        )
        object.__setattr__(
            result,
            "total_time_seconds",
            final_time - total_start,
        )

        if should_raise:
            raise _MPCConfiguredRaiseError(
                policy_result=result,
                problem=problem,
            )
        return result

    def _complete_pre_solver_failure(
        self,
        *,
        decoded: MPCObservation,
        initial_state: np.ndarray,
        progress_schedule: np.ndarray,
        failure: MPCPolicyFailure,
        observation,
        terminated: bool,
        truncated: bool,
        road_horizon_time_seconds: float,
        reference_schedule: _MPCReferenceSchedule | None = None,
        linearization_speeds: np.ndarray | None = None,
        total_start: float,
    ) -> MPCPolicyResult:
        """Complete one classified failure without fabricating a solve."""

        postprocessing_start = perf_counter()
        self.last_problem = None
        self._previous_predicted_states = None
        self._previous_predicted_controls = None
        fallback_mode = self.config.fallback.mode
        if fallback_mode is MPCFallbackMode.RAISE:
            action_request = None
            fallback_action_used = False
        else:
            fallback_action = self._fallback_action(
                solve_result=None,
                failure=failure,
                decoded=decoded,
                observation=observation,
                terminated=terminated,
                truncated=truncated,
            )
            if fallback_mode is MPCFallbackMode.FALLBACK_POLICY:
                fallback_action = self._validate_nested_fallback_action(
                    fallback_action
                )
            else:
                fallback_action = self._validated_fallback_action(
                    fallback_action,
                    require_in_space=(
                        fallback_mode is MPCFallbackMode.CONSTANT_ACTION
                    ),
                )
            requested_steering_angle = (
                self.config.environment.steering_offset_radians
                + self.config.environment.steering_request_limit_radians
                * fallback_action[1]
            )
            action_request = self._build_action_request(
                planned_model_control=None,
                requested_steering_angle_radians=requested_steering_angle,
                normalized_action_before_clipping=fallback_action,
            )
            fallback_action_used = True

        result = MPCPolicyResult(
            solve_result=None,
            failure=failure,
            action_request=action_request,
            fallback_mode=fallback_mode,
            fallback_action_used=fallback_action_used,
            initial_state=initial_state,
            progress_schedule_metres=progress_schedule,
            reference_speeds_mps=(
                None
                if reference_schedule is None
                else reference_schedule.reference_speeds_mps
            ),
            soft_speed_upper_bounds_mps=(
                None
                if reference_schedule is None
                else reference_schedule.soft_speed_upper_bounds_mps
            ),
            linearization_speeds_mps=linearization_speeds,
            reference_transition_index=(
                None
                if reference_schedule is None
                else reference_schedule.reference_transition_index
            ),
            road_horizon_context=(
                None
                if reference_schedule is None
                else reference_schedule.road_horizon_context
            ),
            control_step_index=self._control_step_index,
            terminated=terminated,
            truncated=truncated,
            road_horizon_time_seconds=road_horizon_time_seconds,
            model_schedule_time_seconds=0.0,
            postprocessing_time_seconds=0.0,
            total_time_seconds=0.0,
        )
        self._control_step_index += 1
        if action_request is not None:
            self._last_emitted_action = action_request.environment_action.copy()
            self._last_emitted_action_from_nested_fallback = (
                fallback_mode is MPCFallbackMode.FALLBACK_POLICY
            )
        self.last_result = result
        final_time = perf_counter()
        object.__setattr__(
            result,
            "postprocessing_time_seconds",
            final_time - postprocessing_start,
        )
        object.__setattr__(
            result,
            "total_time_seconds",
            final_time - total_start,
        )
        if fallback_mode is MPCFallbackMode.RAISE:
            raise _MPCConfiguredRaiseError(
                policy_result=result,
                problem=None,
            )
        return result

    def _validate_present_prediction_shapes(self, result: MPCSolveResult) -> None:
        """Validate policy-specific dimensions for a present prediction."""

        prediction = result.prediction
        if prediction is None:
            return
        horizon = self.config.horizon_steps
        expected_shapes = (
            ("states", prediction.states, (horizon + 1, self.n_state)),
            ("controls", prediction.controls, (horizon, self.n_control)),
        )
        for name, values, expected_shape in expected_shapes:
            if values.shape != expected_shape:
                raise ValueError(
                    "solver prediction array "
                    f"{name} must have shape {expected_shape}, got {values.shape}"
                )

    def _controller_validated_steering_angle(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
        requested_steering_angle_radians: float,
    ) -> float:
        raise NotImplementedError

    def _build_action_request(
        self,
        *,
        planned_model_control: np.ndarray | None,
        requested_steering_angle_radians: float,
        normalized_action_before_clipping: np.ndarray,
    ) -> MPCActionRequest:
        try:
            raw = np.asarray(
                normalized_action_before_clipping,
                dtype=np.float64,
            )
        except (TypeError, ValueError) as error:
            raise ValueError("normalized action must be a numeric vector") from error
        if raw.shape != (2,):
            raise ValueError("normalized action must have shape (2,)")
        if not np.isfinite(raw).all():
            raise ValueError("normalized action must be finite")

        action_space = self._adapter.action_space
        assert action_space is not None
        emitted = _expected_environment_action(
            raw,
            action_space.dtype,
        )
        drive_was_clipped, steering_was_clipped = (
            _expected_action_clipping_flags(raw)
        )
        return MPCActionRequest(
            planned_model_control=planned_model_control,
            requested_steering_angle_radians=requested_steering_angle_radians,
            normalized_action_before_clipping=raw,
            environment_action=emitted,
            drive_command_was_clipped=drive_was_clipped,
            steering_command_was_clipped=steering_was_clipped,
        )

    def _validated_fallback_action(
        self,
        action,
        *,
        require_in_space: bool,
    ) -> np.ndarray:
        try:
            values = np.asarray(action, dtype=np.float64)
        except (TypeError, ValueError) as error:
            raise ValueError("fallback action must be a numeric vector") from error
        if values.shape != (2,):
            raise ValueError("fallback action must have shape (2,)")
        if not np.isfinite(values).all():
            raise ValueError("fallback action must be finite")
        lower = np.asarray(
            self.config.environment.action_lower_bounds,
            dtype=np.float64,
        )
        upper = np.asarray(
            self.config.environment.action_upper_bounds,
            dtype=np.float64,
        )
        drive_outside = values[0] < lower[0] or values[0] > upper[0]
        if drive_outside or (
            require_in_space
            and (np.any(values < lower) or np.any(values > upper))
        ):
            raise ValueError(
                "fallback action must be inside the environment action space"
            )
        return values.copy()

    def _validate_nested_fallback_action(self, action) -> np.ndarray:
        try:
            candidate = np.asarray(action)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "fallback policy action must be a real numeric vector"
            ) from error
        if candidate.shape != (2,):
            raise ValueError("fallback policy action must have shape (2,)")
        if not np.issubdtype(candidate.dtype, np.number) or np.issubdtype(
            candidate.dtype,
            np.complexfloating,
        ):
            raise ValueError(
                "fallback policy action must be a real numeric vector"
            )
        if not np.isfinite(candidate).all():
            raise ValueError("fallback policy action must be finite")
        action_space = self._adapter.action_space
        assert action_space is not None
        if not action_space.contains(candidate):
            raise ValueError(
                "fallback policy action must be inside the exact current "
                "environment action space"
            )
        return np.array(candidate, dtype=np.float64, copy=True)

    def _steering_hold_action(self, decoded: MPCObservation) -> np.ndarray:
        steering_request = self._adapter.steering_angle_to_normalized_request(
            decoded.steering_angle_radians
        )
        return np.array([0.0, steering_request], dtype=np.float64)

    def _fallback_action(
        self,
        *,
        solve_result: MPCSolveResult | None,
        failure: MPCPolicyFailure | None,
        decoded: MPCObservation,
        observation,
        terminated: bool,
        truncated: bool,
    ) -> np.ndarray:
        mode = self.config.fallback.mode
        if mode is MPCFallbackMode.HOLD_PREVIOUS_ACTION:
            if self._last_emitted_action is not None:
                return self._last_emitted_action.copy()
            return self._steering_hold_action(decoded)
        if mode is MPCFallbackMode.ZERO_ACTION:
            return np.zeros(2, dtype=np.float64)
        if mode is MPCFallbackMode.ZERO_DRIVE_HOLD_STEERING:
            return self._steering_hold_action(decoded)
        if mode is MPCFallbackMode.CONSTANT_ACTION:
            return np.asarray(
                self.config.fallback.constant_environment_action,
                dtype=np.float64,
            )
        if mode is MPCFallbackMode.FALLBACK_POLICY:
            fallback_policy = self._fallback_policy
            assert fallback_policy is not None
            if not self._fallback_episode_active:
                seed = _cold_fallback_seed(
                    self._rollout_seed,
                    self._fallback_activation_index,
                )
                reset = getattr(fallback_policy, "reset", None)
                assert callable(reset)
                reset(seed=seed)
                self._fallback_activation_index += 1
                self._fallback_episode_active = True
            compute_action = getattr(fallback_policy, "compute_action", None)
            assert callable(compute_action)
            return compute_action(
                observation,
                {},
                terminated,
                truncated,
            )
        if solve_result is not None:
            detail = f"solver status {solve_result.status!r}"
        elif failure is not None:
            detail = f"policy failure {failure.reason!r}"
        else:
            detail = "an unavailable outcome"
        raise RuntimeError("unsupported fallback mode for " + detail)

    def _initial_state(self, observation: MPCObservation) -> np.ndarray:
        raise NotImplementedError

    def _build_reference_schedule(
        self,
        *,
        decoded: MPCObservation,
        progress_schedule: np.ndarray,
        observation,
    ) -> _MPCReferenceSchedule:
        del observation
        reference_speeds, soft_speed_bounds, transition_index = (
            build_recommended_speed_schedules(
                progress_schedule,
                decoded.recommended_speed_mps,
                decoded.next_recommended_speed_mps,
                decoded.distance_to_next_recommended_speed_metres,
                self.config.constraints.recommended_speed_soft_upper_margin_mps,
            )
        )
        return _MPCReferenceSchedule(
            reference_speeds_mps=reference_speeds,
            soft_speed_upper_bounds_mps=soft_speed_bounds,
            reference_transition_index=transition_index,
            road_horizon_context=None,
            road_horizon_time_seconds=0.0,
        )

    def _build_model_schedule(
        self,
        *,
        linearization_speeds: np.ndarray,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> _MPCModelSchedule:
        raise NotImplementedError

    def _build_problem(
        self,
        *,
        initial_state: np.ndarray,
        state_matrices: tuple[np.ndarray, ...],
        control_matrices: tuple[np.ndarray, ...],
        affine_offsets: tuple[np.ndarray, ...] | None,
        reference_speeds: np.ndarray,
        soft_speed_upper_bounds: np.ndarray | None,
        road_horizon_context: MPCRoadHorizonContext | None,
    ) -> LinearQuadraticMPCProblem:
        raise NotImplementedError

    def _requested_steering_angle_from_first_control(
        self,
        first_control: np.ndarray,
        observation: MPCObservation,
    ) -> float:
        raise NotImplementedError
