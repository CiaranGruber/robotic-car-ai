"""Dependency-light contracts and lazy autonomous-driving policies."""

from importlib import import_module
from typing import TYPE_CHECKING

from dreamgym.policies.autonomous_driving.mpc_config import (
    AutonomousDrivingDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareDirectSteeringMPCConfig,
    AutonomousDrivingRoadAwareSteeringRateMPCConfig,
    AutonomousDrivingSteeringRateMPCConfig,
    DirectSteeringMPCConstraintConfig,
    DirectSteeringMPCObjectiveConfig,
    KinematicBicycleMPCModelConfig,
    MPCEnvironmentConfig,
    MPCFallbackConfig,
    MPCFallbackMode,
    MPCRoadPreviewExtensionMode,
    MPCSpeedLinearizationStrategy,
    RoadAwareDirectSteeringMPCConstraintConfig,
    RoadAwareSteeringRateMPCConstraintConfig,
    SteeringRateMPCConstraintConfig,
    SteeringRateMPCObjectiveConfig,
)
from dreamgym.policies.autonomous_driving.mpc_results import (
    MPCActionRequest,
    MPCEnvironmentBindingDiagnostics,
    MPCPolicyFailure,
    MPCPolicyFailureStage,
    MPCPolicyResult,
    MPCRoadHorizonContext,
)
from dreamgym.policies.autonomous_driving.pid import PIDPolicyForAutonomousDriving
from dreamgym.policies.autonomous_driving.rl import RLPolicy

if TYPE_CHECKING:
    from dreamgym.policies.autonomous_driving.mpc import (
        AutonomousDrivingDirectSteeringMPCPolicy,
        AutonomousDrivingSteeringRateMPCPolicy,
    )
    from dreamgym.policies.autonomous_driving.road_aware_mpc import (
        AutonomousDrivingRoadAwareDirectSteeringMPCPolicy,
        AutonomousDrivingRoadAwareSteeringRateMPCPolicy,
    )

__all__ = [
    "AutonomousDrivingDirectSteeringMPCConfig",
    "AutonomousDrivingDirectSteeringMPCPolicy",
    "AutonomousDrivingRoadAwareDirectSteeringMPCConfig",
    "AutonomousDrivingRoadAwareDirectSteeringMPCPolicy",
    "AutonomousDrivingRoadAwareSteeringRateMPCConfig",
    "AutonomousDrivingRoadAwareSteeringRateMPCPolicy",
    "AutonomousDrivingSteeringRateMPCConfig",
    "AutonomousDrivingSteeringRateMPCPolicy",
    "DirectSteeringMPCConstraintConfig",
    "DirectSteeringMPCObjectiveConfig",
    "KinematicBicycleMPCModelConfig",
    "MPCActionRequest",
    "MPCEnvironmentBindingDiagnostics",
    "MPCEnvironmentConfig",
    "MPCFallbackConfig",
    "MPCFallbackMode",
    "MPCPolicyFailure",
    "MPCPolicyFailureStage",
    "MPCPolicyResult",
    "MPCRoadHorizonContext",
    "MPCRoadPreviewExtensionMode",
    "MPCSpeedLinearizationStrategy",
    "PIDPolicyForAutonomousDriving",
    "RLPolicy",
    "RoadAwareDirectSteeringMPCConstraintConfig",
    "RoadAwareSteeringRateMPCConstraintConfig",
    "SteeringRateMPCConstraintConfig",
    "SteeringRateMPCObjectiveConfig",
]

_LAZY_EXPORTS = {
    "AutonomousDrivingDirectSteeringMPCPolicy": (
        "dreamgym.policies.autonomous_driving.mpc",
        "AutonomousDrivingDirectSteeringMPCPolicy",
    ),
    "AutonomousDrivingRoadAwareDirectSteeringMPCPolicy": (
        "dreamgym.policies.autonomous_driving.road_aware_mpc",
        "AutonomousDrivingRoadAwareDirectSteeringMPCPolicy",
    ),
    "AutonomousDrivingRoadAwareSteeringRateMPCPolicy": (
        "dreamgym.policies.autonomous_driving.road_aware_mpc",
        "AutonomousDrivingRoadAwareSteeringRateMPCPolicy",
    ),
    "AutonomousDrivingSteeringRateMPCPolicy": (
        "dreamgym.policies.autonomous_driving.mpc",
        "AutonomousDrivingSteeringRateMPCPolicy",
    ),
}


def __getattr__(name: str):
    if name not in _LAZY_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute_name = _LAZY_EXPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attribute_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Include unresolved lazy exports in interactive introspection."""

    return sorted(set(globals()) | set(_LAZY_EXPORTS))
