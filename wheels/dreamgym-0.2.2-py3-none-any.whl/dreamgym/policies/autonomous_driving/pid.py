#!/usr/bin/env python

import numpy as np

class PIDPolicyForAutonomousDriving:
    """
    A proportional teaching baseline for autonomous driving.

    It combines proportional speed control, curvature-based speed-reference
    adjustment, and speed-scheduled proportional steering for target-line
    tracking. It does not implement integral or derivative feedback.
    """

    def __init__(self, delta_request_max=np.pi / 4.0):
        """
        Initialization function for the "PIDPolicyForAutonomousDriving" class.
        """
        self.integral_of_speed_error = 0.0
        self.integral_of_offset_error = 0.0
        self.delta_request_max = float(delta_request_max)


    def reset(self, seed=None) -> None:
        del seed
        self.integral_of_speed_error = 0.0
        self.integral_of_offset_error = 0.0


    def compute_action(self, observation, info_dict, terminated, truncated):
        # Get the "info_dict" observation of the curvature at the closest point on the road
        curvature_at_closest = observation["target_line_curvature_per_m"][0]
        # Get the "info_dict" observation of the curvature at the progress queries to the line
        look_ahead_curvature = observation[
            "target_line_lookahead_curvatures_per_m"
        ][0]
        
        if (terminated):
            # Zero speed reference after reaching the end of the road
            speed_ref = 0.0
        else:
            # Speed reference relative to look-ahead curvature
            if np.isnan(look_ahead_curvature):
                speed_ref = 20.0/3.6
            else:
                curvature_for_speed_ref = abs(look_ahead_curvature)
                if ( abs(curvature_at_closest) >= abs(look_ahead_curvature) ):
                    curvature_for_speed_ref = abs(curvature_at_closest)

                speed_ref = 60.0/3.6 - curvature_for_speed_ref * (50.0) * (40/3.6)
                speed_ref = max(speed_ref,20.0/3.6)

        # Get the observation of the signed lateral error from the target line
        dist_to_line = observation["lateral_error_from_target_line_m"][0]

        # Compute the speed of the car
        speed = np.sqrt(
            observation["ground_truth_body_longitudinal_velocity_mps"][0]**2
            + observation["ground_truth_body_lateral_velocity_mps"][0]**2
        ) * np.sign(
            observation["ground_truth_body_longitudinal_velocity_mps"][0]
        )
        # Compute the error between the reference and actual speed
        speed_error = speed_ref - speed
        # Compute the drive command action
        drive_command_raw = 0.02 * speed_error
        # Clip the drive command action to be in the normalized range [-1,1]
        drive_command_clipped = max(-1.0, min(drive_command_raw, 1.0))

        # Adjust the steering gain based on the speed
        #kp_steering = 2.0
        kp_steering = -(2.0 / (40.0/3.6)) * speed + 0.5 + ((2.0 / (40.0/3.6)) * (60.0/3.6))
        kp_steering = max( 0.5 , min( 4.0, kp_steering ) )

        # Compute the end-of-step steering angle request in radians, then normalize for the env action.
        delta_request = kp_steering*(np.pi/180.0) * (-dist_to_line)
        steering_command = delta_request / self.delta_request_max if self.delta_request_max > 0.0 else 0.0
        steering_command = max(-1.0, min(steering_command, 1.0))

        # Construct the action vector expected by the gymnasium
        action = np.array([drive_command_clipped, steering_command], dtype=np.float32)

        # Construct the action dictionary expected by the gymnasium
        #action = {
        #    "drive_command" : drive_command_clipped,
        #    "steering_command" : steering_command
        #}

        # Zero input if go too fast
        if (speed > 50.0):
            action[0] = 0.0
            action[1] = 0.0

        # Zero steering and drive after reaching the end of the road
        if (terminated):
            action[1] = 0.0

        # Return the action
        return action
