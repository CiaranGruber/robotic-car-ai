"""Policy namespaces for dreamgym environments."""
