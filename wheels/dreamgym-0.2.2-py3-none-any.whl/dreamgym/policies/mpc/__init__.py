"""Public contracts and lazy solver access for linear-quadratic MPC."""

from importlib import import_module
from typing import TYPE_CHECKING

from dreamgym.policies.mpc.config import MPCSolverConfig
from dreamgym.policies.mpc.problem import LinearQuadraticMPCProblem
from dreamgym.policies.mpc.results import (
    MPCPrediction,
    MPCSolveDiagnostics,
    MPCSolveResult,
)

if TYPE_CHECKING:
    from dreamgym.policies.mpc.solver import LinearQuadraticMPCSolver

__all__ = [
    "LinearQuadraticMPCProblem",
    "LinearQuadraticMPCSolver",
    "MPCPrediction",
    "MPCSolveDiagnostics",
    "MPCSolveResult",
    "MPCSolverConfig",
]

_LAZY_EXPORTS = {
    "LinearQuadraticMPCSolver": (
        "dreamgym.policies.mpc.solver",
        "LinearQuadraticMPCSolver",
    ),
}


def _require_mpc_dependencies() -> None:
    for dependency in ("scipy", "osqp"):
        try:
            __import__(dependency)
        except ModuleNotFoundError as error:
            raise ModuleNotFoundError(
                "MPC solver and policy support requires SciPy and OSQP. "
                "Install them with `python -m pip install -e .[mpc]`.",
                name=error.name or dependency,
            ) from error


def __getattr__(name: str):
    if name not in _LAZY_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    _require_mpc_dependencies()
    module_name, attribute_name = _LAZY_EXPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attribute_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Include unresolved lazy exports in interactive introspection."""

    return sorted(set(globals()) | set(_LAZY_EXPORTS))
