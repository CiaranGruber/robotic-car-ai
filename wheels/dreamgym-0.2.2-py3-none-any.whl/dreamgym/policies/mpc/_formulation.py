"""Pure normalization and sparse formulation helpers for linear MPC."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral

import numpy as np


@dataclass(frozen=True, slots=True)
class NormalizedDynamics:
    """Defensive, stage-indexed data for ``x[k+1] = A x[k] + B u[k] + g``."""

    state_matrices: tuple[np.ndarray, ...]
    control_matrices: tuple[np.ndarray, ...]
    affine_offsets: tuple[np.ndarray, ...]

    @property
    def horizon_steps(self) -> int:
        return len(self.state_matrices)


@dataclass(frozen=True, slots=True)
class NormalizedObjective:
    """Stage and terminal coefficients for the convex quadratic objective."""

    state_cost_matrices: tuple[np.ndarray, ...]
    control_cost_matrices: tuple[np.ndarray, ...]
    state_linear_costs: tuple[np.ndarray, ...]
    control_linear_costs: tuple[np.ndarray, ...]
    terminal_state_cost_matrix: np.ndarray
    terminal_state_linear_cost: np.ndarray

    @property
    def horizon_steps(self) -> int:
        return len(self.state_cost_matrices)


@dataclass(frozen=True, slots=True)
class NormalizedStateReferences:
    """Stage references for states plus the distinct terminal reference."""

    stage_references: tuple[np.ndarray, ...]
    terminal_reference: np.ndarray

    @property
    def horizon_steps(self) -> int:
        return len(self.stage_references)


@dataclass(frozen=True, slots=True)
class NormalizedControlReferences:
    """Stage references for controls (there is no terminal control)."""

    stage_references: tuple[np.ndarray, ...]

    @property
    def horizon_steps(self) -> int:
        return len(self.stage_references)


@dataclass(frozen=True, slots=True)
class NormalizedBounds:
    """Stage-indexed lower and upper bounds with defensive arrays."""

    lower_bounds: tuple[np.ndarray, ...]
    upper_bounds: tuple[np.ndarray, ...]

    @property
    def horizon_steps(self) -> int:
        return len(self.lower_bounds)


@dataclass(frozen=True, slots=True)
class NormalizedSoftStatePenalties:
    """Stage-indexed nonnegative costs applied to each active state slack."""

    linear_penalties: tuple[np.ndarray, ...]
    quadratic_penalties: tuple[np.ndarray, ...]

    @property
    def horizon_steps(self) -> int:
        return len(self.linear_penalties)


@dataclass(frozen=True, slots=True)
class EffectiveProblemConfiguration:
    """Complete optional problem families after applying solver defaults."""

    objective: NormalizedObjective
    state_references: NormalizedStateReferences
    control_references: NormalizedControlReferences
    control_bounds: NormalizedBounds
    control_rate_bounds: NormalizedBounds
    state_bounds: NormalizedBounds
    soft_state_bounds: NormalizedBounds
    soft_state_penalties: NormalizedSoftStatePenalties


@dataclass(frozen=True, slots=True)
class DecisionVariableLayout:
    """Slices for state, control, and active soft-bound slack blocks."""

    horizon_steps: int
    n_state: int
    n_control: int
    lower_slack_components: tuple[tuple[int, ...], ...] = ()
    upper_slack_components: tuple[tuple[int, ...], ...] = ()

    @property
    def n_state_control_variables(self) -> int:
        return (self.horizon_steps + 1) * self.n_state + (
            self.horizon_steps * self.n_control
        )

    @property
    def n_variables(self) -> int:
        return self.n_state_control_variables + sum(
            len(lower) + len(upper)
            for lower, upper in zip(
                self.lower_slack_components,
                self.upper_slack_components,
            )
        )

    def state_slice(self, stage: int) -> slice:
        start = stage * self.n_state
        return slice(start, start + self.n_state)

    def control_slice(self, stage: int) -> slice:
        start = (self.horizon_steps + 1) * self.n_state
        start += stage * self.n_control
        return slice(start, start + self.n_control)

    def lower_slack_slice(self, stage: int) -> slice:
        start = self.n_state_control_variables
        for prior_stage in range(stage):
            start += len(self.lower_slack_components[prior_stage])
            start += len(self.upper_slack_components[prior_stage])
        return slice(start, start + len(self.lower_slack_components[stage]))

    def upper_slack_slice(self, stage: int) -> slice:
        lower_slice = self.lower_slack_slice(stage)
        start = lower_slice.stop
        return slice(start, start + len(self.upper_slack_components[stage]))


@dataclass(frozen=True, slots=True)
class ConstraintFormulation:
    """Sparse OSQP constraint data and its variable layout."""

    matrix: object
    lower_bound: np.ndarray
    upper_bound: np.ndarray
    layout: DecisionVariableLayout


@dataclass(frozen=True, slots=True)
class QuadraticProgramFormulation:
    """Complete dependency-neutral sparse QP data shared by solve/diagnostics.

    ``objective_constant`` records the reference-only term omitted from OSQP's
    expansion for formulation inspection and overflow validation.
    """

    objective_matrix: object
    objective_vector: np.ndarray
    objective_constant: float
    constraints: ConstraintFormulation
    effective_configuration: EffectiveProblemConfiguration


def validate_positive_dimension(name: str, value: object) -> int:
    """Return a positive Python integer, rejecting booleans explicitly."""

    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    converted = int(value)
    if converted <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return converted


def normalize_vector(
    name: str,
    value: object,
    expected_size: int,
    *,
    finite: bool = True,
) -> np.ndarray:
    """Validate and defensively copy one vector as float64."""

    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != (expected_size,):
        raise ValueError(
            f"{name} must have shape {(expected_size,)}, got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    normalized = np.array(value, dtype=np.float64, copy=True)
    if finite and not np.all(np.isfinite(normalized)):
        raise ValueError(f"{name} must contain only finite values")
    if not finite and np.any(np.isnan(normalized)):
        raise ValueError(f"{name} must not contain NaN values")
    normalized.setflags(write=False)
    return normalized


def normalize_stage_arrays(
    name: str,
    value: object,
    horizon_steps: int,
    expected_shape: tuple[int, ...],
    *,
    finite: bool = True,
) -> tuple[np.ndarray, ...]:
    """Expand stage-invariant data or validate a stage-indexed sequence."""

    if isinstance(value, np.ndarray):
        values = (value,) * horizon_steps
    elif isinstance(value, (tuple, list)):
        if len(value) != horizon_steps:
            raise ValueError(
                f"{name} must contain {horizon_steps} stage arrays, got {len(value)}"
            )
        values = tuple(value)
    else:
        raise TypeError(
            f"{name} must be a NumPy array or a tuple/list of NumPy arrays"
        )

    normalized = []
    for stage, array in enumerate(values):
        if not isinstance(array, np.ndarray):
            raise TypeError(f"{name}[{stage}] must be a NumPy array")
        if array.shape != expected_shape:
            raise ValueError(
                f"{name}[{stage}] must have shape {expected_shape}, got {array.shape}"
            )
        if array.dtype.kind not in "iuf":
            raise TypeError(f"{name}[{stage}] must have a real numeric dtype")
        copied = np.array(array, dtype=np.float64, copy=True)
        if finite and not np.all(np.isfinite(copied)):
            raise ValueError(f"{name}[{stage}] must contain only finite values")
        if not finite and np.any(np.isnan(copied)):
            raise ValueError(f"{name}[{stage}] must not contain NaN values")
        copied.setflags(write=False)
        normalized.append(copied)
    return tuple(normalized)


def normalize_dynamics(
    *,
    n_state: int,
    n_control: int,
    horizon_steps: int,
    state_matrices: object,
    control_matrices: object,
    affine_offsets: object | None,
) -> NormalizedDynamics:
    """Normalize LTI or LTV dynamics into independent per-stage arrays."""

    state_stages = normalize_stage_arrays(
        "state_matrices",
        state_matrices,
        horizon_steps,
        (n_state, n_state),
    )
    control_stages = normalize_stage_arrays(
        "control_matrices",
        control_matrices,
        horizon_steps,
        (n_state, n_control),
    )
    if affine_offsets is None:
        zero = np.zeros(n_state, dtype=np.float64)
        zero.setflags(write=False)
        affine_stages = tuple(zero.copy() for _ in range(horizon_steps))
        for stage in affine_stages:
            stage.setflags(write=False)
    else:
        affine_stages = normalize_stage_arrays(
            "affine_offsets",
            affine_offsets,
            horizon_steps,
            (n_state,),
        )
    return NormalizedDynamics(
        state_matrices=state_stages,
        control_matrices=control_stages,
        affine_offsets=affine_stages,
    )


def _zero_stage_arrays(
    horizon_steps: int,
    shape: tuple[int, ...],
) -> tuple[np.ndarray, ...]:
    stages = []
    for _ in range(horizon_steps):
        stage = np.zeros(shape, dtype=np.float64)
        stage.setflags(write=False)
        stages.append(stage)
    return tuple(stages)


def _normalize_cost_matrices(
    name: str,
    value: object | None,
    horizon_steps: int,
    size: int,
) -> tuple[np.ndarray, ...]:
    if value is None:
        return _zero_stage_arrays(horizon_steps, (size, size))
    stages = normalize_stage_arrays(
        name,
        value,
        horizon_steps,
        (size, size),
    )
    return tuple(
        _validate_cost_matrix(f"{name}[{stage}]", matrix)
        for stage, matrix in enumerate(stages)
    )


def _validate_cost_matrix(name: str, matrix: np.ndarray) -> np.ndarray:
    """Project machine-scale roundoff after explicit symmetry/PSD checks."""

    values = np.asarray(matrix, dtype=np.float64)
    dimension = values.shape[0]
    eps = np.finfo(np.float64).eps
    symmetry_scale = max(1.0, float(np.max(np.abs(values))))
    symmetry_tol = 64.0 * eps * max(1, dimension) * symmetry_scale
    half_values = 0.5 * values
    half_difference = half_values - half_values.T
    if not np.all(np.isfinite(half_difference)) or float(
        np.max(np.abs(half_difference))
    ) > 0.5 * symmetry_tol:
        raise ValueError(f"{name} must be symmetric")
    symmetric = half_values + half_values.T
    try:
        eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    except np.linalg.LinAlgError as exc:
        raise ValueError(
            f"{name} could not be checked for positive semidefinite"
        ) from exc
    if not np.all(np.isfinite(eigenvalues)) or not np.all(
        np.isfinite(eigenvectors)
    ):
        raise ValueError(f"{name} could not be checked for positive semidefinite")
    eigen_scale = max(1.0, float(np.max(np.abs(eigenvalues))))
    tolerance = 64.0 * eps * max(1, dimension) * eigen_scale
    if float(eigenvalues[0]) < -tolerance:
        raise ValueError(f"{name} must be positive semidefinite")
    with np.errstate(over="ignore", invalid="ignore"):
        projected = (eigenvectors * np.maximum(eigenvalues, 0.0)) @ eigenvectors.T
    if not np.all(np.isfinite(projected)):
        raise ValueError(f"{name} could not be projected to positive semidefinite")
    projected = 0.5 * projected + 0.5 * projected.T
    try:
        projected_eigenvalues = np.linalg.eigvalsh(projected)
    except np.linalg.LinAlgError as exc:
        raise ValueError(
            f"{name} could not be projected to positive semidefinite"
        ) from exc
    if not np.all(np.isfinite(projected_eigenvalues)):
        raise ValueError(f"{name} could not be projected to positive semidefinite")
    minimum = float(projected_eigenvalues[0])
    if -tolerance <= minimum < 0.0:
        with np.errstate(over="ignore", invalid="ignore"):
            projected = projected + np.eye(dimension) * (-minimum + tolerance)
    if not np.all(np.isfinite(projected)):
        raise ValueError(f"{name} could not be projected to positive semidefinite")
    try:
        projected_eigenvalues = np.linalg.eigvalsh(projected)
    except np.linalg.LinAlgError as exc:
        raise ValueError(
            f"{name} could not be projected to positive semidefinite"
        ) from exc
    if not np.all(np.isfinite(projected_eigenvalues)):
        raise ValueError(f"{name} could not be projected to positive semidefinite")
    if float(projected_eigenvalues[0]) < -tolerance:
        raise ValueError(f"{name} could not be projected to positive semidefinite")
    projected.setflags(write=False)
    return projected


def normalize_objective(
    *,
    n_state: int,
    n_control: int,
    horizon_steps: int,
    state_cost_matrices: object | None,
    control_cost_matrices: object | None,
    state_linear_costs: object | None,
    control_linear_costs: object | None,
    terminal_state_cost_matrix: object | None,
    terminal_state_linear_cost: object | None,
) -> NormalizedObjective:
    """Normalize optional LTI/LTV objective data, using zeros for omissions."""

    state_costs = _normalize_cost_matrices(
        "state_cost_matrices",
        state_cost_matrices,
        horizon_steps,
        n_state,
    )
    control_costs = _normalize_cost_matrices(
        "control_cost_matrices",
        control_cost_matrices,
        horizon_steps,
        n_control,
    )
    if state_linear_costs is None:
        state_linear = _zero_stage_arrays(horizon_steps, (n_state,))
    else:
        state_linear = normalize_stage_arrays(
            "state_linear_costs",
            state_linear_costs,
            horizon_steps,
            (n_state,),
        )
    if control_linear_costs is None:
        control_linear = _zero_stage_arrays(horizon_steps, (n_control,))
    else:
        control_linear = normalize_stage_arrays(
            "control_linear_costs",
            control_linear_costs,
            horizon_steps,
            (n_control,),
        )

    if terminal_state_cost_matrix is None:
        terminal_cost = np.zeros((n_state, n_state), dtype=np.float64)
        terminal_cost.setflags(write=False)
    else:
        terminal_cost = _validate_cost_matrix(
            "terminal_state_cost_matrix",
            normalize_stage_arrays(
                "terminal_state_cost_matrix",
                terminal_state_cost_matrix,
                1,
                (n_state, n_state),
            )[0],
        )
    if terminal_state_linear_cost is None:
        terminal_linear = np.zeros(n_state, dtype=np.float64)
        terminal_linear.setflags(write=False)
    else:
        terminal_linear = normalize_vector(
            "terminal_state_linear_cost",
            terminal_state_linear_cost,
            n_state,
        )
    return NormalizedObjective(
        state_cost_matrices=state_costs,
        control_cost_matrices=control_costs,
        state_linear_costs=state_linear,
        control_linear_costs=control_linear,
        terminal_state_cost_matrix=terminal_cost,
        terminal_state_linear_cost=terminal_linear,
    )


def normalize_state_references(
    *,
    n_state: int,
    horizon_steps: int,
    state_references: object | None,
    terminal_state_reference: object | None,
) -> NormalizedStateReferences:
    """Normalize stage references and apply the terminal inheritance rule."""

    if state_references is None:
        stage_references = _zero_stage_arrays(horizon_steps, (n_state,))
    else:
        stage_references = normalize_stage_arrays(
            "state_references",
            state_references,
            horizon_steps,
            (n_state,),
        )
    if terminal_state_reference is None:
        if state_references is None:
            terminal_reference = np.zeros(n_state, dtype=np.float64)
        else:
            terminal_reference = stage_references[-1].copy()
        terminal_reference.setflags(write=False)
    else:
        terminal_reference = normalize_vector(
            "terminal_state_reference",
            terminal_state_reference,
            n_state,
        )
    return NormalizedStateReferences(stage_references, terminal_reference)


def normalize_control_references(
    *,
    n_control: int,
    horizon_steps: int,
    control_references: object | None,
) -> NormalizedControlReferences:
    """Normalize optional control references, using zero for omissions."""

    if control_references is None:
        stage_references = _zero_stage_arrays(horizon_steps, (n_control,))
    else:
        stage_references = normalize_stage_arrays(
            "control_references",
            control_references,
            horizon_steps,
            (n_control,),
        )
    return NormalizedControlReferences(stage_references)


def normalize_bounds(
    *,
    name: str,
    horizon_steps: int,
    size: int,
    lower_bounds: object | None,
    upper_bounds: object | None,
) -> NormalizedBounds:
    """Normalize optional one-sided boxes and reject invalid infinity signs."""

    if lower_bounds is None:
        lower = tuple(
            np.full(size, -np.inf, dtype=np.float64)
            for _ in range(horizon_steps)
        )
    else:
        lower = normalize_stage_arrays(
            f"{name}_lower_bounds",
            lower_bounds,
            horizon_steps,
            (size,),
            finite=False,
        )
    if upper_bounds is None:
        upper = tuple(
            np.full(size, np.inf, dtype=np.float64)
            for _ in range(horizon_steps)
        )
    else:
        upper = normalize_stage_arrays(
            f"{name}_upper_bounds",
            upper_bounds,
            horizon_steps,
            (size,),
            finite=False,
        )
    for stage, (stage_lower, stage_upper) in enumerate(zip(lower, upper)):
        if np.any(np.isposinf(stage_lower)):
            raise ValueError(
                f"{name}_lower_bounds[{stage}] must not contain positive infinity"
            )
        if np.any(np.isneginf(stage_upper)):
            raise ValueError(
                f"{name}_upper_bounds[{stage}] must not contain negative infinity"
            )
        if np.any(stage_lower > stage_upper):
            raise ValueError(
                f"{name}_lower_bounds must not exceed {name}_upper_bounds "
                f"at stage {stage}"
            )
    return NormalizedBounds(lower, upper)


def normalize_control_bounds(
    *,
    horizon_steps: int,
    n_control: int,
    lower_bounds: object | None,
    upper_bounds: object | None,
) -> tuple[tuple[np.ndarray, ...], tuple[np.ndarray, ...]]:
    """Normalize hard control bounds and return their stage-indexed tuples."""

    normalized = normalize_bounds(
        name="control",
        horizon_steps=horizon_steps,
        size=n_control,
        lower_bounds=lower_bounds,
        upper_bounds=upper_bounds,
    )
    return normalized.lower_bounds, normalized.upper_bounds


def stage_zero_control_rate_requires_previous_control(
    bounds: NormalizedBounds | None,
) -> bool:
    """Return whether a finite stage-zero rate side needs an external control."""

    if bounds is None:
        return False
    return bool(
        np.isfinite(bounds.lower_bounds[0]).any()
        or np.isfinite(bounds.upper_bounds[0]).any()
    )


def normalize_soft_state_penalties(
    *,
    horizon_steps: int,
    n_state: int,
    linear_penalties: object | None,
    quadratic_penalties: object | None,
) -> NormalizedSoftStatePenalties:
    """Normalize full-state slack costs and require convex nonnegative values."""

    if linear_penalties is None:
        linear = _zero_stage_arrays(horizon_steps, (n_state,))
    else:
        linear = normalize_stage_arrays(
            "soft_state_linear_penalties",
            linear_penalties,
            horizon_steps,
            (n_state,),
        )
    if quadratic_penalties is None:
        quadratic = _zero_stage_arrays(horizon_steps, (n_state,))
    else:
        quadratic = normalize_stage_arrays(
            "soft_state_quadratic_penalties",
            quadratic_penalties,
            horizon_steps,
            (n_state,),
        )
    for stage, (stage_linear, stage_quadratic) in enumerate(
        zip(linear, quadratic)
    ):
        if np.any(stage_linear < 0.0):
            raise ValueError(
                f"soft_state_linear_penalties[{stage}] must be nonnegative"
            )
        if np.any(stage_quadratic < 0.0):
            raise ValueError(
                f"soft_state_quadratic_penalties[{stage}] must be nonnegative"
            )
    return NormalizedSoftStatePenalties(linear, quadratic)


def validate_active_soft_state_penalties(
    bounds: NormalizedBounds,
    penalties: NormalizedSoftStatePenalties,
) -> None:
    """Require a positive linear or quadratic cost for each active entry."""

    for stage, (
        lower_bounds,
        upper_bounds,
        linear_penalties,
        quadratic_penalties,
    ) in enumerate(
        zip(
            bounds.lower_bounds,
            bounds.upper_bounds,
            penalties.linear_penalties,
            penalties.quadratic_penalties,
        )
    ):
        active = np.isfinite(lower_bounds) | np.isfinite(upper_bounds)
        unpenalized = (linear_penalties == 0.0) & (quadratic_penalties == 0.0)
        offending_components = np.flatnonzero(active & unpenalized)
        if offending_components.size:
            component = int(offending_components[0])
            raise ValueError(
                "active soft-state bound at "
                f"stage {stage}, component {component} requires a positive "
                "linear or quadratic penalty"
            )


def effective_problem_configuration(
    *,
    n_state: int,
    n_control: int,
    horizon_steps: int,
    objective: NormalizedObjective | None,
    state_references: NormalizedStateReferences | None,
    control_references: NormalizedControlReferences | None,
    control_lower_bounds: tuple[np.ndarray, ...] | None,
    control_upper_bounds: tuple[np.ndarray, ...] | None,
    control_rate_bounds: NormalizedBounds | None,
    state_bounds: NormalizedBounds | None,
    soft_state_bounds: NormalizedBounds | None,
    soft_state_penalties: NormalizedSoftStatePenalties | None,
) -> EffectiveProblemConfiguration:
    """Return the optional families exactly as the QP formulation sees them."""

    if objective is None:
        objective = normalize_objective(
            n_state=n_state,
            n_control=n_control,
            horizon_steps=horizon_steps,
            state_cost_matrices=None,
            control_cost_matrices=None,
            state_linear_costs=None,
            control_linear_costs=None,
            terminal_state_cost_matrix=None,
            terminal_state_linear_cost=None,
        )
    if state_references is None:
        state_references = normalize_state_references(
            n_state=n_state,
            horizon_steps=horizon_steps,
            state_references=None,
            terminal_state_reference=None,
        )
    if control_references is None:
        control_references = normalize_control_references(
            n_control=n_control,
            horizon_steps=horizon_steps,
            control_references=None,
        )
    if control_lower_bounds is None or control_upper_bounds is None:
        normalized_control_bounds = normalize_bounds(
            name="control",
            horizon_steps=horizon_steps,
            size=n_control,
            lower_bounds=None,
            upper_bounds=None,
        )
    else:
        normalized_control_bounds = NormalizedBounds(
            control_lower_bounds,
            control_upper_bounds,
        )
    if control_rate_bounds is None:
        control_rate_bounds = normalize_bounds(
            name="control_rate",
            horizon_steps=horizon_steps,
            size=n_control,
            lower_bounds=None,
            upper_bounds=None,
        )
    if state_bounds is None:
        state_bounds = normalize_bounds(
            name="state",
            horizon_steps=horizon_steps,
            size=n_state,
            lower_bounds=None,
            upper_bounds=None,
        )
    if soft_state_bounds is None:
        soft_state_bounds = normalize_bounds(
            name="soft_state",
            horizon_steps=horizon_steps,
            size=n_state,
            lower_bounds=None,
            upper_bounds=None,
        )
    if soft_state_penalties is None:
        soft_state_penalties = normalize_soft_state_penalties(
            n_state=n_state,
            horizon_steps=horizon_steps,
            linear_penalties=None,
            quadratic_penalties=None,
        )
    validate_active_soft_state_penalties(soft_state_bounds, soft_state_penalties)
    return EffectiveProblemConfiguration(
        objective=objective,
        state_references=state_references,
        control_references=control_references,
        control_bounds=normalized_control_bounds,
        control_rate_bounds=control_rate_bounds,
        state_bounds=state_bounds,
        soft_state_bounds=soft_state_bounds,
        soft_state_penalties=soft_state_penalties,
    )


def _translate_stage_zero_rate_bound(
    bound: np.ndarray,
    previous_control: np.ndarray,
) -> np.ndarray:
    """Translate one rate-bound side without losing a finite constraint."""

    try:
        with np.errstate(over="raise", invalid="raise"):
            translated = bound + previous_control
    except FloatingPointError as exc:
        raise ValueError(
            "quadratic-program formulation produced a non-finite stage-zero "
            "control-rate bound"
        ) from exc
    if np.any(np.isfinite(bound) & ~np.isfinite(translated)):
        raise ValueError(
            "quadratic-program formulation produced a non-finite stage-zero "
            "control-rate bound"
        )
    return translated


def build_dynamics_constraints(
    *,
    dynamics: NormalizedDynamics,
    initial_state: np.ndarray,
    control_lower_bounds: tuple[np.ndarray, ...],
    control_upper_bounds: tuple[np.ndarray, ...],
    control_rate_bounds: NormalizedBounds | None = None,
    previous_control: np.ndarray | None = None,
    state_bounds: NormalizedBounds | None = None,
    soft_state_bounds: NormalizedBounds | None = None,
) -> ConstraintFormulation:
    """Build the sparse dynamics, hard boxes, rates, and soft boxes for OSQP.

    The decision vector starts with the dense conceptual blocks

    ``z = [x[0], ..., x[N], u[0], ..., u[N-1],``
    ``lambda[0], mu[0], ..., lambda[N-1], mu[N-1]]``,

    where each stage's ``lambda`` and ``mu`` blocks contain only the active
    lower- and upper-bound slacks.  OSQP represents every row as
    ``l <= A z <= u``.  The mathematical block rows are therefore:

    * initial state: ``x[0] = x_initial``;
    * model: ``-A[k] x[k] + x[k+1] - B[k] u[k] = g[k]``;
    * control box: ``u_lower[k] <= u[k] <= u_upper[k]``;
    * first control difference:
      ``du_lower[0] <= u[0] - u_previous <= du_upper[0]``;
    * later control differences:
      ``du_lower[k] <= u[k] - u[k-1] <= du_upper[k]``;
    * hard state box on predicted states only:
      ``x_lower[k] <= x[k+1] <= x_upper[k]``;
    * soft lower state box and nonnegative slack:
      ``soft_lower[k] <= S_lower[k] x[k+1] + lambda[k]`` and
      ``0 <= lambda[k]``;
    * soft upper state box and nonnegative slack:
      ``S_upper[k] x[k+1] - mu[k] <= soft_upper[k]`` and ``0 <= mu[k]``.

    Control-box rows remain explicit for every stage and component, including
    deliberately unbounded ``[-inf, inf]`` rows.  Hard-state and control-rate
    selectors retain components with at least one finite side; soft-state
    selectors retain the components for their corresponding finite side.  The
    active slack blocks therefore remain reconstructable.  State and soft-state
    stage ``k`` always refer to ``x[k+1]``; control and difference stage ``k``
    refer to ``u[k]``.
    """

    try:
        from scipy import sparse
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "MPC solver support requires scipy. Install it with "
            "`python -m pip install -e .[mpc]`."
        ) from exc

    horizon_steps = dynamics.horizon_steps
    n_state = initial_state.shape[0]
    n_control = dynamics.control_matrices[0].shape[1]
    if state_bounds is None:
        state_bounds = normalize_bounds(
            name="state",
            horizon_steps=horizon_steps,
            size=n_state,
            lower_bounds=None,
            upper_bounds=None,
        )
    if soft_state_bounds is None:
        soft_state_bounds = normalize_bounds(
            name="soft_state",
            horizon_steps=horizon_steps,
            size=n_state,
            lower_bounds=None,
            upper_bounds=None,
        )

    lower_slack_components = tuple(
        tuple(np.flatnonzero(np.isfinite(stage_lower)).tolist())
        for stage_lower in soft_state_bounds.lower_bounds
    )
    upper_slack_components = tuple(
        tuple(np.flatnonzero(np.isfinite(stage_upper)).tolist())
        for stage_upper in soft_state_bounds.upper_bounds
    )
    layout = DecisionVariableLayout(
        horizon_steps,
        n_state,
        n_control,
        lower_slack_components,
        upper_slack_components,
    )

    rate_components: tuple[tuple[int, ...], ...]
    if control_rate_bounds is None:
        rate_components = tuple(() for _ in range(horizon_steps))
    else:
        rate_components = tuple(
            tuple(
                np.flatnonzero(
                    np.isfinite(stage_lower) | np.isfinite(stage_upper)
                ).tolist()
            )
            for stage_lower, stage_upper in zip(
                control_rate_bounds.lower_bounds,
                control_rate_bounds.upper_bounds,
            )
        )
        if (
            stage_zero_control_rate_requires_previous_control(control_rate_bounds)
            and previous_control is None
        ):
            raise ValueError(
                "previous_control is required when a stage-zero control-rate "
                "bound is finite"
            )

    state_components = tuple(
        tuple(
            np.flatnonzero(
                np.isfinite(stage_lower) | np.isfinite(stage_upper)
            ).tolist()
        )
        for stage_lower, stage_upper in zip(
            state_bounds.lower_bounds,
            state_bounds.upper_bounds,
        )
    )

    n_rows = n_state + horizon_steps * n_state + horizon_steps * n_control
    n_rows += sum(len(components) for components in rate_components)
    n_rows += sum(len(components) for components in state_components)
    n_rows += 2 * sum(len(components) for components in lower_slack_components)
    n_rows += 2 * sum(len(components) for components in upper_slack_components)
    matrix = sparse.lil_matrix(
        (n_rows, layout.n_variables),
        dtype=np.float64,
    )
    lower = np.empty(n_rows, dtype=np.float64)
    upper = np.empty(n_rows, dtype=np.float64)

    row = 0
    matrix[row : row + n_state, layout.state_slice(0)] = np.eye(n_state)
    lower[row : row + n_state] = initial_state
    upper[row : row + n_state] = initial_state
    row += n_state

    for stage in range(horizon_steps):
        stage_rows = slice(row, row + n_state)
        matrix[stage_rows, layout.state_slice(stage)] = -dynamics.state_matrices[
            stage
        ]
        matrix[stage_rows, layout.state_slice(stage + 1)] = np.eye(n_state)
        matrix[stage_rows, layout.control_slice(stage)] = -dynamics.control_matrices[
            stage
        ]
        lower[stage_rows] = dynamics.affine_offsets[stage]
        upper[stage_rows] = dynamics.affine_offsets[stage]
        row += n_state

    for stage in range(horizon_steps):
        stage_rows = slice(row, row + n_control)
        matrix[stage_rows, layout.control_slice(stage)] = np.eye(n_control)
        lower[stage_rows] = control_lower_bounds[stage]
        upper[stage_rows] = control_upper_bounds[stage]
        row += n_control

    for stage, components in enumerate(rate_components):
        if not components:
            continue
        selected = np.asarray(components, dtype=int)
        n_selected = len(components)
        stage_rows = slice(row, row + n_selected)
        selector = np.eye(n_control, dtype=np.float64)[selected]
        matrix[stage_rows, layout.control_slice(stage)] = selector
        if stage == 0:
            lower[stage_rows] = _translate_stage_zero_rate_bound(
                control_rate_bounds.lower_bounds[stage][selected],
                previous_control[selected],
            )
            upper[stage_rows] = _translate_stage_zero_rate_bound(
                control_rate_bounds.upper_bounds[stage][selected],
                previous_control[selected],
            )
        else:
            matrix[stage_rows, layout.control_slice(stage - 1)] = -selector
            lower[stage_rows] = control_rate_bounds.lower_bounds[stage][selected]
            upper[stage_rows] = control_rate_bounds.upper_bounds[stage][selected]
        row += n_selected

    for stage, components in enumerate(state_components):
        if not components:
            continue
        selected = np.asarray(components, dtype=int)
        n_selected = len(components)
        stage_rows = slice(row, row + n_selected)
        selector = np.eye(n_state, dtype=np.float64)[selected]
        matrix[stage_rows, layout.state_slice(stage + 1)] = selector
        lower[stage_rows] = state_bounds.lower_bounds[stage][selected]
        upper[stage_rows] = state_bounds.upper_bounds[stage][selected]
        row += n_selected

    for stage, components in enumerate(lower_slack_components):
        if not components:
            continue
        selected = np.asarray(components, dtype=int)
        n_selected = len(components)
        selector = np.eye(n_state, dtype=np.float64)[selected]
        identity = np.eye(n_selected, dtype=np.float64)

        bound_rows = slice(row, row + n_selected)
        matrix[bound_rows, layout.state_slice(stage + 1)] = selector
        matrix[bound_rows, layout.lower_slack_slice(stage)] = identity
        lower[bound_rows] = soft_state_bounds.lower_bounds[stage][selected]
        upper[bound_rows] = np.inf
        row += n_selected

        positivity_rows = slice(row, row + n_selected)
        matrix[positivity_rows, layout.lower_slack_slice(stage)] = identity
        lower[positivity_rows] = 0.0
        upper[positivity_rows] = np.inf
        row += n_selected

    for stage, components in enumerate(upper_slack_components):
        if not components:
            continue
        selected = np.asarray(components, dtype=int)
        n_selected = len(components)
        selector = np.eye(n_state, dtype=np.float64)[selected]
        identity = np.eye(n_selected, dtype=np.float64)

        bound_rows = slice(row, row + n_selected)
        matrix[bound_rows, layout.state_slice(stage + 1)] = selector
        matrix[bound_rows, layout.upper_slack_slice(stage)] = -identity
        lower[bound_rows] = -np.inf
        upper[bound_rows] = soft_state_bounds.upper_bounds[stage][selected]
        row += n_selected

        positivity_rows = slice(row, row + n_selected)
        matrix[positivity_rows, layout.upper_slack_slice(stage)] = identity
        lower[positivity_rows] = 0.0
        upper[positivity_rows] = np.inf
        row += n_selected

    assert row == n_rows

    return ConstraintFormulation(
        matrix=matrix.tocsc(),
        lower_bound=lower,
        upper_bound=upper,
        layout=layout,
    )


def _assemble_quadratic_term(
    cost_matrix: np.ndarray,
    reference: np.ndarray,
    linear_cost: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Assemble one finite-input term for later whole-QP validation."""

    with np.errstate(over="ignore", invalid="ignore"):
        hessian = 2.0 * cost_matrix
        linear = -2.0 * cost_matrix @ reference + linear_cost
        constant = float(reference @ cost_matrix @ reference)
    return hessian, linear, constant


def _double_quadratic_penalties(values: np.ndarray) -> np.ndarray:
    """Scale finite slack penalties without leaking an overflow warning."""

    with np.errstate(over="ignore", invalid="ignore"):
        return 2.0 * values


def build_quadratic_objective(
    *,
    layout: DecisionVariableLayout,
    objective: NormalizedObjective | None,
    state_references: NormalizedStateReferences | None,
    control_references: NormalizedControlReferences | None,
    soft_state_penalties: NormalizedSoftStatePenalties | None = None,
):
    """Build OSQP's ``P/q`` data and the omitted reference constant.

    The public convention writes each quadratic stage term as

    ``(x - x_ref)^T Q (x - x_ref)``.

    Expanding it gives ``x^T Q x - 2 x_ref^T Q x + x_ref^T Q x_ref``.
    OSQP instead minimizes ``0.5 z^T P z + q^T z``.  We therefore place
    ``2 Q`` in ``P`` and ``-2 Q x_ref`` in ``q``.  The final reference-only
    scalar is deliberately not sent to the optimizer because it cannot change
    the minimizer; it is returned separately for formulation inspection and
    overflow validation.  Control-reference and terminal-state terms use the
    same expansion, while explicit linear costs add directly to ``q``.
    """

    try:
        from scipy import sparse
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "MPC solver support requires scipy. Install it with "
            "`python -m pip install -e .[mpc]`."
        ) from exc

    horizon_steps = layout.horizon_steps
    if objective is None:
        objective = normalize_objective(
            n_state=layout.n_state,
            n_control=layout.n_control,
            horizon_steps=horizon_steps,
            state_cost_matrices=None,
            control_cost_matrices=None,
            state_linear_costs=None,
            control_linear_costs=None,
            terminal_state_cost_matrix=None,
            terminal_state_linear_cost=None,
        )
    if state_references is None:
        state_references = normalize_state_references(
            n_state=layout.n_state,
            horizon_steps=horizon_steps,
            state_references=None,
            terminal_state_reference=None,
        )
    if control_references is None:
        control_references = normalize_control_references(
            n_control=layout.n_control,
            horizon_steps=horizon_steps,
            control_references=None,
        )
    if soft_state_penalties is None:
        soft_state_penalties = normalize_soft_state_penalties(
            n_state=layout.n_state,
            horizon_steps=horizon_steps,
            linear_penalties=None,
            quadratic_penalties=None,
        )

    matrix = sparse.lil_matrix(
        (layout.n_variables, layout.n_variables),
        dtype=np.float64,
    )
    linear = np.zeros(layout.n_variables, dtype=np.float64)
    constant = 0.0

    for stage in range(horizon_steps):
        state_slice = layout.state_slice(stage)
        control_slice = layout.control_slice(stage)
        state_cost = objective.state_cost_matrices[stage]
        control_cost = objective.control_cost_matrices[stage]
        state_reference = state_references.stage_references[stage]
        control_reference = control_references.stage_references[stage]

        state_hessian, state_linear, state_constant = _assemble_quadratic_term(
            state_cost,
            state_reference,
            objective.state_linear_costs[stage],
        )
        control_hessian, control_linear, control_constant = (
            _assemble_quadratic_term(
                control_cost,
                control_reference,
                objective.control_linear_costs[stage],
            )
        )
        matrix[state_slice, state_slice] = state_hessian
        matrix[control_slice, control_slice] = control_hessian
        linear[state_slice] = state_linear
        linear[control_slice] = control_linear
        constant += state_constant
        constant += control_constant

        lower_slack_slice = layout.lower_slack_slice(stage)
        lower_components = np.asarray(
            layout.lower_slack_components[stage],
            dtype=int,
        )
        if lower_components.size:
            # The public slack term is ``p_quad * lambda^2 + p_lin * lambda``.
            # OSQP uses ``0.5 z^T P z + q^T z``, hence the factor of two in P.
            matrix[lower_slack_slice, lower_slack_slice] = np.diag(
                _double_quadratic_penalties(
                    soft_state_penalties.quadratic_penalties[stage][
                        lower_components
                    ]
                )
            )
            linear[lower_slack_slice] = (
                soft_state_penalties.linear_penalties[stage][lower_components]
            )

        upper_slack_slice = layout.upper_slack_slice(stage)
        upper_components = np.asarray(
            layout.upper_slack_components[stage],
            dtype=int,
        )
        if upper_components.size:
            matrix[upper_slack_slice, upper_slack_slice] = np.diag(
                _double_quadratic_penalties(
                    soft_state_penalties.quadratic_penalties[stage][
                        upper_components
                    ]
                )
            )
            linear[upper_slack_slice] = (
                soft_state_penalties.linear_penalties[stage][upper_components]
            )

    terminal_slice = layout.state_slice(horizon_steps)
    terminal_cost = objective.terminal_state_cost_matrix
    terminal_reference = state_references.terminal_reference
    terminal_hessian, terminal_linear, terminal_constant = (
        _assemble_quadratic_term(
            terminal_cost,
            terminal_reference,
            objective.terminal_state_linear_cost,
        )
    )
    matrix[terminal_slice, terminal_slice] = terminal_hessian
    linear[terminal_slice] = terminal_linear
    constant += terminal_constant

    # OSQP reads the upper triangle of P.  Supplying only that triangle avoids
    # storing duplicate symmetric entries and makes the convention explicit.
    return sparse.triu(matrix.tocsc(), format="csc"), linear, constant


def evaluate_teaching_objective(
    *,
    states: np.ndarray,
    controls: np.ndarray,
    lower_state_slack: np.ndarray,
    upper_state_slack: np.ndarray,
    configuration: EffectiveProblemConfiguration,
) -> float:
    """Evaluate the public objective directly from the returned prediction."""

    objective = configuration.objective
    state_references = configuration.state_references
    control_references = configuration.control_references
    slack_penalties = configuration.soft_state_penalties
    value = np.float64(0.0)

    with np.errstate(over="ignore", invalid="ignore"):
        for stage in range(objective.horizon_steps):
            state_error = states[stage] - state_references.stage_references[stage]
            control_error = (
                controls[stage] - control_references.stage_references[stage]
            )
            value += state_error @ objective.state_cost_matrices[stage] @ state_error
            value += objective.state_linear_costs[stage] @ states[stage]
            value += (
                control_error
                @ objective.control_cost_matrices[stage]
                @ control_error
            )
            value += objective.control_linear_costs[stage] @ controls[stage]

            linear_penalty = slack_penalties.linear_penalties[stage]
            quadratic_penalty = slack_penalties.quadratic_penalties[stage]
            lower_slack = lower_state_slack[stage]
            upper_slack = upper_state_slack[stage]
            value += linear_penalty @ lower_slack
            value += quadratic_penalty @ (lower_slack * lower_slack)
            value += linear_penalty @ upper_slack
            value += quadratic_penalty @ (upper_slack * upper_slack)

        terminal_error = states[-1] - state_references.terminal_reference
        value += (
            terminal_error
            @ objective.terminal_state_cost_matrix
            @ terminal_error
        )
        value += objective.terminal_state_linear_cost @ states[-1]

    result = float(value)
    if not bool(np.isfinite(result)):
        raise RuntimeError("recomputed MPC teaching objective is nonfinite")
    return result


def validate_quadratic_program(formulation: QuadraticProgramFormulation) -> None:
    """Reject non-finite or inconsistent effective QP data before OSQP."""

    if not np.all(np.isfinite(formulation.objective_matrix.data)):
        raise ValueError(
            "quadratic-program formulation must contain only finite "
            "objective-matrix coefficients"
        )
    if not np.all(np.isfinite(formulation.objective_vector)):
        raise ValueError(
            "quadratic-program formulation must contain only finite "
            "objective-vector coefficients"
        )
    if not bool(np.isfinite(formulation.objective_constant)):
        raise ValueError(
            "quadratic-program formulation objective constant must be finite"
        )

    constraints = formulation.constraints
    if not np.all(np.isfinite(constraints.matrix.data)):
        raise ValueError(
            "quadratic-program formulation must contain only finite "
            "constraint-matrix coefficients"
        )
    lower = constraints.lower_bound
    upper = constraints.upper_bound
    if np.any(np.isnan(lower)) or np.any(np.isposinf(lower)):
        raise ValueError(
            "quadratic-program formulation lower bounds must not contain "
            "NaN or positive infinity"
        )
    if np.any(np.isnan(upper)) or np.any(np.isneginf(upper)):
        raise ValueError(
            "quadratic-program formulation upper bounds must not contain "
            "NaN or negative infinity"
        )
    if np.any(lower > upper):
        raise ValueError(
            "quadratic-program formulation lower bounds must not exceed "
            "upper bounds"
        )
