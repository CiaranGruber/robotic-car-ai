"""Fresh-setup OSQP orchestration for linear-quadratic MPC."""

from __future__ import annotations

import math
from numbers import Integral, Real
from time import perf_counter

import numpy as np

from dreamgym.policies.mpc._diagnostics import MPCDiagnosticsMixin
from dreamgym.policies.mpc._formulation import (
    EffectiveProblemConfiguration,
    NormalizedBounds,
    NormalizedControlReferences,
    NormalizedDynamics,
    NormalizedObjective,
    NormalizedSoftStatePenalties,
    NormalizedStateReferences,
    QuadraticProgramFormulation,
    build_dynamics_constraints,
    build_quadratic_objective,
    effective_problem_configuration,
    evaluate_teaching_objective,
    normalize_bounds,
    normalize_control_bounds,
    normalize_control_references,
    normalize_dynamics,
    normalize_objective,
    normalize_soft_state_penalties,
    normalize_state_references,
    normalize_vector,
    stage_zero_control_rate_requires_previous_control,
    validate_active_soft_state_penalties,
    validate_quadratic_program,
    validate_positive_dimension,
)
from dreamgym.policies.mpc.config import MPCSolverConfig
from dreamgym.policies.mpc.problem import LinearQuadraticMPCProblem
from dreamgym.policies.mpc.results import MPCSolveResult, _make_solver_result


_MISSING = object()


def _read_solver_status(raw_result: object) -> tuple[object, str, int]:
    info = getattr(raw_result, "info", _MISSING)
    if info is _MISSING or info is None:
        raise RuntimeError("OSQP returned malformed result: missing info")
    status = getattr(info, "status", _MISSING)
    if not isinstance(status, str) or not status:
        raise RuntimeError("OSQP returned malformed status text")
    status_code = getattr(info, "status_val", _MISSING)
    if isinstance(status_code, bool) or not isinstance(status_code, Integral):
        raise RuntimeError("OSQP returned malformed status code")
    return info, status, int(status_code)


def _require_array(name: str, value: object | None) -> None:
    if value is not None and not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array or None")


class LinearQuadraticMPCSolver(MPCDiagnosticsMixin):
    """Solve finite-horizon linear MPC problems with a fresh OSQP setup."""

    def __init__(
        self,
        n_state: int,
        n_control: int,
        config: MPCSolverConfig | None = None,
    ) -> None:
        self._n_state = validate_positive_dimension("n_state", n_state)
        self._n_control = validate_positive_dimension("n_control", n_control)
        if config is None:
            config = MPCSolverConfig()
        if not isinstance(config, MPCSolverConfig):
            raise TypeError("config must be an MPCSolverConfig or None")
        self.config = config

        self._horizon_steps: int | None = None
        self._dynamics: NormalizedDynamics | None = None
        self._initial_state: np.ndarray | None = None
        self._control_lower_bounds: tuple[np.ndarray, ...] | None = None
        self._control_upper_bounds: tuple[np.ndarray, ...] | None = None
        self._objective: NormalizedObjective | None = None
        self._state_references: NormalizedStateReferences | None = None
        self._control_references: NormalizedControlReferences | None = None
        self._control_rate_bounds: NormalizedBounds | None = None
        self._previous_control: np.ndarray | None = None
        self._state_bounds: NormalizedBounds | None = None
        self._soft_state_bounds: NormalizedBounds | None = None
        self._soft_state_penalties: NormalizedSoftStatePenalties | None = None

    @property
    def n_state(self) -> int:
        """State dimension fixed when the solver is constructed."""

        return self._n_state

    @property
    def n_control(self) -> int:
        """Control dimension fixed when the solver is constructed."""

        return self._n_control

    def set_horizon(self, horizon_steps: int) -> None:
        """Set the positive number of control intervals in the horizon."""

        normalized = validate_positive_dimension("horizon_steps", horizon_steps)
        if self._dynamics is not None and self._dynamics.horizon_steps != normalized:
            raise ValueError("horizon_steps does not match the configured model")
        if self._objective is not None and self._objective.horizon_steps != normalized:
            raise ValueError("horizon_steps does not match the configured objective")
        if (
            self._state_references is not None
            and self._state_references.horizon_steps != normalized
        ):
            raise ValueError("horizon_steps does not match the state references")
        if (
            self._control_references is not None
            and self._control_references.horizon_steps != normalized
        ):
            raise ValueError("horizon_steps does not match the control references")
        if (
            self._control_lower_bounds is not None
            and len(self._control_lower_bounds) != normalized
        ):
            raise ValueError("horizon_steps does not match the control bounds")
        for name, configured in (
            ("control-rate bounds", self._control_rate_bounds),
            ("state bounds", self._state_bounds),
            ("soft-state bounds", self._soft_state_bounds),
            ("soft-state penalties", self._soft_state_penalties),
        ):
            if configured is not None and configured.horizon_steps != normalized:
                raise ValueError(f"horizon_steps does not match the {name}")
        self._horizon_steps = normalized

    def set_model(
        self,
        state_matrix,
        control_matrix,
        affine_offset=None,
    ) -> None:
        """Set a time-invariant affine model across the configured horizon."""

        if self._horizon_steps is None:
            raise ValueError("set_horizon must be called before set_model")
        _require_array("state_matrix", state_matrix)
        _require_array("control_matrix", control_matrix)
        _require_array("affine_offset", affine_offset)
        normalized = normalize_dynamics(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=self._horizon_steps,
            state_matrices=state_matrix,
            control_matrices=control_matrix,
            affine_offsets=affine_offset,
        )
        self._dynamics = normalized

    def set_time_varying_model(
        self,
        state_matrices,
        control_matrices,
        affine_offsets=None,
    ) -> None:
        """Set stage-indexed affine dynamics, inferring the horizon if needed."""

        if not isinstance(state_matrices, (tuple, list)):
            raise TypeError("state_matrices must be a tuple/list of NumPy arrays")
        inferred_horizon = validate_positive_dimension(
            "number of state_matrices",
            len(state_matrices),
        )
        if self._horizon_steps is not None and self._horizon_steps != inferred_horizon:
            raise ValueError("state_matrices length does not match horizon_steps")
        normalized = normalize_dynamics(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=inferred_horizon,
            state_matrices=state_matrices,
            control_matrices=control_matrices,
            affine_offsets=affine_offsets,
        )
        self._horizon_steps = inferred_horizon
        self._dynamics = normalized

    def set_initial_state(self, initial_state) -> None:
        """Set the state fixed at stage zero."""

        normalized = normalize_vector("initial_state", initial_state, self.n_state)
        self._initial_state = normalized

    def set_objective(
        self,
        state_cost_matrix,
        control_cost_matrix,
        state_linear_cost=None,
        control_linear_cost=None,
        terminal_state_cost_matrix=None,
        terminal_state_linear_cost=None,
    ) -> None:
        """Set time-invariant stage costs and an optional terminal cost."""

        if self._horizon_steps is None:
            raise ValueError("set_horizon must be called before set_objective")
        for name, value in (
            ("state_cost_matrix", state_cost_matrix),
            ("control_cost_matrix", control_cost_matrix),
            ("state_linear_cost", state_linear_cost),
            ("control_linear_cost", control_linear_cost),
            ("terminal_state_cost_matrix", terminal_state_cost_matrix),
            ("terminal_state_linear_cost", terminal_state_linear_cost),
        ):
            _require_array(name, value)
        normalized = normalize_objective(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=self._horizon_steps,
            state_cost_matrices=state_cost_matrix,
            control_cost_matrices=control_cost_matrix,
            state_linear_costs=state_linear_cost,
            control_linear_costs=control_linear_cost,
            terminal_state_cost_matrix=terminal_state_cost_matrix,
            terminal_state_linear_cost=terminal_state_linear_cost,
        )
        self._objective = normalized

    def set_time_varying_objective(
        self,
        state_cost_matrices,
        control_cost_matrices,
        state_linear_costs=None,
        control_linear_costs=None,
        terminal_state_cost_matrix=None,
        terminal_state_linear_cost=None,
    ) -> None:
        """Set stage-indexed costs, inferring the horizon when necessary."""

        stage_values = next(
            (
                value
                for value in (
                    state_cost_matrices,
                    control_cost_matrices,
                    state_linear_costs,
                    control_linear_costs,
                )
                if isinstance(value, (tuple, list))
            ),
            None,
        )
        if stage_values is None:
            if self._horizon_steps is None:
                raise ValueError(
                    "a stage sequence is required to infer horizon_steps"
                )
            horizon_steps = self._horizon_steps
        else:
            horizon_steps = validate_positive_dimension(
                "number of objective stages",
                len(stage_values),
            )
            if self._horizon_steps is not None and self._horizon_steps != horizon_steps:
                raise ValueError("objective stage count does not match horizon_steps")
        normalized = normalize_objective(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=horizon_steps,
            state_cost_matrices=state_cost_matrices,
            control_cost_matrices=control_cost_matrices,
            state_linear_costs=state_linear_costs,
            control_linear_costs=control_linear_costs,
            terminal_state_cost_matrix=terminal_state_cost_matrix,
            terminal_state_linear_cost=terminal_state_linear_cost,
        )
        self._horizon_steps = horizon_steps
        self._objective = normalized

    def set_state_reference(
        self,
        state_reference,
        terminal_state_reference=None,
    ) -> None:
        """Set one stage reference and an optional distinct terminal reference.

        Omitting ``terminal_state_reference`` applies ``state_reference`` at the
        terminal state as well.  An explicit terminal reference, including zero,
        overrides that inherited value.
        """

        if self._horizon_steps is None:
            raise ValueError("set_horizon must be called before set_state_reference")
        _require_array("state_reference", state_reference)
        _require_array("terminal_state_reference", terminal_state_reference)
        normalized = normalize_state_references(
            n_state=self.n_state,
            horizon_steps=self._horizon_steps,
            state_references=state_reference,
            terminal_state_reference=terminal_state_reference,
        )
        self._state_references = normalized

    def set_time_varying_state_references(
        self,
        state_references,
        terminal_state_reference=None,
    ) -> None:
        """Set stage-indexed state references and a terminal reference.

        An omitted terminal reference inherits the final stage reference.  An
        explicit terminal reference, including zero, overrides that value.
        """

        if not isinstance(state_references, (tuple, list)):
            raise TypeError("state_references must be a tuple/list of NumPy arrays")
        horizon_steps = validate_positive_dimension(
            "number of state references",
            len(state_references),
        )
        if self._horizon_steps is not None and self._horizon_steps != horizon_steps:
            raise ValueError("state reference count does not match horizon_steps")
        normalized = normalize_state_references(
            n_state=self.n_state,
            horizon_steps=horizon_steps,
            state_references=state_references,
            terminal_state_reference=terminal_state_reference,
        )
        self._horizon_steps = horizon_steps
        self._state_references = normalized

    def set_control_reference(self, control_reference) -> None:
        """Set one control reference for every control stage."""

        if self._horizon_steps is None:
            raise ValueError("set_horizon must be called before set_control_reference")
        _require_array("control_reference", control_reference)
        normalized = normalize_control_references(
            n_control=self.n_control,
            horizon_steps=self._horizon_steps,
            control_references=control_reference,
        )
        self._control_references = normalized

    def set_time_varying_control_references(self, control_references) -> None:
        """Set stage-indexed control references."""

        if not isinstance(control_references, (tuple, list)):
            raise TypeError("control_references must be a tuple/list of NumPy arrays")
        horizon_steps = validate_positive_dimension(
            "number of control references",
            len(control_references),
        )
        if self._horizon_steps is not None and self._horizon_steps != horizon_steps:
            raise ValueError("control reference count does not match horizon_steps")
        normalized = normalize_control_references(
            n_control=self.n_control,
            horizon_steps=horizon_steps,
            control_references=control_references,
        )
        self._horizon_steps = horizon_steps
        self._control_references = normalized

    def _require_horizon(self, method_name: str) -> int:
        if self._horizon_steps is None:
            raise ValueError(f"set_horizon must be called before {method_name}")
        return self._horizon_steps

    def _time_varying_horizon(self, name: str, *values: object | None) -> int:
        sequences = []
        for value in values:
            if value is None:
                continue
            if not isinstance(value, (tuple, list)):
                raise TypeError(f"{name} must be tuple/list stage sequences")
            sequences.append(value)
        if not sequences:
            return self._require_horizon(name)
        horizon_steps = validate_positive_dimension(
            f"number of {name} stages",
            len(sequences[0]),
        )
        if self._horizon_steps is not None and self._horizon_steps != horizon_steps:
            raise ValueError(f"{name} stage count does not match horizon_steps")
        return horizon_steps

    def set_control_bounds(self, lower_bound=None, upper_bound=None) -> None:
        """Set one hard control box for every ``u[0]..u[N-1]``."""

        horizon_steps = self._require_horizon("set_control_bounds")
        _require_array("lower_bound", lower_bound)
        _require_array("upper_bound", upper_bound)
        normalized = normalize_bounds(
            name="control",
            horizon_steps=horizon_steps,
            size=self.n_control,
            lower_bounds=lower_bound,
            upper_bounds=upper_bound,
        )
        self._control_lower_bounds = normalized.lower_bounds
        self._control_upper_bounds = normalized.upper_bounds

    def set_time_varying_control_bounds(
        self,
        lower_bounds=None,
        upper_bounds=None,
    ) -> None:
        """Set stage-indexed hard control boxes."""

        horizon_steps = self._time_varying_horizon(
            "control bounds",
            lower_bounds,
            upper_bounds,
        )
        normalized = normalize_bounds(
            name="control",
            horizon_steps=horizon_steps,
            size=self.n_control,
            lower_bounds=lower_bounds,
            upper_bounds=upper_bounds,
        )
        self._horizon_steps = horizon_steps
        self._control_lower_bounds = normalized.lower_bounds
        self._control_upper_bounds = normalized.upper_bounds

    def set_control_rate_bounds(self, lower_bound=None, upper_bound=None) -> None:
        """Set one control-difference box for every control stage."""

        horizon_steps = self._require_horizon("set_control_rate_bounds")
        _require_array("lower_bound", lower_bound)
        _require_array("upper_bound", upper_bound)
        self._control_rate_bounds = normalize_bounds(
            name="control_rate",
            horizon_steps=horizon_steps,
            size=self.n_control,
            lower_bounds=lower_bound,
            upper_bounds=upper_bound,
        )

    def set_time_varying_control_rate_bounds(
        self,
        lower_bounds=None,
        upper_bounds=None,
    ) -> None:
        """Set stage-indexed control-difference boxes."""

        horizon_steps = self._time_varying_horizon(
            "control-rate bounds",
            lower_bounds,
            upper_bounds,
        )
        normalized = normalize_bounds(
            name="control_rate",
            horizon_steps=horizon_steps,
            size=self.n_control,
            lower_bounds=lower_bounds,
            upper_bounds=upper_bounds,
        )
        self._horizon_steps = horizon_steps
        self._control_rate_bounds = normalized

    def set_state_bounds(self, lower_bound=None, upper_bound=None) -> None:
        """Set one hard state box for every predicted ``x[1]..x[N]``."""

        horizon_steps = self._require_horizon("set_state_bounds")
        _require_array("lower_bound", lower_bound)
        _require_array("upper_bound", upper_bound)
        self._state_bounds = normalize_bounds(
            name="state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=lower_bound,
            upper_bounds=upper_bound,
        )

    def set_time_varying_state_bounds(
        self,
        lower_bounds=None,
        upper_bounds=None,
    ) -> None:
        """Set stage-indexed hard boxes for predicted states."""

        horizon_steps = self._time_varying_horizon(
            "state bounds",
            lower_bounds,
            upper_bounds,
        )
        normalized = normalize_bounds(
            name="state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=lower_bounds,
            upper_bounds=upper_bounds,
        )
        self._horizon_steps = horizon_steps
        self._state_bounds = normalized

    def set_soft_state_bounds(self, lower_bound=None, upper_bound=None) -> None:
        """Set one soft state box for every predicted ``x[1]..x[N]``."""

        horizon_steps = self._require_horizon("set_soft_state_bounds")
        _require_array("lower_bound", lower_bound)
        _require_array("upper_bound", upper_bound)
        normalized = normalize_bounds(
            name="soft_state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=lower_bound,
            upper_bounds=upper_bound,
        )
        if self._soft_state_penalties is not None:
            validate_active_soft_state_penalties(
                normalized,
                self._soft_state_penalties,
            )
        self._soft_state_bounds = normalized

    def set_time_varying_soft_state_bounds(
        self,
        lower_bounds=None,
        upper_bounds=None,
    ) -> None:
        """Set stage-indexed soft boxes for predicted states."""

        horizon_steps = self._time_varying_horizon(
            "soft-state bounds",
            lower_bounds,
            upper_bounds,
        )
        normalized = normalize_bounds(
            name="soft_state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=lower_bounds,
            upper_bounds=upper_bounds,
        )
        if self._soft_state_penalties is not None:
            validate_active_soft_state_penalties(
                normalized,
                self._soft_state_penalties,
            )
        self._horizon_steps = horizon_steps
        self._soft_state_bounds = normalized

    def set_soft_state_penalties(
        self,
        linear_penalty=None,
        quadratic_penalty=None,
    ) -> None:
        """Set nonnegative costs for each active lower and upper state slack."""

        horizon_steps = self._require_horizon("set_soft_state_penalties")
        _require_array("linear_penalty", linear_penalty)
        _require_array("quadratic_penalty", quadratic_penalty)
        normalized = normalize_soft_state_penalties(
            horizon_steps=horizon_steps,
            n_state=self.n_state,
            linear_penalties=linear_penalty,
            quadratic_penalties=quadratic_penalty,
        )
        if self._soft_state_bounds is not None:
            validate_active_soft_state_penalties(
                self._soft_state_bounds,
                normalized,
            )
        self._soft_state_penalties = normalized

    def set_time_varying_soft_state_penalties(
        self,
        linear_penalties=None,
        quadratic_penalties=None,
    ) -> None:
        """Set stage-indexed nonnegative state-slack costs."""

        horizon_steps = self._time_varying_horizon(
            "soft-state penalties",
            linear_penalties,
            quadratic_penalties,
        )
        normalized = normalize_soft_state_penalties(
            horizon_steps=horizon_steps,
            n_state=self.n_state,
            linear_penalties=linear_penalties,
            quadratic_penalties=quadratic_penalties,
        )
        if self._soft_state_bounds is not None:
            validate_active_soft_state_penalties(
                self._soft_state_bounds,
                normalized,
            )
        self._horizon_steps = horizon_steps
        self._soft_state_penalties = normalized

    def set_previous_control(self, previous_control) -> None:
        """Set the applied control used by the stage-zero difference row."""

        self._previous_control = normalize_vector(
            "previous_control",
            previous_control,
            self.n_control,
        )

    def set_problem(self, problem: LinearQuadraticMPCProblem) -> None:
        """Validate and install one declarative problem atomically."""

        if not isinstance(problem, LinearQuadraticMPCProblem):
            raise TypeError("problem must be a LinearQuadraticMPCProblem")
        horizon_steps = problem.horizon_steps
        dynamics = normalize_dynamics(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=horizon_steps,
            state_matrices=problem.state_matrices,
            control_matrices=problem.control_matrices,
            affine_offsets=problem.affine_offsets,
        )
        initial_state = normalize_vector(
            "initial_state",
            problem.initial_state,
            self.n_state,
        )
        lower_bounds, upper_bounds = normalize_control_bounds(
            horizon_steps=horizon_steps,
            n_control=self.n_control,
            lower_bounds=problem.control_lower_bounds,
            upper_bounds=problem.control_upper_bounds,
        )
        objective = normalize_objective(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=horizon_steps,
            state_cost_matrices=problem.state_cost_matrices,
            control_cost_matrices=problem.control_cost_matrices,
            state_linear_costs=problem.state_linear_costs,
            control_linear_costs=problem.control_linear_costs,
            terminal_state_cost_matrix=problem.terminal_state_cost_matrix,
            terminal_state_linear_cost=problem.terminal_state_linear_cost,
        )
        state_references = normalize_state_references(
            n_state=self.n_state,
            horizon_steps=horizon_steps,
            state_references=problem.state_references,
            terminal_state_reference=problem.terminal_state_reference,
        )
        control_references = normalize_control_references(
            n_control=self.n_control,
            horizon_steps=horizon_steps,
            control_references=problem.control_references,
        )
        control_rate_bounds = normalize_bounds(
            name="control_rate",
            horizon_steps=horizon_steps,
            size=self.n_control,
            lower_bounds=problem.control_rate_lower_bounds,
            upper_bounds=problem.control_rate_upper_bounds,
        )
        previous_control = (
            None
            if problem.previous_control is None
            else normalize_vector(
                "previous_control",
                problem.previous_control,
                self.n_control,
            )
        )
        if (
            stage_zero_control_rate_requires_previous_control(control_rate_bounds)
            and previous_control is None
        ):
            raise ValueError(
                "previous_control is required when a stage-zero control-rate "
                "bound is finite"
            )
        state_bounds = normalize_bounds(
            name="state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=problem.state_lower_bounds,
            upper_bounds=problem.state_upper_bounds,
        )
        soft_state_bounds = normalize_bounds(
            name="soft_state",
            horizon_steps=horizon_steps,
            size=self.n_state,
            lower_bounds=problem.soft_state_lower_bounds,
            upper_bounds=problem.soft_state_upper_bounds,
        )
        soft_state_penalties = normalize_soft_state_penalties(
            horizon_steps=horizon_steps,
            n_state=self.n_state,
            linear_penalties=problem.soft_state_linear_penalties,
            quadratic_penalties=problem.soft_state_quadratic_penalties,
        )
        validate_active_soft_state_penalties(
            soft_state_bounds,
            soft_state_penalties,
        )

        # Commit only after every declarative field has normalized successfully.
        # Assigning the complete state also clears constraints from a prior problem.
        self._horizon_steps = horizon_steps
        self._dynamics = dynamics
        self._initial_state = initial_state
        self._control_lower_bounds = lower_bounds
        self._control_upper_bounds = upper_bounds
        self._objective = objective
        self._state_references = state_references
        self._control_references = control_references
        self._control_rate_bounds = control_rate_bounds
        self._previous_control = previous_control
        self._state_bounds = state_bounds
        self._soft_state_bounds = soft_state_bounds
        self._soft_state_penalties = soft_state_penalties

    def _effective_configuration(self) -> EffectiveProblemConfiguration | None:
        """Return normalized optional defaults when a horizon is available."""

        if self._horizon_steps is None:
            return None
        return effective_problem_configuration(
            n_state=self.n_state,
            n_control=self.n_control,
            horizon_steps=self._horizon_steps,
            objective=self._objective,
            state_references=self._state_references,
            control_references=self._control_references,
            control_lower_bounds=self._control_lower_bounds,
            control_upper_bounds=self._control_upper_bounds,
            control_rate_bounds=self._control_rate_bounds,
            state_bounds=self._state_bounds,
            soft_state_bounds=self._soft_state_bounds,
            soft_state_penalties=self._soft_state_penalties,
        )

    def _formulate_qp(self) -> QuadraticProgramFormulation:
        """Build the exact sparse QP used by both diagnostics and ``solve``."""

        if self._horizon_steps is None:
            raise ValueError("horizon_steps is not configured")
        if self._dynamics is None:
            raise ValueError("the dynamics model is not configured")
        if self._initial_state is None:
            raise ValueError("initial_state is not configured")
        effective = self._effective_configuration()
        assert effective is not None
        constraints = build_dynamics_constraints(
            dynamics=self._dynamics,
            initial_state=self._initial_state,
            control_lower_bounds=effective.control_bounds.lower_bounds,
            control_upper_bounds=effective.control_bounds.upper_bounds,
            control_rate_bounds=effective.control_rate_bounds,
            previous_control=self._previous_control,
            state_bounds=effective.state_bounds,
            soft_state_bounds=effective.soft_state_bounds,
        )
        objective_matrix, objective_vector, objective_constant = (
            build_quadratic_objective(
                layout=constraints.layout,
                objective=effective.objective,
                state_references=effective.state_references,
                control_references=effective.control_references,
                soft_state_penalties=effective.soft_state_penalties,
            )
        )
        formulation = QuadraticProgramFormulation(
            objective_matrix=objective_matrix,
            objective_vector=objective_vector,
            objective_constant=objective_constant,
            constraints=constraints,
            effective_configuration=effective,
        )
        validate_quadratic_program(formulation)
        return formulation

    def solve(self) -> MPCSolveResult:
        """Formulate, set up, and solve the current problem from scratch."""

        total_start = perf_counter()
        formulation_start = perf_counter()
        formulation = self._formulate_qp()
        formulation_time = perf_counter() - formulation_start
        constraints = formulation.constraints

        try:
            import osqp
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "MPC solver support requires osqp. Install it with "
                "`python -m pip install -e .[mpc]`."
            ) from exc

        optimizer = osqp.OSQP()
        optimizer.setup(
            P=formulation.objective_matrix,
            q=formulation.objective_vector,
            A=constraints.matrix,
            l=constraints.lower_bound,
            u=constraints.upper_bound,
            **self.config.to_osqp_settings(),
        )
        raw_result = optimizer.solve(raise_error=False)
        postprocessing_start = perf_counter()
        info, status, status_code = _read_solver_status(raw_result)
        accepted = status_code == 1 or (
            status_code == 2 and self.config.accept_solved_inaccurate
        )

        if accepted:
            try:
                raw_solution = np.asarray(getattr(raw_result, "x", None))
            except (TypeError, ValueError, OverflowError) as error:
                raise RuntimeError(
                    "accepted OSQP result contains malformed solution"
                ) from error
            if raw_solution.dtype.kind not in "iuf":
                raise RuntimeError(
                    "accepted OSQP result contains malformed solution"
                )
            try:
                solution = np.asarray(raw_solution, dtype=np.float64)
            except (TypeError, ValueError, OverflowError) as error:
                raise RuntimeError(
                    "accepted OSQP result contains malformed solution"
                ) from error
            if (
                solution.shape != (constraints.layout.n_variables,)
                or not np.isfinite(solution).all()
            ):
                raise RuntimeError(
                    "accepted OSQP result contains malformed solution"
                )
            layout = constraints.layout
            state_values = (layout.horizon_steps + 1) * layout.n_state
            control_values = layout.horizon_steps * layout.n_control
            states = solution[:state_values].reshape(
                layout.horizon_steps + 1,
                layout.n_state,
            ).copy()
            assert self._initial_state is not None
            states[0] = self._initial_state.copy()
            controls = solution[
                state_values : state_values + control_values
            ].reshape(
                layout.horizon_steps,
                layout.n_control,
            ).copy()
            lower_slack = np.zeros(
                (layout.horizon_steps, layout.n_state),
                dtype=np.float64,
            )
            upper_slack = np.zeros_like(lower_slack)
            for stage in range(layout.horizon_steps):
                lower_components = layout.lower_slack_components[stage]
                if lower_components:
                    lower_slack[stage, list(lower_components)] = solution[
                        layout.lower_slack_slice(stage)
                    ]
                upper_components = layout.upper_slack_components[stage]
                if upper_components:
                    upper_slack[stage, list(upper_components)] = solution[
                        layout.upper_slack_slice(stage)
                    ]

            primal_norm = float(np.linalg.norm(solution, ord=np.inf))
            slack_tolerance = (
                self.config.absolute_tolerance
                + self.config.relative_tolerance * max(1.0, primal_norm)
            )
            for extracted_slack in (lower_slack, upper_slack):
                if (
                    float(np.min(extracted_slack, initial=0.0))
                    < -slack_tolerance
                ):
                    raise RuntimeError(
                        "accepted OSQP solution contains materially negative slack"
                    )
                np.maximum(extracted_slack, 0.0, out=extracted_slack)

            raw_objective = getattr(info, "obj_val", _MISSING)
            if isinstance(raw_objective, bool) or not isinstance(
                raw_objective,
                Real,
            ):
                raise RuntimeError(
                    "accepted OSQP result contains malformed objective"
                )
            try:
                raw_objective_value = float(raw_objective)
            except (TypeError, ValueError, OverflowError) as error:
                raise RuntimeError(
                    "accepted OSQP result contains malformed objective"
                ) from error
            if not math.isfinite(raw_objective_value):
                raise RuntimeError(
                    "accepted OSQP result contains malformed objective"
                )
            objective_value = evaluate_teaching_objective(
                states=states,
                controls=controls,
                lower_state_slack=lower_slack,
                upper_state_slack=upper_slack,
                configuration=formulation.effective_configuration,
            )
        else:
            states = None
            controls = None
            lower_slack = None
            upper_slack = None
            objective_value = None

        return _make_solver_result(
            status=status,
            status_code=status_code,
            states=states,
            controls=controls,
            lower_slack=lower_slack,
            upper_slack=upper_slack,
            objective=objective_value,
            iterations=getattr(info, "iter", None),
            primal_residual=getattr(info, "prim_res", None),
            dual_residual=getattr(info, "dual_res", None),
            formulation_time_seconds=formulation_time,
            setup_time_seconds=getattr(info, "setup_time", None),
            solve_time_seconds=getattr(info, "solve_time", None),
            run_time_seconds=getattr(info, "run_time", None),
            decision_variable_count=int(
                formulation.objective_matrix.shape[0]
            ),
            constraint_row_count=int(constraints.matrix.shape[0]),
            hessian_nonzero_count=int(formulation.objective_matrix.nnz),
            constraint_matrix_nonzero_count=int(constraints.matrix.nnz),
            postprocessing_started_at=postprocessing_start,
            total_started_at=total_start,
            clock=perf_counter,
        )
