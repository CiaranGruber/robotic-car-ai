"""Configuration contracts for the generic MPC solver."""

from __future__ import annotations

from collections.abc import Mapping
import copy
from dataclasses import dataclass, field
import math
from numbers import Integral, Real

import numpy as np


_RESERVED_TYPED_OSQP_SETTINGS = frozenset(
    {
        "verbose",
        "eps_abs",
        "eps_rel",
        "max_iter",
        "polishing",
        "adaptive_rho",
        "check_termination",
        "time_limit",
    }
)
_REJECTED_OSQP_SETTINGS = frozenset(
    {
        "polish",
        "warm_start",
        "warm_starting",
        "linsys_solver",
        "cg_precond",
        "rho_is_vec",
    }
)
_POSITIVE_REAL_SETTINGS = frozenset(
    {
        "rho",
        "sigma",
        "adaptive_rho_fraction",
        "eps_prim_inf",
        "eps_dual_inf",
        "delta",
    }
)
_NONNEGATIVE_INTEGER_SETTINGS = frozenset(
    {
        "scaling",
        "adaptive_rho_interval",
        "polish_refine_iter",
    }
)
_POSITIVE_INTEGER_SETTINGS = frozenset({"cg_max_iter", "cg_tol_reduction"})
_BOOLEAN_SETTINGS = frozenset({"scaled_termination", "check_dualgap"})


class _ImmutableMapping(Mapping[str, object]):
    """Small read-only mapping that remains compatible with ``asdict``."""

    __slots__ = ("_items",)

    def __init__(self, values: Mapping[str, object]) -> None:
        self._items = tuple(values.items())

    def __getitem__(self, key: str) -> object:
        for candidate, value in self._items:
            if candidate == key:
                return value
        raise KeyError(key)

    def __iter__(self):
        return (key for key, _ in self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Mapping):
            return NotImplemented
        return dict(self) == dict(other)

    def __repr__(self) -> str:
        return repr(dict(self))

    def __deepcopy__(self, memo: dict[int, object]) -> dict[str, object]:
        return copy.deepcopy(dict(self), memo)


def _positive_float(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted) or converted <= 0.0:
        raise ValueError(f"{name} must be finite and greater than zero")
    return converted


def _positive_integer(name: str, value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    converted = int(value)
    if converted <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return converted


def _finite_real_setting(name: str, value: object) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value,
        (Real, np.integer, np.floating),
    ):
        raise TypeError(f"additional_osqp_settings[{name!r}] must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"additional_osqp_settings[{name!r}] must be finite")
    return converted


def _integer_setting(name: str, value: object) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value,
        (Integral, np.integer),
    ):
        raise TypeError(f"additional_osqp_settings[{name!r}] must be an integer")
    return int(value)


def _normalize_additional_osqp_setting(key: str, value: object) -> object:
    if key in _RESERVED_TYPED_OSQP_SETTINGS:
        raise ValueError(
            f"additional_osqp_settings[{key!r}] is reserved by a typed setting"
        )
    if key in _REJECTED_OSQP_SETTINGS:
        raise ValueError(f"additional_osqp_settings[{key!r}] is not supported")

    if key in _POSITIVE_REAL_SETTINGS:
        converted_real = _finite_real_setting(key, value)
        if converted_real <= 0.0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be greater than zero"
            )
        return converted_real

    if key == "alpha":
        converted_real = _finite_real_setting(key, value)
        if not 0.0 < converted_real < 2.0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be between zero and two"
            )
        return converted_real

    if key == "adaptive_rho_tolerance":
        converted_real = _finite_real_setting(key, value)
        if converted_real < 1.0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be at least one"
            )
        return converted_real

    if key == "cg_tol_fraction":
        converted_real = _finite_real_setting(key, value)
        if not 0.0 < converted_real < 1.0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be between zero and one"
            )
        return converted_real

    if key in _NONNEGATIVE_INTEGER_SETTINGS:
        converted_integer = _integer_setting(key, value)
        if converted_integer < 0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be nonnegative"
            )
        return converted_integer

    if key in _POSITIVE_INTEGER_SETTINGS:
        converted_integer = _integer_setting(key, value)
        if converted_integer <= 0:
            raise ValueError(
                f"additional_osqp_settings[{key!r}] must be greater than zero"
            )
        return converted_integer

    if key in _BOOLEAN_SETTINGS:
        if not isinstance(value, (bool, np.bool_)):
            raise TypeError(f"additional_osqp_settings[{key!r}] must be a bool")
        return bool(value)

    if key == "device":
        converted_integer = _integer_setting(key, value)
        if converted_integer != 0:
            raise ValueError(f"additional_osqp_settings[{key!r}] must be zero")
        return converted_integer

    raise ValueError(f"additional_osqp_settings[{key!r}] is not supported")


@dataclass(frozen=True, slots=True)
class MPCSolverConfig:
    """Validated, dependency-light settings for the OSQP-backed solver."""

    dtype: str = "float64"
    verbose: bool = False
    absolute_tolerance: float = 1.0e-3
    relative_tolerance: float = 1.0e-3
    max_iterations: int = 4000
    polishing: bool = False
    adaptive_rho: bool = True
    check_termination_interval: int = 25
    time_limit_seconds: float | None = None
    accept_solved_inaccurate: bool = True
    additional_osqp_settings: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.dtype, str):
            raise TypeError("dtype must be a string")
        if self.dtype != "float64":
            raise ValueError("dtype must be 'float64'")

        for field_name in (
            "verbose",
            "polishing",
            "adaptive_rho",
            "accept_solved_inaccurate",
        ):
            if not isinstance(getattr(self, field_name), bool):
                raise TypeError(f"{field_name} must be a bool")

        object.__setattr__(
            self,
            "absolute_tolerance",
            _positive_float("absolute_tolerance", self.absolute_tolerance),
        )
        object.__setattr__(
            self,
            "relative_tolerance",
            _positive_float("relative_tolerance", self.relative_tolerance),
        )
        object.__setattr__(
            self,
            "max_iterations",
            _positive_integer("max_iterations", self.max_iterations),
        )
        object.__setattr__(
            self,
            "check_termination_interval",
            _positive_integer(
                "check_termination_interval",
                self.check_termination_interval,
            ),
        )
        if self.time_limit_seconds is not None:
            object.__setattr__(
                self,
                "time_limit_seconds",
                _positive_float("time_limit_seconds", self.time_limit_seconds),
            )

        if not isinstance(self.additional_osqp_settings, Mapping):
            raise TypeError("additional_osqp_settings must be a mapping")
        copied_settings = dict(self.additional_osqp_settings)
        if not all(isinstance(key, str) for key in copied_settings):
            raise TypeError("additional_osqp_settings keys must be strings")
        normalized_settings = {
            key: _normalize_additional_osqp_setting(key, value)
            for key, value in copied_settings.items()
        }
        object.__setattr__(
            self,
            "additional_osqp_settings",
            _ImmutableMapping(normalized_settings),
        )

    def to_osqp_settings(self) -> dict[str, object]:
        """Return a fresh OSQP settings dictionary."""

        settings = {
            "verbose": self.verbose,
            "eps_abs": self.absolute_tolerance,
            "eps_rel": self.relative_tolerance,
            "max_iter": self.max_iterations,
            "polishing": self.polishing,
            "adaptive_rho": self.adaptive_rho,
            "check_termination": self.check_termination_interval,
        }
        if self.time_limit_seconds is not None:
            settings["time_limit"] = self.time_limit_seconds
        settings.update(dict(self.additional_osqp_settings))
        return settings
