"""Declarative problem data for linear-quadratic MPC."""

from __future__ import annotations

from dataclasses import dataclass, fields
from numbers import Integral

import numpy as np


def _read_only_array(
    name: str,
    value: object,
    expected_shape: tuple[int, ...],
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.shape != expected_shape:
        raise ValueError(
            f"{name} must have shape {expected_shape}, got {value.shape}"
        )
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    copied = np.array(value, copy=True)
    copied.setflags(write=False)
    return copied


def _stage_arrays(
    name: str,
    value: object,
    horizon_steps: int,
    expected_shape: tuple[int, ...],
) -> np.ndarray | tuple[np.ndarray, ...]:
    if isinstance(value, np.ndarray):
        return _read_only_array(name, value, expected_shape)
    if not isinstance(value, (tuple, list)):
        raise TypeError(
            f"{name} must be a NumPy array or a tuple/list of NumPy arrays"
        )
    if len(value) != horizon_steps:
        raise ValueError(
            f"{name} must contain {horizon_steps} stage arrays, got {len(value)}"
        )
    return tuple(
        _read_only_array(f"{name}[{index}]", stage, expected_shape)
        for index, stage in enumerate(value)
    )


def _control_stage_arrays(
    value: object,
    horizon_steps: int,
    n_state: int,
) -> tuple[np.ndarray | tuple[np.ndarray, ...], int]:
    if isinstance(value, np.ndarray):
        candidates = (value,)
    elif isinstance(value, (tuple, list)):
        if len(value) != horizon_steps:
            raise ValueError(
                "control_matrices must contain "
                f"{horizon_steps} stage arrays, got {len(value)}"
            )
        candidates = tuple(value)
    else:
        raise TypeError(
            "control_matrices must be a NumPy array or a tuple/list of NumPy arrays"
        )

    first = candidates[0]
    if not isinstance(first, np.ndarray):
        raise TypeError("control_matrices[0] must be a NumPy array")
    if first.ndim != 2 or first.shape[0] != n_state or first.shape[1] <= 0:
        raise ValueError(
            "control_matrices must have shape (n_state, n_control) with "
            "n_control greater than zero"
        )
    n_control = first.shape[1]
    expected_shape = (n_state, n_control)

    if isinstance(value, np.ndarray):
        return _read_only_array("control_matrices", value, expected_shape), n_control
    return (
        tuple(
            _read_only_array(
                f"control_matrices[{index}]",
                stage,
                expected_shape,
            )
            for index, stage in enumerate(candidates)
        ),
        n_control,
    )


@dataclass(frozen=True, slots=True)
class LinearQuadraticMPCProblem:
    """Atomic, immutable input data for one finite-horizon MPC problem."""

    horizon_steps: int
    state_matrices: object
    control_matrices: object
    initial_state: np.ndarray
    affine_offsets: object | None = None
    state_cost_matrices: object | None = None
    control_cost_matrices: object | None = None
    state_linear_costs: object | None = None
    control_linear_costs: object | None = None
    terminal_state_cost_matrix: np.ndarray | None = None
    terminal_state_linear_cost: np.ndarray | None = None
    state_references: object | None = None
    terminal_state_reference: np.ndarray | None = None
    control_references: object | None = None
    control_lower_bounds: object | None = None
    control_upper_bounds: object | None = None
    control_rate_lower_bounds: object | None = None
    control_rate_upper_bounds: object | None = None
    previous_control: np.ndarray | None = None
    state_lower_bounds: object | None = None
    state_upper_bounds: object | None = None
    soft_state_lower_bounds: object | None = None
    soft_state_upper_bounds: object | None = None
    soft_state_linear_penalties: object | None = None
    soft_state_quadratic_penalties: object | None = None

    def __post_init__(self) -> None:
        if isinstance(self.horizon_steps, bool) or not isinstance(
            self.horizon_steps, Integral
        ):
            raise TypeError("horizon_steps must be an integer")
        horizon_steps = int(self.horizon_steps)
        if horizon_steps <= 0:
            raise ValueError("horizon_steps must be greater than zero")
        object.__setattr__(self, "horizon_steps", horizon_steps)

        if not isinstance(self.initial_state, np.ndarray):
            raise TypeError("initial_state must be a NumPy array")
        if self.initial_state.ndim != 1 or self.initial_state.shape[0] <= 0:
            raise ValueError("initial_state must be a nonempty one-dimensional array")
        n_state = self.initial_state.shape[0]
        object.__setattr__(
            self,
            "initial_state",
            _read_only_array("initial_state", self.initial_state, (n_state,)),
        )
        object.__setattr__(
            self,
            "state_matrices",
            _stage_arrays(
                "state_matrices",
                self.state_matrices,
                horizon_steps,
                (n_state, n_state),
            ),
        )
        control_matrices, n_control = _control_stage_arrays(
            self.control_matrices,
            horizon_steps,
            n_state,
        )
        object.__setattr__(self, "control_matrices", control_matrices)

        state_stage_fields = (
            "affine_offsets",
            "state_linear_costs",
            "state_references",
            "state_lower_bounds",
            "state_upper_bounds",
            "soft_state_lower_bounds",
            "soft_state_upper_bounds",
            "soft_state_linear_penalties",
            "soft_state_quadratic_penalties",
        )
        state_matrix_stage_fields = ("state_cost_matrices",)
        control_stage_fields = (
            "control_linear_costs",
            "control_references",
            "control_lower_bounds",
            "control_upper_bounds",
            "control_rate_lower_bounds",
            "control_rate_upper_bounds",
        )
        control_matrix_stage_fields = ("control_cost_matrices",)

        for field_name in state_stage_fields:
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _stage_arrays(
                        field_name,
                        value,
                        horizon_steps,
                        (n_state,),
                    ),
                )
        for field_name in state_matrix_stage_fields:
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _stage_arrays(
                        field_name,
                        value,
                        horizon_steps,
                        (n_state, n_state),
                    ),
                )
        for field_name in control_stage_fields:
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _stage_arrays(
                        field_name,
                        value,
                        horizon_steps,
                        (n_control,),
                    ),
                )
        for field_name in control_matrix_stage_fields:
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _stage_arrays(
                        field_name,
                        value,
                        horizon_steps,
                        (n_control, n_control),
                    ),
                )

        terminal_shapes = {
            "terminal_state_cost_matrix": (n_state, n_state),
            "terminal_state_linear_cost": (n_state,),
            "terminal_state_reference": (n_state,),
            "previous_control": (n_control,),
        }
        for field_name, expected_shape in terminal_shapes.items():
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _read_only_array(field_name, value, expected_shape),
                )

        # Keep this assertion close to the normalization logic so adding a public
        # field cannot silently skip defensive handling.
        handled_fields = {
            "horizon_steps",
            "state_matrices",
            "control_matrices",
            "initial_state",
            *state_stage_fields,
            *state_matrix_stage_fields,
            *control_stage_fields,
            *control_matrix_stage_fields,
            *terminal_shapes,
        }
        assert handled_fields == {field.name for field in fields(self)}
