"""Dependency-light structured results returned by the generic MPC solver."""

from __future__ import annotations

from dataclasses import dataclass
import math
from numbers import Integral, Real
from typing import Callable

import numpy as np


def _prediction_matrix(
    name: str,
    value: object,
    *,
    copy_array: bool,
) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a NumPy array")
    if value.ndim != 2:
        raise ValueError(f"{name} must be a two-dimensional array")
    if value.dtype.kind not in "iuf":
        raise TypeError(f"{name} must have a real numeric dtype")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} must contain only finite values")
    if copy_array:
        return np.array(value, copy=True)
    return value


def _finite_number(name: str, value: object, *, nonnegative: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{name} must be finite")
    if nonnegative and converted < 0.0:
        raise ValueError(f"{name} must be nonnegative")
    return converted


def _optional_strict_nonnegative_integer(
    name: str,
    value: object,
) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer or None")
    converted = int(value)
    if converted < 0:
        raise ValueError(f"{name} must be nonnegative")
    return converted


def _validated_prediction_values(
    *,
    states: object,
    controls: object,
    lower_state_slack: object,
    upper_state_slack: object,
    objective_value: object,
    copy_arrays: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    states_array = _prediction_matrix(
        "states",
        states,
        copy_array=copy_arrays,
    )
    controls_array = _prediction_matrix(
        "controls",
        controls,
        copy_array=copy_arrays,
    )
    lower_slack_array = _prediction_matrix(
        "lower_state_slack",
        lower_state_slack,
        copy_array=copy_arrays,
    )
    upper_slack_array = _prediction_matrix(
        "upper_state_slack",
        upper_state_slack,
        copy_array=copy_arrays,
    )

    horizon_steps, n_control = controls_array.shape
    if horizon_steps <= 0:
        raise ValueError("controls must contain at least one horizon step")
    if n_control <= 0:
        raise ValueError("controls must have at least one column")
    if states_array.shape[0] != horizon_steps + 1 or states_array.shape[1] <= 0:
        raise ValueError(
            "states must have shape (number of controls + 1, n_state) "
            "with a positive n_state"
        )
    expected_slack_shape = (horizon_steps, states_array.shape[1])
    if lower_slack_array.shape != expected_slack_shape:
        raise ValueError(
            "lower_state_slack must have shape "
            f"{expected_slack_shape}, got {lower_slack_array.shape}"
        )
    if upper_slack_array.shape != expected_slack_shape:
        raise ValueError(
            "upper_state_slack must have shape "
            f"{expected_slack_shape}, got {upper_slack_array.shape}"
        )
    if np.any(lower_slack_array < 0.0):
        raise ValueError("lower_state_slack must be nonnegative")
    if np.any(upper_slack_array < 0.0):
        raise ValueError("upper_state_slack must be nonnegative")
    objective = _finite_number("objective_value", objective_value)

    arrays = (
        states_array,
        controls_array,
        lower_slack_array,
        upper_slack_array,
    )
    for values in arrays:
        values.setflags(write=False)
    return (*arrays, objective)


def _optional_nonnegative_float(value: object) -> float | None:
    if value is None or isinstance(value, bool) or not isinstance(value, Real):
        return None
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(converted) or converted < 0.0:
        return None
    return converted


def _optional_nonnegative_integer(value: object) -> int | None:
    if value is None or isinstance(value, bool) or not isinstance(value, Integral):
        return None
    converted = int(value)
    if converted < 0:
        return None
    return converted


@dataclass(frozen=True, slots=True)
class MPCPrediction:
    """Finite, shape-consistent prediction produced by an MPC solve."""

    states: np.ndarray
    controls: np.ndarray
    lower_state_slack: np.ndarray
    upper_state_slack: np.ndarray
    objective_value: float

    def __post_init__(self) -> None:
        states, controls, lower_slack, upper_slack, objective = (
            _validated_prediction_values(
                states=self.states,
                controls=self.controls,
                lower_state_slack=self.lower_state_slack,
                upper_state_slack=self.upper_state_slack,
                objective_value=self.objective_value,
                copy_arrays=True,
            )
        )

        object.__setattr__(self, "states", states)
        object.__setattr__(self, "controls", controls)
        object.__setattr__(self, "lower_state_slack", lower_slack)
        object.__setattr__(self, "upper_state_slack", upper_slack)
        object.__setattr__(self, "objective_value", objective)

    @property
    def N(self) -> int:
        """Number of control intervals in the prediction horizon."""

        return self.controls.shape[0]

    @property
    def n_state(self) -> int:
        """State dimension."""

        return self.states.shape[1]

    @property
    def n_control(self) -> int:
        """Control dimension."""

        return self.controls.shape[1]


@dataclass(frozen=True, slots=True)
class MPCSolveDiagnostics:
    """Optional backend metrics and required locally measured solve timings."""

    iterations: int | None
    primal_residual: float | None
    dual_residual: float | None
    formulation_time_seconds: float
    setup_time_seconds: float | None
    solve_time_seconds: float | None
    run_time_seconds: float | None
    postprocessing_time_seconds: float
    total_time_seconds: float
    decision_variable_count: int | None = None
    constraint_row_count: int | None = None
    hessian_nonzero_count: int | None = None
    constraint_matrix_nonzero_count: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "iterations",
            _optional_nonnegative_integer(self.iterations),
        )
        for field_name in (
            "primal_residual",
            "dual_residual",
            "setup_time_seconds",
            "solve_time_seconds",
            "run_time_seconds",
        ):
            object.__setattr__(
                self,
                field_name,
                _optional_nonnegative_float(getattr(self, field_name)),
            )
        for field_name in (
            "formulation_time_seconds",
            "postprocessing_time_seconds",
            "total_time_seconds",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_number(
                    field_name,
                    getattr(self, field_name),
                    nonnegative=True,
                ),
            )
        for field_name in (
            "decision_variable_count",
            "constraint_row_count",
            "hessian_nonzero_count",
            "constraint_matrix_nonzero_count",
        ):
            object.__setattr__(
                self,
                field_name,
                _optional_strict_nonnegative_integer(
                    field_name,
                    getattr(self, field_name),
                ),
            )


@dataclass(frozen=True, slots=True)
class MPCSolveResult:
    """Exact solver status, optional prediction, and solve diagnostics."""

    status: str
    status_code: int
    prediction: MPCPrediction | None
    diagnostics: MPCSolveDiagnostics

    def __post_init__(self) -> None:
        if not isinstance(self.status, str):
            raise TypeError("status must be a string")
        if not self.status:
            raise ValueError("status must not be empty")
        if isinstance(self.status_code, bool) or not isinstance(
            self.status_code,
            Integral,
        ):
            raise TypeError("status_code must be an integer")
        status_code = int(self.status_code)
        object.__setattr__(self, "status_code", status_code)
        if self.prediction is not None and not isinstance(
            self.prediction,
            MPCPrediction,
        ):
            raise TypeError("prediction must be an MPCPrediction or None")
        if not isinstance(self.diagnostics, MPCSolveDiagnostics):
            raise TypeError("diagnostics must be an MPCSolveDiagnostics")

        if status_code == 1 and self.prediction is None:
            raise ValueError("status code 1 requires a prediction")
        if status_code not in (1, 2) and self.prediction is not None:
            raise ValueError(
                f"status code {status_code} must not contain a prediction"
            )

    @property
    def usable(self) -> bool:
        """Whether this result contains a prediction safe for consumption."""

        return self.prediction is not None

    @property
    def first_control(self) -> np.ndarray | None:
        """Return a defensive copy of the first predicted control, if present."""

        if self.prediction is None:
            return None
        return self.prediction.controls[0].copy()

    @property
    def objective_value(self) -> float | None:
        """Return the prediction objective, or ``None`` for failed solves."""

        if self.prediction is None:
            return None
        return self.prediction.objective_value


def _adopt_solver_prediction(
    *,
    states: np.ndarray,
    controls: np.ndarray,
    lower_slack: np.ndarray,
    upper_slack: np.ndarray,
    objective: float,
) -> MPCPrediction:
    """Adopt validated solver-owned arrays without a second defensive copy."""

    states, controls, lower_slack, upper_slack, objective = (
        _validated_prediction_values(
            states=states,
            controls=controls,
            lower_state_slack=lower_slack,
            upper_state_slack=upper_slack,
            objective_value=objective,
            copy_arrays=False,
        )
    )
    prediction = object.__new__(MPCPrediction)
    object.__setattr__(prediction, "states", states)
    object.__setattr__(prediction, "controls", controls)
    object.__setattr__(prediction, "lower_state_slack", lower_slack)
    object.__setattr__(prediction, "upper_state_slack", upper_slack)
    object.__setattr__(prediction, "objective_value", objective)
    return prediction


def _make_solver_result(
    *,
    status: str,
    status_code: int,
    states: np.ndarray | None,
    controls: np.ndarray | None,
    lower_slack: np.ndarray | None,
    upper_slack: np.ndarray | None,
    objective: float | None,
    iterations: object,
    primal_residual: object,
    dual_residual: object,
    formulation_time_seconds: float,
    setup_time_seconds: object,
    solve_time_seconds: object,
    run_time_seconds: object,
    decision_variable_count: object = None,
    constraint_row_count: object = None,
    hessian_nonzero_count: object = None,
    constraint_matrix_nonzero_count: object = None,
    postprocessing_started_at: float,
    total_started_at: float,
    clock: Callable[[], float],
) -> MPCSolveResult:
    """Build one result from validated solver-owned extraction values."""

    if states is None:
        prediction = None
    else:
        assert controls is not None
        assert lower_slack is not None
        assert upper_slack is not None
        assert objective is not None
        prediction = _adopt_solver_prediction(
            states=states,
            controls=controls,
            lower_slack=lower_slack,
            upper_slack=upper_slack,
            objective=objective,
        )
    diagnostics = MPCSolveDiagnostics(
        iterations=iterations,
        primal_residual=primal_residual,
        dual_residual=dual_residual,
        formulation_time_seconds=formulation_time_seconds,
        setup_time_seconds=setup_time_seconds,
        solve_time_seconds=solve_time_seconds,
        run_time_seconds=run_time_seconds,
        postprocessing_time_seconds=0.0,
        total_time_seconds=0.0,
        decision_variable_count=decision_variable_count,
        constraint_row_count=constraint_row_count,
        hessian_nonzero_count=hessian_nonzero_count,
        constraint_matrix_nonzero_count=constraint_matrix_nonzero_count,
    )
    result = MPCSolveResult(
        status=status,
        status_code=status_code,
        prediction=prediction,
        diagnostics=diagnostics,
    )
    finished_at = clock()
    postprocessing = finished_at - postprocessing_started_at
    total = finished_at - total_started_at
    object.__setattr__(
        diagnostics,
        "postprocessing_time_seconds",
        postprocessing,
    )
    object.__setattr__(diagnostics, "total_time_seconds", total)
    return result
