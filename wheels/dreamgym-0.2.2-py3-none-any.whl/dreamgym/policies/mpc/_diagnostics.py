"""Human-readable inspection helpers for the generic linear MPC solver."""

from __future__ import annotations

from numbers import Integral

import numpy as np


def _nonnegative_integer(name: str, value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    converted = int(value)
    if converted < 0:
        raise ValueError(f"{name} must be nonnegative")
    return converted


def _array_string(value: object, decimals: int) -> str:
    try:
        from scipy import sparse
    except ModuleNotFoundError:
        sparse = None
    if sparse is not None and sparse.issparse(value):
        value = value.toarray()
    array = np.asarray(value)
    formatter = {"float_kind": lambda number: f"{number:.{decimals}f}"}
    return np.array2string(array, max_line_width=200, formatter=formatter)


def _stage_preview(values: object, maximum: int) -> str:
    if values is None:
        return "None"
    stages = tuple(values)
    if maximum == 0 and stages:
        return "[...]"
    shown = stages[:maximum]
    suffix = ", ..." if len(stages) > maximum else ""
    return "[" + ", ".join(_array_string(stage, 3) for stage in shown) + suffix + "]"


class MPCDiagnosticsMixin:
    """Print normalized configuration and the exact sparse QP sent to OSQP."""

    def print_configuration(
        self,
        verbose: bool = False,
        max_stage_preview: int = 2,
    ) -> None:
        """Print dimensions and optionally normalized stage-data previews."""

        if not isinstance(verbose, bool):
            raise TypeError("verbose must be a bool")
        maximum = _nonnegative_integer("max_stage_preview", max_stage_preview)
        print("LinearQuadraticMPCSolver configuration")
        print(f"n_state: {self.n_state}")
        print(f"n_control: {self.n_control}")
        print(f"horizon_steps: {self._horizon_steps}")
        print(f"dtype: {self.config.dtype}")
        print(
            "accept_solved_inaccurate: "
            f"{self.config.accept_solved_inaccurate}"
        )
        if not verbose:
            return

        effective = self._effective_configuration()
        stage_previews = (
            (
                "state_matrices",
                None if self._dynamics is None else self._dynamics.state_matrices,
            ),
            (
                "control_matrices",
                None if self._dynamics is None else self._dynamics.control_matrices,
            ),
            (
                "affine_offsets",
                None if self._dynamics is None else self._dynamics.affine_offsets,
            ),
            (
                "state_cost_matrices",
                None
                if effective is None
                else effective.objective.state_cost_matrices,
            ),
            (
                "control_cost_matrices",
                None
                if effective is None
                else effective.objective.control_cost_matrices,
            ),
            (
                "state_linear_costs",
                None
                if effective is None
                else effective.objective.state_linear_costs,
            ),
            (
                "control_linear_costs",
                None
                if effective is None
                else effective.objective.control_linear_costs,
            ),
            (
                "state_references",
                None
                if effective is None
                else effective.state_references.stage_references,
            ),
            (
                "control_references",
                None
                if effective is None
                else effective.control_references.stage_references,
            ),
            (
                "control_lower_bounds",
                None if effective is None else effective.control_bounds.lower_bounds,
            ),
            (
                "control_upper_bounds",
                None if effective is None else effective.control_bounds.upper_bounds,
            ),
            (
                "control_rate_lower_bounds",
                None
                if effective is None
                else effective.control_rate_bounds.lower_bounds,
            ),
            (
                "control_rate_upper_bounds",
                None
                if effective is None
                else effective.control_rate_bounds.upper_bounds,
            ),
            (
                "state_lower_bounds",
                None
                if effective is None
                else effective.state_bounds.lower_bounds,
            ),
            (
                "state_upper_bounds",
                None
                if effective is None
                else effective.state_bounds.upper_bounds,
            ),
            (
                "soft_state_lower_bounds",
                None
                if effective is None
                else effective.soft_state_bounds.lower_bounds,
            ),
            (
                "soft_state_upper_bounds",
                None
                if effective is None
                else effective.soft_state_bounds.upper_bounds,
            ),
            (
                "soft_state_linear_penalties",
                None
                if effective is None
                else effective.soft_state_penalties.linear_penalties,
            ),
            (
                "soft_state_quadratic_penalties",
                None
                if effective is None
                else effective.soft_state_penalties.quadratic_penalties,
            ),
        )
        for label, values in stage_previews:
            print(f"{label}: {_stage_preview(values, maximum)}")

        single_values = (
            (
                "terminal_state_cost_matrix",
                None
                if effective is None
                else effective.objective.terminal_state_cost_matrix,
            ),
            (
                "terminal_state_linear_cost",
                None
                if effective is None
                else effective.objective.terminal_state_linear_cost,
            ),
            (
                "terminal_state_reference",
                None
                if effective is None
                else effective.state_references.terminal_reference,
            ),
            ("previous_control", self._previous_control),
        )
        for label, value in single_values:
            print(f"{label}: {_array_string(value, 3)}")
        print(f"initial_state: {_array_string(self._initial_state, 3)}")

    def print_variable_layout(self, as_row: bool = False) -> None:
        """Print the ordered state/control/active-slack decision blocks."""

        if not isinstance(as_row, bool):
            raise TypeError("as_row must be a bool")
        layout = self._formulate_qp().constraints.layout
        labels = [f"x[{stage}]" for stage in range(layout.horizon_steps + 1)]
        labels.extend(f"u[{stage}]" for stage in range(layout.horizon_steps))
        for stage in range(layout.horizon_steps):
            if layout.lower_slack_components[stage]:
                labels.append(f"lower_slack[{stage}]")
            if layout.upper_slack_components[stage]:
                labels.append(f"upper_slack[{stage}]")
        if as_row:
            print("[" + ", ".join(labels) + "]")
            return
        print("[")
        for label in labels:
            print(f"  {label},")
        print("]")

    def print_objective(self, decimals: int = 3) -> None:
        """Print the exact OSQP Hessian/vector and omitted constant."""

        decimals = _nonnegative_integer("decimals", decimals)
        formulation = self._formulate_qp()
        print(f"P = {_array_string(formulation.objective_matrix, decimals)}")
        print(f"q = {_array_string(formulation.objective_vector, decimals)}")
        print(
            "objective_constant = "
            f"{formulation.objective_constant:.{decimals}f}"
        )

    def print_constraints(self, decimals: int = 3) -> None:
        """Print the exact ``l <= A z <= u`` matrices and vectors."""

        decimals = _nonnegative_integer("decimals", decimals)
        constraints = self._formulate_qp().constraints
        print(
            "constraint_row_layout: explicit "
            "(including unbounded control-box rows)"
        )
        print("l <= A z <= u")
        print(f"A = {_array_string(constraints.matrix, decimals)}")
        print(f"l = {_array_string(constraints.lower_bound, decimals)}")
        print(f"u = {_array_string(constraints.upper_bound, decimals)}")
