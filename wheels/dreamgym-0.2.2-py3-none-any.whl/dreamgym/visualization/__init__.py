"""Visualization namespaces for dreamgym environments."""

from importlib import import_module
from types import MappingProxyType

__all__ = [
    "plot_metric_histograms",
    "plot_pareto_scatter",
    "plot_policy_metric_bars",
    "save_performance_metric_plots",
    "AutonomousDrivingVisualizationTheme",
    "default_autonomous_driving_visualization_theme",
    "resolve_autonomous_driving_visualization_theme",
]

_EXPORTS = MappingProxyType(
    {
        **{
            name: ("dreamgym.visualization.performance_metrics", name)
            for name in (
                "plot_metric_histograms",
                "plot_pareto_scatter",
                "plot_policy_metric_bars",
                "save_performance_metric_plots",
            )
        },
        **{
            name: ("dreamgym.visualization.autonomous_driving.theme", name)
            for name in (
                "AutonomousDrivingVisualizationTheme",
                "default_autonomous_driving_visualization_theme",
                "resolve_autonomous_driving_visualization_theme",
            )
        },
    }
)


def __getattr__(name):
    try:
        module_name, attribute_name = _EXPORTS[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None
    value = getattr(import_module(module_name), attribute_name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(__all__))
