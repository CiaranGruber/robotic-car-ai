"""Autonomous-driving visualization helpers."""

from importlib import import_module
from types import MappingProxyType

__all__ = [
    "animate_simulation_trajectory",
    "plot_current_state",
    "plot_eval_summary",
    "plot_run_comparison",
    "plot_road_from_spec",
    "plot_simulation_results",
    "plot_training_progress",
    "save_current_state_plot",
    "save_figure",
    "save_road_plot",
    "save_simulation_result_plots",
    "save_trajectory_animation",
]

__all__.append("plot_mpc_prediction_at_transition")
__all__.append("plot_mpc_prediction_horizon_fan")
__all__.append("plot_mpc_fixed_lead_predictions")
__all__.append("plot_mpc_solver_health")
__all__.append("plot_mpc_controller_outcomes")
__all__.append("animate_mpc_prediction_history")
__all__.append("plot_mpc_world_prediction_at_transition")
__all__.append("animate_mpc_world_prediction_history")
__all__.append("MPCLivePredictionOverlayConfig")
__all__.append("AutonomousDrivingMPCLivePredictionOverlayAdapter")
__all__.extend(
    [
        "AutonomousDrivingVisualizationTheme",
        "default_autonomous_driving_visualization_theme",
        "resolve_autonomous_driving_visualization_theme",
    ]
)

_EXPORTS = MappingProxyType(
    {
        **{
            name: ("dreamgym.visualization.autonomous_driving.matplotlib", name)
            for name in (
                "animate_simulation_trajectory",
                "plot_current_state",
                "plot_eval_summary",
                "plot_run_comparison",
                "plot_road_from_spec",
                "plot_simulation_results",
                "plot_training_progress",
                "save_current_state_plot",
                "save_figure",
                "save_road_plot",
                "save_simulation_result_plots",
                "save_trajectory_animation",
            )
        },
        **{
            name: ("dreamgym.visualization.autonomous_driving.mpc", name)
            for name in (
                "plot_mpc_prediction_at_transition",
                "plot_mpc_prediction_horizon_fan",
                "plot_mpc_fixed_lead_predictions",
                "plot_mpc_solver_health",
                "plot_mpc_controller_outcomes",
                "animate_mpc_prediction_history",
            )
        },
        **{
            name: ("dreamgym.visualization.autonomous_driving.mpc_world", name)
            for name in (
                "plot_mpc_world_prediction_at_transition",
                "animate_mpc_world_prediction_history",
            )
        },
        **{
            name: ("dreamgym.visualization.autonomous_driving.mpc_live", name)
            for name in (
                "MPCLivePredictionOverlayConfig",
                "AutonomousDrivingMPCLivePredictionOverlayAdapter",
            )
        },
        **{
            name: ("dreamgym.visualization.autonomous_driving.theme", name)
            for name in (
                "AutonomousDrivingVisualizationTheme",
                "default_autonomous_driving_visualization_theme",
                "resolve_autonomous_driving_visualization_theme",
            )
        },
    }
)


def __getattr__(name):
    try:
        module_name, attribute_name = _EXPORTS[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None
    value = getattr(import_module(module_name), attribute_name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(__all__))
