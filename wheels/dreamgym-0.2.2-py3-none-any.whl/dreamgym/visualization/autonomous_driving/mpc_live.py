"""Live autonomous-driving MPC prediction overlay configuration."""

from __future__ import annotations

from dataclasses import dataclass, fields

import numpy as np

from dreamgym.envs._render_overlay import (
    _AutonomousDrivingRenderOverlaySnapshot,
    _RenderOverlayMarker,
    _RenderOverlayPolyline,
    _validated_nonnegative_integer,
)


@dataclass(frozen=True, slots=True)
class MPCLivePredictionOverlayConfig:
    """Select the MPC prediction content shown by the live renderer."""

    show_formulation_target: bool = True
    show_prediction_nodes: bool = True
    show_status: bool = True
    show_predicted_headings: bool = False
    show_sensor_preview_samples: bool = False
    show_lane_envelope: bool = False
    show_speed_and_curvature_annotations: bool = False

    def __post_init__(self) -> None:
        for item in fields(self):
            if type(getattr(self, item.name)) is not bool:
                raise TypeError(f"{item.name} must be a bool")


def _status_lines_for_projection(
    *,
    config,
    formulation,
    policy_result,
    outcome,
) -> tuple[str, ...]:
    lines = []
    if config.show_status:
        solve_status = policy_result.solve_status
        if solve_status is None:
            failure = policy_result.failure
            solve_status = (
                "pre-solver failure"
                if failure is None
                else f"{failure.stage.value}: {failure.reason}"
            )
        lines.append(f"MPC {formulation.value}: {solve_status}")
    if outcome.world_prediction is None:
        if config.show_status:
            lines.append(
                f"projection: {outcome.unavailability_reason.value}"
            )
        return tuple(lines)

    prediction = outcome.world_prediction
    if config.show_status:
        lines.append(
            "timing: controller "
            f"{1000.0 * policy_result.total_time_seconds:.2f} ms, "
            f"projection {1000.0 * prediction.projection_time_seconds:.2f} ms"
        )
    if config.show_speed_and_curvature_annotations:
        references = policy_result.reference_speeds_mps
        if references is not None:
            lines.append(
                "speed reference: "
                f"{float(np.min(references)):.2f}-"
                f"{float(np.max(references)):.2f} m/s"
            )
        road_context = policy_result.road_horizon_context
        curvatures = (
            None
            if road_context is None
            else road_context.interpolated_target_line_curvatures_per_metre
        )
        if curvatures is not None:
            lines.append(
                "curvature: max |k|="
                f"{float(np.max(np.abs(curvatures))):.4f} 1/m"
            )
    return tuple(lines[:4])


def _snapshot_from_projection_outcome(
    *,
    episode_generation,
    transition_index,
    config,
    formulation,
    policy_result,
    outcome,
):
    """Convert canonical evaluator output to policy-neutral renderer data."""

    status_lines = _status_lines_for_projection(
        config=config,
        formulation=formulation,
        policy_result=policy_result,
        outcome=outcome,
    )
    prediction = outcome.world_prediction
    if prediction is None:
        return _AutonomousDrivingRenderOverlaySnapshot(
            episode_generation=episode_generation,
            transition_index=transition_index,
            polylines=(),
            markers=(),
            status_lines=status_lines,
        )

    predicted_positions = prediction.predicted_vehicle_positions_metres
    polylines = []
    if config.show_formulation_target:
        polylines.append(
            _RenderOverlayPolyline(
                prediction.formulation_target_line_positions_metres,
                "formulation_target",
            )
        )
    polylines.extend(
        (
            _RenderOverlayPolyline(predicted_positions, "predicted_path"),
            _RenderOverlayPolyline(
                predicted_positions[:2],
                "executed_predicted_segment",
            ),
        )
    )
    if config.show_predicted_headings:
        heading_length_metres = 0.75
        for position, heading in zip(
            predicted_positions,
            prediction.predicted_vehicle_headings_radians,
            strict=True,
        ):
            endpoint = position + heading_length_metres * np.array(
                [np.cos(heading), np.sin(heading)],
                dtype=np.float64,
            )
            polylines.append(
                _RenderOverlayPolyline(
                    np.stack((position, endpoint)),
                    "predicted_heading",
                )
            )

    markers = []
    if config.show_prediction_nodes:
        markers.extend(
            _RenderOverlayMarker(position, "prediction_node")
            for position in predicted_positions
        )
    markers.append(
        _RenderOverlayMarker(
            predicted_positions[1],
            "first_predicted_state",
        )
    )

    if config.show_sensor_preview_samples:
        source_positions = (
            prediction.source_preview_target_line_positions_metres
        )
        source_validity = prediction.source_preview_validity
        if source_positions is not None and source_validity is not None:
            valid_positions = source_positions[source_validity]
            if valid_positions.shape[0] >= 2:
                polylines.append(
                    _RenderOverlayPolyline(
                        valid_positions,
                        "sensor_preview",
                    )
                )
            markers.extend(
                _RenderOverlayMarker(position, "sensor_preview_sample")
                for position in valid_positions
            )
    if config.show_lane_envelope:
        right = prediction.installed_right_lane_bound_positions_metres
        left = prediction.installed_left_lane_bound_positions_metres
        for positions, semantic in (
            (right, "lane_right"),
            (left, "lane_left"),
        ):
            if positions is not None:
                if positions.shape[0] == 1:
                    positions = np.repeat(positions, 2, axis=0)
                polylines.append(
                    _RenderOverlayPolyline(positions, semantic)
                )

    return _AutonomousDrivingRenderOverlaySnapshot(
        episode_generation=episode_generation,
        transition_index=transition_index,
        polylines=tuple(polylines),
        markers=tuple(markers),
        status_lines=status_lines,
    )


class AutonomousDrivingMPCLivePredictionOverlayAdapter:
    """Publish one MPC prediction at a time to a bound driving renderer."""

    def __init__(self, env, config) -> None:
        if not isinstance(config, MPCLivePredictionOverlayConfig):
            raise TypeError(
                "config must be an MPCLivePredictionOverlayConfig"
            )
        unwrapped = getattr(env, "unwrapped", None)
        if unwrapped is None:
            raise TypeError("env must expose an unwrapped environment")
        if getattr(unwrapped, "render_mode", None) is None:
            raise ValueError(
                "A live MPC overlay requires an environment render_mode."
            )
        self._environment = unwrapped
        self._config = config
        self._state = "ready"
        self._episode_generation = -1
        self._last_transition_index = None
        self._policy_control_step_offset = None

    def _require_active(self) -> int:
        if self._state == "closed":
            raise RuntimeError("The MPC live overlay adapter is closed.")
        if self._state != "active":
            raise RuntimeError(
                "The MPC live overlay adapter has no active episode."
            )
        return self._episode_generation

    def begin_episode(self) -> int:
        if self._state == "closed":
            raise RuntimeError("The MPC live overlay adapter is closed.")
        if self._state == "active":
            raise RuntimeError(
                "The MPC live overlay adapter episode is already active."
            )
        if getattr(
            self._environment,
            "_render_overlay_episode_generation",
            None,
        ) is not None:
            raise RuntimeError(
                "The environment's live overlay episode is already owned by "
                "another active provider."
            )
        self._environment.ground_truth_mode = "full"
        self._episode_generation = (
            int(
                getattr(
                    self._environment,
                    "_mpc_live_overlay_last_generation",
                    -1,
                )
            )
            + 1
        )
        self._environment._begin_render_overlay_episode(
            self._episode_generation
        )
        self._environment._mpc_live_overlay_last_generation = (
            self._episode_generation
        )
        self._last_transition_index = None
        self._policy_control_step_offset = None
        self._state = "active"
        return self._episode_generation

    def _clear_active_snapshot(self) -> None:
        self._environment._clear_render_overlay_snapshot(
            self._episode_generation
        )

    def _validate_transition_index(self, transition_index) -> int:
        transition_index = _validated_nonnegative_integer(
            transition_index,
            name="transition_index",
        )
        expected_transition = (
            0
            if self._last_transition_index is None
            else self._last_transition_index + 1
        )
        if transition_index != expected_transition:
            raise ValueError(
                "MPC live overlay transition index is stale or out of "
                "sequence."
            )
        return transition_index

    def _validate_publication(self, *, policy, policy_result, transition_index):
        from dreamgym.evaluation.autonomous_driving._mpc_rollout import (
            _formulation_and_metadata_for_policy,
        )
        from dreamgym.policies.autonomous_driving.mpc_results import (
            MPCPolicyResult,
        )

        if not isinstance(policy_result, MPCPolicyResult):
            raise TypeError(
                "A supported MPC policy must expose a fresh MPCPolicyResult."
            )
        formulation, _ = _formulation_and_metadata_for_policy(policy)
        transition_index = self._validate_transition_index(transition_index)
        if self._policy_control_step_offset is None:
            control_step_offset = (
                policy_result.control_step_index - transition_index
            )
        else:
            control_step_offset = self._policy_control_step_offset
        if policy_result.control_step_index != (
            control_step_offset + transition_index
        ):
            raise ValueError(
                "MPC live overlay policy result is stale or out of sequence."
            )
        return formulation, transition_index, control_step_offset

    def publish_policy_result(
        self,
        policy,
        *,
        transition_index: int,
    ) -> None:
        self._require_active()
        try:
            policy_result = getattr(policy, "last_result", None)
            formulation, transition_index, control_step_offset = (
                self._validate_publication(
                    policy=policy,
                    policy_result=policy_result,
                    transition_index=transition_index,
                )
            )
            problem = getattr(policy, "last_problem", None)
            from dreamgym.policies.mpc.problem import (
                LinearQuadraticMPCProblem,
            )

            if problem is not None and not isinstance(
                problem,
                LinearQuadraticMPCProblem,
            ):
                raise TypeError(
                    "policy last_problem must be a "
                    "LinearQuadraticMPCProblem or None"
                )
            if policy_result.solve_usable and problem is None:
                raise TypeError(
                    "a usable policy result requires a fresh last_problem"
                )
            from dreamgym.evaluation.autonomous_driving._mpc_rollout import (
                _materialize_prediction_context,
                _reference_line_progress_from_ground_truth,
            )
            from dreamgym.evaluation.autonomous_driving._mpc_world_projection import (
                _project_mpc_world_prediction,
            )

            ground_truth = self._environment.get_current_ground_truth()
            prediction_context = (
                None
                if problem is None
                else _materialize_prediction_context(
                    problem=problem,
                    policy_result=policy_result,
                    model_config=policy.config.model,
                    actual_progress_anchor_metres=(
                        _reference_line_progress_from_ground_truth(
                            ground_truth
                        )
                    ),
                )
            )
            outcome = _project_mpc_world_prediction(
                formulation=formulation,
                policy_result=policy_result,
                prediction_context=prediction_context,
                model_config=policy.config.model,
                ground_truth=ground_truth,
            )
            self._publish_projection_outcome(
                policy=policy,
                policy_result=policy_result,
                outcome=outcome,
                transition_index=transition_index,
                expected_formulation=formulation,
                expected_control_step_offset=control_step_offset,
            )
        except BaseException:
            self._clear_active_snapshot()
            raise

    def _publish_projection_outcome(
        self,
        *,
        policy,
        policy_result,
        outcome,
        transition_index,
        expected_formulation=None,
        expected_control_step_offset=None,
    ) -> None:
        generation = self._require_active()
        try:
            formulation, transition_index, control_step_offset = (
                self._validate_publication(
                    policy=policy,
                    policy_result=policy_result,
                    transition_index=transition_index,
                )
            )
            if (
                expected_formulation is not None
                and formulation is not expected_formulation
            ):
                raise ValueError(
                    "MPC live overlay formulation changed during publication."
                )
            if (
                expected_control_step_offset is not None
                and control_step_offset != expected_control_step_offset
            ):
                raise ValueError(
                    "MPC live overlay control-step sequence changed."
                )
            snapshot = _snapshot_from_projection_outcome(
                episode_generation=generation,
                transition_index=transition_index,
                config=self._config,
                formulation=formulation,
                policy_result=policy_result,
                outcome=outcome,
            )
            self._environment._publish_render_overlay_snapshot(snapshot)
        except BaseException:
            self._clear_active_snapshot()
            raise
        self._last_transition_index = transition_index
        self._policy_control_step_offset = control_step_offset

    def invalidate(
        self,
        *,
        transition_index: int,
        status_text: str,
    ) -> None:
        generation = self._require_active()
        try:
            transition_index = self._validate_transition_index(
                transition_index
            )
            validated_snapshot = _AutonomousDrivingRenderOverlaySnapshot(
                episode_generation=generation,
                transition_index=transition_index,
                polylines=(),
                markers=(),
                status_lines=(status_text,),
            )
            snapshot = (
                validated_snapshot
                if self._config.show_status
                else _AutonomousDrivingRenderOverlaySnapshot(
                    episode_generation=generation,
                    transition_index=transition_index,
                    polylines=(),
                    markers=(),
                    status_lines=(),
                )
            )
            self._environment._publish_render_overlay_snapshot(snapshot)
        except BaseException:
            self._clear_active_snapshot()
            raise
        self._last_transition_index = transition_index

    def finish_rollout(self) -> None:
        if self._state == "closed":
            return
        if self._state == "finished":
            return
        if self._state != "active":
            raise RuntimeError(
                "The MPC live overlay adapter has no active episode."
            )
        self._environment._finish_render_overlay_episode(
            self._episode_generation
        )
        self._state = "finished"

    def close(self) -> None:
        if self._state == "closed":
            return
        if self._state == "active":
            self._environment._finish_render_overlay_episode(
                self._episode_generation
            )
        self._state = "closed"
