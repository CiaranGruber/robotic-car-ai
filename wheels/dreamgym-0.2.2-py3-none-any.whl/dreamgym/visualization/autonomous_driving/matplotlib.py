"""Matplotlib helpers for the autonomous-driving environment."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from dreamgym.envs.road import Road
from dreamgym.visualization.autonomous_driving._road_presentation import (
    _cadence_for_pattern,
    _nan_separated_polyline,
    _resolve_road_presentation_style,
    _segment_world_polyline,
)


def _pyplot():
    import matplotlib.pyplot as plt

    return plt


_LINE_PATTERNS = {
    "solid": "-",
    "dashed": "--",
    "dotted": ":",
    "dash_dot": "-.",
}


def _resolve_visualization_theme(visualization_theme):
    from dreamgym.visualization.autonomous_driving.theme import (
        resolve_autonomous_driving_visualization_theme,
    )

    return resolve_autonomous_driving_visualization_theme(visualization_theme)


def _prevalidate_road(road, theme):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _prevalidate_road_presentation,
    )

    _prevalidate_road_presentation(road, theme)


def _resolve_environment_visualization_theme(env, visualization_theme):
    return _resolve_visualization_theme_with_inheritance(
        visualization_theme,
        env.unwrapped.visualization_theme,
    )


def _resolve_visualization_theme_with_inheritance(visualization_theme, inherited_theme):
    from dreamgym.visualization.autonomous_driving.theme import (
        resolve_autonomous_driving_visualization_theme,
    )

    return resolve_autonomous_driving_visualization_theme(
        visualization_theme,
        inherited_theme=inherited_theme,
    )


def _layer_zorder(theme, layer):
    return tuple(theme.layer_order).index(layer)


def _apply_world_scene_theme(fig, axis, theme):
    canvas_zorder = _layer_zorder(theme, "canvas")
    fig.set_facecolor(theme.canvas.figure_background_color)
    fig.patch.set_zorder(canvas_zorder)
    axis.set_facecolor(theme.canvas.world_background_color)
    axis.patch.set_zorder(canvas_zorder)
    axis.grid(
        visible=True,
        which="both",
        axis="both",
        color=theme.canvas.grid_color,
        alpha=theme.canvas.grid_opacity,
        linewidth=0.5 * theme.canvas.grid_line_scale,
        linestyle=_LINE_PATTERNS[theme.canvas.grid_pattern],
        zorder=canvas_zorder,
    )


def _plot_suffix(file_name_suffix):
    return "" if isinstance(file_name_suffix, str) and file_name_suffix == "" else "_" + str(file_name_suffix)


def plot_road_from_spec(
    road_spec,
    *,
    title="The road",
    figure_size=None,
    visualization_theme=None,
):
    theme = _resolve_visualization_theme(visualization_theme)
    road = Road(road_spec=road_spec)
    _prevalidate_road(road, theme)
    plt = _pyplot()
    fig, axis = plt.subplots(1, 1, figsize=figure_size)
    _apply_world_scene_theme(fig, axis, theme)
    axis.set_xlim(auto=True)
    axis.set_ylim(auto=True)
    handles = road.plot_road_on_matplotlib_axis(
        axis,
        visualization_theme=theme,
    )
    axis.set_aspect("equal", adjustable="box")
    axis.set_xlabel("x [m]")
    axis.set_ylabel("y [m]")
    fig.suptitle(title, fontsize=12)
    return fig, axis, handles


def plot_current_state(
    env,
    *,
    zoom_width_m=20.0,
    zoom_height_m=20.0,
    title="Zoom in of the road and car",
    visualization_theme=None,
):
    theme = _resolve_environment_visualization_theme(env, visualization_theme)
    base_env = env.unwrapped
    _prevalidate_road(base_env.road, theme)
    plt = _pyplot()
    fig, axis = plt.subplots(1, 1)
    _apply_world_scene_theme(fig, axis, theme)
    base_env.road.plot_road_on_matplotlib_axis(axis, visualization_theme=theme)
    car_state = base_env.car.state
    world_pose = car_state["world_pose"]
    position_x_m = float(world_pose["x_m"])
    position_y_m = float(world_pose["y_m"])
    base_env.car.plot_car_on_matplotlib_axis(
        axis,
        position_x_m,
        position_y_m,
        float(world_pose["heading_rad"]),
        float(car_state["front_wheel_steering_angle_rad"]),
        scale=1.0,
        visualization_theme=theme,
    )
    axis.set_xlim(
        xmin=position_x_m - 0.5 * float(zoom_width_m),
        xmax=position_x_m + 0.5 * float(zoom_width_m),
    )
    axis.set_ylim(
        ymin=position_y_m - 0.5 * float(zoom_height_m),
        ymax=position_y_m + 0.5 * float(zoom_height_m),
    )
    axis.set_aspect("equal", adjustable="box")
    axis.set_xlabel("x (World) [meters]")
    axis.set_ylabel("y (World) [meters]")
    fig.suptitle(title, fontsize=12)
    return fig, axis


def _first_valid_length(values):
    values = np.asarray(values)
    nan_indices = np.where(np.isnan(values))[0]
    if nan_indices.size == 0:
        return values.shape[0]
    return int(nan_indices[0])


def _place_time_series_legend(axis):
    axis.legend(
        loc="upper left",
        bbox_to_anchor=(1.01, 1.0),
        borderaxespad=0.0,
        ncol=1,
        labelspacing=0.1,
    )


def _plot_single_series(axis, results, field_name, label, ylabel):
    axis.plot(results["time_in_seconds"], results[field_name], label=label)
    axis.set_ylabel(ylabel, fontsize=10)
    axis.grid(visible=True, which="both", axis="both", linestyle="--")
    _place_time_series_legend(axis)


def plot_simulation_results(
    env,
    sim_time_series_results,
    *,
    should_plot_reward=True,
    should_plot_speed_error=False,
    visualization_theme=None,
):
    theme = _resolve_environment_visualization_theme(env, visualization_theme)
    _prevalidate_road(env.unwrapped.road, theme)
    plt = _pyplot()
    figures = {}

    fig, axis = plt.subplots(
        1,
        1,
        gridspec_kw={"left": 0.15, "right": 0.95, "top": 0.94, "bottom": 0.18},
    )
    _apply_world_scene_theme(fig, axis, theme)
    road_handles = env.unwrapped.road.plot_road_on_matplotlib_axis(
        axis,
        visualization_theme=theme,
    )
    legend_handles = []
    if road_handles:
        road_handles[0].set_label("road")
        legend_handles.append(road_handles[0])
    trajectory_coordinates = np.column_stack((
        sim_time_series_results["px"],
        sim_time_series_results["py"],
    ))
    trajectory_style = _resolve_road_presentation_style(theme)
    trajectory_segments, _ = _segment_world_polyline(
        trajectory_coordinates,
        _cadence_for_pattern(theme.mpc.actual_trajectory.pattern, trajectory_style),
    )
    visible_trajectory_coordinates = _nan_separated_polyline(trajectory_segments)
    trajectory_line, = axis.plot(
        visible_trajectory_coordinates[:, 0],
        visible_trajectory_coordinates[:, 1],
        color=theme.mpc.actual_trajectory.color,
        alpha=theme.mpc.actual_trajectory.opacity,
        linestyle="-",
        linewidth=theme.mpc.actual_trajectory.line_scale,
        zorder=_layer_zorder(theme, "actual_trajectory"),
        label="trajectory of vehicle",
    )
    legend_handles.append(trajectory_line)
    axis.set_xlabel("px [meters]", fontsize=10)
    axis.set_ylabel("py [meters]", fontsize=10)
    axis.set_aspect("equal", adjustable="box")
    fig.legend(handles=legend_handles, loc="lower center", ncol=4, labelspacing=0.1)
    fig.suptitle("Showing the road and the (px,py) trajectory", fontsize=12)
    figures["cartesian_coords"] = fig

    subplot_count = 7 if should_plot_reward else 5
    if should_plot_speed_error:
        subplot_count += 1
    fig, axes = plt.subplots(
        subplot_count,
        1,
        sharex=True,
        sharey=False,
        gridspec_kw={"left": 0.15, "right": 0.68, "top": 0.94, "bottom": 0.05},
    )
    fig.set_size_inches(7, 10 if should_plot_reward else 8)
    axes = np.asarray(axes).reshape(-1)
    axis_idx = 0

    if should_plot_reward:
        _plot_single_series(
            axes[axis_idx],
            sim_time_series_results,
            "reward",
            "reward",
            "[reward units]",
        )
        axis_idx += 1
        cumulative_reward = np.cumsum(
            sim_time_series_results["reward"],
            dtype=np.float32,
        )
        axes[axis_idx].plot(
            sim_time_series_results["time_in_seconds"],
            cumulative_reward,
            label="cumulative reward",
        )
        axes[axis_idx].set_ylabel("[reward units]", fontsize=10)
        axes[axis_idx].grid(visible=True, which="both", axis="both", linestyle="--")
        _place_time_series_legend(axes[axis_idx])
        axis_idx += 1

    axes[axis_idx].plot(
        sim_time_series_results["time_in_seconds"],
        sim_time_series_results["vx"] * 3.6,
        label="forwards velocity (vx)",
    )
    axes[axis_idx].plot(
        sim_time_series_results["time_in_seconds"],
        sim_time_series_results["recommended_speed_at_closest_point"] * 3.6,
        label="recommended speed",
    )
    axes[axis_idx].set_ylabel("[km/h]", fontsize=10)
    axes[axis_idx].grid(visible=True, which="both", axis="both", linestyle="--")
    _place_time_series_legend(axes[axis_idx])
    axis_idx += 1

    if should_plot_speed_error:
        speed_error_kph = (
            sim_time_series_results["vx"] -
            sim_time_series_results["recommended_speed_at_closest_point"]
        ) * 3.6
        axes[axis_idx].plot(
            sim_time_series_results["time_in_seconds"],
            speed_error_kph,
            label="speed error",
        )
        axes[axis_idx].axhline(0.0, color="black", linewidth=0.8, alpha=0.5)
        axes[axis_idx].set_ylabel("speed error [km/h]", fontsize=10)
        axes[axis_idx].grid(visible=True, which="both", axis="both", linestyle="--")
        _place_time_series_legend(axes[axis_idx])
        axis_idx += 1

    _plot_single_series(
        axes[axis_idx],
        sim_time_series_results,
        "lateral_error_from_target_line",
        "distance to line",
        "[meters]",
    )
    axis_idx += 1

    axes[axis_idx].plot(
        sim_time_series_results["time_in_seconds"],
        sim_time_series_results["heading_angle_relative_to_target_line"]
        * 180.0
        / np.pi,
        label="heading relative to line",
    )
    axes[axis_idx].set_ylabel("[degrees]", fontsize=10)
    axes[axis_idx].grid(visible=True, which="both", axis="both", linestyle="--")
    _place_time_series_legend(axes[axis_idx])
    axis_idx += 1

    _plot_single_series(
        axes[axis_idx],
        sim_time_series_results,
        "drive_command",
        "drive command",
        "[-1,1]",
    )
    axis_idx += 1

    axes[axis_idx].plot(
        sim_time_series_results["time_in_seconds"],
        sim_time_series_results["delta_request"] * 180.0 / np.pi,
        label="delta request",
    )
    axes[axis_idx].plot(
        sim_time_series_results["time_in_seconds"],
        sim_time_series_results["delta"] * 180.0 / np.pi,
        label="actual delta",
    )
    axes[axis_idx].set_xlabel("time [seconds]", fontsize=10)
    axes[axis_idx].set_ylabel("[degrees]", fontsize=10)
    axes[axis_idx].grid(visible=True, which="both", axis="both", linestyle="--")
    _place_time_series_legend(axes[axis_idx])

    fig.suptitle("Time series results", fontsize=12)
    figures["time_series"] = fig
    return figures


def animate_simulation_trajectory(
    env,
    sim_time_series_results,
    *,
    Ts=None,
    frame_step=1,
    figure_title=None,
    zoom_width_m=20.0,
    zoom_height_m=20.0,
    visualization_theme=None,
):
    theme = _resolve_environment_visualization_theme(env, visualization_theme)
    base_env = env.unwrapped
    _prevalidate_road(base_env.road, theme)
    import matplotlib.animation as animation

    plt = _pyplot()
    px = np.asarray(sim_time_series_results["px"])
    py = np.asarray(sim_time_series_results["py"])
    theta = np.asarray(sim_time_series_results["theta"])
    delta = np.asarray(sim_time_series_results["delta"])

    traj_length = _first_valid_length(px)
    if traj_length <= 0:
        raise ValueError("sim_time_series_results['px'] must contain at least one value")

    step = int(frame_step)
    if step <= 0:
        raise ValueError("frame_step must be a positive integer")

    px = px[:traj_length]
    py = py[:traj_length]
    theta = theta[:traj_length]
    delta = delta[:traj_length]
    frame_indices = range(0, traj_length, step)
    interval_ms = 1000.0 * float(
        base_env.environment_step_duration_s if Ts is None else Ts
    )

    fig, axis = plt.subplots(1, 1)
    _apply_world_scene_theme(fig, axis, theme)
    base_env.road.plot_road_on_matplotlib_axis(axis, visualization_theme=theme)
    fig.suptitle("Animation of car" if figure_title is None else figure_title, fontsize=12)
    car_handles = base_env.car.plot_car_on_matplotlib_axis(
        axis,
        px[0],
        py[0],
        theta[0],
        delta[0],
        scale=1.0,
        visualization_theme=theme,
    )

    def update(frame_idx):
        base_env.car.plot_car_on_matplotlib_axis(
            axis,
            px[frame_idx],
            py[frame_idx],
            theta[frame_idx],
            delta[frame_idx],
            scale=1.0,
            plot_handles=car_handles,
        )
        axis.set_xlim(
            xmin=float(px[frame_idx]) - 0.5 * float(zoom_width_m),
            xmax=float(px[frame_idx]) + 0.5 * float(zoom_width_m),
        )
        axis.set_ylim(
            ymin=float(py[frame_idx]) - 0.5 * float(zoom_height_m),
            ymax=float(py[frame_idx]) + 0.5 * float(zoom_height_m),
        )
        axis.set_aspect("equal", adjustable="box")
        axis.set_xlabel("x (World) [meters]")
        axis.set_ylabel("y (World) [meters]")
        _apply_world_scene_theme(fig, axis, theme)
        return list(car_handles.values())

    update(0)
    return animation.FuncAnimation(
        fig,
        update,
        frames=frame_indices,
        interval=interval_ms,
    )


def save_figure(fig, output_path):
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    return path


def save_road_plot(fig, output_dir, *, file_name_suffix="", file_format="pdf"):
    output_path = Path(output_dir) / (
        "ad_road" + _plot_suffix(file_name_suffix) + "." + file_format
    )
    return save_figure(fig, output_path)


def save_current_state_plot(fig, output_dir, *, file_name_suffix="", file_format="pdf"):
    output_path = Path(output_dir) / (
        "ad_vehicle" + _plot_suffix(file_name_suffix) + "." + file_format
    )
    return save_figure(fig, output_path)


def save_simulation_result_plots(
    figures,
    output_dir,
    *,
    file_name_suffix="",
    file_format="pdf",
):
    suffix = _plot_suffix(file_name_suffix)
    output_dir = Path(output_dir)
    paths = {
        "cartesian_coords": output_dir / (
            "ad_cartesian_coords" + suffix + "." + file_format
        ),
        "time_series": output_dir / ("ad_time_series" + suffix + "." + file_format),
    }
    return {name: save_figure(figures[name], path) for name, path in paths.items()}


def plot_eval_summary(rows, path):
    if not rows:
        return
    plt = _pyplot()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    names = [str(row["road_name"]) for row in rows]
    progress = [float(row["final_progress_m"]) for row in rows]
    lateral = [float(row["mean_abs_lateral_error_m"]) for row in rows]

    fig, axes = plt.subplots(2, 1, figsize=(8, 6), constrained_layout=True)
    axes[0].bar(names, progress)
    axes[0].set_ylabel("progress [m]")
    axes[0].tick_params(axis="x", rotation=35)
    axes[1].bar(names, lateral)
    axes[1].set_ylabel("mean |lateral error| [m]")
    axes[1].tick_params(axis="x", rotation=35)
    fig.savefig(path)
    plt.close(fig)


def plot_training_progress(progress_csv, path):
    import csv

    progress_csv = Path(progress_csv)
    if not progress_csv.exists():
        return
    with progress_csv.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    steps = [int(float(row["timesteps"])) for row in rows]
    elapsed = [float(row["elapsed_s"]) for row in rows]

    plt = _pyplot()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 1, figsize=(7, 4), constrained_layout=True)
    ax.plot(steps, elapsed, marker="o")
    ax.set_xlabel("timesteps")
    ax.set_ylabel("elapsed [s]")
    ax.grid(True, linestyle="--", alpha=0.4)
    fig.savefig(path)
    plt.close(fig)


def plot_run_comparison(rows, path):
    if not rows:
        return
    plt = _pyplot()
    names = [row["run_name"] for row in rows]
    steps_per_s = [
        float(row["steps_per_s"]) if str(row["steps_per_s"]).strip() else 0.0
        for row in rows
    ]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 1, figsize=(8, 4), constrained_layout=True)
    ax.bar(names, steps_per_s)
    ax.set_ylabel("training steps/s")
    ax.tick_params(axis="x", rotation=35)
    fig.savefig(path)
    plt.close(fig)


def save_trajectory_animation(
    animation,
    output_dir,
    *,
    file_name="ad_animation.gif",
    writer=None,
):
    output_path = Path(output_dir) / file_name
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if writer is None:
        animation.save(output_path)
    else:
        animation.save(output_path, writer=writer)
    return output_path
