"""Private Matplotlib drawing adapter for the dynamic bicycle model."""

import numpy as np
from matplotlib.patches import Rectangle


def _zorder(theme, layer):
    return tuple(theme.layer_order).index(layer)


def plot_car(
    axis_handle,
    state_values,
    Lf,
    Lr,
    body_len_f,
    body_len_r,
    body_width,
    scale=1.0,
    plot_handles=None,
    theme=None,
):
    """Create themed vehicle artists or update existing artists geometrically."""
    px, py, theta, _, _, _, delta = state_values
    Lf = float(Lf) * scale
    Lr = float(Lr) * scale
    body_len_f = float(body_len_f) * scale
    body_len_r = float(body_len_r) * scale
    body_width = float(body_width) * scale
    wheel_radius = 0.1 * (Lf + Lr)

    pxf = px + Lf * np.cos(theta)
    pyf = py + Lf * np.sin(theta)
    pxr = px - Lr * np.cos(theta)
    pyr = py - Lr * np.sin(theta)

    wfxf = pxf + wheel_radius * np.cos(theta + delta)
    wfyf = pyf + wheel_radius * np.sin(theta + delta)
    wfxr = pxf - wheel_radius * np.cos(theta + delta)
    wfyr = pyf - wheel_radius * np.sin(theta + delta)
    wrxf = pxr + wheel_radius * np.cos(theta)
    wryf = pyr + wheel_radius * np.sin(theta)
    wrxr = pxr - wheel_radius * np.cos(theta)
    wryr = pyr - wheel_radius * np.sin(theta)
    brrx = px - body_len_r * np.cos(theta) + 0.5 * body_width * np.sin(theta)
    brry = py - body_len_r * np.sin(theta) - 0.5 * body_width * np.cos(theta)

    if plot_handles is not None:
        plot_handles["body_line"].set_data([pxr, pxf], [pyr, pyf])
        plot_handles["front_wheel"].set_data([wfxr, wfxf], [wfyr, wfyf])
        plot_handles["rear_wheel"].set_data([wrxr, wrxf], [wryr, wryf])
        plot_handles["body_rect"].set_xy((brrx, brry))
        plot_handles["body_rect"].set_angle(theta * 57.2957795)
        return plot_handles

    if theme is None:
        raise TypeError("theme is required when creating vehicle artists")
    vehicle = theme.vehicle
    zorder = _zorder(theme, "vehicle")
    body_line = axis_handle.plot(
        [pxr, pxf],
        [pyr, pyf],
        linewidth=2.0 * vehicle.centerline_line_scale,
        color=vehicle.centerline_color, alpha=1.0, zorder=zorder,
    )[0]
    front_wheel = axis_handle.plot(
        [wfxr, wfxf], [wfyr, wfyf], linewidth=4.0 * vehicle.wheel_line_scale,
        color=vehicle.wheel_color, alpha=1.0, zorder=zorder,
    )[0]
    rear_wheel = axis_handle.plot(
        [wrxr, wrxf], [wryr, wryf], linewidth=4.0 * vehicle.wheel_line_scale,
        color=vehicle.wheel_color, alpha=1.0, zorder=zorder,
    )[0]
    body_rect = Rectangle(
        (brrx, brry),
        width=body_len_r + body_len_f,
        height=body_width,
        angle=theta * 57.2957795,
        rotation_point="xy",
        linewidth=0.5 * vehicle.outline_scale,
        edgecolor=vehicle.outline_color,
        facecolor=vehicle.fill_color,
        alpha=vehicle.fill_opacity,
        zorder=zorder,
    )
    axis_handle.add_patch(body_rect)
    for handle, gid in (
        (body_line, "vehicle-centerline"),
        (front_wheel, "vehicle-front-wheel"),
        (rear_wheel, "vehicle-rear-wheel"),
        (body_rect, "vehicle-body"),
    ):
        handle.set_gid(gid)
    return {
        "body_line": body_line,
        "front_wheel": front_wheel,
        "rear_wheel": rear_wheel,
        "body_rect": body_rect,
    }
