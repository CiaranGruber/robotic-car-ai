"""Stored-history Matplotlib views for MPC world predictions."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral, Real

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCRolloutHistory,
)


_BOOLEAN_FLAGS = (
    "show_formulation_target",
    "show_prediction_nodes",
    "show_actual_rollout",
    "show_status",
    "show_predicted_headings",
    "show_sensor_preview_samples",
    "show_lane_envelope",
    "show_speed_and_curvature_annotations",
)

_ANIMATION_ZOOM_MODES = ("follow", "fixed", "full_road")

_LINE_PATTERNS = {
    "solid": "-",
    "dashed": "--",
    "dotted": ":",
    "dash_dot": "-.",
}

_MARKERS = {
    "circle": "o",
    "square": "s",
    "diamond": "D",
    "cross": "x",
}

_BASE_LINE_WIDTH = 2.0
_BASE_MARKER_SIZE = 22.0
_BASE_ANNOTATION_FONT_SIZE = 7.0
_BASE_STATUS_FONT_SIZE = 8.0


def _pyplot():
    import matplotlib.pyplot as plt

    return plt


def _resolve_visualization_theme(visualization_theme):
    from dreamgym.visualization.autonomous_driving.theme import (
        resolve_autonomous_driving_visualization_theme,
    )

    return resolve_autonomous_driving_visualization_theme(
        visualization_theme
    )


def _prevalidate_road(road, theme):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _prevalidate_road_presentation,
    )

    _prevalidate_road_presentation(road, theme)


def _cadence_for_pattern(pattern, style):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _cadence_for_pattern as shared_cadence_for_pattern,
    )

    return shared_cadence_for_pattern(pattern, style)


def _nan_separated_polyline(segments):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _nan_separated_polyline as shared_nan_separated_polyline,
    )

    return shared_nan_separated_polyline(segments)


def _resolve_road_presentation_style(theme):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _resolve_road_presentation_style as shared_resolve_style,
    )

    return shared_resolve_style(theme)


def _segment_world_polyline(coordinates, cadence_m, *, initial_phase_m=0.0):
    from dreamgym.visualization.autonomous_driving._road_presentation import (
        _segment_world_polyline as shared_segment_world_polyline,
    )

    return shared_segment_world_polyline(
        coordinates,
        cadence_m,
        initial_phase_m=initial_phase_m,
    )


def _layer_zorder(theme, layer):
    return tuple(theme.layer_order).index(layer)


def _line_style(theme, style, layer):
    return {
        "color": style.color,
        "alpha": style.opacity,
        "linestyle": "-",
        "linewidth": _BASE_LINE_WIDTH * style.line_scale,
        "zorder": _layer_zorder(theme, layer),
    }


def _marker_style(theme, style, layer):
    outline_color = getattr(style, "outline_color", None)
    outline_scale = getattr(style, "outline_scale", None)
    native = {
        "alpha": style.opacity,
        "marker": _MARKERS[style.shape],
        "s": _BASE_MARKER_SIZE * style.marker_scale ** 2,
        "zorder": _layer_zorder(theme, layer),
    }
    if style.shape == "cross":
        native["color"] = style.color
    else:
        native.update(
            facecolors=style.color,
            edgecolors=(
                style.color if outline_color is None else outline_color
            ),
            linewidths=0.0 if outline_scale is None else outline_scale,
        )
    return native


def _apply_world_scene_theme(figure, axis, theme):
    canvas_zorder = _layer_zorder(theme, "canvas")
    figure.set_facecolor(theme.canvas.figure_background_color)
    figure.patch.set_zorder(canvas_zorder)
    axis.set_facecolor(theme.canvas.world_background_color)
    axis.patch.set_zorder(canvas_zorder)
    axis.grid(
        visible=True,
        which="both",
        axis="both",
        color=theme.canvas.grid_color,
        alpha=theme.canvas.grid_opacity,
        linewidth=0.5 * theme.canvas.grid_line_scale,
        linestyle=_LINE_PATTERNS[theme.canvas.grid_pattern],
        zorder=canvas_zorder,
    )


def _validate_display_units(display_units):
    if display_units not in ("driving", "si"):
        raise ValueError("display_units must be exactly 'driving' or 'si'")


def _validate_flags(values):
    for name, value in zip(_BOOLEAN_FLAGS, values, strict=True):
        if not isinstance(value, bool):
            raise TypeError(f"{name} must be a bool")


def _validate_animation_view(zoom_mode, zoom_width_m, zoom_height_m):
    if zoom_mode not in _ANIMATION_ZOOM_MODES:
        raise ValueError(
            "zoom_mode must be 'follow', 'fixed', or 'full_road'"
        )
    if zoom_mode == "full_road":
        if zoom_width_m is not None or zoom_height_m is not None:
            raise ValueError(
                "zoom dimensions must be None when zoom_mode='full_road'"
            )
        return None, None
    if zoom_width_m is None or zoom_height_m is None:
        raise ValueError(
            "zoom_width_m and zoom_height_m are required for follow and fixed views"
        )
    values = []
    for name, raw in (
        ("zoom_width_m", zoom_width_m),
        ("zoom_height_m", zoom_height_m),
    ):
        if isinstance(raw, bool) or not isinstance(raw, Real):
            raise TypeError(f"{name} must be a finite real number")
        value = float(raw)
        if not np.isfinite(value):
            raise ValueError(f"{name} must be finite")
        if value <= 0.0:
            raise ValueError(f"{name} must be positive")
        values.append(value)
    return tuple(values)


def _validate_animation_vehicle(vehicle, show_actual_rollout):
    if vehicle is None:
        return
    plot_vehicle = getattr(vehicle, "plot_car_on_matplotlib_axis", None)
    if not callable(plot_vehicle):
        raise TypeError(
            "vehicle must provide plot_car_on_matplotlib_axis(...) or be None"
        )
    if not show_actual_rollout:
        raise ValueError(
            "vehicle requires show_actual_rollout=True"
        )


def _validate_figure_title(figure_title):
    if figure_title is None:
        return
    if not isinstance(figure_title, str) or not figure_title.strip():
        raise TypeError("figure_title must be a non-empty string or None")


def _require_world_history(history):
    if not isinstance(history, AutonomousDrivingMPCRolloutHistory):
        raise TypeError(
            "history must be an AutonomousDrivingMPCRolloutHistory"
        )
    if not history.world_prediction_capture_requested:
        raise ValueError(
            "world predictions were not captured; rerun the rollout with "
            "capture_world_predictions=True"
        )
    if history.transition_count == 0:
        raise ValueError("history is empty and has no transition to plot")


def _strict_transition_index(value, count):
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError("transition_index must be an integer")
    index = int(value)
    if index < 0 or index >= count:
        raise IndexError(f"transition_index must lie in 0..{count - 1}")
    return index


def _positive_integer(name, value):
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer")
    converted = int(value)
    if converted <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return converted


def _figure_and_axis(ax):
    if ax is None:
        return _pyplot().subplots(figsize=(9, 6), constrained_layout=True)
    from matplotlib.axes import Axes

    if not isinstance(ax, Axes):
        raise TypeError("ax must be a Matplotlib Axes or None")
    return ax.figure, ax


def _road_plotter(road):
    if road is None:
        return None
    plot_road = getattr(road, "plot_road_on_matplotlib_axis", None)
    if not callable(plot_road):
        raise TypeError(
            "road must provide plot_road_on_matplotlib_axis(ax) or be None"
        )
    return plot_road


def _draw_road_background(axis, plot_road, theme):
    if plot_road is None:
        return
    plot_road(axis, visualization_theme=theme)


def _empty_offsets():
    return np.empty((0, 2), dtype=np.float64)


def _new_line(axis, label, gid, *, cadence_m, **style):
    line, = axis.plot([], [], label=label, **style)
    line.set_gid(gid)
    line._dreamgym_world_cadence_m = tuple(cadence_m)
    return line


def _new_scatter(axis, label, gid, **style):
    collection = axis.scatter([], [], label=label, **style)
    collection.set_offsets(_empty_offsets())
    collection.set_gid(gid)
    return collection


@dataclass(slots=True)
class _WorldArtists:
    formulation_target: object | None
    predicted_path: object
    prediction_nodes: object | None
    executed_segment: object
    predicted_x1: object
    actual_rollout: object | None
    actual_vehicle: object | None
    actual_vehicle_plot_handles: object | None
    predicted_headings: object | None
    heading_annotations: tuple[object, ...]
    sensor_preview_samples: object | None
    unavailable_sensor_preview_samples: object | None
    right_lane_bound: object | None
    left_lane_bound: object | None
    speed_curvature_annotations: tuple[object, ...]
    status: object | None

    @classmethod
    def create(
        cls,
        axis,
        *,
        show_formulation_target,
        show_prediction_nodes,
        show_actual_rollout,
        show_status,
        show_predicted_headings,
        show_sensor_preview_samples,
        show_lane_envelope,
        show_speed_and_curvature_annotations,
        horizon_rows,
        theme,
        use_actual_vehicle_marker=True,
    ):
        mpc = theme.mpc
        annotations = theme.annotations
        cadence_style = _resolve_road_presentation_style(theme)
        formulation_target = None
        if show_formulation_target:
            formulation_target = _new_line(
                axis,
                "formulation target",
                "mpc-world-formulation-target",
                cadence_m=_cadence_for_pattern(
                    mpc.formulation_target.pattern,
                    cadence_style,
                ),
                **_line_style(
                    theme,
                    mpc.formulation_target,
                    "formulation_target",
                ),
            )
        predicted_path = _new_line(
            axis,
            "predicted vehicle centre path",
            "mpc-world-predicted-path",
            cadence_m=_cadence_for_pattern(
                mpc.predicted_path.pattern,
                cadence_style,
            ),
            **_line_style(theme, mpc.predicted_path, "predicted_path"),
        )
        prediction_nodes = None
        if show_prediction_nodes:
            prediction_nodes = _new_scatter(
                axis,
                "prediction nodes",
                "mpc-world-prediction-nodes",
                **_marker_style(
                    theme,
                    mpc.prediction_nodes,
                    "prediction_nodes",
                ),
            )
        executed_segment = _new_line(
            axis,
            "executed first segment",
            "mpc-world-executed-segment",
            cadence_m=_cadence_for_pattern(
                mpc.executed_segment.pattern,
                cadence_style,
            ),
            **_line_style(theme, mpc.executed_segment, "executed_segment"),
        )
        predicted_x1 = _new_scatter(
            axis,
            "predicted x[1]",
            "mpc-world-predicted-x1",
            **_marker_style(
                theme,
                mpc.first_predicted_state,
                "first_predicted_state",
            ),
        )
        actual_rollout = None
        actual_vehicle = None
        if show_actual_rollout:
            actual_rollout = _new_line(
                axis,
                "actual rollout",
                "mpc-world-actual-rollout",
                cadence_m=_cadence_for_pattern(
                    mpc.actual_trajectory.pattern,
                    cadence_style,
                ),
                **_line_style(
                    theme,
                    mpc.actual_trajectory,
                    "actual_trajectory",
                ),
            )
            if use_actual_vehicle_marker:
                actual_vehicle = _new_scatter(
                    axis,
                    "actual vehicle",
                    "mpc-world-actual-vehicle",
                    **_marker_style(
                        theme,
                        mpc.actual_vehicle_fallback_marker,
                        "vehicle",
                    ),
                )
        predicted_headings = None
        heading_annotations = ()
        if show_predicted_headings:
            from matplotlib.collections import LineCollection

            predicted_headings = LineCollection(
                [],
                colors=mpc.predicted_headings.color,
                linewidths=(
                    _BASE_LINE_WIDTH
                    * mpc.predicted_headings.line_scale
                ),
                linestyles="solid",
                alpha=mpc.predicted_headings.opacity,
                label="predicted headings",
                zorder=_layer_zorder(theme, "predicted_headings"),
            )
            predicted_headings.set_gid("mpc-world-predicted-headings")
            predicted_headings._dreamgym_world_cadence_m = tuple(
                _cadence_for_pattern(
                    mpc.predicted_headings.pattern,
                    cadence_style,
                )
            )
            axis.add_collection(predicted_headings)
            heading_annotations = tuple(
                axis.text(
                    0.0,
                    0.0,
                    "",
                    color=annotations.heading_text_color,
                    fontsize=(
                        _BASE_ANNOTATION_FONT_SIZE
                        * annotations.font_scale
                    ),
                    ha="left",
                    va="bottom",
                    zorder=_layer_zorder(theme, "annotations"),
                )
                for _ in range(horizon_rows)
            )
            for index, annotation in enumerate(heading_annotations):
                annotation.set_gid(f"mpc-world-heading-{index}")
        sensor_preview_samples = None
        unavailable_sensor_preview_samples = None
        if show_sensor_preview_samples:
            sensor_preview_samples = _new_scatter(
                axis,
                "sensor preview samples",
                "mpc-world-sensor-preview-samples",
                **_marker_style(
                    theme,
                    mpc.sensor_preview,
                    "sensor_markers",
                ),
            )
            unavailable_sensor_preview_samples = _new_scatter(
                axis,
                "unavailable sensor preview samples",
                "mpc-world-unavailable-sensor-preview-samples",
                **_marker_style(
                    theme,
                    mpc.unavailable_sensor_preview_marker,
                    "sensor_markers",
                ),
            )
        right_lane_bound = None
        left_lane_bound = None
        if show_lane_envelope:
            right_lane_bound = _new_line(
                axis,
                "installed right lane bound",
                "mpc-world-installed-right-lane-bound",
                cadence_m=_cadence_for_pattern(
                    mpc.lane_envelope.pattern,
                    cadence_style,
                ),
                **_line_style(theme, mpc.lane_envelope, "lane_envelope"),
            )
            left_lane_bound = _new_line(
                axis,
                "installed left lane bound",
                "mpc-world-installed-left-lane-bound",
                cadence_m=_cadence_for_pattern(
                    mpc.lane_envelope.pattern,
                    cadence_style,
                ),
                **_line_style(theme, mpc.lane_envelope, "lane_envelope"),
            )
        speed_curvature_annotations = ()
        if show_speed_and_curvature_annotations:
            speed_curvature_annotations = tuple(
                axis.text(
                    0.0,
                    0.0,
                    "",
                    color=annotations.muted_text_color,
                    fontsize=(
                        _BASE_ANNOTATION_FONT_SIZE
                        * annotations.font_scale
                    ),
                    ha="left",
                    va="top",
                    zorder=_layer_zorder(theme, "annotations"),
                )
                for _ in range(horizon_rows)
            )
            for index, annotation in enumerate(
                speed_curvature_annotations
            ):
                annotation.set_gid(
                    f"mpc-world-speed-curvature-{index}"
                )
        status = None
        if show_status:
            panel_style = annotations.panel_style
            status = axis.text(
                0.01,
                0.99,
                "",
                transform=axis.transAxes,
                ha="left",
                va="top",
                color=annotations.text_color,
                fontsize=_BASE_STATUS_FONT_SIZE * annotations.font_scale,
                family=panel_style.font_family,
                bbox={
                    "boxstyle": "round,pad=0.3",
                    "facecolor": panel_style.background_color,
                    "edgecolor": panel_style.border_color,
                    "alpha": panel_style.background_opacity,
                    "linewidth": panel_style.border_line_scale,
                },
                zorder=_layer_zorder(theme, "hud"),
            )
            status.set_gid("mpc-world-status")
        return cls(
            formulation_target=formulation_target,
            predicted_path=predicted_path,
            prediction_nodes=prediction_nodes,
            executed_segment=executed_segment,
            predicted_x1=predicted_x1,
            actual_rollout=actual_rollout,
            actual_vehicle=actual_vehicle,
            actual_vehicle_plot_handles=None,
            predicted_headings=predicted_headings,
            heading_annotations=heading_annotations,
            sensor_preview_samples=sensor_preview_samples,
            unavailable_sensor_preview_samples=(
                unavailable_sensor_preview_samples
            ),
            right_lane_bound=right_lane_bound,
            left_lane_bound=left_lane_bound,
            speed_curvature_annotations=speed_curvature_annotations,
            status=status,
        )

    def clear(self):
        for line in (
            self.formulation_target,
            self.predicted_path,
            self.executed_segment,
            self.actual_rollout,
            self.right_lane_bound,
            self.left_lane_bound,
        ):
            if line is not None:
                line.set_data([], [])
        for collection in (
            self.prediction_nodes,
            self.predicted_x1,
            self.actual_vehicle,
            self.sensor_preview_samples,
            self.unavailable_sensor_preview_samples,
        ):
            if collection is not None:
                collection.set_offsets(_empty_offsets())
        if self.predicted_headings is not None:
            self.predicted_headings.set_segments([])
        for annotation in (
            *self.heading_annotations,
            *self.speed_curvature_annotations,
        ):
            annotation.set_text("")
            annotation.set_position((0.0, 0.0))
        if self.actual_vehicle_plot_handles is not None:
            for handle in self.actual_vehicle_plot_handles.values():
                handle.set_visible(False)


def _set_line(line, positions):
    if line is not None:
        values = np.asarray(positions, dtype=np.float64)
        segments, _ = _segment_world_polyline(
            values,
            line._dreamgym_world_cadence_m,
        )
        visible = _nan_separated_polyline(segments)
        line.set_data(visible[:, 0], visible[:, 1])


def _set_scatter(collection, positions):
    if collection is not None:
        collection.set_offsets(np.asarray(positions, dtype=np.float64))


def _heading_display(value, display_units):
    if display_units == "driving":
        return float(np.rad2deg(value)), "deg"
    return float(value), "rad"


def _speed_display(value, display_units):
    if display_units == "driving":
        return 3.6 * float(value), "km/h"
    return float(value), "m/s"


def _update_heading_artists(artists, prediction, display_units):
    if artists.predicted_headings is None:
        return
    positions = prediction.predicted_vehicle_positions_metres
    headings = prediction.predicted_vehicle_headings_radians
    marker_length_metres = 0.35
    endpoints = positions + marker_length_metres * np.column_stack(
        (np.cos(headings), np.sin(headings))
    )
    visible_heading_segments = []
    for stroke in np.stack((positions, endpoints), axis=1):
        segments, _ = _segment_world_polyline(
            stroke,
            artists.predicted_headings._dreamgym_world_cadence_m,
        )
        visible_heading_segments.extend(segments)
    artists.predicted_headings.set_segments(visible_heading_segments)
    for annotation, endpoint, heading in zip(
        artists.heading_annotations,
        endpoints,
        headings,
        strict=True,
    ):
        shown, unit = _heading_display(heading, display_units)
        annotation.set_position(tuple(endpoint))
        shown_heading = (
            f"{shown:.1f} {unit}"
            if unit == "deg"
            else f"{shown:.3f} {unit}"
        )
        annotation.set_text(f"heading={shown_heading}")


def _update_sensor_preview_artists(artists, prediction):
    if artists.sensor_preview_samples is None:
        return
    positions = prediction.source_preview_target_line_positions_metres
    validity = prediction.source_preview_validity
    if positions is None or validity is None:
        return
    _set_scatter(artists.sensor_preview_samples, positions[validity])
    _set_scatter(
        artists.unavailable_sensor_preview_samples,
        positions[np.logical_not(validity)],
    )


def _update_lane_artists(artists, prediction):
    if artists.right_lane_bound is None:
        return
    right = prediction.installed_right_lane_bound_positions_metres
    left = prediction.installed_left_lane_bound_positions_metres
    if right is None or left is None:
        return
    _set_line(artists.right_lane_bound, right)
    _set_line(artists.left_lane_bound, left)


def _update_speed_curvature_annotations(
    artists,
    context,
    prediction,
    display_units,
):
    if not artists.speed_curvature_annotations:
        return
    speeds = context.reference_speeds_mps
    road_context = context.road_horizon_context
    curvatures = (
        None
        if road_context is None
        else road_context.interpolated_target_line_curvatures_per_metre
    )
    for index, (annotation, position, speed) in enumerate(
        zip(
            artists.speed_curvature_annotations,
            prediction.predicted_vehicle_positions_metres,
            speeds,
            strict=True,
        )
    ):
        shown_speed, speed_unit = _speed_display(speed, display_units)
        text = f"v={shown_speed:.2f} {speed_unit}"
        if curvatures is not None:
            text += f"\ncurvature={curvatures[index]:.4f} 1/m"
        annotation.set_position(tuple(position))
        annotation.set_text(text)


def _world_prediction(record):
    context = record.prediction_context
    return None if context is None else context.world_prediction


def _unavailable_status(record):
    context = record.prediction_context
    if (
        context is not None
        and context.world_projection_unavailability_reason is not None
    ):
        reason = context.world_projection_unavailability_reason.value
    elif record.policy_result.failure is not None:
        reason = record.policy_result.failure.reason
    else:
        reason = "no_usable_prediction"
    return f"world prediction unavailable: {reason}"


def _status_text(history, transition_index, prediction):
    record = history.records[transition_index]
    result = record.policy_result
    solver_status = (
        result.solve_status
        if result.solve_status is not None
        else f"policy failure: {result.failure.reason}"
    )
    fallback = (
        "none"
        if result.fallback_mode is None
        else result.fallback_mode.value
    )
    solver_time = (
        None
        if result.solve_result is None
        else result.solve_result.diagnostics.total_time_seconds
    )
    solver_timing = (
        "n/a" if solver_time is None else f"{1000.0 * solver_time:.2f} ms"
    )
    projection_timing = (
        "n/a"
        if prediction is None
        else f"{1000.0 * prediction.projection_time_seconds:.2f} ms"
    )
    status = (
        f"transition={transition_index} | policy={history.formulation.value} | "
        f"solver={solver_status} | fallback={fallback}\n"
        f"policy={1000.0 * result.total_time_seconds:.2f} ms | "
        f"solver={solver_timing} | projection={projection_timing}"
    )
    if prediction is None:
        status += f"\n{_unavailable_status(record)}"
    return status


def _configure_axis(axis, transition_index, figure_title=None):
    axis.set_xlabel("x [m]")
    axis.set_ylabel("y [m]")
    axis.set_aspect("equal", adjustable="datalim")
    title = (
        f"MPC world prediction at transition {transition_index}"
        if figure_title is None
        else f"{figure_title} — transition {transition_index}"
    )
    axis.set_title(title)


def _apply_animation_view(
    axis,
    history,
    transition_index,
    zoom_mode,
    zoom_width_m,
    zoom_height_m,
):
    if zoom_mode == "full_road":
        axis.relim()
        axis.autoscale_view()
        return
    center_index = transition_index + 1 if zoom_mode == "follow" else 0
    center = history.actual_world_positions_metres[center_index]
    axis.set_aspect("equal", adjustable="box")
    axis.set_xlim(
        float(center[0]) - 0.5 * zoom_width_m,
        float(center[0]) + 0.5 * zoom_width_m,
    )
    axis.set_ylim(
        float(center[1]) - 0.5 * zoom_height_m,
        float(center[1]) + 0.5 * zoom_height_m,
    )


def _render_transition(
    history,
    transition_index,
    artists,
    *,
    static_actual_segment,
    display_units,
    vehicle=None,
    axis=None,
):
    artists.clear()
    record = history.records[transition_index]
    prediction = _world_prediction(record)
    if artists.status is not None:
        artists.status.set_text(
            _status_text(history, transition_index, prediction)
        )
    if prediction is None:
        return

    positions = prediction.predicted_vehicle_positions_metres
    _set_line(
        artists.formulation_target,
        prediction.formulation_target_line_positions_metres,
    )
    _set_line(artists.predicted_path, positions)
    _set_scatter(artists.prediction_nodes, positions)
    _set_line(artists.executed_segment, positions[:2])
    _set_scatter(artists.predicted_x1, positions[1:2])
    _update_heading_artists(artists, prediction, display_units)
    _update_sensor_preview_artists(artists, prediction)
    _update_lane_artists(artists, prediction)
    assert record.prediction_context is not None
    _update_speed_curvature_annotations(
        artists,
        record.prediction_context,
        prediction,
        display_units,
    )
    if static_actual_segment and artists.actual_rollout is not None:
        final_index = min(
            transition_index + positions.shape[0] - 1,
            history.transition_count,
        )
        actual = history.actual_world_positions_metres[
            transition_index : final_index + 1
        ]
        _set_line(artists.actual_rollout, actual)
    elif artists.actual_rollout is not None:
        _set_line(
            artists.actual_rollout,
            history.actual_world_positions_metres[: transition_index + 2],
        )

    if artists.actual_rollout is not None:
        _set_scatter(
            artists.actual_vehicle,
            history.actual_world_positions_metres[
                transition_index + 1 : transition_index + 2
            ],
        )
        if artists.actual_vehicle_plot_handles is not None:
            assert axis is not None
            position = history.actual_world_positions_metres[
                transition_index + 1
            ]
            heading = history.actual_world_headings_radians[
                transition_index + 1
            ]
            steering = history.realized_steering_angles_radians[
                transition_index
            ]
            vehicle.plot_car_on_matplotlib_axis(
                axis,
                float(position[0]),
                float(position[1]),
                float(heading),
                float(steering),
                scale=1.0,
                plot_handles=artists.actual_vehicle_plot_handles,
            )
            for handle in artists.actual_vehicle_plot_handles.values():
                handle.set_visible(True)


def _create_world_artists(
    history,
    axis,
    *,
    show_formulation_target,
    show_prediction_nodes,
    show_actual_rollout,
    show_status,
    show_predicted_headings,
    show_sensor_preview_samples,
    show_lane_envelope,
    show_speed_and_curvature_annotations,
    theme,
    vehicle=None,
):
    artists = _WorldArtists.create(
        axis,
        show_formulation_target=show_formulation_target,
        show_prediction_nodes=show_prediction_nodes,
        show_actual_rollout=show_actual_rollout,
        show_status=show_status,
        show_predicted_headings=show_predicted_headings,
        show_sensor_preview_samples=show_sensor_preview_samples,
        show_lane_envelope=show_lane_envelope,
        show_speed_and_curvature_annotations=(
            show_speed_and_curvature_annotations
        ),
        horizon_rows=(
            int(history.policy_config_snapshot["horizon_steps"]) + 1
        ),
        theme=theme,
        use_actual_vehicle_marker=vehicle is None,
    )
    if vehicle is not None:
        position = history.actual_world_positions_metres[0]
        artists.actual_vehicle_plot_handles = (
            vehicle.plot_car_on_matplotlib_axis(
                axis,
                float(position[0]),
                float(position[1]),
                float(history.actual_world_headings_radians[0]),
                float(history.realized_steering_angles_radians[0]),
                scale=1.0,
                visualization_theme=theme,
            )
        )
        for handle in artists.actual_vehicle_plot_handles.values():
            handle.set_visible(False)
    return artists


def animate_mpc_world_prediction_history(
    history,
    *,
    zoom_mode,
    zoom_width_m=None,
    zoom_height_m=None,
    vehicle=None,
    figure_title=None,
    ax=None,
    road=None,
    frame_step=1,
    display_units="driving",
    show_formulation_target=True,
    show_prediction_nodes=True,
    show_actual_rollout=True,
    show_status=True,
    show_predicted_headings=False,
    show_sensor_preview_samples=False,
    show_lane_envelope=False,
    show_speed_and_curvature_annotations=False,
    visualization_theme=None,
):
    """Animate retained world predictions without showing or saving them."""

    _require_world_history(history)
    step = _positive_integer("frame_step", frame_step)
    _validate_display_units(display_units)
    _validate_flags(
        (
            show_formulation_target,
            show_prediction_nodes,
            show_actual_rollout,
            show_status,
            show_predicted_headings,
            show_sensor_preview_samples,
            show_lane_envelope,
            show_speed_and_curvature_annotations,
        )
    )
    zoom_width_m, zoom_height_m = _validate_animation_view(
        zoom_mode,
        zoom_width_m,
        zoom_height_m,
    )
    _validate_animation_vehicle(vehicle, show_actual_rollout)
    _validate_figure_title(figure_title)
    plot_road = _road_plotter(road)
    theme = _resolve_visualization_theme(visualization_theme)
    _prevalidate_road(road, theme)

    import matplotlib.animation as mpl_animation

    figure, axis = _figure_and_axis(ax)
    _apply_world_scene_theme(figure, axis, theme)
    _draw_road_background(axis, plot_road, theme)
    artists = _create_world_artists(
        history,
        axis,
        show_formulation_target=show_formulation_target,
        show_prediction_nodes=show_prediction_nodes,
        show_actual_rollout=show_actual_rollout,
        show_status=show_status,
        show_predicted_headings=show_predicted_headings,
        show_sensor_preview_samples=show_sensor_preview_samples,
        show_lane_envelope=show_lane_envelope,
        show_speed_and_curvature_annotations=(
            show_speed_and_curvature_annotations
        ),
        theme=theme,
        vehicle=vehicle,
    )
    _configure_axis(axis, 0, figure_title=figure_title)

    def update(transition_index):
        _render_transition(
            history,
            transition_index,
            artists,
            static_actual_segment=False,
            display_units=display_units,
            vehicle=vehicle,
            axis=axis,
        )
        _configure_axis(
            axis,
            transition_index,
            figure_title=figure_title,
        )
        _apply_animation_view(
            axis,
            history,
            transition_index,
            zoom_mode,
            zoom_width_m,
            zoom_height_m,
        )
        return tuple(
            (*axis.lines, *axis.collections, *axis.patches, *axis.texts)
        )

    return mpl_animation.FuncAnimation(
        figure,
        update,
        frames=range(0, history.transition_count, step),
        interval=1000.0 * step * history.control_timestep_seconds,
        cache_frame_data=False,
    )


def plot_mpc_world_prediction_at_transition(
    history,
    transition_index,
    *,
    ax=None,
    road=None,
    display_units="driving",
    show_formulation_target=True,
    show_prediction_nodes=True,
    show_actual_rollout=True,
    show_status=True,
    show_predicted_headings=False,
    show_sensor_preview_samples=False,
    show_lane_envelope=False,
    show_speed_and_curvature_annotations=False,
    visualization_theme=None,
):
    """Plot one retained world prediction without showing or saving it."""

    _require_world_history(history)
    index = _strict_transition_index(
        transition_index,
        history.transition_count,
    )
    _validate_display_units(display_units)
    _validate_flags(
        (
            show_formulation_target,
            show_prediction_nodes,
            show_actual_rollout,
            show_status,
            show_predicted_headings,
            show_sensor_preview_samples,
            show_lane_envelope,
            show_speed_and_curvature_annotations,
        )
    )
    plot_road = _road_plotter(road)
    theme = _resolve_visualization_theme(visualization_theme)
    _prevalidate_road(road, theme)
    figure, axis = _figure_and_axis(ax)
    _apply_world_scene_theme(figure, axis, theme)
    _draw_road_background(axis, plot_road, theme)
    artists = _create_world_artists(
        history,
        axis,
        show_formulation_target=show_formulation_target,
        show_prediction_nodes=show_prediction_nodes,
        show_actual_rollout=show_actual_rollout,
        show_status=show_status,
        show_predicted_headings=show_predicted_headings,
        show_sensor_preview_samples=show_sensor_preview_samples,
        show_lane_envelope=show_lane_envelope,
        show_speed_and_curvature_annotations=(
            show_speed_and_curvature_annotations
        ),
        theme=theme,
    )
    _render_transition(
        history,
        index,
        artists,
        static_actual_segment=True,
        display_units=display_units,
    )
    _configure_axis(axis, index)
    axis.relim()
    axis.autoscale_view()
    return figure, axis
