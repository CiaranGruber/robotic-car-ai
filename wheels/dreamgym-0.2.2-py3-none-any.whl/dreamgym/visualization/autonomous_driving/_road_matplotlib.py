"""Matplotlib adapter for Road drawing and Road-owned animations."""

import datetime
from pathlib import Path

import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import PathCollection
from matplotlib.patches import Rectangle
from matplotlib.transforms import Affine2D, IdentityTransform

from dreamgym.envs.road_core import schema_utils
from dreamgym.envs.road_core import lane_geometry
from dreamgym.envs.road_core import utils as road_utils
from ._road_presentation import (
    _cadence_for_pattern,
    _calibrate_marking,
    _cone_color,
    _marking_signature,
    _marking_components,
    _nan_separated_polyline,
    _segment_world_polyline,
    _surface_color,
)


def _zorder(style, layer):
    return tuple(style.layer_order).index(layer)


def _marking_color(marking, resolved_marking_colors):
    color = marking.get("color")
    key = tuple(color) if isinstance(color, list) else color
    return dict(resolved_marking_colors)[key]


def progress_samples_for_element(element_idx, progress_step_m, element_lengths, element_ends):
    progress_step_m = max(float(progress_step_m), 0.05)
    element_start = float(element_ends[element_idx] - element_lengths[element_idx])
    element_end = float(element_ends[element_idx])
    element_length = float(element_lengths[element_idx])
    num_samples = max(2, int(np.ceil(element_length / progress_step_m)) + 1)
    return np.linspace(element_start, element_end, num=num_samples, endpoint=True, dtype=np.float32)


def _render_offset_line(
    axis_handle, segmented_coordinates, color, linewidth, opacity, zorder,
):
    return axis_handle.plot(
        segmented_coordinates[:, 0], segmented_coordinates[:, 1],
        color=color, linewidth=linewidth,
        linestyle="-", alpha=opacity, zorder=zorder,
    )


def _render_lane_marking(
    road, axis_handle, progress_values, center_offsets, marking, zorder, style,
    resolved_marking_colors, reference_points=None, reference_angles=None,
    color=None, opacity=None, line_scale=None,
    *, identity_prefix, incoming_phase_by_identity,
):
    handles = []
    terminal_phase_by_identity = {}
    color = _marking_color(marking, resolved_marking_colors) if color is None else color
    opacity = style.marking_opacity if opacity is None else opacity
    marking_width, _, calibrated_line_scale, outline_scale = _calibrate_marking(marking, style)
    line_scale = calibrated_line_scale if line_scale is None else line_scale
    linewidth = max(0.6, marking_width * 10.0 * line_scale)
    center_offsets = np.asarray(center_offsets, dtype=np.float32).reshape(-1)
    marking_signature = _marking_signature(marking)
    for component_index, (extra_offset_m, pattern) in enumerate(
        _marking_components(0.0, marking)
    ):
        offsets = center_offsets + extra_offset_m
        if (reference_points is None) or (reference_angles is None):
            coordinates = road.convert_progression_and_lateral_offsets_to_coordinates(
                progress_values, offsets,
            )
        else:
            coordinates = road_utils.coordinates_at_lateral_offsets_from_reference_points(
                reference_points, reference_angles, offsets,
            )
        coordinates = np.asarray(coordinates, dtype=np.float64)
        finite_pairs = np.all(np.isfinite(coordinates[:-1]), axis=1) & np.all(
            np.isfinite(coordinates[1:]), axis=1,
        )
        has_positive_length_finite_run = bool(np.any(
            finite_pairs
            & (np.linalg.norm(coordinates[1:] - coordinates[:-1], axis=1) > 0.0)
        ))
        identity = identity_prefix + (marking_signature, component_index)
        segments, terminal_phase_m = _segment_world_polyline(
            coordinates,
            _cadence_for_pattern(pattern, style),
            initial_phase_m=incoming_phase_by_identity.get(identity, 0.0),
        )
        segmented_coordinates = _nan_separated_polyline(segments)
        if outline_scale > 0.0:
            handles.extend(_render_offset_line(
                axis_handle, segmented_coordinates, style.marking_outline_color,
                linewidth * (1.0 + outline_scale), opacity, zorder,
            ))
        handles.extend(_render_offset_line(
            axis_handle, segmented_coordinates, color, linewidth, opacity, zorder,
        ))
        if has_positive_length_finite_run:
            terminal_phase_by_identity[identity] = terminal_phase_m
    return handles, terminal_phase_by_identity


def _render_offset_band(
    road, axis_handle, progress_values, lower_offsets, upper_offsets, color, opacity,
    zorder, reference_points=None, reference_angles=None,
):
    lower_offsets = np.asarray(lower_offsets, dtype=np.float32).reshape(-1)
    upper_offsets = np.asarray(upper_offsets, dtype=np.float32).reshape(-1)
    if np.all(np.isnan(upper_offsets - lower_offsets)):
        return []
    if np.nanmax(np.abs(upper_offsets - lower_offsets)) <= 1e-9:
        return []
    if (reference_points is None) or (reference_angles is None):
        lower_coords = road.convert_progression_and_lateral_offsets_to_coordinates(progress_values, lower_offsets)
        upper_coords = road.convert_progression_and_lateral_offsets_to_coordinates(progress_values, upper_offsets)
    else:
        lower_coords = road_utils.coordinates_at_lateral_offsets_from_reference_points(reference_points, reference_angles, lower_offsets)
        upper_coords = road_utils.coordinates_at_lateral_offsets_from_reference_points(reference_points, reference_angles, upper_offsets)
    return axis_handle.fill(
        np.concatenate((lower_coords[:, 0], upper_coords[::-1, 0])),
        np.concatenate((lower_coords[:, 1], upper_coords[::-1, 1])),
        facecolor=color, edgecolor="none", alpha=opacity, zorder=zorder,
    )


def _render_element_surfaces(
    road, axis_handle, progress_values, reference_points, reference_angles, cross_sections,
    lane_samples, render_lanes, render_edge_bands, style,
):
    handles = []
    if render_edge_bands:
        for side in ("left", "right"):
            for band_idx in range(max(len(section["edge_bands"][side]) for section in cross_sections)):
                band = next(section["edge_bands"][side][band_idx] for section in cross_sections if band_idx < len(section["edge_bands"][side]))
                handles.extend(_render_offset_band(
                    road, axis_handle, progress_values,
                    [section["edge_bands"][side][band_idx]["lower_offset_m"] if band_idx < len(section["edge_bands"][side]) else np.nan for section in cross_sections],
                    [section["edge_bands"][side][band_idx]["upper_offset_m"] if band_idx < len(section["edge_bands"][side]) else np.nan for section in cross_sections],
                    _surface_color(band["surface"], style), style.surface_opacity,
                    _zorder(style, "edge_bands"), reference_points, reference_angles,
                ))
    if render_lanes:
        centered_lane_samples = [
            sample
            if sample["metadata"]["lanes"]["reference_line_role"] == "lane_center"
            else None
            for sample in lane_samples
        ]
        if any(sample is not None for sample in centered_lane_samples):
            centered_lane_sample = next(
                sample for sample in centered_lane_samples if sample is not None
            )
            centered_lane_bounds = [
                (
                    lane_geometry.reference_lane_bounds_from_lane_sample(sample)
                    if sample is not None
                    else None
                )
                for sample in centered_lane_samples
            ]
            handles.extend(_render_offset_band(
                road, axis_handle, progress_values,
                [
                    bounds["right_bound_m"] if bounds is not None else np.nan
                    for bounds in centered_lane_bounds
                ],
                [
                    bounds["left_bound_m"] if bounds is not None else np.nan
                    for bounds in centered_lane_bounds
                ],
                _surface_color(
                    centered_lane_sample["metadata"]["lanes"]["reference_lane"]["surface"],
                    style,
                ),
                style.surface_opacity,
                _zorder(style, "lane_surfaces"), reference_points, reference_angles,
            ))
        lane_indices = []
        for section in cross_sections:
            lane_indices.extend(lane["lane_index"] for lane in section["lanes"] if lane["lane_index"] not in lane_indices)
        for lane_index in lane_indices:
            lane = next(lane for section in cross_sections for lane in section["lanes"] if lane["lane_index"] == lane_index)
            matching_lanes = [
                [candidate for candidate in section["lanes"] if candidate["lane_index"] == lane_index]
                for section in cross_sections
            ]
            handles.extend(_render_offset_band(
                road, axis_handle, progress_values,
                [matches[0]["lower_offset_m"] if matches else np.nan for matches in matching_lanes],
                [matches[0]["upper_offset_m"] if matches else np.nan for matches in matching_lanes],
                _surface_color(lane["surface"], style), style.surface_opacity,
                _zorder(style, "lane_surfaces"), reference_points, reference_angles,
            ))
    return handles


def _render_element_lane_lines(
    road, axis_handle, progress_values, reference_points, reference_angles, cross_sections,
    render_lane_lines, render_reference_line, style, resolved_marking_colors,
    incoming_phase_by_identity,
):
    handles = []
    terminal_phase_by_identity = {}
    line_indices = []
    for section in cross_sections:
        line_indices.extend(line["lane_line_index"] for line in section["lane_lines"] if line["lane_line_index"] not in line_indices)
    for line_idx in line_indices:
        line = next(
            line
            for section in reversed(cross_sections)
            for line in section["lane_lines"]
            if line["lane_line_index"] == line_idx
        )
        if (line_idx == 0 and not render_reference_line) or (line_idx != 0 and not render_lane_lines):
            continue
        offsets = [
            matches[0]["offset_m"] if matches else np.nan
            for matches in ([line for line in section["lane_lines"] if line["lane_line_index"] == line_idx] for section in cross_sections)
        ]
        marking_handles, marking_phases = _render_lane_marking(
            road, axis_handle, progress_values, offsets, line["marking"],
            _zorder(style, "road_markings"), style, resolved_marking_colors,
            reference_points, reference_angles,
            identity_prefix=("lane_line", line_idx),
            incoming_phase_by_identity=incoming_phase_by_identity,
        )
        handles.extend(marking_handles)
        terminal_phase_by_identity.update(marking_phases)
    return handles, terminal_phase_by_identity


def _render_element_lane_centers(
    road, axis_handle, progress_values, reference_points, reference_angles, lane_samples,
    cross_sections, show_lane_centers, style, resolved_marking_colors,
    incoming_phase_by_identity,
):
    handles = []
    terminal_phase_by_identity = {}
    lane_indices = []
    for section in cross_sections:
        lane_indices.extend(lane["lane_index"] for lane in section["lanes"] if lane["lane_index"] not in lane_indices)
    for lane_idx in lane_indices:
        lane_key = schema_utils.lane_key(lane_idx)
        metadata = next(
            sample["metadata"]
            for sample in reversed(lane_samples)
            if lane_key in sample["metadata"]["lane_markings"]["lane_center_lines"]
        )
        marking = metadata["lane_markings"]["lane_center_lines"].get(lane_key, {"style": "none"})
        if marking.get("style", "none") == "none":
            if not show_lane_centers:
                continue
            marking = {"style": style.lane_center_pattern, "width_m": 0.05, "gap_m": 0.10}
            presentation_overrides = {
                "color": style.lane_center_color,
                "opacity": style.lane_center_opacity,
                "line_scale": style.lane_center_line_scale,
            }
        else:
            presentation_overrides = {}
        offsets = [
            matches[0]["center_offset_m"] if matches else np.nan
            for matches in ([lane for lane in section["lanes"] if lane["lane_index"] == lane_idx] for section in cross_sections)
        ]
        marking_handles, marking_phases = _render_lane_marking(
            road, axis_handle, progress_values, offsets, marking, _zorder(style, "lane_centers"),
            style, resolved_marking_colors, reference_points, reference_angles,
            identity_prefix=("lane_center", lane_idx),
            incoming_phase_by_identity=incoming_phase_by_identity,
            **presentation_overrides,
        )
        handles.extend(marking_handles)
        terminal_phase_by_identity.update(marking_phases)
    return handles, terminal_phase_by_identity


def _render_spec_cones(axis_handle, cone_points, style):
    grouped_points = {}
    for cone in cone_points:
        grouped_points.setdefault((cone["color"], cone["radius_m"]), []).append(cone)
    handles = []
    for (color, radius_m), cones in grouped_points.items():
        marker_radius = float(radius_m) * 120.0 * style.cone_marker_scale
        handle = axis_handle.scatter(
            x=[cone["px"] for cone in cones], y=[cone["py"] for cone in cones],
            s=max(8.0, marker_radius ** 2), marker="o", facecolor=_cone_color(color, style),
            alpha=1.0, linewidths=0.5 * style.cone_outline_scale,
            edgecolors=style.cone_outline_color, zorder=_zorder(style, "cones"),
        )
        if hasattr(handle, "set_gid"):
            handle.set_gid("road-cones-" + str(color))
        handles.append(handle)
    return handles


def plot_road(
    road, axis_handle, element_lengths, element_ends, reference_line_samples_at_progresses,
    lane_samples_at_progresses, cross_section_from_lane_sample, get_cone_points_from_spec,
    resolved_marking_colors, style, should_render_lanes=True, should_render_lane_lines=True,
    should_render_edge_bands=True, should_render_cones=True, show_lane_centers=False,
    should_render_reference_line=True, progress_step_m=1.0, cone_rng_seed=0,
):
    if element_ends.shape[0] == 0:
        return []
    line_handles, surface_handles, cone_handles = [], [], []
    incoming_phase_by_identity = {}
    for element_idx in range(element_ends.shape[0]):
        progress_values = progress_samples_for_element(element_idx, progress_step_m, element_lengths, element_ends)
        reference_samples = reference_line_samples_at_progresses(
            progress_values, include_coordinates=True, include_angles=True,
            include_curvatures=False, include_speeds=False, include_element_indices=False,
        )
        lane_samples = lane_samples_at_progresses(progress_values)
        cross_sections = [cross_section_from_lane_sample(sample) for sample in lane_samples]
        surface_handles.extend(_render_element_surfaces(
            road, axis_handle, progress_values, reference_samples["coordinates"], reference_samples["angles"],
            cross_sections, lane_samples, should_render_lanes, should_render_edge_bands, style,
        ))
        element_line_handles, line_phases = _render_element_lane_lines(
            road, axis_handle, progress_values, reference_samples["coordinates"], reference_samples["angles"],
            cross_sections, should_render_lane_lines, should_render_reference_line, style, resolved_marking_colors,
            incoming_phase_by_identity,
        )
        line_handles.extend(element_line_handles)
        element_center_handles, center_phases = _render_element_lane_centers(
            road, axis_handle, progress_values, reference_samples["coordinates"], reference_samples["angles"],
            lane_samples, cross_sections, show_lane_centers, style, resolved_marking_colors,
            incoming_phase_by_identity,
        )
        line_handles.extend(element_center_handles)
        next_phase_by_identity = {}
        next_phase_by_identity.update(line_phases)
        next_phase_by_identity.update(center_phases)
        incoming_phase_by_identity = next_phase_by_identity
    if should_render_cones:
        cone_handles.extend(_render_spec_cones(
            axis_handle, get_cone_points_from_spec(rng=np.random.default_rng(cone_rng_seed)), style,
        ))
    return line_handles + surface_handles + cone_handles


def _speed_specs(speed_values, should_render, kind, speed_change_indices):
    return [(kind, index, speed_values[index]) for index in speed_change_indices(speed_values)] if should_render else []


def _validate_sign_sides(speed_limit_side, recommended_speed_side):
    if speed_limit_side not in ("left", "right"):
        raise ValueError("speed_limit_side must be 'left' or 'right'.")
    if recommended_speed_side not in ("left", "right"):
        raise ValueError("recommended_speed_side must be 'left' or 'right'.")


def _sign_coordinate(element_start_progresses, element_idx, side, gap, outer_offset_for_speed_sign, coordinates):
    progress = float(element_start_progresses[element_idx])
    lateral_offset = outer_offset_for_speed_sign(progress, side) + (1.0 if side == "left" else -1.0) * float(gap)
    return coordinates([progress], [lateral_offset])[0]


def plot_speed_signs(
    axis_handle, element_ends, element_start_progresses, speed_limits, recommended_speeds,
    outer_offset_for_speed_sign, coordinates, speed_change_indices, style,
    should_render_speed_limits=True, should_render_recommended_speeds=True,
    speed_limit_lateral_gap_m=1.0, recommended_speed_lateral_gap_m=1.0,
    speed_limit_side="left", recommended_speed_side="right",
):
    if element_ends.shape[0] == 0:
        return []
    _validate_sign_sides(speed_limit_side, recommended_speed_side)
    specs = _speed_specs(speed_limits, should_render_speed_limits, "speed_limit", speed_change_indices)
    specs += _speed_specs(recommended_speeds, should_render_recommended_speeds, "recommended_speed", speed_change_indices)
    handles = []
    base_size = max(200.0, (0.75 * 30.0) ** 2)
    for sign_index, (kind, element_idx, speed_mps) in enumerate(specs):
        is_limit = kind == "speed_limit"
        side, gap = (speed_limit_side, speed_limit_lateral_gap_m) if is_limit else (recommended_speed_side, recommended_speed_lateral_gap_m)
        coord = _sign_coordinate(element_start_progresses, element_idx, side, gap, outer_offset_for_speed_sign, coordinates)
        marker_scale = style.speed_limit_marker_scale if is_limit else style.recommended_speed_marker_scale
        marker = axis_handle.scatter(
            [float(coord[0])], [float(coord[1])], s=base_size * marker_scale ** 2,
            marker="o" if is_limit else "D",
            facecolors=style.speed_limit_face_color if is_limit else style.recommended_speed_face_color,
            edgecolors=style.speed_limit_ring_color if is_limit else style.recommended_speed_outline_color,
            linewidths=(1.8 if is_limit else 1.2) * style.sign_outline_scale,
            zorder=_zorder(style, "speed_signs"),
        )
        marker._dreamgym_base_marker_size = float(base_size * marker_scale ** 2)
        marker.set_gid("road-" + kind.replace("_", "-") + "-sign-" + str(sign_index))
        text = axis_handle.text(
            float(coord[0]), float(coord[1]), str(int(round(float(speed_mps) * 3.6))),
            ha="center", va="center",
            color=style.speed_limit_text_color if is_limit else style.recommended_speed_text_color,
            fontsize=8.0 * style.sign_font_scale, fontweight="bold",
            zorder=_zorder(style, "speed_signs"),
        )
        text._dreamgym_base_font_size = 8.0 * style.sign_font_scale
        text.set_gid("road-" + kind.replace("_", "-") + "-text-" + str(sign_index))
        handles.extend((marker, text))
    return handles


def plot_speed_change_markers(
    axis_handle, element_ends, element_start_progresses, speed_limits, recommended_speeds,
    outer_offset_for_speed_sign, coordinates, speed_change_indices, style,
    should_render_speed_limits=True, should_render_recommended_speeds=True,
    speed_limit_side="left", recommended_speed_side="right", speed_limit_lateral_gap_m=0.6,
    recommended_speed_lateral_gap_m=0.6,
):
    if element_ends.shape[0] == 0:
        return []
    _validate_sign_sides(speed_limit_side, recommended_speed_side)
    specs = _speed_specs(speed_limits, should_render_speed_limits, "speed_limit", speed_change_indices)
    specs += _speed_specs(recommended_speeds, should_render_recommended_speeds, "recommended_speed", speed_change_indices)
    handles = []
    for marker_index, (kind, element_idx, _) in enumerate(specs):
        is_limit = kind == "speed_limit"
        side, gap = (speed_limit_side, speed_limit_lateral_gap_m) if is_limit else (recommended_speed_side, recommended_speed_lateral_gap_m)
        coord = _sign_coordinate(element_start_progresses, element_idx, side, gap, outer_offset_for_speed_sign, coordinates)
        scale = style.speed_limit_marker_scale if is_limit else style.recommended_speed_marker_scale
        handle = axis_handle.scatter(
            [float(coord[0])], [float(coord[1])], s=60.0 * scale ** 2,
            marker="o" if is_limit else "D",
            facecolors=style.speed_limit_face_color if is_limit else style.recommended_speed_face_color,
            edgecolors=style.speed_limit_ring_color if is_limit else style.recommended_speed_outline_color,
            linewidths=(1.4 if is_limit else 1.0) * style.sign_outline_scale,
            zorder=_zorder(style, "speed_signs"),
        )
        handle.set_gid("road-" + kind.replace("_", "-") + "-change-" + str(marker_index))
        handles.append(handle)
    return handles


def _update_speed_sign_screen_sizes(speed_sign_handles, axis_handle, shrink_start_span_m, min_scale):
    if not speed_sign_handles:
        return
    scale = 1.0
    if shrink_start_span_m is not None and float(shrink_start_span_m) > 0.0:
        x_span = abs(float(axis_handle.get_xlim()[1]) - float(axis_handle.get_xlim()[0]))
        y_span = abs(float(axis_handle.get_ylim()[1]) - float(axis_handle.get_ylim()[0]))
        visible_span = max(x_span, y_span)
        if visible_span > float(shrink_start_span_m):
            scale = max(float(min_scale), float(shrink_start_span_m) / visible_span)
    for handle in speed_sign_handles:
        base_marker_size = getattr(handle, "_dreamgym_base_marker_size", None)
        if base_marker_size is not None and hasattr(handle, "set_sizes"):
            handle.set_sizes([float(base_marker_size) * scale * scale])
        base_font_size = getattr(handle, "_dreamgym_base_font_size", None)
        if base_font_size is not None and hasattr(handle, "set_fontsize"):
            handle.set_fontsize(float(base_font_size) * scale)


def _create_fixed_speed_sign_status(axis_handle, theme):
    roadside = theme.roadside
    layout = roadside.fixed_speed_sign_layout
    anchor_x, anchor_y = layout.recommended_speed_anchor_in_axes_coordinates
    base_size = 720.0
    specs = (
        (
            "speed-limit",
            anchor_x - layout.horizontal_gap_fraction_of_axes_width,
            "o",
            base_size * roadside.speed_limit_marker_scale ** 2,
            roadside.speed_limit_face_color, roadside.speed_limit_ring_color,
            roadside.speed_limit_text_color, 1.8,
        ),
        (
            "recommended-speed", anchor_x, "D",
            0.70 * base_size * roadside.recommended_speed_marker_scale ** 2,
            roadside.recommended_speed_face_color, roadside.recommended_speed_outline_color,
            roadside.recommended_speed_text_color, 1.2,
        ),
    )
    handles = []
    text_handles = {}
    for kind, x_pos, marker, marker_size, facecolor, edgecolor, textcolor, linewidth in specs:
        marker_handle = axis_handle.scatter(
            [x_pos], [anchor_y], s=marker_size, marker=marker, facecolors=facecolor,
            edgecolors=edgecolor, linewidths=linewidth * roadside.sign_outline_scale,
            transform=axis_handle.transAxes, clip_on=False,
            zorder=_zorder(theme, "speed_signs"),
        )
        marker_handle.set_gid("road-animation-fixed-" + kind + "-sign")
        text_handle = axis_handle.text(
            x_pos, anchor_y, "", transform=axis_handle.transAxes, ha="center", va="center",
            color=textcolor, fontsize=8.5 * roadside.sign_font_scale, fontweight="bold",
            clip_on=False, zorder=_zorder(theme, "speed_signs"),
        )
        text_handle.set_gid("road-animation-fixed-" + kind + "-text")
        handles.extend((marker_handle, text_handle))
        text_handles[kind] = text_handle
    return {"handles": handles, "text_handles": text_handles}


def _update_fixed_speed_sign_status(status, speed_limit_mps, recommended_speed_mps):
    if status is None:
        return
    status["text_handles"]["speed-limit"].set_text(str(int(round(float(speed_limit_mps) * 3.6))))
    status["text_handles"]["recommended-speed"].set_text(
        str(int(round(float(recommended_speed_mps) * 3.6)))
    )


def _vehicle_artists(vehicle_handle):
    return [] if vehicle_handle is None else list(vehicle_handle.values())


def _create_animation_vehicle(
    axis_handle, px, py, theta, vehicle_style, vehicle_width_m, vehicle_length_m, theme,
):
    if vehicle_style == "none":
        return None
    vehicle = theme.vehicle
    zorder = _zorder(theme, "vehicle")
    if vehicle_style == "dot":
        marker_by_shape = {"circle": "o", "square": "s", "diamond": "D", "cross": "x"}
        line, = axis_handle.plot(
            [px], [py], marker=marker_by_shape[vehicle.dot_shape],
            markersize=6.0 * vehicle.dot_marker_scale, color=vehicle.fill_color,
            alpha=vehicle.fill_opacity, markeredgecolor=vehicle.outline_color,
            markeredgewidth=vehicle.outline_scale, zorder=zorder,
        )
        line.set_gid("road-animation-vehicle-dot")
        return {"marker": line}
    if vehicle_style != "car":
        raise ValueError("vehicle_style must be 'none', 'dot', or 'car'.")
    rectangle = Rectangle(
        (px - 0.5 * vehicle_length_m, py - 0.5 * vehicle_width_m),
        width=vehicle_length_m, height=vehicle_width_m,
        angle=float(theta) * 180.0 / np.pi, rotation_point="center",
        linewidth=vehicle.outline_scale, edgecolor=vehicle.outline_color,
        facecolor=vehicle.fill_color, alpha=vehicle.fill_opacity, zorder=zorder,
    )
    rectangle.set_gid("road-animation-vehicle-car")
    axis_handle.add_patch(rectangle)
    return {"body_rect": rectangle}


def _update_animation_vehicle(
    vehicle_handle, px, py, theta, vehicle_style, vehicle_width_m, vehicle_length_m,
):
    if vehicle_handle is None:
        return
    if vehicle_style == "dot":
        vehicle_handle["marker"].set_data([px], [py])
    elif vehicle_style == "car":
        rectangle = vehicle_handle["body_rect"]
        rectangle.set_xy((px - 0.5 * vehicle_length_m, py - 0.5 * vehicle_width_m))
        rectangle.set_angle(float(theta) * 180.0 / np.pi)


def _configure_canvas(axis, fig, theme, view_orientation):
    fig.set_facecolor(theme.canvas.figure_background_color)
    fig.patch.set_gid("road-animation-figure-canvas")
    fig.patch.set_zorder(_zorder(theme, "canvas"))
    axis.set_facecolor(theme.canvas.world_background_color)
    axis.patch.set_gid("road-animation-world-canvas")
    axis.patch.set_zorder(_zorder(theme, "canvas"))
    axis.set_aspect("equal", adjustable="box")
    if view_orientation == "car":
        axis.set_xlabel("x body [m]")
        axis.set_ylabel("y body [m]")
    else:
        axis.set_xlabel("x [m]")
        axis.set_ylabel("y [m]")
    patterns = {"solid": "-", "dashed": "--", "dotted": ":", "dash_dot": "-."}
    axis.grid(
        True, color=theme.canvas.grid_color, linewidth=0.5 * theme.canvas.grid_line_scale,
        alpha=theme.canvas.grid_opacity, linestyle=patterns[theme.canvas.grid_pattern],
        zorder=_zorder(theme, "canvas"),
    )
    for index, gridline in enumerate(axis.get_xgridlines() + axis.get_ygridlines()):
        gridline.set_gid("road-animation-grid-" + str(index))
    axis.margins(0.08)


def animate_reference_line_drive(
    road,
    motion,
    road_width,
    minimum_lane_width,
    resolved_marking_colors,
    style,
    theme,
    element_lengths,
    element_ends,
    element_starts,
    speed_limits,
    recommended_speeds,
    reference_line_samples_at_progresses,
    lane_samples_at_progresses,
    cross_section_from_lane_sample,
    get_cone_points_from_spec,
    outer_offset_for_speed_sign,
    coordinates_from_progress_and_offsets,
    speed_change_indices,
    zoom_limits,
    body_frame_limits_from_world_limits,
    interpolate_limits,
    *,
    fps,
    vehicle_style,
    zoom_mode,
    start_view_mode,
    view_orientation,
    zoom_width_m,
    zoom_height_m,
    zoom_road_width_factor,
    intro_duration_s,
    figure_size,
    dpi,
    should_render_lanes,
    should_render_lane_lines,
    should_render_edge_bands,
    should_render_cones,
    should_render_reference_line,
    should_render_speed_signs,
    show_details,
    show_progress_bar,
    progress_bar_position,
    road_progress_step_m,
    cone_rng_seed,
    speed_sign_display_mode,
    should_render_speed_change_markers,
    save_path,
    should_save,
    writer,
    return_animation,
    return_details,
):
    if zoom_width_m is None:
        zoom_width_m = float(zoom_road_width_factor) * road_width
    if zoom_height_m is None:
        zoom_height_m = float(zoom_road_width_factor) * road_width
    vehicle_width_m = 0.8 * minimum_lane_width
    vehicle_length_m = 2.0 * vehicle_width_m
    fig = None
    try:
        fig, axis = plt.subplots(figsize=figure_size, dpi=dpi)
        road_handles = plot_road(
            road, axis, element_lengths, element_ends, reference_line_samples_at_progresses,
            lane_samples_at_progresses, cross_section_from_lane_sample, get_cone_points_from_spec,
            resolved_marking_colors, style, should_render_lanes=should_render_lanes,
            should_render_lane_lines=should_render_lane_lines,
            should_render_edge_bands=should_render_edge_bands,
            should_render_cones=should_render_cones,
            should_render_reference_line=should_render_reference_line,
            progress_step_m=road_progress_step_m, cone_rng_seed=cone_rng_seed,
        )
        speed_sign_handles = []
        fixed_speed_sign_status = None
        if should_render_speed_signs:
            if speed_sign_display_mode in ("roadside", "both"):
                speed_sign_handles.extend(plot_speed_signs(
                    axis, element_ends, element_starts, speed_limits, recommended_speeds,
                    outer_offset_for_speed_sign,
                    coordinates_from_progress_and_offsets, speed_change_indices, style,
                ))
            if speed_sign_display_mode in ("fixed", "both"):
                if should_render_speed_change_markers:
                    speed_sign_handles.extend(plot_speed_change_markers(
                        axis, element_ends, element_starts, speed_limits, recommended_speeds,
                        outer_offset_for_speed_sign,
                        coordinates_from_progress_and_offsets, speed_change_indices, style,
                    ))
                fixed_speed_sign_status = _create_fixed_speed_sign_status(axis, theme)

        px0, py0, theta0 = (float(motion[name][0]) for name in ("px", "py", "theta"))
        vehicle_handle = _create_animation_vehicle(
            axis, px0, py0, theta0, vehicle_style, vehicle_width_m, vehicle_length_m, theme,
        )
        _configure_canvas(axis, fig, theme, view_orientation)
        full_xlim, full_ylim = axis.get_xlim(), axis.get_ylim()
        start_zoom_xlim, start_zoom_ylim = zoom_limits(px0, py0, zoom_width_m, zoom_height_m)
        body_full_xlim0, body_full_ylim0 = body_frame_limits_from_world_limits(
            full_xlim, full_ylim, px0, py0, theta0,
        )
        body_zoom_xlim, body_zoom_ylim = zoom_limits(0.0, 0.0, zoom_width_m, zoom_height_m)

        details_text = None
        if show_details:
            details_anchors = (
                theme.annotations.details_panel_anchors_in_axes_coordinates
            )
            anchor = (
                details_anchors.with_progress_bar_at_top
                if progress_bar_position == "top"
                else details_anchors.with_progress_bar_at_bottom
            )
            panel_style = theme.annotations.panel_style
            details_text = axis.text(
                anchor[0], anchor[1], "", transform=axis.transAxes, ha="left", va="top",
                color=theme.annotations.text_color,
                fontsize=8.0 * theme.annotations.font_scale,
                fontfamily=panel_style.font_family,
                bbox={
                    "facecolor": panel_style.background_color,
                    "edgecolor": panel_style.border_color,
                    "alpha": panel_style.background_opacity,
                    "linewidth": 0.5 * panel_style.border_line_scale,
                    "boxstyle": "round,pad=0.25",
                },
                zorder=_zorder(theme, "annotations"),
            )
            details_text.set_gid("road-animation-details")

        progress_bar_handles = None
        if show_progress_bar:
            progress_style = theme.annotations.progress_bar_style
            y_bar = 0.96 if progress_bar_position == "top" else 0.04
            background, = axis.plot(
                [0.08, 0.92], [y_bar, y_bar], transform=axis.transAxes,
                color=progress_style.background_color,
                linewidth=5.0 * progress_style.line_scale,
                solid_capstyle="round", zorder=_zorder(theme, "hud"),
            )
            foreground, = axis.plot(
                [0.08, 0.08], [y_bar, y_bar], transform=axis.transAxes,
                color=progress_style.foreground_color,
                linewidth=5.0 * progress_style.line_scale,
                solid_capstyle="round", zorder=_zorder(theme, "hud"),
            )
            background.set_gid("road-animation-progress-background")
            foreground.set_gid("road-animation-progress-foreground")
            progress_bar_handles = (background, foreground)

        vehicle_data_artists = _vehicle_artists(vehicle_handle)
        data_artists = list(road_handles) + list(speed_sign_handles) + vehicle_data_artists
        intro_frame_count = 0
        if start_view_mode == "full_then_zoom" and zoom_mode != "full_road":
            intro_frame_count = max(2, int(round(float(intro_duration_s) * float(fps))))
        motion_frame_count = motion["progress_m"].shape[0]
        total_frame_count = intro_frame_count + motion_frame_count
        shrink_start_span_m = (
            theme.roadside.speed_sign_shrink_start_view_span_factor * max(
                float(zoom_width_m),
                float(zoom_height_m),
            )
        )

        def update_frame(frame_idx):
            if frame_idx < intro_frame_count:
                motion_idx = 0
                alpha = frame_idx / max(1, intro_frame_count - 1)
            else:
                motion_idx = min(frame_idx - intro_frame_count, motion_frame_count - 1)
                alpha = 1.0
            px, py, theta = (
                float(motion[name][motion_idx]) for name in ("px", "py", "theta")
            )
            progress = float(motion["progress_m"][motion_idx])
            speed = float(motion["speed_mps"][motion_idx])
            speed_limit = float(motion["speed_limit_mps"][motion_idx])
            recommended_speed = float(motion["recommended_speed_mps"][motion_idx])
            progress_fraction = float(motion["progress_fraction"][motion_idx])
            _update_animation_vehicle(
                vehicle_handle, px, py, theta, vehicle_style, vehicle_width_m, vehicle_length_m,
            )
            if view_orientation == "car":
                if zoom_mode == "full_road":
                    body_full_xlim, body_full_ylim = body_frame_limits_from_world_limits(
                        full_xlim, full_ylim, px, py, theta,
                    )
                    axis.set_xlim(body_full_xlim)
                    axis.set_ylim(body_full_ylim)
                elif frame_idx < intro_frame_count:
                    axis.set_xlim(interpolate_limits(body_full_xlim0, body_zoom_xlim, alpha))
                    axis.set_ylim(interpolate_limits(body_full_ylim0, body_zoom_ylim, alpha))
                else:
                    axis.set_xlim(body_zoom_xlim)
                    axis.set_ylim(body_zoom_ylim)
            elif zoom_mode == "full_road":
                axis.set_xlim(full_xlim)
                axis.set_ylim(full_ylim)
            else:
                center_x, center_y = (px, py) if zoom_mode == "follow" else (px0, py0)
                zoom_xlim, zoom_ylim = zoom_limits(
                    center_x, center_y, zoom_width_m, zoom_height_m,
                )
                if frame_idx < intro_frame_count:
                    axis.set_xlim(interpolate_limits(full_xlim, start_zoom_xlim, alpha))
                    axis.set_ylim(interpolate_limits(full_ylim, start_zoom_ylim, alpha))
                else:
                    axis.set_xlim(zoom_xlim)
                    axis.set_ylim(zoom_ylim)
            _update_speed_sign_screen_sizes(
                speed_sign_handles,
                axis,
                shrink_start_span_m,
                theme.roadside.speed_sign_minimum_scale,
            )
            _update_fixed_speed_sign_status(
                fixed_speed_sign_status, speed_limit, recommended_speed,
            )
            if view_orientation == "car":
                data_transform = Affine2D().translate(-px, -py).rotate(-theta) + axis.transData
            else:
                data_transform = axis.transData
            for artist in data_artists:
                if isinstance(artist, PathCollection):
                    artist.set_transform(IdentityTransform())
                    artist.set_offset_transform(data_transform)
                else:
                    artist.set_transform(data_transform)
            if details_text is not None:
                details_text.set_text(
                    "progress: {:.1f} m ({:.0f}%)\nspeed: {:.1f} m/s ({:.0f} km/h)\n"
                    "theta: {:.2f} rad".format(
                        progress, 100.0 * progress_fraction, speed, 3.6 * speed, theta,
                    )
                )
            if progress_bar_handles is not None:
                progress_bar_handles[1].set_data(
                    [0.08, 0.08 + 0.84 * progress_fraction],
                    progress_bar_handles[1].get_ydata(),
                )
            returned_artists = data_artists
            if fixed_speed_sign_status is not None:
                returned_artists = returned_artists + list(fixed_speed_sign_status["handles"])
            if details_text is not None:
                returned_artists = returned_artists + [details_text]
            if progress_bar_handles is not None:
                returned_artists = returned_artists + list(progress_bar_handles)
            return returned_artists

        ani = animation.FuncAnimation(
            fig, update_frame, frames=range(total_frame_count),
            interval=1000.0 / float(fps), blit=False,
        )
        update_frame(0)
        resolved_save_path = None
        if should_save:
            if save_path is None:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                resolved_save_path = Path("examples") / "saved_figures" / (
                    "road_reference_line_drive_" + timestamp + ".gif"
                )
            else:
                resolved_save_path = Path(save_path)
                if resolved_save_path.suffix == "":
                    resolved_save_path = resolved_save_path.with_suffix(".gif")
            resolved_save_path.parent.mkdir(parents=True, exist_ok=True)
            selected_writer = writer
            if selected_writer is None:
                selected_writer = (
                    "ffmpeg" if resolved_save_path.suffix.lower() == ".mp4" else "pillow"
                )
            ani.save(str(resolved_save_path), writer=selected_writer, fps=float(fps), dpi=dpi)
        if return_details:
            return {
                "animation": ani if return_animation else None,
                "motion": motion,
                "figure": fig,
                "axis": axis,
                "save_path": None if resolved_save_path is None else str(resolved_save_path),
            }
        if return_animation:
            return ani
        result = None if resolved_save_path is None else str(resolved_save_path)
        plt.close(fig)
        return result
    except BaseException:
        if fig is not None:
            try:
                plt.close(fig)
            except BaseException:
                pass
        raise
