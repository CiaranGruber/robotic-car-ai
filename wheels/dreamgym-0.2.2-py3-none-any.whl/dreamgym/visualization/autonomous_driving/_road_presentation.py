"""Dependency-light autonomous-driving road presentation semantics.

This module resolves headless road records and one already-resolved theme into
immutable values consumed by private backend adapters.
"""

from dataclasses import dataclass

import numpy as np

from .theme import AutonomousDrivingVisualizationTheme, _normalise_colour


_ROAD_LITERAL_COLORS = {
    "black": "#000000",
    "white": "#ffffff",
    "red": "#ff0000",
    "green": "#008000",
    "blue": "#0000ff",
    "yellow": "#ffff00",
    "orange": "#ffa500",
    "purple": "#800080",
    "brown": "#a52a2a",
    "gray": "#808080",
    "grey": "#808080",
}


@dataclass(frozen=True, slots=True)
class _RoadPresentationStyle:
    surface_colors: tuple[tuple[str, str], ...]
    fallback_surface_color: str
    surface_opacity: float
    cone_colors: tuple[tuple[str, str], ...]
    default_marking_color: str
    marking_outline_color: str
    marking_opacity: float
    marking_line_scale: float
    marking_outline_scale: float
    lane_center_color: str
    lane_center_opacity: float
    lane_center_line_scale: float
    lane_center_pattern: str
    dashed_cadence_m: tuple[float, float]
    dotted_cadence_m: tuple[float, float]
    dash_dot_cadence_m: tuple[float, float, float, float]
    cone_outline_color: str
    cone_marker_scale: float
    cone_outline_scale: float
    speed_limit_face_color: str
    speed_limit_ring_color: str
    speed_limit_text_color: str
    recommended_speed_face_color: str
    recommended_speed_outline_color: str
    recommended_speed_text_color: str
    speed_limit_marker_scale: float
    recommended_speed_marker_scale: float
    sign_outline_scale: float
    sign_font_scale: float
    layer_order: tuple[str, ...]


def _resolve_road_presentation_style(theme):
    """Detach the road-relevant subset of an already-resolved theme once."""
    if not isinstance(theme, AutonomousDrivingVisualizationTheme):
        raise TypeError("theme must be an AutonomousDrivingVisualizationTheme")
    return _RoadPresentationStyle(
        surface_colors=(
            ("tarmac", theme.surfaces.tarmac_color),
            ("concrete", theme.surfaces.concrete_color),
            ("dirt", theme.surfaces.dirt_color),
            ("grass", theme.surfaces.grass_color),
        ),
        fallback_surface_color=theme.surfaces.fallback_color,
        surface_opacity=theme.surfaces.opacity,
        cone_colors=(
            ("blue", theme.roadside.cone_colors.blue),
            ("yellow", theme.roadside.cone_colors.yellow),
            ("orange", theme.roadside.cone_colors.orange),
            ("red", theme.roadside.cone_colors.red),
            ("green", theme.roadside.cone_colors.green),
            ("white", theme.roadside.cone_colors.white),
            ("black", theme.roadside.cone_colors.black),
        ),
        default_marking_color=theme.markings.default_color,
        marking_outline_color=theme.markings.outline_color,
        marking_opacity=theme.markings.opacity,
        marking_line_scale=theme.markings.line_scale,
        marking_outline_scale=theme.markings.outline_scale,
        lane_center_color=theme.markings.lane_center_color,
        lane_center_opacity=theme.markings.lane_center_opacity,
        lane_center_line_scale=theme.markings.lane_center_line_scale,
        lane_center_pattern=theme.markings.lane_center_pattern,
        dashed_cadence_m=tuple(theme.markings.dashed_cadence_m),
        dotted_cadence_m=tuple(theme.markings.dotted_cadence_m),
        dash_dot_cadence_m=tuple(theme.markings.dash_dot_cadence_m),
        cone_outline_color=theme.roadside.cone_outline_color,
        cone_marker_scale=theme.roadside.cone_marker_scale,
        cone_outline_scale=theme.roadside.cone_outline_scale,
        speed_limit_face_color=theme.roadside.speed_limit_face_color,
        speed_limit_ring_color=theme.roadside.speed_limit_ring_color,
        speed_limit_text_color=theme.roadside.speed_limit_text_color,
        recommended_speed_face_color=theme.roadside.recommended_speed_face_color,
        recommended_speed_outline_color=theme.roadside.recommended_speed_outline_color,
        recommended_speed_text_color=theme.roadside.recommended_speed_text_color,
        speed_limit_marker_scale=theme.roadside.speed_limit_marker_scale,
        recommended_speed_marker_scale=theme.roadside.recommended_speed_marker_scale,
        sign_outline_scale=theme.roadside.sign_outline_scale,
        sign_font_scale=theme.roadside.sign_font_scale,
        layer_order=tuple(theme.layer_order),
    )


def _resolve_marking_color(marking, style):
    """Resolve one explicit road literal or theme-inherited marking colour."""
    color = None if marking is None else marking.get("color")
    if color is None:
        return style.default_marking_color
    if isinstance(color, str) and color in _ROAD_LITERAL_COLORS:
        color = _ROAD_LITERAL_COLORS[color]
    return _normalise_colour(color, "road marking color")


def _iter_lane_markings(markings):
    """Iterate normalized public metadata or retained private renderer data."""
    if "lane_lines" in markings:
        yield from markings["lane_lines"].values()
        yield from markings["lane_centerlines"].values()
        return

    yield markings["reference_line"]
    yield from markings["left_lane_lines"]
    yield from markings["right_lane_lines"]
    yield from markings["lane_center_lines"].values()


def _resolve_marking_colors(lane_metadata, style):
    """Resolve and validate every structural marking colour before backend import."""
    colors = {None: _resolve_marking_color(None, style)}
    for metadata in lane_metadata:
        markings = metadata["lane_markings"]
        for marking in _iter_lane_markings(markings):
            color = marking.get("color")
            key = tuple(color) if isinstance(color, list) else color
            colors[key] = _resolve_marking_color(marking, style)
    _validate_cone_colors(lane_metadata, style)
    return tuple(colors.items())


def _validate_cone_colors(lane_metadata, style):
    """Validate every semantic cone colour before backend import."""
    for metadata in lane_metadata:
        for cone in metadata.get("cones", ()):
            _cone_color(cone.get("color", "orange"), style)


def _prevalidate_road_presentation(road, theme):
    """Validate presentation literals exposed by a road before backend work."""
    metadata_getter = getattr(road, "get_road_element_lane_metadata", None)
    if not callable(metadata_getter):
        return
    style = _resolve_road_presentation_style(theme)
    _resolve_marking_colors(metadata_getter(), style)


def _surface_color(surface, style):
    return dict(style.surface_colors).get(str(surface), style.fallback_surface_color)


def _cone_color(color, style):
    try:
        return dict(style.cone_colors)[color]
    except KeyError as exc:
        raise ValueError("unsupported semantic cone color: " + str(color)) from exc


def _marking_pattern(marking):
    return marking.get("pattern", marking.get("style", "none"))


def _marking_width_m(marking):
    return float(marking.get("nominal_width_m", marking.get("width_m", 0.12)))


def _marking_parallel_gap_m(marking):
    return float(
        marking.get(
            "nominal_parallel_line_gap_m",
            marking.get("gap_m", 0.12),
        )
    )


def _marking_components(center_offset_m, marking):
    """Return offset/pattern components for a semantic lane-marking style."""
    marking_style = _marking_pattern(marking)
    center = float(center_offset_m)
    single = {"solid": "solid", "dashed": "dashed", "dotted": "dotted"}
    if marking_style == "none":
        return ()
    if marking_style in single:
        return ((center, single[marking_style]),)
    half_separation = max(
        0.5 * (_marking_width_m(marking) + _marking_parallel_gap_m(marking)),
        0.03,
    )
    double = {
        "double_solid": ("solid", "solid"),
        "double_dashed": ("dashed", "dashed"),
        "solid_dashed": ("solid", "dashed"),
        "dashed_solid": ("dashed", "solid"),
        "right_solid_left_dashed": ("solid", "dashed"),
        "right_dashed_left_solid": ("dashed", "solid"),
    }
    try:
        first, second = double[marking_style]
    except KeyError as exc:
        raise ValueError("unsupported lane marking style: " + str(marking_style)) from exc
    return ((center - half_separation, first), (center + half_separation, second))


def _marking_signature(marking) -> tuple[object, ...]:
    raw_color = marking.get("color")
    color_key = tuple(raw_color) if isinstance(raw_color, list) else raw_color
    return (
        _marking_pattern(marking),
        color_key,
        _marking_width_m(marking),
        _marking_parallel_gap_m(marking),
    )


def _cadence_for_pattern(pattern, style):
    cadences = {
        "solid": (),
        "dashed": style.dashed_cadence_m,
        "dotted": style.dotted_cadence_m,
        "dash_dot": style.dash_dot_cadence_m,
    }
    try:
        return cadences[pattern]
    except KeyError as exc:
        raise ValueError("unsupported road pattern: " + str(pattern)) from exc


def _segment_world_polyline(
    coordinates,
    cadence_m,
    *,
    initial_phase_m=0.0,
) -> tuple[tuple[np.ndarray, ...], float]:
    """Split a world-coordinate polyline into visible cadence runs."""
    try:
        points = np.asarray(coordinates, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ValueError("coordinates must be an N x 2 numeric array") from exc
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError("coordinates must be an N x 2 numeric array")

    try:
        cadence = np.asarray(cadence_m, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ValueError("cadence_m must be an even-length numeric sequence") from exc
    if cadence.ndim != 1 or cadence.size % 2:
        raise ValueError("cadence_m must be an even-length numeric sequence")
    if np.any(~np.isfinite(cadence)) or np.any(cadence <= 0.0):
        raise ValueError("cadence_m entries must be finite and strictly positive")

    try:
        initial_phase = float(initial_phase_m)
    except (TypeError, ValueError) as exc:
        raise ValueError("initial_phase_m must be finite and non-negative") from exc
    if not np.isfinite(initial_phase) or initial_phase < 0.0:
        raise ValueError("initial_phase_m must be finite and non-negative")

    finite_rows = np.all(np.isfinite(points), axis=1)
    if cadence.size == 0:
        finite_runs = []
        run_start = None
        for index, is_finite in enumerate(finite_rows):
            if is_finite and run_start is None:
                run_start = index
            elif not is_finite and run_start is not None:
                finite_runs.append(points[run_start:index].copy())
                run_start = None
        if run_start is not None:
            finite_runs.append(points[run_start:].copy())
        return tuple(finite_runs), 0.0

    cadence_ends = np.cumsum(cadence, dtype=np.float64)
    cycle_length = float(cadence_ends[-1])
    phase = initial_phase % cycle_length
    cadence_index = int(np.searchsorted(cadence_ends, phase, side="right"))
    if cadence_index == cadence.size:
        cadence_index = 0
        phase = 0.0
    cadence_remaining = float(cadence_ends[cadence_index] - phase)
    visible_segments = []
    current_visible = None

    def finish_visible() -> None:
        nonlocal current_visible
        if current_visible is not None:
            visible_segments.append(np.vstack(current_visible).astype(np.float64, copy=False))
            current_visible = None

    def reset_phase() -> None:
        nonlocal cadence_index, cadence_remaining, phase
        cadence_index = 0
        cadence_remaining = float(cadence[0])
        phase = 0.0

    def traverse_finite_run(run: np.ndarray) -> None:
        nonlocal cadence_index, cadence_remaining, current_visible, phase
        for start, end in zip(run[:-1], run[1:]):
            chord = end - start
            chord_length = float(np.linalg.norm(chord))
            if chord_length == 0.0:
                continue

            distance = 0.0
            while distance < chord_length:
                chord_remaining = chord_length - distance
                step = min(chord_remaining, cadence_remaining)
                reaches_chord_end = step >= chord_remaining
                reaches_cadence_end = step >= cadence_remaining
                next_distance = chord_length if reaches_chord_end else distance + step
                piece_start = start.copy() if distance == 0.0 else start + chord * (
                    distance / chord_length
                )
                piece_end = end.copy() if reaches_chord_end else start + chord * (
                    next_distance / chord_length
                )

                if cadence_index % 2 == 0:
                    if current_visible is None:
                        current_visible = [piece_start]
                    current_visible.append(piece_end)

                distance = next_distance
                if reaches_cadence_end:
                    if cadence_index % 2 == 0:
                        finish_visible()
                    cadence_index = (cadence_index + 1) % cadence.size
                    phase = (
                        0.0
                        if cadence_index == 0
                        else float(cadence_ends[cadence_index - 1])
                    )
                    cadence_remaining = float(cadence[cadence_index])
                else:
                    phase += step
                    cadence_remaining -= step
        finish_visible()

    run_start = None
    for index, is_finite in enumerate(finite_rows):
        if is_finite and run_start is None:
            run_start = index
        elif not is_finite:
            if run_start is not None:
                traverse_finite_run(points[run_start:index])
                run_start = None
            reset_phase()
    if run_start is not None:
        traverse_finite_run(points[run_start:])

    return tuple(visible_segments), float(phase % cycle_length)


def _nan_separated_polyline(segments) -> np.ndarray:
    """Join visible polylines with one non-finite separator row."""
    arrays = [np.asarray(segment, dtype=np.float64).copy() for segment in segments]
    if not arrays:
        return np.empty((0, 2), dtype=np.float64)
    pieces = []
    separator = np.full((1, 2), np.nan, dtype=np.float64)
    for index, array in enumerate(arrays):
        if index:
            pieces.append(separator)
        pieces.append(array)
    return np.vstack(pieces).astype(np.float64, copy=False)


def _calibrate_marking(marking, style):
    """Return physical marking inputs and semantic scales for adapters."""
    return (
        _marking_width_m(marking),
        _marking_parallel_gap_m(marking),
        style.marking_line_scale,
        style.marking_outline_scale,
    )
