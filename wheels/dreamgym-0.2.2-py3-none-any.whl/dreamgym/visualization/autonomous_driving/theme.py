"""Immutable, dependency-free presentation theme for autonomous driving."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass, fields, is_dataclass
import math


_CANONICAL_THEME = {
    "canvas": {"world_background_color": "#eef5ea", "figure_background_color": "#f8fafc", "grid_color": "#94a3b8", "grid_opacity": 0.45, "grid_line_scale": 0.5, "grid_pattern": "dashed"},
    "surfaces": {"tarmac_color": "#b7c0ca", "concrete_color": "#d9d5cd", "dirt_color": "#ddc09f", "grass_color": "#d2e7cb", "fallback_color": "#cbd5e1", "opacity": 1.0},
    "markings": {"default_color": "#f8fafc", "outline_color": "#64748b", "opacity": 1.0, "line_scale": 1.0, "outline_scale": 0.5, "lane_center_color": "#0e7490", "lane_center_opacity": 0.75, "lane_center_line_scale": 0.7, "lane_center_pattern": "dotted", "dashed_cadence_m": [1.0, 0.7], "dotted_cadence_m": [0.2, 0.35], "dash_dot_cadence_m": [1.0, 0.45, 0.2, 0.45]},
    "roadside": {"cone_colors": {"blue": "#1d4ed8", "yellow": "#a16207", "orange": "#c2410c", "red": "#b91c1c", "green": "#166534", "white": "#f8fafc", "black": "#111827"}, "cone_outline_color": "#1f2937", "cone_marker_scale": 1.0, "cone_outline_scale": 0.5, "speed_limit_face_color": "#f8fafc", "speed_limit_ring_color": "#b42318", "speed_limit_text_color": "#1f2937", "recommended_speed_face_color": "#d6a84b", "recommended_speed_outline_color": "#713f12", "recommended_speed_text_color": "#1f2937", "speed_limit_marker_scale": 1.0, "recommended_speed_marker_scale": 1.08, "sign_outline_scale": 0.7, "sign_font_scale": 1.0, "speed_sign_shrink_start_view_span_factor": 1.1, "speed_sign_minimum_scale": 0.3, "fixed_speed_sign_layout": {"recommended_speed_anchor_in_axes_coordinates": [0.92, 0.86], "horizontal_gap_fraction_of_axes_width": 0.18}},
    "vehicle": {"fill_color": "#1e3a5f", "fill_opacity": 0.9, "outline_color": "#111827", "outline_scale": 0.6, "centerline_color": "#111827", "centerline_line_scale": 0.8, "wheel_color": "#111827", "wheel_line_scale": 1.4, "dot_shape": "circle", "dot_marker_scale": 1.0},
    "mpc": {"predicted_path": {"color": "#075985", "opacity": 1.0, "pattern": "solid", "line_scale": 1.0}, "prediction_nodes": {"color": "#075985", "opacity": 1.0, "shape": "circle", "marker_scale": 1.0, "outline_color": "#f8fafc", "outline_scale": 0.0}, "formulation_target": {"color": "#b45309", "opacity": 1.0, "pattern": "dashed", "line_scale": 0.6}, "first_predicted_state": {"color": "#b42318", "opacity": 1.0, "shape": "circle", "marker_scale": 1.8, "outline_color": "#f8fafc", "outline_scale": 0.8}, "actual_trajectory": {"color": "#166534", "opacity": 1.0, "pattern": "dotted", "line_scale": 0.9}, "actual_vehicle_fallback_marker": {"color": "#166534", "opacity": 1.0, "shape": "square", "marker_scale": 1.7, "outline_color": "#f8fafc", "outline_scale": 0.8}, "predicted_headings": {"color": "#6b4ca5", "opacity": 0.85, "pattern": "solid", "line_scale": 0.65}, "sensor_preview": {"color": "#b45309", "opacity": 0.8, "pattern": "solid", "line_scale": 0.8, "shape": "diamond", "marker_scale": 1.2}, "unavailable_sensor_preview_marker": {"color": "#6b7280", "opacity": 0.9, "shape": "cross", "marker_scale": 1.2, "outline_color": None, "outline_scale": None}, "lane_envelope": {"color": "#7c4a2d", "opacity": 0.8, "pattern": "dash_dot", "line_scale": 0.75}, "executed_segment": {"color": "#475569", "opacity": 0.85, "pattern": "solid", "line_scale": 1.4}},
    "annotations": {"text_color": "#1f2937", "muted_text_color": "#475569", "heading_text_color": "#6b4ca5", "font_scale": 1.0, "panel_style": {"font_family": "monospace", "background_color": "#f8fafc", "background_opacity": 0.92, "border_color": "#64748b", "border_line_scale": 0.5}, "details_panel_anchors_in_axes_coordinates": {"with_progress_bar_at_top": [0.02, 0.91], "with_progress_bar_at_bottom": [0.02, 0.98]}, "progress_bar_style": {"background_color": "#94a3b8", "foreground_color": "#1e3a5f", "line_scale": 1.0}},
    "layer_order": ["canvas", "edge_bands", "lane_surfaces", "road_markings", "lane_centers", "cones", "lane_envelope", "sensor_preview", "predicted_path", "predicted_headings", "executed_segment", "actual_trajectory", "prediction_nodes", "formulation_target", "sensor_markers", "first_predicted_state", "speed_signs", "vehicle", "annotations", "hud"],
}

_PATTERNS = frozenset(("solid", "dashed", "dotted", "dash_dot"))
_MARKERS = frozenset(("circle", "square", "diamond", "cross"))
_LAYER_NAMES = tuple(_CANONICAL_THEME["layer_order"])
_COLOUR_FIELDS = frozenset(
    {
        "color", "world_background_color", "figure_background_color", "grid_color", "tarmac_color",
        "concrete_color", "dirt_color", "grass_color", "fallback_color",
        "default_color", "outline_color", "lane_center_color", "cone_outline_color",
        "speed_limit_face_color", "speed_limit_ring_color", "speed_limit_text_color",
        "recommended_speed_face_color", "recommended_speed_outline_color",
        "recommended_speed_text_color", "fill_color", "centerline_color", "wheel_color",
        "text_color", "muted_text_color", "heading_text_color", "background_color",
        "border_color", "foreground_color",
    }
)


@dataclass(frozen=True, slots=True)
class _CanvasTheme:
    world_background_color: str
    figure_background_color: str
    grid_color: str
    grid_opacity: float
    grid_line_scale: float
    grid_pattern: str


@dataclass(frozen=True, slots=True)
class _SurfacesTheme:
    tarmac_color: str
    concrete_color: str
    dirt_color: str
    grass_color: str
    fallback_color: str
    opacity: float


@dataclass(frozen=True, slots=True)
class _MarkingsTheme:
    default_color: str
    outline_color: str
    opacity: float
    line_scale: float
    outline_scale: float
    lane_center_color: str
    lane_center_opacity: float
    lane_center_line_scale: float
    lane_center_pattern: str
    dashed_cadence_m: tuple[float, ...]
    dotted_cadence_m: tuple[float, ...]
    dash_dot_cadence_m: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class _ConeColorsTheme:
    blue: str
    yellow: str
    orange: str
    red: str
    green: str
    white: str
    black: str


@dataclass(frozen=True, slots=True)
class _FixedSpeedSignLayoutTheme:
    recommended_speed_anchor_in_axes_coordinates: tuple[float, float]
    horizontal_gap_fraction_of_axes_width: float


@dataclass(frozen=True, slots=True)
class _RoadsideTheme:
    cone_colors: _ConeColorsTheme
    cone_outline_color: str
    cone_marker_scale: float
    cone_outline_scale: float
    speed_limit_face_color: str
    speed_limit_ring_color: str
    speed_limit_text_color: str
    recommended_speed_face_color: str
    recommended_speed_outline_color: str
    recommended_speed_text_color: str
    speed_limit_marker_scale: float
    recommended_speed_marker_scale: float
    sign_outline_scale: float
    sign_font_scale: float
    speed_sign_shrink_start_view_span_factor: float
    speed_sign_minimum_scale: float
    fixed_speed_sign_layout: _FixedSpeedSignLayoutTheme


@dataclass(frozen=True, slots=True)
class _VehicleTheme:
    fill_color: str
    fill_opacity: float
    outline_color: str
    outline_scale: float
    centerline_color: str
    centerline_line_scale: float
    wheel_color: str
    wheel_line_scale: float
    dot_shape: str
    dot_marker_scale: float


@dataclass(frozen=True, slots=True)
class _LineTheme:
    color: str
    opacity: float
    pattern: str
    line_scale: float


@dataclass(frozen=True, slots=True)
class _MarkerTheme:
    color: str
    opacity: float
    shape: str
    marker_scale: float
    outline_color: str | None = None
    outline_scale: float | None = None


@dataclass(frozen=True, slots=True)
class _LineMarkerTheme:
    color: str
    opacity: float
    pattern: str
    line_scale: float
    shape: str
    marker_scale: float


@dataclass(frozen=True, slots=True)
class _MPCTheme:
    predicted_path: _LineTheme
    prediction_nodes: _MarkerTheme
    formulation_target: _LineTheme
    first_predicted_state: _MarkerTheme
    actual_trajectory: _LineTheme
    actual_vehicle_fallback_marker: _MarkerTheme
    predicted_headings: _LineTheme
    sensor_preview: _LineMarkerTheme
    unavailable_sensor_preview_marker: _MarkerTheme
    lane_envelope: _LineTheme
    executed_segment: _LineTheme


@dataclass(frozen=True, slots=True)
class _PanelStyleTheme:
    font_family: str
    background_color: str
    background_opacity: float
    border_color: str
    border_line_scale: float


@dataclass(frozen=True, slots=True)
class _DetailsPanelAnchorsTheme:
    with_progress_bar_at_top: tuple[float, float]
    with_progress_bar_at_bottom: tuple[float, float]


@dataclass(frozen=True, slots=True)
class _ProgressBarStyleTheme:
    background_color: str
    foreground_color: str
    line_scale: float


@dataclass(frozen=True, slots=True)
class _AnnotationsTheme:
    text_color: str
    muted_text_color: str
    heading_text_color: str
    font_scale: float
    panel_style: _PanelStyleTheme
    details_panel_anchors_in_axes_coordinates: _DetailsPanelAnchorsTheme
    progress_bar_style: _ProgressBarStyleTheme


@dataclass(frozen=True, slots=True)
class AutonomousDrivingVisualizationTheme:
    canvas: _CanvasTheme
    surfaces: _SurfacesTheme
    markings: _MarkingsTheme
    roadside: _RoadsideTheme
    vehicle: _VehicleTheme
    mpc: _MPCTheme
    annotations: _AnnotationsTheme
    layer_order: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return _to_json_native(self)


def _to_json_native(value):
    if is_dataclass(value):
        return {
            field.name: _to_json_native(field_value)
            for field in fields(value)
            if (field_value := getattr(value, field.name)) is not None
        }
    if isinstance(value, tuple):
        return [_to_json_native(item) for item in value]
    return value


def _normalise_colour(value, path):
    if isinstance(value, str):
        if len(value) == 4 and value.startswith("#") and all(character in "0123456789abcdefABCDEF" for character in value[1:]):
            return "#" + "".join(character * 2 for character in value[1:]).lower()
        if len(value) == 7 and value.startswith("#") and all(character in "0123456789abcdefABCDEF" for character in value[1:]):
            return value.lower()
        raise ValueError(f"{path} must be #RGB, #RRGGBB, or an RGB triple")
    if isinstance(value, (list, tuple)) and len(value) == 3:
        if all(isinstance(component, int) and not isinstance(component, bool) and 0 <= component <= 255 for component in value):
            return "#" + "".join(f"{component:02x}" for component in value)
    raise ValueError(f"{path} must be #RGB, #RRGGBB, or an RGB triple")


def _finite_number(value, path, *, minimum=None, allow_zero=False, maximum=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{path} must be a finite number")
    if minimum is not None and (value < minimum or (value == minimum and not allow_zero)):
        raise ValueError(f"{path} has an invalid value")
    if maximum is not None and value > maximum:
        raise ValueError(f"{path} has an invalid value")
    return value


def _normalise_sequence(value, path, *, length=None, bounded=False):
    if not isinstance(value, (list, tuple)) or (length is not None and len(value) != length):
        raise ValueError(f"{path} must be a sequence of the required length")
    return tuple(
        _finite_number(item, f"{path}[{index}]", minimum=0, allow_zero=bounded, maximum=1 if bounded else None)
        for index, item in enumerate(value)
    )


def _merge_sparse(base, supplied, path=""):
    if not isinstance(supplied, Mapping):
        raise TypeError(f"{path or 'visualization_theme'} must be a mapping")
    for key, value in supplied.items():
        field_path = f"{path}.{key}" if path else str(key)
        if key not in base:
            raise ValueError(f"unknown visualization theme field: {field_path}")
        if isinstance(base[key], Mapping):
            base[key] = _merge_sparse(deepcopy(base[key]), value, field_path)
        else:
            base[key] = value
    return base


def _validate_mapping(data):
    def visit(value, canonical, path):
        if isinstance(canonical, Mapping):
            if not isinstance(value, Mapping):
                raise TypeError(f"{path} must be a mapping")
            return {key: visit(value[key], nested, f"{path}.{key}" if path else key) for key, nested in canonical.items()}
        field = path.rsplit(".", 1)[-1]
        if canonical is None and value is None:
            return None
        if field in _COLOUR_FIELDS or path.startswith("roadside.cone_colors."):
            return _normalise_colour(value, path)
        if field.endswith("opacity"):
            return _finite_number(value, path, minimum=0, allow_zero=True, maximum=1)
        if field.endswith("cadence_m"):
            length = 4 if field == "dash_dot_cadence_m" else 2
            return _normalise_sequence(value, path, length=length)
        if field in {
            "recommended_speed_anchor_in_axes_coordinates",
            "with_progress_bar_at_top",
            "with_progress_bar_at_bottom",
        }:
            return _normalise_sequence(value, path, length=2, bounded=True)
        if field.endswith("pattern"):
            if value not in _PATTERNS:
                raise ValueError(f"{path} must be one of {sorted(_PATTERNS)}")
            return value
        if field.endswith("shape"):
            if value not in _MARKERS:
                raise ValueError(f"{path} must be one of {sorted(_MARKERS)}")
            return value
        if field.endswith("scale") or field in {
            "speed_sign_shrink_start_view_span_factor",
            "horizontal_gap_fraction_of_axes_width",
        }:
            return _finite_number(
                value,
                path,
                minimum=0,
                allow_zero=field.endswith("outline_scale"),
            )
        if field == "font_family":
            if not isinstance(value, str) or not value:
                raise ValueError(f"{path} must be a non-empty string")
            return value
        return value

    validated = visit(data, _CANONICAL_THEME, "")
    layer_order = validated["layer_order"]
    if not isinstance(layer_order, (list, tuple)) or len(layer_order) != len(_LAYER_NAMES) or set(layer_order) != set(_LAYER_NAMES):
        raise ValueError("layer_order must contain every required layer exactly once")
    if len(set(layer_order)) != len(layer_order):
        raise ValueError("layer_order must not contain duplicates")
    validated["layer_order"] = tuple(layer_order)
    _validate_layer_order(validated["layer_order"])
    return validated


def _validate_layer_order(order):
    positions = {name: index for index, name in enumerate(order)}
    if positions["canvas"] != 0 or positions["annotations"] != len(order) - 2 or positions["hud"] != len(order) - 1:
        raise ValueError("layer_order must keep canvas first, annotations second-last, and hud last")
    relations = (
        ("formulation_target", "predicted_path"),
        ("formulation_target", "prediction_nodes"),
        ("first_predicted_state", "prediction_nodes"),
        ("first_predicted_state", "formulation_target"),
    )
    relations += tuple(("vehicle", earlier) for earlier in ("lane_envelope", "sensor_preview", "predicted_path", "predicted_headings", "executed_segment", "actual_trajectory", "formulation_target", "prediction_nodes", "sensor_markers", "first_predicted_state"))
    for later, earlier in relations:
        if positions[later] <= positions[earlier]:
            raise ValueError(f"layer_order must put {later} after {earlier}")


def _record(record_type, values):
    return record_type(**values)


def _build_theme(data):
    mpc = data["mpc"]
    roadside = data["roadside"]
    annotations = data["annotations"]
    return AutonomousDrivingVisualizationTheme(
        canvas=_record(_CanvasTheme, data["canvas"]),
        surfaces=_record(_SurfacesTheme, data["surfaces"]),
        markings=_record(_MarkingsTheme, data["markings"]),
        roadside=_RoadsideTheme(
            cone_colors=_record(_ConeColorsTheme, roadside["cone_colors"]),
            fixed_speed_sign_layout=_record(
                _FixedSpeedSignLayoutTheme,
                roadside["fixed_speed_sign_layout"],
            ),
            **{
                key: value
                for key, value in roadside.items()
                if key not in {"cone_colors", "fixed_speed_sign_layout"}
            },
        ),
        vehicle=_record(_VehicleTheme, data["vehicle"]),
        mpc=_MPCTheme(
            predicted_path=_record(_LineTheme, mpc["predicted_path"]),
            prediction_nodes=_record(_MarkerTheme, mpc["prediction_nodes"]),
            formulation_target=_record(_LineTheme, mpc["formulation_target"]),
            first_predicted_state=_record(_MarkerTheme, mpc["first_predicted_state"]),
            actual_trajectory=_record(_LineTheme, mpc["actual_trajectory"]),
            actual_vehicle_fallback_marker=_record(
                _MarkerTheme,
                mpc["actual_vehicle_fallback_marker"],
            ),
            predicted_headings=_record(_LineTheme, mpc["predicted_headings"]),
            sensor_preview=_record(_LineMarkerTheme, mpc["sensor_preview"]),
            unavailable_sensor_preview_marker=_record(
                _MarkerTheme,
                mpc["unavailable_sensor_preview_marker"],
            ),
            lane_envelope=_record(_LineTheme, mpc["lane_envelope"]),
            executed_segment=_record(_LineTheme, mpc["executed_segment"]),
        ),
        annotations=_AnnotationsTheme(
            panel_style=_record(_PanelStyleTheme, annotations["panel_style"]),
            details_panel_anchors_in_axes_coordinates=_record(
                _DetailsPanelAnchorsTheme,
                annotations["details_panel_anchors_in_axes_coordinates"],
            ),
            progress_bar_style=_record(
                _ProgressBarStyleTheme,
                annotations["progress_bar_style"],
            ),
            **{
                key: value
                for key, value in annotations.items()
                if key not in {
                    "panel_style",
                    "details_panel_anchors_in_axes_coordinates",
                    "progress_bar_style",
                }
            },
        ),
        layer_order=data["layer_order"],
    )


def default_autonomous_driving_visualization_theme() -> AutonomousDrivingVisualizationTheme:
    """Return a new resolved instance of the canonical teaching theme."""
    return _build_theme(_validate_mapping(deepcopy(_CANONICAL_THEME)))


def _validate_resolved_theme(
    theme: AutonomousDrivingVisualizationTheme,
    *,
    path: str,
) -> AutonomousDrivingVisualizationTheme:
    parent_records = (
        (path, theme, AutonomousDrivingVisualizationTheme),
        (f"{path}.canvas", theme.canvas, _CanvasTheme),
        (f"{path}.surfaces", theme.surfaces, _SurfacesTheme),
        (f"{path}.markings", theme.markings, _MarkingsTheme),
        (f"{path}.roadside", theme.roadside, _RoadsideTheme),
        (f"{path}.vehicle", theme.vehicle, _VehicleTheme),
        (f"{path}.mpc", theme.mpc, _MPCTheme),
        (f"{path}.annotations", theme.annotations, _AnnotationsTheme),
    )
    for field_path, record, record_type in parent_records:
        if type(record) is not record_type:
            raise TypeError(f"{field_path} must be a {record_type.__name__}")

    nested_records = (
        (
            f"{path}.roadside.cone_colors",
            theme.roadside.cone_colors,
            _ConeColorsTheme,
        ),
        (
            f"{path}.roadside.fixed_speed_sign_layout",
            theme.roadside.fixed_speed_sign_layout,
            _FixedSpeedSignLayoutTheme,
        ),
        (
            f"{path}.annotations.panel_style",
            theme.annotations.panel_style,
            _PanelStyleTheme,
        ),
        (
            f"{path}.annotations.details_panel_anchors_in_axes_coordinates",
            theme.annotations.details_panel_anchors_in_axes_coordinates,
            _DetailsPanelAnchorsTheme,
        ),
        (
            f"{path}.annotations.progress_bar_style",
            theme.annotations.progress_bar_style,
            _ProgressBarStyleTheme,
        ),
    )
    for field_path, record, record_type in nested_records:
        if type(record) is not record_type:
            raise TypeError(f"{field_path} must be a {record_type.__name__}")

    mpc_records = (
        (f"{path}.mpc.predicted_path", theme.mpc.predicted_path, _LineTheme),
        (f"{path}.mpc.prediction_nodes", theme.mpc.prediction_nodes, _MarkerTheme),
        (f"{path}.mpc.formulation_target", theme.mpc.formulation_target, _LineTheme),
        (f"{path}.mpc.first_predicted_state", theme.mpc.first_predicted_state, _MarkerTheme),
        (f"{path}.mpc.actual_trajectory", theme.mpc.actual_trajectory, _LineTheme),
        (
            f"{path}.mpc.actual_vehicle_fallback_marker",
            theme.mpc.actual_vehicle_fallback_marker,
            _MarkerTheme,
        ),
        (f"{path}.mpc.predicted_headings", theme.mpc.predicted_headings, _LineTheme),
        (f"{path}.mpc.sensor_preview", theme.mpc.sensor_preview, _LineMarkerTheme),
        (
            f"{path}.mpc.unavailable_sensor_preview_marker",
            theme.mpc.unavailable_sensor_preview_marker,
            _MarkerTheme,
        ),
        (f"{path}.mpc.lane_envelope", theme.mpc.lane_envelope, _LineTheme),
        (f"{path}.mpc.executed_segment", theme.mpc.executed_segment, _LineTheme),
    )
    for field_path, record, record_type in mpc_records:
        if type(record) is not record_type:
            raise TypeError(f"{field_path} must be a {record_type.__name__}")

    try:
        rebuilt = _build_theme(
            _validate_mapping(
                _merge_sparse(deepcopy(_CANONICAL_THEME), theme.to_dict())
            )
        )
    except (TypeError, ValueError) as error:
        raise type(error)(f"{path}.{error}") from error
    if rebuilt != theme:
        raise ValueError(f"{path} must be a canonical resolved visualization theme")
    return theme


def resolve_autonomous_driving_visualization_theme(
    visualization_theme=None,
    *,
    inherited_theme=None,
) -> AutonomousDrivingVisualizationTheme:
    """Resolve ``None``, a frozen theme, or a strict sparse mapping."""
    if inherited_theme is not None and not isinstance(inherited_theme, AutonomousDrivingVisualizationTheme):
        raise TypeError("inherited_theme must be an AutonomousDrivingVisualizationTheme")
    if inherited_theme is not None:
        _validate_resolved_theme(inherited_theme, path="inherited_theme")
    if isinstance(visualization_theme, AutonomousDrivingVisualizationTheme):
        return _validate_resolved_theme(visualization_theme, path="visualization_theme")
    if visualization_theme is None:
        return inherited_theme if inherited_theme is not None else default_autonomous_driving_visualization_theme()
    if not isinstance(visualization_theme, Mapping):
        raise TypeError("visualization_theme must be None, a resolved theme, or a mapping")
    base = deepcopy(_CANONICAL_THEME)
    if inherited_theme is not None:
        base = _merge_sparse(base, inherited_theme.to_dict())
    return _build_theme(_validate_mapping(_merge_sparse(base, visualization_theme)))


__all__ = [
    "AutonomousDrivingVisualizationTheme",
    "default_autonomous_driving_visualization_theme",
    "resolve_autonomous_driving_visualization_theme",
]
