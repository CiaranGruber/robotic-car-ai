"""Offline Matplotlib views for autonomous-driving MPC rollout histories."""

from __future__ import annotations

import numpy as np

from dreamgym.evaluation.autonomous_driving.mpc_history import (
    AutonomousDrivingMPCRolloutHistory,
)


_DRIVING_UNITS = {
    "m/s": (3.6, "km/h"),
    "rad": (180.0 / np.pi, "deg"),
    "rad/s": (180.0 / np.pi, "deg/s"),
    "m": (1.0, "m"),
    "1": (1.0, "1"),
}


def _pyplot():
    import matplotlib.pyplot as plt

    return plt


def _display(values, unit_si, profile):
    if profile == "si":
        return np.asarray(values), unit_si
    if profile != "driving":
        raise ValueError("display_units must be exactly 'driving' or 'si'")
    scale, label = _DRIVING_UNITS[unit_si]
    return np.asarray(values) * scale, label


def _require_history(history):
    if not isinstance(history, AutonomousDrivingMPCRolloutHistory):
        raise TypeError(
            "history must be an AutonomousDrivingMPCRolloutHistory"
        )
    if history.transition_count == 0:
        raise ValueError("history is empty and has no transition to plot")


def _strict_index(value, count):
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise TypeError("transition_index must be an integer")
    value = int(value)
    if value < 0 or value >= count:
        raise IndexError(f"transition_index must lie in 0..{count - 1}")
    return value


def _positive_integer(name, value):
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise TypeError(f"{name} must be an integer")
    value = int(value)
    if value <= 0:
        raise ValueError(f"{name} must be greater than zero")
    return value


def _names(values, valid, argument):
    if values is None:
        return tuple(valid)
    values = tuple(values)
    if len(set(values)) != len(values):
        raise ValueError(f"{argument} contains duplicate names")
    unknown = tuple(value for value in values if value not in valid)
    if unknown:
        raise ValueError(
            f"{argument} contains {unknown}; valid choices are {tuple(valid)}"
        )
    return values


def _selected_keys(states, controls):
    return (
        tuple(f"state:{name}" for name in states)
        + tuple(f"control:{name}" for name in controls)
        + (
            "action:normalized_steering_command",
            "action:steering_angle_request",
        )
    )


def _prediction_keys(states, controls):
    return (
        tuple(f"state:{name}" for name in states)
        + tuple(f"control:{name}" for name in controls)
    )


def _lead_steps(values, horizon_steps):
    if values is None:
        return tuple(value for value in (1, 5, 10) if value <= horizon_steps)
    leads = tuple(values)
    if len(set(leads)) != len(leads):
        raise ValueError("lead_steps contains duplicate values")
    for value in leads:
        if isinstance(value, bool) or not isinstance(
            value,
            (int, np.integer),
        ):
            raise TypeError("lead_steps must contain integers")
        if value < 0 or value > horizon_steps:
            raise ValueError(f"lead_steps must lie in 0..{horizon_steps}")
    return tuple(int(value) for value in leads)


def _axes(keys):
    figure, raw_axes = _pyplot().subplots(
        len(keys),
        1,
        figsize=(9, max(5, 2.2 * len(keys))),
        constrained_layout=True,
    )
    axes = np.atleast_1d(raw_axes).reshape(-1)
    return figure, dict(zip(keys, axes, strict=True))


def _plot(axis, x, y, label):
    axis.plot(np.asarray(x), np.asarray(y), label=label)


def _legend_outside(axis):
    axis.legend(
        loc="center left",
        bbox_to_anchor=(1.01, 0.5),
        borderaxespad=0.0,
    )


def _plot_finite_values(axis, x, y, label):
    values = np.asarray(y)
    finite = np.isfinite(values)
    if finite.any():
        _plot(axis, x, np.where(finite, values, np.nan), label)


def _optional_series(records, getter):
    values = []
    for record in records:
        value = getter(record)
        values.append(np.nan if value is None else float(value))
    return np.asarray(values)


def _prediction_value(record, getter):
    solve_result = record.policy_result.solve_result
    if solve_result is None:
        return np.nan
    prediction = solve_result.prediction
    return np.nan if prediction is None else float(getter(prediction))


def _outcome_status(record):
    result = record.policy_result
    if result.solve_status is not None:
        return result.solve_status
    failure = result.failure
    assert failure is not None
    return f"policy failure: {failure.reason}"


def _solver_diagnostic(record, attribute):
    solve_result = record.policy_result.solve_result
    if solve_result is None:
        return None
    return getattr(solve_result.diagnostics, attribute)


def _action_axes(history):
    keys = [
        "objective",
        *[
            f"slack:{name}"
            for name in history.variable_metadata.state_names
        ],
        "fallback_mode",
        "fallback_used",
        "clipping",
        "action:normalized_drive_command",
        "action:normalized_steering_command",
        "action:steering_angle_request",
    ]
    if "steering_rate" in history.variable_metadata.control_names:
        keys.append("action:steering_rate")
    return tuple(keys)


def _render_selected(
    history,
    transition_index,
    axes,
    *,
    state_names,
    control_names,
    display_units,
):
    record = history.records[transition_index]
    alignment = history.alignment_at(transition_index)
    metadata = history.variable_metadata
    context = record.prediction_context
    solve_result = record.policy_result.solve_result
    prediction = None if solve_result is None else solve_result.prediction
    request = record.policy_result.action_request
    execution = record.action_execution

    for name in state_names:
        index = metadata.state_names.index(name)
        unit_si = metadata.state_units_si[index]
        axis = axes[f"state:{name}"]
        axis.clear()
        actual, unit = _display(
            alignment.actual_states[:, index], unit_si, display_units
        )
        _plot(axis, alignment.actual_state_times_seconds, actual, "actual")
        if context is not None:
            reference, _ = _display(
                context.state_references[:, index], unit_si, display_units
            )
            _plot(
                axis,
                alignment.predicted_state_times_seconds,
                reference,
                "reference",
            )
            for values, label in (
                (context.hard_state_lower_bounds[:, index], "hard lower"),
                (context.hard_state_upper_bounds[:, index], "hard upper"),
                (context.soft_state_lower_bounds[:, index], "soft lower"),
                (context.soft_state_upper_bounds[:, index], "soft upper"),
            ):
                shown, _ = _display(values, unit_si, display_units)
                _plot_finite_values(
                    axis,
                    alignment.predicted_state_times_seconds[1:],
                    shown,
                    label,
                )
        if alignment.predicted_states is not None:
            shown, _ = _display(
                alignment.predicted_states[:, index],
                unit_si,
                display_units,
            )
            _plot(
                axis,
                alignment.predicted_state_times_seconds,
                shown,
                "predicted",
            )
            if prediction is not None:
                for values, label in (
                    (prediction.lower_state_slack[:, index], "lower slack"),
                    (prediction.upper_state_slack[:, index], "upper slack"),
                ):
                    shown, _ = _display(values, unit_si, display_units)
                    _plot(
                        axis,
                        alignment.predicted_state_times_seconds[1:],
                        shown,
                        label,
                    )
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)

    for name in control_names:
        index = metadata.control_names.index(name)
        unit_si = metadata.control_units_si[index]
        axis = axes[f"control:{name}"]
        axis.clear()
        actual, unit = _display(
            alignment.actual_controls[:, index], unit_si, display_units
        )
        _plot(
            axis,
            alignment.actual_control_times_seconds,
            actual,
            "actual comparator",
        )
        if context is not None:
            for values, label in (
                (context.control_references[:, index], "control reference"),
                (context.control_lower_bounds[:, index], "control lower"),
                (context.control_upper_bounds[:, index], "control upper"),
            ):
                shown, _ = _display(values, unit_si, display_units)
                _plot_finite_values(
                    axis,
                    alignment.predicted_control_times_seconds,
                    shown,
                    label,
                )
        if alignment.predicted_controls is not None:
            shown, _ = _display(
                alignment.predicted_controls[:, index],
                unit_si,
                display_units,
            )
            _plot(
                axis,
                alignment.predicted_control_times_seconds,
                shown,
                "predicted",
            )
        if name == "normalized_drive_command":
            for value, label in (
                (
                    request.normalized_action_before_clipping[0],
                    "pre-clip drive",
                ),
                (request.environment_action[0], "emitted drive"),
                (
                    execution.environment_normalized_drive_command_request,
                    "environment drive request",
                ),
                (execution.applied_normalized_drive_command, "applied drive"),
            ):
                _plot(axis, [record.time_seconds], [value], label)
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)

    normalized = axes["action:normalized_steering_command"]
    normalized.clear()
    _plot(
        normalized,
        [record.time_seconds],
        [request.normalized_action_before_clipping[1]],
        "pre-clip steering",
    )
    _plot(
        normalized,
        [record.time_seconds],
        [request.environment_action[1]],
        "emitted steering",
    )
    normalized.set_ylabel("[1]")
    _legend_outside(normalized)

    angle = axes["action:steering_angle_request"]
    angle.clear()
    for value, label in (
        (request.requested_steering_angle_radians, "policy steering request"),
        (
            execution.environment_steering_request_radians,
            "environment steering request",
        ),
        (
            execution.environment_steering_target_radians,
            "environment steering target",
        ),
    ):
        shown, unit = _display([value], "rad", display_units)
        _plot(angle, [record.time_seconds], shown, label)
    realized, unit = _display(
        [execution.realized_steering_angle_radians],
        "rad",
        display_units,
    )
    _plot(
        angle,
        [record.time_seconds + history.control_timestep_seconds],
        realized,
        "realized steering angle",
    )
    angle.set_ylabel(f"[{unit}]")
    _legend_outside(angle)
    solve_status = _outcome_status(record)
    if not alignment.prediction_available:
        solve_status = f"failed: {solve_status}"
    axes[next(iter(axes))].figure.suptitle(
        f"transition {transition_index}: "
        f"{solve_status}; "
        f"fallback={record.policy_result.fallback_mode}"
    )


def animate_mpc_prediction_history(
    history,
    *,
    frame_step=1,
    state_names=None,
    control_names=None,
    display_units="driving",
):
    import matplotlib.animation as mpl_animation

    _require_history(history)
    step = _positive_integer("frame_step", frame_step)
    metadata = history.variable_metadata
    states = _names(state_names, metadata.state_names, "state_names")
    controls = _names(
        control_names,
        metadata.control_names,
        "control_names",
    )
    _display([], "1", display_units)
    figure, axes = _axes(_selected_keys(states, controls))
    for key, axis in axes.items():
        axis.set_gid(key)

    def update(transition_index):
        _render_selected(
            history,
            transition_index,
            axes,
            state_names=states,
            control_names=controls,
            display_units=display_units,
        )
        return tuple(axes.values())

    return mpl_animation.FuncAnimation(
        figure,
        update,
        frames=range(0, history.transition_count, step),
        interval=(
            1000.0
            * step
            * history.control_timestep_seconds
        ),
    )


def plot_mpc_prediction_at_transition(
    history,
    transition_index,
    *,
    state_names=None,
    control_names=None,
    display_units="driving",
):
    _require_history(history)
    index = _strict_index(transition_index, history.transition_count)
    metadata = history.variable_metadata
    states = _names(state_names, metadata.state_names, "state_names")
    controls = _names(control_names, metadata.control_names, "control_names")
    _display([], "1", display_units)
    figure, axes = _axes(_selected_keys(states, controls))
    _render_selected(
        history,
        index,
        axes,
        state_names=states,
        control_names=controls,
        display_units=display_units,
    )
    return figure, axes


def plot_mpc_prediction_horizon_fan(
    history,
    *,
    prediction_stride=1,
    state_names=None,
    control_names=None,
    display_units="driving",
):
    _require_history(history)
    stride = _positive_integer("prediction_stride", prediction_stride)
    metadata = history.variable_metadata
    states = _names(state_names, metadata.state_names, "state_names")
    controls = _names(control_names, metadata.control_names, "control_names")
    _display([], "1", display_units)
    figure, axes = _axes(_prediction_keys(states, controls))
    alignments = tuple(
        history.alignment_at(origin)
        for origin in range(0, history.transition_count, stride)
    )

    for name in states:
        index = metadata.state_names.index(name)
        unit_si = metadata.state_units_si[index]
        axis = axes[f"state:{name}"]
        actual, unit = _display(
            history.actual_model_states[:, index],
            unit_si,
            display_units,
        )
        axis.plot(
            history.actual_state_times_seconds,
            actual,
            color="black",
            linewidth=2.5,
            zorder=10,
            label="actual",
        )
        for alignment in alignments:
            if alignment.predicted_states is None:
                continue
            shown, _ = _display(
                alignment.predicted_states[:, index],
                unit_si,
                display_units,
            )
            _plot(
                axis,
                alignment.predicted_state_times_seconds,
                shown,
                f"prediction {alignment.transition_index}",
            )
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)

    for name in controls:
        index = metadata.control_names.index(name)
        unit_si = metadata.control_units_si[index]
        axis = axes[f"control:{name}"]
        actual, unit = _display(
            history.applied_control_comparators[:, index],
            unit_si,
            display_units,
        )
        axis.plot(
            history.transition_times_seconds,
            actual,
            color="black",
            linewidth=2.5,
            zorder=10,
            label="actual",
        )
        for alignment in alignments:
            if alignment.predicted_controls is None:
                continue
            shown, _ = _display(
                alignment.predicted_controls[:, index],
                unit_si,
                display_units,
            )
            _plot(
                axis,
                alignment.predicted_control_times_seconds,
                shown,
                f"prediction {alignment.transition_index}",
            )
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)
    return figure, axes


def plot_mpc_fixed_lead_predictions(
    history,
    *,
    lead_steps=None,
    state_names=None,
    control_names=None,
    display_units="driving",
):
    _require_history(history)
    metadata = history.variable_metadata
    states = _names(state_names, metadata.state_names, "state_names")
    controls = _names(control_names, metadata.control_names, "control_names")
    _display([], "1", display_units)
    alignments = tuple(
        history.alignment_at(origin)
        for origin in range(history.transition_count)
    )
    horizon = alignments[0].predicted_control_times_seconds.shape[0]
    leads = _lead_steps(lead_steps, horizon)
    figure, axes = _axes(_prediction_keys(states, controls))

    for name in states:
        index = metadata.state_names.index(name)
        unit_si = metadata.state_units_si[index]
        axis = axes[f"state:{name}"]
        actual, unit = _display(
            history.actual_model_states[:, index],
            unit_si,
            display_units,
        )
        _plot(axis, history.actual_state_times_seconds, actual, "actual")
        if 0 in leads:
            visible, _ = _display(
                history.controller_visible_model_states[:, index],
                unit_si,
                display_units,
            )
            _plot(
                axis,
                history.transition_times_seconds,
                visible,
                "controller-visible lead 0",
            )
        for lead in leads:
            times = np.empty(history.transition_count)
            values = np.full(history.transition_count, np.nan)
            for origin, alignment in enumerate(alignments):
                times[origin] = alignment.predicted_state_times_seconds[lead]
                if (
                    alignment.predicted_states is not None
                    and alignment.state_availability_mask[lead]
                ):
                    values[origin] = alignment.predicted_states[lead, index]
            shown, _ = _display(values, unit_si, display_units)
            _plot(axis, times, shown, f"prediction lead {lead}")
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)

    for name in controls:
        index = metadata.control_names.index(name)
        unit_si = metadata.control_units_si[index]
        axis = axes[f"control:{name}"]
        actual, unit = _display(
            history.applied_control_comparators[:, index],
            unit_si,
            display_units,
        )
        _plot(axis, history.transition_times_seconds, actual, "actual")
        for lead in leads:
            if lead == horizon:
                continue
            times = np.empty(history.transition_count)
            values = np.full(history.transition_count, np.nan)
            for origin, alignment in enumerate(alignments):
                times[origin] = alignment.predicted_control_times_seconds[lead]
                if (
                    alignment.predicted_controls is not None
                    and alignment.control_availability_mask[lead]
                ):
                    values[origin] = alignment.predicted_controls[lead, index]
            shown, _ = _display(values, unit_si, display_units)
            _plot(axis, times, shown, f"prediction lead {lead}")
        axis.set_ylabel(f"{name} [{unit}]")
        _legend_outside(axis)
    return figure, axes


def plot_mpc_solver_health(history, *, display_units="driving"):
    _require_history(history)
    _display([], "1", display_units)
    figure, axes = _axes(
        ("status", "usable", "iterations", "residuals", "timings")
    )
    time = (
        np.arange(history.transition_count)
        * history.control_timestep_seconds
    )
    records = history.records
    usable = np.array(
        [record.policy_result.solve_usable for record in records],
        dtype=float,
    )
    statuses = [_outcome_status(record) for record in records]
    categories = {
        name: index
        for index, name in enumerate(dict.fromkeys(statuses))
    }
    status_values = np.array([categories[name] for name in statuses])
    _plot(axes["status"], time, status_values, "status")
    axes["status"].set_yticks(
        list(categories.values()),
        list(categories.keys()),
    )
    _plot(axes["usable"], time, usable, "usable")
    axes["usable"].set_yticks([0.0, 1.0], ["rejected", "usable"])

    diagnostics = [
        (
            None
            if record.policy_result.solve_result is None
            else record.policy_result.solve_result.diagnostics
        )
        for record in records
    ]
    _plot(
        axes["iterations"],
        time,
        np.array(
            [
                np.nan
                if item is None or item.iterations is None
                else item.iterations
                for item in diagnostics
            ]
        ),
        "iterations",
    )
    for attribute, label in (
        ("primal_residual", "primal residual"),
        ("dual_residual", "dual residual"),
    ):
        _plot(
            axes["residuals"],
            time,
            np.array(
                [
                    np.nan
                    if item is None or getattr(item, attribute) is None
                    else getattr(item, attribute)
                    for item in diagnostics
                ]
            ),
            label,
        )
    axes["residuals"].set_yscale("symlog", linthresh=1e-12)

    timing_getters = (
        (
            "model schedule",
            lambda record: record.policy_result.model_schedule_time_seconds,
        ),
        (
            "solver formulation",
            lambda record: _solver_diagnostic(
                record, "formulation_time_seconds"
            ),
        ),
        (
            "solver setup",
            lambda record: _solver_diagnostic(record, "setup_time_seconds"),
        ),
        (
            "solver solve",
            lambda record: _solver_diagnostic(record, "solve_time_seconds"),
        ),
        (
            "solver run",
            lambda record: _solver_diagnostic(record, "run_time_seconds"),
        ),
        (
            "solver postprocessing",
            lambda record: _solver_diagnostic(
                record, "postprocessing_time_seconds"
            ),
        ),
        (
            "solver total",
            lambda record: _solver_diagnostic(record, "total_time_seconds"),
        ),
        (
            "policy postprocessing",
            lambda record: record.policy_result.postprocessing_time_seconds,
        ),
        (
            "policy total",
            lambda record: record.policy_result.total_time_seconds,
        ),
    )
    for label, getter in timing_getters:
        _plot(axes["timings"], time, _optional_series(records, getter), label)
    for axis in axes.values():
        axis.grid(True, linestyle="--", alpha=0.4)
        _legend_outside(axis)
    axes["timings"].set_ylabel("seconds")
    return figure, axes


def plot_mpc_controller_outcomes(history, *, display_units="driving"):
    _require_history(history)
    _display([], "1", display_units)
    figure, axes = _axes(_action_axes(history))
    time = (
        np.arange(history.transition_count)
        * history.control_timestep_seconds
    )
    records = history.records
    objectives = np.array(
        [
            _prediction_value(
                record,
                lambda prediction: prediction.objective_value,
            )
            for record in records
        ]
    )
    _plot(axes["objective"], time, objectives, "teaching objective")

    for state_index, state_name in enumerate(
        history.variable_metadata.state_names
    ):
        axis = axes[f"slack:{state_name}"]
        unit_si = history.variable_metadata.state_units_si[state_index]
        lower = np.array(
            [
                _prediction_value(
                    record,
                    lambda prediction, index=state_index: np.max(
                        prediction.lower_state_slack[:, index]
                    ),
                )
                for record in records
            ]
        )
        upper = np.array(
            [
                _prediction_value(
                    record,
                    lambda prediction, index=state_index: np.max(
                        prediction.upper_state_slack[:, index]
                    ),
                )
                for record in records
            ]
        )
        lower, unit = _display(lower, unit_si, display_units)
        upper, _ = _display(upper, unit_si, display_units)
        _plot(axis, time, lower, "max lower slack")
        _plot(axis, time, upper, "max upper slack")
        axis.set_ylabel(f"[{unit}]")

    fallback_modes = [
        (
            "none"
            if record.policy_result.fallback_mode is None
            else record.policy_result.fallback_mode.value
        )
        for record in records
    ]
    fallback_categories = {
        name: index
        for index, name in enumerate(dict.fromkeys(fallback_modes))
    }
    _plot(
        axes["fallback_mode"],
        time,
        np.asarray(
            [fallback_categories[name] for name in fallback_modes]
        ),
        "fallback mode",
    )
    axes["fallback_mode"].set_yticks(
        list(fallback_categories.values()),
        list(fallback_categories.keys()),
    )
    _plot(
        axes["fallback_used"],
        time,
        np.array(
            [record.policy_result.fallback_action_used for record in records],
            dtype=float,
        ),
        "fallback used",
    )
    axes["fallback_used"].set_yticks(
        [0.0, 1.0],
        ["not used", "used"],
    )
    _plot(
        axes["clipping"],
        time,
        np.array(
            [
                record.policy_result.action_request.drive_command_was_clipped
                for record in records
            ],
            dtype=float,
        ),
        "drive clipped",
    )
    _plot(
        axes["clipping"],
        time,
        np.array(
            [
                record.policy_result.action_request.steering_command_was_clipped
                for record in records
            ],
            dtype=float,
        ),
        "steering clipped",
    )

    drive = axes["action:normalized_drive_command"]
    drive_series = (
        (
            "planned drive",
            lambda record: (
                np.nan
                if record.policy_result.action_request.planned_model_control
                is None
                else record.policy_result.action_request.planned_model_control[0]
            ),
        ),
        (
            "pre-clip drive",
            lambda record: (
                record.policy_result.action_request.normalized_action_before_clipping[
                    0
                ]
            ),
        ),
        (
            "emitted drive",
            lambda record: record.policy_result.action_request.environment_action[0],
        ),
        (
            "environment drive request",
            lambda record: (
                record.action_execution.environment_normalized_drive_command_request
            ),
        ),
        (
            "applied drive",
            lambda record: record.action_execution.applied_normalized_drive_command,
        ),
    )
    for label, getter in drive_series:
        _plot(
            drive,
            time,
            np.array([getter(record) for record in records]),
            label,
        )
    drive.set_ylabel("[1]")

    normalized = axes["action:normalized_steering_command"]
    _plot(
        normalized,
        time,
        np.array(
            [
                record.policy_result.action_request.normalized_action_before_clipping[1]
                for record in records
            ]
        ),
        "pre-clip steering",
    )
    _plot(
        normalized,
        time,
        history.emitted_environment_actions[:, 1],
        "emitted steering",
    )
    normalized.set_ylabel("[1]")

    angle = axes["action:steering_angle_request"]
    if "steering_angle" in history.variable_metadata.control_names:
        planned_angle = np.array(
            [
                np.nan
                if record.policy_result.action_request.planned_model_control
                is None
                else record.policy_result.action_request.planned_model_control[1]
                for record in records
            ]
        )
        planned_angle, angle_unit = _display(
            planned_angle,
            "rad",
            display_units,
        )
        _plot(
            angle,
            time,
            planned_angle,
            "planned steering angle",
        )
    for label, getter in (
        (
            "policy steering request",
            lambda record: (
                record.policy_result.action_request.requested_steering_angle_radians
            ),
        ),
        (
            "environment steering request",
            lambda record: record.action_execution.environment_steering_request_radians,
        ),
        (
            "environment steering target",
            lambda record: record.action_execution.environment_steering_target_radians,
        ),
    ):
        values, angle_unit = _display(
            [getter(record) for record in records],
            "rad",
            display_units,
        )
        _plot(angle, time, values, label)
    realized, angle_unit = _display(
        [
            record.action_execution.realized_steering_angle_radians
            for record in records
        ],
        "rad",
        display_units,
    )
    _plot(
        angle,
        (np.arange(history.transition_count) + 1)
        * history.control_timestep_seconds,
        realized,
        "realized steering angle",
    )
    angle.set_ylabel(f"[{angle_unit}]")

    if "action:steering_rate" in axes:
        rate = axes["action:steering_rate"]
        planned = np.array(
            [
                np.nan
                if record.policy_result.action_request.planned_model_control
                is None
                else record.policy_result.action_request.planned_model_control[1]
                for record in records
            ]
        )
        applied = np.array(
            [
                record.action_execution.applied_steering_rate_radians_per_second
                for record in records
            ]
        )
        planned, rate_unit = _display(planned, "rad/s", display_units)
        applied, _ = _display(applied, "rad/s", display_units)
        _plot(rate, time, planned, "planned steering rate")
        _plot(rate, time, applied, "applied steering rate")
        rate.set_ylabel(f"[{rate_unit}]")

    for axis in axes.values():
        axis.grid(True, linestyle="--", alpha=0.4)
        _legend_outside(axis)
    return figure, axes
