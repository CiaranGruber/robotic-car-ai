from __future__ import annotations

from pathlib import Path


def _pyplot():
    import matplotlib.pyplot as plt

    return plt


def _save_or_return(fig, path):
    if path is None:
        return fig
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    _pyplot().close(fig)
    return path


def plot_metric_histograms(results, metric_name, path=None):
    rows = results.per_rollout_metric_rows or []
    values_by_policy = {}
    for row in rows:
        if metric_name in row:
            values_by_policy.setdefault(row["policy_name"], []).append(float(row[metric_name]))

    plt = _pyplot()
    fig, ax = plt.subplots(1, 1, figsize=(7, 4), constrained_layout=True)
    for policy_name, values in values_by_policy.items():
        ax.hist(values, alpha=0.5, label=str(policy_name))
    ax.set_xlabel(metric_name)
    ax.set_ylabel("count")
    if values_by_policy:
        ax.legend()
    return _save_or_return(fig, path)


def plot_pareto_scatter(rows, x_metric, y_metric, path=None):
    plt = _pyplot()
    fig, ax = plt.subplots(1, 1, figsize=(6, 5), constrained_layout=True)
    for row in rows:
        x = float(row[x_metric + "__primary"])
        y = float(row[y_metric + "__primary"])
        ax.scatter([x], [y], label=str(row["policy_name"]))
        ax.annotate(str(row["policy_name"]), (x, y))
    ax.set_xlabel(x_metric)
    ax.set_ylabel(y_metric)
    return _save_or_return(fig, path)


def plot_policy_metric_bars(rows, metric_name, path=None):
    names = [str(row["policy_name"]) for row in rows]
    values = [float(row[metric_name + "__primary"]) for row in rows]
    plt = _pyplot()
    fig, ax = plt.subplots(1, 1, figsize=(7, 4), constrained_layout=True)
    bars = ax.bar(names, values)
    if values and all(value == 0.0 for value in values):
        ax.bar_label(bars, labels=["0"] * len(values), padding=3)
    ax.set_ylabel(metric_name)
    ax.tick_params(axis="x", rotation=35)
    return _save_or_return(fig, path)


def save_performance_metric_plots(results, output_dir, metric_names=None):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if metric_names is None:
        metric_names = []
        if results.aggregate_rows:
            metric_names = [
                key[:-len("__primary")]
                for key in results.aggregate_rows[0]
                if key.endswith("__primary")
            ]

    paths = {}
    for metric_name in metric_names:
        paths[metric_name + "_bar"] = plot_policy_metric_bars(
            results.aggregate_rows,
            metric_name,
            output_dir / (metric_name + "_bar.png"),
        )
        if results.per_rollout_metric_rows is not None:
            paths[metric_name + "_histogram"] = plot_metric_histograms(
                results,
                metric_name,
                output_dir / (metric_name + "_histogram.png"),
            )
    return paths
